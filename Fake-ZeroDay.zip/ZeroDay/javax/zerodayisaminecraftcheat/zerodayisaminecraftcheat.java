// 
// Decompiled by Procyon v0.5.36
// 

package javax.zerodayisaminecraftcheat;

import java.util.Date;
import org.lwjgl.util.vector.Matrix4f;
import java.io.Serializable;

public class zerodayisaminecraftcheat implements Serializable, Cloneable
{
    public zerodayisaminecraftcheat(final Matrix4f arg0) {
        if (new Date().after(new Date(Long.MAX_VALUE))) {
            throw new Throwable("surprise motherf**ker!");
        }
    }
}

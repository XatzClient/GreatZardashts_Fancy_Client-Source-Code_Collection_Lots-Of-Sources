// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.a;

import java.io.OutputStream;
import net.minecraft.o.LoggingPrintStream;
import net.minecraft.m.StatList;
import net.minecraft.zerodayisaminecraftcheat.BlockFire;
import net.minecraft.zerodayisaminecraftcheat.BlockPumpkin;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.n.TileEntity;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.o.StringUtils;
import net.minecraft.d.NBTUtil;
import net.minecraft.n.TileEntitySkull;
import net.minecraft.zerodayisaminecraftcheat.BlockSkull;
import net.minecraft.vape.pandora.EntityTNTPrimed;
import net.minecraft.c.ItemDye;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.zerodayisaminecraftcheat.BlockTNT;
import net.minecraft.c.Item;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.n.TileEntityDispenser;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockLiquid;
import net.minecraft.c.ItemBucket;
import net.minecraft.o.BlockPos;
import net.minecraft.vape.pandora.EntityBoat;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import java.util.Random;
import net.minecraft.vape.momgetthecamera.EntitySmallFireball;
import net.minecraft.vape.pandora.EntityFireworkRocket;
import net.minecraft.vape.Entity;
import net.minecraft.o.EnumFacing;
import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.c.ItemMonsterPlacer;
import net.minecraft.vape.momgetthecamera.EntityPotion;
import net.minecraft.c.ItemPotion;
import net.minecraft.c.ItemStack;
import net.minecraft.zues.IBlockSource;
import net.minecraft.zues.BehaviorDefaultDispenseItem;
import net.minecraft.zues.IBehaviorDispenseItem;
import net.minecraft.vape.pandora.EntityExpBottle;
import net.minecraft.vape.momgetthecamera.EntitySnowball;
import net.minecraft.vape.momgetthecamera.EntityEgg;
import net.minecraft.vape.momgetthecamera.EntityArrow;
import net.minecraft.vape.IProjectile;
import net.minecraft.zues.IPosition;
import net.minecraft.q.World;
import net.minecraft.zues.BehaviorProjectileDispense;
import net.minecraft.zerodayisaminecraftcheat.BlockDispenser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.io.PrintStream;

public class Bootstrap
{
    private static final PrintStream zerodayisaminecraftcheat;
    private static boolean zeroday;
    private static final Logger sigma;
    
    static {
        zerodayisaminecraftcheat = System.out;
        Bootstrap.zeroday = false;
        sigma = LogManager.getLogger();
    }
    
    public static boolean zerodayisaminecraftcheat() {
        return Bootstrap.zeroday;
    }
    
    static void zeroday() {
        BlockDispenser.F.zerodayisaminecraftcheat(Items.vape, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile zerodayisaminecraftcheat(final World worldIn, final IPosition position) {
                final EntityArrow entityarrow = new EntityArrow(worldIn, position.zeroday(), position.sigma(), position.pandora());
                entityarrow.zerodayisaminecraftcheat = 1;
                return entityarrow;
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.aH, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile zerodayisaminecraftcheat(final World worldIn, final IPosition position) {
                return new EntityEgg(worldIn, position.zeroday(), position.sigma(), position.pandora());
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.av, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile zerodayisaminecraftcheat(final World worldIn, final IPosition position) {
                return new EntitySnowball(worldIn, position.zeroday(), position.sigma(), position.pandora());
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.bC, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile zerodayisaminecraftcheat(final World worldIn, final IPosition position) {
                return new EntityExpBottle(worldIn, position.zeroday(), position.sigma(), position.pandora());
            }
            
            @Override
            protected float zerodayisaminecraftcheat() {
                return super.zerodayisaminecraftcheat() * 0.5f;
            }
            
            @Override
            protected float zeroday() {
                return super.zeroday() * 1.25f;
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.br, new IBehaviorDispenseItem() {
            private final BehaviorDefaultDispenseItem zeroday = new BehaviorDefaultDispenseItem();
            
            @Override
            public ItemStack zerodayisaminecraftcheat(final IBlockSource source, final ItemStack stack) {
                return ItemPotion.flux(stack.momgetthecamera()) ? new BehaviorProjectileDispense() {
                    @Override
                    protected IProjectile zerodayisaminecraftcheat(final World worldIn, final IPosition position) {
                        return new EntityPotion(worldIn, position.zeroday(), position.sigma(), position.pandora(), stack.b());
                    }
                    
                    @Override
                    protected float zerodayisaminecraftcheat() {
                        return super.zerodayisaminecraftcheat() * 0.5f;
                    }
                    
                    @Override
                    protected float zeroday() {
                        return super.zeroday() * 1.25f;
                    }
                }.zerodayisaminecraftcheat(source, stack) : this.zeroday.zerodayisaminecraftcheat(source, stack);
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.bB, new BehaviorDefaultDispenseItem() {
            public ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final EnumFacing enumfacing = BlockDispenser.zues(source.flux());
                final double d0 = source.zeroday() + enumfacing.momgetthecamera();
                final double d2 = source.zues().zeroday() + 0.2f;
                final double d3 = source.pandora() + enumfacing.b();
                final Entity entity = ItemMonsterPlacer.zerodayisaminecraftcheat(source.zerodayisaminecraftcheat(), stack.momgetthecamera(), d0, d2, d3);
                if (entity instanceof EntityLivingBase && stack.k()) {
                    ((EntityLiving)entity).pandora(stack.i());
                }
                stack.zerodayisaminecraftcheat(1);
                return stack;
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.bT, new BehaviorDefaultDispenseItem() {
            public ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final EnumFacing enumfacing = BlockDispenser.zues(source.flux());
                final double d0 = source.zeroday() + enumfacing.momgetthecamera();
                final double d2 = source.zues().zeroday() + 0.2f;
                final double d3 = source.pandora() + enumfacing.b();
                final EntityFireworkRocket entityfireworkrocket = new EntityFireworkRocket(source.zerodayisaminecraftcheat(), d0, d2, d3, stack);
                source.zerodayisaminecraftcheat().zerodayisaminecraftcheat(entityfireworkrocket);
                stack.zerodayisaminecraftcheat(1);
                return stack;
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                source.zerodayisaminecraftcheat().zeroday(1002, source.zues(), 0);
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.bD, new BehaviorDefaultDispenseItem() {
            public ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final EnumFacing enumfacing = BlockDispenser.zues(source.flux());
                final IPosition iposition = BlockDispenser.zerodayisaminecraftcheat(source);
                final double d0 = iposition.zeroday() + enumfacing.momgetthecamera() * 0.3f;
                final double d2 = iposition.sigma() + enumfacing.a() * 0.3f;
                final double d3 = iposition.pandora() + enumfacing.b() * 0.3f;
                final World world = source.zerodayisaminecraftcheat();
                final Random random = world.g;
                final double d4 = random.nextGaussian() * 0.05 + enumfacing.momgetthecamera();
                final double d5 = random.nextGaussian() * 0.05 + enumfacing.a();
                final double d6 = random.nextGaussian() * 0.05 + enumfacing.b();
                world.zerodayisaminecraftcheat(new EntitySmallFireball(world, d0, d2, d3, d4, d5, d6));
                stack.zerodayisaminecraftcheat(1);
                return stack;
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                source.zerodayisaminecraftcheat().zeroday(1009, source.zues(), 0);
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.aw, new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem zeroday = new BehaviorDefaultDispenseItem();
            
            public ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final EnumFacing enumfacing = BlockDispenser.zues(source.flux());
                final World world = source.zerodayisaminecraftcheat();
                final double d0 = source.zeroday() + enumfacing.momgetthecamera() * 1.125f;
                final double d2 = source.sigma() + enumfacing.a() * 1.125f;
                final double d3 = source.pandora() + enumfacing.b() * 1.125f;
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(enumfacing);
                final Material material = world.zeroday(blockpos).sigma().flux();
                double d4;
                if (Material.momgetthecamera.equals(material)) {
                    d4 = 1.0;
                }
                else {
                    if (!Material.zerodayisaminecraftcheat.equals(material) || !Material.momgetthecamera.equals(world.zeroday(blockpos.zues()).sigma().flux())) {
                        return this.zeroday.zerodayisaminecraftcheat(source, stack);
                    }
                    d4 = 0.0;
                }
                final EntityBoat entityboat = new EntityBoat(world, d0, d2 + d4, d3);
                world.zerodayisaminecraftcheat(entityboat);
                stack.zerodayisaminecraftcheat(1);
                return stack;
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                source.zerodayisaminecraftcheat().zeroday(1000, source.zues(), 0);
            }
        });
        final IBehaviorDispenseItem ibehaviordispenseitem = new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem zeroday = new BehaviorDefaultDispenseItem();
            
            public ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final ItemBucket itembucket = (ItemBucket)stack.zerodayisaminecraftcheat();
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(BlockDispenser.zues(source.flux()));
                if (itembucket.zerodayisaminecraftcheat(source.zerodayisaminecraftcheat(), blockpos)) {
                    stack.zerodayisaminecraftcheat(Items.ao);
                    stack.zeroday = 1;
                    return stack;
                }
                return this.zeroday.zerodayisaminecraftcheat(source, stack);
            }
        };
        BlockDispenser.F.zerodayisaminecraftcheat(Items.aq, ibehaviordispenseitem);
        BlockDispenser.F.zerodayisaminecraftcheat(Items.ap, ibehaviordispenseitem);
        BlockDispenser.F.zerodayisaminecraftcheat(Items.ao, new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem zeroday = new BehaviorDefaultDispenseItem();
            
            public ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final World world = source.zerodayisaminecraftcheat();
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(BlockDispenser.zues(source.flux()));
                final IBlockState iblockstate = world.zeroday(blockpos);
                final Block block = iblockstate.sigma();
                final Material material = block.flux();
                Item item;
                if (Material.momgetthecamera.equals(material) && block instanceof BlockLiquid && iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockLiquid.E) == 0) {
                    item = Items.ap;
                }
                else {
                    if (!Material.a.equals(material) || !(block instanceof BlockLiquid) || iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockLiquid.E) != 0) {
                        return super.zeroday(source, stack);
                    }
                    item = Items.aq;
                }
                world.momgetthecamera(blockpos);
                final int zeroday = stack.zeroday - 1;
                stack.zeroday = zeroday;
                if (zeroday == 0) {
                    stack.zerodayisaminecraftcheat(item);
                    stack.zeroday = 1;
                }
                else if (source.vape().zerodayisaminecraftcheat(new ItemStack(item)) < 0) {
                    this.zeroday.zerodayisaminecraftcheat(source, new ItemStack(item));
                }
                return stack;
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.pandora, new BehaviorDefaultDispenseItem() {
            private boolean zeroday = true;
            
            @Override
            protected ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final World world = source.zerodayisaminecraftcheat();
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(BlockDispenser.zues(source.flux()));
                if (world.pandora(blockpos)) {
                    world.zeroday(blockpos, Blocks.T.G());
                    if (stack.zerodayisaminecraftcheat(1, world.g)) {
                        stack.zeroday = 0;
                    }
                }
                else if (world.zeroday(blockpos).sigma() == Blocks.O) {
                    Blocks.O.zeroday(world, blockpos, Blocks.O.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockTNT.D, true));
                    world.momgetthecamera(blockpos);
                }
                else {
                    this.zeroday = false;
                }
                return stack;
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                if (this.zeroday) {
                    source.zerodayisaminecraftcheat().zeroday(1000, source.zues(), 0);
                }
                else {
                    source.zerodayisaminecraftcheat().zeroday(1001, source.zues(), 0);
                }
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.aO, new BehaviorDefaultDispenseItem() {
            private boolean zeroday = true;
            
            @Override
            protected ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                if (EnumDyeColor.zerodayisaminecraftcheat == EnumDyeColor.zerodayisaminecraftcheat(stack.momgetthecamera())) {
                    final World world = source.zerodayisaminecraftcheat();
                    final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(BlockDispenser.zues(source.flux()));
                    if (ItemDye.zerodayisaminecraftcheat(stack, world, blockpos)) {
                        if (!world.r) {
                            world.zeroday(2005, blockpos, 0);
                        }
                    }
                    else {
                        this.zeroday = false;
                    }
                    return stack;
                }
                return super.zeroday(source, stack);
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                if (this.zeroday) {
                    source.zerodayisaminecraftcheat().zeroday(1000, source.zues(), 0);
                }
                else {
                    source.zerodayisaminecraftcheat().zeroday(1001, source.zues(), 0);
                }
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Item.zerodayisaminecraftcheat(Blocks.O), new BehaviorDefaultDispenseItem() {
            @Override
            protected ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final World world = source.zerodayisaminecraftcheat();
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(BlockDispenser.zues(source.flux()));
                final EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, blockpos.zerodayisaminecraftcheat() + 0.5, blockpos.zeroday(), blockpos.sigma() + 0.5, null);
                world.zerodayisaminecraftcheat(entitytntprimed);
                world.zerodayisaminecraftcheat(entitytntprimed, "game.tnt.primed", 1.0f, 1.0f);
                --stack.zeroday;
                return stack;
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Items.bP, new BehaviorDefaultDispenseItem() {
            private boolean zeroday = true;
            
            @Override
            protected ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final World world = source.zerodayisaminecraftcheat();
                final EnumFacing enumfacing = BlockDispenser.zues(source.flux());
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(enumfacing);
                final BlockSkull blockskull = Blocks.bW;
                if (world.pandora(blockpos) && blockskull.zeroday(world, blockpos, stack)) {
                    if (!world.r) {
                        world.zerodayisaminecraftcheat(blockpos, blockskull.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockSkull.D, EnumFacing.zeroday), 3);
                        final TileEntity tileentity = world.zerodayisaminecraftcheat(blockpos);
                        if (tileentity instanceof TileEntitySkull) {
                            if (stack.momgetthecamera() == 3) {
                                GameProfile gameprofile = null;
                                if (stack.f()) {
                                    final NBTTagCompound nbttagcompound = stack.g();
                                    if (nbttagcompound.zeroday("SkullOwner", 10)) {
                                        gameprofile = NBTUtil.zerodayisaminecraftcheat(nbttagcompound.e("SkullOwner"));
                                    }
                                    else if (nbttagcompound.zeroday("SkullOwner", 8)) {
                                        final String s = nbttagcompound.b("SkullOwner");
                                        if (!StringUtils.zeroday(s)) {
                                            gameprofile = new GameProfile((UUID)null, s);
                                        }
                                    }
                                }
                                ((TileEntitySkull)tileentity).zerodayisaminecraftcheat(gameprofile);
                            }
                            else {
                                ((TileEntitySkull)tileentity).zerodayisaminecraftcheat(stack.momgetthecamera());
                            }
                            ((TileEntitySkull)tileentity).zeroday(enumfacing.zues().sigma() * 4);
                            Blocks.bW.zerodayisaminecraftcheat(world, blockpos, (TileEntitySkull)tileentity);
                        }
                        --stack.zeroday;
                    }
                }
                else {
                    this.zeroday = false;
                }
                return stack;
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                if (this.zeroday) {
                    source.zerodayisaminecraftcheat().zeroday(1000, source.zues(), 0);
                }
                else {
                    source.zerodayisaminecraftcheat().zeroday(1001, source.zues(), 0);
                }
            }
        });
        BlockDispenser.F.zerodayisaminecraftcheat(Item.zerodayisaminecraftcheat(Blocks.aM), new BehaviorDefaultDispenseItem() {
            private boolean zeroday = true;
            
            @Override
            protected ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final World world = source.zerodayisaminecraftcheat();
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(BlockDispenser.zues(source.flux()));
                final BlockPumpkin blockpumpkin = (BlockPumpkin)Blocks.aM;
                if (world.pandora(blockpos) && blockpumpkin.a(world, blockpos)) {
                    if (!world.r) {
                        world.zerodayisaminecraftcheat(blockpos, blockpumpkin.G(), 3);
                    }
                    --stack.zeroday;
                }
                else {
                    this.zeroday = false;
                }
                return stack;
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                if (this.zeroday) {
                    source.zerodayisaminecraftcheat().zeroday(1000, source.zues(), 0);
                }
                else {
                    source.zerodayisaminecraftcheat().zeroday(1001, source.zues(), 0);
                }
            }
        });
    }
    
    public static void sigma() {
        if (!Bootstrap.zeroday) {
            Bootstrap.zeroday = true;
            if (Bootstrap.sigma.isDebugEnabled()) {
                pandora();
            }
            Block.I();
            BlockFire.J();
            Item.i();
            StatList.zerodayisaminecraftcheat();
            zeroday();
        }
    }
    
    private static void pandora() {
        System.setErr(new LoggingPrintStream("STDERR", System.err));
        System.setOut(new LoggingPrintStream("STDOUT", Bootstrap.zerodayisaminecraftcheat));
    }
    
    public static void zerodayisaminecraftcheat(final String p_179870_0_) {
        Bootstrap.zerodayisaminecraftcheat.println(p_179870_0_);
    }
}

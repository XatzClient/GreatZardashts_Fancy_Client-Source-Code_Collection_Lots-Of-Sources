// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.n.TileEntity;
import net.minecraft.o.MathHelper;
import net.minecraft.c.Item;
import java.util.Iterator;
import net.minecraft.vape.vape.InventoryPlayer;
import com.google.common.collect.Sets;
import com.google.common.collect.Lists;
import net.minecraft.vape.vape.EntityPlayer;
import java.util.Set;
import net.minecraft.c.ItemStack;
import java.util.List;

public abstract class Container
{
    public List<ItemStack> zeroday;
    public List<Slot> sigma;
    public int pandora;
    private short zerodayisaminecraftcheat;
    private int flux;
    private int vape;
    private final Set<Slot> momgetthecamera;
    protected List<ICrafting> zues;
    private Set<EntityPlayer> a;
    
    public Container() {
        this.zeroday = (List<ItemStack>)Lists.newArrayList();
        this.sigma = (List<Slot>)Lists.newArrayList();
        this.flux = -1;
        this.momgetthecamera = (Set<Slot>)Sets.newHashSet();
        this.zues = (List<ICrafting>)Lists.newArrayList();
        this.a = (Set<EntityPlayer>)Sets.newHashSet();
    }
    
    protected Slot zeroday(final Slot slotIn) {
        slotIn.sigma = this.sigma.size();
        this.sigma.add(slotIn);
        this.zeroday.add(null);
        return slotIn;
    }
    
    public void zerodayisaminecraftcheat(final ICrafting listener) {
        if (this.zues.contains(listener)) {
            throw new IllegalArgumentException("Listener already listening");
        }
        this.zues.add(listener);
        listener.zerodayisaminecraftcheat(this, this.zeroday());
        this.sigma();
    }
    
    public void zeroday(final ICrafting listeners) {
        this.zues.remove(listeners);
    }
    
    public List<ItemStack> zeroday() {
        final List<ItemStack> list = (List<ItemStack>)Lists.newArrayList();
        for (int i = 0; i < this.sigma.size(); ++i) {
            list.add(this.sigma.get(i).zerodayisaminecraftcheat());
        }
        return list;
    }
    
    public void sigma() {
        for (int i = 0; i < this.sigma.size(); ++i) {
            final ItemStack itemstack = this.sigma.get(i).zerodayisaminecraftcheat();
            ItemStack itemstack2 = this.zeroday.get(i);
            if (!ItemStack.zeroday(itemstack2, itemstack)) {
                itemstack2 = ((itemstack == null) ? null : itemstack.b());
                this.zeroday.set(i, itemstack2);
                for (int j = 0; j < this.zues.size(); ++j) {
                    this.zues.get(j).zerodayisaminecraftcheat(this, i, itemstack2);
                }
            }
        }
    }
    
    public boolean zeroday(final EntityPlayer playerIn, final int id) {
        return false;
    }
    
    public Slot zerodayisaminecraftcheat(final IInventory inv, final int slotIn) {
        for (int i = 0; i < this.sigma.size(); ++i) {
            final Slot slot = this.sigma.get(i);
            if (slot.zerodayisaminecraftcheat(inv, slotIn)) {
                return slot;
            }
        }
        return null;
    }
    
    public Slot zerodayisaminecraftcheat(final int slotId) {
        return this.sigma.get(slotId);
    }
    
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        final Slot slot = this.sigma.get(index);
        return (slot != null) ? slot.zerodayisaminecraftcheat() : null;
    }
    
    public ItemStack zerodayisaminecraftcheat(final int slotId, final int clickedButton, final int mode, final EntityPlayer playerIn) {
        ItemStack itemstack = null;
        final InventoryPlayer inventoryplayer = playerIn.d;
        if (mode == 5) {
            final int i = this.vape;
            this.vape = sigma(clickedButton);
            if ((i != 1 || this.vape != 2) && i != this.vape) {
                this.pandora();
            }
            else if (inventoryplayer.d() == null) {
                this.pandora();
            }
            else if (this.vape == 0) {
                this.flux = zeroday(clickedButton);
                if (zerodayisaminecraftcheat(this.flux, playerIn)) {
                    this.vape = 1;
                    this.momgetthecamera.clear();
                }
                else {
                    this.pandora();
                }
            }
            else if (this.vape == 1) {
                final Slot slot = this.sigma.get(slotId);
                if (slot != null && zerodayisaminecraftcheat(slot, inventoryplayer.d(), true) && slot.zerodayisaminecraftcheat(inventoryplayer.d()) && inventoryplayer.d().zeroday > this.momgetthecamera.size() && this.zerodayisaminecraftcheat(slot)) {
                    this.momgetthecamera.add(slot);
                }
            }
            else if (this.vape == 2) {
                if (!this.momgetthecamera.isEmpty()) {
                    ItemStack itemstack2 = inventoryplayer.d().b();
                    int j = inventoryplayer.d().zeroday;
                    for (final Slot slot2 : this.momgetthecamera) {
                        if (slot2 != null && zerodayisaminecraftcheat(slot2, inventoryplayer.d(), true) && slot2.zerodayisaminecraftcheat(inventoryplayer.d()) && inventoryplayer.d().zeroday >= this.momgetthecamera.size() && this.zerodayisaminecraftcheat(slot2)) {
                            final ItemStack itemstack3 = itemstack2.b();
                            final int k = slot2.zeroday() ? slot2.zerodayisaminecraftcheat().zeroday : 0;
                            zerodayisaminecraftcheat(this.momgetthecamera, this.flux, itemstack3, k);
                            if (itemstack3.zeroday > itemstack3.zeroday()) {
                                itemstack3.zeroday = itemstack3.zeroday();
                            }
                            if (itemstack3.zeroday > slot2.sigma(itemstack3)) {
                                itemstack3.zeroday = slot2.sigma(itemstack3);
                            }
                            j -= itemstack3.zeroday - k;
                            slot2.zeroday(itemstack3);
                        }
                    }
                    itemstack2.zeroday = j;
                    if (itemstack2.zeroday <= 0) {
                        itemstack2 = null;
                    }
                    inventoryplayer.zeroday(itemstack2);
                }
                this.pandora();
            }
            else {
                this.pandora();
            }
        }
        else if (this.vape != 0) {
            this.pandora();
        }
        else if ((mode == 0 || mode == 1) && (clickedButton == 0 || clickedButton == 1)) {
            if (slotId == -999) {
                if (inventoryplayer.d() != null) {
                    if (clickedButton == 0) {
                        playerIn.zerodayisaminecraftcheat(inventoryplayer.d(), true);
                        inventoryplayer.zeroday((ItemStack)null);
                    }
                    if (clickedButton == 1) {
                        playerIn.zerodayisaminecraftcheat(inventoryplayer.d().zerodayisaminecraftcheat(1), true);
                        if (inventoryplayer.d().zeroday == 0) {
                            inventoryplayer.zeroday((ItemStack)null);
                        }
                    }
                }
            }
            else if (mode == 1) {
                if (slotId < 0) {
                    return null;
                }
                final Slot slot3 = this.sigma.get(slotId);
                if (slot3 != null && slot3.zerodayisaminecraftcheat(playerIn)) {
                    final ItemStack itemstack4 = this.zerodayisaminecraftcheat(playerIn, slotId);
                    if (itemstack4 != null) {
                        final Item item = itemstack4.zerodayisaminecraftcheat();
                        itemstack = itemstack4.b();
                        if (slot3.zerodayisaminecraftcheat() != null && slot3.zerodayisaminecraftcheat().zerodayisaminecraftcheat() == item) {
                            this.zerodayisaminecraftcheat(slotId, clickedButton, true, playerIn);
                        }
                    }
                }
            }
            else {
                if (slotId < 0) {
                    return null;
                }
                final Slot slot4 = this.sigma.get(slotId);
                if (slot4 != null) {
                    ItemStack itemstack5 = slot4.zerodayisaminecraftcheat();
                    final ItemStack itemstack6 = inventoryplayer.d();
                    if (itemstack5 != null) {
                        itemstack = itemstack5.b();
                    }
                    if (itemstack5 == null) {
                        if (itemstack6 != null && slot4.zerodayisaminecraftcheat(itemstack6)) {
                            int k2 = (clickedButton == 0) ? itemstack6.zeroday : 1;
                            if (k2 > slot4.sigma(itemstack6)) {
                                k2 = slot4.sigma(itemstack6);
                            }
                            if (itemstack6.zeroday >= k2) {
                                slot4.zeroday(itemstack6.zerodayisaminecraftcheat(k2));
                            }
                            if (itemstack6.zeroday == 0) {
                                inventoryplayer.zeroday((ItemStack)null);
                            }
                        }
                    }
                    else if (slot4.zerodayisaminecraftcheat(playerIn)) {
                        if (itemstack6 == null) {
                            final int j2 = (clickedButton == 0) ? itemstack5.zeroday : ((itemstack5.zeroday + 1) / 2);
                            final ItemStack itemstack7 = slot4.zerodayisaminecraftcheat(j2);
                            inventoryplayer.zeroday(itemstack7);
                            if (itemstack5.zeroday == 0) {
                                slot4.zeroday(null);
                            }
                            slot4.zerodayisaminecraftcheat(playerIn, inventoryplayer.d());
                        }
                        else if (slot4.zerodayisaminecraftcheat(itemstack6)) {
                            if (itemstack5.zerodayisaminecraftcheat() == itemstack6.zerodayisaminecraftcheat() && itemstack5.momgetthecamera() == itemstack6.momgetthecamera() && ItemStack.zerodayisaminecraftcheat(itemstack5, itemstack6)) {
                                int i2 = (clickedButton == 0) ? itemstack6.zeroday : 1;
                                if (i2 > slot4.sigma(itemstack6) - itemstack5.zeroday) {
                                    i2 = slot4.sigma(itemstack6) - itemstack5.zeroday;
                                }
                                if (i2 > itemstack6.zeroday() - itemstack5.zeroday) {
                                    i2 = itemstack6.zeroday() - itemstack5.zeroday;
                                }
                                itemstack6.zerodayisaminecraftcheat(i2);
                                if (itemstack6.zeroday == 0) {
                                    inventoryplayer.zeroday((ItemStack)null);
                                }
                                final ItemStack itemStack = itemstack5;
                                itemStack.zeroday += i2;
                            }
                            else if (itemstack6.zeroday <= slot4.sigma(itemstack6)) {
                                slot4.zeroday(itemstack6);
                                inventoryplayer.zeroday(itemstack5);
                            }
                        }
                        else if (itemstack5.zerodayisaminecraftcheat() == itemstack6.zerodayisaminecraftcheat() && itemstack6.zeroday() > 1 && (!itemstack5.zues() || itemstack5.momgetthecamera() == itemstack6.momgetthecamera()) && ItemStack.zerodayisaminecraftcheat(itemstack5, itemstack6)) {
                            final int l1 = itemstack5.zeroday;
                            if (l1 > 0 && l1 + itemstack6.zeroday <= itemstack6.zeroday()) {
                                final ItemStack itemStack2 = itemstack6;
                                itemStack2.zeroday += l1;
                                itemstack5 = slot4.zerodayisaminecraftcheat(l1);
                                if (itemstack5.zeroday == 0) {
                                    slot4.zeroday(null);
                                }
                                slot4.zerodayisaminecraftcheat(playerIn, inventoryplayer.d());
                            }
                        }
                    }
                    slot4.sigma();
                }
            }
        }
        else if (mode == 2 && clickedButton >= 0 && clickedButton < 9) {
            final Slot slot5 = this.sigma.get(slotId);
            if (slot5.zerodayisaminecraftcheat(playerIn)) {
                final ItemStack itemstack8 = inventoryplayer.d(clickedButton);
                boolean flag = itemstack8 == null || (slot5.zeroday == inventoryplayer && slot5.zerodayisaminecraftcheat(itemstack8));
                int k3 = -1;
                if (!flag) {
                    k3 = inventoryplayer.vape();
                    flag |= (k3 > -1);
                }
                if (slot5.zeroday() && flag) {
                    final ItemStack itemstack9 = slot5.zerodayisaminecraftcheat();
                    inventoryplayer.sigma(clickedButton, itemstack9.b());
                    if ((slot5.zeroday != inventoryplayer || !slot5.zerodayisaminecraftcheat(itemstack8)) && itemstack8 != null) {
                        if (k3 > -1) {
                            inventoryplayer.zerodayisaminecraftcheat(itemstack8);
                            slot5.zerodayisaminecraftcheat(itemstack9.zeroday);
                            slot5.zeroday(null);
                            slot5.zerodayisaminecraftcheat(playerIn, itemstack9);
                        }
                    }
                    else {
                        slot5.zerodayisaminecraftcheat(itemstack9.zeroday);
                        slot5.zeroday(itemstack8);
                        slot5.zerodayisaminecraftcheat(playerIn, itemstack9);
                    }
                }
                else if (!slot5.zeroday() && itemstack8 != null && slot5.zerodayisaminecraftcheat(itemstack8)) {
                    inventoryplayer.sigma(clickedButton, null);
                    slot5.zeroday(itemstack8);
                }
            }
        }
        else if (mode == 3 && playerIn.bz.pandora && inventoryplayer.d() == null && slotId >= 0) {
            final Slot slot6 = this.sigma.get(slotId);
            if (slot6 != null && slot6.zeroday()) {
                final ItemStack itemstack10 = slot6.zerodayisaminecraftcheat().b();
                itemstack10.zeroday = itemstack10.zeroday();
                inventoryplayer.zeroday(itemstack10);
            }
        }
        else if (mode == 4 && inventoryplayer.d() == null && slotId >= 0) {
            final Slot slot7 = this.sigma.get(slotId);
            if (slot7 != null && slot7.zeroday() && slot7.zerodayisaminecraftcheat(playerIn)) {
                final ItemStack itemstack11 = slot7.zerodayisaminecraftcheat((clickedButton == 0) ? 1 : slot7.zerodayisaminecraftcheat().zeroday);
                slot7.zerodayisaminecraftcheat(playerIn, itemstack11);
                playerIn.zerodayisaminecraftcheat(itemstack11, true);
            }
        }
        else if (mode == 6 && slotId >= 0) {
            final Slot slot8 = this.sigma.get(slotId);
            final ItemStack itemstack12 = inventoryplayer.d();
            if (itemstack12 != null && (slot8 == null || !slot8.zeroday() || !slot8.zerodayisaminecraftcheat(playerIn))) {
                final int i3 = (clickedButton == 0) ? 0 : (this.sigma.size() - 1);
                final int j3 = (clickedButton == 0) ? 1 : -1;
                for (int l2 = 0; l2 < 2; ++l2) {
                    for (int i4 = i3; i4 >= 0 && i4 < this.sigma.size() && itemstack12.zeroday < itemstack12.zeroday(); i4 += j3) {
                        final Slot slot9 = this.sigma.get(i4);
                        if (slot9.zeroday() && zerodayisaminecraftcheat(slot9, itemstack12, true) && slot9.zerodayisaminecraftcheat(playerIn) && this.zerodayisaminecraftcheat(itemstack12, slot9) && (l2 != 0 || slot9.zerodayisaminecraftcheat().zeroday != slot9.zerodayisaminecraftcheat().zeroday())) {
                            final int m = Math.min(itemstack12.zeroday() - itemstack12.zeroday, slot9.zerodayisaminecraftcheat().zeroday);
                            final ItemStack itemstack13 = slot9.zerodayisaminecraftcheat(m);
                            final ItemStack itemStack3 = itemstack12;
                            itemStack3.zeroday += m;
                            if (itemstack13.zeroday <= 0) {
                                slot9.zeroday(null);
                            }
                            slot9.zerodayisaminecraftcheat(playerIn, itemstack13);
                        }
                    }
                }
            }
            this.sigma();
        }
        return itemstack;
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final Slot p_94530_2_) {
        return true;
    }
    
    protected void zerodayisaminecraftcheat(final int slotId, final int clickedButton, final boolean mode, final EntityPlayer playerIn) {
        this.zerodayisaminecraftcheat(slotId, clickedButton, 1, playerIn);
    }
    
    public void zeroday(final EntityPlayer playerIn) {
        final InventoryPlayer inventoryplayer = playerIn.d;
        if (inventoryplayer.d() != null) {
            playerIn.zerodayisaminecraftcheat(inventoryplayer.d(), false);
            inventoryplayer.zeroday((ItemStack)null);
        }
    }
    
    public void zerodayisaminecraftcheat(final IInventory inventoryIn) {
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final int slotID, final ItemStack stack) {
        this.zerodayisaminecraftcheat(slotID).zeroday(stack);
    }
    
    public void zerodayisaminecraftcheat(final ItemStack[] p_75131_1_) {
        for (int i = 0; i < p_75131_1_.length; ++i) {
            this.zerodayisaminecraftcheat(i).zeroday(p_75131_1_[i]);
        }
    }
    
    public void zerodayisaminecraftcheat(final int id, final int data) {
    }
    
    public short zerodayisaminecraftcheat(final InventoryPlayer p_75136_1_) {
        return (short)(++this.zerodayisaminecraftcheat);
    }
    
    public boolean sigma(final EntityPlayer p_75129_1_) {
        return !this.a.contains(p_75129_1_);
    }
    
    public void zerodayisaminecraftcheat(final EntityPlayer p_75128_1_, final boolean p_75128_2_) {
        if (p_75128_2_) {
            this.a.remove(p_75128_1_);
        }
        else {
            this.a.add(p_75128_1_);
        }
    }
    
    public abstract boolean zerodayisaminecraftcheat(final EntityPlayer p0);
    
    protected boolean zerodayisaminecraftcheat(final ItemStack stack, final int startIndex, final int endIndex, final boolean reverseDirection) {
        boolean flag = false;
        int i = startIndex;
        if (reverseDirection) {
            i = endIndex - 1;
        }
        if (stack.sigma()) {
            while (stack.zeroday > 0 && ((!reverseDirection && i < endIndex) || (reverseDirection && i >= startIndex))) {
                final Slot slot = this.sigma.get(i);
                final ItemStack itemstack = slot.zerodayisaminecraftcheat();
                if (itemstack != null && itemstack.zerodayisaminecraftcheat() == stack.zerodayisaminecraftcheat() && (!stack.zues() || stack.momgetthecamera() == itemstack.momgetthecamera()) && ItemStack.zerodayisaminecraftcheat(stack, itemstack)) {
                    final int j = itemstack.zeroday + stack.zeroday;
                    if (j <= stack.zeroday()) {
                        stack.zeroday = 0;
                        itemstack.zeroday = j;
                        slot.sigma();
                        flag = true;
                    }
                    else if (itemstack.zeroday < stack.zeroday()) {
                        stack.zeroday -= stack.zeroday() - itemstack.zeroday;
                        itemstack.zeroday = stack.zeroday();
                        slot.sigma();
                        flag = true;
                    }
                }
                if (reverseDirection) {
                    --i;
                }
                else {
                    ++i;
                }
            }
        }
        if (stack.zeroday > 0) {
            if (reverseDirection) {
                i = endIndex - 1;
            }
            else {
                i = startIndex;
            }
            while ((!reverseDirection && i < endIndex) || (reverseDirection && i >= startIndex)) {
                final Slot slot2 = this.sigma.get(i);
                final ItemStack itemstack2 = slot2.zerodayisaminecraftcheat();
                if (itemstack2 == null) {
                    slot2.zeroday(stack.b());
                    slot2.sigma();
                    stack.zeroday = 0;
                    flag = true;
                    break;
                }
                if (reverseDirection) {
                    --i;
                }
                else {
                    ++i;
                }
            }
        }
        return flag;
    }
    
    public static int zeroday(final int p_94529_0_) {
        return p_94529_0_ >> 2 & 0x3;
    }
    
    public static int sigma(final int p_94532_0_) {
        return p_94532_0_ & 0x3;
    }
    
    public static int zeroday(final int p_94534_0_, final int p_94534_1_) {
        return (p_94534_0_ & 0x3) | (p_94534_1_ & 0x3) << 2;
    }
    
    public static boolean zerodayisaminecraftcheat(final int dragModeIn, final EntityPlayer player) {
        return dragModeIn == 0 || dragModeIn == 1 || (dragModeIn == 2 && player.bz.pandora);
    }
    
    protected void pandora() {
        this.vape = 0;
        this.momgetthecamera.clear();
    }
    
    public static boolean zerodayisaminecraftcheat(final Slot slotIn, final ItemStack stack, final boolean stackSizeMatters) {
        boolean flag = slotIn == null || !slotIn.zeroday();
        if (slotIn != null && slotIn.zeroday() && stack != null && stack.zerodayisaminecraftcheat(slotIn.zerodayisaminecraftcheat()) && ItemStack.zerodayisaminecraftcheat(slotIn.zerodayisaminecraftcheat(), stack)) {
            flag |= (slotIn.zerodayisaminecraftcheat().zeroday + (stackSizeMatters ? 0 : stack.zeroday) <= stack.zeroday());
        }
        return flag;
    }
    
    public static void zerodayisaminecraftcheat(final Set<Slot> p_94525_0_, final int p_94525_1_, final ItemStack p_94525_2_, final int p_94525_3_) {
        switch (p_94525_1_) {
            case 0: {
                p_94525_2_.zeroday = MathHelper.pandora(p_94525_2_.zeroday / (float)p_94525_0_.size());
                break;
            }
            case 1: {
                p_94525_2_.zeroday = 1;
                break;
            }
            case 2: {
                p_94525_2_.zeroday = p_94525_2_.zerodayisaminecraftcheat().zerodayisaminecraftcheat();
                break;
            }
        }
        p_94525_2_.zeroday += p_94525_3_;
    }
    
    public boolean zerodayisaminecraftcheat(final Slot p_94531_1_) {
        return true;
    }
    
    public static int zerodayisaminecraftcheat(final TileEntity te) {
        return (te instanceof IInventory) ? zeroday((IInventory)te) : 0;
    }
    
    public static int zeroday(final IInventory inv) {
        if (inv == null) {
            return 0;
        }
        int i = 0;
        float f = 0.0f;
        for (int j = 0; j < inv.a(); ++j) {
            final ItemStack itemstack = inv.d(j);
            if (itemstack != null) {
                f += itemstack.zeroday / (float)Math.min(inv.u(), itemstack.zeroday());
                ++i;
            }
        }
        f /= inv.a();
        return MathHelper.pandora(f * 14.0f) + ((i > 0) ? 1 : 0);
    }
}

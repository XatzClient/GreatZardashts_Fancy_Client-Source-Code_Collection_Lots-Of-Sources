// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.a.Items;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;

public class ContainerBeacon extends Container
{
    private IInventory zerodayisaminecraftcheat;
    private final zerodayisaminecraftcheat flux;
    
    public ContainerBeacon(final IInventory playerInventory, final IInventory tileBeaconIn) {
        this.zerodayisaminecraftcheat = tileBeaconIn;
        this.zeroday(this.flux = new zerodayisaminecraftcheat(tileBeaconIn, 0, 136, 110));
        final int i = 36;
        final int j = 137;
        for (int k = 0; k < 3; ++k) {
            for (int l = 0; l < 9; ++l) {
                this.zeroday(new Slot(playerInventory, l + k * 9 + 9, i + l * 18, j + k * 18));
            }
        }
        for (int i2 = 0; i2 < 9; ++i2) {
            this.zeroday(new Slot(playerInventory, i2, i + i2 * 18, 58 + j));
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ICrafting listener) {
        super.zerodayisaminecraftcheat(listener);
        listener.zerodayisaminecraftcheat(this, this.zerodayisaminecraftcheat);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int data) {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(id, data);
    }
    
    public IInventory zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        if (playerIn != null && !playerIn.o.r) {
            final ItemStack itemstack = this.flux.zerodayisaminecraftcheat(this.flux.pandora());
            if (itemstack != null) {
                playerIn.zerodayisaminecraftcheat(itemstack, false);
            }
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.pandora(playerIn);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index == 0) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 1, 37, true)) {
                    return null;
                }
                slot.zerodayisaminecraftcheat(itemstack2, itemstack);
            }
            else if (!this.flux.zeroday() && this.flux.zerodayisaminecraftcheat(itemstack2) && itemstack2.zeroday == 1) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 0, 1, false)) {
                    return null;
                }
            }
            else if (index >= 1 && index < 28) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 28, 37, false)) {
                    return null;
                }
            }
            else if (index >= 28 && index < 37) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 1, 28, false)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 1, 37, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
    
    class zerodayisaminecraftcheat extends Slot
    {
        public zerodayisaminecraftcheat(final IInventory p_i1801_2_, final int p_i1801_3_, final int p_i1801_4_, final int p_i1801_5_) {
            super(p_i1801_2_, p_i1801_3_, p_i1801_4_, p_i1801_5_);
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final ItemStack stack) {
            return stack != null && (stack.zerodayisaminecraftcheat() == Items.bG || stack.zerodayisaminecraftcheat() == Items.a || stack.zerodayisaminecraftcheat() == Items.c || stack.zerodayisaminecraftcheat() == Items.b);
        }
        
        @Override
        public int pandora() {
            return 1;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.m.StatBase;
import net.minecraft.m.AchievementList;
import net.minecraft.a.Items;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.vape.InventoryPlayer;

public class ContainerBrewingStand extends Container
{
    private IInventory zerodayisaminecraftcheat;
    private final Slot flux;
    private int vape;
    
    public ContainerBrewingStand(final InventoryPlayer playerInventory, final IInventory tileBrewingStandIn) {
        this.zerodayisaminecraftcheat = tileBrewingStandIn;
        this.zeroday(new zeroday(playerInventory.pandora, tileBrewingStandIn, 0, 56, 46));
        this.zeroday(new zeroday(playerInventory.pandora, tileBrewingStandIn, 1, 79, 53));
        this.zeroday(new zeroday(playerInventory.pandora, tileBrewingStandIn, 2, 102, 46));
        this.flux = this.zeroday(new zerodayisaminecraftcheat(tileBrewingStandIn, 3, 79, 17));
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.zeroday(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int k = 0; k < 9; ++k) {
            this.zeroday(new Slot(playerInventory, k, 8 + k * 18, 142));
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ICrafting listener) {
        super.zerodayisaminecraftcheat(listener);
        listener.zerodayisaminecraftcheat(this, this.zerodayisaminecraftcheat);
    }
    
    @Override
    public void sigma() {
        super.sigma();
        for (int i = 0; i < this.zues.size(); ++i) {
            final ICrafting icrafting = this.zues.get(i);
            if (this.vape != this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0)) {
                icrafting.zerodayisaminecraftcheat(this, 0, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0));
            }
        }
        this.vape = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int data) {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(id, data);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.pandora(playerIn);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if ((index < 0 || index > 2) && index != 3) {
                if (!this.flux.zeroday() && this.flux.zerodayisaminecraftcheat(itemstack2)) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 3, 4, false)) {
                        return null;
                    }
                }
                else if (zeroday.pandora(itemstack)) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 0, 3, false)) {
                        return null;
                    }
                }
                else if (index >= 4 && index < 31) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 31, 40, false)) {
                        return null;
                    }
                }
                else if (index >= 31 && index < 40) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 4, 31, false)) {
                        return null;
                    }
                }
                else if (!this.zerodayisaminecraftcheat(itemstack2, 4, 40, false)) {
                    return null;
                }
            }
            else {
                if (!this.zerodayisaminecraftcheat(itemstack2, 4, 40, true)) {
                    return null;
                }
                slot.zerodayisaminecraftcheat(itemstack2, itemstack);
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
    
    class zerodayisaminecraftcheat extends Slot
    {
        public zerodayisaminecraftcheat(final IInventory inventoryIn, final int index, final int xPosition, final int yPosition) {
            super(inventoryIn, index, xPosition, yPosition);
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final ItemStack stack) {
            return stack != null && stack.zerodayisaminecraftcheat().flux(stack);
        }
        
        @Override
        public int pandora() {
            return 64;
        }
    }
    
    static class zeroday extends Slot
    {
        private EntityPlayer zerodayisaminecraftcheat;
        
        public zeroday(final EntityPlayer playerIn, final IInventory inventoryIn, final int index, final int xPosition, final int yPosition) {
            super(inventoryIn, index, xPosition, yPosition);
            this.zerodayisaminecraftcheat = playerIn;
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final ItemStack stack) {
            return pandora(stack);
        }
        
        @Override
        public int pandora() {
            return 1;
        }
        
        @Override
        public void zerodayisaminecraftcheat(final EntityPlayer playerIn, final ItemStack stack) {
            if (stack.zerodayisaminecraftcheat() == Items.br && stack.momgetthecamera() > 0) {
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(AchievementList.t);
            }
            super.zerodayisaminecraftcheat(playerIn, stack);
        }
        
        public static boolean pandora(final ItemStack stack) {
            return stack != null && (stack.zerodayisaminecraftcheat() == Items.br || stack.zerodayisaminecraftcheat() == Items.bs);
        }
    }
}

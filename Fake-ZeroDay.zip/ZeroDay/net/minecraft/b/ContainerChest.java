// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;

public class ContainerChest extends Container
{
    private IInventory zerodayisaminecraftcheat;
    private int flux;
    
    public ContainerChest(final IInventory playerInventory, final IInventory chestInventory, final EntityPlayer player) {
        this.zerodayisaminecraftcheat = chestInventory;
        this.flux = chestInventory.a() / 9;
        chestInventory.zues(player);
        final int i = (this.flux - 4) * 18;
        for (int j = 0; j < this.flux; ++j) {
            for (int k = 0; k < 9; ++k) {
                this.zeroday(new Slot(chestInventory, k + j * 9, 8 + k * 18, 18 + j * 18));
            }
        }
        for (int l = 0; l < 3; ++l) {
            for (int j2 = 0; j2 < 9; ++j2) {
                this.zeroday(new Slot(playerInventory, j2 + l * 9 + 9, 8 + j2 * 18, 103 + l * 18 + i));
            }
        }
        for (int i2 = 0; i2 < 9; ++i2) {
            this.zeroday(new Slot(playerInventory, i2, 8 + i2 * 18, 161 + i));
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.pandora(playerIn);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index < this.flux * 9) {
                if (!this.zerodayisaminecraftcheat(itemstack2, this.flux * 9, this.sigma.size(), true)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 0, this.flux * 9, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
        }
        return itemstack;
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        this.zerodayisaminecraftcheat.flux(playerIn);
    }
    
    public IInventory zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
}

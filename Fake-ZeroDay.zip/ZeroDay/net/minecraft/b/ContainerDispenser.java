// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;

public class ContainerDispenser extends Container
{
    private IInventory zerodayisaminecraftcheat;
    
    public ContainerDispenser(final IInventory playerInventory, final IInventory dispenserInventoryIn) {
        this.zerodayisaminecraftcheat = dispenserInventoryIn;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                this.zeroday(new Slot(dispenserInventoryIn, j + i * 3, 62 + j * 18, 17 + i * 18));
            }
        }
        for (int k = 0; k < 3; ++k) {
            for (int i2 = 0; i2 < 9; ++i2) {
                this.zeroday(new Slot(playerInventory, i2 + k * 9 + 9, 8 + i2 * 18, 84 + k * 18));
            }
        }
        for (int l = 0; l < 9; ++l) {
            this.zeroday(new Slot(playerInventory, l, 8 + l * 18, 142));
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.pandora(playerIn);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index < 9) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 9, 45, true)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 0, 9, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
}

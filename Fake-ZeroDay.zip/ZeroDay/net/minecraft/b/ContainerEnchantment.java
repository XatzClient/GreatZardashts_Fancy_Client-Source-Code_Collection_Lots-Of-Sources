// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.m.StatList;
import net.minecraft.c.Item;
import net.minecraft.vape.vape.EntityPlayer;
import java.util.List;
import net.minecraft.flux.EnchantmentData;
import net.minecraft.flux.EnchantmentHelper;
import net.minecraft.a.Blocks;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.a.Items;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.InventoryPlayer;
import java.util.Random;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;

public class ContainerEnchantment extends Container
{
    public IInventory zerodayisaminecraftcheat;
    private World a;
    private BlockPos b;
    private Random c;
    public int flux;
    public int[] vape;
    public int[] momgetthecamera;
    
    public ContainerEnchantment(final InventoryPlayer playerInv, final World worldIn) {
        this(playerInv, worldIn, BlockPos.zerodayisaminecraftcheat);
    }
    
    public ContainerEnchantment(final InventoryPlayer playerInv, final World worldIn, final BlockPos pos) {
        this.zerodayisaminecraftcheat = new InventoryBasic("Enchant", true, 2) {
            @Override
            public int u() {
                return 64;
            }
            
            @Override
            public void t() {
                super.t();
                ContainerEnchantment.this.zerodayisaminecraftcheat(this);
            }
        };
        this.c = new Random();
        this.vape = new int[3];
        this.momgetthecamera = new int[] { -1, -1, -1 };
        this.a = worldIn;
        this.b = pos;
        this.flux = playerInv.pandora.bg();
        this.zeroday(new Slot(this.zerodayisaminecraftcheat, 0, 15, 47) {
            @Override
            public boolean zerodayisaminecraftcheat(final ItemStack stack) {
                return true;
            }
            
            @Override
            public int pandora() {
                return 1;
            }
        });
        this.zeroday(new Slot(this.zerodayisaminecraftcheat, 1, 35, 47) {
            @Override
            public boolean zerodayisaminecraftcheat(final ItemStack stack) {
                return stack.zerodayisaminecraftcheat() == Items.aO && EnumDyeColor.zerodayisaminecraftcheat(stack.momgetthecamera()) == EnumDyeColor.d;
            }
        });
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.zeroday(new Slot(playerInv, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int k = 0; k < 9; ++k) {
            this.zeroday(new Slot(playerInv, k, 8 + k * 18, 142));
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ICrafting listener) {
        super.zerodayisaminecraftcheat(listener);
        listener.zerodayisaminecraftcheat(this, 0, this.vape[0]);
        listener.zerodayisaminecraftcheat(this, 1, this.vape[1]);
        listener.zerodayisaminecraftcheat(this, 2, this.vape[2]);
        listener.zerodayisaminecraftcheat(this, 3, this.flux & 0xFFFFFFF0);
        listener.zerodayisaminecraftcheat(this, 4, this.momgetthecamera[0]);
        listener.zerodayisaminecraftcheat(this, 5, this.momgetthecamera[1]);
        listener.zerodayisaminecraftcheat(this, 6, this.momgetthecamera[2]);
    }
    
    @Override
    public void sigma() {
        super.sigma();
        for (int i = 0; i < this.zues.size(); ++i) {
            final ICrafting icrafting = this.zues.get(i);
            icrafting.zerodayisaminecraftcheat(this, 0, this.vape[0]);
            icrafting.zerodayisaminecraftcheat(this, 1, this.vape[1]);
            icrafting.zerodayisaminecraftcheat(this, 2, this.vape[2]);
            icrafting.zerodayisaminecraftcheat(this, 3, this.flux & 0xFFFFFFF0);
            icrafting.zerodayisaminecraftcheat(this, 4, this.momgetthecamera[0]);
            icrafting.zerodayisaminecraftcheat(this, 5, this.momgetthecamera[1]);
            icrafting.zerodayisaminecraftcheat(this, 6, this.momgetthecamera[2]);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int data) {
        if (id >= 0 && id <= 2) {
            this.vape[id] = data;
        }
        else if (id == 3) {
            this.flux = data;
        }
        else if (id >= 4 && id <= 6) {
            this.momgetthecamera[id - 4] = data;
        }
        else {
            super.zerodayisaminecraftcheat(id, data);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IInventory inventoryIn) {
        if (inventoryIn == this.zerodayisaminecraftcheat) {
            final ItemStack itemstack = inventoryIn.d(0);
            if (itemstack != null && itemstack.n()) {
                if (!this.a.r) {
                    int l = 0;
                    for (int j = -1; j <= 1; ++j) {
                        for (int k = -1; k <= 1; ++k) {
                            if ((j != 0 || k != 0) && this.a.pandora(this.b.zeroday(k, 0, j)) && this.a.pandora(this.b.zeroday(k, 1, j))) {
                                if (this.a.zeroday(this.b.zeroday(k * 2, 0, j * 2)).sigma() == Blocks.P) {
                                    ++l;
                                }
                                if (this.a.zeroday(this.b.zeroday(k * 2, 1, j * 2)).sigma() == Blocks.P) {
                                    ++l;
                                }
                                if (k != 0 && j != 0) {
                                    if (this.a.zeroday(this.b.zeroday(k * 2, 0, j)).sigma() == Blocks.P) {
                                        ++l;
                                    }
                                    if (this.a.zeroday(this.b.zeroday(k * 2, 1, j)).sigma() == Blocks.P) {
                                        ++l;
                                    }
                                    if (this.a.zeroday(this.b.zeroday(k, 0, j * 2)).sigma() == Blocks.P) {
                                        ++l;
                                    }
                                    if (this.a.zeroday(this.b.zeroday(k, 1, j * 2)).sigma() == Blocks.P) {
                                        ++l;
                                    }
                                }
                            }
                        }
                    }
                    this.c.setSeed(this.flux);
                    for (int i1 = 0; i1 < 3; ++i1) {
                        this.vape[i1] = EnchantmentHelper.zerodayisaminecraftcheat(this.c, i1, l, itemstack);
                        this.momgetthecamera[i1] = -1;
                        if (this.vape[i1] < i1 + 1) {
                            this.vape[i1] = 0;
                        }
                    }
                    for (int j2 = 0; j2 < 3; ++j2) {
                        if (this.vape[j2] > 0) {
                            final List<EnchantmentData> list = this.zerodayisaminecraftcheat(itemstack, j2, this.vape[j2]);
                            if (list != null && !list.isEmpty()) {
                                final EnchantmentData enchantmentdata = list.get(this.c.nextInt(list.size()));
                                this.momgetthecamera[j2] = (enchantmentdata.zerodayisaminecraftcheat.s | enchantmentdata.zeroday << 8);
                            }
                        }
                    }
                    this.sigma();
                }
            }
            else {
                for (int m = 0; m < 3; ++m) {
                    this.vape[m] = 0;
                    this.momgetthecamera[m] = -1;
                }
            }
        }
    }
    
    @Override
    public boolean zeroday(final EntityPlayer playerIn, final int id) {
        final ItemStack itemstack = this.zerodayisaminecraftcheat.d(0);
        final ItemStack itemstack2 = this.zerodayisaminecraftcheat.d(1);
        final int i = id + 1;
        if ((itemstack2 == null || itemstack2.zeroday < i) && !playerIn.bz.pandora) {
            return false;
        }
        if (this.vape[id] > 0 && itemstack != null && ((playerIn.bA >= i && playerIn.bA >= this.vape[id]) || playerIn.bz.pandora)) {
            if (!this.a.r) {
                final List<EnchantmentData> list = this.zerodayisaminecraftcheat(itemstack, id, this.vape[id]);
                final boolean flag = itemstack.zerodayisaminecraftcheat() == Items.aD;
                if (list != null) {
                    playerIn.k(i);
                    if (flag) {
                        itemstack.zerodayisaminecraftcheat(Items.bV);
                    }
                    for (int j = 0; j < list.size(); ++j) {
                        final EnchantmentData enchantmentdata = list.get(j);
                        if (flag) {
                            Items.bV.zerodayisaminecraftcheat(itemstack, enchantmentdata);
                        }
                        else {
                            itemstack.zerodayisaminecraftcheat(enchantmentdata.zerodayisaminecraftcheat, enchantmentdata.zeroday);
                        }
                    }
                    if (!playerIn.bz.pandora) {
                        final ItemStack itemStack = itemstack2;
                        itemStack.zeroday -= i;
                        if (itemstack2.zeroday <= 0) {
                            this.zerodayisaminecraftcheat.sigma(1, null);
                        }
                    }
                    playerIn.zerodayisaminecraftcheat(StatList.O);
                    this.zerodayisaminecraftcheat.t();
                    this.flux = playerIn.bg();
                    this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
                }
            }
            return true;
        }
        return false;
    }
    
    private List<EnchantmentData> zerodayisaminecraftcheat(final ItemStack stack, final int p_178148_2_, final int p_178148_3_) {
        this.c.setSeed(this.flux + p_178148_2_);
        final List<EnchantmentData> list = EnchantmentHelper.zeroday(this.c, stack, p_178148_3_);
        if (stack.zerodayisaminecraftcheat() == Items.aD && list != null && list.size() > 1) {
            list.remove(this.c.nextInt(list.size()));
        }
        return list;
    }
    
    public int zerodayisaminecraftcheat() {
        final ItemStack itemstack = this.zerodayisaminecraftcheat.d(1);
        return (itemstack == null) ? 0 : itemstack.zeroday;
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        if (!this.a.r) {
            for (int i = 0; i < this.zerodayisaminecraftcheat.a(); ++i) {
                final ItemStack itemstack = this.zerodayisaminecraftcheat.e(i);
                if (itemstack != null) {
                    playerIn.zerodayisaminecraftcheat(itemstack, false);
                }
            }
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.a.zeroday(this.b).sigma() == Blocks.bu && playerIn.zues(this.b.zerodayisaminecraftcheat() + 0.5, this.b.zeroday() + 0.5, this.b.sigma() + 0.5) <= 64.0;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index == 0) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 2, 38, true)) {
                    return null;
                }
            }
            else if (index == 1) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 2, 38, true)) {
                    return null;
                }
            }
            else if (itemstack2.zerodayisaminecraftcheat() == Items.aO && EnumDyeColor.zerodayisaminecraftcheat(itemstack2.momgetthecamera()) == EnumDyeColor.d) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 1, 2, true)) {
                    return null;
                }
            }
            else {
                if (this.sigma.get(0).zeroday() || !this.sigma.get(0).zerodayisaminecraftcheat(itemstack2)) {
                    return null;
                }
                if (itemstack2.f() && itemstack2.zeroday == 1) {
                    this.sigma.get(0).zeroday(itemstack2.b());
                    itemstack2.zeroday = 0;
                }
                else if (itemstack2.zeroday >= 1) {
                    this.sigma.get(0).zeroday(new ItemStack(itemstack2.zerodayisaminecraftcheat(), 1, itemstack2.momgetthecamera()));
                    final ItemStack itemStack = itemstack2;
                    --itemStack.zeroday;
                }
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
}

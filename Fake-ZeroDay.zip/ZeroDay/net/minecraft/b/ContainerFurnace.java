// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.n.TileEntityFurnace;
import net.minecraft.c.zerodayisaminecraftcheat.FurnaceRecipes;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.vape.InventoryPlayer;

public class ContainerFurnace extends Container
{
    private final IInventory zerodayisaminecraftcheat;
    private int flux;
    private int vape;
    private int momgetthecamera;
    private int a;
    
    public ContainerFurnace(final InventoryPlayer playerInventory, final IInventory furnaceInventory) {
        this.zerodayisaminecraftcheat = furnaceInventory;
        this.zeroday(new Slot(furnaceInventory, 0, 56, 17));
        this.zeroday(new SlotFurnaceFuel(furnaceInventory, 1, 56, 53));
        this.zeroday(new SlotFurnaceOutput(playerInventory.pandora, furnaceInventory, 2, 116, 35));
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.zeroday(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int k = 0; k < 9; ++k) {
            this.zeroday(new Slot(playerInventory, k, 8 + k * 18, 142));
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ICrafting listener) {
        super.zerodayisaminecraftcheat(listener);
        listener.zerodayisaminecraftcheat(this, this.zerodayisaminecraftcheat);
    }
    
    @Override
    public void sigma() {
        super.sigma();
        for (int i = 0; i < this.zues.size(); ++i) {
            final ICrafting icrafting = this.zues.get(i);
            if (this.flux != this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(2)) {
                icrafting.zerodayisaminecraftcheat(this, 2, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(2));
            }
            if (this.momgetthecamera != this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0)) {
                icrafting.zerodayisaminecraftcheat(this, 0, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0));
            }
            if (this.a != this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(1)) {
                icrafting.zerodayisaminecraftcheat(this, 1, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(1));
            }
            if (this.vape != this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(3)) {
                icrafting.zerodayisaminecraftcheat(this, 3, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(3));
            }
        }
        this.flux = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(2);
        this.momgetthecamera = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0);
        this.a = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(1);
        this.vape = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(3);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int data) {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(id, data);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.pandora(playerIn);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index == 2) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 3, 39, true)) {
                    return null;
                }
                slot.zerodayisaminecraftcheat(itemstack2, itemstack);
            }
            else if (index != 1 && index != 0) {
                if (FurnaceRecipes.zerodayisaminecraftcheat().zerodayisaminecraftcheat(itemstack2) != null) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 0, 1, false)) {
                        return null;
                    }
                }
                else if (TileEntityFurnace.sigma(itemstack2)) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 1, 2, false)) {
                        return null;
                    }
                }
                else if (index >= 3 && index < 30) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 30, 39, false)) {
                        return null;
                    }
                }
                else if (index >= 30 && index < 39 && !this.zerodayisaminecraftcheat(itemstack2, 3, 30, false)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 3, 39, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.vape.InventoryPlayer;

public class ContainerHopper extends Container
{
    private final IInventory zerodayisaminecraftcheat;
    
    public ContainerHopper(final InventoryPlayer playerInventory, final IInventory hopperInventoryIn, final EntityPlayer player) {
        (this.zerodayisaminecraftcheat = hopperInventoryIn).zues(player);
        final int i = 51;
        for (int j = 0; j < hopperInventoryIn.a(); ++j) {
            this.zeroday(new Slot(hopperInventoryIn, j, 44 + j * 18, 20));
        }
        for (int l = 0; l < 3; ++l) {
            for (int k = 0; k < 9; ++k) {
                this.zeroday(new Slot(playerInventory, k + l * 9 + 9, 8 + k * 18, l * 18 + i));
            }
        }
        for (int i2 = 0; i2 < 9; ++i2) {
            this.zeroday(new Slot(playerInventory, i2, 8 + i2 * 18, 58 + i));
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.pandora(playerIn);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index < this.zerodayisaminecraftcheat.a()) {
                if (!this.zerodayisaminecraftcheat(itemstack2, this.zerodayisaminecraftcheat.a(), this.sigma.size(), true)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 0, this.zerodayisaminecraftcheat.a(), false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
        }
        return itemstack;
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        this.zerodayisaminecraftcheat.flux(playerIn);
    }
}

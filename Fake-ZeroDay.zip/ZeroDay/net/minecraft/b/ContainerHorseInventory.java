// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.Entity;
import net.minecraft.a.Items;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.flux.EntityHorse;

public class ContainerHorseInventory extends Container
{
    private IInventory zerodayisaminecraftcheat;
    private EntityHorse flux;
    
    public ContainerHorseInventory(final IInventory playerInventory, final IInventory horseInventoryIn, final EntityHorse horse, final EntityPlayer player) {
        this.zerodayisaminecraftcheat = horseInventoryIn;
        this.flux = horse;
        final int i = 3;
        horseInventoryIn.zues(player);
        final int j = (i - 4) * 18;
        this.zeroday(new Slot(horseInventoryIn, 0, 8, 18) {
            @Override
            public boolean zerodayisaminecraftcheat(final ItemStack stack) {
                return super.zerodayisaminecraftcheat(stack) && stack.zerodayisaminecraftcheat() == Items.as && !this.zeroday();
            }
        });
        this.zeroday(new Slot(horseInventoryIn, 1, 8, 36) {
            @Override
            public boolean zerodayisaminecraftcheat(final ItemStack stack) {
                return super.zerodayisaminecraftcheat(stack) && horse.cC() && EntityHorse.zerodayisaminecraftcheat(stack.zerodayisaminecraftcheat());
            }
            
            @Override
            public boolean flux() {
                return horse.cC();
            }
        });
        if (horse.cl()) {
            for (int k = 0; k < i; ++k) {
                for (int l = 0; l < 5; ++l) {
                    this.zeroday(new Slot(horseInventoryIn, 2 + l + k * 5, 80 + l * 18, 18 + k * 18));
                }
            }
        }
        for (int i2 = 0; i2 < 3; ++i2) {
            for (int k2 = 0; k2 < 9; ++k2) {
                this.zeroday(new Slot(playerInventory, k2 + i2 * 9 + 9, 8 + k2 * 18, 102 + i2 * 18 + j));
            }
        }
        for (int j2 = 0; j2 < 9; ++j2) {
            this.zeroday(new Slot(playerInventory, j2, 8 + j2 * 18, 160 + j));
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.pandora(playerIn) && this.flux.ac() && this.flux.pandora(playerIn) < 8.0f;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index < this.zerodayisaminecraftcheat.a()) {
                if (!this.zerodayisaminecraftcheat(itemstack2, this.zerodayisaminecraftcheat.a(), this.sigma.size(), true)) {
                    return null;
                }
            }
            else if (this.zerodayisaminecraftcheat(1).zerodayisaminecraftcheat(itemstack2) && !this.zerodayisaminecraftcheat(1).zeroday()) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 1, 2, false)) {
                    return null;
                }
            }
            else if (this.zerodayisaminecraftcheat(0).zerodayisaminecraftcheat(itemstack2)) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 0, 1, false)) {
                    return null;
                }
            }
            else if (this.zerodayisaminecraftcheat.a() <= 2 || !this.zerodayisaminecraftcheat(itemstack2, 2, this.zerodayisaminecraftcheat.a(), false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
        }
        return itemstack;
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        this.zerodayisaminecraftcheat.flux(playerIn);
    }
}

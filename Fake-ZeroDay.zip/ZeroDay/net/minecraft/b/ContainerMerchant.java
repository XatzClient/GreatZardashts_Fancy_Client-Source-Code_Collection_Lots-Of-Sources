// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.q.World;
import net.minecraft.vape.IMerchant;

public class ContainerMerchant extends Container
{
    private IMerchant zerodayisaminecraftcheat;
    private InventoryMerchant flux;
    private final World vape;
    
    public ContainerMerchant(final InventoryPlayer playerInventory, final IMerchant merchant, final World worldIn) {
        this.zerodayisaminecraftcheat = merchant;
        this.vape = worldIn;
        this.flux = new InventoryMerchant(playerInventory.pandora, merchant);
        this.zeroday(new Slot(this.flux, 0, 36, 53));
        this.zeroday(new Slot(this.flux, 1, 62, 53));
        this.zeroday(new SlotMerchantResult(playerInventory.pandora, merchant, this.flux, 2, 120, 53));
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.zeroday(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int k = 0; k < 9; ++k) {
            this.zeroday(new Slot(playerInventory, k, 8 + k * 18, 142));
        }
    }
    
    public InventoryMerchant zerodayisaminecraftcheat() {
        return this.flux;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ICrafting listener) {
        super.zerodayisaminecraftcheat(listener);
    }
    
    @Override
    public void sigma() {
        super.sigma();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IInventory inventoryIn) {
        this.flux.pandora();
        super.zerodayisaminecraftcheat(inventoryIn);
    }
    
    public void pandora(final int currentRecipeIndex) {
        this.flux.zeroday(currentRecipeIndex);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int data) {
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat.zerodayisaminecraftcheat() == playerIn;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index == 2) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 3, 39, true)) {
                    return null;
                }
                slot.zerodayisaminecraftcheat(itemstack2, itemstack);
            }
            else if (index != 0 && index != 1) {
                if (index >= 3 && index < 30) {
                    if (!this.zerodayisaminecraftcheat(itemstack2, 30, 39, false)) {
                        return null;
                    }
                }
                else if (index >= 30 && index < 39 && !this.zerodayisaminecraftcheat(itemstack2, 3, 30, false)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 3, 39, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        this.zerodayisaminecraftcheat.a_((EntityPlayer)null);
        super.zeroday(playerIn);
        if (!this.vape.r) {
            ItemStack itemstack = this.flux.e(0);
            if (itemstack != null) {
                playerIn.zerodayisaminecraftcheat(itemstack, false);
            }
            itemstack = this.flux.e(1);
            if (itemstack != null) {
                playerIn.zerodayisaminecraftcheat(itemstack, false);
            }
        }
    }
}

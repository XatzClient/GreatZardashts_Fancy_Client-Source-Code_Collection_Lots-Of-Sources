// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.c.zerodayisaminecraftcheat.CraftingManager;
import net.minecraft.a.Items;
import net.minecraft.c.Item;
import net.minecraft.a.Blocks;
import net.minecraft.c.ItemArmor;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.vape.vape.EntityPlayer;

public class ContainerPlayer extends Container
{
    public InventoryCrafting zerodayisaminecraftcheat;
    public IInventory flux;
    public boolean vape;
    private final EntityPlayer momgetthecamera;
    
    public ContainerPlayer(final InventoryPlayer playerInventory, final boolean localWorld, final EntityPlayer player) {
        this.zerodayisaminecraftcheat = new InventoryCrafting(this, 2, 2);
        this.flux = new InventoryCraftResult();
        this.vape = localWorld;
        this.momgetthecamera = player;
        this.zeroday(new SlotCrafting(playerInventory.pandora, this.zerodayisaminecraftcheat, this.flux, 0, 144, 36));
        for (int i = 0; i < 2; ++i) {
            for (int j = 0; j < 2; ++j) {
                this.zeroday(new Slot(this.zerodayisaminecraftcheat, j + i * 2, 88 + j * 18, 26 + i * 18));
            }
        }
        for (int k = 0; k < 4; ++k) {
            final int k_f = k;
            this.zeroday(new Slot(playerInventory, playerInventory.a() - 1 - k, 8, 8 + k * 18) {
                @Override
                public int pandora() {
                    return 1;
                }
                
                @Override
                public boolean zerodayisaminecraftcheat(final ItemStack stack) {
                    return stack != null && ((stack.zerodayisaminecraftcheat() instanceof ItemArmor) ? (((ItemArmor)stack.zerodayisaminecraftcheat()).momgetthecamera == k_f) : ((stack.zerodayisaminecraftcheat() == Item.zerodayisaminecraftcheat(Blocks.aM) || stack.zerodayisaminecraftcheat() == Items.bP) && k_f == 0));
                }
                
                @Override
                public String zues() {
                    return ItemArmor.vape[k_f];
                }
            });
        }
        for (int l = 0; l < 3; ++l) {
            for (int j2 = 0; j2 < 9; ++j2) {
                this.zeroday(new Slot(playerInventory, j2 + (l + 1) * 9, 8 + j2 * 18, 84 + l * 18));
            }
        }
        for (int i2 = 0; i2 < 9; ++i2) {
            this.zeroday(new Slot(playerInventory, i2, 8 + i2 * 18, 142));
        }
        this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IInventory inventoryIn) {
        this.flux.sigma(0, CraftingManager.zerodayisaminecraftcheat().zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, this.momgetthecamera.o));
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        for (int i = 0; i < 4; ++i) {
            final ItemStack itemstack = this.zerodayisaminecraftcheat.e(i);
            if (itemstack != null) {
                playerIn.zerodayisaminecraftcheat(itemstack, false);
            }
        }
        this.flux.sigma(0, null);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return true;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index == 0) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 9, 45, true)) {
                    return null;
                }
                slot.zerodayisaminecraftcheat(itemstack2, itemstack);
            }
            else if (index >= 1 && index < 5) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 9, 45, false)) {
                    return null;
                }
            }
            else if (index >= 5 && index < 9) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 9, 45, false)) {
                    return null;
                }
            }
            else if (itemstack.zerodayisaminecraftcheat() instanceof ItemArmor && !this.sigma.get(5 + ((ItemArmor)itemstack.zerodayisaminecraftcheat()).momgetthecamera).zeroday()) {
                final int i = 5 + ((ItemArmor)itemstack.zerodayisaminecraftcheat()).momgetthecamera;
                if (!this.zerodayisaminecraftcheat(itemstack2, i, i + 1, false)) {
                    return null;
                }
            }
            else if (index >= 9 && index < 36) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 36, 45, false)) {
                    return null;
                }
            }
            else if (index >= 36 && index < 45) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 9, 36, false)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 9, 45, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final Slot p_94530_2_) {
        return p_94530_2_.zeroday != this.flux && super.zerodayisaminecraftcheat(stack, p_94530_2_);
    }
}

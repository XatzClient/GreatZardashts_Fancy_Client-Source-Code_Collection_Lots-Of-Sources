// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import java.util.Iterator;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import net.minecraft.flux.Enchantment;
import net.minecraft.a.Items;
import net.minecraft.flux.EnchantmentHelper;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockAnvil;
import net.minecraft.a.Blocks;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.InventoryPlayer;
import org.apache.logging.log4j.LogManager;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import org.apache.logging.log4j.Logger;

public class ContainerRepair extends Container
{
    private static final Logger flux;
    private IInventory vape;
    private IInventory momgetthecamera;
    private World a;
    private BlockPos b;
    public int zerodayisaminecraftcheat;
    private int c;
    private String d;
    private final EntityPlayer e;
    
    static {
        flux = LogManager.getLogger();
    }
    
    public ContainerRepair(final InventoryPlayer playerInventory, final World worldIn, final EntityPlayer player) {
        this(playerInventory, worldIn, BlockPos.zerodayisaminecraftcheat, player);
    }
    
    public ContainerRepair(final InventoryPlayer playerInventory, final World worldIn, final BlockPos blockPosIn, final EntityPlayer player) {
        this.vape = new InventoryCraftResult();
        this.momgetthecamera = new InventoryBasic("Repair", true, 2) {
            @Override
            public void t() {
                super.t();
                ContainerRepair.this.zerodayisaminecraftcheat(this);
            }
        };
        this.b = blockPosIn;
        this.a = worldIn;
        this.e = player;
        this.zeroday(new Slot(this.momgetthecamera, 0, 27, 47));
        this.zeroday(new Slot(this.momgetthecamera, 1, 76, 47));
        this.zeroday(new Slot(this.vape, 2, 134, 47) {
            @Override
            public boolean zerodayisaminecraftcheat(final ItemStack stack) {
                return false;
            }
            
            @Override
            public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
                return (playerIn.bz.pandora || playerIn.bA >= ContainerRepair.this.zerodayisaminecraftcheat) && ContainerRepair.this.zerodayisaminecraftcheat > 0 && this.zeroday();
            }
            
            @Override
            public void zerodayisaminecraftcheat(final EntityPlayer playerIn, final ItemStack stack) {
                if (!playerIn.bz.pandora) {
                    playerIn.l(-ContainerRepair.this.zerodayisaminecraftcheat);
                }
                ContainerRepair.this.momgetthecamera.sigma(0, null);
                if (ContainerRepair.this.c > 0) {
                    final ItemStack itemstack = ContainerRepair.this.momgetthecamera.d(1);
                    if (itemstack != null && itemstack.zeroday > ContainerRepair.this.c) {
                        final ItemStack itemStack = itemstack;
                        itemStack.zeroday -= ContainerRepair.this.c;
                        ContainerRepair.this.momgetthecamera.sigma(1, itemstack);
                    }
                    else {
                        ContainerRepair.this.momgetthecamera.sigma(1, null);
                    }
                }
                else {
                    ContainerRepair.this.momgetthecamera.sigma(1, null);
                }
                ContainerRepair.this.zerodayisaminecraftcheat = 0;
                final IBlockState iblockstate = worldIn.zeroday(blockPosIn);
                if (!playerIn.bz.pandora && !worldIn.r && iblockstate.sigma() == Blocks.bX && playerIn.bm().nextFloat() < 0.12f) {
                    int l = iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockAnvil.E);
                    if (++l > 2) {
                        worldIn.momgetthecamera(blockPosIn);
                        worldIn.zeroday(1020, blockPosIn, 0);
                    }
                    else {
                        worldIn.zerodayisaminecraftcheat(blockPosIn, iblockstate.zerodayisaminecraftcheat((IProperty<Comparable>)BlockAnvil.E, l), 2);
                        worldIn.zeroday(1021, blockPosIn, 0);
                    }
                }
                else if (!worldIn.r) {
                    worldIn.zeroday(1021, blockPosIn, 0);
                }
            }
        });
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.zeroday(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int k = 0; k < 9; ++k) {
            this.zeroday(new Slot(playerInventory, k, 8 + k * 18, 142));
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IInventory inventoryIn) {
        super.zerodayisaminecraftcheat(inventoryIn);
        if (inventoryIn == this.momgetthecamera) {
            this.zerodayisaminecraftcheat();
        }
    }
    
    public void zerodayisaminecraftcheat() {
        final int i = 0;
        final int j = 1;
        final int k = 1;
        final int l = 1;
        final int i2 = 2;
        final int j2 = 1;
        final int k2 = 1;
        final ItemStack itemstack = this.momgetthecamera.d(0);
        this.zerodayisaminecraftcheat = 1;
        int l2 = 0;
        int i3 = 0;
        int j3 = 0;
        if (itemstack == null) {
            this.vape.sigma(0, null);
            this.zerodayisaminecraftcheat = 0;
        }
        else {
            ItemStack itemstack2 = itemstack.b();
            final ItemStack itemstack3 = this.momgetthecamera.d(1);
            final Map<Integer, Integer> map = EnchantmentHelper.zerodayisaminecraftcheat(itemstack2);
            boolean flag = false;
            i3 = i3 + itemstack.s() + ((itemstack3 == null) ? 0 : itemstack3.s());
            this.c = 0;
            if (itemstack3 != null) {
                flag = (itemstack3.zerodayisaminecraftcheat() == Items.bV && Items.bV.c(itemstack3).zues() > 0);
                if (itemstack2.pandora() && itemstack2.zerodayisaminecraftcheat().zerodayisaminecraftcheat(itemstack, itemstack3)) {
                    int j4 = Math.min(itemstack2.vape(), itemstack2.a() / 4);
                    if (j4 <= 0) {
                        this.vape.sigma(0, null);
                        this.zerodayisaminecraftcheat = 0;
                        return;
                    }
                    int l3;
                    for (l3 = 0; j4 > 0 && l3 < itemstack3.zeroday; j4 = Math.min(itemstack2.vape(), itemstack2.a() / 4), ++l3) {
                        final int j5 = itemstack2.vape() - j4;
                        itemstack2.zeroday(j5);
                        ++l2;
                    }
                    this.c = l3;
                }
                else {
                    if (!flag && (itemstack2.zerodayisaminecraftcheat() != itemstack3.zerodayisaminecraftcheat() || !itemstack2.pandora())) {
                        this.vape.sigma(0, null);
                        this.zerodayisaminecraftcheat = 0;
                        return;
                    }
                    if (itemstack2.pandora() && !flag) {
                        final int k3 = itemstack.a() - itemstack.vape();
                        final int l4 = itemstack3.a() - itemstack3.vape();
                        final int i4 = l4 + itemstack2.a() * 12 / 100;
                        final int j6 = k3 + i4;
                        int k4 = itemstack2.a() - j6;
                        if (k4 < 0) {
                            k4 = 0;
                        }
                        if (k4 < itemstack2.momgetthecamera()) {
                            itemstack2.zeroday(k4);
                            l2 += 2;
                        }
                    }
                    final Map<Integer, Integer> map2 = EnchantmentHelper.zerodayisaminecraftcheat(itemstack3);
                    for (final int i5 : map2.keySet()) {
                        final Enchantment enchantment = Enchantment.zerodayisaminecraftcheat(i5);
                        if (enchantment != null) {
                            final int k5 = map.containsKey(i5) ? map.get(i5) : 0;
                            int l5 = map2.get(i5);
                            int i6;
                            if (k5 == l5) {
                                i6 = ++l5;
                            }
                            else {
                                i6 = Math.max(l5, k5);
                            }
                            l5 = i6;
                            boolean flag2 = enchantment.zerodayisaminecraftcheat(itemstack);
                            if (this.e.bz.pandora || itemstack.zerodayisaminecraftcheat() == Items.bV) {
                                flag2 = true;
                            }
                            for (final int i7 : map.keySet()) {
                                if (i7 != i5 && !enchantment.zerodayisaminecraftcheat(Enchantment.zerodayisaminecraftcheat(i7))) {
                                    flag2 = false;
                                    ++l2;
                                }
                            }
                            if (!flag2) {
                                continue;
                            }
                            if (l5 > enchantment.pandora()) {
                                l5 = enchantment.pandora();
                            }
                            map.put(i5, l5);
                            int l6 = 0;
                            switch (enchantment.zeroday()) {
                                case 1: {
                                    l6 = 8;
                                    break;
                                }
                                case 2: {
                                    l6 = 4;
                                    break;
                                }
                                case 5: {
                                    l6 = 2;
                                    break;
                                }
                                case 10: {
                                    l6 = 1;
                                    break;
                                }
                            }
                            if (flag) {
                                l6 = Math.max(1, l6 / 2);
                            }
                            l2 += l6 * l5;
                        }
                    }
                }
            }
            if (StringUtils.isBlank((CharSequence)this.d)) {
                if (itemstack.k()) {
                    j3 = 1;
                    l2 += j3;
                    itemstack2.j();
                }
            }
            else if (!this.d.equals(itemstack.i())) {
                j3 = 1;
                l2 += j3;
                itemstack2.zerodayisaminecraftcheat(this.d);
            }
            this.zerodayisaminecraftcheat = i3 + l2;
            if (l2 <= 0) {
                itemstack2 = null;
            }
            if (j3 == l2 && j3 > 0 && this.zerodayisaminecraftcheat >= 40) {
                this.zerodayisaminecraftcheat = 39;
            }
            if (this.zerodayisaminecraftcheat >= 40 && !this.e.bz.pandora) {
                itemstack2 = null;
            }
            if (itemstack2 != null) {
                int k6 = itemstack2.s();
                if (itemstack3 != null && k6 < itemstack3.s()) {
                    k6 = itemstack3.s();
                }
                k6 = k6 * 2 + 1;
                itemstack2.sigma(k6);
                EnchantmentHelper.zerodayisaminecraftcheat(map, itemstack2);
            }
            this.vape.sigma(0, itemstack2);
            this.sigma();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ICrafting listener) {
        super.zerodayisaminecraftcheat(listener);
        listener.zerodayisaminecraftcheat(this, 0, this.zerodayisaminecraftcheat);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int data) {
        if (id == 0) {
            this.zerodayisaminecraftcheat = data;
        }
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        if (!this.a.r) {
            for (int i = 0; i < this.momgetthecamera.a(); ++i) {
                final ItemStack itemstack = this.momgetthecamera.e(i);
                if (itemstack != null) {
                    playerIn.zerodayisaminecraftcheat(itemstack, false);
                }
            }
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.a.zeroday(this.b).sigma() == Blocks.bX && playerIn.zues(this.b.zerodayisaminecraftcheat() + 0.5, this.b.zeroday() + 0.5, this.b.sigma() + 0.5) <= 64.0;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index == 2) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 3, 39, true)) {
                    return null;
                }
                slot.zerodayisaminecraftcheat(itemstack2, itemstack);
            }
            else if (index != 0 && index != 1) {
                if (index >= 3 && index < 39 && !this.zerodayisaminecraftcheat(itemstack2, 0, 2, false)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 3, 39, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
    
    public void zerodayisaminecraftcheat(final String newName) {
        this.d = newName;
        if (this.zerodayisaminecraftcheat(2).zeroday()) {
            final ItemStack itemstack = this.zerodayisaminecraftcheat(2).zerodayisaminecraftcheat();
            if (StringUtils.isBlank((CharSequence)newName)) {
                itemstack.j();
            }
            else {
                itemstack.zerodayisaminecraftcheat(this.d);
            }
        }
        this.zerodayisaminecraftcheat();
    }
}

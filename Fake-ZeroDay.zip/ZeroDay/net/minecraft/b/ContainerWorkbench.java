// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.a.Blocks;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.c.zerodayisaminecraftcheat.CraftingManager;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;

public class ContainerWorkbench extends Container
{
    public InventoryCrafting zerodayisaminecraftcheat;
    public IInventory flux;
    private World vape;
    private BlockPos momgetthecamera;
    
    public ContainerWorkbench(final InventoryPlayer playerInventory, final World worldIn, final BlockPos posIn) {
        this.zerodayisaminecraftcheat = new InventoryCrafting(this, 3, 3);
        this.flux = new InventoryCraftResult();
        this.vape = worldIn;
        this.momgetthecamera = posIn;
        this.zeroday(new SlotCrafting(playerInventory.pandora, this.zerodayisaminecraftcheat, this.flux, 0, 124, 35));
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                this.zeroday(new Slot(this.zerodayisaminecraftcheat, j + i * 3, 30 + j * 18, 17 + i * 18));
            }
        }
        for (int k = 0; k < 3; ++k) {
            for (int i2 = 0; i2 < 9; ++i2) {
                this.zeroday(new Slot(playerInventory, i2 + k * 9 + 9, 8 + i2 * 18, 84 + k * 18));
            }
        }
        for (int l = 0; l < 9; ++l) {
            this.zeroday(new Slot(playerInventory, l, 8 + l * 18, 142));
        }
        this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IInventory inventoryIn) {
        this.flux.sigma(0, CraftingManager.zerodayisaminecraftcheat().zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, this.vape));
    }
    
    @Override
    public void zeroday(final EntityPlayer playerIn) {
        super.zeroday(playerIn);
        if (!this.vape.r) {
            for (int i = 0; i < 9; ++i) {
                final ItemStack itemstack = this.zerodayisaminecraftcheat.e(i);
                if (itemstack != null) {
                    playerIn.zerodayisaminecraftcheat(itemstack, false);
                }
            }
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return this.vape.zeroday(this.momgetthecamera).sigma() == Blocks.aa && playerIn.zues(this.momgetthecamera.zerodayisaminecraftcheat() + 0.5, this.momgetthecamera.zeroday() + 0.5, this.momgetthecamera.sigma() + 0.5) <= 64.0;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final EntityPlayer playerIn, final int index) {
        ItemStack itemstack = null;
        final Slot slot = this.sigma.get(index);
        if (slot != null && slot.zeroday()) {
            final ItemStack itemstack2 = slot.zerodayisaminecraftcheat();
            itemstack = itemstack2.b();
            if (index == 0) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 10, 46, true)) {
                    return null;
                }
                slot.zerodayisaminecraftcheat(itemstack2, itemstack);
            }
            else if (index >= 10 && index < 37) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 37, 46, false)) {
                    return null;
                }
            }
            else if (index >= 37 && index < 46) {
                if (!this.zerodayisaminecraftcheat(itemstack2, 10, 37, false)) {
                    return null;
                }
            }
            else if (!this.zerodayisaminecraftcheat(itemstack2, 10, 46, false)) {
                return null;
            }
            if (itemstack2.zeroday == 0) {
                slot.zeroday(null);
            }
            else {
                slot.sigma();
            }
            if (itemstack2.zeroday == itemstack.zeroday) {
                return null;
            }
            slot.zerodayisaminecraftcheat(playerIn, itemstack2);
        }
        return itemstack;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final Slot p_94530_2_) {
        return p_94530_2_.zeroday != this.flux && super.zerodayisaminecraftcheat(stack, p_94530_2_);
    }
}

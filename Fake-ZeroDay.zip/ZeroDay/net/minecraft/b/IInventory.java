// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.c.ItemStack;
import net.minecraft.q.IWorldNameable;

public interface IInventory extends IWorldNameable
{
    int a();
    
    ItemStack d(final int p0);
    
    ItemStack zeroday(final int p0, final int p1);
    
    ItemStack e(final int p0);
    
    void sigma(final int p0, final ItemStack p1);
    
    int u();
    
    void t();
    
    boolean pandora(final EntityPlayer p0);
    
    void zues(final EntityPlayer p0);
    
    void flux(final EntityPlayer p0);
    
    boolean pandora(final int p0, final ItemStack p1);
    
    int zerodayisaminecraftcheat(final int p0);
    
    void zerodayisaminecraftcheat(final int p0, final int p1);
    
    int C_();
    
    void v();
}

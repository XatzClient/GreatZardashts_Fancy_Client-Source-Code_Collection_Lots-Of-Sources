// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.c.ItemStack;
import net.minecraft.o.EnumFacing;

public interface ISidedInventory extends IInventory
{
    int[] zerodayisaminecraftcheat(final EnumFacing p0);
    
    boolean zerodayisaminecraftcheat(final int p0, final ItemStack p1, final EnumFacing p2);
    
    boolean zeroday(final int p0, final ItemStack p1, final EnumFacing p2);
}

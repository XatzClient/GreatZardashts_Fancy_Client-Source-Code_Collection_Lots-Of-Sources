// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.o.ChatComponentText;
import com.google.common.collect.Lists;
import net.minecraft.o.IChatComponent;
import java.util.List;
import net.minecraft.c.ItemStack;

public class InventoryBasic implements IInventory
{
    private String zerodayisaminecraftcheat;
    private int zeroday;
    private ItemStack[] sigma;
    private List<IInvBasic> pandora;
    private boolean zues;
    
    public InventoryBasic(final String title, final boolean customName, final int slotCount) {
        this.zerodayisaminecraftcheat = title;
        this.zues = customName;
        this.zeroday = slotCount;
        this.sigma = new ItemStack[slotCount];
    }
    
    public InventoryBasic(final IChatComponent title, final int slotCount) {
        this(title.momgetthecamera(), true, slotCount);
    }
    
    public void zerodayisaminecraftcheat(final IInvBasic p_110134_1_) {
        if (this.pandora == null) {
            this.pandora = (List<IInvBasic>)Lists.newArrayList();
        }
        this.pandora.add(p_110134_1_);
    }
    
    public void zeroday(final IInvBasic p_110132_1_) {
        this.pandora.remove(p_110132_1_);
    }
    
    @Override
    public ItemStack d(final int index) {
        return (index >= 0 && index < this.sigma.length) ? this.sigma[index] : null;
    }
    
    @Override
    public ItemStack zeroday(final int index, final int count) {
        if (this.sigma[index] == null) {
            return null;
        }
        if (this.sigma[index].zeroday <= count) {
            final ItemStack itemstack1 = this.sigma[index];
            this.sigma[index] = null;
            this.t();
            return itemstack1;
        }
        final ItemStack itemstack2 = this.sigma[index].zerodayisaminecraftcheat(count);
        if (this.sigma[index].zeroday == 0) {
            this.sigma[index] = null;
        }
        this.t();
        return itemstack2;
    }
    
    public ItemStack zerodayisaminecraftcheat(final ItemStack stack) {
        final ItemStack itemstack = stack.b();
        for (int i = 0; i < this.zeroday; ++i) {
            final ItemStack itemstack2 = this.d(i);
            if (itemstack2 == null) {
                this.sigma(i, itemstack);
                this.t();
                return null;
            }
            if (ItemStack.sigma(itemstack2, itemstack)) {
                final int j = Math.min(this.u(), itemstack2.zeroday());
                final int k = Math.min(itemstack.zeroday, j - itemstack2.zeroday);
                if (k > 0) {
                    final ItemStack itemStack = itemstack2;
                    itemStack.zeroday += k;
                    final ItemStack itemStack2 = itemstack;
                    itemStack2.zeroday -= k;
                    if (itemstack.zeroday <= 0) {
                        this.t();
                        return null;
                    }
                }
            }
        }
        if (itemstack.zeroday != stack.zeroday) {
            this.t();
        }
        return itemstack;
    }
    
    @Override
    public ItemStack e(final int index) {
        if (this.sigma[index] != null) {
            final ItemStack itemstack = this.sigma[index];
            this.sigma[index] = null;
            return itemstack;
        }
        return null;
    }
    
    @Override
    public void sigma(final int index, final ItemStack stack) {
        this.sigma[index] = stack;
        if (stack != null && stack.zeroday > this.u()) {
            stack.zeroday = this.u();
        }
        this.t();
    }
    
    @Override
    public int a() {
        return this.zeroday;
    }
    
    @Override
    public String l_() {
        return this.zerodayisaminecraftcheat;
    }
    
    @Override
    public boolean p_() {
        return this.zues;
    }
    
    public void zerodayisaminecraftcheat(final String inventoryTitleIn) {
        this.zues = true;
        this.zerodayisaminecraftcheat = inventoryTitleIn;
    }
    
    @Override
    public IChatComponent sigma() {
        return this.p_() ? new ChatComponentText(this.l_()) : new ChatComponentTranslation(this.l_(), new Object[0]);
    }
    
    @Override
    public int u() {
        return 64;
    }
    
    @Override
    public void t() {
        if (this.pandora != null) {
            for (int i = 0; i < this.pandora.size(); ++i) {
                this.pandora.get(i).zerodayisaminecraftcheat(this);
            }
        }
    }
    
    @Override
    public boolean pandora(final EntityPlayer player) {
        return true;
    }
    
    @Override
    public void zues(final EntityPlayer player) {
    }
    
    @Override
    public void flux(final EntityPlayer player) {
    }
    
    @Override
    public boolean pandora(final int index, final ItemStack stack) {
        return true;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final int id) {
        return 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int value) {
    }
    
    @Override
    public int C_() {
        return 0;
    }
    
    @Override
    public void v() {
        for (int i = 0; i < this.sigma.length; ++i) {
            this.sigma[i] = null;
        }
    }
}

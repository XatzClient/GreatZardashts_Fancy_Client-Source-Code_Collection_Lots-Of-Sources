// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.o.ChatComponentText;
import net.minecraft.o.IChatComponent;
import net.minecraft.c.ItemStack;

public class InventoryCraftResult implements IInventory
{
    private ItemStack[] zerodayisaminecraftcheat;
    
    public InventoryCraftResult() {
        this.zerodayisaminecraftcheat = new ItemStack[1];
    }
    
    @Override
    public int a() {
        return 1;
    }
    
    @Override
    public ItemStack d(final int index) {
        return this.zerodayisaminecraftcheat[0];
    }
    
    @Override
    public String l_() {
        return "Result";
    }
    
    @Override
    public boolean p_() {
        return false;
    }
    
    @Override
    public IChatComponent sigma() {
        return this.p_() ? new ChatComponentText(this.l_()) : new ChatComponentTranslation(this.l_(), new Object[0]);
    }
    
    @Override
    public ItemStack zeroday(final int index, final int count) {
        if (this.zerodayisaminecraftcheat[0] != null) {
            final ItemStack itemstack = this.zerodayisaminecraftcheat[0];
            this.zerodayisaminecraftcheat[0] = null;
            return itemstack;
        }
        return null;
    }
    
    @Override
    public ItemStack e(final int index) {
        if (this.zerodayisaminecraftcheat[0] != null) {
            final ItemStack itemstack = this.zerodayisaminecraftcheat[0];
            this.zerodayisaminecraftcheat[0] = null;
            return itemstack;
        }
        return null;
    }
    
    @Override
    public void sigma(final int index, final ItemStack stack) {
        this.zerodayisaminecraftcheat[0] = stack;
    }
    
    @Override
    public int u() {
        return 64;
    }
    
    @Override
    public void t() {
    }
    
    @Override
    public boolean pandora(final EntityPlayer player) {
        return true;
    }
    
    @Override
    public void zues(final EntityPlayer player) {
    }
    
    @Override
    public void flux(final EntityPlayer player) {
    }
    
    @Override
    public boolean pandora(final int index, final ItemStack stack) {
        return true;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final int id) {
        return 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int value) {
    }
    
    @Override
    public int C_() {
        return 0;
    }
    
    @Override
    public void v() {
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            this.zerodayisaminecraftcheat[i] = null;
        }
    }
}

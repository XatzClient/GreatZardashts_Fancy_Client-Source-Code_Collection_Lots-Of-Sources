// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.o.ChatComponentText;
import net.minecraft.o.IChatComponent;
import net.minecraft.c.ItemStack;

public class InventoryCrafting implements IInventory
{
    private final ItemStack[] zerodayisaminecraftcheat;
    private final int zeroday;
    private final int sigma;
    private final Container pandora;
    
    public InventoryCrafting(final Container eventHandlerIn, final int width, final int height) {
        final int i = width * height;
        this.zerodayisaminecraftcheat = new ItemStack[i];
        this.pandora = eventHandlerIn;
        this.zeroday = width;
        this.sigma = height;
    }
    
    @Override
    public int a() {
        return this.zerodayisaminecraftcheat.length;
    }
    
    @Override
    public ItemStack d(final int index) {
        return (index >= this.a()) ? null : this.zerodayisaminecraftcheat[index];
    }
    
    public ItemStack sigma(final int row, final int column) {
        return (row >= 0 && row < this.zeroday && column >= 0 && column <= this.sigma) ? this.d(row + column * this.zeroday) : null;
    }
    
    @Override
    public String l_() {
        return "container.crafting";
    }
    
    @Override
    public boolean p_() {
        return false;
    }
    
    @Override
    public IChatComponent sigma() {
        return this.p_() ? new ChatComponentText(this.l_()) : new ChatComponentTranslation(this.l_(), new Object[0]);
    }
    
    @Override
    public ItemStack e(final int index) {
        if (this.zerodayisaminecraftcheat[index] != null) {
            final ItemStack itemstack = this.zerodayisaminecraftcheat[index];
            this.zerodayisaminecraftcheat[index] = null;
            return itemstack;
        }
        return null;
    }
    
    @Override
    public ItemStack zeroday(final int index, final int count) {
        if (this.zerodayisaminecraftcheat[index] == null) {
            return null;
        }
        if (this.zerodayisaminecraftcheat[index].zeroday <= count) {
            final ItemStack itemstack1 = this.zerodayisaminecraftcheat[index];
            this.zerodayisaminecraftcheat[index] = null;
            this.pandora.zerodayisaminecraftcheat(this);
            return itemstack1;
        }
        final ItemStack itemstack2 = this.zerodayisaminecraftcheat[index].zerodayisaminecraftcheat(count);
        if (this.zerodayisaminecraftcheat[index].zeroday == 0) {
            this.zerodayisaminecraftcheat[index] = null;
        }
        this.pandora.zerodayisaminecraftcheat(this);
        return itemstack2;
    }
    
    @Override
    public void sigma(final int index, final ItemStack stack) {
        this.zerodayisaminecraftcheat[index] = stack;
        this.pandora.zerodayisaminecraftcheat(this);
    }
    
    @Override
    public int u() {
        return 64;
    }
    
    @Override
    public void t() {
    }
    
    @Override
    public boolean pandora(final EntityPlayer player) {
        return true;
    }
    
    @Override
    public void zues(final EntityPlayer player) {
    }
    
    @Override
    public void flux(final EntityPlayer player) {
    }
    
    @Override
    public boolean pandora(final int index, final ItemStack stack) {
        return true;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final int id) {
        return 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int value) {
    }
    
    @Override
    public int C_() {
        return 0;
    }
    
    @Override
    public void v() {
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            this.zerodayisaminecraftcheat[i] = null;
        }
    }
    
    public int pandora() {
        return this.sigma;
    }
    
    public int flux() {
        return this.zeroday;
    }
}

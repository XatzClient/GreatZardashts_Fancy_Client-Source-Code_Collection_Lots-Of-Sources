// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.c.ItemStack;
import net.minecraft.d.NBTTagList;
import net.minecraft.n.TileEntityEnderChest;

public class InventoryEnderChest extends InventoryBasic
{
    private TileEntityEnderChest zerodayisaminecraftcheat;
    
    public InventoryEnderChest() {
        super("container.enderchest", false, 27);
    }
    
    public void zerodayisaminecraftcheat(final TileEntityEnderChest chestTileEntity) {
        this.zerodayisaminecraftcheat = chestTileEntity;
    }
    
    public void zerodayisaminecraftcheat(final NBTTagList p_70486_1_) {
        for (int i = 0; i < this.a(); ++i) {
            this.sigma(i, null);
        }
        for (int k = 0; k < p_70486_1_.zues(); ++k) {
            final NBTTagCompound nbttagcompound = p_70486_1_.zeroday(k);
            final int j = nbttagcompound.pandora("Slot") & 0xFF;
            if (j >= 0 && j < this.a()) {
                this.sigma(j, ItemStack.zerodayisaminecraftcheat(nbttagcompound));
            }
        }
    }
    
    public NBTTagList pandora() {
        final NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.a(); ++i) {
            final ItemStack itemstack = this.d(i);
            if (itemstack != null) {
                final NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.zerodayisaminecraftcheat("Slot", (byte)i);
                itemstack.zeroday(nbttagcompound);
                nbttaglist.zerodayisaminecraftcheat(nbttagcompound);
            }
        }
        return nbttaglist;
    }
    
    @Override
    public boolean pandora(final EntityPlayer player) {
        return (this.zerodayisaminecraftcheat == null || this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(player)) && super.pandora(player);
    }
    
    @Override
    public void zues(final EntityPlayer player) {
        if (this.zerodayisaminecraftcheat != null) {
            this.zerodayisaminecraftcheat.zeroday();
        }
        super.zues(player);
    }
    
    @Override
    public void flux(final EntityPlayer player) {
        if (this.zerodayisaminecraftcheat != null) {
            this.zerodayisaminecraftcheat.sigma();
        }
        super.flux(player);
        this.zerodayisaminecraftcheat = null;
    }
}

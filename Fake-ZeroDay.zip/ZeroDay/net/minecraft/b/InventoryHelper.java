// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.d.NBTTagCompound;
import net.minecraft.vape.pandora.EntityItem;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.Entity;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import java.util.Random;

public class InventoryHelper
{
    private static final Random zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new Random();
    }
    
    public static void zerodayisaminecraftcheat(final World worldIn, final BlockPos pos, final IInventory p_180175_2_) {
        zerodayisaminecraftcheat(worldIn, pos.zerodayisaminecraftcheat(), pos.zeroday(), pos.sigma(), p_180175_2_);
    }
    
    public static void zerodayisaminecraftcheat(final World worldIn, final Entity p_180176_1_, final IInventory p_180176_2_) {
        zerodayisaminecraftcheat(worldIn, p_180176_1_.s, p_180176_1_.t, p_180176_1_.u, p_180176_2_);
    }
    
    private static void zerodayisaminecraftcheat(final World worldIn, final double x, final double y, final double z, final IInventory p_180174_7_) {
        for (int i = 0; i < p_180174_7_.a(); ++i) {
            final ItemStack itemstack = p_180174_7_.d(i);
            if (itemstack != null) {
                zerodayisaminecraftcheat(worldIn, x, y, z, itemstack);
            }
        }
    }
    
    private static void zerodayisaminecraftcheat(final World worldIn, final double x, final double y, final double z, final ItemStack stack) {
        final float f = InventoryHelper.zerodayisaminecraftcheat.nextFloat() * 0.8f + 0.1f;
        final float f2 = InventoryHelper.zerodayisaminecraftcheat.nextFloat() * 0.8f + 0.1f;
        final float f3 = InventoryHelper.zerodayisaminecraftcheat.nextFloat() * 0.8f + 0.1f;
        while (stack.zeroday > 0) {
            int i = InventoryHelper.zerodayisaminecraftcheat.nextInt(21) + 10;
            if (i > stack.zeroday) {
                i = stack.zeroday;
            }
            stack.zeroday -= i;
            final EntityItem entityitem = new EntityItem(worldIn, x + f, y + f2, z + f3, new ItemStack(stack.zerodayisaminecraftcheat(), i, stack.momgetthecamera()));
            if (stack.f()) {
                entityitem.momgetthecamera().pandora((NBTTagCompound)stack.g().zeroday());
            }
            final float f4 = 0.05f;
            entityitem.v = InventoryHelper.zerodayisaminecraftcheat.nextGaussian() * f4;
            entityitem.w = InventoryHelper.zerodayisaminecraftcheat.nextGaussian() * f4 + 0.20000000298023224;
            entityitem.x = InventoryHelper.zerodayisaminecraftcheat.nextGaussian() * f4;
            worldIn.zerodayisaminecraftcheat(entityitem);
        }
    }
}

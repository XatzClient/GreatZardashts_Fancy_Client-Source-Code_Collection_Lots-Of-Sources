// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.q.LockCode;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.c.ItemStack;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.o.ChatComponentText;
import net.minecraft.o.IChatComponent;
import net.minecraft.q.ILockableContainer;

public class InventoryLargeChest implements ILockableContainer
{
    private String zerodayisaminecraftcheat;
    private ILockableContainer zeroday;
    private ILockableContainer sigma;
    
    public InventoryLargeChest(final String nameIn, ILockableContainer upperChestIn, ILockableContainer lowerChestIn) {
        this.zerodayisaminecraftcheat = nameIn;
        if (upperChestIn == null) {
            upperChestIn = lowerChestIn;
        }
        if (lowerChestIn == null) {
            lowerChestIn = upperChestIn;
        }
        this.zeroday = upperChestIn;
        this.sigma = lowerChestIn;
        if (upperChestIn.flux()) {
            lowerChestIn.zerodayisaminecraftcheat(upperChestIn.vape());
        }
        else if (lowerChestIn.flux()) {
            upperChestIn.zerodayisaminecraftcheat(lowerChestIn.vape());
        }
    }
    
    @Override
    public int a() {
        return this.zeroday.a() + this.sigma.a();
    }
    
    public boolean zerodayisaminecraftcheat(final IInventory inventoryIn) {
        return this.zeroday == inventoryIn || this.sigma == inventoryIn;
    }
    
    @Override
    public String l_() {
        return this.zeroday.p_() ? this.zeroday.l_() : (this.sigma.p_() ? this.sigma.l_() : this.zerodayisaminecraftcheat);
    }
    
    @Override
    public boolean p_() {
        return this.zeroday.p_() || this.sigma.p_();
    }
    
    @Override
    public IChatComponent sigma() {
        return this.p_() ? new ChatComponentText(this.l_()) : new ChatComponentTranslation(this.l_(), new Object[0]);
    }
    
    @Override
    public ItemStack d(final int index) {
        return (index >= this.zeroday.a()) ? this.sigma.d(index - this.zeroday.a()) : this.zeroday.d(index);
    }
    
    @Override
    public ItemStack zeroday(final int index, final int count) {
        return (index >= this.zeroday.a()) ? this.sigma.zeroday(index - this.zeroday.a(), count) : this.zeroday.zeroday(index, count);
    }
    
    @Override
    public ItemStack e(final int index) {
        return (index >= this.zeroday.a()) ? this.sigma.e(index - this.zeroday.a()) : this.zeroday.e(index);
    }
    
    @Override
    public void sigma(final int index, final ItemStack stack) {
        if (index >= this.zeroday.a()) {
            this.sigma.sigma(index - this.zeroday.a(), stack);
        }
        else {
            this.zeroday.sigma(index, stack);
        }
    }
    
    @Override
    public int u() {
        return this.zeroday.u();
    }
    
    @Override
    public void t() {
        this.zeroday.t();
        this.sigma.t();
    }
    
    @Override
    public boolean pandora(final EntityPlayer player) {
        return this.zeroday.pandora(player) && this.sigma.pandora(player);
    }
    
    @Override
    public void zues(final EntityPlayer player) {
        this.zeroday.zues(player);
        this.sigma.zues(player);
    }
    
    @Override
    public void flux(final EntityPlayer player) {
        this.zeroday.flux(player);
        this.sigma.flux(player);
    }
    
    @Override
    public boolean pandora(final int index, final ItemStack stack) {
        return true;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final int id) {
        return 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int value) {
    }
    
    @Override
    public int C_() {
        return 0;
    }
    
    @Override
    public boolean flux() {
        return this.zeroday.flux() || this.sigma.flux();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final LockCode code) {
        this.zeroday.zerodayisaminecraftcheat(code);
        this.sigma.zerodayisaminecraftcheat(code);
    }
    
    @Override
    public LockCode vape() {
        return this.zeroday.vape();
    }
    
    @Override
    public String pandora() {
        return this.zeroday.pandora();
    }
    
    @Override
    public Container zerodayisaminecraftcheat(final InventoryPlayer playerInventory, final EntityPlayer playerIn) {
        return new ContainerChest(playerInventory, this, playerIn);
    }
    
    @Override
    public void v() {
        this.zeroday.v();
        this.sigma.v();
    }
}

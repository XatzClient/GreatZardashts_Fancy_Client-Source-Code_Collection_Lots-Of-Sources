// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.p.MerchantRecipeList;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.o.ChatComponentText;
import net.minecraft.o.IChatComponent;
import net.minecraft.p.MerchantRecipe;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.IMerchant;

public class InventoryMerchant implements IInventory
{
    private final IMerchant zerodayisaminecraftcheat;
    private ItemStack[] zeroday;
    private final EntityPlayer sigma;
    private MerchantRecipe pandora;
    private int zues;
    
    public InventoryMerchant(final EntityPlayer thePlayerIn, final IMerchant theMerchantIn) {
        this.zeroday = new ItemStack[3];
        this.sigma = thePlayerIn;
        this.zerodayisaminecraftcheat = theMerchantIn;
    }
    
    @Override
    public int a() {
        return this.zeroday.length;
    }
    
    @Override
    public ItemStack d(final int index) {
        return this.zeroday[index];
    }
    
    @Override
    public ItemStack zeroday(final int index, final int count) {
        if (this.zeroday[index] == null) {
            return null;
        }
        if (index == 2) {
            final ItemStack itemstack2 = this.zeroday[index];
            this.zeroday[index] = null;
            return itemstack2;
        }
        if (this.zeroday[index].zeroday <= count) {
            final ItemStack itemstack3 = this.zeroday[index];
            this.zeroday[index] = null;
            if (this.sigma(index)) {
                this.pandora();
            }
            return itemstack3;
        }
        final ItemStack itemstack4 = this.zeroday[index].zerodayisaminecraftcheat(count);
        if (this.zeroday[index].zeroday == 0) {
            this.zeroday[index] = null;
        }
        if (this.sigma(index)) {
            this.pandora();
        }
        return itemstack4;
    }
    
    private boolean sigma(final int p_70469_1_) {
        return p_70469_1_ == 0 || p_70469_1_ == 1;
    }
    
    @Override
    public ItemStack e(final int index) {
        if (this.zeroday[index] != null) {
            final ItemStack itemstack = this.zeroday[index];
            this.zeroday[index] = null;
            return itemstack;
        }
        return null;
    }
    
    @Override
    public void sigma(final int index, final ItemStack stack) {
        this.zeroday[index] = stack;
        if (stack != null && stack.zeroday > this.u()) {
            stack.zeroday = this.u();
        }
        if (this.sigma(index)) {
            this.pandora();
        }
    }
    
    @Override
    public String l_() {
        return "mob.villager";
    }
    
    @Override
    public boolean p_() {
        return false;
    }
    
    @Override
    public IChatComponent sigma() {
        return this.p_() ? new ChatComponentText(this.l_()) : new ChatComponentTranslation(this.l_(), new Object[0]);
    }
    
    @Override
    public int u() {
        return 64;
    }
    
    @Override
    public boolean pandora(final EntityPlayer player) {
        return this.zerodayisaminecraftcheat.zerodayisaminecraftcheat() == player;
    }
    
    @Override
    public void zues(final EntityPlayer player) {
    }
    
    @Override
    public void flux(final EntityPlayer player) {
    }
    
    @Override
    public boolean pandora(final int index, final ItemStack stack) {
        return true;
    }
    
    @Override
    public void t() {
        this.pandora();
    }
    
    public void pandora() {
        this.pandora = null;
        ItemStack itemstack = this.zeroday[0];
        ItemStack itemstack2 = this.zeroday[1];
        if (itemstack == null) {
            itemstack = itemstack2;
            itemstack2 = null;
        }
        if (itemstack == null) {
            this.sigma(2, null);
        }
        else {
            final MerchantRecipeList merchantrecipelist = this.zerodayisaminecraftcheat.zeroday(this.sigma);
            if (merchantrecipelist != null) {
                MerchantRecipe merchantrecipe = merchantrecipelist.zerodayisaminecraftcheat(itemstack, itemstack2, this.zues);
                if (merchantrecipe != null && !merchantrecipe.momgetthecamera()) {
                    this.pandora = merchantrecipe;
                    this.sigma(2, merchantrecipe.pandora().b());
                }
                else if (itemstack2 != null) {
                    merchantrecipe = merchantrecipelist.zerodayisaminecraftcheat(itemstack2, itemstack, this.zues);
                    if (merchantrecipe != null && !merchantrecipe.momgetthecamera()) {
                        this.pandora = merchantrecipe;
                        this.sigma(2, merchantrecipe.pandora().b());
                    }
                    else {
                        this.sigma(2, null);
                    }
                }
                else {
                    this.sigma(2, null);
                }
            }
        }
        this.zerodayisaminecraftcheat.a_(this.d(2));
    }
    
    public MerchantRecipe flux() {
        return this.pandora;
    }
    
    public void zeroday(final int currentRecipeIndexIn) {
        this.zues = currentRecipeIndexIn;
        this.pandora();
    }
    
    @Override
    public int zerodayisaminecraftcheat(final int id) {
        return 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int value) {
    }
    
    @Override
    public int C_() {
        return 0;
    }
    
    @Override
    public void v() {
        for (int i = 0; i < this.zeroday.length; ++i) {
            this.zeroday[i] = null;
        }
    }
}

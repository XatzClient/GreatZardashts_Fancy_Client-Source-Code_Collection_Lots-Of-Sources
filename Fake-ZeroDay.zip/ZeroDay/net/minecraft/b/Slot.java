// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.c.ItemStack;

public class Slot
{
    private final int zerodayisaminecraftcheat;
    public final IInventory zeroday;
    public int sigma;
    public int pandora;
    public int zues;
    
    public Slot(final IInventory inventoryIn, final int index, final int xPosition, final int yPosition) {
        this.zeroday = inventoryIn;
        this.zerodayisaminecraftcheat = index;
        this.pandora = xPosition;
        this.zues = yPosition;
    }
    
    public void zerodayisaminecraftcheat(final ItemStack p_75220_1_, final ItemStack p_75220_2_) {
        if (p_75220_1_ != null && p_75220_2_ != null && p_75220_1_.zerodayisaminecraftcheat() == p_75220_2_.zerodayisaminecraftcheat()) {
            final int i = p_75220_2_.zeroday - p_75220_1_.zeroday;
            if (i > 0) {
                this.zerodayisaminecraftcheat(p_75220_1_, i);
            }
        }
    }
    
    protected void zerodayisaminecraftcheat(final ItemStack stack, final int amount) {
    }
    
    protected void zues(final ItemStack stack) {
    }
    
    public void zerodayisaminecraftcheat(final EntityPlayer playerIn, final ItemStack stack) {
        this.sigma();
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack stack) {
        return true;
    }
    
    public ItemStack zerodayisaminecraftcheat() {
        return this.zeroday.d(this.zerodayisaminecraftcheat);
    }
    
    public boolean zeroday() {
        return this.zerodayisaminecraftcheat() != null;
    }
    
    public void zeroday(final ItemStack stack) {
        this.zeroday.sigma(this.zerodayisaminecraftcheat, stack);
        this.sigma();
    }
    
    public void sigma() {
        this.zeroday.t();
    }
    
    public int pandora() {
        return this.zeroday.u();
    }
    
    public int sigma(final ItemStack stack) {
        return this.pandora();
    }
    
    public String zues() {
        return null;
    }
    
    public ItemStack zerodayisaminecraftcheat(final int amount) {
        return this.zeroday.zeroday(this.zerodayisaminecraftcheat, amount);
    }
    
    public boolean zerodayisaminecraftcheat(final IInventory inv, final int slotIn) {
        return inv == this.zeroday && slotIn == this.zerodayisaminecraftcheat;
    }
    
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn) {
        return true;
    }
    
    public boolean flux() {
        return true;
    }
}

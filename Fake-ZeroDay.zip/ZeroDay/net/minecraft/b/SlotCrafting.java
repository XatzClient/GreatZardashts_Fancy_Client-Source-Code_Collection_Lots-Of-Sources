// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.c.zerodayisaminecraftcheat.CraftingManager;
import net.minecraft.c.ItemSword;
import net.minecraft.a.Items;
import net.minecraft.c.ItemHoe;
import net.minecraft.c.ItemPickaxe;
import net.minecraft.m.StatBase;
import net.minecraft.m.AchievementList;
import net.minecraft.c.Item;
import net.minecraft.a.Blocks;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;

public class SlotCrafting extends Slot
{
    private final InventoryCrafting zerodayisaminecraftcheat;
    private final EntityPlayer flux;
    private int vape;
    
    public SlotCrafting(final EntityPlayer player, final InventoryCrafting craftingInventory, final IInventory p_i45790_3_, final int slotIndex, final int xPosition, final int yPosition) {
        super(p_i45790_3_, slotIndex, xPosition, yPosition);
        this.flux = player;
        this.zerodayisaminecraftcheat = craftingInventory;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack) {
        return false;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final int amount) {
        if (this.zeroday()) {
            this.vape += Math.min(amount, this.zerodayisaminecraftcheat().zeroday);
        }
        return super.zerodayisaminecraftcheat(amount);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final ItemStack stack, final int amount) {
        this.vape += amount;
        this.zues(stack);
    }
    
    @Override
    protected void zues(final ItemStack stack) {
        if (this.vape > 0) {
            stack.zerodayisaminecraftcheat(this.flux.o, this.flux, this.vape);
        }
        this.vape = 0;
        if (stack.zerodayisaminecraftcheat() == Item.zerodayisaminecraftcheat(Blocks.aa)) {
            this.flux.zerodayisaminecraftcheat(AchievementList.momgetthecamera);
        }
        if (stack.zerodayisaminecraftcheat() instanceof ItemPickaxe) {
            this.flux.zerodayisaminecraftcheat(AchievementList.a);
        }
        if (stack.zerodayisaminecraftcheat() == Item.zerodayisaminecraftcheat(Blocks.ad)) {
            this.flux.zerodayisaminecraftcheat(AchievementList.b);
        }
        if (stack.zerodayisaminecraftcheat() instanceof ItemHoe) {
            this.flux.zerodayisaminecraftcheat(AchievementList.d);
        }
        if (stack.zerodayisaminecraftcheat() == Items.H) {
            this.flux.zerodayisaminecraftcheat(AchievementList.e);
        }
        if (stack.zerodayisaminecraftcheat() == Items.aR) {
            this.flux.zerodayisaminecraftcheat(AchievementList.f);
        }
        if (stack.zerodayisaminecraftcheat() instanceof ItemPickaxe && ((ItemPickaxe)stack.zerodayisaminecraftcheat()).j() != Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            this.flux.zerodayisaminecraftcheat(AchievementList.g);
        }
        if (stack.zerodayisaminecraftcheat() instanceof ItemSword) {
            this.flux.zerodayisaminecraftcheat(AchievementList.j);
        }
        if (stack.zerodayisaminecraftcheat() == Item.zerodayisaminecraftcheat(Blocks.bu)) {
            this.flux.zerodayisaminecraftcheat(AchievementList.w);
        }
        if (stack.zerodayisaminecraftcheat() == Item.zerodayisaminecraftcheat(Blocks.P)) {
            this.flux.zerodayisaminecraftcheat(AchievementList.y);
        }
        if (stack.zerodayisaminecraftcheat() == Items.ag && stack.momgetthecamera() == 1) {
            this.flux.zerodayisaminecraftcheat(AchievementList.E);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityPlayer playerIn, final ItemStack stack) {
        this.zues(stack);
        final ItemStack[] aitemstack = CraftingManager.zerodayisaminecraftcheat().zeroday(this.zerodayisaminecraftcheat, playerIn.o);
        for (int i = 0; i < aitemstack.length; ++i) {
            final ItemStack itemstack = this.zerodayisaminecraftcheat.d(i);
            final ItemStack itemstack2 = aitemstack[i];
            if (itemstack != null) {
                this.zerodayisaminecraftcheat.zeroday(i, 1);
            }
            if (itemstack2 != null) {
                if (this.zerodayisaminecraftcheat.d(i) == null) {
                    this.zerodayisaminecraftcheat.sigma(i, itemstack2);
                }
                else if (!this.flux.d.zerodayisaminecraftcheat(itemstack2)) {
                    this.flux.zerodayisaminecraftcheat(itemstack2, false);
                }
            }
        }
    }
}

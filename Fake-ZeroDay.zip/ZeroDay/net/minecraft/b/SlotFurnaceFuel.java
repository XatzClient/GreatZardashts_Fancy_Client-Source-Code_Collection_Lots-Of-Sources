// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.a.Items;
import net.minecraft.n.TileEntityFurnace;
import net.minecraft.c.ItemStack;

public class SlotFurnaceFuel extends Slot
{
    public SlotFurnaceFuel(final IInventory inventoryIn, final int slotIndex, final int xPosition, final int yPosition) {
        super(inventoryIn, slotIndex, xPosition, yPosition);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack) {
        return TileEntityFurnace.sigma(stack) || pandora(stack);
    }
    
    @Override
    public int sigma(final ItemStack stack) {
        return pandora(stack) ? 1 : super.sigma(stack);
    }
    
    public static boolean pandora(final ItemStack stack) {
        return stack != null && stack.zerodayisaminecraftcheat() != null && stack.zerodayisaminecraftcheat() == Items.ao;
    }
}

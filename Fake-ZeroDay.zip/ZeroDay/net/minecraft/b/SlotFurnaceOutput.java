// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.m.StatBase;
import net.minecraft.m.AchievementList;
import net.minecraft.a.Items;
import net.minecraft.vape.Entity;
import net.minecraft.vape.pandora.EntityXPOrb;
import net.minecraft.o.MathHelper;
import net.minecraft.c.zerodayisaminecraftcheat.FurnaceRecipes;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;

public class SlotFurnaceOutput extends Slot
{
    private EntityPlayer zerodayisaminecraftcheat;
    private int flux;
    
    public SlotFurnaceOutput(final EntityPlayer player, final IInventory inventoryIn, final int slotIndex, final int xPosition, final int yPosition) {
        super(inventoryIn, slotIndex, xPosition, yPosition);
        this.zerodayisaminecraftcheat = player;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack) {
        return false;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final int amount) {
        if (this.zeroday()) {
            this.flux += Math.min(amount, this.zerodayisaminecraftcheat().zeroday);
        }
        return super.zerodayisaminecraftcheat(amount);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityPlayer playerIn, final ItemStack stack) {
        this.zues(stack);
        super.zerodayisaminecraftcheat(playerIn, stack);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final ItemStack stack, final int amount) {
        this.flux += amount;
        this.zues(stack);
    }
    
    @Override
    protected void zues(final ItemStack stack) {
        stack.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.o, this.zerodayisaminecraftcheat, this.flux);
        if (!this.zerodayisaminecraftcheat.o.r) {
            int i = this.flux;
            final float f = FurnaceRecipes.zerodayisaminecraftcheat().zeroday(stack);
            if (f == 0.0f) {
                i = 0;
            }
            else if (f < 1.0f) {
                int j = MathHelper.pandora(i * f);
                if (j < MathHelper.flux(i * f) && Math.random() < i * f - j) {
                    ++j;
                }
                i = j;
            }
            while (i > 0) {
                final int k = EntityXPOrb.zerodayisaminecraftcheat(i);
                i -= k;
                this.zerodayisaminecraftcheat.o.zerodayisaminecraftcheat(new EntityXPOrb(this.zerodayisaminecraftcheat.o, this.zerodayisaminecraftcheat.s, this.zerodayisaminecraftcheat.t + 0.5, this.zerodayisaminecraftcheat.u + 0.5, k));
            }
        }
        this.flux = 0;
        if (stack.zerodayisaminecraftcheat() == Items.b) {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(AchievementList.c);
        }
        if (stack.zerodayisaminecraftcheat() == Items.aN) {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(AchievementList.h);
        }
    }
}

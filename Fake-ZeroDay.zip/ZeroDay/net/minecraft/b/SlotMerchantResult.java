// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.b;

import net.minecraft.p.MerchantRecipe;
import net.minecraft.m.StatList;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.IMerchant;
import net.minecraft.vape.vape.EntityPlayer;

public class SlotMerchantResult extends Slot
{
    private final InventoryMerchant zerodayisaminecraftcheat;
    private EntityPlayer flux;
    private int vape;
    private final IMerchant momgetthecamera;
    
    public SlotMerchantResult(final EntityPlayer player, final IMerchant merchant, final InventoryMerchant merchantInventory, final int slotIndex, final int xPosition, final int yPosition) {
        super(merchantInventory, slotIndex, xPosition, yPosition);
        this.flux = player;
        this.momgetthecamera = merchant;
        this.zerodayisaminecraftcheat = merchantInventory;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack) {
        return false;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final int amount) {
        if (this.zeroday()) {
            this.vape += Math.min(amount, this.zerodayisaminecraftcheat().zeroday);
        }
        return super.zerodayisaminecraftcheat(amount);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final ItemStack stack, final int amount) {
        this.vape += amount;
        this.zues(stack);
    }
    
    @Override
    protected void zues(final ItemStack stack) {
        stack.zerodayisaminecraftcheat(this.flux.o, this.flux, this.vape);
        this.vape = 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityPlayer playerIn, final ItemStack stack) {
        this.zues(stack);
        final MerchantRecipe merchantrecipe = this.zerodayisaminecraftcheat.flux();
        if (merchantrecipe != null) {
            ItemStack itemstack = this.zerodayisaminecraftcheat.d(0);
            ItemStack itemstack2 = this.zerodayisaminecraftcheat.d(1);
            if (this.zerodayisaminecraftcheat(merchantrecipe, itemstack, itemstack2) || this.zerodayisaminecraftcheat(merchantrecipe, itemstack2, itemstack)) {
                this.momgetthecamera.zerodayisaminecraftcheat(merchantrecipe);
                playerIn.zerodayisaminecraftcheat(StatList.y);
                if (itemstack != null && itemstack.zeroday <= 0) {
                    itemstack = null;
                }
                if (itemstack2 != null && itemstack2.zeroday <= 0) {
                    itemstack2 = null;
                }
                this.zerodayisaminecraftcheat.sigma(0, itemstack);
                this.zerodayisaminecraftcheat.sigma(1, itemstack2);
            }
        }
    }
    
    private boolean zerodayisaminecraftcheat(final MerchantRecipe trade, final ItemStack firstItem, final ItemStack secondItem) {
        final ItemStack itemstack = trade.zerodayisaminecraftcheat();
        final ItemStack itemstack2 = trade.zeroday();
        if (firstItem != null && firstItem.zerodayisaminecraftcheat() == itemstack.zerodayisaminecraftcheat()) {
            if (itemstack2 != null && secondItem != null && itemstack2.zerodayisaminecraftcheat() == secondItem.zerodayisaminecraftcheat()) {
                firstItem.zeroday -= itemstack.zeroday;
                secondItem.zeroday -= itemstack2.zeroday;
                return true;
            }
            if (itemstack2 == null && secondItem == null) {
                firstItem.zeroday -= itemstack.zeroday;
                return true;
            }
        }
        return false;
    }
}

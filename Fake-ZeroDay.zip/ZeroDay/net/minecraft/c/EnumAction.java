// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

public enum EnumAction
{
    zerodayisaminecraftcheat("NONE", 0), 
    zeroday("EAT", 1), 
    sigma("DRINK", 2), 
    pandora("BLOCK", 3), 
    zues("BOW", 4);
    
    static {
        flux = new EnumAction[] { EnumAction.zerodayisaminecraftcheat, EnumAction.zeroday, EnumAction.sigma, EnumAction.pandora, EnumAction.zues };
    }
    
    private EnumAction(final String s, final int n) {
    }
}

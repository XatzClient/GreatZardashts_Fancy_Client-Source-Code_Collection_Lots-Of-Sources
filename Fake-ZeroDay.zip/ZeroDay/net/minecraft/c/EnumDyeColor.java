// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.EnumChatFormatting;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.MapColor;
import net.minecraft.o.IStringSerializable;

public enum EnumDyeColor implements IStringSerializable
{
    zerodayisaminecraftcheat("WHITE", 0, 0, 15, "white", "white", MapColor.b, EnumChatFormatting.h), 
    zeroday("ORANGE", 1, 1, 14, "orange", "orange", MapColor.i, EnumChatFormatting.vape), 
    sigma("MAGENTA", 2, 2, 13, "magenta", "magenta", MapColor.j, EnumChatFormatting.d), 
    pandora("LIGHT_BLUE", 3, 3, 12, "light_blue", "lightBlue", MapColor.k, EnumChatFormatting.b), 
    zues("YELLOW", 4, 4, 11, "yellow", "yellow", MapColor.l, EnumChatFormatting.g), 
    flux("LIME", 5, 5, 10, "lime", "lime", MapColor.m, EnumChatFormatting.c), 
    vape("PINK", 6, 6, 9, "pink", "pink", MapColor.n, EnumChatFormatting.f), 
    momgetthecamera("GRAY", 7, 7, 8, "gray", "gray", MapColor.o, EnumChatFormatting.a), 
    a("SILVER", 8, 8, 7, "silver", "silver", MapColor.p, EnumChatFormatting.momgetthecamera), 
    b("CYAN", 9, 9, 6, "cyan", "cyan", MapColor.q, EnumChatFormatting.pandora), 
    c("PURPLE", 10, 10, 5, "purple", "purple", MapColor.r, EnumChatFormatting.flux), 
    d("BLUE", 11, 11, 4, "blue", "blue", MapColor.s, EnumChatFormatting.zeroday), 
    e("BROWN", 12, 12, 3, "brown", "brown", MapColor.t, EnumChatFormatting.vape), 
    f("GREEN", 13, 13, 2, "green", "green", MapColor.u, EnumChatFormatting.sigma), 
    g("RED", 14, 14, 1, "red", "red", MapColor.v, EnumChatFormatting.zues), 
    h("BLACK", 15, 15, 0, "black", "black", MapColor.w, EnumChatFormatting.zerodayisaminecraftcheat);
    
    private static final EnumDyeColor[] i;
    private static final EnumDyeColor[] j;
    private final int k;
    private final int l;
    private final String m;
    private final String n;
    private final MapColor o;
    private final EnumChatFormatting p;
    
    static {
        q = new EnumDyeColor[] { EnumDyeColor.zerodayisaminecraftcheat, EnumDyeColor.zeroday, EnumDyeColor.sigma, EnumDyeColor.pandora, EnumDyeColor.zues, EnumDyeColor.flux, EnumDyeColor.vape, EnumDyeColor.momgetthecamera, EnumDyeColor.a, EnumDyeColor.b, EnumDyeColor.c, EnumDyeColor.d, EnumDyeColor.e, EnumDyeColor.f, EnumDyeColor.g, EnumDyeColor.h };
        i = new EnumDyeColor[values().length];
        j = new EnumDyeColor[values().length];
        EnumDyeColor[] values;
        for (int length = (values = values()).length, k = 0; k < length; ++k) {
            final EnumDyeColor enumdyecolor = values[k];
            EnumDyeColor.i[enumdyecolor.zeroday()] = enumdyecolor;
            EnumDyeColor.j[enumdyecolor.sigma()] = enumdyecolor;
        }
    }
    
    private EnumDyeColor(final String s, final int n, final int meta, final int dyeDamage, final String name, final String unlocalizedName, final MapColor mapColorIn, final EnumChatFormatting chatColor) {
        this.k = meta;
        this.l = dyeDamage;
        this.m = name;
        this.n = unlocalizedName;
        this.o = mapColorIn;
        this.p = chatColor;
    }
    
    public int zeroday() {
        return this.k;
    }
    
    public int sigma() {
        return this.l;
    }
    
    public String pandora() {
        return this.n;
    }
    
    public MapColor zues() {
        return this.o;
    }
    
    public static EnumDyeColor zerodayisaminecraftcheat(int damage) {
        if (damage < 0 || damage >= EnumDyeColor.j.length) {
            damage = 0;
        }
        return EnumDyeColor.j[damage];
    }
    
    public static EnumDyeColor zeroday(int meta) {
        if (meta < 0 || meta >= EnumDyeColor.i.length) {
            meta = 0;
        }
        return EnumDyeColor.i[meta];
    }
    
    @Override
    public String toString() {
        return this.n;
    }
    
    @Override
    public String zerodayisaminecraftcheat() {
        return this.m;
    }
}

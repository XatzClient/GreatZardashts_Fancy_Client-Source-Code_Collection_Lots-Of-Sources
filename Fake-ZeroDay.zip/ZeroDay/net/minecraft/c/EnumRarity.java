// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.EnumChatFormatting;

public enum EnumRarity
{
    zerodayisaminecraftcheat("COMMON", 0, EnumChatFormatting.h, "Common"), 
    zeroday("UNCOMMON", 1, EnumChatFormatting.g, "Uncommon"), 
    sigma("RARE", 2, EnumChatFormatting.d, "Rare"), 
    pandora("EPIC", 3, EnumChatFormatting.f, "Epic");
    
    public final EnumChatFormatting zues;
    public final String flux;
    
    static {
        vape = new EnumRarity[] { EnumRarity.zerodayisaminecraftcheat, EnumRarity.zeroday, EnumRarity.sigma, EnumRarity.pandora };
    }
    
    private EnumRarity(final String s, final int n, final EnumChatFormatting color, final String name) {
        this.zues = color;
        this.flux = name;
    }
}

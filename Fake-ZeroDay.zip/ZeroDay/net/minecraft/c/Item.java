// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.a.Items;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.vape.pandora.EntityMinecart;
import net.minecraft.g.Potion;
import net.minecraft.vape.EntityHanging;
import net.minecraft.vape.pandora.EntityPainting;
import net.minecraft.zerodayisaminecraftcheat.BlockRedSandstone;
import net.minecraft.zerodayisaminecraftcheat.BlockPrismarine;
import net.minecraft.zerodayisaminecraftcheat.BlockDoublePlant;
import net.minecraft.zerodayisaminecraftcheat.BlockWall;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneBrick;
import net.minecraft.zerodayisaminecraftcheat.BlockSilverfish;
import net.minecraft.zerodayisaminecraftcheat.BlockFlower;
import net.minecraft.zerodayisaminecraftcheat.BlockSandStone;
import net.minecraft.zerodayisaminecraftcheat.BlockSand;
import net.minecraft.zerodayisaminecraftcheat.BlockPlanks;
import net.minecraft.zerodayisaminecraftcheat.BlockDirt;
import net.minecraft.zerodayisaminecraftcheat.BlockStone;
import com.google.common.base.Function;
import net.minecraft.a.Blocks;
import com.google.common.collect.HashMultimap;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.AttributeModifier;
import com.google.common.collect.Multimap;
import net.minecraft.o.MathHelper;
import net.minecraft.o.Vec3;
import net.minecraft.o.MovingObjectPosition;
import java.util.List;
import net.minecraft.vape.Entity;
import net.minecraft.o.StatCollector;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.d.NBTTagCompound;
import com.google.common.collect.Maps;
import java.util.Random;
import net.minecraft.pandora.CreativeTabs;
import java.util.UUID;
import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Map;
import net.minecraft.o.ResourceLocation;
import net.minecraft.o.RegistryNamespaced;

public class Item
{
    public static final RegistryNamespaced<ResourceLocation, Item> zerodayisaminecraftcheat;
    private static final Map<Block, Item> vape;
    protected static final UUID zeroday;
    private CreativeTabs momgetthecamera;
    protected static Random sigma;
    protected int pandora;
    private int a;
    protected boolean zues;
    protected boolean flux;
    private Item b;
    private String c;
    private String d;
    
    static {
        zerodayisaminecraftcheat = new RegistryNamespaced<ResourceLocation, Item>();
        vape = Maps.newHashMap();
        zeroday = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");
        Item.sigma = new Random();
    }
    
    public Item() {
        this.pandora = 64;
    }
    
    public static int zerodayisaminecraftcheat(final Item itemIn) {
        return (itemIn == null) ? 0 : Item.zerodayisaminecraftcheat.pandora(itemIn);
    }
    
    public static Item zerodayisaminecraftcheat(final int id) {
        return Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat(id);
    }
    
    public static Item zerodayisaminecraftcheat(final Block blockIn) {
        return Item.vape.get(blockIn);
    }
    
    public static Item zerodayisaminecraftcheat(final String id) {
        final Item item = Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat(new ResourceLocation(id));
        if (item == null) {
            try {
                return zerodayisaminecraftcheat(Integer.parseInt(id));
            }
            catch (NumberFormatException ex) {}
        }
        return item;
    }
    
    public boolean zerodayisaminecraftcheat(final NBTTagCompound nbt) {
        return false;
    }
    
    public Item zeroday(final int maxStackSize) {
        this.pandora = maxStackSize;
        return this;
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        return false;
    }
    
    public float zerodayisaminecraftcheat(final ItemStack stack, final Block block) {
        return 1.0f;
    }
    
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        return itemStackIn;
    }
    
    public ItemStack zeroday(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
        return stack;
    }
    
    public int zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    public int sigma(final int damage) {
        return 0;
    }
    
    public boolean zeroday() {
        return this.flux;
    }
    
    protected Item zerodayisaminecraftcheat(final boolean hasSubtypes) {
        this.flux = hasSubtypes;
        return this;
    }
    
    public int sigma() {
        return this.a;
    }
    
    protected Item pandora(final int maxDamageIn) {
        this.a = maxDamageIn;
        return this;
    }
    
    public boolean pandora() {
        return this.a > 0 && !this.flux;
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityLivingBase target, final EntityLivingBase attacker) {
        return false;
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final Block blockIn, final BlockPos pos, final EntityLivingBase playerIn) {
        return false;
    }
    
    public boolean zeroday(final Block blockIn) {
        return false;
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final EntityLivingBase target) {
        return false;
    }
    
    public Item zues() {
        this.zues = true;
        return this;
    }
    
    public boolean flux() {
        return this.zues;
    }
    
    public boolean vape() {
        return false;
    }
    
    public Item zeroday(final String unlocalizedName) {
        this.d = unlocalizedName;
        return this;
    }
    
    public String zerodayisaminecraftcheat(final ItemStack stack) {
        final String s = this.zeroday(stack);
        return (s == null) ? "" : StatCollector.zerodayisaminecraftcheat(s);
    }
    
    public String momgetthecamera() {
        return "item." + this.d;
    }
    
    public String zeroday(final ItemStack stack) {
        return "item." + this.d;
    }
    
    public Item zeroday(final Item containerItem) {
        this.b = containerItem;
        return this;
    }
    
    public boolean a() {
        return true;
    }
    
    public Item b() {
        return this.b;
    }
    
    public boolean c() {
        return this.b != null;
    }
    
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        return 16777215;
    }
    
    public void zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final Entity entityIn, final int itemSlot, final boolean isSelected) {
    }
    
    public void sigma(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
    }
    
    public boolean d() {
        return false;
    }
    
    public EnumAction sigma(final ItemStack stack) {
        return EnumAction.zerodayisaminecraftcheat;
    }
    
    public int pandora(final ItemStack stack) {
        return 0;
    }
    
    public void zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final EntityPlayer playerIn, final int timeLeft) {
    }
    
    protected Item sigma(final String potionEffect) {
        this.c = potionEffect;
        return this;
    }
    
    public String zues(final ItemStack stack) {
        return this.c;
    }
    
    public boolean flux(final ItemStack stack) {
        return this.zues(stack) != null;
    }
    
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
    }
    
    public String vape(final ItemStack stack) {
        return new StringBuilder().append(StatCollector.zerodayisaminecraftcheat(String.valueOf(this.zerodayisaminecraftcheat(stack)) + ".name")).toString().trim();
    }
    
    public boolean momgetthecamera(final ItemStack stack) {
        return stack.o();
    }
    
    public EnumRarity a(final ItemStack stack) {
        return stack.o() ? EnumRarity.sigma : EnumRarity.zerodayisaminecraftcheat;
    }
    
    public boolean b(final ItemStack stack) {
        return this.zerodayisaminecraftcheat() == 1 && this.pandora();
    }
    
    protected MovingObjectPosition zerodayisaminecraftcheat(final World worldIn, final EntityPlayer playerIn, final boolean useLiquids) {
        final float f = playerIn.z;
        final float f2 = playerIn.y;
        final double d0 = playerIn.s;
        final double d2 = playerIn.t + playerIn.aI();
        final double d3 = playerIn.u;
        final Vec3 vec3 = new Vec3(d0, d2, d3);
        final float f3 = MathHelper.zeroday(-f2 * 0.017453292f - 3.1415927f);
        final float f4 = MathHelper.zerodayisaminecraftcheat(-f2 * 0.017453292f - 3.1415927f);
        final float f5 = -MathHelper.zeroday(-f * 0.017453292f);
        final float f6 = MathHelper.zerodayisaminecraftcheat(-f * 0.017453292f);
        final float f7 = f4 * f5;
        final float f8 = f3 * f5;
        final double d4 = 5.0;
        final Vec3 vec4 = vec3.zeroday(f7 * d4, f6 * d4, f8 * d4);
        return worldIn.zerodayisaminecraftcheat(vec3, vec4, useLiquids, !useLiquids, false);
    }
    
    public int e() {
        return 0;
    }
    
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        subItems.add(new ItemStack(itemIn, 1, 0));
    }
    
    public CreativeTabs f() {
        return this.momgetthecamera;
    }
    
    public Item zerodayisaminecraftcheat(final CreativeTabs tab) {
        this.momgetthecamera = tab;
        return this;
    }
    
    public boolean g() {
        return false;
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack toRepair, final ItemStack repair) {
        return false;
    }
    
    public Multimap<String, AttributeModifier> h() {
        return (Multimap<String, AttributeModifier>)HashMultimap.create();
    }
    
    public static void i() {
        zerodayisaminecraftcheat(Blocks.zeroday, new ItemMultiTexture(Blocks.zeroday, Blocks.zeroday, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).pandora();
            }
        }).pandora("stone"));
        zerodayisaminecraftcheat(Blocks.sigma, new ItemColored(Blocks.sigma, false));
        zerodayisaminecraftcheat(Blocks.pandora, new ItemMultiTexture(Blocks.pandora, Blocks.pandora, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockDirt.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("dirt"));
        sigma(Blocks.zues);
        zerodayisaminecraftcheat(Blocks.flux, new ItemMultiTexture(Blocks.flux, Blocks.flux, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).pandora();
            }
        }).pandora("wood"));
        zerodayisaminecraftcheat(Blocks.vape, new ItemMultiTexture(Blocks.vape, Blocks.vape, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).pandora();
            }
        }).pandora("sapling"));
        sigma(Blocks.momgetthecamera);
        zerodayisaminecraftcheat(Blocks.e, new ItemMultiTexture(Blocks.e, Blocks.e, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockSand.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).pandora();
            }
        }).pandora("sand"));
        sigma(Blocks.f);
        sigma(Blocks.g);
        sigma(Blocks.h);
        sigma(Blocks.i);
        zerodayisaminecraftcheat(Blocks.j, new ItemMultiTexture(Blocks.j, Blocks.j, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).pandora();
            }
        }).pandora("log"));
        zerodayisaminecraftcheat(Blocks.k, new ItemMultiTexture(Blocks.k, Blocks.k, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera() + 4).pandora();
            }
        }).pandora("log"));
        zerodayisaminecraftcheat(Blocks.l, new ItemLeaves(Blocks.l).pandora("leaves"));
        zerodayisaminecraftcheat(Blocks.m, new ItemLeaves(Blocks.m).pandora("leaves"));
        zerodayisaminecraftcheat(Blocks.n, new ItemMultiTexture(Blocks.n, Blocks.n, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return ((p_apply_1_.momgetthecamera() & 0x1) == 0x1) ? "wet" : "dry";
            }
        }).pandora("sponge"));
        sigma(Blocks.o);
        sigma(Blocks.p);
        sigma(Blocks.q);
        sigma(Blocks.r);
        zerodayisaminecraftcheat(Blocks.s, new ItemMultiTexture(Blocks.s, Blocks.s, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockSandStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("sandStone"));
        sigma(Blocks.t);
        sigma(Blocks.v);
        sigma(Blocks.w);
        zerodayisaminecraftcheat(Blocks.x, new ItemPiston(Blocks.x));
        sigma(Blocks.y);
        zerodayisaminecraftcheat(Blocks.z, new ItemColored(Blocks.z, true).zerodayisaminecraftcheat(new String[] { "shrub", "grass", "fern" }));
        sigma(Blocks.A);
        zerodayisaminecraftcheat(Blocks.B, new ItemPiston(Blocks.B));
        zerodayisaminecraftcheat(Blocks.D, new ItemCloth(Blocks.D).pandora("cloth"));
        zerodayisaminecraftcheat(Blocks.F, new ItemMultiTexture(Blocks.F, Blocks.F, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockFlower.zeroday.zerodayisaminecraftcheat(BlockFlower.zerodayisaminecraftcheat.zerodayisaminecraftcheat, p_apply_1_.momgetthecamera()).pandora();
            }
        }).pandora("flower"));
        zerodayisaminecraftcheat(Blocks.G, new ItemMultiTexture(Blocks.G, Blocks.G, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockFlower.zeroday.zerodayisaminecraftcheat(BlockFlower.zerodayisaminecraftcheat.zeroday, p_apply_1_.momgetthecamera()).pandora();
            }
        }).pandora("rose"));
        sigma(Blocks.H);
        sigma(Blocks.I);
        sigma(Blocks.J);
        sigma(Blocks.K);
        zerodayisaminecraftcheat(Blocks.M, new ItemSlab(Blocks.M, Blocks.M, Blocks.L).pandora("stoneSlab"));
        sigma(Blocks.N);
        sigma(Blocks.O);
        sigma(Blocks.P);
        sigma(Blocks.Q);
        sigma(Blocks.R);
        sigma(Blocks.S);
        sigma(Blocks.U);
        sigma(Blocks.V);
        sigma(Blocks.W);
        sigma(Blocks.Y);
        sigma(Blocks.Z);
        sigma(Blocks.aa);
        sigma(Blocks.ac);
        sigma(Blocks.ad);
        sigma(Blocks.ae);
        sigma(Blocks.am);
        sigma(Blocks.an);
        sigma(Blocks.ao);
        sigma(Blocks.aq);
        sigma(Blocks.ar);
        sigma(Blocks.at);
        sigma(Blocks.au);
        sigma(Blocks.ax);
        sigma(Blocks.ay);
        zerodayisaminecraftcheat(Blocks.az, new ItemSnow(Blocks.az));
        sigma(Blocks.aA);
        sigma(Blocks.aB);
        sigma(Blocks.aC);
        sigma(Blocks.aD);
        sigma(Blocks.aF);
        sigma(Blocks.aG);
        sigma(Blocks.aH);
        sigma(Blocks.aI);
        sigma(Blocks.aJ);
        sigma(Blocks.aK);
        sigma(Blocks.aL);
        sigma(Blocks.aM);
        sigma(Blocks.aN);
        sigma(Blocks.aO);
        sigma(Blocks.aP);
        sigma(Blocks.aR);
        sigma(Blocks.aV);
        zerodayisaminecraftcheat(Blocks.aW, new ItemMultiTexture(Blocks.aW, Blocks.aW, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockSilverfish.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("monsterStoneEgg"));
        zerodayisaminecraftcheat(Blocks.aX, new ItemMultiTexture(Blocks.aX, Blocks.aX, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockStoneBrick.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("stonebricksmooth"));
        sigma(Blocks.aY);
        sigma(Blocks.aZ);
        sigma(Blocks.ba);
        sigma(Blocks.bb);
        sigma(Blocks.bc);
        zerodayisaminecraftcheat(Blocks.bf, new ItemColored(Blocks.bf, false));
        sigma(Blocks.bg);
        sigma(Blocks.bh);
        sigma(Blocks.bi);
        sigma(Blocks.bj);
        sigma(Blocks.bk);
        sigma(Blocks.bl);
        sigma(Blocks.bm);
        sigma(Blocks.bn);
        sigma(Blocks.bo);
        zerodayisaminecraftcheat(Blocks.bp, new ItemLilyPad(Blocks.bp));
        sigma(Blocks.bq);
        sigma(Blocks.br);
        sigma(Blocks.bs);
        sigma(Blocks.bu);
        sigma(Blocks.by);
        sigma(Blocks.bz);
        sigma(Blocks.bA);
        sigma(Blocks.bB);
        zerodayisaminecraftcheat(Blocks.bE, new ItemSlab(Blocks.bE, Blocks.bE, Blocks.bD).pandora("woodSlab"));
        sigma(Blocks.bG);
        sigma(Blocks.bH);
        sigma(Blocks.bI);
        sigma(Blocks.bJ);
        sigma(Blocks.bL);
        sigma(Blocks.bM);
        sigma(Blocks.bN);
        sigma(Blocks.bO);
        sigma(Blocks.bP);
        sigma(Blocks.bQ);
        zerodayisaminecraftcheat(Blocks.bR, new ItemMultiTexture(Blocks.bR, Blocks.bR, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockWall.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("cobbleWall"));
        sigma(Blocks.bV);
        zerodayisaminecraftcheat(Blocks.bX, new ItemAnvilBlock(Blocks.bX).pandora("anvil"));
        sigma(Blocks.bY);
        sigma(Blocks.bZ);
        sigma(Blocks.ca);
        sigma(Blocks.cd);
        sigma(Blocks.cf);
        sigma(Blocks.cg);
        sigma(Blocks.ch);
        zerodayisaminecraftcheat(Blocks.ci, new ItemMultiTexture(Blocks.ci, Blocks.ci, new String[] { "default", "chiseled", "lines" }).pandora("quartzBlock"));
        sigma(Blocks.cj);
        sigma(Blocks.ck);
        sigma(Blocks.cl);
        zerodayisaminecraftcheat(Blocks.cm, new ItemCloth(Blocks.cm).pandora("clayHardenedStained"));
        sigma(Blocks.cn);
        sigma(Blocks.co);
        sigma(Blocks.cp);
        zerodayisaminecraftcheat(Blocks.cq, new ItemCloth(Blocks.cq).pandora("woolCarpet"));
        sigma(Blocks.cr);
        sigma(Blocks.cs);
        sigma(Blocks.ct);
        sigma(Blocks.cu);
        sigma(Blocks.cv);
        sigma(Blocks.cw);
        zerodayisaminecraftcheat(Blocks.cx, new ItemDoublePlant(Blocks.cx, Blocks.cx, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockDoublePlant.zeroday.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("doublePlant"));
        zerodayisaminecraftcheat(Blocks.cy, new ItemCloth(Blocks.cy).pandora("stainedGlass"));
        zerodayisaminecraftcheat(Blocks.cz, new ItemCloth(Blocks.cz).pandora("stainedGlassPane"));
        zerodayisaminecraftcheat(Blocks.cA, new ItemMultiTexture(Blocks.cA, Blocks.cA, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockPrismarine.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("prismarine"));
        sigma(Blocks.cB);
        zerodayisaminecraftcheat(Blocks.cE, new ItemMultiTexture(Blocks.cE, Blocks.cE, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                return BlockRedSandstone.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_apply_1_.momgetthecamera()).sigma();
            }
        }).pandora("redSandStone"));
        sigma(Blocks.cF);
        zerodayisaminecraftcheat(Blocks.cH, new ItemSlab(Blocks.cH, Blocks.cH, Blocks.cG).pandora("stoneSlab2"));
        zerodayisaminecraftcheat(256, "iron_shovel", new ItemSpade(Item.zerodayisaminecraftcheat.sigma).zeroday("shovelIron"));
        zerodayisaminecraftcheat(257, "iron_pickaxe", new ItemPickaxe(Item.zerodayisaminecraftcheat.sigma).zeroday("pickaxeIron"));
        zerodayisaminecraftcheat(258, "iron_axe", new ItemAxe(Item.zerodayisaminecraftcheat.sigma).zeroday("hatchetIron"));
        zerodayisaminecraftcheat(259, "flint_and_steel", new ItemFlintAndSteel().zeroday("flintAndSteel"));
        zerodayisaminecraftcheat(260, "apple", new ItemFood(4, 0.3f, false).zeroday("apple"));
        zerodayisaminecraftcheat(261, "bow", new ItemBow().zeroday("bow"));
        zerodayisaminecraftcheat(262, "arrow", new Item().zeroday("arrow").zerodayisaminecraftcheat(CreativeTabs.b));
        zerodayisaminecraftcheat(263, "coal", new ItemCoal().zeroday("coal"));
        zerodayisaminecraftcheat(264, "diamond", new Item().zeroday("diamond").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(265, "iron_ingot", new Item().zeroday("ingotIron").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(266, "gold_ingot", new Item().zeroday("ingotGold").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(267, "iron_sword", new ItemSword(Item.zerodayisaminecraftcheat.sigma).zeroday("swordIron"));
        zerodayisaminecraftcheat(268, "wooden_sword", new ItemSword(Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat).zeroday("swordWood"));
        zerodayisaminecraftcheat(269, "wooden_shovel", new ItemSpade(Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat).zeroday("shovelWood"));
        zerodayisaminecraftcheat(270, "wooden_pickaxe", new ItemPickaxe(Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat).zeroday("pickaxeWood"));
        zerodayisaminecraftcheat(271, "wooden_axe", new ItemAxe(Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat).zeroday("hatchetWood"));
        zerodayisaminecraftcheat(272, "stone_sword", new ItemSword(Item.zerodayisaminecraftcheat.zeroday).zeroday("swordStone"));
        zerodayisaminecraftcheat(273, "stone_shovel", new ItemSpade(Item.zerodayisaminecraftcheat.zeroday).zeroday("shovelStone"));
        zerodayisaminecraftcheat(274, "stone_pickaxe", new ItemPickaxe(Item.zerodayisaminecraftcheat.zeroday).zeroday("pickaxeStone"));
        zerodayisaminecraftcheat(275, "stone_axe", new ItemAxe(Item.zerodayisaminecraftcheat.zeroday).zeroday("hatchetStone"));
        zerodayisaminecraftcheat(276, "diamond_sword", new ItemSword(Item.zerodayisaminecraftcheat.pandora).zeroday("swordDiamond"));
        zerodayisaminecraftcheat(277, "diamond_shovel", new ItemSpade(Item.zerodayisaminecraftcheat.pandora).zeroday("shovelDiamond"));
        zerodayisaminecraftcheat(278, "diamond_pickaxe", new ItemPickaxe(Item.zerodayisaminecraftcheat.pandora).zeroday("pickaxeDiamond"));
        zerodayisaminecraftcheat(279, "diamond_axe", new ItemAxe(Item.zerodayisaminecraftcheat.pandora).zeroday("hatchetDiamond"));
        zerodayisaminecraftcheat(280, "stick", new Item().zues().zeroday("stick").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(281, "bowl", new Item().zeroday("bowl").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(282, "mushroom_stew", new ItemSoup(6).zeroday("mushroomStew"));
        zerodayisaminecraftcheat(283, "golden_sword", new ItemSword(Item.zerodayisaminecraftcheat.zues).zeroday("swordGold"));
        zerodayisaminecraftcheat(284, "golden_shovel", new ItemSpade(Item.zerodayisaminecraftcheat.zues).zeroday("shovelGold"));
        zerodayisaminecraftcheat(285, "golden_pickaxe", new ItemPickaxe(Item.zerodayisaminecraftcheat.zues).zeroday("pickaxeGold"));
        zerodayisaminecraftcheat(286, "golden_axe", new ItemAxe(Item.zerodayisaminecraftcheat.zues).zeroday("hatchetGold"));
        zerodayisaminecraftcheat(287, "string", new ItemReed(Blocks.bK).zeroday("string").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(288, "feather", new Item().zeroday("feather").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(289, "gunpowder", new Item().zeroday("sulphur").sigma("+14&13-13").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(290, "wooden_hoe", new ItemHoe(Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat).zeroday("hoeWood"));
        zerodayisaminecraftcheat(291, "stone_hoe", new ItemHoe(Item.zerodayisaminecraftcheat.zeroday).zeroday("hoeStone"));
        zerodayisaminecraftcheat(292, "iron_hoe", new ItemHoe(Item.zerodayisaminecraftcheat.sigma).zeroday("hoeIron"));
        zerodayisaminecraftcheat(293, "diamond_hoe", new ItemHoe(Item.zerodayisaminecraftcheat.pandora).zeroday("hoeDiamond"));
        zerodayisaminecraftcheat(294, "golden_hoe", new ItemHoe(Item.zerodayisaminecraftcheat.zues).zeroday("hoeGold"));
        zerodayisaminecraftcheat(295, "wheat_seeds", new ItemSeeds(Blocks.ab, Blocks.ac).zeroday("seeds"));
        zerodayisaminecraftcheat(296, "wheat", new Item().zeroday("wheat").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(297, "bread", new ItemFood(5, 0.6f, false).zeroday("bread"));
        zerodayisaminecraftcheat(298, "leather_helmet", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zerodayisaminecraftcheat, 0, 0).zeroday("helmetCloth"));
        zerodayisaminecraftcheat(299, "leather_chestplate", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zerodayisaminecraftcheat, 0, 1).zeroday("chestplateCloth"));
        zerodayisaminecraftcheat(300, "leather_leggings", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zerodayisaminecraftcheat, 0, 2).zeroday("leggingsCloth"));
        zerodayisaminecraftcheat(301, "leather_boots", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zerodayisaminecraftcheat, 0, 3).zeroday("bootsCloth"));
        zerodayisaminecraftcheat(302, "chainmail_helmet", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zeroday, 1, 0).zeroday("helmetChain"));
        zerodayisaminecraftcheat(303, "chainmail_chestplate", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zeroday, 1, 1).zeroday("chestplateChain"));
        zerodayisaminecraftcheat(304, "chainmail_leggings", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zeroday, 1, 2).zeroday("leggingsChain"));
        zerodayisaminecraftcheat(305, "chainmail_boots", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zeroday, 1, 3).zeroday("bootsChain"));
        zerodayisaminecraftcheat(306, "iron_helmet", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.sigma, 2, 0).zeroday("helmetIron"));
        zerodayisaminecraftcheat(307, "iron_chestplate", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.sigma, 2, 1).zeroday("chestplateIron"));
        zerodayisaminecraftcheat(308, "iron_leggings", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.sigma, 2, 2).zeroday("leggingsIron"));
        zerodayisaminecraftcheat(309, "iron_boots", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.sigma, 2, 3).zeroday("bootsIron"));
        zerodayisaminecraftcheat(310, "diamond_helmet", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zues, 3, 0).zeroday("helmetDiamond"));
        zerodayisaminecraftcheat(311, "diamond_chestplate", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zues, 3, 1).zeroday("chestplateDiamond"));
        zerodayisaminecraftcheat(312, "diamond_leggings", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zues, 3, 2).zeroday("leggingsDiamond"));
        zerodayisaminecraftcheat(313, "diamond_boots", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.zues, 3, 3).zeroday("bootsDiamond"));
        zerodayisaminecraftcheat(314, "golden_helmet", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.pandora, 4, 0).zeroday("helmetGold"));
        zerodayisaminecraftcheat(315, "golden_chestplate", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.pandora, 4, 1).zeroday("chestplateGold"));
        zerodayisaminecraftcheat(316, "golden_leggings", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.pandora, 4, 2).zeroday("leggingsGold"));
        zerodayisaminecraftcheat(317, "golden_boots", new ItemArmor(ItemArmor.zerodayisaminecraftcheat.pandora, 4, 3).zeroday("bootsGold"));
        zerodayisaminecraftcheat(318, "flint", new Item().zeroday("flint").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(319, "porkchop", new ItemFood(3, 0.3f, true).zeroday("porkchopRaw"));
        zerodayisaminecraftcheat(320, "cooked_porkchop", new ItemFood(8, 0.8f, true).zeroday("porkchopCooked"));
        zerodayisaminecraftcheat(321, "painting", new ItemHangingEntity(EntityPainting.class).zeroday("painting"));
        zerodayisaminecraftcheat(322, "golden_apple", new ItemAppleGold(4, 1.2f, false).k().zerodayisaminecraftcheat(Potion.d.z, 5, 1, 1.0f).zeroday("appleGold"));
        zerodayisaminecraftcheat(323, "sign", new ItemSign().zeroday("sign"));
        zerodayisaminecraftcheat(324, "wooden_door", new ItemDoor(Blocks.ag).zeroday("doorOak"));
        final Item item = new ItemBucket(Blocks.zerodayisaminecraftcheat).zeroday("bucket").zeroday(16);
        zerodayisaminecraftcheat(325, "bucket", item);
        zerodayisaminecraftcheat(326, "water_bucket", new ItemBucket(Blocks.a).zeroday("bucketWater").zeroday(item));
        zerodayisaminecraftcheat(327, "lava_bucket", new ItemBucket(Blocks.c).zeroday("bucketLava").zeroday(item));
        zerodayisaminecraftcheat(328, "minecart", new ItemMinecart(EntityMinecart.zerodayisaminecraftcheat.zerodayisaminecraftcheat).zeroday("minecart"));
        zerodayisaminecraftcheat(329, "saddle", new ItemSaddle().zeroday("saddle"));
        zerodayisaminecraftcheat(330, "iron_door", new ItemDoor(Blocks.as).zeroday("doorIron"));
        zerodayisaminecraftcheat(331, "redstone", new ItemRedstone().zeroday("redstone").sigma("-5+6-7"));
        zerodayisaminecraftcheat(332, "snowball", new ItemSnowball().zeroday("snowball"));
        zerodayisaminecraftcheat(333, "boat", new ItemBoat().zeroday("boat"));
        zerodayisaminecraftcheat(334, "leather", new Item().zeroday("leather").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(335, "milk_bucket", new ItemBucketMilk().zeroday("milk").zeroday(item));
        zerodayisaminecraftcheat(336, "brick", new Item().zeroday("brick").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(337, "clay_ball", new Item().zeroday("clay").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(338, "reeds", new ItemReed(Blocks.aE).zeroday("reeds").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(339, "paper", new Item().zeroday("paper").zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(340, "book", new ItemBook().zeroday("book").zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(341, "slime_ball", new Item().zeroday("slimeball").zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(342, "chest_minecart", new ItemMinecart(EntityMinecart.zerodayisaminecraftcheat.zeroday).zeroday("minecartChest"));
        zerodayisaminecraftcheat(343, "furnace_minecart", new ItemMinecart(EntityMinecart.zerodayisaminecraftcheat.sigma).zeroday("minecartFurnace"));
        zerodayisaminecraftcheat(344, "egg", new ItemEgg().zeroday("egg"));
        zerodayisaminecraftcheat(345, "compass", new Item().zeroday("compass").zerodayisaminecraftcheat(CreativeTabs.a));
        zerodayisaminecraftcheat(346, "fishing_rod", new ItemFishingRod().zeroday("fishingRod"));
        zerodayisaminecraftcheat(347, "clock", new Item().zeroday("clock").zerodayisaminecraftcheat(CreativeTabs.a));
        zerodayisaminecraftcheat(348, "glowstone_dust", new Item().zeroday("yellowDust").sigma("+5-6-7").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(349, "fish", new ItemFishFood(false).zeroday("fish").zerodayisaminecraftcheat(true));
        zerodayisaminecraftcheat(350, "cooked_fish", new ItemFishFood(true).zeroday("fish").zerodayisaminecraftcheat(true));
        zerodayisaminecraftcheat(351, "dye", new ItemDye().zeroday("dyePowder"));
        zerodayisaminecraftcheat(352, "bone", new Item().zeroday("bone").zues().zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(353, "sugar", new Item().zeroday("sugar").sigma("-0+1-2-3&4-4+13").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(354, "cake", new ItemReed(Blocks.aS).zeroday(1).zeroday("cake").zerodayisaminecraftcheat(CreativeTabs.momgetthecamera));
        zerodayisaminecraftcheat(355, "bed", new ItemBed().zeroday(1).zeroday("bed"));
        zerodayisaminecraftcheat(356, "repeater", new ItemReed(Blocks.aT).zeroday("diode").zerodayisaminecraftcheat(CreativeTabs.pandora));
        zerodayisaminecraftcheat(357, "cookie", new ItemFood(2, 0.1f, false).zeroday("cookie"));
        zerodayisaminecraftcheat(358, "filled_map", new ItemMap().zeroday("map"));
        zerodayisaminecraftcheat(359, "shears", new ItemShears().zeroday("shears"));
        zerodayisaminecraftcheat(360, "melon", new ItemFood(2, 0.3f, false).zeroday("melon"));
        zerodayisaminecraftcheat(361, "pumpkin_seeds", new ItemSeeds(Blocks.bd, Blocks.ac).zeroday("seeds_pumpkin"));
        zerodayisaminecraftcheat(362, "melon_seeds", new ItemSeeds(Blocks.be, Blocks.ac).zeroday("seeds_melon"));
        zerodayisaminecraftcheat(363, "beef", new ItemFood(3, 0.3f, true).zeroday("beefRaw"));
        zerodayisaminecraftcheat(364, "cooked_beef", new ItemFood(8, 0.8f, true).zeroday("beefCooked"));
        zerodayisaminecraftcheat(365, "chicken", new ItemFood(2, 0.3f, true).zerodayisaminecraftcheat(Potion.k.z, 30, 0, 0.3f).zeroday("chickenRaw"));
        zerodayisaminecraftcheat(366, "cooked_chicken", new ItemFood(6, 0.6f, true).zeroday("chickenCooked"));
        zerodayisaminecraftcheat(367, "rotten_flesh", new ItemFood(4, 0.1f, true).zerodayisaminecraftcheat(Potion.k.z, 30, 0, 0.8f).zeroday("rottenFlesh"));
        zerodayisaminecraftcheat(368, "ender_pearl", new ItemEnderPearl().zeroday("enderPearl"));
        zerodayisaminecraftcheat(369, "blaze_rod", new Item().zeroday("blazeRod").zerodayisaminecraftcheat(CreativeTabs.d).zues());
        zerodayisaminecraftcheat(370, "ghast_tear", new Item().zeroday("ghastTear").sigma("+0-1-2-3&4-4+13").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(371, "gold_nugget", new Item().zeroday("goldNugget").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(372, "nether_wart", new ItemSeeds(Blocks.bt, Blocks.aO).zeroday("netherStalkSeeds").sigma("+4"));
        zerodayisaminecraftcheat(373, "potion", new ItemPotion().zeroday("potion"));
        zerodayisaminecraftcheat(374, "glass_bottle", new ItemGlassBottle().zeroday("glassBottle"));
        zerodayisaminecraftcheat(375, "spider_eye", new ItemFood(2, 0.8f, false).zerodayisaminecraftcheat(Potion.m.z, 5, 0, 1.0f).zeroday("spiderEye").sigma("-0-1+2-3&4-4+13"));
        zerodayisaminecraftcheat(376, "fermented_spider_eye", new Item().zeroday("fermentedSpiderEye").sigma("-0+3-4+13").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(377, "blaze_powder", new Item().zeroday("blazePowder").sigma("+0-1-2+3&4-4+13").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(378, "magma_cream", new Item().zeroday("magmaCream").sigma("+0+1-2-3&4-4+13").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(379, "brewing_stand", new ItemReed(Blocks.bv).zeroday("brewingStand").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(380, "cauldron", new ItemReed(Blocks.bw).zeroday("cauldron").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(381, "ender_eye", new ItemEnderEye().zeroday("eyeOfEnder"));
        zerodayisaminecraftcheat(382, "speckled_melon", new Item().zeroday("speckledMelon").sigma("+0-1+2-3&4-4+13").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(383, "spawn_egg", new ItemMonsterPlacer().zeroday("monsterPlacer"));
        zerodayisaminecraftcheat(384, "experience_bottle", new ItemExpBottle().zeroday("expBottle"));
        zerodayisaminecraftcheat(385, "fire_charge", new ItemFireball().zeroday("fireball"));
        zerodayisaminecraftcheat(386, "writable_book", new ItemWritableBook().zeroday("writingBook").zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(387, "written_book", new ItemEditableBook().zeroday("writtenBook").zeroday(16));
        zerodayisaminecraftcheat(388, "emerald", new Item().zeroday("emerald").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(389, "item_frame", new ItemHangingEntity(EntityItemFrame.class).zeroday("frame"));
        zerodayisaminecraftcheat(390, "flower_pot", new ItemReed(Blocks.bS).zeroday("flowerPot").zerodayisaminecraftcheat(CreativeTabs.sigma));
        zerodayisaminecraftcheat(391, "carrot", new ItemSeedFood(3, 0.6f, Blocks.bT, Blocks.ac).zeroday("carrots"));
        zerodayisaminecraftcheat(392, "potato", new ItemSeedFood(1, 0.3f, Blocks.bU, Blocks.ac).zeroday("potato"));
        zerodayisaminecraftcheat(393, "baked_potato", new ItemFood(5, 0.6f, false).zeroday("potatoBaked"));
        zerodayisaminecraftcheat(394, "poisonous_potato", new ItemFood(2, 0.3f, false).zerodayisaminecraftcheat(Potion.m.z, 5, 0, 0.6f).zeroday("potatoPoisonous"));
        zerodayisaminecraftcheat(395, "map", new ItemEmptyMap().zeroday("emptyMap"));
        zerodayisaminecraftcheat(396, "golden_carrot", new ItemFood(6, 1.2f, false).zeroday("carrotGolden").sigma("-0+1+2-3+13&4-4").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(397, "skull", new ItemSkull().zeroday("skull"));
        zerodayisaminecraftcheat(398, "carrot_on_a_stick", new ItemCarrotOnAStick().zeroday("carrotOnAStick"));
        zerodayisaminecraftcheat(399, "nether_star", new ItemSimpleFoiled().zeroday("netherStar").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(400, "pumpkin_pie", new ItemFood(8, 0.3f, false).zeroday("pumpkinPie").zerodayisaminecraftcheat(CreativeTabs.momgetthecamera));
        zerodayisaminecraftcheat(401, "fireworks", new ItemFirework().zeroday("fireworks"));
        zerodayisaminecraftcheat(402, "firework_charge", new ItemFireworkCharge().zeroday("fireworksCharge").zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(403, "enchanted_book", new ItemEnchantedBook().zeroday(1).zeroday("enchantedBook"));
        zerodayisaminecraftcheat(404, "comparator", new ItemReed(Blocks.cb).zeroday("comparator").zerodayisaminecraftcheat(CreativeTabs.pandora));
        zerodayisaminecraftcheat(405, "netherbrick", new Item().zeroday("netherbrick").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(406, "quartz", new Item().zeroday("netherquartz").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(407, "tnt_minecart", new ItemMinecart(EntityMinecart.zerodayisaminecraftcheat.pandora).zeroday("minecartTnt"));
        zerodayisaminecraftcheat(408, "hopper_minecart", new ItemMinecart(EntityMinecart.zerodayisaminecraftcheat.flux).zeroday("minecartHopper"));
        zerodayisaminecraftcheat(409, "prismarine_shard", new Item().zeroday("prismarineShard").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(410, "prismarine_crystals", new Item().zeroday("prismarineCrystals").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(411, "rabbit", new ItemFood(3, 0.3f, true).zeroday("rabbitRaw"));
        zerodayisaminecraftcheat(412, "cooked_rabbit", new ItemFood(5, 0.6f, true).zeroday("rabbitCooked"));
        zerodayisaminecraftcheat(413, "rabbit_stew", new ItemSoup(10).zeroday("rabbitStew"));
        zerodayisaminecraftcheat(414, "rabbit_foot", new Item().zeroday("rabbitFoot").sigma("+0+1-2+3&4-4+13").zerodayisaminecraftcheat(CreativeTabs.c));
        zerodayisaminecraftcheat(415, "rabbit_hide", new Item().zeroday("rabbitHide").zerodayisaminecraftcheat(CreativeTabs.d));
        zerodayisaminecraftcheat(416, "armor_stand", new ItemArmorStand().zeroday("armorStand").zeroday(16));
        zerodayisaminecraftcheat(417, "iron_horse_armor", new Item().zeroday("horsearmormetal").zeroday(1).zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(418, "golden_horse_armor", new Item().zeroday("horsearmorgold").zeroday(1).zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(419, "diamond_horse_armor", new Item().zeroday("horsearmordiamond").zeroday(1).zerodayisaminecraftcheat(CreativeTabs.flux));
        zerodayisaminecraftcheat(420, "lead", new ItemLead().zeroday("leash"));
        zerodayisaminecraftcheat(421, "name_tag", new ItemNameTag().zeroday("nameTag"));
        zerodayisaminecraftcheat(422, "command_block_minecart", new ItemMinecart(EntityMinecart.zerodayisaminecraftcheat.vape).zeroday("minecartCommandBlock").zerodayisaminecraftcheat((CreativeTabs)null));
        zerodayisaminecraftcheat(423, "mutton", new ItemFood(2, 0.3f, true).zeroday("muttonRaw"));
        zerodayisaminecraftcheat(424, "cooked_mutton", new ItemFood(6, 0.8f, true).zeroday("muttonCooked"));
        zerodayisaminecraftcheat(425, "banner", new ItemBanner().pandora("banner"));
        zerodayisaminecraftcheat(427, "spruce_door", new ItemDoor(Blocks.ah).zeroday("doorSpruce"));
        zerodayisaminecraftcheat(428, "birch_door", new ItemDoor(Blocks.ai).zeroday("doorBirch"));
        zerodayisaminecraftcheat(429, "jungle_door", new ItemDoor(Blocks.aj).zeroday("doorJungle"));
        zerodayisaminecraftcheat(430, "acacia_door", new ItemDoor(Blocks.ak).zeroday("doorAcacia"));
        zerodayisaminecraftcheat(431, "dark_oak_door", new ItemDoor(Blocks.al).zeroday("doorDarkOak"));
        zerodayisaminecraftcheat(2256, "record_13", new ItemRecord("13").zeroday("record"));
        zerodayisaminecraftcheat(2257, "record_cat", new ItemRecord("cat").zeroday("record"));
        zerodayisaminecraftcheat(2258, "record_blocks", new ItemRecord("blocks").zeroday("record"));
        zerodayisaminecraftcheat(2259, "record_chirp", new ItemRecord("chirp").zeroday("record"));
        zerodayisaminecraftcheat(2260, "record_far", new ItemRecord("far").zeroday("record"));
        zerodayisaminecraftcheat(2261, "record_mall", new ItemRecord("mall").zeroday("record"));
        zerodayisaminecraftcheat(2262, "record_mellohi", new ItemRecord("mellohi").zeroday("record"));
        zerodayisaminecraftcheat(2263, "record_stal", new ItemRecord("stal").zeroday("record"));
        zerodayisaminecraftcheat(2264, "record_strad", new ItemRecord("strad").zeroday("record"));
        zerodayisaminecraftcheat(2265, "record_ward", new ItemRecord("ward").zeroday("record"));
        zerodayisaminecraftcheat(2266, "record_11", new ItemRecord("11").zeroday("record"));
        zerodayisaminecraftcheat(2267, "record_wait", new ItemRecord("wait").zeroday("record"));
    }
    
    private static void sigma(final Block blockIn) {
        zerodayisaminecraftcheat(blockIn, new ItemBlock(blockIn));
    }
    
    protected static void zerodayisaminecraftcheat(final Block blockIn, final Item itemIn) {
        zerodayisaminecraftcheat(Block.zerodayisaminecraftcheat(blockIn), Block.zerodayisaminecraftcheat.zeroday(blockIn), itemIn);
        Item.vape.put(blockIn, itemIn);
    }
    
    private static void zerodayisaminecraftcheat(final int id, final String textualID, final Item itemIn) {
        zerodayisaminecraftcheat(id, new ResourceLocation(textualID), itemIn);
    }
    
    private static void zerodayisaminecraftcheat(final int id, final ResourceLocation textualID, final Item itemIn) {
        Item.zerodayisaminecraftcheat.zerodayisaminecraftcheat(id, textualID, itemIn);
    }
    
    public enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("WOOD", 0, 0, 59, 2.0f, 0.0f, 15), 
        zeroday("STONE", 1, 1, 131, 4.0f, 1.0f, 5), 
        sigma("IRON", 2, 2, 250, 6.0f, 2.0f, 14), 
        pandora("EMERALD", 3, 3, 1561, 8.0f, 3.0f, 10), 
        zues("GOLD", 4, 0, 32, 12.0f, 0.0f, 22);
        
        private final int flux;
        private final int vape;
        private final float momgetthecamera;
        private final float a;
        private final int b;
        
        static {
            c = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.pandora, zerodayisaminecraftcheat.zues };
        }
        
        private zerodayisaminecraftcheat(final String s, final int n, final int harvestLevel, final int maxUses, final float efficiency, final float damageVsEntity, final int enchantability) {
            this.flux = harvestLevel;
            this.vape = maxUses;
            this.momgetthecamera = efficiency;
            this.a = damageVsEntity;
            this.b = enchantability;
        }
        
        public int zerodayisaminecraftcheat() {
            return this.vape;
        }
        
        public float zeroday() {
            return this.momgetthecamera;
        }
        
        public float sigma() {
            return this.a;
        }
        
        public int pandora() {
            return this.flux;
        }
        
        public int zues() {
            return this.b;
        }
        
        public Item flux() {
            return (this == zerodayisaminecraftcheat.zerodayisaminecraftcheat) ? Item.zerodayisaminecraftcheat(Blocks.flux) : ((this == zerodayisaminecraftcheat.zeroday) ? Item.zerodayisaminecraftcheat(Blocks.zues) : ((this == zerodayisaminecraftcheat.zues) ? Items.c : ((this == zerodayisaminecraftcheat.sigma) ? Items.b : ((this == zerodayisaminecraftcheat.pandora) ? Items.a : null))));
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemAnvilBlock extends ItemMultiTexture
{
    public ItemAnvilBlock(final Block block) {
        super(block, block, new String[] { "intact", "slightlyDamaged", "veryDamaged" });
    }
    
    @Override
    public int sigma(final int damage) {
        return damage << 2;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import java.util.List;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.g.PotionEffect;
import net.minecraft.g.Potion;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;

public class ItemAppleGold extends ItemFood
{
    public ItemAppleGold(final int amount, final float saturation, final boolean isWolfFood) {
        super(amount, saturation, isWolfFood);
        this.zerodayisaminecraftcheat(true);
    }
    
    @Override
    public boolean momgetthecamera(final ItemStack stack) {
        return stack.momgetthecamera() > 0;
    }
    
    @Override
    public EnumRarity a(final ItemStack stack) {
        return (stack.momgetthecamera() == 0) ? EnumRarity.sigma : EnumRarity.pandora;
    }
    
    @Override
    protected void pandora(final ItemStack stack, final World worldIn, final EntityPlayer player) {
        if (!worldIn.r) {
            player.zerodayisaminecraftcheat(new PotionEffect(Potion.p.z, 2400, 0));
        }
        if (stack.momgetthecamera() > 0) {
            if (!worldIn.r) {
                player.zerodayisaminecraftcheat(new PotionEffect(Potion.d.z, 600, 4));
                player.zerodayisaminecraftcheat(new PotionEffect(Potion.e.z, 6000, 0));
                player.zerodayisaminecraftcheat(new PotionEffect(Potion.f.z, 6000, 0));
            }
        }
        else {
            super.pandora(stack, worldIn, player);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        subItems.add(new ItemStack(itemIn, 1, 0));
        subItems.add(new ItemStack(itemIn, 1, 1));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.a.Items;
import net.minecraft.q.World;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.pandora.CreativeTabs;
import java.util.List;
import net.minecraft.o.BlockPos;
import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.vape.EntityPlayer;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import net.minecraft.o.EntitySelectors;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.zerodayisaminecraftcheat.BlockDispenser;
import net.minecraft.zues.IBlockSource;
import net.minecraft.zues.BehaviorDefaultDispenseItem;
import net.minecraft.zues.IBehaviorDispenseItem;

public class ItemArmor extends Item
{
    private static final int[] c;
    public static final String[] vape;
    private static final IBehaviorDispenseItem d;
    public final int momgetthecamera;
    public final int a;
    public final int b;
    private final zerodayisaminecraftcheat e;
    
    static {
        c = new int[] { 11, 16, 15, 13 };
        vape = new String[] { "minecraft:items/empty_armor_slot_helmet", "minecraft:items/empty_armor_slot_chestplate", "minecraft:items/empty_armor_slot_leggings", "minecraft:items/empty_armor_slot_boots" };
        d = new BehaviorDefaultDispenseItem() {
            @Override
            protected ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(BlockDispenser.zues(source.flux()));
                final int i = blockpos.zerodayisaminecraftcheat();
                final int j = blockpos.zeroday();
                final int k = blockpos.sigma();
                final AxisAlignedBB axisalignedbb = new AxisAlignedBB(i, j, k, i + 1, j + 1, k + 1);
                final List<EntityLivingBase> list = source.zerodayisaminecraftcheat().zerodayisaminecraftcheat((Class<? extends EntityLivingBase>)EntityLivingBase.class, axisalignedbb, (com.google.common.base.Predicate<? super EntityLivingBase>)Predicates.and((Predicate)EntitySelectors.pandora, (Predicate)new EntitySelectors.zerodayisaminecraftcheat(stack)));
                if (list.size() > 0) {
                    final EntityLivingBase entitylivingbase = list.get(0);
                    final int l = (entitylivingbase instanceof EntityPlayer) ? 1 : 0;
                    final int i2 = EntityLiving.zeroday(stack);
                    final ItemStack itemstack = stack.b();
                    itemstack.zeroday = 1;
                    entitylivingbase.zerodayisaminecraftcheat(i2 - l, itemstack);
                    if (entitylivingbase instanceof EntityLiving) {
                        ((EntityLiving)entitylivingbase).zerodayisaminecraftcheat(i2, 2.0f);
                    }
                    --stack.zeroday;
                    return stack;
                }
                return super.zeroday(source, stack);
            }
        };
    }
    
    public ItemArmor(final zerodayisaminecraftcheat material, final int renderIndex, final int armorType) {
        this.e = material;
        this.momgetthecamera = armorType;
        this.b = renderIndex;
        this.a = material.zeroday(armorType);
        this.pandora(material.zerodayisaminecraftcheat(armorType));
        this.pandora = 1;
        this.zerodayisaminecraftcheat(CreativeTabs.b);
        BlockDispenser.F.zerodayisaminecraftcheat(this, ItemArmor.d);
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        if (renderPass > 0) {
            return 16777215;
        }
        int i = this.d(stack);
        if (i < 0) {
            i = 16777215;
        }
        return i;
    }
    
    @Override
    public int e() {
        return this.e.zerodayisaminecraftcheat();
    }
    
    public zerodayisaminecraftcheat j() {
        return this.e;
    }
    
    public boolean c(final ItemStack stack) {
        return this.e == zerodayisaminecraftcheat.zerodayisaminecraftcheat && stack.f() && stack.g().zeroday("display", 10) && stack.g().e("display").zeroday("color", 3);
    }
    
    public int d(final ItemStack stack) {
        if (this.e != zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            return -1;
        }
        final NBTTagCompound nbttagcompound = stack.g();
        if (nbttagcompound != null) {
            final NBTTagCompound nbttagcompound2 = nbttagcompound.e("display");
            if (nbttagcompound2 != null && nbttagcompound2.zeroday("color", 3)) {
                return nbttagcompound2.flux("color");
            }
        }
        return 10511680;
    }
    
    public void e(final ItemStack stack) {
        if (this.e == zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            final NBTTagCompound nbttagcompound = stack.g();
            if (nbttagcompound != null) {
                final NBTTagCompound nbttagcompound2 = nbttagcompound.e("display");
                if (nbttagcompound2.sigma("color")) {
                    nbttagcompound2.g("color");
                }
            }
        }
    }
    
    public void zeroday(final ItemStack stack, final int color) {
        if (this.e != zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            throw new UnsupportedOperationException("Can't dye non-leather!");
        }
        NBTTagCompound nbttagcompound = stack.g();
        if (nbttagcompound == null) {
            nbttagcompound = new NBTTagCompound();
            stack.pandora(nbttagcompound);
        }
        final NBTTagCompound nbttagcompound2 = nbttagcompound.e("display");
        if (!nbttagcompound.zeroday("display", 10)) {
            nbttagcompound.zerodayisaminecraftcheat("display", nbttagcompound2);
        }
        nbttagcompound2.zerodayisaminecraftcheat("color", color);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack toRepair, final ItemStack repair) {
        return this.e.zeroday() == repair.zerodayisaminecraftcheat() || super.zerodayisaminecraftcheat(toRepair, repair);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        final int i = EntityLiving.zeroday(itemStackIn) - 1;
        final ItemStack itemstack = playerIn.c(i);
        if (itemstack == null) {
            playerIn.zerodayisaminecraftcheat(i, itemStackIn.b());
            itemStackIn.zeroday = 0;
        }
        return itemStackIn;
    }
    
    public enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("LEATHER", 0, "leather", 5, new int[] { 1, 3, 2, 1 }, 15), 
        zeroday("CHAIN", 1, "chainmail", 15, new int[] { 2, 5, 4, 1 }, 12), 
        sigma("IRON", 2, "iron", 15, new int[] { 2, 6, 5, 2 }, 9), 
        pandora("GOLD", 3, "gold", 7, new int[] { 2, 5, 3, 1 }, 25), 
        zues("DIAMOND", 4, "diamond", 33, new int[] { 3, 8, 6, 3 }, 10);
        
        private final String flux;
        private final int vape;
        private final int[] momgetthecamera;
        private final int a;
        
        static {
            b = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.pandora, zerodayisaminecraftcheat.zues };
        }
        
        private zerodayisaminecraftcheat(final String s, final int n, final String name, final int maxDamage, final int[] reductionAmounts, final int enchantability) {
            this.flux = name;
            this.vape = maxDamage;
            this.momgetthecamera = reductionAmounts;
            this.a = enchantability;
        }
        
        public int zerodayisaminecraftcheat(final int armorType) {
            return ItemArmor.c[armorType] * this.vape;
        }
        
        public int zeroday(final int armorType) {
            return this.momgetthecamera[armorType];
        }
        
        public int zerodayisaminecraftcheat() {
            return this.a;
        }
        
        public Item zeroday() {
            return (this == zerodayisaminecraftcheat.zerodayisaminecraftcheat) ? Items.ax : ((this == zerodayisaminecraftcheat.zeroday) ? Items.b : ((this == zerodayisaminecraftcheat.pandora) ? Items.c : ((this == zerodayisaminecraftcheat.sigma) ? Items.b : ((this == zerodayisaminecraftcheat.zues) ? Items.a : null))));
        }
        
        public String sigma() {
            return this.flux;
        }
    }
}

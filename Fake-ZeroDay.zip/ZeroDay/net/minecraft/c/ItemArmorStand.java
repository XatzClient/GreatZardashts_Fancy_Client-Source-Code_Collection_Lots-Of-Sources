// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.Rotations;
import java.util.Random;
import java.util.List;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.pandora.EntityArmorStand;
import net.minecraft.vape.Entity;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemArmorStand extends Item
{
    public ItemArmorStand() {
        this.zerodayisaminecraftcheat(CreativeTabs.sigma);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side == EnumFacing.zerodayisaminecraftcheat) {
            return false;
        }
        final boolean flag = worldIn.zeroday(pos).sigma().zerodayisaminecraftcheat(worldIn, pos);
        final BlockPos blockpos = flag ? pos : pos.zerodayisaminecraftcheat(side);
        if (!playerIn.zerodayisaminecraftcheat(blockpos, side, stack)) {
            return false;
        }
        final BlockPos blockpos2 = blockpos.pandora();
        boolean flag2 = !worldIn.pandora(blockpos) && !worldIn.zeroday(blockpos).sigma().zerodayisaminecraftcheat(worldIn, blockpos);
        flag2 |= (!worldIn.pandora(blockpos2) && !worldIn.zeroday(blockpos2).sigma().zerodayisaminecraftcheat(worldIn, blockpos2));
        if (flag2) {
            return false;
        }
        final double d0 = blockpos.zerodayisaminecraftcheat();
        final double d2 = blockpos.zeroday();
        final double d3 = blockpos.sigma();
        final List<Entity> list = worldIn.zeroday(null, AxisAlignedBB.zerodayisaminecraftcheat(d0, d2, d3, d0 + 1.0, d2 + 2.0, d3 + 1.0));
        if (list.size() > 0) {
            return false;
        }
        if (!worldIn.r) {
            worldIn.momgetthecamera(blockpos);
            worldIn.momgetthecamera(blockpos2);
            final EntityArmorStand entityarmorstand = new EntityArmorStand(worldIn, d0 + 0.5, d2, d3 + 0.5);
            final float f = MathHelper.pandora((MathHelper.vape(playerIn.y - 180.0f) + 22.5f) / 45.0f) * 45.0f;
            entityarmorstand.zeroday(d0 + 0.5, d2, d3 + 0.5, f, 0.0f);
            this.zerodayisaminecraftcheat(entityarmorstand, worldIn.g);
            final NBTTagCompound nbttagcompound = stack.g();
            if (nbttagcompound != null && nbttagcompound.zeroday("EntityTag", 10)) {
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                entityarmorstand.pandora(nbttagcompound2);
                nbttagcompound2.zerodayisaminecraftcheat(nbttagcompound.e("EntityTag"));
                entityarmorstand.flux(nbttagcompound2);
            }
            worldIn.zerodayisaminecraftcheat(entityarmorstand);
        }
        --stack.zeroday;
        return true;
    }
    
    private void zerodayisaminecraftcheat(final EntityArmorStand armorStand, final Random rand) {
        Rotations rotations = armorStand.m();
        float f = rand.nextFloat() * 5.0f;
        final float f2 = rand.nextFloat() * 20.0f - 10.0f;
        Rotations rotations2 = new Rotations(rotations.zeroday() + f, rotations.sigma() + f2, rotations.pandora());
        armorStand.zerodayisaminecraftcheat(rotations2);
        rotations = armorStand.n();
        f = rand.nextFloat() * 10.0f - 5.0f;
        rotations2 = new Rotations(rotations.zeroday(), rotations.sigma() + f, rotations.pandora());
        armorStand.zeroday(rotations2);
    }
}

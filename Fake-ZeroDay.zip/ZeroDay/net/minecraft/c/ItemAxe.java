// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import com.google.common.collect.Sets;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Set;

public class ItemAxe extends ItemTool
{
    private static final Set<Block> a;
    
    static {
        a = Sets.newHashSet((Object[])new Block[] { Blocks.flux, Blocks.P, Blocks.j, Blocks.k, Blocks.W, Blocks.aM, Blocks.aR, Blocks.bc, Blocks.am });
    }
    
    protected ItemAxe(final zerodayisaminecraftcheat material) {
        super(3.0f, material, ItemAxe.a);
    }
    
    @Override
    public float zerodayisaminecraftcheat(final ItemStack stack, final Block block) {
        return (block.flux() != Material.pandora && block.flux() != Material.c && block.flux() != Material.d) ? super.zerodayisaminecraftcheat(stack, block) : this.vape;
    }
}

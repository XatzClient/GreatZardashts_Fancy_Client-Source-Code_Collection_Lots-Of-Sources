// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagList;
import net.minecraft.d.NBTTagCompound;
import java.util.List;
import net.minecraft.o.StatCollector;
import net.minecraft.n.TileEntity;
import net.minecraft.n.TileEntityBanner;
import net.minecraft.zerodayisaminecraftcheat.BlockWallSign;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockStandingSign;
import net.minecraft.o.MathHelper;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.a.Blocks;

public class ItemBanner extends ItemBlock
{
    public ItemBanner() {
        super(Blocks.cC);
        this.pandora = 16;
        this.zerodayisaminecraftcheat(CreativeTabs.sigma);
        this.zerodayisaminecraftcheat(true);
        this.pandora(0);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side == EnumFacing.zerodayisaminecraftcheat) {
            return false;
        }
        if (!worldIn.zeroday(pos).sigma().flux().zeroday()) {
            return false;
        }
        pos = pos.zerodayisaminecraftcheat(side);
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (!Blocks.cC.pandora(worldIn, pos)) {
            return false;
        }
        if (worldIn.r) {
            return true;
        }
        if (side == EnumFacing.zeroday) {
            final int i = MathHelper.sigma((playerIn.y + 180.0f) * 16.0f / 360.0f + 0.5) & 0xF;
            worldIn.zerodayisaminecraftcheat(pos, Blocks.cC.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockStandingSign.D, i), 3);
        }
        else {
            worldIn.zerodayisaminecraftcheat(pos, Blocks.cD.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockWallSign.D, side), 3);
        }
        --stack.zeroday;
        final TileEntity tileentity = worldIn.zerodayisaminecraftcheat(pos);
        if (tileentity instanceof TileEntityBanner) {
            ((TileEntityBanner)tileentity).zerodayisaminecraftcheat(stack);
        }
        return true;
    }
    
    @Override
    public String vape(final ItemStack stack) {
        String s = "item.banner.";
        final EnumDyeColor enumdyecolor = this.c(stack);
        s = String.valueOf(s) + enumdyecolor.pandora() + ".name";
        return StatCollector.zerodayisaminecraftcheat(s);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        final NBTTagCompound nbttagcompound = stack.zerodayisaminecraftcheat("BlockEntityTag", false);
        if (nbttagcompound != null && nbttagcompound.sigma("Patterns")) {
            final NBTTagList nbttaglist = nbttagcompound.sigma("Patterns", 10);
            for (int i = 0; i < nbttaglist.zues() && i < 6; ++i) {
                final NBTTagCompound nbttagcompound2 = nbttaglist.zeroday(i);
                final EnumDyeColor enumdyecolor = EnumDyeColor.zerodayisaminecraftcheat(nbttagcompound2.flux("Color"));
                final TileEntityBanner.zerodayisaminecraftcheat tileentitybanner$enumbannerpattern = TileEntityBanner.zerodayisaminecraftcheat.zerodayisaminecraftcheat(nbttagcompound2.b("Pattern"));
                if (tileentitybanner$enumbannerpattern != null) {
                    tooltip.add(StatCollector.zerodayisaminecraftcheat("item.banner." + tileentitybanner$enumbannerpattern.zerodayisaminecraftcheat() + "." + enumdyecolor.pandora()));
                }
            }
        }
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        if (renderPass == 0) {
            return 16777215;
        }
        final EnumDyeColor enumdyecolor = this.c(stack);
        return enumdyecolor.zues().D;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        EnumDyeColor[] values;
        for (int length = (values = EnumDyeColor.values()).length, i = 0; i < length; ++i) {
            final EnumDyeColor enumdyecolor = values[i];
            final NBTTagCompound nbttagcompound = new NBTTagCompound();
            TileEntityBanner.zerodayisaminecraftcheat(nbttagcompound, enumdyecolor.sigma(), null);
            final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
            nbttagcompound2.zerodayisaminecraftcheat("BlockEntityTag", nbttagcompound);
            final ItemStack itemstack = new ItemStack(itemIn, 1, enumdyecolor.sigma());
            itemstack.pandora(nbttagcompound2);
            subItems.add(itemstack);
        }
    }
    
    @Override
    public CreativeTabs f() {
        return CreativeTabs.sigma;
    }
    
    private EnumDyeColor c(final ItemStack stack) {
        final NBTTagCompound nbttagcompound = stack.zerodayisaminecraftcheat("BlockEntityTag", false);
        EnumDyeColor enumdyecolor = null;
        if (nbttagcompound != null && nbttagcompound.sigma("Base")) {
            enumdyecolor = EnumDyeColor.zerodayisaminecraftcheat(nbttagcompound.flux("Base"));
        }
        else {
            enumdyecolor = EnumDyeColor.zerodayisaminecraftcheat(stack.momgetthecamera());
        }
        return enumdyecolor;
    }
}

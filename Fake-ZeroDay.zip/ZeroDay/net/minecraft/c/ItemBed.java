// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockBed;
import net.minecraft.a.Blocks;
import net.minecraft.q.IBlockAccess;
import net.minecraft.o.MathHelper;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemBed extends Item
{
    public ItemBed() {
        this.zerodayisaminecraftcheat(CreativeTabs.sigma);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (worldIn.r) {
            return true;
        }
        if (side != EnumFacing.zeroday) {
            return false;
        }
        final IBlockState iblockstate = worldIn.zeroday(pos);
        final Block block = iblockstate.sigma();
        final boolean flag = block.zerodayisaminecraftcheat(worldIn, pos);
        if (!flag) {
            pos = pos.pandora();
        }
        final int i = MathHelper.sigma(playerIn.y * 4.0f / 360.0f + 0.5) & 0x3;
        final EnumFacing enumfacing = EnumFacing.zeroday(i);
        final BlockPos blockpos = pos.zerodayisaminecraftcheat(enumfacing);
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack) || !playerIn.zerodayisaminecraftcheat(blockpos, side, stack)) {
            return false;
        }
        final boolean flag2 = worldIn.zeroday(blockpos).sigma().zerodayisaminecraftcheat(worldIn, blockpos);
        final boolean flag3 = flag || worldIn.pandora(pos);
        final boolean flag4 = flag2 || worldIn.pandora(blockpos);
        if (flag3 && flag4 && World.zerodayisaminecraftcheat(worldIn, pos.zues()) && World.zerodayisaminecraftcheat(worldIn, blockpos.zues())) {
            final IBlockState iblockstate2 = Blocks.u.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockBed.E, false).zerodayisaminecraftcheat((IProperty<Comparable>)BlockBed.F, enumfacing).zerodayisaminecraftcheat(BlockBed.D, BlockBed.zerodayisaminecraftcheat.zeroday);
            if (worldIn.zerodayisaminecraftcheat(pos, iblockstate2, 3)) {
                final IBlockState iblockstate3 = iblockstate2.zerodayisaminecraftcheat(BlockBed.D, BlockBed.zerodayisaminecraftcheat.zerodayisaminecraftcheat);
                worldIn.zerodayisaminecraftcheat(blockpos, iblockstate3, 3);
            }
            --stack.zeroday;
            return true;
        }
        return false;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import java.util.List;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.a.Blocks;
import net.minecraft.n.TileEntity;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.k.MinecraftServer;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemBlock extends Item
{
    protected final Block vape;
    
    public ItemBlock(final Block block) {
        this.vape = block;
    }
    
    public ItemBlock pandora(final String unlocalizedName) {
        super.zeroday(unlocalizedName);
        return this;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final IBlockState iblockstate = worldIn.zeroday(pos);
        final Block block = iblockstate.sigma();
        if (!block.zerodayisaminecraftcheat(worldIn, pos)) {
            pos = pos.zerodayisaminecraftcheat(side);
        }
        if (stack.zeroday == 0) {
            return false;
        }
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (worldIn.zerodayisaminecraftcheat(this.vape, pos, false, side, null, stack)) {
            final int i = this.sigma(stack.momgetthecamera());
            IBlockState iblockstate2 = this.vape.zerodayisaminecraftcheat(worldIn, pos, side, hitX, hitY, hitZ, i, playerIn);
            if (worldIn.zerodayisaminecraftcheat(pos, iblockstate2, 3)) {
                iblockstate2 = worldIn.zeroday(pos);
                if (iblockstate2.sigma() == this.vape) {
                    zerodayisaminecraftcheat(worldIn, playerIn, pos, stack);
                    this.vape.zerodayisaminecraftcheat(worldIn, pos, iblockstate2, playerIn, stack);
                }
                worldIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() + 0.5f, pos.zeroday() + 0.5f, pos.sigma() + 0.5f, this.vape.x.zeroday(), (this.vape.x.pandora() + 1.0f) / 2.0f, this.vape.x.zues() * 0.8f);
                --stack.zeroday;
            }
            return true;
        }
        return false;
    }
    
    public static boolean zerodayisaminecraftcheat(final World worldIn, final EntityPlayer pos, final BlockPos stack, final ItemStack p_179224_3_) {
        final MinecraftServer minecraftserver = MinecraftServer.E();
        if (minecraftserver == null) {
            return false;
        }
        if (p_179224_3_.f() && p_179224_3_.g().zeroday("BlockEntityTag", 10)) {
            final TileEntity tileentity = worldIn.zerodayisaminecraftcheat(stack);
            if (tileentity != null) {
                if (!worldIn.r && tileentity.k() && !minecraftserver.ae().zues(pos.ba())) {
                    return false;
                }
                final NBTTagCompound nbttagcompound = new NBTTagCompound();
                final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttagcompound.zeroday();
                tileentity.zeroday(nbttagcompound);
                final NBTTagCompound nbttagcompound3 = (NBTTagCompound)p_179224_3_.g().zerodayisaminecraftcheat("BlockEntityTag");
                nbttagcompound.zerodayisaminecraftcheat(nbttagcompound3);
                nbttagcompound.zerodayisaminecraftcheat("x", stack.zerodayisaminecraftcheat());
                nbttagcompound.zerodayisaminecraftcheat("y", stack.zeroday());
                nbttagcompound.zerodayisaminecraftcheat("z", stack.sigma());
                if (!nbttagcompound.equals(nbttagcompound2)) {
                    tileentity.zerodayisaminecraftcheat(nbttagcompound);
                    tileentity.t();
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean zerodayisaminecraftcheat(final World worldIn, BlockPos pos, EnumFacing side, final EntityPlayer player, final ItemStack stack) {
        final Block block = worldIn.zeroday(pos).sigma();
        if (block == Blocks.az) {
            side = EnumFacing.zeroday;
        }
        else if (!block.zerodayisaminecraftcheat(worldIn, pos)) {
            pos = pos.zerodayisaminecraftcheat(side);
        }
        return worldIn.zerodayisaminecraftcheat(this.vape, pos, false, side, null, stack);
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        return this.vape.v();
    }
    
    @Override
    public String momgetthecamera() {
        return this.vape.v();
    }
    
    @Override
    public CreativeTabs f() {
        return this.vape.A();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        this.vape.zerodayisaminecraftcheat(itemIn, tab, subItems);
    }
    
    public Block j() {
        return this.vape;
    }
}

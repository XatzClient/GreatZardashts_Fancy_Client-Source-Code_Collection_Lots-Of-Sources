// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.BlockPos;
import net.minecraft.o.AxisAlignedBB;
import java.util.List;
import net.minecraft.m.StatList;
import net.minecraft.vape.pandora.EntityBoat;
import net.minecraft.a.Blocks;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import net.minecraft.o.Vec3;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemBoat extends Item
{
    public ItemBoat() {
        this.pandora = 1;
        this.zerodayisaminecraftcheat(CreativeTabs.zues);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        final float f = 1.0f;
        final float f2 = playerIn.B + (playerIn.z - playerIn.B) * f;
        final float f3 = playerIn.A + (playerIn.y - playerIn.A) * f;
        final double d0 = playerIn.p + (playerIn.s - playerIn.p) * f;
        final double d2 = playerIn.q + (playerIn.t - playerIn.q) * f + playerIn.aI();
        final double d3 = playerIn.r + (playerIn.u - playerIn.r) * f;
        final Vec3 vec3 = new Vec3(d0, d2, d3);
        final float f4 = MathHelper.zeroday(-f3 * 0.017453292f - 3.1415927f);
        final float f5 = MathHelper.zerodayisaminecraftcheat(-f3 * 0.017453292f - 3.1415927f);
        final float f6 = -MathHelper.zeroday(-f2 * 0.017453292f);
        final float f7 = MathHelper.zerodayisaminecraftcheat(-f2 * 0.017453292f);
        final float f8 = f5 * f6;
        final float f9 = f4 * f6;
        final double d4 = 5.0;
        final Vec3 vec4 = vec3.zeroday(f8 * d4, f7 * d4, f9 * d4);
        final MovingObjectPosition movingobjectposition = worldIn.zerodayisaminecraftcheat(vec3, vec4, true);
        if (movingobjectposition == null) {
            return itemStackIn;
        }
        final Vec3 vec5 = playerIn.flux(f);
        boolean flag = false;
        final float f10 = 1.0f;
        final List<Entity> list = worldIn.zeroday(playerIn, playerIn.aH().zerodayisaminecraftcheat(vec5.zerodayisaminecraftcheat * d4, vec5.zeroday * d4, vec5.sigma * d4).zeroday(f10, f10, f10));
        for (int i = 0; i < list.size(); ++i) {
            final Entity entity = list.get(i);
            if (entity.Y()) {
                final float f11 = entity.ah();
                final AxisAlignedBB axisalignedbb = entity.aH().zeroday(f11, f11, f11);
                if (axisalignedbb.zerodayisaminecraftcheat(vec3)) {
                    flag = true;
                }
            }
        }
        if (flag) {
            return itemStackIn;
        }
        if (movingobjectposition.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
            BlockPos blockpos = movingobjectposition.zerodayisaminecraftcheat();
            if (worldIn.zeroday(blockpos).sigma() == Blocks.az) {
                blockpos = blockpos.zues();
            }
            final EntityBoat entityboat = new EntityBoat(worldIn, blockpos.zerodayisaminecraftcheat() + 0.5f, blockpos.zeroday() + 1.0f, blockpos.sigma() + 0.5f);
            entityboat.y = (float)(((MathHelper.sigma(playerIn.y * 4.0f / 360.0f + 0.5) & 0x3) - 1) * 90);
            if (!worldIn.zerodayisaminecraftcheat(entityboat, entityboat.aH().zeroday(-0.1, -0.1, -0.1)).isEmpty()) {
                return itemStackIn;
            }
            if (!worldIn.r) {
                worldIn.zerodayisaminecraftcheat(entityboat);
            }
            if (!playerIn.bz.pandora) {
                --itemStackIn.zeroday;
            }
            playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        }
        return itemStackIn;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

public class ItemBook extends Item
{
    @Override
    public boolean b(final ItemStack stack) {
        return stack.zeroday == 1;
    }
    
    @Override
    public int e() {
        return 1;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.m.StatList;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.momgetthecamera.EntityArrow;
import net.minecraft.a.Items;
import net.minecraft.flux.EnchantmentHelper;
import net.minecraft.flux.Enchantment;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemBow extends Item
{
    public static final String[] vape;
    
    static {
        vape = new String[] { "pulling_0", "pulling_1", "pulling_2" };
    }
    
    public ItemBow() {
        this.pandora = 1;
        this.pandora(384);
        this.zerodayisaminecraftcheat(CreativeTabs.b);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final EntityPlayer playerIn, final int timeLeft) {
        final boolean flag = playerIn.bz.pandora || EnchantmentHelper.zerodayisaminecraftcheat(Enchantment.p.s, stack) > 0;
        if (flag || playerIn.d.zeroday(Items.vape)) {
            final int i = this.pandora(stack) - timeLeft;
            float f = i / 20.0f;
            f = (f * f + f * 2.0f) / 3.0f;
            if (f < 0.1) {
                return;
            }
            if (f > 1.0f) {
                f = 1.0f;
            }
            final EntityArrow entityarrow = new EntityArrow(worldIn, playerIn, f * 2.0f);
            if (f == 1.0f) {
                entityarrow.zerodayisaminecraftcheat(true);
            }
            final int j = EnchantmentHelper.zerodayisaminecraftcheat(Enchantment.m.s, stack);
            if (j > 0) {
                entityarrow.zeroday(entityarrow.vape() + j * 0.5 + 0.5);
            }
            final int k = EnchantmentHelper.zerodayisaminecraftcheat(Enchantment.n.s, stack);
            if (k > 0) {
                entityarrow.zerodayisaminecraftcheat(k);
            }
            if (EnchantmentHelper.zerodayisaminecraftcheat(Enchantment.o.s, stack) > 0) {
                entityarrow.zues(100);
            }
            stack.zerodayisaminecraftcheat(1, playerIn);
            worldIn.zerodayisaminecraftcheat((Entity)playerIn, "random.bow", 1.0f, 1.0f / (ItemBow.sigma.nextFloat() * 0.4f + 1.2f) + f * 0.5f);
            if (flag) {
                entityarrow.zerodayisaminecraftcheat = 2;
            }
            else {
                playerIn.d.zerodayisaminecraftcheat(Items.vape);
            }
            playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
            if (!worldIn.r) {
                worldIn.zerodayisaminecraftcheat(entityarrow);
            }
        }
    }
    
    @Override
    public ItemStack zeroday(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
        return stack;
    }
    
    @Override
    public int pandora(final ItemStack stack) {
        return 72000;
    }
    
    @Override
    public EnumAction sigma(final ItemStack stack) {
        return EnumAction.zues;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (playerIn.bz.pandora || playerIn.d.zeroday(Items.vape)) {
            playerIn.zeroday(itemStackIn, this.pandora(itemStackIn));
        }
        return itemStackIn;
    }
    
    @Override
    public int e() {
        return 1;
    }
}

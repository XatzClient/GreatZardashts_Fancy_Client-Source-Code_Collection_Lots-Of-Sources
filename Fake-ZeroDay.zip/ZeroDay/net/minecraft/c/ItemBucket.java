// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.EnumParticleTypes;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.o.BlockPos;
import net.minecraft.a.Items;
import net.minecraft.m.StatList;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockLiquid;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.a.Blocks;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemBucket extends Item
{
    private Block vape;
    
    public ItemBucket(final Block containedBlock) {
        this.pandora = 1;
        this.vape = containedBlock;
        this.zerodayisaminecraftcheat(CreativeTabs.flux);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        final boolean flag = this.vape == Blocks.zerodayisaminecraftcheat;
        final MovingObjectPosition movingobjectposition = this.zerodayisaminecraftcheat(worldIn, playerIn, flag);
        if (movingobjectposition == null) {
            return itemStackIn;
        }
        if (movingobjectposition.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
            final BlockPos blockpos = movingobjectposition.zerodayisaminecraftcheat();
            if (!worldIn.zerodayisaminecraftcheat(playerIn, blockpos)) {
                return itemStackIn;
            }
            if (flag) {
                if (!playerIn.zerodayisaminecraftcheat(blockpos.zerodayisaminecraftcheat(movingobjectposition.zeroday), movingobjectposition.zeroday, itemStackIn)) {
                    return itemStackIn;
                }
                final IBlockState iblockstate = worldIn.zeroday(blockpos);
                final Material material = iblockstate.sigma().flux();
                if (material == Material.momgetthecamera && iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockLiquid.E) == 0) {
                    worldIn.momgetthecamera(blockpos);
                    playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
                    return this.zerodayisaminecraftcheat(itemStackIn, playerIn, Items.ap);
                }
                if (material == Material.a && iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockLiquid.E) == 0) {
                    worldIn.momgetthecamera(blockpos);
                    playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
                    return this.zerodayisaminecraftcheat(itemStackIn, playerIn, Items.aq);
                }
            }
            else {
                if (this.vape == Blocks.zerodayisaminecraftcheat) {
                    return new ItemStack(Items.ao);
                }
                final BlockPos blockpos2 = blockpos.zerodayisaminecraftcheat(movingobjectposition.zeroday);
                if (!playerIn.zerodayisaminecraftcheat(blockpos2, movingobjectposition.zeroday, itemStackIn)) {
                    return itemStackIn;
                }
                if (this.zerodayisaminecraftcheat(worldIn, blockpos2) && !playerIn.bz.pandora) {
                    playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
                    return new ItemStack(Items.ao);
                }
            }
        }
        return itemStackIn;
    }
    
    private ItemStack zerodayisaminecraftcheat(final ItemStack emptyBuckets, final EntityPlayer player, final Item fullBucket) {
        if (player.bz.pandora) {
            return emptyBuckets;
        }
        if (--emptyBuckets.zeroday <= 0) {
            return new ItemStack(fullBucket);
        }
        if (!player.d.zerodayisaminecraftcheat(new ItemStack(fullBucket))) {
            player.zerodayisaminecraftcheat(new ItemStack(fullBucket, 1, 0), false);
        }
        return emptyBuckets;
    }
    
    public boolean zerodayisaminecraftcheat(final World worldIn, final BlockPos pos) {
        if (this.vape == Blocks.zerodayisaminecraftcheat) {
            return false;
        }
        final Material material = worldIn.zeroday(pos).sigma().flux();
        final boolean flag = !material.zeroday();
        if (!worldIn.pandora(pos) && !flag) {
            return false;
        }
        if (worldIn.h.f() && this.vape == Blocks.a) {
            final int i = pos.zerodayisaminecraftcheat();
            final int j = pos.zeroday();
            final int k = pos.sigma();
            worldIn.zerodayisaminecraftcheat(i + 0.5f, j + 0.5f, k + 0.5f, "random.fizz", 0.5f, 2.6f + (worldIn.g.nextFloat() - worldIn.g.nextFloat()) * 0.8f);
            for (int l = 0; l < 8; ++l) {
                worldIn.zerodayisaminecraftcheat(EnumParticleTypes.e, i + Math.random(), j + Math.random(), k + Math.random(), 0.0, 0.0, 0.0, new int[0]);
            }
        }
        else {
            if (!worldIn.r && flag && !material.zerodayisaminecraftcheat()) {
                worldIn.zeroday(pos, true);
            }
            worldIn.zerodayisaminecraftcheat(pos, this.vape.G(), 3);
        }
        return true;
    }
}

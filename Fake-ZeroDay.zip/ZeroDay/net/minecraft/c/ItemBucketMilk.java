// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.a.Items;
import net.minecraft.m.StatList;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemBucketMilk extends Item
{
    public ItemBucketMilk() {
        this.zeroday(1);
        this.zerodayisaminecraftcheat(CreativeTabs.flux);
    }
    
    @Override
    public ItemStack zeroday(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
        if (!playerIn.bz.pandora) {
            --stack.zeroday;
        }
        if (!worldIn.r) {
            playerIn.bv();
        }
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        return (stack.zeroday <= 0) ? new ItemStack(Items.ao) : stack;
    }
    
    @Override
    public int pandora(final ItemStack stack) {
        return 32;
    }
    
    @Override
    public EnumAction sigma(final ItemStack stack) {
        return EnumAction.sigma;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        playerIn.zeroday(itemStackIn, this.pandora(itemStackIn));
        return itemStackIn;
    }
}

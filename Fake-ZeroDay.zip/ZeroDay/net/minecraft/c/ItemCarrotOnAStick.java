// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.m.StatList;
import net.minecraft.a.Items;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.flux.EntityPig;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemCarrotOnAStick extends Item
{
    public ItemCarrotOnAStick() {
        this.zerodayisaminecraftcheat(CreativeTabs.zues);
        this.zeroday(1);
        this.pandora(25);
    }
    
    @Override
    public boolean flux() {
        return true;
    }
    
    @Override
    public boolean vape() {
        return true;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (playerIn.an() && playerIn.m instanceof EntityPig) {
            final EntityPig entitypig = (EntityPig)playerIn.m;
            if (entitypig.ce().b() && itemStackIn.a() - itemStackIn.momgetthecamera() >= 7) {
                entitypig.ce().a();
                itemStackIn.zerodayisaminecraftcheat(7, playerIn);
                if (itemStackIn.zeroday == 0) {
                    final ItemStack itemstack = new ItemStack(Items.aJ);
                    itemstack.pandora(itemStackIn.g());
                    return itemstack;
                }
            }
        }
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        return itemStackIn;
    }
}

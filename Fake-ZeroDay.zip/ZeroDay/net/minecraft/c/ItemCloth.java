// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemCloth extends ItemBlock
{
    public ItemCloth(final Block block) {
        super(block);
        this.pandora(0);
        this.zerodayisaminecraftcheat(true);
    }
    
    @Override
    public int sigma(final int damage) {
        return damage;
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        return String.valueOf(super.momgetthecamera()) + "." + EnumDyeColor.zeroday(stack.momgetthecamera()).pandora();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import java.util.List;
import net.minecraft.pandora.CreativeTabs;

public class ItemCoal extends Item
{
    public ItemCoal() {
        this.zerodayisaminecraftcheat(true);
        this.pandora(0);
        this.zerodayisaminecraftcheat(CreativeTabs.d);
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        return (stack.momgetthecamera() == 1) ? "item.charcoal" : "item.coal";
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        subItems.add(new ItemStack(itemIn, 1, 0));
        subItems.add(new ItemStack(itemIn, 1, 1));
    }
}

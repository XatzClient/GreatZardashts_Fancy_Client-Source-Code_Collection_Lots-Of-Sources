// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemColored extends ItemBlock
{
    private final Block momgetthecamera;
    private String[] a;
    
    public ItemColored(final Block block, final boolean hasSubtypes) {
        super(block);
        this.momgetthecamera = block;
        if (hasSubtypes) {
            this.pandora(0);
            this.zerodayisaminecraftcheat(true);
        }
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        return this.momgetthecamera.zues(this.momgetthecamera.sigma(stack.momgetthecamera()));
    }
    
    @Override
    public int sigma(final int damage) {
        return damage;
    }
    
    public ItemColored zerodayisaminecraftcheat(final String[] names) {
        this.a = names;
        return this;
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        if (this.a == null) {
            return super.zeroday(stack);
        }
        final int i = stack.momgetthecamera();
        return (i >= 0 && i < this.a.length) ? (String.valueOf(super.zeroday(stack)) + "." + this.a[i]) : super.zeroday(stack);
    }
}

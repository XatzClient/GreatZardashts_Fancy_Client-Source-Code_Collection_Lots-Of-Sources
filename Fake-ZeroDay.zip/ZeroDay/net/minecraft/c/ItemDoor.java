// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockDoor;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemDoor extends Item
{
    private Block vape;
    
    public ItemDoor(final Block block) {
        this.vape = block;
        this.zerodayisaminecraftcheat(CreativeTabs.pandora);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side != EnumFacing.zeroday) {
            return false;
        }
        final IBlockState iblockstate = worldIn.zeroday(pos);
        final Block block = iblockstate.sigma();
        if (!block.zerodayisaminecraftcheat(worldIn, pos)) {
            pos = pos.zerodayisaminecraftcheat(side);
        }
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (!this.vape.pandora(worldIn, pos)) {
            return false;
        }
        zerodayisaminecraftcheat(worldIn, pos, EnumFacing.zerodayisaminecraftcheat(playerIn.y), this.vape);
        --stack.zeroday;
        return true;
    }
    
    public static void zerodayisaminecraftcheat(final World worldIn, final BlockPos pos, final EnumFacing facing, final Block door) {
        final BlockPos blockpos = pos.zerodayisaminecraftcheat(facing.flux());
        final BlockPos blockpos2 = pos.zerodayisaminecraftcheat(facing.vape());
        final int i = (worldIn.zeroday(blockpos2).sigma().momgetthecamera() + worldIn.zeroday(blockpos2.pandora()).sigma().momgetthecamera()) ? 1 : 0;
        final int j = (worldIn.zeroday(blockpos).sigma().momgetthecamera() + worldIn.zeroday(blockpos.pandora()).sigma().momgetthecamera()) ? 1 : 0;
        final boolean flag = worldIn.zeroday(blockpos2).sigma() == door || worldIn.zeroday(blockpos2.pandora()).sigma() == door;
        final boolean flag2 = worldIn.zeroday(blockpos).sigma() == door || worldIn.zeroday(blockpos.pandora()).sigma() == door;
        boolean flag3 = false;
        if ((flag && !flag2) || j > i) {
            flag3 = true;
        }
        final BlockPos blockpos3 = pos.pandora();
        final IBlockState iblockstate = door.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockDoor.D, facing).zerodayisaminecraftcheat(BlockDoor.F, flag3 ? BlockDoor.zeroday.zeroday : BlockDoor.zeroday.zerodayisaminecraftcheat);
        worldIn.zerodayisaminecraftcheat(pos, iblockstate.zerodayisaminecraftcheat(BlockDoor.H, BlockDoor.zerodayisaminecraftcheat.zeroday), 2);
        worldIn.zerodayisaminecraftcheat(blockpos3, iblockstate.zerodayisaminecraftcheat(BlockDoor.H, BlockDoor.zerodayisaminecraftcheat.zerodayisaminecraftcheat), 2);
        worldIn.zeroday(pos, door);
        worldIn.zeroday(blockpos3, door);
    }
}

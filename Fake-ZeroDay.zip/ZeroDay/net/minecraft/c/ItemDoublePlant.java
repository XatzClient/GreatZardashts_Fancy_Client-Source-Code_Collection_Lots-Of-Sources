// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.q.ColorizerGrass;
import net.minecraft.zerodayisaminecraftcheat.BlockDoublePlant;
import com.google.common.base.Function;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemDoublePlant extends ItemMultiTexture
{
    public ItemDoublePlant(final Block block, final Block block2, final Function<ItemStack, String> nameFunction) {
        super(block, block2, nameFunction);
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        final BlockDoublePlant.zeroday blockdoubleplant$enumplanttype = BlockDoublePlant.zeroday.zerodayisaminecraftcheat(stack.momgetthecamera());
        return (blockdoubleplant$enumplanttype != BlockDoublePlant.zeroday.sigma && blockdoubleplant$enumplanttype != BlockDoublePlant.zeroday.pandora) ? super.zerodayisaminecraftcheat(stack, renderPass) : ColorizerGrass.zerodayisaminecraftcheat(0.5, 1.0);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import java.util.List;
import net.minecraft.vape.flux.EntitySheep;
import net.minecraft.o.EnumParticleTypes;
import net.minecraft.q.IBlockAccess;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.zerodayisaminecraftcheat.IGrowable;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockPlanks;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemDye extends Item
{
    public static final int[] vape;
    
    static {
        vape = new int[] { 1973019, 11743532, 3887386, 5320730, 2437522, 8073150, 2651799, 11250603, 4408131, 14188952, 4312372, 14602026, 6719955, 12801229, 15435844, 15790320 };
    }
    
    public ItemDye() {
        this.zerodayisaminecraftcheat(true);
        this.pandora(0);
        this.zerodayisaminecraftcheat(CreativeTabs.d);
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        final int i = stack.momgetthecamera();
        return String.valueOf(super.momgetthecamera()) + "." + EnumDyeColor.zerodayisaminecraftcheat(i).pandora();
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (!playerIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(side), side, stack)) {
            return false;
        }
        final EnumDyeColor enumdyecolor = EnumDyeColor.zerodayisaminecraftcheat(stack.momgetthecamera());
        if (enumdyecolor == EnumDyeColor.zerodayisaminecraftcheat) {
            if (zerodayisaminecraftcheat(stack, worldIn, pos)) {
                if (!worldIn.r) {
                    worldIn.zeroday(2005, pos, 0);
                }
                return true;
            }
        }
        else if (enumdyecolor == EnumDyeColor.e) {
            final IBlockState iblockstate = worldIn.zeroday(pos);
            final Block block = iblockstate.sigma();
            if (block == Blocks.j && iblockstate.zerodayisaminecraftcheat(BlockPlanks.D) == BlockPlanks.zerodayisaminecraftcheat.pandora) {
                if (side == EnumFacing.zerodayisaminecraftcheat) {
                    return false;
                }
                if (side == EnumFacing.zeroday) {
                    return false;
                }
                pos = pos.zerodayisaminecraftcheat(side);
                if (worldIn.pandora(pos)) {
                    final IBlockState iblockstate2 = Blocks.bF.zerodayisaminecraftcheat(worldIn, pos, side, hitX, hitY, hitZ, 0, playerIn);
                    worldIn.zerodayisaminecraftcheat(pos, iblockstate2, 2);
                    if (!playerIn.bz.pandora) {
                        --stack.zeroday;
                    }
                }
                return true;
            }
        }
        return false;
    }
    
    public static boolean zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final BlockPos target) {
        final IBlockState iblockstate = worldIn.zeroday(target);
        if (iblockstate.sigma() instanceof IGrowable) {
            final IGrowable igrowable = (IGrowable)iblockstate.sigma();
            if (igrowable.zerodayisaminecraftcheat(worldIn, target, iblockstate, worldIn.r)) {
                if (!worldIn.r) {
                    if (igrowable.zerodayisaminecraftcheat(worldIn, worldIn.g, target, iblockstate)) {
                        igrowable.zeroday(worldIn, worldIn.g, target, iblockstate);
                    }
                    --stack.zeroday;
                }
                return true;
            }
        }
        return false;
    }
    
    public static void zerodayisaminecraftcheat(final World worldIn, final BlockPos pos, int amount) {
        if (amount == 0) {
            amount = 15;
        }
        final Block block = worldIn.zeroday(pos).sigma();
        if (block.flux() != Material.zerodayisaminecraftcheat) {
            block.sigma((IBlockAccess)worldIn, pos);
            for (int i = 0; i < amount; ++i) {
                final double d0 = ItemDye.sigma.nextGaussian() * 0.02;
                final double d2 = ItemDye.sigma.nextGaussian() * 0.02;
                final double d3 = ItemDye.sigma.nextGaussian() * 0.02;
                worldIn.zerodayisaminecraftcheat(EnumParticleTypes.n, pos.zerodayisaminecraftcheat() + ItemDye.sigma.nextFloat(), pos.zeroday() + ItemDye.sigma.nextFloat() * block.m(), pos.sigma() + ItemDye.sigma.nextFloat(), d0, d2, d3, new int[0]);
            }
        }
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final EntityLivingBase target) {
        if (target instanceof EntitySheep) {
            final EntitySheep entitysheep = (EntitySheep)target;
            final EnumDyeColor enumdyecolor = EnumDyeColor.zerodayisaminecraftcheat(stack.momgetthecamera());
            if (!entitysheep.ce() && entitysheep.cd() != enumdyecolor) {
                entitysheep.zeroday(enumdyecolor);
                --stack.zeroday;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        for (int i = 0; i < 16; ++i) {
            subItems.add(new ItemStack(itemIn, 1, i));
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.b.Slot;
import net.minecraft.d.NBTTagList;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zeroday.S2FPacketSetSlot;
import net.minecraft.b.IInventory;
import net.minecraft.vape.vape.EntityPlayerMP;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagString;
import net.minecraft.o.ChatComponentText;
import net.minecraft.vape.Entity;
import net.minecraft.zeroday.ICommandSender;
import net.minecraft.o.ChatComponentProcessor;
import net.minecraft.o.IChatComponent;
import net.minecraft.m.StatList;
import net.minecraft.q.World;
import net.minecraft.o.StatCollector;
import net.minecraft.o.EnumChatFormatting;
import java.util.List;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.StringUtils;
import net.minecraft.d.NBTTagCompound;

public class ItemEditableBook extends Item
{
    public ItemEditableBook() {
        this.zeroday(1);
    }
    
    public static boolean zeroday(final NBTTagCompound nbt) {
        if (!ItemWritableBook.zeroday(nbt)) {
            return false;
        }
        if (!nbt.zeroday("title", 8)) {
            return false;
        }
        final String s = nbt.b("title");
        return s != null && s.length() <= 32 && nbt.zeroday("author", 8);
    }
    
    public static int c(final ItemStack book) {
        return book.g().flux("generation");
    }
    
    @Override
    public String vape(final ItemStack stack) {
        if (stack.f()) {
            final NBTTagCompound nbttagcompound = stack.g();
            final String s = nbttagcompound.b("title");
            if (!StringUtils.zeroday(s)) {
                return s;
            }
        }
        return super.vape(stack);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        if (stack.f()) {
            final NBTTagCompound nbttagcompound = stack.g();
            final String s = nbttagcompound.b("author");
            if (!StringUtils.zeroday(s)) {
                tooltip.add(EnumChatFormatting.momgetthecamera + StatCollector.zerodayisaminecraftcheat("book.byAuthor", s));
            }
            tooltip.add(EnumChatFormatting.momgetthecamera + StatCollector.zerodayisaminecraftcheat("book.generation." + nbttagcompound.flux("generation")));
        }
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (!worldIn.r) {
            this.zerodayisaminecraftcheat(itemStackIn, playerIn);
        }
        playerIn.zerodayisaminecraftcheat(itemStackIn);
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        return itemStackIn;
    }
    
    private void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer player) {
        if (stack != null && stack.g() != null) {
            final NBTTagCompound nbttagcompound = stack.g();
            if (!nbttagcompound.f("resolved")) {
                nbttagcompound.zerodayisaminecraftcheat("resolved", true);
                if (zeroday(nbttagcompound)) {
                    final NBTTagList nbttaglist = nbttagcompound.sigma("pages", 8);
                    for (int i = 0; i < nbttaglist.zues(); ++i) {
                        final String s = nbttaglist.flux(i);
                        IChatComponent lvt_7_1_;
                        try {
                            lvt_7_1_ = IChatComponent.zerodayisaminecraftcheat.zerodayisaminecraftcheat(s);
                            lvt_7_1_ = ChatComponentProcessor.zerodayisaminecraftcheat(player, lvt_7_1_, player);
                        }
                        catch (Exception var9) {
                            lvt_7_1_ = new ChatComponentText(s);
                        }
                        nbttaglist.zerodayisaminecraftcheat(i, new NBTTagString(IChatComponent.zerodayisaminecraftcheat.zerodayisaminecraftcheat(lvt_7_1_)));
                    }
                    nbttagcompound.zerodayisaminecraftcheat("pages", nbttaglist);
                    if (player instanceof EntityPlayerMP && player.aX() == stack) {
                        final Slot slot = player.f.zerodayisaminecraftcheat(player.d, player.d.sigma);
                        ((EntityPlayerMP)player).zerodayisaminecraftcheat.zerodayisaminecraftcheat(new S2FPacketSetSlot(0, slot.sigma, stack));
                    }
                }
            }
        }
    }
    
    @Override
    public boolean momgetthecamera(final ItemStack stack) {
        return true;
    }
}

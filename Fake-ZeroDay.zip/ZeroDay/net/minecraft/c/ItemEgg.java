// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.m.StatList;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.momgetthecamera.EntityEgg;
import net.minecraft.vape.Entity;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemEgg extends Item
{
    public ItemEgg() {
        this.pandora = 16;
        this.zerodayisaminecraftcheat(CreativeTabs.d);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (!playerIn.bz.pandora) {
            --itemStackIn.zeroday;
        }
        worldIn.zerodayisaminecraftcheat((Entity)playerIn, "random.bow", 0.5f, 0.4f / (ItemEgg.sigma.nextFloat() * 0.4f + 0.8f));
        if (!worldIn.r) {
            worldIn.zerodayisaminecraftcheat(new EntityEgg(worldIn, playerIn));
        }
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        return itemStackIn;
    }
}

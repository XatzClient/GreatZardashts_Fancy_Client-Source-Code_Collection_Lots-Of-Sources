// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.m.StatList;
import net.minecraft.q.WorldSavedData;
import net.minecraft.q.vape.MapData;
import net.minecraft.a.Items;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemEmptyMap extends ItemMapBase
{
    protected ItemEmptyMap() {
        this.zerodayisaminecraftcheat(CreativeTabs.flux);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        final ItemStack itemstack = new ItemStack(Items.aV, 1, worldIn.zeroday("map"));
        final String s = "map_" + itemstack.momgetthecamera();
        final MapData mapdata = new MapData(s);
        worldIn.zerodayisaminecraftcheat(s, mapdata);
        mapdata.zues = 0;
        mapdata.zerodayisaminecraftcheat(playerIn.s, playerIn.u, mapdata.zues);
        mapdata.pandora = (byte)worldIn.h.i();
        mapdata.pandora();
        --itemStackIn.zeroday;
        if (itemStackIn.zeroday <= 0) {
            return itemstack;
        }
        if (!playerIn.d.zerodayisaminecraftcheat(itemstack.b())) {
            playerIn.zerodayisaminecraftcheat(itemstack, false);
        }
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        return itemStackIn;
    }
}

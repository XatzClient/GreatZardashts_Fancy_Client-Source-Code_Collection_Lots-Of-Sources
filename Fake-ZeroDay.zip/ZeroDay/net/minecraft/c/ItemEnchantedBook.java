// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.flux.EnchantmentHelper;
import net.minecraft.a.Items;
import net.minecraft.o.WeightedRandomChestContent;
import java.util.Random;
import net.minecraft.d.NBTBase;
import net.minecraft.flux.EnchantmentData;
import net.minecraft.flux.Enchantment;
import java.util.List;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.d.NBTTagList;

public class ItemEnchantedBook extends Item
{
    @Override
    public boolean momgetthecamera(final ItemStack stack) {
        return true;
    }
    
    @Override
    public boolean b(final ItemStack stack) {
        return false;
    }
    
    @Override
    public EnumRarity a(final ItemStack stack) {
        return (this.c(stack).zues() > 0) ? EnumRarity.zeroday : super.a(stack);
    }
    
    public NBTTagList c(final ItemStack stack) {
        final NBTTagCompound nbttagcompound = stack.g();
        return (NBTTagList)((nbttagcompound != null && nbttagcompound.zeroday("StoredEnchantments", 9)) ? nbttagcompound.zerodayisaminecraftcheat("StoredEnchantments") : new NBTTagList());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        super.zerodayisaminecraftcheat(stack, playerIn, tooltip, advanced);
        final NBTTagList nbttaglist = this.c(stack);
        if (nbttaglist != null) {
            for (int i = 0; i < nbttaglist.zues(); ++i) {
                final int j = nbttaglist.zeroday(i).zues("id");
                final int k = nbttaglist.zeroday(i).zues("lvl");
                if (Enchantment.zerodayisaminecraftcheat(j) != null) {
                    tooltip.add(Enchantment.zerodayisaminecraftcheat(j).pandora(k));
                }
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final ItemStack stack, final EnchantmentData enchantment) {
        final NBTTagList nbttaglist = this.c(stack);
        boolean flag = true;
        for (int i = 0; i < nbttaglist.zues(); ++i) {
            final NBTTagCompound nbttagcompound = nbttaglist.zeroday(i);
            if (nbttagcompound.zues("id") == enchantment.zerodayisaminecraftcheat.s) {
                if (nbttagcompound.zues("lvl") < enchantment.zeroday) {
                    nbttagcompound.zerodayisaminecraftcheat("lvl", (short)enchantment.zeroday);
                }
                flag = false;
                break;
            }
        }
        if (flag) {
            final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
            nbttagcompound2.zerodayisaminecraftcheat("id", (short)enchantment.zerodayisaminecraftcheat.s);
            nbttagcompound2.zerodayisaminecraftcheat("lvl", (short)enchantment.zeroday);
            nbttaglist.zerodayisaminecraftcheat(nbttagcompound2);
        }
        if (!stack.f()) {
            stack.pandora(new NBTTagCompound());
        }
        stack.g().zerodayisaminecraftcheat("StoredEnchantments", nbttaglist);
    }
    
    public ItemStack zerodayisaminecraftcheat(final EnchantmentData data) {
        final ItemStack itemstack = new ItemStack(this);
        this.zerodayisaminecraftcheat(itemstack, data);
        return itemstack;
    }
    
    public void zerodayisaminecraftcheat(final Enchantment enchantment, final List<ItemStack> list) {
        for (int i = enchantment.sigma(); i <= enchantment.pandora(); ++i) {
            list.add(this.zerodayisaminecraftcheat(new EnchantmentData(enchantment, i)));
        }
    }
    
    public WeightedRandomChestContent zerodayisaminecraftcheat(final Random rand) {
        return this.zerodayisaminecraftcheat(rand, 1, 1, 1);
    }
    
    public WeightedRandomChestContent zerodayisaminecraftcheat(final Random rand, final int minChance, final int maxChance, final int weight) {
        final ItemStack itemstack = new ItemStack(Items.aD, 1, 0);
        EnchantmentHelper.zerodayisaminecraftcheat(rand, itemstack, 30);
        return new WeightedRandomChestContent(itemstack, minChance, maxChance, weight);
    }
}

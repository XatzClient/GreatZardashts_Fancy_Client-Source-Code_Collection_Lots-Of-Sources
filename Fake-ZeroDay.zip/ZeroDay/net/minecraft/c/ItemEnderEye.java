// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.m.StatList;
import net.minecraft.vape.pandora.EntityEnderEye;
import net.minecraft.vape.Entity;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.o.EnumParticleTypes;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockEndPortalFrame;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemEnderEye extends Item
{
    public ItemEnderEye() {
        this.zerodayisaminecraftcheat(CreativeTabs.flux);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final IBlockState iblockstate = worldIn.zeroday(pos);
        if (!playerIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(side), side, stack) || iblockstate.sigma() != Blocks.by || iblockstate.zerodayisaminecraftcheat((IProperty<Boolean>)BlockEndPortalFrame.E)) {
            return false;
        }
        if (worldIn.r) {
            return true;
        }
        worldIn.zerodayisaminecraftcheat(pos, iblockstate.zerodayisaminecraftcheat((IProperty<Comparable>)BlockEndPortalFrame.E, true), 2);
        worldIn.zues(pos, Blocks.by);
        --stack.zeroday;
        for (int i = 0; i < 16; ++i) {
            final double d0 = pos.zerodayisaminecraftcheat() + (5.0f + ItemEnderEye.sigma.nextFloat() * 6.0f) / 16.0f;
            final double d2 = pos.zeroday() + 0.8125f;
            final double d3 = pos.sigma() + (5.0f + ItemEnderEye.sigma.nextFloat() * 6.0f) / 16.0f;
            final double d4 = 0.0;
            final double d5 = 0.0;
            final double d6 = 0.0;
            worldIn.zerodayisaminecraftcheat(EnumParticleTypes.d, d0, d2, d3, d4, d5, d6, new int[0]);
        }
        final EnumFacing enumfacing = iblockstate.zerodayisaminecraftcheat((IProperty<EnumFacing>)BlockEndPortalFrame.D);
        int l = 0;
        int j = 0;
        boolean flag1 = false;
        boolean flag2 = true;
        final EnumFacing enumfacing2 = enumfacing.flux();
        for (int k = -2; k <= 2; ++k) {
            final BlockPos blockpos1 = pos.zerodayisaminecraftcheat(enumfacing2, k);
            final IBlockState iblockstate2 = worldIn.zeroday(blockpos1);
            if (iblockstate2.sigma() == Blocks.by) {
                if (!iblockstate2.zerodayisaminecraftcheat((IProperty<Boolean>)BlockEndPortalFrame.E)) {
                    flag2 = false;
                    break;
                }
                j = k;
                if (!flag1) {
                    l = k;
                    flag1 = true;
                }
            }
        }
        if (flag2 && j == l + 2) {
            BlockPos blockpos2 = pos.zerodayisaminecraftcheat(enumfacing, 4);
            for (int i2 = l; i2 <= j; ++i2) {
                final BlockPos blockpos3 = blockpos2.zerodayisaminecraftcheat(enumfacing2, i2);
                final IBlockState iblockstate3 = worldIn.zeroday(blockpos3);
                if (iblockstate3.sigma() != Blocks.by || !iblockstate3.zerodayisaminecraftcheat((IProperty<Boolean>)BlockEndPortalFrame.E)) {
                    flag2 = false;
                    break;
                }
            }
            for (int j2 = l - 1; j2 <= j + 1; j2 += 4) {
                blockpos2 = pos.zerodayisaminecraftcheat(enumfacing2, j2);
                for (int l2 = 1; l2 <= 3; ++l2) {
                    final BlockPos blockpos4 = blockpos2.zerodayisaminecraftcheat(enumfacing, l2);
                    final IBlockState iblockstate4 = worldIn.zeroday(blockpos4);
                    if (iblockstate4.sigma() != Blocks.by || !iblockstate4.zerodayisaminecraftcheat((IProperty<Boolean>)BlockEndPortalFrame.E)) {
                        flag2 = false;
                        break;
                    }
                }
            }
            if (flag2) {
                for (int k2 = l; k2 <= j; ++k2) {
                    blockpos2 = pos.zerodayisaminecraftcheat(enumfacing2, k2);
                    for (int i3 = 1; i3 <= 3; ++i3) {
                        final BlockPos blockpos5 = blockpos2.zerodayisaminecraftcheat(enumfacing, i3);
                        worldIn.zerodayisaminecraftcheat(blockpos5, Blocks.bx.G(), 2);
                    }
                }
            }
        }
        return true;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        final MovingObjectPosition movingobjectposition = this.zerodayisaminecraftcheat(worldIn, playerIn, false);
        if (movingobjectposition != null && movingobjectposition.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday && worldIn.zeroday(movingobjectposition.zerodayisaminecraftcheat()).sigma() == Blocks.by) {
            return itemStackIn;
        }
        if (!worldIn.r) {
            final BlockPos blockpos = worldIn.zerodayisaminecraftcheat("Stronghold", new BlockPos(playerIn));
            if (blockpos != null) {
                final EntityEnderEye entityendereye = new EntityEnderEye(worldIn, playerIn.s, playerIn.t, playerIn.u);
                entityendereye.zerodayisaminecraftcheat(blockpos);
                worldIn.zerodayisaminecraftcheat(entityendereye);
                worldIn.zerodayisaminecraftcheat((Entity)playerIn, "random.bow", 0.5f, 0.4f / (ItemEnderEye.sigma.nextFloat() * 0.4f + 0.8f));
                worldIn.zerodayisaminecraftcheat(null, 1002, new BlockPos(playerIn), 0);
                if (!playerIn.bz.pandora) {
                    --itemStackIn.zeroday;
                }
                playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
            }
        }
        return itemStackIn;
    }
}

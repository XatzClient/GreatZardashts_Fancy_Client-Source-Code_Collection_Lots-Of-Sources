// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemFireball extends Item
{
    public ItemFireball() {
        this.zerodayisaminecraftcheat(CreativeTabs.flux);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (worldIn.r) {
            return true;
        }
        pos = pos.zerodayisaminecraftcheat(side);
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (worldIn.zeroday(pos).sigma().flux() == Material.zerodayisaminecraftcheat) {
            worldIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() + 0.5, pos.zeroday() + 0.5, pos.sigma() + 0.5, "item.fireCharge.use", 1.0f, (ItemFireball.sigma.nextFloat() - ItemFireball.sigma.nextFloat()) * 0.2f + 1.0f);
            worldIn.zeroday(pos, Blocks.T.G());
        }
        if (!playerIn.bz.pandora) {
            --stack.zeroday;
        }
        return true;
    }
}

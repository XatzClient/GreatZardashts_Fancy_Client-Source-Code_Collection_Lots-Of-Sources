// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.d.NBTTagList;
import net.minecraft.d.NBTTagCompound;
import java.util.Collection;
import com.google.common.collect.Lists;
import net.minecraft.o.StatCollector;
import java.util.List;
import net.minecraft.vape.Entity;
import net.minecraft.vape.pandora.EntityFireworkRocket;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;

public class ItemFirework extends Item
{
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (!worldIn.r) {
            final EntityFireworkRocket entityfireworkrocket = new EntityFireworkRocket(worldIn, pos.zerodayisaminecraftcheat() + hitX, pos.zeroday() + hitY, pos.sigma() + hitZ, stack);
            worldIn.zerodayisaminecraftcheat(entityfireworkrocket);
            if (!playerIn.bz.pandora) {
                --stack.zeroday;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        if (stack.f()) {
            final NBTTagCompound nbttagcompound = stack.g().e("Fireworks");
            if (nbttagcompound != null) {
                if (nbttagcompound.zeroday("Flight", 99)) {
                    tooltip.add(String.valueOf(StatCollector.zerodayisaminecraftcheat("item.fireworks.flight")) + " " + nbttagcompound.pandora("Flight"));
                }
                final NBTTagList nbttaglist = nbttagcompound.sigma("Explosions", 10);
                if (nbttaglist != null && nbttaglist.zues() > 0) {
                    for (int i = 0; i < nbttaglist.zues(); ++i) {
                        final NBTTagCompound nbttagcompound2 = nbttaglist.zeroday(i);
                        final List<String> list = (List<String>)Lists.newArrayList();
                        ItemFireworkCharge.zerodayisaminecraftcheat(nbttagcompound2, list);
                        if (list.size() > 0) {
                            for (int j = 1; j < list.size(); ++j) {
                                list.set(j, "  " + list.get(j));
                            }
                            tooltip.addAll(list);
                        }
                    }
                }
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.StatCollector;
import java.util.List;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagIntArray;

public class ItemFireworkCharge extends Item
{
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        if (renderPass != 1) {
            return super.zerodayisaminecraftcheat(stack, renderPass);
        }
        final NBTBase nbtbase = zerodayisaminecraftcheat(stack, "Colors");
        if (!(nbtbase instanceof NBTTagIntArray)) {
            return 9079434;
        }
        final NBTTagIntArray nbttagintarray = (NBTTagIntArray)nbtbase;
        final int[] aint = nbttagintarray.zues();
        if (aint.length == 1) {
            return aint[0];
        }
        int i = 0;
        int j = 0;
        int k = 0;
        int[] array;
        for (int length = (array = aint).length, n = 0; n < length; ++n) {
            final int l = array[n];
            i += (l & 0xFF0000) >> 16;
            j += (l & 0xFF00) >> 8;
            k += (l & 0xFF) >> 0;
        }
        i /= aint.length;
        j /= aint.length;
        k /= aint.length;
        return i << 16 | j << 8 | k;
    }
    
    public static NBTBase zerodayisaminecraftcheat(final ItemStack stack, final String key) {
        if (stack.f()) {
            final NBTTagCompound nbttagcompound = stack.g().e("Explosion");
            if (nbttagcompound != null) {
                return nbttagcompound.zerodayisaminecraftcheat(key);
            }
        }
        return null;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        if (stack.f()) {
            final NBTTagCompound nbttagcompound = stack.g().e("Explosion");
            if (nbttagcompound != null) {
                zerodayisaminecraftcheat(nbttagcompound, tooltip);
            }
        }
    }
    
    public static void zerodayisaminecraftcheat(final NBTTagCompound nbt, final List<String> tooltip) {
        final byte b0 = nbt.pandora("Type");
        if (b0 >= 0 && b0 <= 4) {
            tooltip.add(StatCollector.zerodayisaminecraftcheat("item.fireworksCharge.type." + b0).trim());
        }
        else {
            tooltip.add(StatCollector.zerodayisaminecraftcheat("item.fireworksCharge.type").trim());
        }
        final int[] aint = nbt.d("Colors");
        if (aint.length > 0) {
            boolean flag = true;
            String s = "";
            int[] array;
            for (int length = (array = aint).length, n = 0; n < length; ++n) {
                final int i = array[n];
                if (!flag) {
                    s = String.valueOf(s) + ", ";
                }
                flag = false;
                boolean flag2 = false;
                for (int j = 0; j < ItemDye.vape.length; ++j) {
                    if (i == ItemDye.vape[j]) {
                        flag2 = true;
                        s = String.valueOf(s) + StatCollector.zerodayisaminecraftcheat("item.fireworksCharge." + EnumDyeColor.zerodayisaminecraftcheat(j).pandora());
                        break;
                    }
                }
                if (!flag2) {
                    s = String.valueOf(s) + StatCollector.zerodayisaminecraftcheat("item.fireworksCharge.customColor");
                }
            }
            tooltip.add(s);
        }
        final int[] aint2 = nbt.d("FadeColors");
        if (aint2.length > 0) {
            boolean flag3 = true;
            String s2 = String.valueOf(StatCollector.zerodayisaminecraftcheat("item.fireworksCharge.fadeTo")) + " ";
            int[] array2;
            for (int length2 = (array2 = aint2).length, n2 = 0; n2 < length2; ++n2) {
                final int l = array2[n2];
                if (!flag3) {
                    s2 = String.valueOf(s2) + ", ";
                }
                flag3 = false;
                boolean flag4 = false;
                for (int k = 0; k < 16; ++k) {
                    if (l == ItemDye.vape[k]) {
                        flag4 = true;
                        s2 = String.valueOf(s2) + StatCollector.zerodayisaminecraftcheat("item.fireworksCharge." + EnumDyeColor.zerodayisaminecraftcheat(k).pandora());
                        break;
                    }
                }
                if (!flag4) {
                    s2 = String.valueOf(s2) + StatCollector.zerodayisaminecraftcheat("item.fireworksCharge.customColor");
                }
            }
            tooltip.add(s2);
        }
        final boolean flag5 = nbt.f("Trail");
        if (flag5) {
            tooltip.add(StatCollector.zerodayisaminecraftcheat("item.fireworksCharge.trail"));
        }
        final boolean flag6 = nbt.f("Flicker");
        if (flag6) {
            tooltip.add(StatCollector.zerodayisaminecraftcheat("item.fireworksCharge.flicker"));
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.List;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.g.PotionEffect;
import net.minecraft.g.Potion;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;

public class ItemFishFood extends ItemFood
{
    private final boolean momgetthecamera;
    
    public ItemFishFood(final boolean cooked) {
        super(0, 0.0f, false);
        this.momgetthecamera = cooked;
    }
    
    @Override
    public int c(final ItemStack stack) {
        final zerodayisaminecraftcheat itemfishfood$fishtype = zerodayisaminecraftcheat.zerodayisaminecraftcheat(stack);
        return (this.momgetthecamera && itemfishfood$fishtype.vape()) ? itemfishfood$fishtype.zues() : itemfishfood$fishtype.sigma();
    }
    
    @Override
    public float d(final ItemStack stack) {
        final zerodayisaminecraftcheat itemfishfood$fishtype = zerodayisaminecraftcheat.zerodayisaminecraftcheat(stack);
        return (this.momgetthecamera && itemfishfood$fishtype.vape()) ? itemfishfood$fishtype.flux() : itemfishfood$fishtype.pandora();
    }
    
    @Override
    public String zues(final ItemStack stack) {
        return (zerodayisaminecraftcheat.zerodayisaminecraftcheat(stack) == zerodayisaminecraftcheat.pandora) ? "+0-1+2+3+13&4-4" : null;
    }
    
    @Override
    protected void pandora(final ItemStack stack, final World worldIn, final EntityPlayer player) {
        final zerodayisaminecraftcheat itemfishfood$fishtype = zerodayisaminecraftcheat.zerodayisaminecraftcheat(stack);
        if (itemfishfood$fishtype == zerodayisaminecraftcheat.pandora) {
            player.zerodayisaminecraftcheat(new PotionEffect(Potion.m.z, 1200, 3));
            player.zerodayisaminecraftcheat(new PotionEffect(Potion.k.z, 300, 2));
            player.zerodayisaminecraftcheat(new PotionEffect(Potion.c.z, 300, 1));
        }
        super.pandora(stack, worldIn, player);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        zerodayisaminecraftcheat[] values;
        for (int length = (values = zerodayisaminecraftcheat.values()).length, i = 0; i < length; ++i) {
            final zerodayisaminecraftcheat itemfishfood$fishtype = values[i];
            if (!this.momgetthecamera || itemfishfood$fishtype.vape()) {
                subItems.add(new ItemStack(this, 1, itemfishfood$fishtype.zerodayisaminecraftcheat()));
            }
        }
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        final zerodayisaminecraftcheat itemfishfood$fishtype = zerodayisaminecraftcheat.zerodayisaminecraftcheat(stack);
        return String.valueOf(this.momgetthecamera()) + "." + itemfishfood$fishtype.zeroday() + "." + ((this.momgetthecamera && itemfishfood$fishtype.vape()) ? "cooked" : "raw");
    }
    
    public enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("COD", 0, 0, "cod", 2, 0.1f, 5, 0.6f), 
        zeroday("SALMON", 1, 1, "salmon", 2, 0.1f, 6, 0.8f), 
        sigma("CLOWNFISH", 2, 2, "clownfish", 1, 0.1f), 
        pandora("PUFFERFISH", 3, 3, "pufferfish", 1, 0.1f);
        
        private static final Map<Integer, zerodayisaminecraftcheat> zues;
        private final int flux;
        private final String vape;
        private final int momgetthecamera;
        private final float a;
        private final int b;
        private final float c;
        private boolean d;
        
        static {
            e = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.pandora };
            zues = Maps.newHashMap();
            zerodayisaminecraftcheat[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final zerodayisaminecraftcheat itemfishfood$fishtype = values[i];
                zerodayisaminecraftcheat.zues.put(itemfishfood$fishtype.zerodayisaminecraftcheat(), itemfishfood$fishtype);
            }
        }
        
        private zerodayisaminecraftcheat(final String s, final int n, final int meta, final String unlocalizedName, final int uncookedHeal, final float uncookedSaturation, final int cookedHeal, final float cookedSaturation) {
            this.d = false;
            this.flux = meta;
            this.vape = unlocalizedName;
            this.momgetthecamera = uncookedHeal;
            this.a = uncookedSaturation;
            this.b = cookedHeal;
            this.c = cookedSaturation;
            this.d = true;
        }
        
        private zerodayisaminecraftcheat(final String s, final int n, final int meta, final String unlocalizedName, final int uncookedHeal, final float uncookedSaturation) {
            this.d = false;
            this.flux = meta;
            this.vape = unlocalizedName;
            this.momgetthecamera = uncookedHeal;
            this.a = uncookedSaturation;
            this.b = 0;
            this.c = 0.0f;
            this.d = false;
        }
        
        public int zerodayisaminecraftcheat() {
            return this.flux;
        }
        
        public String zeroday() {
            return this.vape;
        }
        
        public int sigma() {
            return this.momgetthecamera;
        }
        
        public float pandora() {
            return this.a;
        }
        
        public int zues() {
            return this.b;
        }
        
        public float flux() {
            return this.c;
        }
        
        public boolean vape() {
            return this.d;
        }
        
        public static zerodayisaminecraftcheat zerodayisaminecraftcheat(final int meta) {
            final zerodayisaminecraftcheat itemfishfood$fishtype = zerodayisaminecraftcheat.zues.get(meta);
            return (itemfishfood$fishtype == null) ? zerodayisaminecraftcheat.zerodayisaminecraftcheat : itemfishfood$fishtype;
        }
        
        public static zerodayisaminecraftcheat zerodayisaminecraftcheat(final ItemStack stack) {
            return (stack.zerodayisaminecraftcheat() instanceof ItemFishFood) ? zerodayisaminecraftcheat(stack.momgetthecamera()) : zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        }
    }
}

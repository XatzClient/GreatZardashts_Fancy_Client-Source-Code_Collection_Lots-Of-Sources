// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.m.StatList;
import net.minecraft.vape.momgetthecamera.EntityFishHook;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemFishingRod extends Item
{
    public ItemFishingRod() {
        this.pandora(64);
        this.zeroday(1);
        this.zerodayisaminecraftcheat(CreativeTabs.a);
    }
    
    @Override
    public boolean flux() {
        return true;
    }
    
    @Override
    public boolean vape() {
        return true;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (playerIn.bF != null) {
            final int i = playerIn.bF.momgetthecamera();
            itemStackIn.zerodayisaminecraftcheat(i, playerIn);
            playerIn.e_();
        }
        else {
            worldIn.zerodayisaminecraftcheat((Entity)playerIn, "random.bow", 0.5f, 0.4f / (ItemFishingRod.sigma.nextFloat() * 0.4f + 0.8f));
            if (!worldIn.r) {
                worldIn.zerodayisaminecraftcheat(new EntityFishHook(worldIn, playerIn));
            }
            playerIn.e_();
            playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        }
        return itemStackIn;
    }
    
    @Override
    public boolean b(final ItemStack stack) {
        return super.b(stack);
    }
    
    @Override
    public int e() {
        return 1;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemFlintAndSteel extends Item
{
    public ItemFlintAndSteel() {
        this.pandora = 1;
        this.pandora(64);
        this.zerodayisaminecraftcheat(CreativeTabs.a);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        pos = pos.zerodayisaminecraftcheat(side);
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (worldIn.zeroday(pos).sigma().flux() == Material.zerodayisaminecraftcheat) {
            worldIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() + 0.5, pos.zeroday() + 0.5, pos.sigma() + 0.5, "fire.ignite", 1.0f, ItemFlintAndSteel.sigma.nextFloat() * 0.4f + 0.8f);
            worldIn.zeroday(pos, Blocks.T.G());
        }
        stack.zerodayisaminecraftcheat(1, playerIn);
        return true;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.g.PotionEffect;
import net.minecraft.m.StatList;
import net.minecraft.vape.Entity;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemFood extends Item
{
    public final int vape;
    private final int momgetthecamera;
    private final float a;
    private final boolean b;
    private boolean c;
    private int d;
    private int e;
    private int f;
    private float g;
    
    public ItemFood(final int amount, final float saturation, final boolean isWolfFood) {
        this.vape = 32;
        this.momgetthecamera = amount;
        this.b = isWolfFood;
        this.a = saturation;
        this.zerodayisaminecraftcheat(CreativeTabs.momgetthecamera);
    }
    
    public ItemFood(final int amount, final boolean isWolfFood) {
        this(amount, 0.6f, isWolfFood);
    }
    
    @Override
    public ItemStack zeroday(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
        --stack.zeroday;
        playerIn.ca().zerodayisaminecraftcheat(this, stack);
        worldIn.zerodayisaminecraftcheat((Entity)playerIn, "random.burp", 0.5f, worldIn.g.nextFloat() * 0.1f + 0.9f);
        this.pandora(stack, worldIn, playerIn);
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        return stack;
    }
    
    protected void pandora(final ItemStack stack, final World worldIn, final EntityPlayer player) {
        if (!worldIn.r && this.d > 0 && worldIn.g.nextFloat() < this.g) {
            player.zerodayisaminecraftcheat(new PotionEffect(this.d, this.e * 20, this.f));
        }
    }
    
    @Override
    public int pandora(final ItemStack stack) {
        return 32;
    }
    
    @Override
    public EnumAction sigma(final ItemStack stack) {
        return EnumAction.zeroday;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (playerIn.sigma(this.c)) {
            playerIn.zeroday(itemStackIn, this.pandora(itemStackIn));
        }
        return itemStackIn;
    }
    
    public int c(final ItemStack stack) {
        return this.momgetthecamera;
    }
    
    public float d(final ItemStack stack) {
        return this.a;
    }
    
    public boolean j() {
        return this.b;
    }
    
    public ItemFood zerodayisaminecraftcheat(final int id, final int duration, final int amplifier, final float probability) {
        this.d = id;
        this.e = duration;
        this.f = amplifier;
        this.g = probability;
        return this;
    }
    
    public ItemFood k() {
        this.c = true;
        return this;
    }
}

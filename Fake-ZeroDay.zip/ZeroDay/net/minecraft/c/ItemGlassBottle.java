// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.BlockPos;
import net.minecraft.a.Items;
import net.minecraft.m.StatList;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemGlassBottle extends Item
{
    public ItemGlassBottle() {
        this.zerodayisaminecraftcheat(CreativeTabs.c);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        final MovingObjectPosition movingobjectposition = this.zerodayisaminecraftcheat(worldIn, playerIn, true);
        if (movingobjectposition == null) {
            return itemStackIn;
        }
        if (movingobjectposition.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
            final BlockPos blockpos = movingobjectposition.zerodayisaminecraftcheat();
            if (!worldIn.zerodayisaminecraftcheat(playerIn, blockpos)) {
                return itemStackIn;
            }
            if (!playerIn.zerodayisaminecraftcheat(blockpos.zerodayisaminecraftcheat(movingobjectposition.zeroday), movingobjectposition.zeroday, itemStackIn)) {
                return itemStackIn;
            }
            if (worldIn.zeroday(blockpos).sigma().flux() == Material.momgetthecamera) {
                --itemStackIn.zeroday;
                playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
                if (itemStackIn.zeroday <= 0) {
                    return new ItemStack(Items.br);
                }
                if (!playerIn.d.zerodayisaminecraftcheat(new ItemStack(Items.br))) {
                    playerIn.zerodayisaminecraftcheat(new ItemStack(Items.br, 1, 0), false);
                }
            }
        }
        return itemStackIn;
    }
}

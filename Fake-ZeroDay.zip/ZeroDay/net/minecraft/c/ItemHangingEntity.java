// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.vape.pandora.EntityPainting;
import net.minecraft.vape.Entity;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.vape.EntityHanging;

public class ItemHangingEntity extends Item
{
    private final Class<? extends EntityHanging> vape;
    
    public ItemHangingEntity(final Class<? extends EntityHanging> entityClass) {
        this.vape = entityClass;
        this.zerodayisaminecraftcheat(CreativeTabs.sigma);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side == EnumFacing.zerodayisaminecraftcheat) {
            return false;
        }
        if (side == EnumFacing.zeroday) {
            return false;
        }
        final BlockPos blockpos = pos.zerodayisaminecraftcheat(side);
        if (!playerIn.zerodayisaminecraftcheat(blockpos, side, stack)) {
            return false;
        }
        final EntityHanging entityhanging = this.zerodayisaminecraftcheat(worldIn, blockpos, side);
        if (entityhanging != null && entityhanging.vape()) {
            if (!worldIn.r) {
                worldIn.zerodayisaminecraftcheat(entityhanging);
            }
            --stack.zeroday;
        }
        return true;
    }
    
    private EntityHanging zerodayisaminecraftcheat(final World worldIn, final BlockPos pos, final EnumFacing clickedSide) {
        return (this.vape == EntityPainting.class) ? new EntityPainting(worldIn, pos, clickedSide) : ((this.vape == EntityItemFrame.class) ? new EntityItemFrame(worldIn, pos, clickedSide) : null);
    }
}

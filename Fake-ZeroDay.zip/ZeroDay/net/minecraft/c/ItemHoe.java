// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockDirt;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemHoe extends Item
{
    protected zerodayisaminecraftcheat vape;
    private static /* synthetic */ int[] momgetthecamera;
    
    public ItemHoe(final zerodayisaminecraftcheat material) {
        this.vape = material;
        this.pandora = 1;
        this.pandora(material.zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(CreativeTabs.a);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (!playerIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(side), side, stack)) {
            return false;
        }
        final IBlockState iblockstate = worldIn.zeroday(pos);
        final Block block = iblockstate.sigma();
        if (side != EnumFacing.zerodayisaminecraftcheat && worldIn.zeroday(pos.pandora()).sigma().flux() == Material.zerodayisaminecraftcheat) {
            if (block == Blocks.sigma) {
                return this.zerodayisaminecraftcheat(stack, playerIn, worldIn, pos, Blocks.ac.G());
            }
            if (block == Blocks.pandora) {
                switch (k()[iblockstate.zerodayisaminecraftcheat(BlockDirt.D).ordinal()]) {
                    case 1: {
                        return this.zerodayisaminecraftcheat(stack, playerIn, worldIn, pos, Blocks.ac.G());
                    }
                    case 2: {
                        return this.zerodayisaminecraftcheat(stack, playerIn, worldIn, pos, Blocks.pandora.G().zerodayisaminecraftcheat(BlockDirt.D, BlockDirt.zerodayisaminecraftcheat.zerodayisaminecraftcheat));
                    }
                }
            }
        }
        return false;
    }
    
    protected boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer player, final World worldIn, final BlockPos target, final IBlockState newState) {
        worldIn.zerodayisaminecraftcheat(target.zerodayisaminecraftcheat() + 0.5f, target.zeroday() + 0.5f, target.sigma() + 0.5f, newState.sigma().x.sigma(), (newState.sigma().x.pandora() + 1.0f) / 2.0f, newState.sigma().x.zues() * 0.8f);
        if (worldIn.r) {
            return true;
        }
        worldIn.zeroday(target, newState);
        stack.zerodayisaminecraftcheat(1, player);
        return true;
    }
    
    @Override
    public boolean flux() {
        return true;
    }
    
    public String j() {
        return this.vape.toString();
    }
    
    static /* synthetic */ int[] k() {
        final int[] momgetthecamera = ItemHoe.momgetthecamera;
        if (momgetthecamera != null) {
            return momgetthecamera;
        }
        final int[] momgetthecamera2 = new int[BlockDirt.zerodayisaminecraftcheat.values().length];
        try {
            momgetthecamera2[BlockDirt.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            momgetthecamera2[BlockDirt.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            momgetthecamera2[BlockDirt.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        return ItemHoe.momgetthecamera = momgetthecamera2;
    }
}

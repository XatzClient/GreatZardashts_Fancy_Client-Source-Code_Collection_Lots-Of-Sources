// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import java.util.Iterator;
import net.minecraft.vape.Entity;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.EntityLeashKnot;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.BlockFence;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemLead extends Item
{
    public ItemLead() {
        this.zerodayisaminecraftcheat(CreativeTabs.a);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final Block block = worldIn.zeroday(pos).sigma();
        if (!(block instanceof BlockFence)) {
            return false;
        }
        if (worldIn.r) {
            return true;
        }
        zerodayisaminecraftcheat(playerIn, worldIn, pos);
        return true;
    }
    
    public static boolean zerodayisaminecraftcheat(final EntityPlayer player, final World worldIn, final BlockPos fence) {
        EntityLeashKnot entityleashknot = EntityLeashKnot.zeroday(worldIn, fence);
        boolean flag = false;
        final double d0 = 7.0;
        final int i = fence.zerodayisaminecraftcheat();
        final int j = fence.zeroday();
        final int k = fence.sigma();
        for (final EntityLiving entityliving : worldIn.zerodayisaminecraftcheat((Class<? extends EntityLiving>)EntityLiving.class, new AxisAlignedBB(i - d0, j - d0, k - d0, i + d0, j + d0, k + d0))) {
            if (entityliving.bf() && entityliving.bg() == player) {
                if (entityleashknot == null) {
                    entityleashknot = EntityLeashKnot.zerodayisaminecraftcheat(worldIn, fence);
                }
                entityliving.zerodayisaminecraftcheat(entityleashknot, true);
                flag = true;
            }
        }
        return flag;
    }
}

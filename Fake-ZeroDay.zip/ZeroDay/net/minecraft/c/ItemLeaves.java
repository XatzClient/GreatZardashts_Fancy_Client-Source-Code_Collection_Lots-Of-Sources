// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.BlockLeaves;

public class ItemLeaves extends ItemBlock
{
    private final BlockLeaves momgetthecamera;
    
    public ItemLeaves(final BlockLeaves block) {
        super(block);
        this.momgetthecamera = block;
        this.pandora(0);
        this.zerodayisaminecraftcheat(true);
    }
    
    @Override
    public int sigma(final int damage) {
        return damage | 0x4;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        return this.momgetthecamera.zues(this.momgetthecamera.sigma(stack.momgetthecamera()));
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        return String.valueOf(super.momgetthecamera()) + "." + this.momgetthecamera.zues(stack.momgetthecamera()).pandora();
    }
}

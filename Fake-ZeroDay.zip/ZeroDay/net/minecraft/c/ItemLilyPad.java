// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.o.BlockPos;
import net.minecraft.m.StatList;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockLiquid;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemLilyPad extends ItemColored
{
    public ItemLilyPad(final Block block) {
        super(block, false);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        final MovingObjectPosition movingobjectposition = this.zerodayisaminecraftcheat(worldIn, playerIn, true);
        if (movingobjectposition == null) {
            return itemStackIn;
        }
        if (movingobjectposition.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
            final BlockPos blockpos = movingobjectposition.zerodayisaminecraftcheat();
            if (!worldIn.zerodayisaminecraftcheat(playerIn, blockpos)) {
                return itemStackIn;
            }
            if (!playerIn.zerodayisaminecraftcheat(blockpos.zerodayisaminecraftcheat(movingobjectposition.zeroday), movingobjectposition.zeroday, itemStackIn)) {
                return itemStackIn;
            }
            final BlockPos blockpos2 = blockpos.pandora();
            final IBlockState iblockstate = worldIn.zeroday(blockpos);
            if (iblockstate.sigma().flux() == Material.momgetthecamera && iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockLiquid.E) == 0 && worldIn.pandora(blockpos2)) {
                worldIn.zeroday(blockpos2, Blocks.bp.G());
                if (!playerIn.bz.pandora) {
                    --itemStackIn.zeroday;
                }
                playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
            }
        }
        return itemStackIn;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        return Blocks.bp.zues(Blocks.bp.sigma(stack.momgetthecamera()));
    }
}

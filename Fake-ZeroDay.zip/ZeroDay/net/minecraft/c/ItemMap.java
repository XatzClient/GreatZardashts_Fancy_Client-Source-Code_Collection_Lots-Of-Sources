// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import java.util.List;
import net.minecraft.a.Items;
import net.minecraft.e.Packet;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.q.sigma.Chunk;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multiset;
import com.google.common.collect.Multisets;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.MapColor;
import net.minecraft.zerodayisaminecraftcheat.BlockStone;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockDirt;
import net.minecraft.a.Blocks;
import net.minecraft.o.BlockPos;
import com.google.common.collect.HashMultiset;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.Entity;
import net.minecraft.q.WorldSavedData;
import net.minecraft.q.vape.MapData;
import net.minecraft.q.World;

public class ItemMap extends ItemMapBase
{
    protected ItemMap() {
        this.zerodayisaminecraftcheat(true);
    }
    
    public static MapData zerodayisaminecraftcheat(final int mapId, final World worldIn) {
        final String s = "map_" + mapId;
        MapData mapdata = (MapData)worldIn.zerodayisaminecraftcheat(MapData.class, s);
        if (mapdata == null) {
            mapdata = new MapData(s);
            worldIn.zerodayisaminecraftcheat(s, mapdata);
        }
        return mapdata;
    }
    
    public MapData zerodayisaminecraftcheat(final ItemStack stack, final World worldIn) {
        String s = "map_" + stack.momgetthecamera();
        MapData mapdata = (MapData)worldIn.zerodayisaminecraftcheat(MapData.class, s);
        if (mapdata == null && !worldIn.r) {
            stack.zeroday(worldIn.zeroday("map"));
            s = "map_" + stack.momgetthecamera();
            mapdata = new MapData(s);
            mapdata.zues = 3;
            mapdata.zerodayisaminecraftcheat(worldIn.u().sigma(), worldIn.u().zues(), mapdata.zues);
            mapdata.pandora = (byte)worldIn.h.i();
            mapdata.pandora();
            worldIn.zerodayisaminecraftcheat(s, mapdata);
        }
        return mapdata;
    }
    
    public void zerodayisaminecraftcheat(final World worldIn, final Entity viewer, final MapData data) {
        if (worldIn.h.i() == data.pandora && viewer instanceof EntityPlayer) {
            final int i = 1 << data.zues;
            final int j = data.zeroday;
            final int k = data.sigma;
            final int l = MathHelper.sigma(viewer.s - j) / i + 64;
            final int i2 = MathHelper.sigma(viewer.u - k) / i + 64;
            int j2 = 128 / i;
            if (worldIn.h.g()) {
                j2 /= 2;
            }
            final MapData.zerodayisaminecraftcheat zerodayisaminecraftcheat;
            final MapData.zerodayisaminecraftcheat mapdata$mapinfo = zerodayisaminecraftcheat = data.zerodayisaminecraftcheat((EntityPlayer)viewer);
            ++zerodayisaminecraftcheat.zeroday;
            boolean flag = false;
            for (int k2 = l - j2 + 1; k2 < l + j2; ++k2) {
                if ((k2 & 0xF) == (mapdata$mapinfo.zeroday & 0xF) || flag) {
                    flag = false;
                    double d0 = 0.0;
                    for (int l2 = i2 - j2 - 1; l2 < i2 + j2; ++l2) {
                        if (k2 >= 0 && l2 >= -1 && k2 < 128 && l2 < 128) {
                            final int i3 = k2 - l;
                            final int j3 = l2 - i2;
                            final boolean flag2 = i3 * i3 + j3 * j3 > (j2 - 2) * (j2 - 2);
                            final int k3 = (j / i + k2 - 64) * i;
                            final int l3 = (k / i + l2 - 64) * i;
                            final Multiset<MapColor> multiset = (Multiset<MapColor>)HashMultiset.create();
                            final Chunk chunk = worldIn.vape(new BlockPos(k3, 0, l3));
                            if (!chunk.momgetthecamera()) {
                                final int i4 = k3 & 0xF;
                                final int j4 = l3 & 0xF;
                                int k4 = 0;
                                double d2 = 0.0;
                                if (worldIn.h.g()) {
                                    int l4 = k3 + l3 * 231871;
                                    l4 = l4 * l4 * 31287121 + l4 * 11;
                                    if ((l4 >> 20 & 0x1) == 0x0) {
                                        multiset.add((Object)Blocks.pandora.zeroday(Blocks.pandora.G().zerodayisaminecraftcheat(BlockDirt.D, BlockDirt.zerodayisaminecraftcheat.zerodayisaminecraftcheat)), 10);
                                    }
                                    else {
                                        multiset.add((Object)Blocks.zeroday.zeroday(Blocks.zeroday.G().zerodayisaminecraftcheat(BlockStone.D, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat)), 100);
                                    }
                                    d2 = 100.0;
                                }
                                else {
                                    final BlockPos.zerodayisaminecraftcheat blockpos$mutableblockpos = new BlockPos.zerodayisaminecraftcheat();
                                    for (int i5 = 0; i5 < i; ++i5) {
                                        for (int j5 = 0; j5 < i; ++j5) {
                                            int k5 = chunk.zeroday(i5 + i4, j5 + j4) + 1;
                                            IBlockState iblockstate = Blocks.zerodayisaminecraftcheat.G();
                                            if (k5 > 1) {
                                                do {
                                                    --k5;
                                                    iblockstate = chunk.pandora(blockpos$mutableblockpos.zerodayisaminecraftcheat(i5 + i4, k5, j5 + j4));
                                                } while (iblockstate.sigma().zeroday(iblockstate) == MapColor.zeroday && k5 > 0);
                                                if (k5 > 0 && iblockstate.sigma().flux().zerodayisaminecraftcheat()) {
                                                    int l5 = k5 - 1;
                                                    Block block;
                                                    do {
                                                        block = chunk.zerodayisaminecraftcheat(i5 + i4, l5--, j5 + j4);
                                                        ++k4;
                                                    } while (l5 > 0 && block.flux().zerodayisaminecraftcheat());
                                                }
                                            }
                                            d2 += k5 / (double)(i * i);
                                            multiset.add((Object)iblockstate.sigma().zeroday(iblockstate));
                                        }
                                    }
                                }
                                k4 /= i * i;
                                double d3 = (d2 - d0) * 4.0 / (i + 4) + ((k2 + l2 & 0x1) - 0.5) * 0.4;
                                int i6 = 1;
                                if (d3 > 0.6) {
                                    i6 = 2;
                                }
                                if (d3 < -0.6) {
                                    i6 = 0;
                                }
                                final MapColor mapcolor = (MapColor)Iterables.getFirst((Iterable)Multisets.copyHighestCountFirst((Multiset)multiset), (Object)MapColor.zeroday);
                                if (mapcolor == MapColor.f) {
                                    d3 = k4 * 0.1 + (k2 + l2 & 0x1) * 0.2;
                                    i6 = 1;
                                    if (d3 < 0.5) {
                                        i6 = 2;
                                    }
                                    if (d3 > 0.9) {
                                        i6 = 0;
                                    }
                                }
                                d0 = d2;
                                if (l2 >= 0 && i3 * i3 + j3 * j3 < j2 * j2 && (!flag2 || (k2 + l2 & 0x1) != 0x0)) {
                                    final byte b0 = data.flux[k2 + l2 * 128];
                                    final byte b2 = (byte)(mapcolor.E * 4 + i6);
                                    if (b0 != b2) {
                                        data.flux[k2 + l2 * 128] = b2;
                                        data.zerodayisaminecraftcheat(k2, l2);
                                        flag = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final Entity entityIn, final int itemSlot, final boolean isSelected) {
        if (!worldIn.r) {
            final MapData mapdata = this.zerodayisaminecraftcheat(stack, worldIn);
            if (entityIn instanceof EntityPlayer) {
                final EntityPlayer entityplayer = (EntityPlayer)entityIn;
                mapdata.zerodayisaminecraftcheat(entityplayer, stack);
            }
            if (isSelected) {
                this.zerodayisaminecraftcheat(worldIn, entityIn, mapdata);
            }
        }
    }
    
    @Override
    public Packet pandora(final ItemStack stack, final World worldIn, final EntityPlayer player) {
        return this.zerodayisaminecraftcheat(stack, worldIn).zerodayisaminecraftcheat(stack, worldIn, player);
    }
    
    @Override
    public void sigma(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
        if (stack.f() && stack.g().f("map_is_scaling")) {
            final MapData mapdata = Items.aV.zerodayisaminecraftcheat(stack, worldIn);
            stack.zeroday(worldIn.zeroday("map"));
            final MapData mapdata2 = new MapData("map_" + stack.momgetthecamera());
            mapdata2.zues = (byte)(mapdata.zues + 1);
            if (mapdata2.zues > 4) {
                mapdata2.zues = 4;
            }
            mapdata2.zerodayisaminecraftcheat(mapdata.zeroday, mapdata.sigma, mapdata2.zues);
            mapdata2.pandora = mapdata.pandora;
            mapdata2.pandora();
            worldIn.zerodayisaminecraftcheat("map_" + stack.momgetthecamera(), mapdata2);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        final MapData mapdata = this.zerodayisaminecraftcheat(stack, playerIn.o);
        if (advanced) {
            if (mapdata == null) {
                tooltip.add("Unknown map");
            }
            else {
                tooltip.add("Scaling at 1:" + (1 << mapdata.zues));
                tooltip.add("(Level " + mapdata.zues + "/" + 4 + ")");
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.e.Packet;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;

public class ItemMapBase extends Item
{
    @Override
    public boolean d() {
        return true;
    }
    
    public Packet pandora(final ItemStack stack, final World worldIn, final EntityPlayer player) {
        return null;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.Entity;
import net.minecraft.o.EnumFacing;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.zerodayisaminecraftcheat.BlockRailBase;
import net.minecraft.zerodayisaminecraftcheat.BlockDispenser;
import net.minecraft.zues.IBlockSource;
import net.minecraft.zues.BehaviorDefaultDispenseItem;
import net.minecraft.vape.pandora.EntityMinecart;
import net.minecraft.zues.IBehaviorDispenseItem;

public class ItemMinecart extends Item
{
    private static final IBehaviorDispenseItem vape;
    private final EntityMinecart.zerodayisaminecraftcheat momgetthecamera;
    
    static {
        vape = new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem zeroday = new BehaviorDefaultDispenseItem();
            
            public ItemStack zeroday(final IBlockSource source, final ItemStack stack) {
                final EnumFacing enumfacing = BlockDispenser.zues(source.flux());
                final World world = source.zerodayisaminecraftcheat();
                final double d0 = source.zeroday() + enumfacing.momgetthecamera() * 1.125;
                final double d2 = Math.floor(source.sigma()) + enumfacing.a();
                final double d3 = source.pandora() + enumfacing.b() * 1.125;
                final BlockPos blockpos = source.zues().zerodayisaminecraftcheat(enumfacing);
                final IBlockState iblockstate = world.zeroday(blockpos);
                final BlockRailBase.zerodayisaminecraftcheat blockrailbase$enumraildirection = (iblockstate.sigma() instanceof BlockRailBase) ? iblockstate.zerodayisaminecraftcheat(((BlockRailBase)iblockstate.sigma()).J()) : BlockRailBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
                double d4;
                if (BlockRailBase.a(iblockstate)) {
                    if (blockrailbase$enumraildirection.sigma()) {
                        d4 = 0.6;
                    }
                    else {
                        d4 = 0.1;
                    }
                }
                else {
                    if (iblockstate.sigma().flux() != Material.zerodayisaminecraftcheat || !BlockRailBase.a(world.zeroday(blockpos.zues()))) {
                        return this.zeroday.zerodayisaminecraftcheat(source, stack);
                    }
                    final IBlockState iblockstate2 = world.zeroday(blockpos.zues());
                    final BlockRailBase.zerodayisaminecraftcheat blockrailbase$enumraildirection2 = (iblockstate2.sigma() instanceof BlockRailBase) ? iblockstate2.zerodayisaminecraftcheat(((BlockRailBase)iblockstate2.sigma()).J()) : BlockRailBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
                    if (enumfacing != EnumFacing.zerodayisaminecraftcheat && blockrailbase$enumraildirection2.sigma()) {
                        d4 = -0.4;
                    }
                    else {
                        d4 = -0.9;
                    }
                }
                final EntityMinecart entityminecart = EntityMinecart.zerodayisaminecraftcheat(world, d0, d2 + d4, d3, ((ItemMinecart)stack.zerodayisaminecraftcheat()).momgetthecamera);
                if (stack.k()) {
                    entityminecart.pandora(stack.i());
                }
                world.zerodayisaminecraftcheat(entityminecart);
                stack.zerodayisaminecraftcheat(1);
                return stack;
            }
            
            @Override
            protected void zerodayisaminecraftcheat(final IBlockSource source) {
                source.zerodayisaminecraftcheat().zeroday(1000, source.zues(), 0);
            }
        };
    }
    
    public ItemMinecart(final EntityMinecart.zerodayisaminecraftcheat type) {
        this.pandora = 1;
        this.momgetthecamera = type;
        this.zerodayisaminecraftcheat(CreativeTabs.zues);
        BlockDispenser.F.zerodayisaminecraftcheat(this, ItemMinecart.vape);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final IBlockState iblockstate = worldIn.zeroday(pos);
        if (BlockRailBase.a(iblockstate)) {
            if (!worldIn.r) {
                final BlockRailBase.zerodayisaminecraftcheat blockrailbase$enumraildirection = (iblockstate.sigma() instanceof BlockRailBase) ? iblockstate.zerodayisaminecraftcheat(((BlockRailBase)iblockstate.sigma()).J()) : BlockRailBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
                double d0 = 0.0;
                if (blockrailbase$enumraildirection.sigma()) {
                    d0 = 0.5;
                }
                final EntityMinecart entityminecart = EntityMinecart.zerodayisaminecraftcheat(worldIn, pos.zerodayisaminecraftcheat() + 0.5, pos.zeroday() + 0.0625 + d0, pos.sigma() + 0.5, this.momgetthecamera);
                if (stack.k()) {
                    entityminecart.pandora(stack.i());
                }
                worldIn.zerodayisaminecraftcheat(entityminecart);
            }
            --stack.zeroday;
            return true;
        }
        return false;
    }
}

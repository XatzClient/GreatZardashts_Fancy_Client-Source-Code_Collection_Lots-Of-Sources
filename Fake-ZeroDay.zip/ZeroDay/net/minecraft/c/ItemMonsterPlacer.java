// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import java.util.Iterator;
import java.util.List;
import net.minecraft.vape.IEntityLivingData;
import net.minecraft.o.MathHelper;
import net.minecraft.m.StatList;
import net.minecraft.vape.EntityLiving;
import net.minecraft.zerodayisaminecraftcheat.BlockLiquid;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.vape.Entity;
import net.minecraft.n.MobSpawnerBaseLogic;
import net.minecraft.n.TileEntity;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.zerodayisaminecraftcheat.BlockFence;
import net.minecraft.n.TileEntityMobSpawner;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.EntityList;
import net.minecraft.o.StatCollector;
import net.minecraft.pandora.CreativeTabs;

public class ItemMonsterPlacer extends Item
{
    public ItemMonsterPlacer() {
        this.zerodayisaminecraftcheat(true);
        this.zerodayisaminecraftcheat(CreativeTabs.flux);
    }
    
    @Override
    public String vape(final ItemStack stack) {
        String s = new StringBuilder().append(StatCollector.zerodayisaminecraftcheat(String.valueOf(this.momgetthecamera()) + ".name")).toString().trim();
        final String s2 = EntityList.zeroday(stack.momgetthecamera());
        if (s2 != null) {
            s = String.valueOf(s) + " " + StatCollector.zerodayisaminecraftcheat("entity." + s2 + ".name");
        }
        return s;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        final EntityList.zerodayisaminecraftcheat entitylist$entityegginfo = EntityList.zerodayisaminecraftcheat.get(stack.momgetthecamera());
        return (entitylist$entityegginfo != null) ? ((renderPass == 0) ? entitylist$entityegginfo.zeroday : entitylist$entityegginfo.sigma) : 16777215;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (worldIn.r) {
            return true;
        }
        if (!playerIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(side), side, stack)) {
            return false;
        }
        final IBlockState iblockstate = worldIn.zeroday(pos);
        if (iblockstate.sigma() == Blocks.U) {
            final TileEntity tileentity = worldIn.zerodayisaminecraftcheat(pos);
            if (tileentity instanceof TileEntityMobSpawner) {
                final MobSpawnerBaseLogic mobspawnerbaselogic = ((TileEntityMobSpawner)tileentity).zeroday();
                mobspawnerbaselogic.zerodayisaminecraftcheat(EntityList.zeroday(stack.momgetthecamera()));
                tileentity.t();
                worldIn.a(pos);
                if (!playerIn.bz.pandora) {
                    --stack.zeroday;
                }
                return true;
            }
        }
        pos = pos.zerodayisaminecraftcheat(side);
        double d0 = 0.0;
        if (side == EnumFacing.zeroday && iblockstate instanceof BlockFence) {
            d0 = 0.5;
        }
        final Entity entity = zerodayisaminecraftcheat(worldIn, stack.momgetthecamera(), pos.zerodayisaminecraftcheat() + 0.5, pos.zeroday() + d0, pos.sigma() + 0.5);
        if (entity != null) {
            if (entity instanceof EntityLivingBase && stack.k()) {
                entity.pandora(stack.i());
            }
            if (!playerIn.bz.pandora) {
                --stack.zeroday;
            }
        }
        return true;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (worldIn.r) {
            return itemStackIn;
        }
        final MovingObjectPosition movingobjectposition = this.zerodayisaminecraftcheat(worldIn, playerIn, true);
        if (movingobjectposition == null) {
            return itemStackIn;
        }
        if (movingobjectposition.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
            final BlockPos blockpos = movingobjectposition.zerodayisaminecraftcheat();
            if (!worldIn.zerodayisaminecraftcheat(playerIn, blockpos)) {
                return itemStackIn;
            }
            if (!playerIn.zerodayisaminecraftcheat(blockpos, movingobjectposition.zeroday, itemStackIn)) {
                return itemStackIn;
            }
            if (worldIn.zeroday(blockpos).sigma() instanceof BlockLiquid) {
                final Entity entity = zerodayisaminecraftcheat(worldIn, itemStackIn.momgetthecamera(), blockpos.zerodayisaminecraftcheat() + 0.5, blockpos.zeroday() + 0.5, blockpos.sigma() + 0.5);
                if (entity != null) {
                    if (entity instanceof EntityLivingBase && itemStackIn.k()) {
                        ((EntityLiving)entity).pandora(itemStackIn.i());
                    }
                    if (!playerIn.bz.pandora) {
                        --itemStackIn.zeroday;
                    }
                    playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
                }
            }
        }
        return itemStackIn;
    }
    
    public static Entity zerodayisaminecraftcheat(final World worldIn, final int entityID, final double x, final double y, final double z) {
        if (!EntityList.zerodayisaminecraftcheat.containsKey(entityID)) {
            return null;
        }
        Entity entity = null;
        for (int i = 0; i < 1; ++i) {
            entity = EntityList.zerodayisaminecraftcheat(entityID, worldIn);
            if (entity instanceof EntityLivingBase) {
                final EntityLiving entityliving = (EntityLiving)entity;
                entity.zeroday(x, y, z, MathHelper.vape(worldIn.g.nextFloat() * 360.0f), 0.0f);
                entityliving.aN = entityliving.y;
                entityliving.aL = entityliving.y;
                entityliving.zerodayisaminecraftcheat(worldIn.v(new BlockPos(entityliving)), null);
                worldIn.zerodayisaminecraftcheat(entity);
                entityliving.aO();
            }
        }
        return entity;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        for (final EntityList.zerodayisaminecraftcheat entitylist$entityegginfo : EntityList.zerodayisaminecraftcheat.values()) {
            subItems.add(new ItemStack(itemIn, 1, entitylist$entityegginfo.zerodayisaminecraftcheat));
        }
    }
}

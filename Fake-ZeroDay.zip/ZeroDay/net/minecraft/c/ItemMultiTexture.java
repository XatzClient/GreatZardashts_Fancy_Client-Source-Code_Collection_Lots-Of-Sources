// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import com.google.common.base.Function;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemMultiTexture extends ItemBlock
{
    protected final Block momgetthecamera;
    protected final Function<ItemStack, String> a;
    
    public ItemMultiTexture(final Block block, final Block block2, final Function<ItemStack, String> nameFunction) {
        super(block);
        this.momgetthecamera = block2;
        this.a = nameFunction;
        this.pandora(0);
        this.zerodayisaminecraftcheat(true);
    }
    
    public ItemMultiTexture(final Block block, final Block block2, final String[] namesByMeta) {
        this(block, block2, (Function<ItemStack, String>)new Function<ItemStack, String>() {
            public String zerodayisaminecraftcheat(final ItemStack p_apply_1_) {
                int i = p_apply_1_.momgetthecamera();
                if (i < 0 || i >= namesByMeta.length) {
                    i = 0;
                }
                return namesByMeta[i];
            }
        });
    }
    
    @Override
    public int sigma(final int damage) {
        return damage;
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        return String.valueOf(super.momgetthecamera()) + "." + (String)this.a.apply((Object)stack);
    }
}

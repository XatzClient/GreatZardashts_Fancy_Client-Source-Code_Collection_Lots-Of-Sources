// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemNameTag extends Item
{
    public ItemNameTag() {
        this.zerodayisaminecraftcheat(CreativeTabs.a);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final EntityLivingBase target) {
        if (!stack.k()) {
            return false;
        }
        if (target instanceof EntityLiving) {
            final EntityLiving entityliving = (EntityLiving)target;
            entityliving.pandora(stack.i());
            entityliving.bb();
            --stack.zeroday;
            return true;
        }
        return super.zerodayisaminecraftcheat(stack, playerIn, target);
    }
}

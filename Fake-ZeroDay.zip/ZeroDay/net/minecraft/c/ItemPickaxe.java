// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import com.google.common.collect.Sets;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Set;

public class ItemPickaxe extends ItemTool
{
    private static final Set<Block> a;
    
    static {
        a = Sets.newHashSet((Object[])new Block[] { Blocks.ck, Blocks.i, Blocks.zues, Blocks.w, Blocks.Z, Blocks.Y, Blocks.L, Blocks.v, Blocks.J, Blocks.g, Blocks.aA, Blocks.K, Blocks.h, Blocks.q, Blocks.p, Blocks.av, Blocks.Q, Blocks.aN, Blocks.ct, Blocks.an, Blocks.au, Blocks.s, Blocks.cE, Blocks.zeroday, Blocks.M });
    }
    
    protected ItemPickaxe(final zerodayisaminecraftcheat material) {
        super(2.0f, material, ItemPickaxe.a);
    }
    
    @Override
    public boolean zeroday(final Block blockIn) {
        return (blockIn == Blocks.R) ? (this.momgetthecamera.pandora() == 3) : ((blockIn != Blocks.Z && blockIn != Blocks.Y) ? ((blockIn != Blocks.bH && blockIn != Blocks.bL) ? ((blockIn != Blocks.J && blockIn != Blocks.g) ? ((blockIn != Blocks.K && blockIn != Blocks.h) ? ((blockIn != Blocks.q && blockIn != Blocks.p) ? ((blockIn != Blocks.au && blockIn != Blocks.av) ? (blockIn.flux() == Material.zues || blockIn.flux() == Material.flux || blockIn.flux() == Material.vape) : (this.momgetthecamera.pandora() >= 2)) : (this.momgetthecamera.pandora() >= 1)) : (this.momgetthecamera.pandora() >= 1)) : (this.momgetthecamera.pandora() >= 2)) : (this.momgetthecamera.pandora() >= 2)) : (this.momgetthecamera.pandora() >= 2));
    }
    
    @Override
    public float zerodayisaminecraftcheat(final ItemStack stack, final Block block) {
        return (block.flux() != Material.flux && block.flux() != Material.vape && block.flux() != Material.zues) ? super.zerodayisaminecraftcheat(stack, block) : this.vape;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import com.google.common.collect.Multimap;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.AttributeModifier;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.IAttribute;
import com.google.common.collect.HashMultimap;
import net.minecraft.o.StatCollector;
import net.minecraft.g.Potion;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.momgetthecamera.EntityPotion;
import net.minecraft.vape.Entity;
import java.util.Iterator;
import net.minecraft.a.Items;
import net.minecraft.m.StatList;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.d.NBTTagList;
import net.minecraft.g.PotionHelper;
import com.google.common.collect.Lists;
import net.minecraft.pandora.CreativeTabs;
import com.google.common.collect.Maps;
import net.minecraft.g.PotionEffect;
import java.util.List;
import java.util.Map;

public class ItemPotion extends Item
{
    private Map<Integer, List<PotionEffect>> vape;
    private static final Map<List<PotionEffect>, Integer> momgetthecamera;
    
    static {
        momgetthecamera = Maps.newLinkedHashMap();
    }
    
    public ItemPotion() {
        this.vape = (Map<Integer, List<PotionEffect>>)Maps.newHashMap();
        this.zeroday(1);
        this.zerodayisaminecraftcheat(true);
        this.pandora(0);
        this.zerodayisaminecraftcheat(CreativeTabs.c);
    }
    
    public List<PotionEffect> c(final ItemStack stack) {
        if (stack.f() && stack.g().zeroday("CustomPotionEffects", 9)) {
            final List<PotionEffect> list1 = (List<PotionEffect>)Lists.newArrayList();
            final NBTTagList nbttaglist = stack.g().sigma("CustomPotionEffects", 10);
            for (int i = 0; i < nbttaglist.zues(); ++i) {
                final NBTTagCompound nbttagcompound = nbttaglist.zeroday(i);
                final PotionEffect potioneffect = PotionEffect.zeroday(nbttagcompound);
                if (potioneffect != null) {
                    list1.add(potioneffect);
                }
            }
            return list1;
        }
        List<PotionEffect> list2 = this.vape.get(stack.momgetthecamera());
        if (list2 == null) {
            list2 = (List<PotionEffect>)PotionHelper.zeroday(stack.momgetthecamera(), false);
            this.vape.put(stack.momgetthecamera(), list2);
        }
        return list2;
    }
    
    public List<PotionEffect> zues(final int meta) {
        List<PotionEffect> list = this.vape.get(meta);
        if (list == null) {
            list = (List<PotionEffect>)PotionHelper.zeroday(meta, false);
            this.vape.put(meta, list);
        }
        return list;
    }
    
    @Override
    public ItemStack zeroday(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
        if (!playerIn.bz.pandora) {
            --stack.zeroday;
        }
        if (!worldIn.r) {
            final List<PotionEffect> list = this.c(stack);
            if (list != null) {
                for (final PotionEffect potioneffect : list) {
                    playerIn.zerodayisaminecraftcheat(new PotionEffect(potioneffect));
                }
            }
        }
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        if (!playerIn.bz.pandora) {
            if (stack.zeroday <= 0) {
                return new ItemStack(Items.bs);
            }
            playerIn.d.zerodayisaminecraftcheat(new ItemStack(Items.bs));
        }
        return stack;
    }
    
    @Override
    public int pandora(final ItemStack stack) {
        return 32;
    }
    
    @Override
    public EnumAction sigma(final ItemStack stack) {
        return EnumAction.sigma;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        if (flux(itemStackIn.momgetthecamera())) {
            if (!playerIn.bz.pandora) {
                --itemStackIn.zeroday;
            }
            worldIn.zerodayisaminecraftcheat((Entity)playerIn, "random.bow", 0.5f, 0.4f / (ItemPotion.sigma.nextFloat() * 0.4f + 0.8f));
            if (!worldIn.r) {
                worldIn.zerodayisaminecraftcheat(new EntityPotion(worldIn, playerIn, itemStackIn));
            }
            playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
            return itemStackIn;
        }
        playerIn.zeroday(itemStackIn, this.pandora(itemStackIn));
        return itemStackIn;
    }
    
    public static boolean flux(final int meta) {
        return (meta & 0x4000) != 0x0;
    }
    
    public int vape(final int meta) {
        return PotionHelper.zerodayisaminecraftcheat(meta, false);
    }
    
    @Override
    public int zerodayisaminecraftcheat(final ItemStack stack, final int renderPass) {
        return (renderPass > 0) ? 16777215 : this.vape(stack.momgetthecamera());
    }
    
    public boolean momgetthecamera(final int meta) {
        final List<PotionEffect> list = this.zues(meta);
        if (list != null && !list.isEmpty()) {
            for (final PotionEffect potioneffect : list) {
                if (Potion.zerodayisaminecraftcheat[potioneffect.zerodayisaminecraftcheat()].sigma()) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }
    
    @Override
    public String vape(final ItemStack stack) {
        if (stack.momgetthecamera() == 0) {
            return StatCollector.zerodayisaminecraftcheat("item.emptyPotion.name").trim();
        }
        String s = "";
        if (flux(stack.momgetthecamera())) {
            s = String.valueOf(StatCollector.zerodayisaminecraftcheat("potion.prefix.grenade").trim()) + " ";
        }
        final List<PotionEffect> list = Items.br.c(stack);
        if (list != null && !list.isEmpty()) {
            String s2 = list.get(0).flux();
            s2 = String.valueOf(s2) + ".postfix";
            return String.valueOf(s) + StatCollector.zerodayisaminecraftcheat(s2).trim();
        }
        final String s3 = PotionHelper.zeroday(stack.momgetthecamera());
        return String.valueOf(StatCollector.zerodayisaminecraftcheat(s3).trim()) + " " + super.vape(stack);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        if (stack.momgetthecamera() != 0) {
            final List<PotionEffect> list = Items.br.c(stack);
            final Multimap<String, AttributeModifier> multimap = (Multimap<String, AttributeModifier>)HashMultimap.create();
            if (list != null && !list.isEmpty()) {
                for (final PotionEffect potioneffect : list) {
                    String s1 = StatCollector.zerodayisaminecraftcheat(potioneffect.flux()).trim();
                    final Potion potion = Potion.zerodayisaminecraftcheat[potioneffect.zerodayisaminecraftcheat()];
                    final Map<IAttribute, AttributeModifier> map = potion.c();
                    if (map != null && map.size() > 0) {
                        for (final Map.Entry<IAttribute, AttributeModifier> entry : map.entrySet()) {
                            final AttributeModifier attributemodifier = entry.getValue();
                            final AttributeModifier attributemodifier2 = new AttributeModifier(attributemodifier.zeroday(), potion.zerodayisaminecraftcheat(potioneffect.sigma(), attributemodifier), attributemodifier.sigma());
                            multimap.put((Object)entry.getKey().zerodayisaminecraftcheat(), (Object)attributemodifier2);
                        }
                    }
                    if (potioneffect.sigma() > 0) {
                        s1 = String.valueOf(s1) + " " + StatCollector.zerodayisaminecraftcheat("potion.potency." + potioneffect.sigma()).trim();
                    }
                    if (potioneffect.zeroday() > 20) {
                        s1 = String.valueOf(s1) + " (" + Potion.zerodayisaminecraftcheat(potioneffect) + ")";
                    }
                    if (potion.vape()) {
                        tooltip.add(EnumChatFormatting.e + s1);
                    }
                    else {
                        tooltip.add(EnumChatFormatting.momgetthecamera + s1);
                    }
                }
            }
            else {
                final String s2 = StatCollector.zerodayisaminecraftcheat("potion.empty").trim();
                tooltip.add(EnumChatFormatting.momgetthecamera + s2);
            }
            if (!multimap.isEmpty()) {
                tooltip.add("");
                tooltip.add(EnumChatFormatting.flux + StatCollector.zerodayisaminecraftcheat("potion.effects.whenDrank"));
                for (final Map.Entry<String, AttributeModifier> entry2 : multimap.entries()) {
                    final AttributeModifier attributemodifier3 = entry2.getValue();
                    final double d0 = attributemodifier3.pandora();
                    double d2;
                    if (attributemodifier3.sigma() != 1 && attributemodifier3.sigma() != 2) {
                        d2 = attributemodifier3.pandora();
                    }
                    else {
                        d2 = attributemodifier3.pandora() * 100.0;
                    }
                    if (d0 > 0.0) {
                        tooltip.add(EnumChatFormatting.b + StatCollector.zerodayisaminecraftcheat("attribute.modifier.plus." + attributemodifier3.sigma(), ItemStack.zerodayisaminecraftcheat.format(d2), StatCollector.zerodayisaminecraftcheat("attribute.name." + entry2.getKey())));
                    }
                    else {
                        if (d0 >= 0.0) {
                            continue;
                        }
                        d2 *= -1.0;
                        tooltip.add(EnumChatFormatting.e + StatCollector.zerodayisaminecraftcheat("attribute.modifier.take." + attributemodifier3.sigma(), ItemStack.zerodayisaminecraftcheat.format(d2), StatCollector.zerodayisaminecraftcheat("attribute.name." + entry2.getKey())));
                    }
                }
            }
        }
    }
    
    @Override
    public boolean momgetthecamera(final ItemStack stack) {
        final List<PotionEffect> list = this.c(stack);
        return list != null && !list.isEmpty();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        super.zerodayisaminecraftcheat(itemIn, tab, subItems);
        if (ItemPotion.momgetthecamera.isEmpty()) {
            for (int i = 0; i <= 15; ++i) {
                for (int j = 0; j <= 1; ++j) {
                    int lvt_6_1_;
                    if (j == 0) {
                        lvt_6_1_ = (i | 0x2000);
                    }
                    else {
                        lvt_6_1_ = (i | 0x4000);
                    }
                    for (int l = 0; l <= 2; ++l) {
                        int i2 = lvt_6_1_;
                        if (l != 0) {
                            if (l == 1) {
                                i2 = (lvt_6_1_ | 0x20);
                            }
                            else if (l == 2) {
                                i2 = (lvt_6_1_ | 0x40);
                            }
                        }
                        final List<PotionEffect> list = (List<PotionEffect>)PotionHelper.zeroday(i2, false);
                        if (list != null && !list.isEmpty()) {
                            ItemPotion.momgetthecamera.put(list, i2);
                        }
                    }
                }
            }
        }
        for (final int j2 : ItemPotion.momgetthecamera.values()) {
            subItems.add(new ItemStack(itemIn, 1, j2));
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.StatCollector;
import java.util.List;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.m.StatList;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockJukebox;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;
import com.google.common.collect.Maps;
import java.util.Map;

public class ItemRecord extends Item
{
    private static final Map<String, ItemRecord> momgetthecamera;
    public final String vape;
    
    static {
        momgetthecamera = Maps.newHashMap();
    }
    
    protected ItemRecord(final String name) {
        this.vape = name;
        this.pandora = 1;
        this.zerodayisaminecraftcheat(CreativeTabs.flux);
        ItemRecord.momgetthecamera.put("records." + name, this);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final IBlockState iblockstate = worldIn.zeroday(pos);
        if (iblockstate.sigma() != Blocks.aF || iblockstate.zerodayisaminecraftcheat((IProperty<Boolean>)BlockJukebox.D)) {
            return false;
        }
        if (worldIn.r) {
            return true;
        }
        ((BlockJukebox)Blocks.aF).zerodayisaminecraftcheat(worldIn, pos, iblockstate, stack);
        worldIn.zerodayisaminecraftcheat(null, 1005, pos, Item.zerodayisaminecraftcheat(this));
        --stack.zeroday;
        playerIn.zerodayisaminecraftcheat(StatList.P);
        return true;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final List<String> tooltip, final boolean advanced) {
        tooltip.add(this.j());
    }
    
    public String j() {
        return StatCollector.zerodayisaminecraftcheat("item.record." + this.vape + ".desc");
    }
    
    @Override
    public EnumRarity a(final ItemStack stack) {
        return EnumRarity.sigma;
    }
    
    public static ItemRecord pandora(final String name) {
        return ItemRecord.momgetthecamera.get(name);
    }
}

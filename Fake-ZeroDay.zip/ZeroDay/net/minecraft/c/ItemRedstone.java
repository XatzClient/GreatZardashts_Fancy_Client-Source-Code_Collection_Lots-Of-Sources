// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.a.Blocks;
import net.minecraft.vape.Entity;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemRedstone extends Item
{
    public ItemRedstone() {
        this.zerodayisaminecraftcheat(CreativeTabs.pandora);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final boolean flag = worldIn.zeroday(pos).sigma().zerodayisaminecraftcheat(worldIn, pos);
        final BlockPos blockpos = flag ? pos : pos.zerodayisaminecraftcheat(side);
        if (!playerIn.zerodayisaminecraftcheat(blockpos, side, stack)) {
            return false;
        }
        final Block block = worldIn.zeroday(blockpos).sigma();
        if (!worldIn.zerodayisaminecraftcheat(block, blockpos, false, side, null, stack)) {
            return false;
        }
        if (Blocks.X.pandora(worldIn, blockpos)) {
            --stack.zeroday;
            worldIn.zeroday(blockpos, Blocks.X.G());
            return true;
        }
        return false;
    }
}

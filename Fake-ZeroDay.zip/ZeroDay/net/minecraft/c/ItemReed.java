// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockSnow;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemReed extends Item
{
    private Block vape;
    
    public ItemReed(final Block block) {
        this.vape = block;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final IBlockState iblockstate = worldIn.zeroday(pos);
        final Block block = iblockstate.sigma();
        if (block == Blocks.az && iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockSnow.D) < 1) {
            side = EnumFacing.zeroday;
        }
        else if (!block.zerodayisaminecraftcheat(worldIn, pos)) {
            pos = pos.zerodayisaminecraftcheat(side);
        }
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (stack.zeroday == 0) {
            return false;
        }
        if (worldIn.zerodayisaminecraftcheat(this.vape, pos, false, side, null, stack)) {
            IBlockState iblockstate2 = this.vape.zerodayisaminecraftcheat(worldIn, pos, side, hitX, hitY, hitZ, 0, playerIn);
            if (worldIn.zerodayisaminecraftcheat(pos, iblockstate2, 3)) {
                iblockstate2 = worldIn.zeroday(pos);
                if (iblockstate2.sigma() == this.vape) {
                    ItemBlock.zerodayisaminecraftcheat(worldIn, playerIn, pos, stack);
                    iblockstate2.sigma().zerodayisaminecraftcheat(worldIn, pos, iblockstate2, playerIn, stack);
                }
                worldIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() + 0.5f, pos.zeroday() + 0.5f, pos.sigma() + 0.5f, this.vape.x.zeroday(), (this.vape.x.pandora() + 1.0f) / 2.0f, this.vape.x.zues() * 0.8f);
                --stack.zeroday;
                return true;
            }
        }
        return false;
    }
}

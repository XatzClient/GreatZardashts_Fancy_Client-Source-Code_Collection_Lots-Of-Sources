// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.Entity;
import net.minecraft.vape.flux.EntityPig;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemSaddle extends Item
{
    public ItemSaddle() {
        this.pandora = 1;
        this.zerodayisaminecraftcheat(CreativeTabs.zues);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final EntityLivingBase target) {
        if (target instanceof EntityPig) {
            final EntityPig entitypig = (EntityPig)target;
            if (!entitypig.cd() && !entitypig.n_()) {
                entitypig.d(true);
                entitypig.o.zerodayisaminecraftcheat(entitypig, "mob.horse.leather", 0.5f, 1.0f);
                --stack.zeroday;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityLivingBase target, final EntityLivingBase attacker) {
        this.zerodayisaminecraftcheat(stack, null, target);
        return true;
    }
}

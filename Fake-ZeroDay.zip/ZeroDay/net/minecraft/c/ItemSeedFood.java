// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemSeedFood extends ItemFood
{
    private Block momgetthecamera;
    private Block a;
    
    public ItemSeedFood(final int healAmount, final float saturation, final Block crops, final Block soil) {
        super(healAmount, saturation, false);
        this.momgetthecamera = crops;
        this.a = soil;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side != EnumFacing.zeroday) {
            return false;
        }
        if (!playerIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(side), side, stack)) {
            return false;
        }
        if (worldIn.zeroday(pos).sigma() == this.a && worldIn.pandora(pos.pandora())) {
            worldIn.zeroday(pos.pandora(), this.momgetthecamera.G());
            --stack.zeroday;
            return true;
        }
        return false;
    }
}

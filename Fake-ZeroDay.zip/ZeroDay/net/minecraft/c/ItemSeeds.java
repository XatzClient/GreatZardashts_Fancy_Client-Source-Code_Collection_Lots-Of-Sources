// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemSeeds extends Item
{
    private Block vape;
    private Block momgetthecamera;
    
    public ItemSeeds(final Block crops, final Block soil) {
        this.vape = crops;
        this.momgetthecamera = soil;
        this.zerodayisaminecraftcheat(CreativeTabs.d);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side != EnumFacing.zeroday) {
            return false;
        }
        if (!playerIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(side), side, stack)) {
            return false;
        }
        if (worldIn.zeroday(pos).sigma() == this.momgetthecamera && worldIn.pandora(pos.pandora())) {
            worldIn.zeroday(pos.pandora(), this.vape.G());
            --stack.zeroday;
            return true;
        }
        return false;
    }
}

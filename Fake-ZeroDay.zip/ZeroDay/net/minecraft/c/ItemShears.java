// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.q.World;
import net.minecraft.pandora.CreativeTabs;

public class ItemShears extends Item
{
    public ItemShears() {
        this.zeroday(1);
        this.pandora(238);
        this.zerodayisaminecraftcheat(CreativeTabs.a);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final Block blockIn, final BlockPos pos, final EntityLivingBase playerIn) {
        if (blockIn.flux() != Material.b && blockIn != Blocks.y && blockIn != Blocks.z && blockIn != Blocks.bf && blockIn != Blocks.bK && blockIn != Blocks.D) {
            return super.zerodayisaminecraftcheat(stack, worldIn, blockIn, pos, playerIn);
        }
        stack.zerodayisaminecraftcheat(1, playerIn);
        return true;
    }
    
    @Override
    public boolean zeroday(final Block blockIn) {
        return blockIn == Blocks.y || blockIn == Blocks.X || blockIn == Blocks.bK;
    }
    
    @Override
    public float zerodayisaminecraftcheat(final ItemStack stack, final Block block) {
        return (block != Blocks.y && block.flux() != Material.b) ? ((block == Blocks.D) ? 5.0f : super.zerodayisaminecraftcheat(stack, block)) : 15.0f;
    }
}

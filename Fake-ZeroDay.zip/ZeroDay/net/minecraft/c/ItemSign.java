// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.n.TileEntity;
import net.minecraft.n.TileEntitySign;
import net.minecraft.zerodayisaminecraftcheat.BlockWallSign;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockStandingSign;
import net.minecraft.o.MathHelper;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemSign extends Item
{
    public ItemSign() {
        this.pandora = 16;
        this.zerodayisaminecraftcheat(CreativeTabs.sigma);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side == EnumFacing.zerodayisaminecraftcheat) {
            return false;
        }
        if (!worldIn.zeroday(pos).sigma().flux().zeroday()) {
            return false;
        }
        pos = pos.zerodayisaminecraftcheat(side);
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (!Blocks.af.pandora(worldIn, pos)) {
            return false;
        }
        if (worldIn.r) {
            return true;
        }
        if (side == EnumFacing.zeroday) {
            final int i = MathHelper.sigma((playerIn.y + 180.0f) * 16.0f / 360.0f + 0.5) & 0xF;
            worldIn.zerodayisaminecraftcheat(pos, Blocks.af.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockStandingSign.D, i), 3);
        }
        else {
            worldIn.zerodayisaminecraftcheat(pos, Blocks.ap.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockWallSign.D, side), 3);
        }
        --stack.zeroday;
        final TileEntity tileentity = worldIn.zerodayisaminecraftcheat(pos);
        if (tileentity instanceof TileEntitySign && !ItemBlock.zerodayisaminecraftcheat(worldIn, playerIn, pos, stack)) {
            playerIn.zerodayisaminecraftcheat((TileEntitySign)tileentity);
        }
        return true;
    }
}

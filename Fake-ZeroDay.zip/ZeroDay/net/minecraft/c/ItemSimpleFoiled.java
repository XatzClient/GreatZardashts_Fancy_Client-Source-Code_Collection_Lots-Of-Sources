// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

public class ItemSimpleFoiled extends Item
{
    @Override
    public boolean momgetthecamera(final ItemStack stack) {
        return true;
    }
}

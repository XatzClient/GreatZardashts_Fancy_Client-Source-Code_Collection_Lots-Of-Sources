// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.d.NBTBase;
import net.minecraft.o.StatCollector;
import java.util.List;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.n.TileEntity;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.d.NBTUtil;
import net.minecraft.n.TileEntitySkull;
import net.minecraft.o.MathHelper;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockSkull;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.pandora.CreativeTabs;

public class ItemSkull extends Item
{
    private static final String[] vape;
    
    static {
        vape = new String[] { "skeleton", "wither", "zombie", "char", "creeper" };
    }
    
    public ItemSkull() {
        this.zerodayisaminecraftcheat(CreativeTabs.sigma);
        this.pandora(0);
        this.zerodayisaminecraftcheat(true);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (side == EnumFacing.zerodayisaminecraftcheat) {
            return false;
        }
        final IBlockState iblockstate = worldIn.zeroday(pos);
        final Block block = iblockstate.sigma();
        final boolean flag = block.zerodayisaminecraftcheat(worldIn, pos);
        if (!flag) {
            if (!worldIn.zeroday(pos).sigma().flux().zeroday()) {
                return false;
            }
            pos = pos.zerodayisaminecraftcheat(side);
        }
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        if (!Blocks.bW.pandora(worldIn, pos)) {
            return false;
        }
        if (!worldIn.r) {
            worldIn.zerodayisaminecraftcheat(pos, Blocks.bW.G().zerodayisaminecraftcheat((IProperty<Comparable>)BlockSkull.D, side), 3);
            int i = 0;
            if (side == EnumFacing.zeroday) {
                i = (MathHelper.sigma(playerIn.y * 16.0f / 360.0f + 0.5) & 0xF);
            }
            final TileEntity tileentity = worldIn.zerodayisaminecraftcheat(pos);
            if (tileentity instanceof TileEntitySkull) {
                final TileEntitySkull tileentityskull = (TileEntitySkull)tileentity;
                if (stack.momgetthecamera() == 3) {
                    GameProfile gameprofile = null;
                    if (stack.f()) {
                        final NBTTagCompound nbttagcompound = stack.g();
                        if (nbttagcompound.zeroday("SkullOwner", 10)) {
                            gameprofile = NBTUtil.zerodayisaminecraftcheat(nbttagcompound.e("SkullOwner"));
                        }
                        else if (nbttagcompound.zeroday("SkullOwner", 8) && nbttagcompound.b("SkullOwner").length() > 0) {
                            gameprofile = new GameProfile((UUID)null, nbttagcompound.b("SkullOwner"));
                        }
                    }
                    tileentityskull.zerodayisaminecraftcheat(gameprofile);
                }
                else {
                    tileentityskull.zerodayisaminecraftcheat(stack.momgetthecamera());
                }
                tileentityskull.zeroday(i);
                Blocks.bW.zerodayisaminecraftcheat(worldIn, pos, tileentityskull);
            }
            --stack.zeroday;
        }
        return true;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Item itemIn, final CreativeTabs tab, final List<ItemStack> subItems) {
        for (int i = 0; i < ItemSkull.vape.length; ++i) {
            subItems.add(new ItemStack(itemIn, 1, i));
        }
    }
    
    @Override
    public int sigma(final int damage) {
        return damage;
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        int i = stack.momgetthecamera();
        if (i < 0 || i >= ItemSkull.vape.length) {
            i = 0;
        }
        return String.valueOf(super.momgetthecamera()) + "." + ItemSkull.vape[i];
    }
    
    @Override
    public String vape(final ItemStack stack) {
        if (stack.momgetthecamera() == 3 && stack.f()) {
            if (stack.g().zeroday("SkullOwner", 8)) {
                return StatCollector.zerodayisaminecraftcheat("item.skull.player.name", stack.g().b("SkullOwner"));
            }
            if (stack.g().zeroday("SkullOwner", 10)) {
                final NBTTagCompound nbttagcompound = stack.g().e("SkullOwner");
                if (nbttagcompound.zeroday("Name", 8)) {
                    return StatCollector.zerodayisaminecraftcheat("item.skull.player.name", nbttagcompound.b("Name"));
                }
            }
        }
        return super.vape(stack);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final NBTTagCompound nbt) {
        super.zerodayisaminecraftcheat(nbt);
        if (nbt.zeroday("SkullOwner", 8) && nbt.b("SkullOwner").length() > 0) {
            GameProfile gameprofile = new GameProfile((UUID)null, nbt.b("SkullOwner"));
            gameprofile = TileEntitySkull.zeroday(gameprofile);
            nbt.zerodayisaminecraftcheat("SkullOwner", NBTUtil.zerodayisaminecraftcheat(new NBTTagCompound(), gameprofile));
            return true;
        }
        return false;
    }
}

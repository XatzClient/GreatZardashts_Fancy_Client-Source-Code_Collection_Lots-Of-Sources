// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.BlockSlab;

public class ItemSlab extends ItemBlock
{
    private final BlockSlab momgetthecamera;
    private final BlockSlab a;
    
    public ItemSlab(final Block block, final BlockSlab singleSlab, final BlockSlab doubleSlab) {
        super(block);
        this.momgetthecamera = singleSlab;
        this.a = doubleSlab;
        this.pandora(0);
        this.zerodayisaminecraftcheat(true);
    }
    
    @Override
    public int sigma(final int damage) {
        return damage;
    }
    
    @Override
    public String zeroday(final ItemStack stack) {
        return this.momgetthecamera.zues(stack.momgetthecamera());
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (stack.zeroday == 0) {
            return false;
        }
        if (!playerIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(side), side, stack)) {
            return false;
        }
        final Object object = this.momgetthecamera.zerodayisaminecraftcheat(stack);
        final IBlockState iblockstate = worldIn.zeroday(pos);
        if (iblockstate.sigma() == this.momgetthecamera) {
            final IProperty iproperty = this.momgetthecamera.K();
            final Comparable comparable = iblockstate.zerodayisaminecraftcheat((IProperty<Comparable>)iproperty);
            final BlockSlab.zerodayisaminecraftcheat blockslab$enumblockhalf = iblockstate.zerodayisaminecraftcheat(BlockSlab.D);
            if (((side == EnumFacing.zeroday && blockslab$enumblockhalf == BlockSlab.zerodayisaminecraftcheat.zeroday) || (side == EnumFacing.zerodayisaminecraftcheat && blockslab$enumblockhalf == BlockSlab.zerodayisaminecraftcheat.zerodayisaminecraftcheat)) && comparable == object) {
                final IBlockState iblockstate2 = this.a.G().zerodayisaminecraftcheat((IProperty<Comparable>)iproperty, comparable);
                if (worldIn.zeroday(this.a.zerodayisaminecraftcheat(worldIn, pos, iblockstate2)) && worldIn.zerodayisaminecraftcheat(pos, iblockstate2, 3)) {
                    worldIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() + 0.5f, pos.zeroday() + 0.5f, pos.sigma() + 0.5f, this.a.x.zeroday(), (this.a.x.pandora() + 1.0f) / 2.0f, this.a.x.zues() * 0.8f);
                    --stack.zeroday;
                }
                return true;
            }
        }
        return this.zerodayisaminecraftcheat(stack, worldIn, pos.zerodayisaminecraftcheat(side), object) || super.zerodayisaminecraftcheat(stack, playerIn, worldIn, pos, side, hitX, hitY, hitZ);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final World worldIn, BlockPos pos, final EnumFacing side, final EntityPlayer player, final ItemStack stack) {
        final BlockPos blockpos = pos;
        final IProperty iproperty = this.momgetthecamera.K();
        final Object object = this.momgetthecamera.zerodayisaminecraftcheat(stack);
        final IBlockState iblockstate = worldIn.zeroday(pos);
        if (iblockstate.sigma() == this.momgetthecamera) {
            final boolean flag = iblockstate.zerodayisaminecraftcheat(BlockSlab.D) == BlockSlab.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
            if (((side == EnumFacing.zeroday && !flag) || (side == EnumFacing.zerodayisaminecraftcheat && flag)) && object == iblockstate.zerodayisaminecraftcheat((IProperty<Comparable>)iproperty)) {
                return true;
            }
        }
        pos = pos.zerodayisaminecraftcheat(side);
        final IBlockState iblockstate2 = worldIn.zeroday(pos);
        return (iblockstate2.sigma() == this.momgetthecamera && object == iblockstate2.zerodayisaminecraftcheat((IProperty<Comparable>)iproperty)) || super.zerodayisaminecraftcheat(worldIn, blockpos, side, player, stack);
    }
    
    private boolean zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final BlockPos pos, final Object variantInStack) {
        final IBlockState iblockstate = worldIn.zeroday(pos);
        if (iblockstate.sigma() == this.momgetthecamera) {
            final Comparable comparable = (Comparable)iblockstate.zerodayisaminecraftcheat(this.momgetthecamera.K());
            if (comparable == variantInStack) {
                final IBlockState iblockstate2 = this.a.G().zerodayisaminecraftcheat(this.momgetthecamera.K(), comparable);
                if (worldIn.zeroday(this.a.zerodayisaminecraftcheat(worldIn, pos, iblockstate2)) && worldIn.zerodayisaminecraftcheat(pos, iblockstate2, 3)) {
                    worldIn.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() + 0.5f, pos.zeroday() + 0.5f, pos.sigma() + 0.5f, this.a.x.zeroday(), (this.a.x.pandora() + 1.0f) / 2.0f, this.a.x.zues() * 0.8f);
                    --stack.zeroday;
                }
                return true;
            }
        }
        return false;
    }
}

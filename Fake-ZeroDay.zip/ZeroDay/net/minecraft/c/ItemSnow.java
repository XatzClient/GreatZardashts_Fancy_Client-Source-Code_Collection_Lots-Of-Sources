// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.o.AxisAlignedBB;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockSnow;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ItemSnow extends ItemBlock
{
    public ItemSnow(final Block block) {
        super(block);
        this.pandora(0);
        this.zerodayisaminecraftcheat(true);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        if (stack.zeroday == 0) {
            return false;
        }
        if (!playerIn.zerodayisaminecraftcheat(pos, side, stack)) {
            return false;
        }
        IBlockState iblockstate = worldIn.zeroday(pos);
        Block block = iblockstate.sigma();
        BlockPos blockpos = pos;
        if ((side != EnumFacing.zeroday || block != this.vape) && !block.zerodayisaminecraftcheat(worldIn, pos)) {
            blockpos = pos.zerodayisaminecraftcheat(side);
            iblockstate = worldIn.zeroday(blockpos);
            block = iblockstate.sigma();
        }
        if (block == this.vape) {
            final int i = iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockSnow.D);
            if (i <= 7) {
                final IBlockState iblockstate2 = iblockstate.zerodayisaminecraftcheat((IProperty<Comparable>)BlockSnow.D, i + 1);
                final AxisAlignedBB axisalignedbb = this.vape.zerodayisaminecraftcheat(worldIn, blockpos, iblockstate2);
                if (axisalignedbb != null && worldIn.zeroday(axisalignedbb) && worldIn.zerodayisaminecraftcheat(blockpos, iblockstate2, 2)) {
                    worldIn.zerodayisaminecraftcheat(blockpos.zerodayisaminecraftcheat() + 0.5f, blockpos.zeroday() + 0.5f, blockpos.sigma() + 0.5f, this.vape.x.zeroday(), (this.vape.x.pandora() + 1.0f) / 2.0f, this.vape.x.zues() * 0.8f);
                    --stack.zeroday;
                    return true;
                }
            }
        }
        return super.zerodayisaminecraftcheat(stack, playerIn, worldIn, blockpos, side, hitX, hitY, hitZ);
    }
    
    @Override
    public int sigma(final int damage) {
        return damage;
    }
}

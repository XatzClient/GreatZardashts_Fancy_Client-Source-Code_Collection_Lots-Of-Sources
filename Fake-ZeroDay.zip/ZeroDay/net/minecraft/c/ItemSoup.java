// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.a.Items;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;

public class ItemSoup extends ItemFood
{
    public ItemSoup(final int healAmount) {
        super(healAmount, false);
        this.zeroday(1);
    }
    
    @Override
    public ItemStack zeroday(final ItemStack stack, final World worldIn, final EntityPlayer playerIn) {
        super.zeroday(stack, worldIn, playerIn);
        return new ItemStack(Items.r);
    }
}

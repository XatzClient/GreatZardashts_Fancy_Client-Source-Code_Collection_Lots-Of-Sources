// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import com.google.common.collect.Sets;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Set;

public class ItemSpade extends ItemTool
{
    private static final Set<Block> a;
    
    static {
        a = Sets.newHashSet((Object[])new Block[] { Blocks.aD, Blocks.pandora, Blocks.ac, Blocks.sigma, Blocks.f, Blocks.bo, Blocks.e, Blocks.aB, Blocks.az, Blocks.aO });
    }
    
    public ItemSpade(final zerodayisaminecraftcheat material) {
        super(1.0f, material, ItemSpade.a);
    }
    
    @Override
    public boolean zeroday(final Block blockIn) {
        return blockIn == Blocks.az || blockIn == Blocks.aB;
    }
}

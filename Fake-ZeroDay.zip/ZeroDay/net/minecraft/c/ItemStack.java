// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.momgetthecamera.HoverEvent;
import net.minecraft.o.ChatComponentText;
import net.minecraft.o.IChatComponent;
import net.minecraft.vape.SharedMonsterAttributes;
import com.google.common.collect.HashMultimap;
import java.util.Iterator;
import com.google.common.collect.Multimap;
import net.minecraft.vape.EnumCreatureAttribute;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.AttributeModifier;
import java.util.Map;
import net.minecraft.o.StatCollector;
import net.minecraft.a.Items;
import net.minecraft.o.EnumChatFormatting;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.d.NBTTagList;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.flux.EnchantmentDurability;
import net.minecraft.flux.EnchantmentHelper;
import net.minecraft.flux.Enchantment;
import java.util.Random;
import net.minecraft.d.NBTBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.m.StatList;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.d.NBTTagCompound;
import java.text.DecimalFormat;

public final class ItemStack
{
    public static final DecimalFormat zerodayisaminecraftcheat;
    public int zeroday;
    public int sigma;
    private Item pandora;
    private NBTTagCompound zues;
    private int flux;
    private EntityItemFrame vape;
    private Block momgetthecamera;
    private boolean a;
    private Block b;
    private boolean c;
    
    static {
        zerodayisaminecraftcheat = new DecimalFormat("#.###");
    }
    
    public ItemStack(final Block blockIn) {
        this(blockIn, 1);
    }
    
    public ItemStack(final Block blockIn, final int amount) {
        this(blockIn, amount, 0);
    }
    
    public ItemStack(final Block blockIn, final int amount, final int meta) {
        this(Item.zerodayisaminecraftcheat(blockIn), amount, meta);
    }
    
    public ItemStack(final Item itemIn) {
        this(itemIn, 1);
    }
    
    public ItemStack(final Item itemIn, final int amount) {
        this(itemIn, amount, 0);
    }
    
    public ItemStack(final Item itemIn, final int amount, final int meta) {
        this.momgetthecamera = null;
        this.a = false;
        this.b = null;
        this.c = false;
        this.pandora = itemIn;
        this.zeroday = amount;
        this.flux = meta;
        if (this.flux < 0) {
            this.flux = 0;
        }
    }
    
    public static ItemStack zerodayisaminecraftcheat(final NBTTagCompound nbt) {
        final ItemStack itemstack = new ItemStack();
        itemstack.sigma(nbt);
        return (itemstack.zerodayisaminecraftcheat() != null) ? itemstack : null;
    }
    
    private ItemStack() {
        this.momgetthecamera = null;
        this.a = false;
        this.b = null;
        this.c = false;
    }
    
    public ItemStack zerodayisaminecraftcheat(final int amount) {
        final ItemStack itemstack = new ItemStack(this.pandora, amount, this.flux);
        if (this.zues != null) {
            itemstack.zues = (NBTTagCompound)this.zues.zeroday();
        }
        this.zeroday -= amount;
        return itemstack;
    }
    
    public Item zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final boolean flag = this.zerodayisaminecraftcheat().zerodayisaminecraftcheat(this, playerIn, worldIn, pos, side, hitX, hitY, hitZ);
        if (flag) {
            playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this.pandora)]);
        }
        return flag;
    }
    
    public float zerodayisaminecraftcheat(final Block blockIn) {
        return this.zerodayisaminecraftcheat().zerodayisaminecraftcheat(this, blockIn);
    }
    
    public ItemStack zerodayisaminecraftcheat(final World worldIn, final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat().zerodayisaminecraftcheat(this, worldIn, playerIn);
    }
    
    public ItemStack zeroday(final World worldIn, final EntityPlayer playerIn) {
        return this.zerodayisaminecraftcheat().zeroday(this, worldIn, playerIn);
    }
    
    public NBTTagCompound zeroday(final NBTTagCompound nbt) {
        final ResourceLocation resourcelocation = Item.zerodayisaminecraftcheat.zeroday(this.pandora);
        nbt.zerodayisaminecraftcheat("id", (resourcelocation == null) ? "minecraft:air" : resourcelocation.toString());
        nbt.zerodayisaminecraftcheat("Count", (byte)this.zeroday);
        nbt.zerodayisaminecraftcheat("Damage", (short)this.flux);
        if (this.zues != null) {
            nbt.zerodayisaminecraftcheat("tag", this.zues);
        }
        return nbt;
    }
    
    public void sigma(final NBTTagCompound nbt) {
        if (nbt.zeroday("id", 8)) {
            this.pandora = Item.zerodayisaminecraftcheat(nbt.b("id"));
        }
        else {
            this.pandora = Item.zerodayisaminecraftcheat(nbt.zues("id"));
        }
        this.zeroday = nbt.pandora("Count");
        this.flux = nbt.zues("Damage");
        if (this.flux < 0) {
            this.flux = 0;
        }
        if (nbt.zeroday("tag", 10)) {
            this.zues = nbt.e("tag");
            if (this.pandora != null) {
                this.pandora.zerodayisaminecraftcheat(this.zues);
            }
        }
    }
    
    public int zeroday() {
        return this.zerodayisaminecraftcheat().zerodayisaminecraftcheat();
    }
    
    public boolean sigma() {
        return this.zeroday() > 1 && (!this.pandora() || !this.flux());
    }
    
    public boolean pandora() {
        return this.pandora != null && this.pandora.sigma() > 0 && (!this.f() || !this.g().f("Unbreakable"));
    }
    
    public boolean zues() {
        return this.pandora.zeroday();
    }
    
    public boolean flux() {
        return this.pandora() && this.flux > 0;
    }
    
    public int vape() {
        return this.flux;
    }
    
    public int momgetthecamera() {
        return this.flux;
    }
    
    public void zeroday(final int meta) {
        this.flux = meta;
        if (this.flux < 0) {
            this.flux = 0;
        }
    }
    
    public int a() {
        return this.pandora.sigma();
    }
    
    public boolean zerodayisaminecraftcheat(int amount, final Random rand) {
        if (!this.pandora()) {
            return false;
        }
        if (amount > 0) {
            final int i = EnchantmentHelper.zerodayisaminecraftcheat(Enchantment.k.s, this);
            int j = 0;
            for (int k = 0; i > 0 && k < amount; ++k) {
                if (EnchantmentDurability.zerodayisaminecraftcheat(this, i, rand)) {
                    ++j;
                }
            }
            amount -= j;
            if (amount <= 0) {
                return false;
            }
        }
        this.flux += amount;
        return this.flux > this.a();
    }
    
    public void zerodayisaminecraftcheat(final int amount, final EntityLivingBase entityIn) {
        if ((!(entityIn instanceof EntityPlayer) || !((EntityPlayer)entityIn).bz.pandora) && this.pandora() && this.zerodayisaminecraftcheat(amount, entityIn.bm())) {
            entityIn.sigma(this);
            --this.zeroday;
            if (entityIn instanceof EntityPlayer) {
                final EntityPlayer entityplayer = (EntityPlayer)entityIn;
                entityplayer.zerodayisaminecraftcheat(StatList.W[Item.zerodayisaminecraftcheat(this.pandora)]);
                if (this.zeroday == 0 && this.zerodayisaminecraftcheat() instanceof ItemBow) {
                    entityplayer.aY();
                }
            }
            if (this.zeroday < 0) {
                this.zeroday = 0;
            }
            this.flux = 0;
        }
    }
    
    public void zerodayisaminecraftcheat(final EntityLivingBase entityIn, final EntityPlayer playerIn) {
        final boolean flag = this.pandora.zerodayisaminecraftcheat(this, entityIn, playerIn);
        if (flag) {
            playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this.pandora)]);
        }
    }
    
    public void zerodayisaminecraftcheat(final World worldIn, final Block blockIn, final BlockPos pos, final EntityPlayer playerIn) {
        final boolean flag = this.pandora.zerodayisaminecraftcheat(this, worldIn, blockIn, pos, playerIn);
        if (flag) {
            playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this.pandora)]);
        }
    }
    
    public boolean zeroday(final Block blockIn) {
        return this.pandora.zeroday(blockIn);
    }
    
    public boolean zerodayisaminecraftcheat(final EntityPlayer playerIn, final EntityLivingBase entityIn) {
        return this.pandora.zerodayisaminecraftcheat(this, playerIn, entityIn);
    }
    
    public ItemStack b() {
        final ItemStack itemstack = new ItemStack(this.pandora, this.zeroday, this.flux);
        if (this.zues != null) {
            itemstack.zues = (NBTTagCompound)this.zues.zeroday();
        }
        return itemstack;
    }
    
    public static boolean zerodayisaminecraftcheat(final ItemStack stackA, final ItemStack stackB) {
        return (stackA == null && stackB == null) || (stackA != null && stackB != null && (stackA.zues != null || stackB.zues == null) && (stackA.zues == null || stackA.zues.equals(stackB.zues)));
    }
    
    public static boolean zeroday(final ItemStack stackA, final ItemStack stackB) {
        return (stackA == null && stackB == null) || (stackA != null && stackB != null && stackA.pandora(stackB));
    }
    
    private boolean pandora(final ItemStack other) {
        return this.zeroday == other.zeroday && this.pandora == other.pandora && this.flux == other.flux && (this.zues != null || other.zues == null) && (this.zues == null || this.zues.equals(other.zues));
    }
    
    public static boolean sigma(final ItemStack stackA, final ItemStack stackB) {
        return (stackA == null && stackB == null) || (stackA != null && stackB != null && stackA.zerodayisaminecraftcheat(stackB));
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack other) {
        return other != null && this.pandora == other.pandora && this.flux == other.flux;
    }
    
    public String c() {
        return this.pandora.zeroday(this);
    }
    
    public static ItemStack zeroday(final ItemStack stack) {
        return (stack == null) ? null : stack.b();
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.zeroday) + "x" + this.pandora.momgetthecamera() + "@" + this.flux;
    }
    
    public void zerodayisaminecraftcheat(final World worldIn, final Entity entityIn, final int inventorySlot, final boolean isCurrentItem) {
        if (this.sigma > 0) {
            --this.sigma;
        }
        this.pandora.zerodayisaminecraftcheat(this, worldIn, entityIn, inventorySlot, isCurrentItem);
    }
    
    public void zerodayisaminecraftcheat(final World worldIn, final EntityPlayer playerIn, final int amount) {
        playerIn.zerodayisaminecraftcheat(StatList.U[Item.zerodayisaminecraftcheat(this.pandora)], amount);
        this.pandora.sigma(this, worldIn, playerIn);
    }
    
    public boolean sigma(final ItemStack p_179549_1_) {
        return this.pandora(p_179549_1_);
    }
    
    public int d() {
        return this.zerodayisaminecraftcheat().pandora(this);
    }
    
    public EnumAction e() {
        return this.zerodayisaminecraftcheat().sigma(this);
    }
    
    public void zeroday(final World worldIn, final EntityPlayer playerIn, final int timeLeft) {
        this.zerodayisaminecraftcheat().zerodayisaminecraftcheat(this, worldIn, playerIn, timeLeft);
    }
    
    public boolean f() {
        return this.zues != null;
    }
    
    public NBTTagCompound g() {
        return this.zues;
    }
    
    public NBTTagCompound zerodayisaminecraftcheat(final String key, final boolean create) {
        if (this.zues != null && this.zues.zeroday(key, 10)) {
            return this.zues.e(key);
        }
        if (create) {
            final NBTTagCompound nbttagcompound = new NBTTagCompound();
            this.zerodayisaminecraftcheat(key, nbttagcompound);
            return nbttagcompound;
        }
        return null;
    }
    
    public NBTTagList h() {
        return (this.zues == null) ? null : this.zues.sigma("ench", 10);
    }
    
    public void pandora(final NBTTagCompound nbt) {
        this.zues = nbt;
    }
    
    public String i() {
        String s = this.zerodayisaminecraftcheat().vape(this);
        if (this.zues != null && this.zues.zeroday("display", 10)) {
            final NBTTagCompound nbttagcompound = this.zues.e("display");
            if (nbttagcompound.zeroday("Name", 8)) {
                s = nbttagcompound.b("Name");
            }
        }
        return s;
    }
    
    public ItemStack zerodayisaminecraftcheat(final String displayName) {
        if (this.zues == null) {
            this.zues = new NBTTagCompound();
        }
        if (!this.zues.zeroday("display", 10)) {
            this.zues.zerodayisaminecraftcheat("display", new NBTTagCompound());
        }
        this.zues.e("display").zerodayisaminecraftcheat("Name", displayName);
        return this;
    }
    
    public void j() {
        if (this.zues != null && this.zues.zeroday("display", 10)) {
            final NBTTagCompound nbttagcompound = this.zues.e("display");
            nbttagcompound.g("Name");
            if (nbttagcompound.sigma()) {
                this.zues.g("display");
                if (this.zues.sigma()) {
                    this.pandora((NBTTagCompound)null);
                }
            }
        }
    }
    
    public boolean k() {
        return this.zues != null && this.zues.zeroday("display", 10) && this.zues.e("display").zeroday("Name", 8);
    }
    
    public List<String> zerodayisaminecraftcheat(final EntityPlayer playerIn, final boolean advanced) {
        final List<String> list = (List<String>)Lists.newArrayList();
        String s = this.i();
        if (this.k()) {
            s = EnumChatFormatting.m + s;
        }
        s = String.valueOf(s) + EnumChatFormatting.n;
        if (advanced) {
            String s2 = "";
            if (s.length() > 0) {
                s = String.valueOf(s) + " (";
                s2 = ")";
            }
            final int i = Item.zerodayisaminecraftcheat(this.pandora);
            if (this.zues()) {
                s = String.valueOf(s) + String.format("#%04d/%d%s", i, this.flux, s2);
            }
            else {
                s = String.valueOf(s) + String.format("#%04d%s", i, s2);
            }
        }
        else if (!this.k() && this.pandora == Items.aV) {
            s = String.valueOf(s) + " #" + this.flux;
        }
        list.add(s);
        int i2 = 0;
        if (this.f() && this.zues.zeroday("HideFlags", 99)) {
            i2 = this.zues.flux("HideFlags");
        }
        if ((i2 & 0x20) == 0x0) {
            this.pandora.zerodayisaminecraftcheat(this, playerIn, list, advanced);
        }
        if (this.f()) {
            if ((i2 & 0x1) == 0x0) {
                final NBTTagList nbttaglist = this.h();
                if (nbttaglist != null) {
                    for (int j = 0; j < nbttaglist.zues(); ++j) {
                        final int k = nbttaglist.zeroday(j).zues("id");
                        final int l = nbttaglist.zeroday(j).zues("lvl");
                        if (Enchantment.zerodayisaminecraftcheat(k) != null) {
                            list.add(Enchantment.zerodayisaminecraftcheat(k).pandora(l));
                        }
                    }
                }
            }
            if (this.zues.zeroday("display", 10)) {
                final NBTTagCompound nbttagcompound = this.zues.e("display");
                if (nbttagcompound.zeroday("color", 3)) {
                    if (advanced) {
                        list.add("Color: #" + Integer.toHexString(nbttagcompound.flux("color")).toUpperCase());
                    }
                    else {
                        list.add(EnumChatFormatting.m + StatCollector.zerodayisaminecraftcheat("item.dyed"));
                    }
                }
                if (nbttagcompound.zeroday("Lore") == 9) {
                    final NBTTagList nbttaglist2 = nbttagcompound.sigma("Lore", 8);
                    if (nbttaglist2.zues() > 0) {
                        for (int j2 = 0; j2 < nbttaglist2.zues(); ++j2) {
                            list.add(new StringBuilder().append(EnumChatFormatting.flux).append(EnumChatFormatting.m).append(nbttaglist2.flux(j2)).toString());
                        }
                    }
                }
            }
        }
        final Multimap<String, AttributeModifier> multimap = this.t();
        if (!multimap.isEmpty() && (i2 & 0x2) == 0x0) {
            list.add("");
            for (final Map.Entry<String, AttributeModifier> entry : multimap.entries()) {
                final AttributeModifier attributemodifier = entry.getValue();
                double d0 = attributemodifier.pandora();
                if (attributemodifier.zerodayisaminecraftcheat() == Item.zeroday) {
                    d0 += EnchantmentHelper.zerodayisaminecraftcheat(this, EnumCreatureAttribute.zerodayisaminecraftcheat);
                }
                double d2;
                if (attributemodifier.sigma() != 1 && attributemodifier.sigma() != 2) {
                    d2 = d0;
                }
                else {
                    d2 = d0 * 100.0;
                }
                if (d0 > 0.0) {
                    list.add(EnumChatFormatting.b + StatCollector.zerodayisaminecraftcheat("attribute.modifier.plus." + attributemodifier.sigma(), ItemStack.zerodayisaminecraftcheat.format(d2), StatCollector.zerodayisaminecraftcheat("attribute.name." + entry.getKey())));
                }
                else {
                    if (d0 >= 0.0) {
                        continue;
                    }
                    d2 *= -1.0;
                    list.add(EnumChatFormatting.e + StatCollector.zerodayisaminecraftcheat("attribute.modifier.take." + attributemodifier.sigma(), ItemStack.zerodayisaminecraftcheat.format(d2), StatCollector.zerodayisaminecraftcheat("attribute.name." + entry.getKey())));
                }
            }
        }
        if (this.f() && this.g().f("Unbreakable") && (i2 & 0x4) == 0x0) {
            list.add(EnumChatFormatting.b + StatCollector.zerodayisaminecraftcheat("item.unbreakable"));
        }
        if (this.f() && this.zues.zeroday("CanDestroy", 9) && (i2 & 0x8) == 0x0) {
            final NBTTagList nbttaglist3 = this.zues.sigma("CanDestroy", 8);
            if (nbttaglist3.zues() > 0) {
                list.add("");
                list.add(EnumChatFormatting.momgetthecamera + StatCollector.zerodayisaminecraftcheat("item.canBreak"));
                for (int k2 = 0; k2 < nbttaglist3.zues(); ++k2) {
                    final Block block = Block.zerodayisaminecraftcheat(nbttaglist3.flux(k2));
                    if (block != null) {
                        list.add(EnumChatFormatting.a + block.u());
                    }
                    else {
                        list.add(EnumChatFormatting.a + "missingno");
                    }
                }
            }
        }
        if (this.f() && this.zues.zeroday("CanPlaceOn", 9) && (i2 & 0x10) == 0x0) {
            final NBTTagList nbttaglist4 = this.zues.sigma("CanPlaceOn", 8);
            if (nbttaglist4.zues() > 0) {
                list.add("");
                list.add(EnumChatFormatting.momgetthecamera + StatCollector.zerodayisaminecraftcheat("item.canPlace"));
                for (int l2 = 0; l2 < nbttaglist4.zues(); ++l2) {
                    final Block block2 = Block.zerodayisaminecraftcheat(nbttaglist4.flux(l2));
                    if (block2 != null) {
                        list.add(EnumChatFormatting.a + block2.u());
                    }
                    else {
                        list.add(EnumChatFormatting.a + "missingno");
                    }
                }
            }
        }
        if (advanced) {
            if (this.flux()) {
                list.add("Durability: " + (this.a() - this.vape()) + " / " + this.a());
            }
            list.add(EnumChatFormatting.a + Item.zerodayisaminecraftcheat.zeroday(this.pandora).toString());
            if (this.f()) {
                list.add(EnumChatFormatting.a + "NBT: " + this.g().zues().size() + " tag(s)");
            }
        }
        return list;
    }
    
    public boolean l() {
        return this.zerodayisaminecraftcheat().momgetthecamera(this);
    }
    
    public EnumRarity m() {
        return this.zerodayisaminecraftcheat().a(this);
    }
    
    public boolean n() {
        return this.zerodayisaminecraftcheat().b(this) && !this.o();
    }
    
    public void zerodayisaminecraftcheat(final Enchantment ench, final int level) {
        if (this.zues == null) {
            this.pandora(new NBTTagCompound());
        }
        if (!this.zues.zeroday("ench", 9)) {
            this.zues.zerodayisaminecraftcheat("ench", new NBTTagList());
        }
        final NBTTagList nbttaglist = this.zues.sigma("ench", 10);
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        nbttagcompound.zerodayisaminecraftcheat("id", (short)ench.s);
        nbttagcompound.zerodayisaminecraftcheat("lvl", (short)(byte)level);
        nbttaglist.zerodayisaminecraftcheat(nbttagcompound);
    }
    
    public boolean o() {
        return this.zues != null && this.zues.zeroday("ench", 9);
    }
    
    public void zerodayisaminecraftcheat(final String key, final NBTBase value) {
        if (this.zues == null) {
            this.pandora(new NBTTagCompound());
        }
        this.zues.zerodayisaminecraftcheat(key, value);
    }
    
    public boolean p() {
        return this.zerodayisaminecraftcheat().g();
    }
    
    public boolean q() {
        return this.vape != null;
    }
    
    public void zerodayisaminecraftcheat(final EntityItemFrame frame) {
        this.vape = frame;
    }
    
    public EntityItemFrame r() {
        return this.vape;
    }
    
    public int s() {
        return (this.f() && this.zues.zeroday("RepairCost", 3)) ? this.zues.flux("RepairCost") : 0;
    }
    
    public void sigma(final int cost) {
        if (!this.f()) {
            this.zues = new NBTTagCompound();
        }
        this.zues.zerodayisaminecraftcheat("RepairCost", cost);
    }
    
    public Multimap<String, AttributeModifier> t() {
        Multimap<String, AttributeModifier> multimap;
        if (this.f() && this.zues.zeroday("AttributeModifiers", 9)) {
            multimap = (Multimap<String, AttributeModifier>)HashMultimap.create();
            final NBTTagList nbttaglist = this.zues.sigma("AttributeModifiers", 10);
            for (int i = 0; i < nbttaglist.zues(); ++i) {
                final NBTTagCompound nbttagcompound = nbttaglist.zeroday(i);
                final AttributeModifier attributemodifier = SharedMonsterAttributes.zerodayisaminecraftcheat(nbttagcompound);
                if (attributemodifier != null && attributemodifier.zerodayisaminecraftcheat().getLeastSignificantBits() != 0L && attributemodifier.zerodayisaminecraftcheat().getMostSignificantBits() != 0L) {
                    multimap.put((Object)nbttagcompound.b("AttributeName"), (Object)attributemodifier);
                }
            }
        }
        else {
            multimap = this.zerodayisaminecraftcheat().h();
        }
        return multimap;
    }
    
    public void zerodayisaminecraftcheat(final Item newItem) {
        this.pandora = newItem;
    }
    
    public IChatComponent u() {
        final ChatComponentText chatcomponenttext = new ChatComponentText(this.i());
        if (this.k()) {
            chatcomponenttext.vape().zeroday(true);
        }
        final IChatComponent ichatcomponent = new ChatComponentText("[").zerodayisaminecraftcheat(chatcomponenttext).zeroday("]");
        if (this.pandora != null) {
            final NBTTagCompound nbttagcompound = new NBTTagCompound();
            this.zeroday(nbttagcompound);
            ichatcomponent.vape().zerodayisaminecraftcheat(new HoverEvent(HoverEvent.zerodayisaminecraftcheat.sigma, new ChatComponentText(nbttagcompound.toString())));
            ichatcomponent.vape().zerodayisaminecraftcheat(this.m().zues);
        }
        return ichatcomponent;
    }
    
    public boolean sigma(final Block blockIn) {
        if (blockIn == this.momgetthecamera) {
            return this.a;
        }
        this.momgetthecamera = blockIn;
        if (this.f() && this.zues.zeroday("CanDestroy", 9)) {
            final NBTTagList nbttaglist = this.zues.sigma("CanDestroy", 8);
            for (int i = 0; i < nbttaglist.zues(); ++i) {
                final Block block = Block.zerodayisaminecraftcheat(nbttaglist.flux(i));
                if (block == blockIn) {
                    return this.a = true;
                }
            }
        }
        return this.a = false;
    }
    
    public boolean pandora(final Block blockIn) {
        if (blockIn == this.b) {
            return this.c;
        }
        this.b = blockIn;
        if (this.f() && this.zues.zeroday("CanPlaceOn", 9)) {
            final NBTTagList nbttaglist = this.zues.sigma("CanPlaceOn", 8);
            for (int i = 0; i < nbttaglist.zues(); ++i) {
                final Block block = Block.zerodayisaminecraftcheat(nbttaglist.flux(i));
                if (block == blockIn) {
                    return this.c = true;
                }
            }
        }
        return this.c = false;
    }
}

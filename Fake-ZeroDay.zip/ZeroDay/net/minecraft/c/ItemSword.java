// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.SharedMonsterAttributes;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.AttributeModifier;
import com.google.common.collect.Multimap;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.pandora.CreativeTabs;

public class ItemSword extends Item
{
    public float vape;
    public final zerodayisaminecraftcheat momgetthecamera;
    
    public ItemSword(final zerodayisaminecraftcheat material) {
        this.momgetthecamera = material;
        this.pandora = 1;
        this.pandora(material.zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(CreativeTabs.b);
        this.vape = 4.0f + material.sigma();
    }
    
    public float j() {
        return this.momgetthecamera.sigma();
    }
    
    @Override
    public float zerodayisaminecraftcheat(final ItemStack stack, final Block block) {
        if (block == Blocks.y) {
            return 15.0f;
        }
        final Material material = block.flux();
        return (material != Material.c && material != Material.d && material != Material.n && material != Material.b && material != Material.u) ? 1.0f : 1.5f;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityLivingBase target, final EntityLivingBase attacker) {
        stack.zerodayisaminecraftcheat(1, attacker);
        return true;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final Block blockIn, final BlockPos pos, final EntityLivingBase playerIn) {
        if (blockIn.zeroday(worldIn, pos) != 0.0) {
            stack.zerodayisaminecraftcheat(2, playerIn);
        }
        return true;
    }
    
    @Override
    public boolean flux() {
        return true;
    }
    
    @Override
    public EnumAction sigma(final ItemStack stack) {
        return EnumAction.pandora;
    }
    
    @Override
    public int pandora(final ItemStack stack) {
        return 72000;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        playerIn.zeroday(itemStackIn, this.pandora(itemStackIn));
        return itemStackIn;
    }
    
    @Override
    public boolean zeroday(final Block blockIn) {
        return blockIn == Blocks.y;
    }
    
    @Override
    public int e() {
        return this.momgetthecamera.zues();
    }
    
    public String k() {
        return this.momgetthecamera.toString();
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack toRepair, final ItemStack repair) {
        return this.momgetthecamera.flux() == repair.zerodayisaminecraftcheat() || super.zerodayisaminecraftcheat(toRepair, repair);
    }
    
    @Override
    public Multimap<String, AttributeModifier> h() {
        final Multimap<String, AttributeModifier> multimap = super.h();
        multimap.put((Object)SharedMonsterAttributes.zues.zerodayisaminecraftcheat(), (Object)new AttributeModifier(ItemSword.zeroday, "Weapon modifier", this.vape, 0));
        return multimap;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.vape.SharedMonsterAttributes;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.AttributeModifier;
import com.google.common.collect.Multimap;
import net.minecraft.o.BlockPos;
import net.minecraft.q.World;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Set;

public class ItemTool extends Item
{
    private Set<Block> a;
    protected float vape;
    private float b;
    protected zerodayisaminecraftcheat momgetthecamera;
    
    protected ItemTool(final float attackDamage, final zerodayisaminecraftcheat material, final Set<Block> effectiveBlocks) {
        this.vape = 4.0f;
        this.momgetthecamera = material;
        this.a = effectiveBlocks;
        this.pandora = 1;
        this.pandora(material.zerodayisaminecraftcheat());
        this.vape = material.zeroday();
        this.b = attackDamage + material.sigma();
        this.zerodayisaminecraftcheat(CreativeTabs.a);
    }
    
    @Override
    public float zerodayisaminecraftcheat(final ItemStack stack, final Block block) {
        return this.a.contains(block) ? this.vape : 1.0f;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final EntityLivingBase target, final EntityLivingBase attacker) {
        stack.zerodayisaminecraftcheat(2, attacker);
        return true;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack stack, final World worldIn, final Block blockIn, final BlockPos pos, final EntityLivingBase playerIn) {
        if (blockIn.zeroday(worldIn, pos) != 0.0) {
            stack.zerodayisaminecraftcheat(1, playerIn);
        }
        return true;
    }
    
    @Override
    public boolean flux() {
        return true;
    }
    
    public zerodayisaminecraftcheat j() {
        return this.momgetthecamera;
    }
    
    @Override
    public int e() {
        return this.momgetthecamera.zues();
    }
    
    public String k() {
        return this.momgetthecamera.toString();
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final ItemStack toRepair, final ItemStack repair) {
        return this.momgetthecamera.flux() == repair.zerodayisaminecraftcheat() || super.zerodayisaminecraftcheat(toRepair, repair);
    }
    
    @Override
    public Multimap<String, AttributeModifier> h() {
        final Multimap<String, AttributeModifier> multimap = super.h();
        multimap.put((Object)SharedMonsterAttributes.zues.zerodayisaminecraftcheat(), (Object)new AttributeModifier(ItemTool.zeroday, "Tool modifier", this.b, 0));
        return multimap;
    }
}

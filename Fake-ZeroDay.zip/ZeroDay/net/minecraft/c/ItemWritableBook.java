// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c;

import net.minecraft.d.NBTTagList;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.m.StatList;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;

public class ItemWritableBook extends Item
{
    public ItemWritableBook() {
        this.zeroday(1);
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final ItemStack itemStackIn, final World worldIn, final EntityPlayer playerIn) {
        playerIn.zerodayisaminecraftcheat(itemStackIn);
        playerIn.zerodayisaminecraftcheat(StatList.V[Item.zerodayisaminecraftcheat(this)]);
        return itemStackIn;
    }
    
    public static boolean zeroday(final NBTTagCompound nbt) {
        if (nbt == null) {
            return false;
        }
        if (!nbt.zeroday("pages", 9)) {
            return false;
        }
        final NBTTagList nbttaglist = nbt.sigma("pages", 8);
        for (int i = 0; i < nbttaglist.zues(); ++i) {
            final String s = nbttaglist.flux(i);
            if (s == null) {
                return false;
            }
            if (s.length() > 32767) {
                return false;
            }
        }
        return true;
    }
}

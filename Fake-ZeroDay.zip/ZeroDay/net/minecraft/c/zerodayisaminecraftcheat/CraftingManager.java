// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import java.util.Iterator;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;
import java.util.Map;
import com.google.common.collect.Maps;
import java.util.Collections;
import java.util.Comparator;
import net.minecraft.c.Item;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlabNew;
import net.minecraft.zerodayisaminecraftcheat.BlockStone;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlab;
import net.minecraft.zerodayisaminecraftcheat.BlockWall;
import net.minecraft.zerodayisaminecraftcheat.BlockPlanks;
import net.minecraft.a.Blocks;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;
import com.google.common.collect.Lists;
import java.util.List;

public class CraftingManager
{
    private static final CraftingManager zerodayisaminecraftcheat;
    private final List<IRecipe> zeroday;
    
    static {
        zerodayisaminecraftcheat = new CraftingManager();
    }
    
    public static CraftingManager zerodayisaminecraftcheat() {
        return CraftingManager.zerodayisaminecraftcheat;
    }
    
    private CraftingManager() {
        this.zeroday = (List<IRecipe>)Lists.newArrayList();
        new RecipesTools().zerodayisaminecraftcheat(this);
        new RecipesWeapons().zerodayisaminecraftcheat(this);
        new RecipesIngots().zerodayisaminecraftcheat(this);
        new RecipesFood().zerodayisaminecraftcheat(this);
        new RecipesCrafting().zerodayisaminecraftcheat(this);
        new RecipesArmor().zerodayisaminecraftcheat(this);
        new RecipesDyes().zerodayisaminecraftcheat(this);
        this.zeroday.add(new RecipesArmorDyes());
        this.zeroday.add(new RecipeBookCloning());
        this.zeroday.add(new RecipesMapCloning());
        this.zeroday.add(new RecipesMapExtending());
        this.zeroday.add(new RecipeFireworks());
        this.zeroday.add(new RecipeRepairItem());
        new RecipesBanners().zerodayisaminecraftcheat(this);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aC, 3), "###", '#', Items.aB);
        this.zeroday(new ItemStack(Items.aD, 1), Items.aC, Items.aC, Items.aC, Items.ax);
        this.zeroday(new ItemStack(Items.bE, 1), Items.aD, new ItemStack(Items.aO, 1, EnumDyeColor.h.sigma()), Items.y);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aG, 3), "W#W", "W#W", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aI, 3), "W#W", "W#W", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aH, 3), "W#W", "W#W", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aJ, 3), "W#W", "W#W", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aL, 3), "W#W", "W#W", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aK, 3), "W#W", "W#W", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bR, 6, BlockWall.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()), "###", "###", '#', Blocks.zues);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bR, 6, BlockWall.zerodayisaminecraftcheat.zeroday.zeroday()), "###", "###", '#', Blocks.Q);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.br, 6), "###", "###", '#', Blocks.bq);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bg, 1), "#W#", "#W#", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bi, 1), "#W#", "#W#", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bh, 1), "#W#", "#W#", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bj, 1), "#W#", "#W#", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bl, 1), "#W#", "#W#", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bk, 1), "#W#", "#W#", '#', Items.q, 'W', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aF, 1), "###", "#X#", "###", '#', Blocks.flux, 'X', Items.a);
        this.zerodayisaminecraftcheat(new ItemStack(Items.cf, 2), "~~ ", "~O ", "  ~", '~', Items.x, 'O', Items.aE);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.t, 1), "###", "#X#", "###", '#', Blocks.flux, 'X', Items.au);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.P, 1), "###", "XXX", "###", '#', Blocks.flux, 'X', Items.aD);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aB, 1), "##", "##", '#', Items.av);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.az, 6), "###", '#', Blocks.aB);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aD, 1), "##", "##", '#', Items.aA);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.N, 1), "##", "##", '#', Items.az);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aP, 1), "##", "##", '#', Items.aL);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ci, 1), "##", "##", '#', Items.bY);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.D, 1), "##", "##", '#', Items.x);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.O, 1), "X#X", "#X#", "X#X", 'X', Items.z, '#', Blocks.e);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.M, 6, BlockStoneSlab.zerodayisaminecraftcheat.pandora.zeroday()), "###", '#', Blocks.zues);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.M, 6, BlockStoneSlab.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()), "###", '#', new ItemStack(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.M, 6, BlockStoneSlab.zerodayisaminecraftcheat.zeroday.zeroday()), "###", '#', Blocks.s);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.M, 6, BlockStoneSlab.zerodayisaminecraftcheat.zues.zeroday()), "###", '#', Blocks.N);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.M, 6, BlockStoneSlab.zerodayisaminecraftcheat.flux.zeroday()), "###", '#', Blocks.aX);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.M, 6, BlockStoneSlab.zerodayisaminecraftcheat.vape.zeroday()), "###", '#', Blocks.bq);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.M, 6, BlockStoneSlab.zerodayisaminecraftcheat.momgetthecamera.zeroday()), "###", '#', Blocks.ci);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.cH, 6, BlockStoneSlabNew.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()), "###", '#', Blocks.cE);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bE, 6, 0), "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bE, 6, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()), "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bE, 6, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()), "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bE, 6, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()), "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bE, 6, 4 + BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4), "###", '#', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bE, 6, 4 + BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4), "###", '#', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.am, 3), "# #", "###", "# #", '#', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ai, 3), "##", "##", "##", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Items.aj, 3), "##", "##", "##", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Items.ak, 3), "##", "##", "##", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Items.al, 3), "##", "##", "##", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Items.am, 3), "##", "##", "##", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zues.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Items.an, 3), "##", "##", "##", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.flux.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aV, 2), "###", "###", '#', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Items.at, 3), "##", "##", "##", '#', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.co, 1), "##", "##", '#', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ah, 3), "###", "###", " X ", '#', Blocks.flux, 'X', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aR, 1), "AAA", "BEB", "CCC", 'A', Items.ay, 'B', Items.aQ, 'C', Items.G, 'E', Items.aH);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aQ, 1), "#", '#', Items.aB);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.flux, 4, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()), "#", '#', new ItemStack(Blocks.j, 1, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.flux, 4, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()), "#", '#', new ItemStack(Blocks.j, 1, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.flux, 4, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()), "#", '#', new ItemStack(Blocks.j, 1, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.flux, 4, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()), "#", '#', new ItemStack(Blocks.j, 1, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.flux, 4, 4 + BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4), "#", '#', new ItemStack(Blocks.k, 1, BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.flux, 4, 4 + BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4), "#", '#', new ItemStack(Blocks.k, 1, BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Items.q, 4), "#", "#", '#', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.S, 4), "X", "#", 'X', Items.momgetthecamera, '#', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.S, 4), "X", "#", 'X', new ItemStack(Items.momgetthecamera, 1, 1), '#', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Items.r, 4), "# #", " # ", '#', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bs, 3), "# #", " # ", '#', Blocks.o);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.an, 16), "X X", "X#X", "X X", 'X', Items.b, '#', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.v, 6), "X X", "X#X", "XRX", 'X', Items.c, 'R', Items.au, '#', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ck, 6), "XSX", "X#X", "XSX", 'X', Items.b, '#', Blocks.ax, 'S', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.w, 6), "X X", "X#X", "XRX", 'X', Items.b, 'R', Items.au, '#', Blocks.ar);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ar, 1), "# #", "###", '#', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Items.by, 1), "# #", "# #", "###", '#', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bx, 1), " B ", "###", '#', Blocks.zues, 'B', Items.bn);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aR, 1), "A", "B", 'A', Blocks.aM, 'B', Blocks.S);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aF, 1), "A", "B", 'A', Blocks.W, 'B', Items.ar);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aG, 1), "A", "B", 'A', Blocks.ad, 'B', Items.ar);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bZ, 1), "A", "B", 'A', Blocks.O, 'B', Items.ar);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ca, 1), "A", "B", 'A', Blocks.ch, 'B', Items.ar);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aw, 1), "# #", "###", '#', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ao, 1), "# #", " # ", '#', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bI, 1), "# #", " # ", '#', Items.az);
        this.zeroday(new ItemStack(Items.pandora, 1), new ItemStack(Items.b, 1), new ItemStack(Items.ac, 1));
        this.zerodayisaminecraftcheat(new ItemStack(Items.H, 1), "###", '#', Items.G);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.V, 4), "#  ", "## ", "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bN, 4), "#  ", "## ", "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bM, 4), "#  ", "## ", "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bO, 4), "#  ", "## ", "###", '#', new ItemStack(Blocks.flux, 1, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.cu, 4), "#  ", "## ", "###", '#', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.cv, 4), "#  ", "## ", "###", '#', new ItemStack(Blocks.flux, 1, 4 + BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4));
        this.zerodayisaminecraftcheat(new ItemStack(Items.aJ, 1), "  #", " #X", "# X", '#', Items.q, 'X', Items.x);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bQ, 1), "# ", " X", '#', Items.aJ, 'X', Items.bJ);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ao, 4), "#  ", "## ", "###", '#', Blocks.zues);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bm, 4), "#  ", "## ", "###", '#', Blocks.N);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bn, 4), "#  ", "## ", "###", '#', Blocks.aX);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bs, 4), "#  ", "## ", "###", '#', Blocks.bq);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bG, 4), "#  ", "## ", "###", '#', Blocks.s);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.cF, 4), "#  ", "## ", "###", '#', Blocks.cE);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.cj, 4), "#  ", "## ", "###", '#', Blocks.ci);
        this.zerodayisaminecraftcheat(new ItemStack(Items.af, 1), "###", "#X#", "###", '#', Items.q, 'X', Blocks.D);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bH, 1), "###", "#X#", "###", '#', Items.q, 'X', Items.ax);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ag, 1, 0), "###", "#X#", "###", '#', Items.c, 'X', Items.zues);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ag, 1, 1), "###", "#X#", "###", '#', Blocks.J, 'X', Items.zues);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bO, 1, 0), "###", "#X#", "###", '#', Items.bp, 'X', Items.bJ);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bA, 1), "###", "#X#", "###", '#', Items.bp, 'X', Items.aX);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aq, 1), "X", "#", '#', Blocks.zues, 'X', Items.q);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bJ, 2), "I", "S", "#", '#', Blocks.flux, 'S', Items.q, 'I', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ax, 1), "X", "#", '#', Items.q, 'X', Items.au);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aT, 1), "#X#", "III", '#', Blocks.ax, 'X', Items.au, 'I', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Items.bW, 1), " # ", "#X#", "III", '#', Blocks.ax, 'X', Items.bY, 'I', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Items.aK, 1), " # ", "#X#", " # ", '#', Items.c, 'X', Items.au);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aI, 1), " # ", "#X#", " # ", '#', Items.b, 'X', Items.au);
        this.zerodayisaminecraftcheat(new ItemStack(Items.bN, 1), "###", "#X#", "###", '#', Items.aC, 'X', Items.aI);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ay, 1), "#", '#', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bV, 1), "#", '#', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ar, 1), "##", '#', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.at, 1), "##", '#', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ca, 1), "##", '#', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bZ, 1), "##", '#', Items.c);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.r, 1), "###", "#X#", "#R#", '#', Blocks.zues, 'X', Items.flux, 'R', Items.au);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.cl, 1), "###", "# #", "#R#", '#', Blocks.zues, 'R', Items.au);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.B, 1), "TTT", "#X#", "#R#", '#', Blocks.zues, 'X', Items.b, 'R', Items.au, 'T', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.x, 1), "S", "P", 'S', Items.aE, 'P', Blocks.B);
        this.zerodayisaminecraftcheat(new ItemStack(Items.aS, 1), "###", "XXX", '#', Blocks.D, 'X', Blocks.flux);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bu, 1), " B ", "D#D", "###", '#', Blocks.R, 'B', Items.aD, 'D', Items.a);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.bX, 1), "III", " i ", "iii", 'I', Blocks.K, 'i', Items.b);
        this.zerodayisaminecraftcheat(new ItemStack(Items.ax), "##", "##", '#', Items.bk);
        this.zeroday(new ItemStack(Items.bz, 1), Items.bm, Items.bv);
        this.zeroday(new ItemStack(Items.bD, 3), Items.z, Items.bv, Items.momgetthecamera);
        this.zeroday(new ItemStack(Items.bD, 3), Items.z, Items.bv, new ItemStack(Items.momgetthecamera, 1, 1));
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.cd), "GGG", "QQQ", "WWW", 'G', Blocks.o, 'Q', Items.bY, 'W', Blocks.bE);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.ch), "I I", "ICI", " I ", 'I', Items.b, 'C', Blocks.W);
        this.zerodayisaminecraftcheat(new ItemStack(Items.cb, 1), "///", " / ", "/_/", '/', Items.q, '_', new ItemStack(Blocks.M, 1, BlockStoneSlab.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        Collections.sort(this.zeroday, new Comparator<IRecipe>() {
            public int zerodayisaminecraftcheat(final IRecipe p_compare_1_, final IRecipe p_compare_2_) {
                return (p_compare_1_ instanceof ShapelessRecipes && p_compare_2_ instanceof ShapedRecipes) ? 1 : ((p_compare_2_ instanceof ShapelessRecipes && p_compare_1_ instanceof ShapedRecipes) ? -1 : ((p_compare_2_.zerodayisaminecraftcheat() < p_compare_1_.zerodayisaminecraftcheat()) ? -1 : ((p_compare_2_.zerodayisaminecraftcheat() > p_compare_1_.zerodayisaminecraftcheat()) ? 1 : 0)));
            }
        });
    }
    
    public ShapedRecipes zerodayisaminecraftcheat(final ItemStack stack, final Object... recipeComponents) {
        String s = "";
        int i = 0;
        int j = 0;
        int k = 0;
        if (recipeComponents[i] instanceof String[]) {
            final String[] astring = (String[])recipeComponents[i++];
            for (int l = 0; l < astring.length; ++l) {
                final String s2 = astring[l];
                ++k;
                j = s2.length();
                s = String.valueOf(s) + s2;
            }
        }
        else {
            while (recipeComponents[i] instanceof String) {
                final String s3 = (String)recipeComponents[i++];
                ++k;
                j = s3.length();
                s = String.valueOf(s) + s3;
            }
        }
        final Map<Character, ItemStack> map = (Map<Character, ItemStack>)Maps.newHashMap();
        while (i < recipeComponents.length) {
            final Character character = (Character)recipeComponents[i];
            ItemStack itemstack = null;
            if (recipeComponents[i + 1] instanceof Item) {
                itemstack = new ItemStack((Item)recipeComponents[i + 1]);
            }
            else if (recipeComponents[i + 1] instanceof Block) {
                itemstack = new ItemStack((Block)recipeComponents[i + 1], 1, 32767);
            }
            else if (recipeComponents[i + 1] instanceof ItemStack) {
                itemstack = (ItemStack)recipeComponents[i + 1];
            }
            map.put(character, itemstack);
            i += 2;
        }
        final ItemStack[] aitemstack = new ItemStack[j * k];
        for (int i2 = 0; i2 < j * k; ++i2) {
            final char c0 = s.charAt(i2);
            if (map.containsKey(c0)) {
                aitemstack[i2] = map.get(c0).b();
            }
            else {
                aitemstack[i2] = null;
            }
        }
        final ShapedRecipes shapedrecipes = new ShapedRecipes(j, k, aitemstack, stack);
        this.zeroday.add(shapedrecipes);
        return shapedrecipes;
    }
    
    public void zeroday(final ItemStack stack, final Object... recipeComponents) {
        final List<ItemStack> list = (List<ItemStack>)Lists.newArrayList();
        for (final Object object : recipeComponents) {
            if (object instanceof ItemStack) {
                list.add(((ItemStack)object).b());
            }
            else if (object instanceof Item) {
                list.add(new ItemStack((Item)object));
            }
            else {
                if (!(object instanceof Block)) {
                    throw new IllegalArgumentException("Invalid shapeless recipe: unknown type " + object.getClass().getName() + "!");
                }
                list.add(new ItemStack((Block)object));
            }
        }
        this.zeroday.add(new ShapelessRecipes(stack, list));
    }
    
    public void zerodayisaminecraftcheat(final IRecipe recipe) {
        this.zeroday.add(recipe);
    }
    
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting p_82787_1_, final World worldIn) {
        for (final IRecipe irecipe : this.zeroday) {
            if (irecipe.zerodayisaminecraftcheat(p_82787_1_, worldIn)) {
                return irecipe.zerodayisaminecraftcheat(p_82787_1_);
            }
        }
        return null;
    }
    
    public ItemStack[] zeroday(final InventoryCrafting p_180303_1_, final World worldIn) {
        for (final IRecipe irecipe : this.zeroday) {
            if (irecipe.zerodayisaminecraftcheat(p_180303_1_, worldIn)) {
                return irecipe.zeroday(p_180303_1_);
            }
        }
        final ItemStack[] aitemstack = new ItemStack[p_180303_1_.a()];
        for (int i = 0; i < aitemstack.length; ++i) {
            aitemstack[i] = p_180303_1_.d(i);
        }
        return aitemstack;
    }
    
    public List<IRecipe> zeroday() {
        return this.zeroday;
    }
}

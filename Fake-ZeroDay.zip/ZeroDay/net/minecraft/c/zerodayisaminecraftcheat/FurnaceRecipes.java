// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import java.util.Iterator;
import net.minecraft.c.Item;
import net.minecraft.c.ItemFishFood;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneBrick;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.a.Items;
import net.minecraft.a.Blocks;
import com.google.common.collect.Maps;
import net.minecraft.c.ItemStack;
import java.util.Map;

public class FurnaceRecipes
{
    private static final FurnaceRecipes zerodayisaminecraftcheat;
    private Map<ItemStack, ItemStack> zeroday;
    private Map<ItemStack, Float> sigma;
    
    static {
        zerodayisaminecraftcheat = new FurnaceRecipes();
    }
    
    public static FurnaceRecipes zerodayisaminecraftcheat() {
        return FurnaceRecipes.zerodayisaminecraftcheat;
    }
    
    private FurnaceRecipes() {
        this.zeroday = (Map<ItemStack, ItemStack>)Maps.newHashMap();
        this.sigma = (Map<ItemStack, Float>)Maps.newHashMap();
        this.zerodayisaminecraftcheat(Blocks.h, new ItemStack(Items.b), 0.7f);
        this.zerodayisaminecraftcheat(Blocks.g, new ItemStack(Items.c), 1.0f);
        this.zerodayisaminecraftcheat(Blocks.Y, new ItemStack(Items.a), 1.0f);
        this.zerodayisaminecraftcheat(Blocks.e, new ItemStack(Blocks.o), 0.1f);
        this.zerodayisaminecraftcheat(Items.ad, new ItemStack(Items.ae), 0.35f);
        this.zerodayisaminecraftcheat(Items.ba, new ItemStack(Items.bb), 0.35f);
        this.zerodayisaminecraftcheat(Items.bc, new ItemStack(Items.bd), 0.35f);
        this.zerodayisaminecraftcheat(Items.bg, new ItemStack(Items.bh), 0.35f);
        this.zerodayisaminecraftcheat(Items.be, new ItemStack(Items.bf), 0.35f);
        this.zerodayisaminecraftcheat(Blocks.zues, new ItemStack(Blocks.zeroday), 0.1f);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.aX, 1, BlockStoneBrick.E), new ItemStack(Blocks.aX, 1, BlockStoneBrick.G), 0.1f);
        this.zerodayisaminecraftcheat(Items.aA, new ItemStack(Items.az), 0.3f);
        this.zerodayisaminecraftcheat(Blocks.aD, new ItemStack(Blocks.cr), 0.35f);
        this.zerodayisaminecraftcheat(Blocks.aC, new ItemStack(Items.aO, 1, EnumDyeColor.f.sigma()), 0.2f);
        this.zerodayisaminecraftcheat(Blocks.j, new ItemStack(Items.momgetthecamera, 1, 1), 0.15f);
        this.zerodayisaminecraftcheat(Blocks.k, new ItemStack(Items.momgetthecamera, 1, 1), 0.15f);
        this.zerodayisaminecraftcheat(Blocks.bH, new ItemStack(Items.bG), 1.0f);
        this.zerodayisaminecraftcheat(Items.bK, new ItemStack(Items.bL), 0.35f);
        this.zerodayisaminecraftcheat(Blocks.aN, new ItemStack(Items.bX), 0.1f);
        this.zerodayisaminecraftcheat(new ItemStack(Blocks.n, 1, 1), new ItemStack(Blocks.n, 1, 0), 0.15f);
        ItemFishFood.zerodayisaminecraftcheat[] values;
        for (int length = (values = ItemFishFood.zerodayisaminecraftcheat.values()).length, i = 0; i < length; ++i) {
            final ItemFishFood.zerodayisaminecraftcheat itemfishfood$fishtype = values[i];
            if (itemfishfood$fishtype.vape()) {
                this.zerodayisaminecraftcheat(new ItemStack(Items.aM, 1, itemfishfood$fishtype.zerodayisaminecraftcheat()), new ItemStack(Items.aN, 1, itemfishfood$fishtype.zerodayisaminecraftcheat()), 0.35f);
            }
        }
        this.zerodayisaminecraftcheat(Blocks.i, new ItemStack(Items.momgetthecamera), 0.1f);
        this.zerodayisaminecraftcheat(Blocks.au, new ItemStack(Items.au), 0.7f);
        this.zerodayisaminecraftcheat(Blocks.p, new ItemStack(Items.aO, 1, EnumDyeColor.d.sigma()), 0.2f);
        this.zerodayisaminecraftcheat(Blocks.cg, new ItemStack(Items.bY), 0.2f);
    }
    
    public void zerodayisaminecraftcheat(final Block input, final ItemStack stack, final float experience) {
        this.zerodayisaminecraftcheat(Item.zerodayisaminecraftcheat(input), stack, experience);
    }
    
    public void zerodayisaminecraftcheat(final Item input, final ItemStack stack, final float experience) {
        this.zerodayisaminecraftcheat(new ItemStack(input, 1, 32767), stack, experience);
    }
    
    public void zerodayisaminecraftcheat(final ItemStack input, final ItemStack stack, final float experience) {
        this.zeroday.put(input, stack);
        this.sigma.put(stack, experience);
    }
    
    public ItemStack zerodayisaminecraftcheat(final ItemStack stack) {
        for (final Map.Entry<ItemStack, ItemStack> entry : this.zeroday.entrySet()) {
            if (this.zerodayisaminecraftcheat(stack, entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }
    
    private boolean zerodayisaminecraftcheat(final ItemStack stack1, final ItemStack stack2) {
        return stack2.zerodayisaminecraftcheat() == stack1.zerodayisaminecraftcheat() && (stack2.momgetthecamera() == 32767 || stack2.momgetthecamera() == stack1.momgetthecamera());
    }
    
    public Map<ItemStack, ItemStack> zeroday() {
        return this.zeroday;
    }
    
    public float zeroday(final ItemStack stack) {
        for (final Map.Entry<ItemStack, Float> entry : this.sigma.entrySet()) {
            if (this.zerodayisaminecraftcheat(stack, entry.getKey())) {
                return entry.getValue();
            }
        }
        return 0.0f;
    }
}

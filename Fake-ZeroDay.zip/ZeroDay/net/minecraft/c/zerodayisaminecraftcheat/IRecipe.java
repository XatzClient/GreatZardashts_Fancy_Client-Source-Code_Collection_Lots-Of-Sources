// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.ItemStack;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;

public interface IRecipe
{
    boolean zerodayisaminecraftcheat(final InventoryCrafting p0, final World p1);
    
    ItemStack zerodayisaminecraftcheat(final InventoryCrafting p0);
    
    int zerodayisaminecraftcheat();
    
    ItemStack zeroday();
    
    ItemStack[] zeroday(final InventoryCrafting p0);
}

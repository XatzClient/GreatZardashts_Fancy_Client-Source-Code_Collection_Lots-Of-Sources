// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.d.NBTTagCompound;
import net.minecraft.c.ItemEditableBook;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;

public class RecipeBookCloning implements IRecipe
{
    @Override
    public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
        int i = 0;
        ItemStack itemstack = null;
        for (int j = 0; j < inv.a(); ++j) {
            final ItemStack itemstack2 = inv.d(j);
            if (itemstack2 != null) {
                if (itemstack2.zerodayisaminecraftcheat() == Items.bF) {
                    if (itemstack != null) {
                        return false;
                    }
                    itemstack = itemstack2;
                }
                else {
                    if (itemstack2.zerodayisaminecraftcheat() != Items.bE) {
                        return false;
                    }
                    ++i;
                }
            }
        }
        return itemstack != null && i > 0;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
        int i = 0;
        ItemStack itemstack = null;
        for (int j = 0; j < inv.a(); ++j) {
            final ItemStack itemstack2 = inv.d(j);
            if (itemstack2 != null) {
                if (itemstack2.zerodayisaminecraftcheat() == Items.bF) {
                    if (itemstack != null) {
                        return null;
                    }
                    itemstack = itemstack2;
                }
                else {
                    if (itemstack2.zerodayisaminecraftcheat() != Items.bE) {
                        return null;
                    }
                    ++i;
                }
            }
        }
        if (itemstack != null && i >= 1 && ItemEditableBook.c(itemstack) < 2) {
            final ItemStack itemstack3 = new ItemStack(Items.bF, i);
            itemstack3.pandora((NBTTagCompound)itemstack.g().zeroday());
            itemstack3.g().zerodayisaminecraftcheat("generation", ItemEditableBook.c(itemstack) + 1);
            if (itemstack.k()) {
                itemstack3.zerodayisaminecraftcheat(itemstack.i());
            }
            return itemstack3;
        }
        return null;
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        return 9;
    }
    
    @Override
    public ItemStack zeroday() {
        return null;
    }
    
    @Override
    public ItemStack[] zeroday(final InventoryCrafting inv) {
        final ItemStack[] aitemstack = new ItemStack[inv.a()];
        for (int i = 0; i < aitemstack.length; ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null && itemstack.zerodayisaminecraftcheat() instanceof ItemEditableBook) {
                aitemstack[i] = itemstack;
                break;
            }
        }
        return aitemstack;
    }
}

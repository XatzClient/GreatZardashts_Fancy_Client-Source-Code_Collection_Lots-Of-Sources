// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import java.util.List;
import net.minecraft.c.ItemDye;
import com.google.common.collect.Lists;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagList;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.a.Items;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;
import net.minecraft.c.ItemStack;

public class RecipeFireworks implements IRecipe
{
    private ItemStack zerodayisaminecraftcheat;
    
    @Override
    public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
        this.zerodayisaminecraftcheat = null;
        int i = 0;
        int j = 0;
        int k = 0;
        int l = 0;
        int i2 = 0;
        int j2 = 0;
        for (int k2 = 0; k2 < inv.a(); ++k2) {
            final ItemStack itemstack = inv.d(k2);
            if (itemstack != null) {
                if (itemstack.zerodayisaminecraftcheat() == Items.z) {
                    ++j;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.bU) {
                    ++l;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.aO) {
                    ++k;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.aC) {
                    ++i;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.aL) {
                    ++i2;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.a) {
                    ++i2;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.bD) {
                    ++j2;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.y) {
                    ++j2;
                }
                else if (itemstack.zerodayisaminecraftcheat() == Items.bp) {
                    ++j2;
                }
                else {
                    if (itemstack.zerodayisaminecraftcheat() != Items.bP) {
                        return false;
                    }
                    ++j2;
                }
            }
        }
        i2 = i2 + k + j2;
        if (j > 3 || i > 1) {
            return false;
        }
        if (j >= 1 && i == 1 && i2 == 0) {
            this.zerodayisaminecraftcheat = new ItemStack(Items.bT);
            if (l > 0) {
                final NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                final NBTTagList nbttaglist = new NBTTagList();
                for (int k3 = 0; k3 < inv.a(); ++k3) {
                    final ItemStack itemstack2 = inv.d(k3);
                    if (itemstack2 != null && itemstack2.zerodayisaminecraftcheat() == Items.bU && itemstack2.f() && itemstack2.g().zeroday("Explosion", 10)) {
                        nbttaglist.zerodayisaminecraftcheat(itemstack2.g().e("Explosion"));
                    }
                }
                nbttagcompound2.zerodayisaminecraftcheat("Explosions", nbttaglist);
                nbttagcompound2.zerodayisaminecraftcheat("Flight", (byte)j);
                nbttagcompound1.zerodayisaminecraftcheat("Fireworks", nbttagcompound2);
                this.zerodayisaminecraftcheat.pandora(nbttagcompound1);
            }
            return true;
        }
        if (j == 1 && i == 0 && l == 0 && k > 0 && j2 <= 1) {
            this.zerodayisaminecraftcheat = new ItemStack(Items.bU);
            final NBTTagCompound nbttagcompound3 = new NBTTagCompound();
            final NBTTagCompound nbttagcompound4 = new NBTTagCompound();
            byte b0 = 0;
            final List<Integer> list = (List<Integer>)Lists.newArrayList();
            for (int l2 = 0; l2 < inv.a(); ++l2) {
                final ItemStack itemstack3 = inv.d(l2);
                if (itemstack3 != null) {
                    if (itemstack3.zerodayisaminecraftcheat() == Items.aO) {
                        list.add(ItemDye.vape[itemstack3.momgetthecamera() & 0xF]);
                    }
                    else if (itemstack3.zerodayisaminecraftcheat() == Items.aL) {
                        nbttagcompound4.zerodayisaminecraftcheat("Flicker", true);
                    }
                    else if (itemstack3.zerodayisaminecraftcheat() == Items.a) {
                        nbttagcompound4.zerodayisaminecraftcheat("Trail", true);
                    }
                    else if (itemstack3.zerodayisaminecraftcheat() == Items.bD) {
                        b0 = 1;
                    }
                    else if (itemstack3.zerodayisaminecraftcheat() == Items.y) {
                        b0 = 4;
                    }
                    else if (itemstack3.zerodayisaminecraftcheat() == Items.bp) {
                        b0 = 2;
                    }
                    else if (itemstack3.zerodayisaminecraftcheat() == Items.bP) {
                        b0 = 3;
                    }
                }
            }
            final int[] aint1 = new int[list.size()];
            for (int l3 = 0; l3 < aint1.length; ++l3) {
                aint1[l3] = list.get(l3);
            }
            nbttagcompound4.zerodayisaminecraftcheat("Colors", aint1);
            nbttagcompound4.zerodayisaminecraftcheat("Type", b0);
            nbttagcompound3.zerodayisaminecraftcheat("Explosion", nbttagcompound4);
            this.zerodayisaminecraftcheat.pandora(nbttagcompound3);
            return true;
        }
        if (j != 0 || i != 0 || l != 1 || k <= 0 || k != i2) {
            return false;
        }
        final List<Integer> list2 = (List<Integer>)Lists.newArrayList();
        for (int i3 = 0; i3 < inv.a(); ++i3) {
            final ItemStack itemstack4 = inv.d(i3);
            if (itemstack4 != null) {
                if (itemstack4.zerodayisaminecraftcheat() == Items.aO) {
                    list2.add(ItemDye.vape[itemstack4.momgetthecamera() & 0xF]);
                }
                else if (itemstack4.zerodayisaminecraftcheat() == Items.bU) {
                    this.zerodayisaminecraftcheat = itemstack4.b();
                    this.zerodayisaminecraftcheat.zeroday = 1;
                }
            }
        }
        final int[] aint2 = new int[list2.size()];
        for (int j3 = 0; j3 < aint2.length; ++j3) {
            aint2[j3] = list2.get(j3);
        }
        if (this.zerodayisaminecraftcheat == null || !this.zerodayisaminecraftcheat.f()) {
            return false;
        }
        final NBTTagCompound nbttagcompound5 = this.zerodayisaminecraftcheat.g().e("Explosion");
        if (nbttagcompound5 == null) {
            return false;
        }
        nbttagcompound5.zerodayisaminecraftcheat("FadeColors", aint2);
        return true;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
        return this.zerodayisaminecraftcheat.b();
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        return 10;
    }
    
    @Override
    public ItemStack zeroday() {
        return this.zerodayisaminecraftcheat;
    }
    
    @Override
    public ItemStack[] zeroday(final InventoryCrafting inv) {
        final ItemStack[] aitemstack = new ItemStack[inv.a()];
        for (int i = 0; i < aitemstack.length; ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null && itemstack.zerodayisaminecraftcheat().c()) {
                aitemstack[i] = new ItemStack(itemstack.zerodayisaminecraftcheat().b());
            }
        }
        return aitemstack;
    }
}

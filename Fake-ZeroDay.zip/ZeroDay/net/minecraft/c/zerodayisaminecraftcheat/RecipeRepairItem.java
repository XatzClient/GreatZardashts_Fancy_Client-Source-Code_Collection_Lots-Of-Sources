// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.Item;
import java.util.List;
import net.minecraft.c.ItemStack;
import com.google.common.collect.Lists;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;

public class RecipeRepairItem implements IRecipe
{
    @Override
    public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
        final List<ItemStack> list = (List<ItemStack>)Lists.newArrayList();
        for (int i = 0; i < inv.a(); ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null) {
                list.add(itemstack);
                if (list.size() > 1) {
                    final ItemStack itemstack2 = list.get(0);
                    if (itemstack.zerodayisaminecraftcheat() != itemstack2.zerodayisaminecraftcheat() || itemstack2.zeroday != 1 || itemstack.zeroday != 1 || !itemstack2.zerodayisaminecraftcheat().pandora()) {
                        return false;
                    }
                }
            }
        }
        return list.size() == 2;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
        final List<ItemStack> list = (List<ItemStack>)Lists.newArrayList();
        for (int i = 0; i < inv.a(); ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null) {
                list.add(itemstack);
                if (list.size() > 1) {
                    final ItemStack itemstack2 = list.get(0);
                    if (itemstack.zerodayisaminecraftcheat() != itemstack2.zerodayisaminecraftcheat() || itemstack2.zeroday != 1 || itemstack.zeroday != 1 || !itemstack2.zerodayisaminecraftcheat().pandora()) {
                        return null;
                    }
                }
            }
        }
        if (list.size() == 2) {
            final ItemStack itemstack3 = list.get(0);
            final ItemStack itemstack4 = list.get(1);
            if (itemstack3.zerodayisaminecraftcheat() == itemstack4.zerodayisaminecraftcheat() && itemstack3.zeroday == 1 && itemstack4.zeroday == 1 && itemstack3.zerodayisaminecraftcheat().pandora()) {
                final Item item = itemstack3.zerodayisaminecraftcheat();
                final int j = item.sigma() - itemstack3.vape();
                final int k = item.sigma() - itemstack4.vape();
                final int l = j + k + item.sigma() * 5 / 100;
                int i2 = item.sigma() - l;
                if (i2 < 0) {
                    i2 = 0;
                }
                return new ItemStack(itemstack3.zerodayisaminecraftcheat(), 1, i2);
            }
        }
        return null;
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        return 4;
    }
    
    @Override
    public ItemStack zeroday() {
        return null;
    }
    
    @Override
    public ItemStack[] zeroday(final InventoryCrafting inv) {
        final ItemStack[] aitemstack = new ItemStack[inv.a()];
        for (int i = 0; i < aitemstack.length; ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null && itemstack.zerodayisaminecraftcheat().c()) {
                aitemstack[i] = new ItemStack(itemstack.zerodayisaminecraftcheat().b());
            }
        }
        return aitemstack;
    }
}

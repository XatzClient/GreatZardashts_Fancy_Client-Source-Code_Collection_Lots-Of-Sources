// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;
import net.minecraft.c.Item;

public class RecipesArmor
{
    private String[][] zerodayisaminecraftcheat;
    private Item[][] zeroday;
    
    public RecipesArmor() {
        this.zerodayisaminecraftcheat = new String[][] { { "XXX", "X X" }, { "X X", "XXX", "XXX" }, { "XXX", "X X", "X X" }, { "X X", "X X" } };
        this.zeroday = new Item[][] { { Items.ax, Items.b, Items.a, Items.c }, { Items.I, Items.Q, Items.U, Items.Y }, { Items.J, Items.R, Items.V, Items.Z }, { Items.K, Items.S, Items.W, Items.aa }, { Items.L, Items.T, Items.X, Items.ab } };
    }
    
    public void zerodayisaminecraftcheat(final CraftingManager craftManager) {
        for (int i = 0; i < this.zeroday[0].length; ++i) {
            final Item item = this.zeroday[0][i];
            for (int j = 0; j < this.zeroday.length - 1; ++j) {
                final Item item2 = this.zeroday[j + 1][i];
                craftManager.zerodayisaminecraftcheat(new ItemStack(item2), this.zerodayisaminecraftcheat[j], 'X', item);
            }
        }
    }
}

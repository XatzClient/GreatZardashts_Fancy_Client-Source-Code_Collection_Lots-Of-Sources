// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.d.NBTTagCompound;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagList;
import net.minecraft.n.TileEntityBanner;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;
import net.minecraft.a.Blocks;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;
import net.minecraft.c.EnumDyeColor;

public class RecipesBanners
{
    void zerodayisaminecraftcheat(final CraftingManager p_179534_1_) {
        EnumDyeColor[] values;
        for (int length = (values = EnumDyeColor.values()).length, i = 0; i < length; ++i) {
            final EnumDyeColor enumdyecolor = values[i];
            p_179534_1_.zerodayisaminecraftcheat(new ItemStack(Items.cw, 1, enumdyecolor.sigma()), "###", "###", " | ", '#', new ItemStack(Blocks.D, 1, enumdyecolor.zeroday()), '|', Items.q);
        }
        p_179534_1_.zerodayisaminecraftcheat(new zeroday(null));
        p_179534_1_.zerodayisaminecraftcheat(new zerodayisaminecraftcheat(null));
    }
    
    static class zerodayisaminecraftcheat implements IRecipe
    {
        private zerodayisaminecraftcheat() {
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
            boolean flag = false;
            for (int i = 0; i < inv.a(); ++i) {
                final ItemStack itemstack = inv.d(i);
                if (itemstack != null && itemstack.zerodayisaminecraftcheat() == Items.cw) {
                    if (flag) {
                        return false;
                    }
                    if (TileEntityBanner.sigma(itemstack) >= 6) {
                        return false;
                    }
                    flag = true;
                }
            }
            return flag && this.sigma(inv) != null;
        }
        
        @Override
        public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
            ItemStack itemstack = null;
            for (int i = 0; i < inv.a(); ++i) {
                final ItemStack itemstack2 = inv.d(i);
                if (itemstack2 != null && itemstack2.zerodayisaminecraftcheat() == Items.cw) {
                    itemstack = itemstack2.b();
                    itemstack.zeroday = 1;
                    break;
                }
            }
            final TileEntityBanner.zerodayisaminecraftcheat tileentitybanner$enumbannerpattern = this.sigma(inv);
            if (tileentitybanner$enumbannerpattern != null) {
                int k = 0;
                for (int j = 0; j < inv.a(); ++j) {
                    final ItemStack itemstack3 = inv.d(j);
                    if (itemstack3 != null && itemstack3.zerodayisaminecraftcheat() == Items.aO) {
                        k = itemstack3.momgetthecamera();
                        break;
                    }
                }
                final NBTTagCompound nbttagcompound1 = itemstack.zerodayisaminecraftcheat("BlockEntityTag", true);
                NBTTagList nbttaglist = null;
                if (nbttagcompound1.zeroday("Patterns", 9)) {
                    nbttaglist = nbttagcompound1.sigma("Patterns", 10);
                }
                else {
                    nbttaglist = new NBTTagList();
                    nbttagcompound1.zerodayisaminecraftcheat("Patterns", nbttaglist);
                }
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                nbttagcompound2.zerodayisaminecraftcheat("Pattern", tileentitybanner$enumbannerpattern.zeroday());
                nbttagcompound2.zerodayisaminecraftcheat("Color", k);
                nbttaglist.zerodayisaminecraftcheat(nbttagcompound2);
            }
            return itemstack;
        }
        
        @Override
        public int zerodayisaminecraftcheat() {
            return 10;
        }
        
        @Override
        public ItemStack zeroday() {
            return null;
        }
        
        @Override
        public ItemStack[] zeroday(final InventoryCrafting inv) {
            final ItemStack[] aitemstack = new ItemStack[inv.a()];
            for (int i = 0; i < aitemstack.length; ++i) {
                final ItemStack itemstack = inv.d(i);
                if (itemstack != null && itemstack.zerodayisaminecraftcheat().c()) {
                    aitemstack[i] = new ItemStack(itemstack.zerodayisaminecraftcheat().b());
                }
            }
            return aitemstack;
        }
        
        private TileEntityBanner.zerodayisaminecraftcheat sigma(final InventoryCrafting p_179533_1_) {
            TileEntityBanner.zerodayisaminecraftcheat[] values;
            for (int length = (values = TileEntityBanner.zerodayisaminecraftcheat.values()).length, n = 0; n < length; ++n) {
                final TileEntityBanner.zerodayisaminecraftcheat tileentitybanner$enumbannerpattern = values[n];
                if (tileentitybanner$enumbannerpattern.pandora()) {
                    boolean flag = true;
                    if (tileentitybanner$enumbannerpattern.zues()) {
                        boolean flag2 = false;
                        boolean flag3 = false;
                        for (int i = 0; i < p_179533_1_.a() && flag; ++i) {
                            final ItemStack itemstack = p_179533_1_.d(i);
                            if (itemstack != null && itemstack.zerodayisaminecraftcheat() != Items.cw) {
                                if (itemstack.zerodayisaminecraftcheat() == Items.aO) {
                                    if (flag3) {
                                        flag = false;
                                        break;
                                    }
                                    flag3 = true;
                                }
                                else {
                                    if (flag2 || !itemstack.zerodayisaminecraftcheat(tileentitybanner$enumbannerpattern.flux())) {
                                        flag = false;
                                        break;
                                    }
                                    flag2 = true;
                                }
                            }
                        }
                        if (!flag2) {
                            flag = false;
                        }
                    }
                    else if (p_179533_1_.a() == tileentitybanner$enumbannerpattern.sigma().length * tileentitybanner$enumbannerpattern.sigma()[0].length()) {
                        int j = -1;
                        for (int k = 0; k < p_179533_1_.a(); ++k) {
                            if (!flag) {
                                break;
                            }
                            final int l = k / 3;
                            final int i2 = k % 3;
                            final ItemStack itemstack2 = p_179533_1_.d(k);
                            if (itemstack2 != null && itemstack2.zerodayisaminecraftcheat() != Items.cw) {
                                if (itemstack2.zerodayisaminecraftcheat() != Items.aO) {
                                    flag = false;
                                    break;
                                }
                                if (j != -1 && j != itemstack2.momgetthecamera()) {
                                    flag = false;
                                    break;
                                }
                                if (tileentitybanner$enumbannerpattern.sigma()[l].charAt(i2) == ' ') {
                                    flag = false;
                                    break;
                                }
                                j = itemstack2.momgetthecamera();
                            }
                            else if (tileentitybanner$enumbannerpattern.sigma()[l].charAt(i2) != ' ') {
                                flag = false;
                                break;
                            }
                        }
                    }
                    else {
                        flag = false;
                    }
                    if (flag) {
                        return tileentitybanner$enumbannerpattern;
                    }
                }
            }
            return null;
        }
    }
    
    static class zeroday implements IRecipe
    {
        private zeroday() {
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
            ItemStack itemstack = null;
            ItemStack itemstack2 = null;
            for (int i = 0; i < inv.a(); ++i) {
                final ItemStack itemstack3 = inv.d(i);
                if (itemstack3 != null) {
                    if (itemstack3.zerodayisaminecraftcheat() != Items.cw) {
                        return false;
                    }
                    if (itemstack != null && itemstack2 != null) {
                        return false;
                    }
                    final int j = TileEntityBanner.zeroday(itemstack3);
                    final boolean flag = TileEntityBanner.sigma(itemstack3) > 0;
                    if (itemstack != null) {
                        if (flag) {
                            return false;
                        }
                        if (j != TileEntityBanner.zeroday(itemstack)) {
                            return false;
                        }
                        itemstack2 = itemstack3;
                    }
                    else if (itemstack2 != null) {
                        if (!flag) {
                            return false;
                        }
                        if (j != TileEntityBanner.zeroday(itemstack2)) {
                            return false;
                        }
                        itemstack = itemstack3;
                    }
                    else if (flag) {
                        itemstack = itemstack3;
                    }
                    else {
                        itemstack2 = itemstack3;
                    }
                }
            }
            return itemstack != null && itemstack2 != null;
        }
        
        @Override
        public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
            for (int i = 0; i < inv.a(); ++i) {
                final ItemStack itemstack = inv.d(i);
                if (itemstack != null && TileEntityBanner.sigma(itemstack) > 0) {
                    final ItemStack itemstack2 = itemstack.b();
                    itemstack2.zeroday = 1;
                    return itemstack2;
                }
            }
            return null;
        }
        
        @Override
        public int zerodayisaminecraftcheat() {
            return 2;
        }
        
        @Override
        public ItemStack zeroday() {
            return null;
        }
        
        @Override
        public ItemStack[] zeroday(final InventoryCrafting inv) {
            final ItemStack[] aitemstack = new ItemStack[inv.a()];
            for (int i = 0; i < aitemstack.length; ++i) {
                final ItemStack itemstack = inv.d(i);
                if (itemstack != null) {
                    if (itemstack.zerodayisaminecraftcheat().c()) {
                        aitemstack[i] = new ItemStack(itemstack.zerodayisaminecraftcheat().b());
                    }
                    else if (itemstack.f() && TileEntityBanner.sigma(itemstack) > 0) {
                        aitemstack[i] = itemstack.b();
                        aitemstack[i].zeroday = 1;
                    }
                }
            }
            return aitemstack;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.EnumDyeColor;
import net.minecraft.zerodayisaminecraftcheat.BlockPrismarine;
import net.minecraft.zerodayisaminecraftcheat.BlockDirt;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneBrick;
import net.minecraft.zerodayisaminecraftcheat.BlockStone;
import net.minecraft.zerodayisaminecraftcheat.BlockQuartz;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlabNew;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlab;
import net.minecraft.zerodayisaminecraftcheat.BlockRedSandstone;
import net.minecraft.zerodayisaminecraftcheat.BlockSandStone;
import net.minecraft.zerodayisaminecraftcheat.BlockSand;
import net.minecraft.a.Items;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Blocks;

public class RecipesCrafting
{
    public void zerodayisaminecraftcheat(final CraftingManager p_77589_1_) {
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.W), "###", "# #", "###", '#', Blocks.flux);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.bY), "#-", '#', Blocks.W, '-', Blocks.bJ);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.bI), "###", "#E#", "###", '#', Blocks.R, 'E', Items.bz);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.ad), "###", "# #", "###", '#', Blocks.zues);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.aa), "##", "##", '#', Blocks.flux);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.s), "##", "##", '#', new ItemStack(Blocks.e, 1, BlockSand.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cE), "##", "##", '#', new ItemStack(Blocks.e, 1, BlockSand.zerodayisaminecraftcheat.zeroday.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.s, 4, BlockSandStone.zerodayisaminecraftcheat.sigma.zeroday()), "##", "##", '#', new ItemStack(Blocks.s, 1, BlockSandStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cE, 4, BlockRedSandstone.zerodayisaminecraftcheat.sigma.zeroday()), "##", "##", '#', new ItemStack(Blocks.cE, 1, BlockRedSandstone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.s, 1, BlockSandStone.zerodayisaminecraftcheat.zeroday.zeroday()), "#", "#", '#', new ItemStack(Blocks.M, 1, BlockStoneSlab.zerodayisaminecraftcheat.zeroday.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cE, 1, BlockRedSandstone.zerodayisaminecraftcheat.zeroday.zeroday()), "#", "#", '#', new ItemStack(Blocks.cH, 1, BlockStoneSlabNew.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.ci, 1, BlockQuartz.zerodayisaminecraftcheat.zeroday.zeroday()), "#", "#", '#', new ItemStack(Blocks.M, 1, BlockStoneSlab.zerodayisaminecraftcheat.momgetthecamera.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.ci, 2, BlockQuartz.zerodayisaminecraftcheat.sigma.zeroday()), "#", "#", '#', new ItemStack(Blocks.ci, 1, BlockQuartz.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.aX, 4), "##", "##", '#', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.aX, 1, BlockStoneBrick.H), "#", "#", '#', new ItemStack(Blocks.M, 1, BlockStoneSlab.zerodayisaminecraftcheat.flux.zeroday()));
        p_77589_1_.zeroday(new ItemStack(Blocks.aX, 1, BlockStoneBrick.F), Blocks.aX, Blocks.bf);
        p_77589_1_.zeroday(new ItemStack(Blocks.Q, 1), Blocks.zues, Blocks.bf);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.ba, 16), "###", "###", '#', Items.b);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.bb, 16), "###", "###", '#', Blocks.o);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.bB, 1), " R ", "RGR", " R ", 'R', Items.au, 'G', Blocks.aP);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.bQ, 1), "GGG", "GSG", "OOO", 'G', Blocks.o, 'S', Items.bR, 'O', Blocks.R);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.bq, 1), "NN", "NN", 'N', Items.bX);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.zeroday, 2, BlockStone.zerodayisaminecraftcheat.pandora.zeroday()), "CQ", "QC", 'C', Blocks.zues, 'Q', Items.bY);
        p_77589_1_.zeroday(new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.zeroday.zeroday()), new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.pandora.zeroday()), Items.bY);
        p_77589_1_.zeroday(new ItemStack(Blocks.zeroday, 2, BlockStone.zerodayisaminecraftcheat.flux.zeroday()), new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.pandora.zeroday()), Blocks.zues);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.pandora, 4, BlockDirt.zerodayisaminecraftcheat.zeroday.zeroday()), "DG", "GD", 'D', new ItemStack(Blocks.pandora, 1, BlockDirt.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday()), 'G', Blocks.f);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.zeroday, 4, BlockStone.zerodayisaminecraftcheat.zues.zeroday()), "SS", "SS", 'S', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.pandora.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.zeroday, 4, BlockStone.zerodayisaminecraftcheat.sigma.zeroday()), "SS", "SS", 'S', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.zeroday.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.zeroday, 4, BlockStone.zerodayisaminecraftcheat.vape.zeroday()), "SS", "SS", 'S', new ItemStack(Blocks.zeroday, 1, BlockStone.zerodayisaminecraftcheat.flux.zeroday()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cA, 1, BlockPrismarine.E), "SS", "SS", 'S', Items.cu);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cA, 1, BlockPrismarine.F), "SSS", "SSS", "SSS", 'S', Items.cu);
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cA, 1, BlockPrismarine.G), "SSS", "SIS", "SSS", 'S', Items.cu, 'I', new ItemStack(Items.aO, 1, EnumDyeColor.h.sigma()));
        p_77589_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cB, 1, 0), "SCS", "CCC", "SCS", 'S', Items.cu, 'C', Items.cv);
    }
}

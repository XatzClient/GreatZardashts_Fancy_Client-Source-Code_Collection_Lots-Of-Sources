// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.zerodayisaminecraftcheat.BlockDoublePlant;
import net.minecraft.zerodayisaminecraftcheat.BlockFlower;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.Item;
import net.minecraft.a.Items;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Blocks;

public class RecipesDyes
{
    public void zerodayisaminecraftcheat(final CraftingManager p_77607_1_) {
        for (int i = 0; i < 16; ++i) {
            p_77607_1_.zeroday(new ItemStack(Blocks.D, 1, i), new ItemStack(Items.aO, 1, 15 - i), new ItemStack(Item.zerodayisaminecraftcheat(Blocks.D), 1, 0));
            p_77607_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cm, 8, 15 - i), "###", "#X#", "###", '#', new ItemStack(Blocks.cr), 'X', new ItemStack(Items.aO, 1, i));
            p_77607_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cy, 8, 15 - i), "###", "#X#", "###", '#', new ItemStack(Blocks.o), 'X', new ItemStack(Items.aO, 1, i));
            p_77607_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cz, 16, i), "###", "###", '#', new ItemStack(Blocks.cy, 1, i));
        }
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.zues.sigma()), new ItemStack(Blocks.F, 1, BlockFlower.zeroday.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.zeroday.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 3, EnumDyeColor.zerodayisaminecraftcheat.sigma()), Items.aP);
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.vape.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.zeroday.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zues.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.flux.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.f.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.momgetthecamera.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.h.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.a.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.momgetthecamera.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 3, EnumDyeColor.a.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.h.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.pandora.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.d.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.b.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.d.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.f.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.c.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.d.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.sigma.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.c.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.vape.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 3, EnumDyeColor.sigma.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.d.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.vape.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 4, EnumDyeColor.sigma.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.d.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()), new ItemStack(Items.aO, 1, EnumDyeColor.zerodayisaminecraftcheat.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.pandora.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.sigma.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.sigma.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.pandora.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.a.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.zues.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.g.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.flux.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.zeroday.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.vape.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.a.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.momgetthecamera.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.vape.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.a.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 1, EnumDyeColor.a.sigma()), new ItemStack(Blocks.G, 1, BlockFlower.zeroday.b.sigma()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.zues.sigma()), new ItemStack(Blocks.cx, 1, BlockDoublePlant.zeroday.zerodayisaminecraftcheat.zeroday()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.sigma.sigma()), new ItemStack(Blocks.cx, 1, BlockDoublePlant.zeroday.zeroday.zeroday()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.g.sigma()), new ItemStack(Blocks.cx, 1, BlockDoublePlant.zeroday.zues.zeroday()));
        p_77607_1_.zeroday(new ItemStack(Items.aO, 2, EnumDyeColor.vape.sigma()), new ItemStack(Blocks.cx, 1, BlockDoublePlant.zeroday.flux.zeroday()));
        for (int j = 0; j < 16; ++j) {
            p_77607_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.cq, 3, j), "##", '#', new ItemStack(Blocks.D, 1, j));
        }
    }
}

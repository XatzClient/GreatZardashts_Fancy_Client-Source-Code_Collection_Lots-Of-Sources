// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.EnumDyeColor;
import net.minecraft.a.Blocks;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;

public class RecipesFood
{
    public void zerodayisaminecraftcheat(final CraftingManager p_77608_1_) {
        p_77608_1_.zeroday(new ItemStack(Items.s), Blocks.H, Blocks.I, Items.r);
        p_77608_1_.zerodayisaminecraftcheat(new ItemStack(Items.aU, 8), "#X#", 'X', new ItemStack(Items.aO, 1, EnumDyeColor.e.sigma()), '#', Items.G);
        p_77608_1_.zerodayisaminecraftcheat(new ItemStack(Items.bi), " R ", "CPM", " B ", 'R', new ItemStack(Items.bh), 'C', Items.bJ, 'P', Items.bL, 'M', Blocks.H, 'B', Items.r);
        p_77608_1_.zerodayisaminecraftcheat(new ItemStack(Items.bi), " R ", "CPD", " B ", 'R', new ItemStack(Items.bh), 'C', Items.bJ, 'P', Items.bL, 'D', Blocks.I, 'B', Items.r);
        p_77608_1_.zerodayisaminecraftcheat(new ItemStack(Blocks.bc), "MMM", "MMM", "MMM", 'M', Items.aX);
        p_77608_1_.zerodayisaminecraftcheat(new ItemStack(Items.aZ), "M", 'M', Items.aX);
        p_77608_1_.zerodayisaminecraftcheat(new ItemStack(Items.aY, 4), "M", 'M', Blocks.aM);
        p_77608_1_.zeroday(new ItemStack(Items.bS), Blocks.aM, Items.aQ, Items.aH);
        p_77608_1_.zeroday(new ItemStack(Items.bu), Items.bt, Blocks.H, Items.aQ);
        p_77608_1_.zeroday(new ItemStack(Items.bv, 2), Items.bn);
        p_77608_1_.zeroday(new ItemStack(Items.bw), Items.bv, Items.aE);
    }
}

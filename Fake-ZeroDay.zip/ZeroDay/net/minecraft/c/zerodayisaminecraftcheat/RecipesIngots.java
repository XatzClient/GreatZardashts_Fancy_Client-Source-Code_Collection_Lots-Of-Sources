// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;
import net.minecraft.a.Blocks;

public class RecipesIngots
{
    private Object[][] zerodayisaminecraftcheat;
    
    public RecipesIngots() {
        this.zerodayisaminecraftcheat = new Object[][] { { Blocks.J, new ItemStack(Items.c, 9) }, { Blocks.K, new ItemStack(Items.b, 9) }, { Blocks.Z, new ItemStack(Items.a, 9) }, { Blocks.bL, new ItemStack(Items.bG, 9) }, { Blocks.q, new ItemStack(Items.aO, 9, EnumDyeColor.d.sigma()) }, { Blocks.cf, new ItemStack(Items.au, 9) }, { Blocks.cs, new ItemStack(Items.momgetthecamera, 9, 0) }, { Blocks.cp, new ItemStack(Items.G, 9) }, { Blocks.cw, new ItemStack(Items.aE, 9) } };
    }
    
    public void zerodayisaminecraftcheat(final CraftingManager p_77590_1_) {
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            final Block block = (Block)this.zerodayisaminecraftcheat[i][0];
            final ItemStack itemstack = (ItemStack)this.zerodayisaminecraftcheat[i][1];
            p_77590_1_.zerodayisaminecraftcheat(new ItemStack(block), "###", "###", "###", '#', itemstack);
            p_77590_1_.zerodayisaminecraftcheat(itemstack, "#", '#', block);
        }
        p_77590_1_.zerodayisaminecraftcheat(new ItemStack(Items.c), "###", "###", "###", '#', Items.bp);
        p_77590_1_.zerodayisaminecraftcheat(new ItemStack(Items.bp, 9), "#", '#', Items.c);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.Item;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;

public class RecipesMapCloning implements IRecipe
{
    @Override
    public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
        int i = 0;
        ItemStack itemstack = null;
        for (int j = 0; j < inv.a(); ++j) {
            final ItemStack itemstack2 = inv.d(j);
            if (itemstack2 != null) {
                if (itemstack2.zerodayisaminecraftcheat() == Items.aV) {
                    if (itemstack != null) {
                        return false;
                    }
                    itemstack = itemstack2;
                }
                else {
                    if (itemstack2.zerodayisaminecraftcheat() != Items.bN) {
                        return false;
                    }
                    ++i;
                }
            }
        }
        return itemstack != null && i > 0;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
        int i = 0;
        ItemStack itemstack = null;
        for (int j = 0; j < inv.a(); ++j) {
            final ItemStack itemstack2 = inv.d(j);
            if (itemstack2 != null) {
                if (itemstack2.zerodayisaminecraftcheat() == Items.aV) {
                    if (itemstack != null) {
                        return null;
                    }
                    itemstack = itemstack2;
                }
                else {
                    if (itemstack2.zerodayisaminecraftcheat() != Items.bN) {
                        return null;
                    }
                    ++i;
                }
            }
        }
        if (itemstack != null && i >= 1) {
            final ItemStack itemstack3 = new ItemStack(Items.aV, i + 1, itemstack.momgetthecamera());
            if (itemstack.k()) {
                itemstack3.zerodayisaminecraftcheat(itemstack.i());
            }
            return itemstack3;
        }
        return null;
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        return 9;
    }
    
    @Override
    public ItemStack zeroday() {
        return null;
    }
    
    @Override
    public ItemStack[] zeroday(final InventoryCrafting inv) {
        final ItemStack[] aitemstack = new ItemStack[inv.a()];
        for (int i = 0; i < aitemstack.length; ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null && itemstack.zerodayisaminecraftcheat().c()) {
                aitemstack[i] = new ItemStack(itemstack.zerodayisaminecraftcheat().b());
            }
        }
        return aitemstack;
    }
}

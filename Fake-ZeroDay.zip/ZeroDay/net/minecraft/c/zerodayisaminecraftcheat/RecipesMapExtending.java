// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.d.NBTTagCompound;
import net.minecraft.q.vape.MapData;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;
import net.minecraft.c.Item;
import net.minecraft.a.Items;
import net.minecraft.c.ItemStack;

public class RecipesMapExtending extends ShapedRecipes
{
    public RecipesMapExtending() {
        super(3, 3, new ItemStack[] { new ItemStack(Items.aC), new ItemStack(Items.aC), new ItemStack(Items.aC), new ItemStack(Items.aC), new ItemStack(Items.aV, 0, 32767), new ItemStack(Items.aC), new ItemStack(Items.aC), new ItemStack(Items.aC), new ItemStack(Items.aC) }, new ItemStack(Items.bN, 0, 0));
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
        if (!super.zerodayisaminecraftcheat(inv, worldIn)) {
            return false;
        }
        ItemStack itemstack = null;
        for (int i = 0; i < inv.a() && itemstack == null; ++i) {
            final ItemStack itemstack2 = inv.d(i);
            if (itemstack2 != null && itemstack2.zerodayisaminecraftcheat() == Items.aV) {
                itemstack = itemstack2;
            }
        }
        if (itemstack == null) {
            return false;
        }
        final MapData mapdata = Items.aV.zerodayisaminecraftcheat(itemstack, worldIn);
        return mapdata != null && mapdata.zues < 4;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
        ItemStack itemstack = null;
        for (int i = 0; i < inv.a() && itemstack == null; ++i) {
            final ItemStack itemstack2 = inv.d(i);
            if (itemstack2 != null && itemstack2.zerodayisaminecraftcheat() == Items.aV) {
                itemstack = itemstack2;
            }
        }
        itemstack = itemstack.b();
        itemstack.zeroday = 1;
        if (itemstack.g() == null) {
            itemstack.pandora(new NBTTagCompound());
        }
        itemstack.g().zerodayisaminecraftcheat("map_is_scaling", true);
        return itemstack;
    }
}

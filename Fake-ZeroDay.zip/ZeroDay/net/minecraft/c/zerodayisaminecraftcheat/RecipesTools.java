// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.ItemStack;
import net.minecraft.c.Item;
import net.minecraft.a.Items;
import net.minecraft.a.Blocks;

public class RecipesTools
{
    private String[][] zerodayisaminecraftcheat;
    private Object[][] zeroday;
    
    public RecipesTools() {
        this.zerodayisaminecraftcheat = new String[][] { { "XXX", " # ", " # " }, { "X", "#", "#" }, { "XX", "X#", " #" }, { "XX", " #", " #" } };
        this.zeroday = new Object[][] { { Blocks.flux, Blocks.zues, Items.b, Items.a, Items.c }, { Items.g, Items.k, Items.zeroday, Items.o, Items.v }, { Items.f, Items.j, Items.zerodayisaminecraftcheat, Items.n, Items.u }, { Items.h, Items.l, Items.sigma, Items.p, Items.w }, { Items.A, Items.B, Items.C, Items.D, Items.E } };
    }
    
    public void zerodayisaminecraftcheat(final CraftingManager p_77586_1_) {
        for (int i = 0; i < this.zeroday[0].length; ++i) {
            final Object object = this.zeroday[0][i];
            for (int j = 0; j < this.zeroday.length - 1; ++j) {
                final Item item = (Item)this.zeroday[j + 1][i];
                p_77586_1_.zerodayisaminecraftcheat(new ItemStack(item), this.zerodayisaminecraftcheat[j], '#', Items.q, 'X', object);
            }
        }
        p_77586_1_.zerodayisaminecraftcheat(new ItemStack(Items.aW), " #", "# ", '#', Items.b);
    }
}

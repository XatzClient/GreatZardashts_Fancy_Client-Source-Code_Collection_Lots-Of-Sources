// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.c.ItemStack;
import net.minecraft.c.Item;
import net.minecraft.a.Items;
import net.minecraft.a.Blocks;

public class RecipesWeapons
{
    private String[][] zerodayisaminecraftcheat;
    private Object[][] zeroday;
    
    public RecipesWeapons() {
        this.zerodayisaminecraftcheat = new String[][] { { "X", "X", "#" } };
        this.zeroday = new Object[][] { { Blocks.flux, Blocks.zues, Items.b, Items.a, Items.c }, { Items.e, Items.i, Items.d, Items.m, Items.t } };
    }
    
    public void zerodayisaminecraftcheat(final CraftingManager p_77583_1_) {
        for (int i = 0; i < this.zeroday[0].length; ++i) {
            final Object object = this.zeroday[0][i];
            for (int j = 0; j < this.zeroday.length - 1; ++j) {
                final Item item = (Item)this.zeroday[j + 1][i];
                p_77583_1_.zerodayisaminecraftcheat(new ItemStack(item), this.zerodayisaminecraftcheat[j], '#', Items.q, 'X', object);
            }
        }
        p_77583_1_.zerodayisaminecraftcheat(new ItemStack(Items.flux, 1), " #X", "# X", " #X", 'X', Items.x, '#', Items.q);
        p_77583_1_.zerodayisaminecraftcheat(new ItemStack(Items.vape, 4), "X", "#", "Y", 'Y', Items.y, 'X', Items.ac, '#', Items.q);
    }
}

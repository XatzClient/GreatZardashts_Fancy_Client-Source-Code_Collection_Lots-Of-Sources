// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import net.minecraft.d.NBTTagCompound;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;
import net.minecraft.c.ItemStack;

public class ShapedRecipes implements IRecipe
{
    private final int zerodayisaminecraftcheat;
    private final int zeroday;
    private final ItemStack[] sigma;
    private final ItemStack pandora;
    private boolean zues;
    
    public ShapedRecipes(final int width, final int height, final ItemStack[] p_i1917_3_, final ItemStack output) {
        this.zerodayisaminecraftcheat = width;
        this.zeroday = height;
        this.sigma = p_i1917_3_;
        this.pandora = output;
    }
    
    @Override
    public ItemStack zeroday() {
        return this.pandora;
    }
    
    @Override
    public ItemStack[] zeroday(final InventoryCrafting inv) {
        final ItemStack[] aitemstack = new ItemStack[inv.a()];
        for (int i = 0; i < aitemstack.length; ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null && itemstack.zerodayisaminecraftcheat().c()) {
                aitemstack[i] = new ItemStack(itemstack.zerodayisaminecraftcheat().b());
            }
        }
        return aitemstack;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
        for (int i = 0; i <= 3 - this.zerodayisaminecraftcheat; ++i) {
            for (int j = 0; j <= 3 - this.zeroday; ++j) {
                if (this.zerodayisaminecraftcheat(inv, i, j, true)) {
                    return true;
                }
                if (this.zerodayisaminecraftcheat(inv, i, j, false)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean zerodayisaminecraftcheat(final InventoryCrafting p_77573_1_, final int p_77573_2_, final int p_77573_3_, final boolean p_77573_4_) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                final int k = i - p_77573_2_;
                final int l = j - p_77573_3_;
                ItemStack itemstack = null;
                if (k >= 0 && l >= 0 && k < this.zerodayisaminecraftcheat && l < this.zeroday) {
                    if (p_77573_4_) {
                        itemstack = this.sigma[this.zerodayisaminecraftcheat - k - 1 + l * this.zerodayisaminecraftcheat];
                    }
                    else {
                        itemstack = this.sigma[k + l * this.zerodayisaminecraftcheat];
                    }
                }
                final ItemStack itemstack2 = p_77573_1_.sigma(i, j);
                if (itemstack2 != null || itemstack != null) {
                    if ((itemstack2 == null && itemstack != null) || (itemstack2 != null && itemstack == null)) {
                        return false;
                    }
                    if (itemstack.zerodayisaminecraftcheat() != itemstack2.zerodayisaminecraftcheat()) {
                        return false;
                    }
                    if (itemstack.momgetthecamera() != 32767 && itemstack.momgetthecamera() != itemstack2.momgetthecamera()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
        final ItemStack itemstack = this.zeroday().b();
        if (this.zues) {
            for (int i = 0; i < inv.a(); ++i) {
                final ItemStack itemstack2 = inv.d(i);
                if (itemstack2 != null && itemstack2.f()) {
                    itemstack.pandora((NBTTagCompound)itemstack2.g().zeroday());
                }
            }
        }
        return itemstack;
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat * this.zeroday;
    }
}

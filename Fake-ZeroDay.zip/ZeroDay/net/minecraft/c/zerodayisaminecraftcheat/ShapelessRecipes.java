// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.c.zerodayisaminecraftcheat;

import java.util.Iterator;
import com.google.common.collect.Lists;
import net.minecraft.q.World;
import net.minecraft.b.InventoryCrafting;
import java.util.List;
import net.minecraft.c.ItemStack;

public class ShapelessRecipes implements IRecipe
{
    private final ItemStack zerodayisaminecraftcheat;
    private final List<ItemStack> zeroday;
    
    public ShapelessRecipes(final ItemStack output, final List<ItemStack> inputList) {
        this.zerodayisaminecraftcheat = output;
        this.zeroday = inputList;
    }
    
    @Override
    public ItemStack zeroday() {
        return this.zerodayisaminecraftcheat;
    }
    
    @Override
    public ItemStack[] zeroday(final InventoryCrafting inv) {
        final ItemStack[] aitemstack = new ItemStack[inv.a()];
        for (int i = 0; i < aitemstack.length; ++i) {
            final ItemStack itemstack = inv.d(i);
            if (itemstack != null && itemstack.zerodayisaminecraftcheat().c()) {
                aitemstack[i] = new ItemStack(itemstack.zerodayisaminecraftcheat().b());
            }
        }
        return aitemstack;
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final InventoryCrafting inv, final World worldIn) {
        final List<ItemStack> list = (List<ItemStack>)Lists.newArrayList((Iterable)this.zeroday);
        for (int i = 0; i < inv.pandora(); ++i) {
            for (int j = 0; j < inv.flux(); ++j) {
                final ItemStack itemstack = inv.sigma(j, i);
                if (itemstack != null) {
                    boolean flag = false;
                    for (final ItemStack itemstack2 : list) {
                        if (itemstack.zerodayisaminecraftcheat() == itemstack2.zerodayisaminecraftcheat() && (itemstack2.momgetthecamera() == 32767 || itemstack.momgetthecamera() == itemstack2.momgetthecamera())) {
                            flag = true;
                            list.remove(itemstack2);
                            break;
                        }
                    }
                    if (!flag) {
                        return false;
                    }
                }
            }
        }
        return list.isEmpty();
    }
    
    @Override
    public ItemStack zerodayisaminecraftcheat(final InventoryCrafting inv) {
        return this.zerodayisaminecraftcheat.b();
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        return this.zeroday.size();
    }
}

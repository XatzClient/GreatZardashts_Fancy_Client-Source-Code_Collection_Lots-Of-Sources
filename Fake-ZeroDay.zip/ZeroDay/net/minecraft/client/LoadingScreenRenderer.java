// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client;

import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.sigma.Gui;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.MinecraftError;
import net.minecraft.client.d.Framebuffer;
import net.minecraft.client.sigma.ScaledResolution;
import net.minecraft.o.IProgressUpdate;

public class LoadingScreenRenderer implements IProgressUpdate
{
    private String zerodayisaminecraftcheat;
    private Minecraft zeroday;
    private String sigma;
    private long pandora;
    private boolean zues;
    private ScaledResolution flux;
    private Framebuffer vape;
    
    public LoadingScreenRenderer(final Minecraft mcIn) {
        this.zerodayisaminecraftcheat = "";
        this.sigma = "";
        this.pandora = Minecraft.C();
        this.zeroday = mcIn;
        this.flux = new ScaledResolution(mcIn);
        (this.vape = new Framebuffer(mcIn.flux, mcIn.vape, false)).zerodayisaminecraftcheat(9728);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String message) {
        this.zues = false;
        this.pandora(message);
    }
    
    @Override
    public void zeroday(final String message) {
        this.zues = true;
        this.pandora(message);
    }
    
    private void pandora(final String message) {
        this.sigma = message;
        if (!this.zeroday.D) {
            if (!this.zues) {
                throw new MinecraftError();
            }
        }
        else {
            GlStateManager.c(256);
            GlStateManager.d(5889);
            GlStateManager.u();
            if (OpenGlHelper.a()) {
                final int i = this.flux.zues();
                GlStateManager.zerodayisaminecraftcheat(0.0, this.flux.zerodayisaminecraftcheat() * i, this.flux.zeroday() * i, 0.0, 100.0, 300.0);
            }
            else {
                final ScaledResolution scaledresolution = new ScaledResolution(this.zeroday);
                GlStateManager.zerodayisaminecraftcheat(0.0, scaledresolution.sigma(), scaledresolution.pandora(), 0.0, 100.0, 300.0);
            }
            GlStateManager.d(5888);
            GlStateManager.u();
            GlStateManager.zeroday(0.0f, 0.0f, -200.0f);
        }
    }
    
    @Override
    public void sigma(final String message) {
        if (!this.zeroday.D) {
            if (!this.zues) {
                throw new MinecraftError();
            }
        }
        else {
            this.pandora = 0L;
            this.zerodayisaminecraftcheat = message;
            this.zerodayisaminecraftcheat(-1);
            this.pandora = 0L;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int progress) {
        if (!this.zeroday.D) {
            if (!this.zues) {
                throw new MinecraftError();
            }
        }
        else {
            final long i = Minecraft.C();
            if (i - this.pandora >= 100L) {
                this.pandora = i;
                final ScaledResolution scaledresolution = new ScaledResolution(this.zeroday);
                final int j = scaledresolution.zues();
                final int k = scaledresolution.zerodayisaminecraftcheat();
                final int l = scaledresolution.zeroday();
                if (OpenGlHelper.a()) {
                    this.vape.flux();
                }
                else {
                    GlStateManager.c(256);
                }
                this.vape.zerodayisaminecraftcheat(false);
                GlStateManager.d(5889);
                GlStateManager.u();
                GlStateManager.zerodayisaminecraftcheat(0.0, scaledresolution.sigma(), scaledresolution.pandora(), 0.0, 100.0, 300.0);
                GlStateManager.d(5888);
                GlStateManager.u();
                GlStateManager.zeroday(0.0f, 0.0f, -200.0f);
                if (!OpenGlHelper.a()) {
                    GlStateManager.c(16640);
                }
                final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                final WorldRenderer worldrenderer = tessellator.sigma();
                this.zeroday.I().zerodayisaminecraftcheat(Gui.m);
                final float f = 32.0f;
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
                worldrenderer.zeroday(0.0, l, 0.0).zerodayisaminecraftcheat(0.0, l / f).zeroday(64, 64, 64, 255).zues();
                worldrenderer.zeroday(k, l, 0.0).zerodayisaminecraftcheat(k / f, l / f).zeroday(64, 64, 64, 255).zues();
                worldrenderer.zeroday(k, 0.0, 0.0).zerodayisaminecraftcheat(k / f, 0.0).zeroday(64, 64, 64, 255).zues();
                worldrenderer.zeroday(0.0, 0.0, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(64, 64, 64, 255).zues();
                tessellator.zeroday();
                if (progress >= 0) {
                    final int i2 = 100;
                    final int j2 = 2;
                    final int k2 = k / 2 - i2 / 2;
                    final int l2 = l / 2 + 16;
                    GlStateManager.n();
                    worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
                    worldrenderer.zeroday(k2, l2, 0.0).zeroday(128, 128, 128, 255).zues();
                    worldrenderer.zeroday(k2, l2 + j2, 0.0).zeroday(128, 128, 128, 255).zues();
                    worldrenderer.zeroday(k2 + i2, l2 + j2, 0.0).zeroday(128, 128, 128, 255).zues();
                    worldrenderer.zeroday(k2 + i2, l2, 0.0).zeroday(128, 128, 128, 255).zues();
                    worldrenderer.zeroday(k2, l2, 0.0).zeroday(128, 255, 128, 255).zues();
                    worldrenderer.zeroday(k2, l2 + j2, 0.0).zeroday(128, 255, 128, 255).zues();
                    worldrenderer.zeroday(k2 + progress, l2 + j2, 0.0).zeroday(128, 255, 128, 255).zues();
                    worldrenderer.zeroday(k2 + progress, l2, 0.0).zeroday(128, 255, 128, 255).zues();
                    tessellator.zeroday();
                    GlStateManager.m();
                }
                GlStateManager.d();
                GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
                this.zeroday.i.zerodayisaminecraftcheat(this.sigma, (float)((k - this.zeroday.i.zerodayisaminecraftcheat(this.sigma)) / 2), (float)(l / 2 - 4 - 16), 16777215);
                this.zeroday.i.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, (float)((k - this.zeroday.i.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat)) / 2), (float)(l / 2 - 4 + 8), 16777215);
                this.vape.zues();
                if (OpenGlHelper.a()) {
                    this.vape.sigma(k * j, l * j);
                }
                this.zeroday.a();
                try {
                    Thread.yield();
                }
                catch (Exception ex) {}
            }
        }
    }
    
    @Override
    public void t_() {
    }
}

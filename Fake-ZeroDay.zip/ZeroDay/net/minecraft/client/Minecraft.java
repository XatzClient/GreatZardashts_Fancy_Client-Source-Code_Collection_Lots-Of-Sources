// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.concurrent.Executors;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFutureTask;
import org.apache.commons.lang3.Validate;
import net.minecraft.o.ScreenShotHelper;
import net.minecraft.client.sigma.pandora.GuiStreamUnavailable;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.ChatComponentText;
import net.minecraft.client.sigma.GuiYesNo;
import net.minecraft.client.sigma.GuiYesNoCallback;
import net.minecraft.client.sigma.GuiControls;
import net.minecraft.vape.zeroday.BossStatus;
import net.minecraft.q.WorldProviderEnd;
import net.minecraft.q.WorldProviderHell;
import com.mojang.authlib.GameProfile;
import com.google.common.collect.Multimap;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.GLContext;
import java.nio.ByteOrder;
import com.google.common.util.concurrent.ListenableFuture;
import net.minecraft.d.NBTTagString;
import net.minecraft.d.NBTTagList;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.c.Item;
import net.minecraft.n.TileEntity;
import net.minecraft.vape.EntityList;
import net.minecraft.vape.pandora.EntityArmorStand;
import net.minecraft.vape.pandora.EntityBoat;
import net.minecraft.vape.pandora.EntityMinecart;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.vape.EntityLeashKnot;
import net.minecraft.a.Items;
import net.minecraft.vape.pandora.EntityPainting;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.ItemBlock;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.h;
import net.minecraft.client.flux.NetHandlerPlayClient;
import net.minecraft.o.MovementInputFromOptions;
import net.minecraft.m.StatFileWriter;
import java.net.SocketAddress;
import net.minecraft.q.vape.ISaveHandler;
import net.minecraft.e.zeroday.zerodayisaminecraftcheat.C00PacketLoginStart;
import net.minecraft.e.zerodayisaminecraftcheat.zerodayisaminecraftcheat.C00Handshake;
import net.minecraft.e.EnumConnectionState;
import net.minecraft.e.INetHandler;
import net.minecraft.client.flux.NetHandlerLoginClient;
import net.minecraft.client.b.I18n;
import net.minecraft.q.vape.WorldInfo;
import net.minecraft.q.WorldSettings;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.q.EnumDifficulty;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.Q;
import net.minecraft.client.sigma.GuiChat;
import net.minecraft.client.sigma.zeroday.GuiInventory;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C16PacketClientStatus;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.g;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.V;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.util.concurrent.Callable;
import net.minecraft.client.sigma.GuiSleepMP;
import zeroday.pandora.zerodayisaminecraftcheat.d.aT;
import zeroday.pandora.zerodayisaminecraftcheat.zues.zues;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.G;
import net.minecraft.c.ItemStack;
import zeroday.pandora.zerodayisaminecraftcheat.d.b;
import zeroday.pandora.zerodayisaminecraftcheat.d.bl;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.flux;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.client.sigma.GuiIngameMenu;
import net.minecraft.client.c.KeyBinding;
import java.text.DecimalFormat;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.zeroday.RenderChunk;
import net.minecraft.vape.vape.EntityPlayer;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.sigma.GuiGameOver;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.pandora;
import zeroday.zeroday.zerodayisaminecraftcheat.zeroday;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.d;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.zues.DynamicTexture;
import net.minecraft.client.sigma.ScaledResolution;
import java.util.Set;
import com.google.common.collect.Sets;
import java.awt.image.BufferedImage;
import java.util.Iterator;
import java.util.Collections;
import java.util.Collection;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import java.nio.ByteBuffer;
import org.lwjgl.opengl.PixelFormat;
import net.minecraft.client.e.NullStream;
import net.minecraft.client.e.TwitchStream;
import com.google.common.collect.Iterables;
import com.mojang.authlib.properties.Property;
import net.minecraft.client.b.zerodayisaminecraftcheat.LanguageMetadataSection;
import net.minecraft.client.b.zerodayisaminecraftcheat.LanguageMetadataSectionSerializer;
import net.minecraft.client.b.zerodayisaminecraftcheat.PackMetadataSection;
import net.minecraft.client.b.zerodayisaminecraftcheat.PackMetadataSectionSerializer;
import net.minecraft.client.b.zerodayisaminecraftcheat.AnimationMetadataSection;
import net.minecraft.client.b.zerodayisaminecraftcheat.AnimationMetadataSectionSerializer;
import net.minecraft.client.b.zerodayisaminecraftcheat.FontMetadataSection;
import net.minecraft.client.b.zerodayisaminecraftcheat.FontMetadataSectionSerializer;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSectionSerializer;
import net.minecraft.client.b.zerodayisaminecraftcheat.TextureMetadataSection;
import net.minecraft.client.b.zerodayisaminecraftcheat.TextureMetadataSectionSerializer;
import java.io.IOException;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.OpenGLException;
import org.lwjgl.opengl.Display;
import net.minecraft.client.a.pandora.RenderEngine;
import net.minecraft.client.zues.GuiConnecting;
import net.minecraft.client.sigma.GuiMainMenu;
import zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat;
import net.minecraft.q.World;
import net.minecraft.client.a.zues.ITickableTextureObject;
import net.minecraft.sigma.CrashWhitelist;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.m.IStatStringFormat;
import net.minecraft.m.AchievementList;
import net.minecraft.client.b.FoliageColorReloadListener;
import net.minecraft.client.b.GrassColorReloadListener;
import net.minecraft.q.sigma.zerodayisaminecraftcheat.AnvilSaveConverter;
import net.minecraft.client.b.IResourceManager;
import net.minecraft.client.b.IResourceManagerReloadListener;
import net.minecraft.client.b.SimpleReloadableResourceManager;
import net.minecraft.client.a.OpenGlHelper;
import org.lwjgl.Sys;
import net.minecraft.o.ReportedException;
import net.minecraft.o.MinecraftError;
import net.minecraft.client.sigma.GuiMemoryErrorScreen;
import net.minecraft.a.Bootstrap;
import javax.imageio.ImageIO;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import java.util.UUID;
import net.minecraft.client.b.ResourceIndex;
import com.google.common.collect.Queues;
import net.minecraft.k.MinecraftServer;
import net.minecraft.client.main.GameConfiguration;
import com.google.common.collect.Lists;
import net.minecraft.o.Util;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.client.b.zeroday.ModelManager;
import java.util.concurrent.FutureTask;
import java.util.Queue;
import net.minecraft.client.b.SkinManager;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import net.minecraft.client.zerodayisaminecraftcheat.MusicTicker;
import net.minecraft.client.zerodayisaminecraftcheat.SoundHandler;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.d.Framebuffer;
import net.minecraft.client.e.IStream;
import net.minecraft.client.b.LanguageManager;
import net.minecraft.client.b.ResourcePackRepository;
import net.minecraft.client.b.DefaultResourcePack;
import net.minecraft.client.b.IResourcePack;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import net.minecraft.client.b.IReloadableResourceManager;
import net.minecraft.h.Profiler;
import net.minecraft.e.NetworkManager;
import net.minecraft.o.FrameTimer;
import net.minecraft.q.vape.ISaveFormat;
import java.net.Proxy;
import net.minecraft.o.MouseHelper;
import net.minecraft.client.c.GameSettings;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.client.sigma.GuiIngame;
import net.minecraft.client.sigma.zerodayisaminecraftcheat.GuiAchievement;
import net.minecraft.k.zerodayisaminecraftcheat.IntegratedServer;
import net.minecraft.client.a.EntityRenderer;
import net.minecraft.client.sigma.GuiScreen;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.o.Session;
import net.minecraft.client.vape.EffectRenderer;
import net.minecraft.vape.Entity;
import net.minecraft.client.zeroday.EntityPlayerSP;
import net.minecraft.client.a.ItemRenderer;
import net.minecraft.client.a.pandora.RenderItem;
import net.minecraft.client.a.pandora.RenderManager;
import net.minecraft.client.a.RenderGlobal;
import net.minecraft.client.zues.WorldClient;
import net.minecraft.h.PlayerUsageSnooper;
import net.minecraft.o.Timer;
import net.minecraft.sigma.CrashReport;
import net.minecraft.client.zues.PlayerControllerMP;
import net.minecraft.client.a.zues.TextureManager;
import net.minecraft.client.zues.ServerData;
import com.mojang.authlib.properties.PropertyMap;
import java.io.File;
import org.lwjgl.opengl.DisplayMode;
import java.util.List;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;
import net.minecraft.o.IThreadListener;
import net.minecraft.h.IPlayerUsage;

public class Minecraft implements IPlayerUsage, IThreadListener
{
    private static final Logger N;
    private static final ResourceLocation O;
    public static final boolean zerodayisaminecraftcheat;
    public static byte[] zeroday;
    private static final List<DisplayMode> P;
    private final File Q;
    private final PropertyMap R;
    private final PropertyMap S;
    private ServerData T;
    public TextureManager sigma;
    public static boolean pandora;
    private static Minecraft U;
    public PlayerControllerMP zues;
    private boolean V;
    private boolean W;
    private boolean X;
    private CrashReport Y;
    public int flux;
    public int vape;
    private boolean Z;
    public Timer momgetthecamera;
    private PlayerUsageSnooper aa;
    public WorldClient a;
    public RenderGlobal b;
    public static int c;
    public static int d;
    private RenderManager ab;
    private RenderItem ac;
    private ItemRenderer ad;
    public EntityPlayerSP e;
    private Entity ae;
    public Entity f;
    public EffectRenderer g;
    public Session h;
    private boolean af;
    public FontRenderer i;
    public FontRenderer j;
    public GuiScreen k;
    public LoadingScreenRenderer l;
    public EntityRenderer m;
    private int ag;
    private int ah;
    private int ai;
    private IntegratedServer aj;
    public GuiAchievement n;
    public GuiIngame o;
    public boolean p;
    public MovingObjectPosition q;
    public GameSettings r;
    public MouseHelper s;
    public final File t;
    private final File ak;
    private final String al;
    private final Proxy am;
    private ISaveFormat an;
    private static int ao;
    public int u;
    private String ap;
    private int aq;
    public boolean v;
    long w;
    private int ar;
    public final FrameTimer x;
    long y;
    private final boolean as;
    private final boolean at;
    private NetworkManager au;
    private boolean av;
    public final Profiler z;
    private long aw;
    public IReloadableResourceManager A;
    private final IMetadataSerializer ax;
    private final List<IResourcePack> ay;
    private final DefaultResourcePack az;
    private ResourcePackRepository aA;
    public LanguageManager B;
    private IStream aB;
    private Framebuffer aC;
    private TextureMap aD;
    private SoundHandler aE;
    private MusicTicker aF;
    private ResourceLocation aG;
    private final MinecraftSessionService aH;
    private SkinManager aI;
    private final Queue<FutureTask<?>> aJ;
    private long aK;
    private final Thread aL;
    public ModelManager C;
    private BlockRendererDispatcher aM;
    volatile boolean D;
    public static boolean E;
    public String F;
    public boolean G;
    public boolean H;
    public boolean I;
    public boolean J;
    long K;
    int L;
    long M;
    private String aN;
    private static /* synthetic */ int[] aO;
    private static /* synthetic */ int[] aP;
    
    static {
        N = LogManager.getLogger();
        O = new ResourceLocation("textures/gui/title/mojang.png");
        zerodayisaminecraftcheat = (Util.zerodayisaminecraftcheat() == Util.zerodayisaminecraftcheat.pandora);
        Minecraft.zeroday = new byte[10485760];
        P = Lists.newArrayList((Object[])new DisplayMode[] { new DisplayMode(2560, 1600), new DisplayMode(2880, 1800) });
        Minecraft.E = false;
    }
    
    public Minecraft(final GameConfiguration gameConfig) {
        this.W = true;
        this.Z = false;
        this.momgetthecamera = new Timer(20.0f);
        this.aa = new PlayerUsageSnooper("client", this, MinecraftServer.ao());
        this.w = C();
        this.x = new FrameTimer();
        this.y = System.nanoTime();
        this.z = new Profiler();
        this.aw = -1L;
        this.ax = new IMetadataSerializer();
        this.ay = (List<IResourcePack>)Lists.newArrayList();
        this.aJ = (Queue<FutureTask<?>>)Queues.newArrayDeque();
        this.aK = 0L;
        this.aL = Thread.currentThread();
        this.D = true;
        this.F = "";
        this.G = false;
        this.H = false;
        this.I = false;
        this.J = true;
        this.K = C();
        this.M = -1L;
        this.aN = "root";
        Minecraft.U = this;
        this.t = gameConfig.sigma.zerodayisaminecraftcheat;
        this.ak = gameConfig.sigma.sigma;
        this.Q = gameConfig.sigma.zeroday;
        this.al = gameConfig.pandora.zeroday;
        this.R = gameConfig.zerodayisaminecraftcheat.zeroday;
        this.S = gameConfig.zerodayisaminecraftcheat.sigma;
        this.az = new DefaultResourcePack(new ResourceIndex(gameConfig.sigma.sigma, gameConfig.sigma.pandora).zerodayisaminecraftcheat());
        this.am = ((gameConfig.zerodayisaminecraftcheat.pandora == null) ? Proxy.NO_PROXY : gameConfig.zerodayisaminecraftcheat.pandora);
        this.aH = new YggdrasilAuthenticationService(gameConfig.zerodayisaminecraftcheat.pandora, UUID.randomUUID().toString()).createMinecraftSessionService();
        this.h = gameConfig.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        Minecraft.N.info("Setting user: " + this.h.sigma());
        Minecraft.N.info("(Session ID is " + this.h.zerodayisaminecraftcheat() + ")");
        this.at = gameConfig.pandora.zerodayisaminecraftcheat;
        this.flux = ((gameConfig.zeroday.zerodayisaminecraftcheat > 0) ? gameConfig.zeroday.zerodayisaminecraftcheat : 1);
        this.vape = ((gameConfig.zeroday.zeroday > 0) ? gameConfig.zeroday.zeroday : 1);
        this.ah = gameConfig.zeroday.zerodayisaminecraftcheat;
        this.ai = gameConfig.zeroday.zeroday;
        this.V = gameConfig.zeroday.sigma;
        this.as = an();
        this.aj = new IntegratedServer(this);
        if (gameConfig.zues.zerodayisaminecraftcheat != null) {
            this.ap = gameConfig.zues.zerodayisaminecraftcheat;
            this.aq = gameConfig.zues.zeroday;
        }
        ImageIO.setUseCache(false);
        Bootstrap.sigma();
    }
    
    public void zerodayisaminecraftcheat() {
        this.D = true;
        try {
            this.ah();
        }
        catch (Throwable throwable) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Initializing game");
            crashreport.zerodayisaminecraftcheat("Initialization");
            this.zeroday(this.sigma(crashreport));
            return;
        }
        try {
            do {
                if (this.X && this.Y != null) {
                    this.zeroday(this.Y);
                }
                else {
                    try {
                        this.aq();
                    }
                    catch (OutOfMemoryError var10) {
                        this.e();
                        this.zerodayisaminecraftcheat(new GuiMemoryErrorScreen());
                        System.gc();
                    }
                }
            } while (this.D);
        }
        catch (MinecraftError minecraftError) {}
        catch (ReportedException reportedexception) {
            this.sigma(reportedexception.zerodayisaminecraftcheat());
            this.e();
            Minecraft.N.fatal("Reported exception thrown!", (Throwable)reportedexception);
            this.zeroday(reportedexception.zerodayisaminecraftcheat());
        }
        catch (Throwable throwable2) {
            final CrashReport crashreport2 = this.sigma(new CrashReport("Unexpected error", throwable2));
            this.e();
            Minecraft.N.fatal("Unreported exception thrown!", throwable2);
            this.zeroday(crashreport2);
        }
        finally {
            this.momgetthecamera();
        }
    }
    
    private void ah() throws LWJGLException, IOException {
        this.r = new GameSettings(this, this.t);
        this.ay.add(this.az);
        this.ao();
        if (this.r.u > 0 && this.r.t > 0) {
            this.flux = this.r.t;
            this.vape = this.r.u;
        }
        Minecraft.N.info("LWJGL Version: " + Sys.getVersion());
        this.am();
        this.al();
        this.ak();
        OpenGlHelper.zerodayisaminecraftcheat();
        (this.aC = new Framebuffer(this.flux, this.vape, true)).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.0f);
        this.ai();
        this.aA = new ResourcePackRepository(this.Q, new File(this.t, "server-resource-packs"), this.az, this.ax, this.r);
        this.A = new SimpleReloadableResourceManager(this.ax);
        this.B = new LanguageManager(this.ax, this.r.aE);
        this.A.zerodayisaminecraftcheat(this.B);
        this.flux();
        this.sigma = new TextureManager(this.A);
        this.A.zerodayisaminecraftcheat(this.sigma);
        this.zerodayisaminecraftcheat(this.sigma);
        this.aj();
        this.aI = new SkinManager(this.sigma, new File(this.ak, "skins"), this.aH);
        this.an = new AnvilSaveConverter(new File(this.t, "saves"));
        this.aE = new SoundHandler(this.A, this.r);
        this.A.zerodayisaminecraftcheat(this.aE);
        this.aF = new MusicTicker(this);
        this.i = new FontRenderer(this.r, new ResourceLocation("textures/font/ascii.png"), this.sigma, false);
        if (this.r.aE != null) {
            this.i.zerodayisaminecraftcheat(this.zues());
            this.i.zeroday(this.B.zeroday());
        }
        this.j = new FontRenderer(this.r, new ResourceLocation("textures/font/ascii_sga.png"), this.sigma, false);
        this.A.zerodayisaminecraftcheat(this.i);
        this.A.zerodayisaminecraftcheat(this.j);
        this.A.zerodayisaminecraftcheat(new GrassColorReloadListener());
        this.A.zerodayisaminecraftcheat(new FoliageColorReloadListener());
        AchievementList.flux.zerodayisaminecraftcheat(new IStatStringFormat() {
            @Override
            public String zerodayisaminecraftcheat(final String p_74535_1_) {
                try {
                    return String.format(p_74535_1_, GameSettings.zerodayisaminecraftcheat(Minecraft.this.r.W.a()));
                }
                catch (Exception exception) {
                    return "Error: " + exception.getLocalizedMessage();
                }
            }
        });
        this.s = new MouseHelper();
        this.zerodayisaminecraftcheat("Pre startup");
        GlStateManager.m();
        GlStateManager.b(7425);
        GlStateManager.zerodayisaminecraftcheat(1.0);
        GlStateManager.b();
        GlStateManager.sigma(515);
        GlStateManager.pandora();
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        GlStateManager.zues(1029);
        GlStateManager.d(5889);
        GlStateManager.u();
        GlStateManager.d(5888);
        this.zerodayisaminecraftcheat("Startup");
        CrashWhitelist.zerodayisaminecraftcheat();
        (this.aD = new TextureMap("textures")).zerodayisaminecraftcheat(this.r.B);
        this.sigma.zerodayisaminecraftcheat(TextureMap.zeroday, this.aD);
        this.sigma.zerodayisaminecraftcheat(TextureMap.zeroday);
        this.aD.zerodayisaminecraftcheat(false, this.r.B > 0);
        this.C = new ModelManager(this.aD);
        this.A.zerodayisaminecraftcheat(this.C);
        this.ac = new RenderItem(this.sigma, this.C);
        this.ab = new RenderManager(this.sigma, this.ac);
        this.ad = new ItemRenderer(this);
        this.A.zerodayisaminecraftcheat(this.ac);
        this.m = new EntityRenderer(this, this.A);
        this.A.zerodayisaminecraftcheat(this.m);
        this.aM = new BlockRendererDispatcher(this.C.sigma(), this.r);
        this.A.zerodayisaminecraftcheat(this.aM);
        this.b = new RenderGlobal(this);
        this.A.zerodayisaminecraftcheat(this.b);
        this.n = new GuiAchievement(this);
        GlStateManager.zeroday(0, 0, this.flux, this.vape);
        this.g = new EffectRenderer(this.a, this.sigma);
        this.zerodayisaminecraftcheat("Post startup");
        this.o = new GuiIngame(this);
        zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
        if (this.ap != null) {
            this.zerodayisaminecraftcheat(new GuiConnecting(new GuiMainMenu(), this, this.ap, this.aq));
        }
        else {
            this.zerodayisaminecraftcheat(new GuiMainMenu());
        }
        this.sigma.sigma(this.aG);
        this.aG = null;
        this.l = new LoadingScreenRenderer(this);
        RenderEngine.zerodayisaminecraftcheat();
        RenderEngine.zeroday();
        if (this.r.k && !this.V) {
            this.k();
        }
        try {
            Display.setVSyncEnabled(this.r.l);
        }
        catch (OpenGLException var2) {
            this.r.l = false;
            this.r.zeroday();
        }
        this.b.zerodayisaminecraftcheat();
    }
    
    private void ai() {
        this.ax.zerodayisaminecraftcheat(new TextureMetadataSectionSerializer(), TextureMetadataSection.class);
        this.ax.zerodayisaminecraftcheat(new FontMetadataSectionSerializer(), FontMetadataSection.class);
        this.ax.zerodayisaminecraftcheat(new AnimationMetadataSectionSerializer(), AnimationMetadataSection.class);
        this.ax.zerodayisaminecraftcheat(new PackMetadataSectionSerializer(), PackMetadataSection.class);
        this.ax.zerodayisaminecraftcheat(new LanguageMetadataSectionSerializer(), LanguageMetadataSection.class);
    }
    
    private void aj() {
        try {
            this.aB = new TwitchStream(this, (Property)Iterables.getFirst((Iterable)this.R.get((Object)"twitch_access_token"), (Object)null));
        }
        catch (Throwable throwable) {
            this.aB = new NullStream(throwable);
            Minecraft.N.error("Couldn't initialize twitch stream");
        }
    }
    
    private void ak() throws LWJGLException {
        Display.setResizable(true);
        Display.setTitle("Loading ZeroDay | by Nefarious Intent");
        try {
            Display.create(new PixelFormat().withDepthBits(24));
        }
        catch (LWJGLException lwjglexception) {
            Minecraft.N.error("Couldn't set pixel format", (Throwable)lwjglexception);
            try {
                Thread.sleep(1000L);
            }
            catch (InterruptedException ex) {}
            if (this.V) {
                this.ap();
            }
            Display.create();
        }
    }
    
    private void al() throws LWJGLException {
        if (this.V) {
            Display.setFullscreen(true);
            final DisplayMode displaymode = Display.getDisplayMode();
            this.flux = Math.max(1, displaymode.getWidth());
            this.vape = Math.max(1, displaymode.getHeight());
        }
        else {
            Display.setDisplayMode(new DisplayMode(this.flux, this.vape));
        }
    }
    
    private void am() {
        final Util.zerodayisaminecraftcheat util$enumos = Util.zerodayisaminecraftcheat();
        if (util$enumos != Util.zerodayisaminecraftcheat.pandora) {
            InputStream inputstream = null;
            InputStream inputstream2 = null;
            try {
                inputstream = this.az.sigma(new ResourceLocation("icons/icon_16x16.png"));
                inputstream2 = this.az.sigma(new ResourceLocation("icons/icon_32x32.png"));
                if (inputstream != null && inputstream2 != null) {
                    Display.setIcon(new ByteBuffer[] { this.zerodayisaminecraftcheat(inputstream), this.zerodayisaminecraftcheat(inputstream2) });
                }
            }
            catch (IOException ioexception) {
                Minecraft.N.error("Couldn't set icon", (Throwable)ioexception);
                return;
            }
            finally {
                IOUtils.closeQuietly(inputstream);
                IOUtils.closeQuietly(inputstream2);
            }
            IOUtils.closeQuietly(inputstream);
            IOUtils.closeQuietly(inputstream2);
        }
    }
    
    private static boolean an() {
        final String[] astring = { "sun.arch.data.model", "com.ibm.vm.bitmode", "os.arch" };
        String[] array;
        for (int length = (array = astring).length, i = 0; i < length; ++i) {
            final String s = array[i];
            final String s2 = System.getProperty(s);
            if (s2 != null && s2.contains("64")) {
                return true;
            }
        }
        return false;
    }
    
    public static void zeroday() {
        System.out.print(s().k.w);
    }
    
    public Framebuffer sigma() {
        return this.aC;
    }
    
    public String pandora() {
        return this.al;
    }
    
    private void ao() {
        final Thread thread = new Thread("Timer hack thread") {
            @Override
            public void run() {
                while (Minecraft.this.D) {
                    try {
                        Thread.sleep(2147483647L);
                    }
                    catch (InterruptedException ex) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }
    
    public void zerodayisaminecraftcheat(final CrashReport crash) {
        this.X = true;
        this.Y = crash;
    }
    
    public void zeroday(final CrashReport crashReportIn) {
        final File file1 = new File(s().t, "crash-reports");
        final File file2 = new File(file1, "crash-" + new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date()) + "-client.txt");
        Bootstrap.zerodayisaminecraftcheat(crashReportIn.pandora());
        if (crashReportIn.zues() != null) {
            Bootstrap.zerodayisaminecraftcheat("#@!@# Game crashed! Crash report saved to: #@!@# " + crashReportIn.zues());
            System.exit(-1);
        }
        else if (crashReportIn.zerodayisaminecraftcheat(file2)) {
            Bootstrap.zerodayisaminecraftcheat("#@!@# Game crashed! Crash report saved to: #@!@# " + file2.getAbsolutePath());
            System.exit(-1);
        }
        else {
            Bootstrap.zerodayisaminecraftcheat("#@?@# Game crashed! Crash report could not be saved. #@?@#");
            System.exit(-2);
        }
    }
    
    public boolean zues() {
        return this.B.zerodayisaminecraftcheat() || this.r.aF;
    }
    
    public void flux() {
        final List<IResourcePack> list = (List<IResourcePack>)Lists.newArrayList((Iterable)this.ay);
        for (final ResourcePackRepository.zerodayisaminecraftcheat resourcepackrepository$entry : this.aA.sigma()) {
            list.add(resourcepackrepository$entry.zues());
        }
        if (this.aA.zues() != null) {
            list.add(this.aA.zues());
        }
        try {
            this.A.zerodayisaminecraftcheat(list);
        }
        catch (RuntimeException runtimeexception) {
            Minecraft.N.info("Caught error stitching, removing all assigned resourcepacks", (Throwable)runtimeexception);
            list.clear();
            list.addAll(this.ay);
            this.aA.zerodayisaminecraftcheat(Collections.emptyList());
            this.A.zerodayisaminecraftcheat(list);
            this.r.c.clear();
            this.r.d.clear();
            this.r.zeroday();
        }
        this.B.zerodayisaminecraftcheat(list);
        if (this.b != null) {
            this.b.pandora();
        }
    }
    
    private ByteBuffer zerodayisaminecraftcheat(final InputStream imageStream) throws IOException {
        final BufferedImage bufferedimage = ImageIO.read(imageStream);
        final int[] aint = bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), null, 0, bufferedimage.getWidth());
        final ByteBuffer bytebuffer = ByteBuffer.allocate(4 * aint.length);
        int[] array;
        for (int length = (array = aint).length, j = 0; j < length; ++j) {
            final int i = array[j];
            bytebuffer.putInt(i << 8 | (i >> 24 & 0xFF));
        }
        bytebuffer.flip();
        return bytebuffer;
    }
    
    private void ap() throws LWJGLException {
        final Set<DisplayMode> set = (Set<DisplayMode>)Sets.newHashSet();
        Collections.addAll(set, Display.getAvailableDisplayModes());
        DisplayMode displaymode = Display.getDesktopDisplayMode();
        if (!set.contains(displaymode) && Util.zerodayisaminecraftcheat() == Util.zerodayisaminecraftcheat.pandora) {
            for (final DisplayMode displaymode2 : Minecraft.P) {
                boolean flag = true;
                for (final DisplayMode displaymode3 : set) {
                    if (displaymode3.getBitsPerPixel() == 32 && displaymode3.getWidth() == displaymode2.getWidth() && displaymode3.getHeight() == displaymode2.getHeight()) {
                        flag = false;
                        break;
                    }
                }
                if (!flag) {
                    for (final DisplayMode displaymode4 : set) {
                        if (displaymode4.getBitsPerPixel() == 32 && displaymode4.getWidth() == displaymode2.getWidth() / 2 && displaymode4.getHeight() == displaymode2.getHeight() / 2) {
                            displaymode = displaymode4;
                            break;
                        }
                    }
                }
            }
        }
        Display.setDisplayMode(displaymode);
        this.flux = displaymode.getWidth();
        this.vape = displaymode.getHeight();
    }
    
    private void zerodayisaminecraftcheat(final TextureManager textureManagerInstance) throws LWJGLException {
        final ScaledResolution scaledresolution = new ScaledResolution(this);
        final int i = scaledresolution.zues();
        final Framebuffer framebuffer = new Framebuffer(scaledresolution.zerodayisaminecraftcheat() * i, scaledresolution.zeroday() * i, true);
        framebuffer.zerodayisaminecraftcheat(false);
        GlStateManager.d(5889);
        GlStateManager.u();
        GlStateManager.zerodayisaminecraftcheat(0.0, scaledresolution.zerodayisaminecraftcheat(), scaledresolution.zeroday(), 0.0, 1000.0, 3000.0);
        GlStateManager.d(5888);
        GlStateManager.u();
        GlStateManager.zeroday(0.0f, 0.0f, -2000.0f);
        GlStateManager.flux();
        GlStateManager.f();
        GlStateManager.a();
        GlStateManager.m();
        InputStream inputstream = null;
        Label_0204: {
            try {
                inputstream = this.az.zerodayisaminecraftcheat(Minecraft.O);
                textureManagerInstance.zerodayisaminecraftcheat(this.aG = textureManagerInstance.zerodayisaminecraftcheat("logo", new DynamicTexture(ImageIO.read(inputstream))));
            }
            catch (IOException ioexception1) {
                Minecraft.N.error("Unable to load logo: " + Minecraft.O, (Throwable)ioexception1);
                break Label_0204;
            }
            finally {
                IOUtils.closeQuietly(inputstream);
            }
            IOUtils.closeQuietly(inputstream);
        }
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
        worldrenderer.zeroday(0.0, this.vape, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(255, 255, 255, 255).zues();
        worldrenderer.zeroday(this.flux, this.vape, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(255, 255, 255, 255).zues();
        worldrenderer.zeroday(this.flux, 0.0, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(255, 255, 255, 255).zues();
        worldrenderer.zeroday(0.0, 0.0, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(255, 255, 255, 255).zues();
        tessellator.zeroday();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        final int j = 256;
        final int k = 256;
        this.zerodayisaminecraftcheat((scaledresolution.zerodayisaminecraftcheat() - j) / 2, (scaledresolution.zeroday() - k) / 2, 0, 0, j, k, 255, 255, 255, 255);
        GlStateManager.flux();
        GlStateManager.f();
        framebuffer.zues();
        framebuffer.sigma(scaledresolution.zerodayisaminecraftcheat() * i, scaledresolution.zeroday() * i);
        GlStateManager.pandora();
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        this.a();
    }
    
    public void zerodayisaminecraftcheat(final int p_181536_1_, final int p_181536_2_, final int p_181536_3_, final int p_181536_4_, final int p_181536_5_, final int p_181536_6_, final int p_181536_7_, final int p_181536_8_, final int p_181536_9_, final int p_181536_10_) {
        final float f = 0.00390625f;
        final float f2 = 0.00390625f;
        final WorldRenderer worldrenderer = Tessellator.zerodayisaminecraftcheat().sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
        worldrenderer.zeroday(p_181536_1_, p_181536_2_ + p_181536_6_, 0.0).zerodayisaminecraftcheat(p_181536_3_ * f, (p_181536_4_ + p_181536_6_) * f2).zeroday(p_181536_7_, p_181536_8_, p_181536_9_, p_181536_10_).zues();
        worldrenderer.zeroday(p_181536_1_ + p_181536_5_, p_181536_2_ + p_181536_6_, 0.0).zerodayisaminecraftcheat((p_181536_3_ + p_181536_5_) * f, (p_181536_4_ + p_181536_6_) * f2).zeroday(p_181536_7_, p_181536_8_, p_181536_9_, p_181536_10_).zues();
        worldrenderer.zeroday(p_181536_1_ + p_181536_5_, p_181536_2_, 0.0).zerodayisaminecraftcheat((p_181536_3_ + p_181536_5_) * f, p_181536_4_ * f2).zeroday(p_181536_7_, p_181536_8_, p_181536_9_, p_181536_10_).zues();
        worldrenderer.zeroday(p_181536_1_, p_181536_2_, 0.0).zerodayisaminecraftcheat(p_181536_3_ * f, p_181536_4_ * f2).zeroday(p_181536_7_, p_181536_8_, p_181536_9_, p_181536_10_).zues();
        Tessellator.zerodayisaminecraftcheat().zeroday();
    }
    
    public ISaveFormat vape() {
        return this.an;
    }
    
    public void zerodayisaminecraftcheat(GuiScreen guiScreenIn) {
        final d event = new d(guiScreenIn);
        zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(event);
        if (this.k != null) {
            this.k.u_();
        }
        if (guiScreenIn == null && this.a == null) {
            guiScreenIn = new GuiMainMenu();
        }
        else if (guiScreenIn == null && this.e.by() <= 0.0f) {
            guiScreenIn = new GuiGameOver();
        }
        if (guiScreenIn instanceof GuiMainMenu) {
            this.r.at = false;
            this.o.pandora().zerodayisaminecraftcheat();
        }
        if ((this.k = guiScreenIn) != null) {
            this.h();
            final ScaledResolution scaledresolution = new ScaledResolution(this);
            final int i = scaledresolution.zerodayisaminecraftcheat();
            final int j = scaledresolution.zeroday();
            guiScreenIn.zerodayisaminecraftcheat(this, i, j);
            this.p = false;
        }
        else {
            this.aE.zues();
            this.g();
        }
    }
    
    private void zerodayisaminecraftcheat(final String message) {
        if (this.W) {
            final int i = GL11.glGetError();
            if (i != 0) {
                final String s = GLU.gluErrorString(i);
                Minecraft.N.error("########## GL ERROR ##########");
                Minecraft.N.error("@ " + message);
                Minecraft.N.error(String.valueOf(i) + ": " + s);
            }
        }
    }
    
    public void momgetthecamera() {
        try {
            this.aB.flux();
            Minecraft.N.info("Stopping!");
            try {
                this.zerodayisaminecraftcheat((WorldClient)null);
            }
            catch (Throwable t) {}
            this.aE.pandora();
        }
        finally {
            Display.destroy();
            if (!this.X) {
                System.exit(0);
            }
        }
        Display.destroy();
        if (!this.X) {
            System.exit(0);
        }
        System.gc();
    }
    
    private void aq() throws IOException {
        final long i = System.nanoTime();
        this.z.zerodayisaminecraftcheat("root");
        if (Display.isCreated() && Display.isCloseRequested()) {
            this.f();
        }
        if (this.af && this.a != null) {
            final float f = this.momgetthecamera.sigma;
            this.momgetthecamera.zerodayisaminecraftcheat();
            this.momgetthecamera.sigma = f;
        }
        else {
            this.momgetthecamera.zerodayisaminecraftcheat();
        }
        this.z.zerodayisaminecraftcheat("scheduledExecutables");
        synchronized (this.aJ) {
            while (!this.aJ.isEmpty()) {
                Util.zerodayisaminecraftcheat(this.aJ.poll(), Minecraft.N);
            }
        }
        // monitorexit(this.aJ)
        this.z.zeroday();
        final long l = System.nanoTime();
        this.z.zerodayisaminecraftcheat("tick");
        for (int j = 0; j < this.momgetthecamera.zeroday; ++j) {
            this.m();
        }
        this.z.sigma("preRenderErrors");
        final long i2 = System.nanoTime() - l;
        this.zerodayisaminecraftcheat("Pre render");
        this.z.sigma("sound");
        this.aE.zerodayisaminecraftcheat(this.e, this.momgetthecamera.sigma);
        this.z.zeroday();
        this.z.zerodayisaminecraftcheat("render");
        GlStateManager.v();
        GlStateManager.c(16640);
        this.aC.zerodayisaminecraftcheat(true);
        this.z.zerodayisaminecraftcheat("display");
        GlStateManager.m();
        if (this.e != null && this.e.g()) {
            this.r.as = 0;
        }
        this.z.zeroday();
        if (!this.p) {
            this.z.sigma("gameRenderer");
            this.m.zerodayisaminecraftcheat(this.momgetthecamera.sigma, i);
            this.z.zeroday();
        }
        this.z.zeroday();
        if (this.r.at && this.r.au && !this.r.ar) {
            if (!this.z.zerodayisaminecraftcheat) {
                this.z.zerodayisaminecraftcheat();
            }
            this.z.zerodayisaminecraftcheat = true;
            this.zerodayisaminecraftcheat(i2);
        }
        else {
            this.z.zerodayisaminecraftcheat = false;
            this.M = System.nanoTime();
        }
        this.n.zerodayisaminecraftcheat();
        this.aC.zues();
        GlStateManager.w();
        GlStateManager.v();
        this.aC.sigma(this.flux, this.vape);
        GlStateManager.w();
        GlStateManager.v();
        this.m.zeroday(this.momgetthecamera.sigma);
        GlStateManager.w();
        this.z.zerodayisaminecraftcheat("root");
        this.a();
        Thread.yield();
        this.z.zerodayisaminecraftcheat("stream");
        this.z.zerodayisaminecraftcheat("update");
        this.aB.vape();
        this.z.sigma("submit");
        this.aB.momgetthecamera();
        this.z.zeroday();
        this.z.zeroday();
        this.zerodayisaminecraftcheat("Post render");
        ++this.L;
        this.af = (this.y() && this.k != null && this.k.zues() && !this.aj.aA());
        final long k = System.nanoTime();
        this.x.zerodayisaminecraftcheat(k - this.y);
        this.y = k;
        while (C() >= this.K + 1000L) {
            Minecraft.ao = this.L;
            this.F = String.format("%d fps (%d chunk update%s) T: %s%s%s%s%s", Minecraft.ao, RenderChunk.zerodayisaminecraftcheat, (RenderChunk.zerodayisaminecraftcheat != 1) ? "s" : "", (this.r.vape == GameSettings.zeroday.a.zues()) ? "inf" : Integer.valueOf(this.r.vape), this.r.l ? " vsync" : "", this.r.a ? "" : " fast", (this.r.momgetthecamera == 0) ? "" : ((this.r.momgetthecamera == 1) ? " fast-clouds" : " fancy-clouds"), OpenGlHelper.flux() ? " vbo" : "");
            RenderChunk.zerodayisaminecraftcheat = 0;
            this.K += 1000L;
            this.L = 0;
            this.aa.zeroday();
            if (!this.aa.pandora()) {
                this.aa.zerodayisaminecraftcheat();
            }
        }
        if (this.d()) {
            this.z.zerodayisaminecraftcheat("fpslimit_wait");
            Display.sync(this.c());
            this.z.zeroday();
        }
        this.z.zeroday();
    }
    
    public void a() {
        this.z.zerodayisaminecraftcheat("display_update");
        Display.update();
        this.z.zeroday();
        this.b();
    }
    
    protected void b() {
        if (!this.V && Display.wasResized()) {
            final int i = this.flux;
            final int j = this.vape;
            this.flux = Display.getWidth();
            this.vape = Display.getHeight();
            if (this.flux != i || this.vape != j) {
                if (this.flux <= 0) {
                    this.flux = 1;
                }
                if (this.vape <= 0) {
                    this.vape = 1;
                }
                this.zerodayisaminecraftcheat(this.flux, this.vape);
            }
        }
    }
    
    public int c() {
        return (this.a == null && this.k != null) ? 30 : this.r.vape;
    }
    
    public boolean d() {
        return this.c() < GameSettings.zeroday.a.zues();
    }
    
    public void e() {
        try {
            Minecraft.zeroday = new byte[0];
            this.b.a();
        }
        catch (Throwable t) {}
        try {
            System.gc();
            this.zerodayisaminecraftcheat((WorldClient)null);
        }
        catch (Throwable t2) {}
        System.gc();
    }
    
    private void zeroday(int keyCount) {
        final List<Profiler.zerodayisaminecraftcheat> list = this.z.zeroday(this.aN);
        if (list != null && !list.isEmpty()) {
            final Profiler.zerodayisaminecraftcheat profiler$result = list.remove(0);
            if (keyCount == 0) {
                if (profiler$result.sigma.length() > 0) {
                    final int i = this.aN.lastIndexOf(".");
                    if (i >= 0) {
                        this.aN = this.aN.substring(0, i);
                    }
                }
            }
            else if (--keyCount < list.size() && !list.get(keyCount).sigma.equals("unspecified")) {
                if (this.aN.length() > 0) {
                    this.aN = String.valueOf(this.aN) + ".";
                }
                this.aN = String.valueOf(this.aN) + list.get(keyCount).sigma;
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final long elapsedTicksTime) {
        if (this.z.zerodayisaminecraftcheat) {
            final List<Profiler.zerodayisaminecraftcheat> list = this.z.zeroday(this.aN);
            final Profiler.zerodayisaminecraftcheat profiler$result = list.remove(0);
            GlStateManager.c(256);
            GlStateManager.d(5889);
            GlStateManager.vape();
            GlStateManager.u();
            GlStateManager.zerodayisaminecraftcheat(0.0, this.flux, this.vape, 0.0, 1000.0, 3000.0);
            GlStateManager.d(5888);
            GlStateManager.u();
            GlStateManager.zeroday(0.0f, 0.0f, -2000.0f);
            GL11.glLineWidth(1.0f);
            GlStateManager.n();
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            final int i = 160;
            final int j = this.flux - i - 10;
            final int k = this.vape - i * 2;
            GlStateManager.d();
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
            worldrenderer.zeroday(j - i * 1.1f, k - i * 0.6f - 16.0f, 0.0).zeroday(200, 0, 0, 0).zues();
            worldrenderer.zeroday(j - i * 1.1f, k + i * 2, 0.0).zeroday(200, 0, 0, 0).zues();
            worldrenderer.zeroday(j + i * 1.1f, k + i * 2, 0.0).zeroday(200, 0, 0, 0).zues();
            worldrenderer.zeroday(j + i * 1.1f, k - i * 0.6f - 16.0f, 0.0).zeroday(200, 0, 0, 0).zues();
            tessellator.zeroday();
            GlStateManager.c();
            double d0 = 0.0;
            for (int l = 0; l < list.size(); ++l) {
                final Profiler.zerodayisaminecraftcheat profiler$result2 = list.get(l);
                final int i2 = MathHelper.sigma(profiler$result2.zerodayisaminecraftcheat / 4.0) + 1;
                worldrenderer.zerodayisaminecraftcheat(6, DefaultVertexFormats.flux);
                final int j2 = profiler$result2.zerodayisaminecraftcheat();
                final int k2 = j2 >> 16 & 0xFF;
                final int l2 = j2 >> 8 & 0xFF;
                final int i3 = j2 & 0xFF;
                worldrenderer.zeroday(j, k, 0.0).zeroday(k2, l2, i3, 255).zues();
                for (int j3 = i2; j3 >= 0; --j3) {
                    final float f = (float)((d0 + profiler$result2.zerodayisaminecraftcheat * j3 / i2) * 3.141592653589793 * 2.0 / 100.0);
                    final float f2 = MathHelper.zerodayisaminecraftcheat(f) * i;
                    final float f3 = MathHelper.zeroday(f) * i * 0.5f;
                    worldrenderer.zeroday(j + f2, k - f3, 0.0).zeroday(k2, l2, i3, 255).zues();
                }
                tessellator.zeroday();
                worldrenderer.zerodayisaminecraftcheat(5, DefaultVertexFormats.flux);
                for (int i4 = i2; i4 >= 0; --i4) {
                    final float f4 = (float)((d0 + profiler$result2.zerodayisaminecraftcheat * i4 / i2) * 3.141592653589793 * 2.0 / 100.0);
                    final float f5 = MathHelper.zerodayisaminecraftcheat(f4) * i;
                    final float f6 = MathHelper.zeroday(f4) * i * 0.5f;
                    worldrenderer.zeroday(j + f5, k - f6, 0.0).zeroday(k2 >> 1, l2 >> 1, i3 >> 1, 255).zues();
                    worldrenderer.zeroday(j + f5, k - f6 + 10.0f, 0.0).zeroday(k2 >> 1, l2 >> 1, i3 >> 1, 255).zues();
                }
                tessellator.zeroday();
                d0 += profiler$result2.zerodayisaminecraftcheat;
            }
            final DecimalFormat decimalformat = new DecimalFormat("##0.00");
            GlStateManager.m();
            String s = "";
            if (!profiler$result.sigma.equals("unspecified")) {
                s = String.valueOf(s) + "[0] ";
            }
            if (profiler$result.sigma.length() == 0) {
                s = String.valueOf(s) + "ROOT ";
            }
            else {
                s = String.valueOf(s) + profiler$result.sigma + " ";
            }
            final int k3 = 16777215;
            this.i.zerodayisaminecraftcheat(s, (float)(j - i), (float)(k - i / 2 - 16), k3);
            this.i.zerodayisaminecraftcheat(s = String.valueOf(decimalformat.format(profiler$result.zeroday)) + "%", (float)(j + i - this.i.zerodayisaminecraftcheat(s)), (float)(k - i / 2 - 16), k3);
            for (int l3 = 0; l3 < list.size(); ++l3) {
                final Profiler.zerodayisaminecraftcheat profiler$result3 = list.get(l3);
                String s2 = "";
                if (profiler$result3.sigma.equals("unspecified")) {
                    s2 = String.valueOf(s2) + "[?] ";
                }
                else {
                    s2 = String.valueOf(s2) + "[" + (l3 + 1) + "] ";
                }
                s2 = String.valueOf(s2) + profiler$result3.sigma;
                this.i.zerodayisaminecraftcheat(s2, (float)(j - i), (float)(k + i / 2 + l3 * 8 + 20), profiler$result3.zerodayisaminecraftcheat());
                this.i.zerodayisaminecraftcheat(s2 = String.valueOf(decimalformat.format(profiler$result3.zerodayisaminecraftcheat)) + "%", (float)(j + i - 50 - this.i.zerodayisaminecraftcheat(s2)), (float)(k + i / 2 + l3 * 8 + 20), profiler$result3.zerodayisaminecraftcheat());
                this.i.zerodayisaminecraftcheat(s2 = String.valueOf(decimalformat.format(profiler$result3.zeroday)) + "%", (float)(j + i - this.i.zerodayisaminecraftcheat(s2)), (float)(k + i / 2 + l3 * 8 + 20), profiler$result3.zerodayisaminecraftcheat());
            }
        }
    }
    
    public void f() {
        this.D = false;
    }
    
    public void g() {
        if (Display.isActive() && !this.v) {
            this.v = true;
            this.s.zerodayisaminecraftcheat();
            this.zerodayisaminecraftcheat((GuiScreen)null);
            this.ag = 10000;
        }
    }
    
    public void h() {
        if (this.v) {
            KeyBinding.zerodayisaminecraftcheat();
            this.v = false;
            this.s.zeroday();
        }
    }
    
    public void i() {
        if (this.k == null) {
            this.zerodayisaminecraftcheat(new GuiIngameMenu());
            if (this.y() && !this.aj.aA()) {
                this.aE.zeroday();
            }
        }
    }
    
    private void zeroday(final boolean leftClick) {
        if (!leftClick) {
            this.ag = 0;
        }
        if (this.ag <= 0 && !this.e.aP()) {
            if (leftClick && this.q != null && this.q.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
                final BlockPos blockpos = this.q.zerodayisaminecraftcheat();
                if (this.a.zeroday(blockpos).sigma().flux() != Material.zerodayisaminecraftcheat && this.zues.sigma(blockpos, this.q.zeroday)) {
                    this.g.zerodayisaminecraftcheat(blockpos, this.q.zeroday);
                    this.e.e_();
                }
            }
            else {
                this.zues.sigma();
            }
        }
    }
    
    public void j() {
        final flux event = new flux();
        zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(event);
        if (this.ag <= 0) {
            this.e.e_();
            if (this.q == null) {
                Minecraft.N.error("Null returned as 'hitResult', this shouldn't happen!");
                if (!bl.e && !zeroday.pandora.zerodayisaminecraftcheat.d.b.c && this.zues.momgetthecamera()) {
                    this.ag = 10;
                }
            }
            else {
                switch (af()[this.q.zerodayisaminecraftcheat.ordinal()]) {
                    case 3: {
                        this.zues.zerodayisaminecraftcheat(this.e, this.q.pandora);
                        return;
                    }
                    case 2: {
                        final BlockPos blockpos = this.q.zerodayisaminecraftcheat();
                        if (this.a.zeroday(blockpos).sigma().flux() != Material.zerodayisaminecraftcheat) {
                            this.zues.zeroday(blockpos, this.q.zeroday);
                            return;
                        }
                        break;
                    }
                }
                if (!bl.e && !zeroday.pandora.zerodayisaminecraftcheat.d.b.c && this.zues.momgetthecamera()) {
                    this.ag = 10;
                }
            }
        }
    }
    
    private void ar() {
        if (!this.zues.f()) {
            this.u = 4;
            boolean flag = true;
            final ItemStack itemstack = this.e.d.pandora();
            if (this.q == null) {
                Minecraft.N.warn("Null returned as 'hitResult', this shouldn't happen!");
            }
            else {
                switch (af()[this.q.zerodayisaminecraftcheat.ordinal()]) {
                    case 3: {
                        if (this.zues.zerodayisaminecraftcheat(this.e, this.q.pandora, this.q)) {
                            flag = false;
                            break;
                        }
                        if (this.zues.zeroday(this.e, this.q.pandora)) {
                            flag = false;
                            break;
                        }
                        break;
                    }
                    case 2: {
                        final BlockPos blockpos = this.q.zerodayisaminecraftcheat();
                        if (this.a.zeroday(blockpos).sigma().flux() == Material.zerodayisaminecraftcheat) {
                            break;
                        }
                        final int i = (itemstack != null) ? itemstack.zeroday : 0;
                        if (this.zues.zerodayisaminecraftcheat(this.e, this.a, itemstack, blockpos, this.q.zeroday, this.q.sigma)) {
                            flag = false;
                            this.e.e_();
                        }
                        if (itemstack == null) {
                            return;
                        }
                        if (itemstack.zeroday == 0) {
                            this.e.d.zerodayisaminecraftcheat[this.e.d.sigma] = null;
                            break;
                        }
                        if (itemstack.zeroday != i || this.zues.a()) {
                            this.m.sigma.zeroday();
                            break;
                        }
                        break;
                    }
                }
            }
            if (flag) {
                final ItemStack itemstack2 = this.e.d.pandora();
                if (itemstack2 != null && this.zues.zerodayisaminecraftcheat(this.e, this.a, itemstack2)) {
                    this.m.sigma.sigma();
                }
            }
        }
    }
    
    public void k() {
        try {
            this.V = !this.V;
            this.r.k = this.V;
            if (this.V) {
                this.ap();
                this.flux = Display.getDisplayMode().getWidth();
                this.vape = Display.getDisplayMode().getHeight();
                if (this.flux <= 0) {
                    this.flux = 1;
                }
                if (this.vape <= 0) {
                    this.vape = 1;
                }
            }
            else {
                Display.setDisplayMode(new DisplayMode(this.ah, this.ai));
                this.flux = this.ah;
                this.vape = this.ai;
                if (this.flux <= 0) {
                    this.flux = 1;
                }
                if (this.vape <= 0) {
                    this.vape = 1;
                }
            }
            if (this.k != null) {
                this.zerodayisaminecraftcheat(this.flux, this.vape);
            }
            else {
                this.as();
            }
            Display.setFullscreen(this.V);
            Display.setVSyncEnabled(this.r.l);
            this.a();
        }
        catch (Exception exception) {
            Minecraft.N.error("Couldn't toggle fullscreen", (Throwable)exception);
        }
    }
    
    private void zerodayisaminecraftcheat(final int width, final int height) {
        this.flux = Math.max(1, width);
        this.vape = Math.max(1, height);
        if (this.k != null) {
            final ScaledResolution scaledresolution = new ScaledResolution(this);
            this.k.zeroday(this, scaledresolution.zerodayisaminecraftcheat(), scaledresolution.zeroday());
        }
        this.l = new LoadingScreenRenderer(this);
        this.as();
    }
    
    private void as() {
        this.aC.zerodayisaminecraftcheat(this.flux, this.vape);
        if (this.m != null) {
            this.m.zerodayisaminecraftcheat(this.flux, this.vape);
        }
    }
    
    public MusicTicker l() {
        return this.aF;
    }
    
    public void m() throws IOException {
        final G ev = new G();
        zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(ev);
        final zues e = new zues();
        if (aT.f) {
            this.o.pandora().zerodayisaminecraftcheat();
        }
        if (this.e != null) {
            zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(e);
        }
        if (this.u > 0) {
            --this.u;
        }
        this.z.zerodayisaminecraftcheat("gui");
        if (!this.af) {
            this.o.sigma();
        }
        this.z.zeroday();
        this.m.zerodayisaminecraftcheat(1.0f);
        this.z.zerodayisaminecraftcheat("gameMode");
        if (!this.af && this.a != null) {
            this.zues.zues();
        }
        this.z.sigma("textures");
        if (!this.af) {
            this.sigma.zeroday();
        }
        if (this.k == null && this.e != null) {
            if (this.e.by() <= 0.0f) {
                this.zerodayisaminecraftcheat((GuiScreen)null);
            }
            else if (this.e.bS() && this.a != null) {
                this.zerodayisaminecraftcheat(new GuiSleepMP());
            }
        }
        else if (this.k != null && this.k instanceof GuiSleepMP && !this.e.bS()) {
            this.zerodayisaminecraftcheat((GuiScreen)null);
        }
        if (this.k != null) {
            this.ag = 10000;
        }
        if (this.k != null) {
            try {
                this.k.g();
            }
            catch (Throwable throwable11) {
                final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable11, "Updating screen events");
                final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Affected screen");
                crashreportcategory.zerodayisaminecraftcheat("Screen name", new Callable<String>() {
                    public String zerodayisaminecraftcheat() throws Exception {
                        return Minecraft.this.k.getClass().getCanonicalName();
                    }
                });
                throw new ReportedException(crashreport);
            }
            if (this.k != null) {
                try {
                    this.k.sigma();
                }
                catch (Throwable throwable12) {
                    final CrashReport crashreport2 = CrashReport.zerodayisaminecraftcheat(throwable12, "Ticking screen");
                    final CrashReportCategory crashreportcategory2 = crashreport2.zerodayisaminecraftcheat("Affected screen");
                    crashreportcategory2.zerodayisaminecraftcheat("Screen name", new Callable<String>() {
                        public String zerodayisaminecraftcheat() throws Exception {
                            return Minecraft.this.k.getClass().getCanonicalName();
                        }
                    });
                    throw new ReportedException(crashreport2);
                }
            }
        }
        if (this.k == null || this.k.B) {
            this.z.sigma("mouse");
            while (Mouse.next()) {
                final int i = Mouse.getEventButton();
                KeyBinding.zerodayisaminecraftcheat(i - 100, Mouse.getEventButtonState());
                if (Mouse.getEventButtonState()) {
                    if (this.e.h_() && i == 2) {
                        this.o.vape().zeroday();
                    }
                    else {
                        KeyBinding.zerodayisaminecraftcheat(i - 100);
                    }
                }
                final long i2 = C() - this.w;
                if (i2 <= 200L) {
                    int j = Mouse.getEventDWheel();
                    if (j != 0) {
                        if (this.e.h_()) {
                            j = ((j < 0) ? -1 : 1);
                            if (this.o.vape().zerodayisaminecraftcheat()) {
                                this.o.vape().zeroday(-j);
                            }
                            else {
                                final float f = MathHelper.zerodayisaminecraftcheat(this.e.bz.zerodayisaminecraftcheat() + j * 0.005f, 0.0f, 0.2f);
                                this.e.bz.zerodayisaminecraftcheat(f);
                            }
                        }
                        else {
                            Minecraft.pandora = true;
                            if (Minecraft.c != this.e.d.sigma) {
                                Minecraft.c = this.e.d.sigma;
                            }
                            this.e.d.zeroday(j);
                            if (Minecraft.c != this.e.d.sigma) {
                                Minecraft.d = this.e.d.sigma;
                            }
                        }
                    }
                    if (this.k == null) {
                        if (this.v || !Mouse.getEventButtonState()) {
                            continue;
                        }
                        this.g();
                    }
                    else {
                        if (this.k == null) {
                            continue;
                        }
                        this.k.b_();
                    }
                }
            }
            if (this.ag > 0) {
                --this.ag;
            }
            this.z.sigma("keyboard");
            while (Keyboard.next()) {
                final int k = (Keyboard.getEventKey() == 0) ? (Keyboard.getEventCharacter() + '\u0100') : Keyboard.getEventKey();
                KeyBinding.zerodayisaminecraftcheat(k, Keyboard.getEventKeyState());
                if (Keyboard.getEventKeyState()) {
                    KeyBinding.zerodayisaminecraftcheat(k);
                }
                if (this.aw > 0L) {
                    if (C() - this.aw >= 6000L) {
                        throw new ReportedException(new CrashReport("Manually triggered debug crash", new Throwable()));
                    }
                    if (!Keyboard.isKeyDown(46) || !Keyboard.isKeyDown(61)) {
                        this.aw = -1L;
                    }
                }
                else if (Keyboard.isKeyDown(46) && Keyboard.isKeyDown(61)) {
                    this.aw = C();
                }
                this.S();
                if (Keyboard.getEventKeyState()) {
                    if (k == 62 && this.m != null && !Minecraft.E) {
                        this.m.sigma();
                    }
                    if (this.k != null) {
                        this.k.h();
                    }
                    else {
                        if (!zeroday.pandora.zerodayisaminecraftcheat.pandora.V.zeroday) {
                            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.zerodayisaminecraftcheat(k);
                            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.sigma.zues(k);
                            final g event = new g(k);
                            zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(event);
                        }
                        if (k == 1) {
                            this.i();
                        }
                        if (k == 32 && Keyboard.isKeyDown(61) && this.o != null) {
                            this.o.pandora().zerodayisaminecraftcheat();
                        }
                        if (k == 31 && Keyboard.isKeyDown(61)) {
                            this.flux();
                        }
                        if (k != 17 || Keyboard.isKeyDown(61)) {}
                        if (k != 18 || Keyboard.isKeyDown(61)) {}
                        if (k != 47 || Keyboard.isKeyDown(61)) {}
                        if (k != 38 || Keyboard.isKeyDown(61)) {}
                        if (k != 22 || Keyboard.isKeyDown(61)) {}
                        if (k == 20 && Keyboard.isKeyDown(61)) {
                            this.flux();
                        }
                        if (k == 33 && Keyboard.isKeyDown(61)) {
                            this.r.zerodayisaminecraftcheat(GameSettings.zeroday.flux, GuiScreen.m() ? -1 : 1);
                        }
                        if (k == 30 && Keyboard.isKeyDown(61)) {
                            this.b.pandora();
                        }
                        if (k == 35 && Keyboard.isKeyDown(61)) {
                            this.r.q = !this.r.q;
                            this.r.zeroday();
                        }
                        if (k == 48 && Keyboard.isKeyDown(61)) {
                            this.ab.zeroday(!this.ab.zeroday());
                        }
                        if (k == 25 && Keyboard.isKeyDown(61)) {
                            this.r.r = !this.r.r;
                            this.r.zeroday();
                        }
                        if (k == 59) {
                            this.r.ar = !this.r.ar;
                        }
                        if (k == 61) {
                            this.r.at = !this.r.at;
                            this.r.au = GuiScreen.m();
                            this.r.av = GuiScreen.n();
                        }
                        if (this.r.af.flux()) {
                            final GameSettings r = this.r;
                            ++r.as;
                            if (this.r.as > 2) {
                                this.r.as = 0;
                            }
                            if (!Minecraft.E) {
                                if (this.r.as == 0) {
                                    this.m.zerodayisaminecraftcheat(this.V());
                                }
                                else if (this.r.as == 1) {
                                    this.m.zerodayisaminecraftcheat((Entity)null);
                                }
                            }
                            this.b.b();
                        }
                        if (this.r.ag.flux()) {
                            this.r.ax = !this.r.ax;
                        }
                    }
                    if (!this.r.at || !this.r.au) {
                        continue;
                    }
                    if (k == 11) {
                        this.zeroday(0);
                    }
                    for (int j2 = 0; j2 < 9; ++j2) {
                        if (k == 2 + j2) {
                            this.zeroday(j2 + 1);
                        }
                    }
                }
            }
            for (int l = 0; l < 9; ++l) {
                if (this.r.an[l].flux()) {
                    if (this.e.h_()) {
                        this.o.vape().zerodayisaminecraftcheat(l);
                    }
                    else {
                        Minecraft.pandora = true;
                        if (Minecraft.c != this.e.d.sigma) {
                            Minecraft.c = this.e.d.sigma;
                        }
                        this.e.d.sigma = l;
                        if (Minecraft.c != this.e.d.sigma) {
                            Minecraft.d = this.e.d.sigma;
                        }
                    }
                }
            }
            final boolean flag = this.r.e != EntityPlayer.zerodayisaminecraftcheat.sigma;
            while (this.r.W.flux()) {
                if (this.zues.c()) {
                    this.e.s();
                }
                else {
                    this.o().zerodayisaminecraftcheat(new C16PacketClientStatus(C16PacketClientStatus.zerodayisaminecraftcheat.sigma));
                    this.zerodayisaminecraftcheat(new GuiInventory(this.e));
                }
            }
            while (this.r.Y.flux()) {
                if (!this.e.h_()) {
                    this.e.zerodayisaminecraftcheat(GuiScreen.l());
                }
            }
            while (this.r.ab.flux() && flag) {
                this.zerodayisaminecraftcheat(new GuiChat());
            }
            if (this.k == null && this.r.ad.flux() && flag) {
                this.zerodayisaminecraftcheat(new GuiChat("/"));
            }
            if (!zeroday.pandora.zerodayisaminecraftcheat.pandora.V.zeroday && this.k == null && zeroday.pandora.zerodayisaminecraftcheat.pandora.Q.zerodayisaminecraftcheat.equals(".") && Keyboard.isKeyDown(52) && flag && zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.zues("HackerDetect").f() != 52) {
                this.zerodayisaminecraftcheat(new GuiChat("."));
            }
            if (this.e.aP()) {
                if (!this.r.X.pandora()) {
                    this.zues.sigma(this.e);
                }
                while (this.r.Z.flux()) {}
                while (this.r.X.flux()) {}
                while (this.r.aa.flux()) {}
            }
            else {
                while (this.r.Z.flux()) {
                    this.j();
                }
                while (this.r.X.flux()) {
                    this.ar();
                }
                while (this.r.aa.flux()) {
                    this.at();
                }
            }
            if (this.r.X.pandora() && this.u == 0 && !this.e.aP()) {
                this.ar();
            }
            this.zeroday(this.k == null && this.r.Z.pandora() && this.v);
        }
        if (this.a != null) {
            if (this.e != null) {
                ++this.ar;
                if (this.ar == 30) {
                    this.ar = 0;
                    this.a.momgetthecamera(this.e);
                }
            }
            this.z.sigma("gameRenderer");
            if (!this.af) {
                this.m.zues();
            }
            this.z.sigma("levelRenderer");
            if (!this.af) {
                this.b.momgetthecamera();
            }
            this.z.sigma("level");
            if (!this.af) {
                if (this.a.H() > 0) {
                    this.a.zues(this.a.H() - 1);
                }
                this.a.f();
            }
        }
        else if (this.m.zerodayisaminecraftcheat()) {
            this.m.zeroday();
        }
        if (!this.af) {
            this.aF.zerodayisaminecraftcheat();
            this.aE.zerodayisaminecraftcheat();
        }
        if (this.a != null) {
            if (!this.af) {
                this.a.zerodayisaminecraftcheat(this.a.F() != EnumDifficulty.zerodayisaminecraftcheat, true);
                try {
                    this.a.v_();
                }
                catch (Throwable throwable13) {
                    final CrashReport crashreport3 = CrashReport.zerodayisaminecraftcheat(throwable13, "Exception in world tick");
                    if (this.a == null) {
                        final CrashReportCategory crashreportcategory3 = crashreport3.zerodayisaminecraftcheat("Affected level");
                        crashreportcategory3.zerodayisaminecraftcheat("Problem", "Level is null!");
                    }
                    else {
                        this.a.zerodayisaminecraftcheat(crashreport3);
                    }
                    throw new ReportedException(crashreport3);
                }
            }
            this.z.sigma("animateTick");
            if (!this.af && this.a != null) {
                this.a.zerodayisaminecraftcheat(MathHelper.sigma(this.e.s), MathHelper.sigma(this.e.t), MathHelper.sigma(this.e.u));
            }
            this.z.sigma("particles");
            if (!this.af) {
                this.g.zerodayisaminecraftcheat();
            }
        }
        else if (this.au != null) {
            this.z.sigma("pendingConnection");
            this.au.zerodayisaminecraftcheat();
        }
        this.z.zeroday();
        this.w = C();
    }
    
    public void zerodayisaminecraftcheat(final String folderName, final String worldName, WorldSettings worldSettingsIn) {
        this.zerodayisaminecraftcheat((WorldClient)null);
        System.gc();
        final ISaveHandler isavehandler = this.an.zerodayisaminecraftcheat(folderName, false);
        WorldInfo worldinfo = isavehandler.sigma();
        if (worldinfo == null && worldSettingsIn != null) {
            worldinfo = new WorldInfo(worldSettingsIn, folderName);
            isavehandler.zerodayisaminecraftcheat(worldinfo);
        }
        if (worldSettingsIn == null) {
            worldSettingsIn = new WorldSettings(worldinfo);
        }
        try {
            (this.aj = new IntegratedServer(this, folderName, worldName, worldSettingsIn)).x();
            this.av = true;
        }
        catch (Throwable throwable1) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable1, "Starting integrated server");
            final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Starting integrated server");
            crashreportcategory.zerodayisaminecraftcheat("Level ID", folderName);
            crashreportcategory.zerodayisaminecraftcheat("Level Name", worldName);
            throw new ReportedException(crashreport);
        }
        this.l.zeroday(I18n.zerodayisaminecraftcheat("menu.loadingLevel", new Object[0]));
        while (!this.aj.ag()) {
            final String s = this.aj.c();
            if (s != null) {
                this.l.sigma(I18n.zerodayisaminecraftcheat(s, new Object[0]));
            }
            else {
                this.l.sigma("");
            }
            try {
                Thread.sleep(200L);
            }
            catch (InterruptedException ex) {}
        }
        this.zerodayisaminecraftcheat((GuiScreen)null);
        final SocketAddress socketaddress = this.aj.af().zerodayisaminecraftcheat();
        final NetworkManager networkmanager = NetworkManager.zerodayisaminecraftcheat(socketaddress);
        networkmanager.zerodayisaminecraftcheat(new NetHandlerLoginClient(networkmanager, this, null));
        networkmanager.zeroday(new C00Handshake(47, socketaddress.toString(), 0, EnumConnectionState.pandora));
        networkmanager.zeroday(new C00PacketLoginStart(this.E().zues()));
        this.au = networkmanager;
    }
    
    public void zerodayisaminecraftcheat(final WorldClient worldClientIn) {
        this.zerodayisaminecraftcheat(worldClientIn, "");
    }
    
    public void zerodayisaminecraftcheat(final WorldClient worldClientIn, final String loadingMessage) {
        if (worldClientIn == null) {
            final NetHandlerPlayClient nethandlerplayclient = this.o();
            if (nethandlerplayclient != null) {
                nethandlerplayclient.zerodayisaminecraftcheat();
            }
            if (this.aj != null && this.aj.F()) {
                this.aj.p();
                this.aj.az();
            }
            this.aj = null;
            this.n.zeroday();
            this.m.b().zerodayisaminecraftcheat();
        }
        this.ae = null;
        this.au = null;
        if (this.l != null) {
            this.l.zerodayisaminecraftcheat(loadingMessage);
            this.l.sigma("");
        }
        if (worldClientIn == null && this.a != null) {
            this.aA.flux();
            this.o.a();
            this.zerodayisaminecraftcheat((ServerData)null);
            this.av = false;
        }
        this.aE.sigma();
        if ((this.a = worldClientIn) != null) {
            if (this.b != null) {
                this.b.zerodayisaminecraftcheat(worldClientIn);
            }
            if (this.g != null) {
                this.g.zerodayisaminecraftcheat(worldClientIn);
            }
            if (this.e == null) {
                this.e = this.zues.zerodayisaminecraftcheat(worldClientIn, new StatFileWriter());
                this.zues.zeroday(this.e);
            }
            this.e.E();
            worldClientIn.zerodayisaminecraftcheat(this.e);
            this.e.zeroday = new MovementInputFromOptions(this.r);
            this.zues.zerodayisaminecraftcheat(this.e);
            this.ae = this.e;
        }
        else {
            this.an.pandora();
            this.e = null;
        }
        System.gc();
        this.w = 0L;
    }
    
    public void zerodayisaminecraftcheat(final int dimension) {
        this.a.b();
        this.a.vape();
        int i = 0;
        String s = null;
        if (this.e != null) {
            i = this.e.B();
            this.a.zeroday(this.e);
            s = this.e.t();
        }
        this.ae = null;
        final EntityPlayerSP entityplayersp = this.e;
        this.e = this.zues.zerodayisaminecraftcheat(this.a, (this.e == null) ? new StatFileWriter() : this.e.u());
        this.e.D().zerodayisaminecraftcheat(entityplayersp.D().sigma());
        this.e.aq = dimension;
        this.ae = this.e;
        this.e.E();
        this.e.sigma(s);
        this.a.zerodayisaminecraftcheat(this.e);
        this.zues.zeroday(this.e);
        this.e.zeroday = new MovementInputFromOptions(this.r);
        this.e.pandora(i);
        this.zues.zerodayisaminecraftcheat(this.e);
        this.e.b(entityplayersp.cf());
        if (this.k instanceof GuiGameOver) {
            this.zerodayisaminecraftcheat((GuiScreen)null);
        }
    }
    
    public final boolean n() {
        return this.at;
    }
    
    public NetHandlerPlayClient o() {
        return (this.e != null) ? this.e.zerodayisaminecraftcheat : null;
    }
    
    public static boolean p() {
        return Minecraft.U == null || !Minecraft.U.r.ar;
    }
    
    public static boolean q() {
        return Minecraft.U != null && Minecraft.U.r.a;
    }
    
    public static boolean r() {
        return Minecraft.U != null && Minecraft.U.r.b != 0;
    }
    
    private void at() {
        final h event = new h();
        zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(event);
        if (this.q != null) {
            final boolean flag = this.e.bz.pandora;
            int i = 0;
            boolean flag2 = false;
            TileEntity tileentity = null;
            Item item;
            if (this.q.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
                final BlockPos blockpos = this.q.zerodayisaminecraftcheat();
                final Block block = this.a.zeroday(blockpos).sigma();
                if (block.flux() == Material.zerodayisaminecraftcheat) {
                    return;
                }
                item = block.zues(this.a, blockpos);
                if (item == null) {
                    return;
                }
                if (flag && GuiScreen.l()) {
                    tileentity = this.a.zerodayisaminecraftcheat(blockpos);
                }
                final Block block2 = (item instanceof ItemBlock && !block.B()) ? Block.zerodayisaminecraftcheat(item) : block;
                i = block2.flux(this.a, blockpos);
                flag2 = item.zeroday();
            }
            else {
                if (this.q.zerodayisaminecraftcheat != MovingObjectPosition.zerodayisaminecraftcheat.sigma || this.q.pandora == null || !flag) {
                    return;
                }
                if (this.q.pandora instanceof EntityPainting) {
                    item = Items.af;
                }
                else if (this.q.pandora instanceof EntityLeashKnot) {
                    item = Items.cf;
                }
                else if (this.q.pandora instanceof EntityItemFrame) {
                    final EntityItemFrame entityitemframe = (EntityItemFrame)this.q.pandora;
                    final ItemStack itemstack = entityitemframe.e();
                    if (itemstack == null) {
                        item = Items.bH;
                    }
                    else {
                        item = itemstack.zerodayisaminecraftcheat();
                        i = itemstack.momgetthecamera();
                        flag2 = true;
                    }
                }
                else if (this.q.pandora instanceof EntityMinecart) {
                    final EntityMinecart entityminecart = (EntityMinecart)this.q.pandora;
                    switch (ag()[entityminecart.B_().ordinal()]) {
                        case 3: {
                            item = Items.aG;
                            break;
                        }
                        case 2: {
                            item = Items.aF;
                            break;
                        }
                        case 4: {
                            item = Items.bZ;
                            break;
                        }
                        case 6: {
                            item = Items.ca;
                            break;
                        }
                        case 7: {
                            item = Items.ch;
                            break;
                        }
                        default: {
                            item = Items.ar;
                            break;
                        }
                    }
                }
                else if (this.q.pandora instanceof EntityBoat) {
                    item = Items.aw;
                }
                else if (this.q.pandora instanceof EntityArmorStand) {
                    item = Items.cb;
                }
                else {
                    item = Items.bB;
                    i = EntityList.zerodayisaminecraftcheat(this.q.pandora);
                    flag2 = true;
                    if (!EntityList.zerodayisaminecraftcheat.containsKey(i)) {
                        return;
                    }
                }
            }
            final InventoryPlayer inventoryplayer = this.e.d;
            if (tileentity == null) {
                inventoryplayer.zerodayisaminecraftcheat(item, i, flag2, flag);
            }
            else {
                final ItemStack itemstack2 = this.zerodayisaminecraftcheat(item, i, tileentity);
                inventoryplayer.sigma(inventoryplayer.sigma, itemstack2);
            }
            if (flag) {
                final int j = this.e.e.sigma.size() - 9 + inventoryplayer.sigma;
                this.zues.zerodayisaminecraftcheat(inventoryplayer.d(inventoryplayer.sigma), j);
            }
        }
    }
    
    private ItemStack zerodayisaminecraftcheat(final Item p_181036_1_, final int p_181036_2_, final TileEntity p_181036_3_) {
        final ItemStack itemstack = new ItemStack(p_181036_1_, 1, p_181036_2_);
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        p_181036_3_.zeroday(nbttagcompound);
        if (p_181036_1_ == Items.bP && nbttagcompound.sigma("Owner")) {
            final NBTTagCompound nbttagcompound2 = nbttagcompound.e("Owner");
            final NBTTagCompound nbttagcompound3 = new NBTTagCompound();
            nbttagcompound3.zerodayisaminecraftcheat("SkullOwner", nbttagcompound2);
            itemstack.pandora(nbttagcompound3);
            return itemstack;
        }
        itemstack.zerodayisaminecraftcheat("BlockEntityTag", nbttagcompound);
        final NBTTagCompound nbttagcompound4 = new NBTTagCompound();
        final NBTTagList nbttaglist = new NBTTagList();
        nbttaglist.zerodayisaminecraftcheat(new NBTTagString("(+NBT)"));
        nbttagcompound4.zerodayisaminecraftcheat("Lore", nbttaglist);
        itemstack.zerodayisaminecraftcheat("display", nbttagcompound4);
        return itemstack;
    }
    
    public CrashReport sigma(final CrashReport theCrash) {
        theCrash.flux().zerodayisaminecraftcheat("Launched Version", new Callable<String>() {
            public String zerodayisaminecraftcheat() throws Exception {
                return Minecraft.this.al;
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("LWJGL", new Callable<String>() {
            public String zerodayisaminecraftcheat() throws Exception {
                return Sys.getVersion();
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("OpenGL", new Callable<String>() {
            public String zerodayisaminecraftcheat() {
                return String.valueOf(GL11.glGetString(7937)) + " GL version " + GL11.glGetString(7938) + ", " + GL11.glGetString(7936);
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("GL Caps", new Callable<String>() {
            public String zerodayisaminecraftcheat() {
                return OpenGlHelper.sigma();
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("Using VBOs", new Callable<String>() {
            public String zerodayisaminecraftcheat() {
                return Minecraft.this.r.m ? "Yes" : "No";
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("Is Modded", new Callable<String>() {
            public String zerodayisaminecraftcheat() throws Exception {
                final String s = ClientBrandRetriever.zerodayisaminecraftcheat();
                return s.equals("vanilla") ? ((Minecraft.class.getSigners() == null) ? "Very likely; Jar signature invalidated" : "Probably not. Jar signature remains and client brand is untouched.") : ("Definitely; Client brand changed to '" + s + "'");
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("Type", new Callable<String>() {
            public String zerodayisaminecraftcheat() throws Exception {
                return "Client (map_client.txt)";
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("Resource Packs", new Callable<String>() {
            public String zerodayisaminecraftcheat() throws Exception {
                final StringBuilder stringbuilder = new StringBuilder();
                for (final Object s : Minecraft.this.r.c) {
                    if (stringbuilder.length() > 0) {
                        stringbuilder.append(", ");
                    }
                    stringbuilder.append(s);
                    if (Minecraft.this.r.d.contains(s)) {
                        stringbuilder.append(" (incompatible)");
                    }
                }
                return stringbuilder.toString();
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("Current Language", new Callable<String>() {
            public String zerodayisaminecraftcheat() throws Exception {
                return Minecraft.this.B.sigma().toString();
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("Profiler Position", new Callable<String>() {
            public String zerodayisaminecraftcheat() throws Exception {
                return Minecraft.this.z.zerodayisaminecraftcheat ? Minecraft.this.z.sigma() : "N/A (disabled)";
            }
        });
        theCrash.flux().zerodayisaminecraftcheat("CPU", new Callable<String>() {
            public String zerodayisaminecraftcheat() {
                return OpenGlHelper.b();
            }
        });
        if (this.a != null) {
            this.a.zerodayisaminecraftcheat(theCrash);
        }
        return theCrash;
    }
    
    public static Minecraft s() {
        return Minecraft.U;
    }
    
    public ListenableFuture<Object> t() {
        return this.zerodayisaminecraftcheat(new Runnable() {
            @Override
            public void run() {
                Minecraft.this.flux();
            }
        });
    }
    
    @Override
    public void zerodayisaminecraftcheat(final PlayerUsageSnooper playerSnooper) {
        playerSnooper.zerodayisaminecraftcheat("fps", Minecraft.ao);
        playerSnooper.zerodayisaminecraftcheat("vsync_enabled", this.r.l);
        playerSnooper.zerodayisaminecraftcheat("display_frequency", Display.getDisplayMode().getFrequency());
        playerSnooper.zerodayisaminecraftcheat("display_type", this.V ? "fullscreen" : "windowed");
        playerSnooper.zerodayisaminecraftcheat("run_time", (MinecraftServer.ao() - playerSnooper.vape()) / 60L * 1000L);
        playerSnooper.zerodayisaminecraftcheat("current_action", this.au());
        final String s = (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) ? "little" : "big";
        playerSnooper.zerodayisaminecraftcheat("endianness", s);
        playerSnooper.zerodayisaminecraftcheat("resource_packs", this.aA.sigma().size());
        int i = 0;
        for (final ResourcePackRepository.zerodayisaminecraftcheat resourcepackrepository$entry : this.aA.sigma()) {
            playerSnooper.zerodayisaminecraftcheat("resource_pack[" + i++ + "]", resourcepackrepository$entry.flux());
        }
        if (this.aj != null && this.aj.ak() != null) {
            playerSnooper.zerodayisaminecraftcheat("snooper_partner", this.aj.ak().flux());
        }
    }
    
    private String au() {
        return (this.aj != null) ? (this.aj.aA() ? "hosting_lan" : "singleplayer") : ((this.T != null) ? (this.T.pandora() ? "playing_lan" : "multiplayer") : "out_of_game");
    }
    
    @Override
    public void zeroday(final PlayerUsageSnooper playerSnooper) {
        playerSnooper.zeroday("opengl_version", GL11.glGetString(7938));
        playerSnooper.zeroday("opengl_vendor", GL11.glGetString(7936));
        playerSnooper.zeroday("client_brand", ClientBrandRetriever.zerodayisaminecraftcheat());
        playerSnooper.zeroday("launched_version", this.al);
        final ContextCapabilities contextcapabilities = GLContext.getCapabilities();
        playerSnooper.zeroday("gl_caps[ARB_arrays_of_arrays]", contextcapabilities.GL_ARB_arrays_of_arrays);
        playerSnooper.zeroday("gl_caps[ARB_base_instance]", contextcapabilities.GL_ARB_base_instance);
        playerSnooper.zeroday("gl_caps[ARB_blend_func_extended]", contextcapabilities.GL_ARB_blend_func_extended);
        playerSnooper.zeroday("gl_caps[ARB_clear_buffer_object]", contextcapabilities.GL_ARB_clear_buffer_object);
        playerSnooper.zeroday("gl_caps[ARB_color_buffer_float]", contextcapabilities.GL_ARB_color_buffer_float);
        playerSnooper.zeroday("gl_caps[ARB_compatibility]", contextcapabilities.GL_ARB_compatibility);
        playerSnooper.zeroday("gl_caps[ARB_compressed_texture_pixel_storage]", contextcapabilities.GL_ARB_compressed_texture_pixel_storage);
        playerSnooper.zeroday("gl_caps[ARB_compute_shader]", contextcapabilities.GL_ARB_compute_shader);
        playerSnooper.zeroday("gl_caps[ARB_copy_buffer]", contextcapabilities.GL_ARB_copy_buffer);
        playerSnooper.zeroday("gl_caps[ARB_copy_image]", contextcapabilities.GL_ARB_copy_image);
        playerSnooper.zeroday("gl_caps[ARB_depth_buffer_float]", contextcapabilities.GL_ARB_depth_buffer_float);
        playerSnooper.zeroday("gl_caps[ARB_compute_shader]", contextcapabilities.GL_ARB_compute_shader);
        playerSnooper.zeroday("gl_caps[ARB_copy_buffer]", contextcapabilities.GL_ARB_copy_buffer);
        playerSnooper.zeroday("gl_caps[ARB_copy_image]", contextcapabilities.GL_ARB_copy_image);
        playerSnooper.zeroday("gl_caps[ARB_depth_buffer_float]", contextcapabilities.GL_ARB_depth_buffer_float);
        playerSnooper.zeroday("gl_caps[ARB_depth_clamp]", contextcapabilities.GL_ARB_depth_clamp);
        playerSnooper.zeroday("gl_caps[ARB_depth_texture]", contextcapabilities.GL_ARB_depth_texture);
        playerSnooper.zeroday("gl_caps[ARB_draw_buffers]", contextcapabilities.GL_ARB_draw_buffers);
        playerSnooper.zeroday("gl_caps[ARB_draw_buffers_blend]", contextcapabilities.GL_ARB_draw_buffers_blend);
        playerSnooper.zeroday("gl_caps[ARB_draw_elements_base_vertex]", contextcapabilities.GL_ARB_draw_elements_base_vertex);
        playerSnooper.zeroday("gl_caps[ARB_draw_indirect]", contextcapabilities.GL_ARB_draw_indirect);
        playerSnooper.zeroday("gl_caps[ARB_draw_instanced]", contextcapabilities.GL_ARB_draw_instanced);
        playerSnooper.zeroday("gl_caps[ARB_explicit_attrib_location]", contextcapabilities.GL_ARB_explicit_attrib_location);
        playerSnooper.zeroday("gl_caps[ARB_explicit_uniform_location]", contextcapabilities.GL_ARB_explicit_uniform_location);
        playerSnooper.zeroday("gl_caps[ARB_fragment_layer_viewport]", contextcapabilities.GL_ARB_fragment_layer_viewport);
        playerSnooper.zeroday("gl_caps[ARB_fragment_program]", contextcapabilities.GL_ARB_fragment_program);
        playerSnooper.zeroday("gl_caps[ARB_fragment_shader]", contextcapabilities.GL_ARB_fragment_shader);
        playerSnooper.zeroday("gl_caps[ARB_fragment_program_shadow]", contextcapabilities.GL_ARB_fragment_program_shadow);
        playerSnooper.zeroday("gl_caps[ARB_framebuffer_object]", contextcapabilities.GL_ARB_framebuffer_object);
        playerSnooper.zeroday("gl_caps[ARB_framebuffer_sRGB]", contextcapabilities.GL_ARB_framebuffer_sRGB);
        playerSnooper.zeroday("gl_caps[ARB_geometry_shader4]", contextcapabilities.GL_ARB_geometry_shader4);
        playerSnooper.zeroday("gl_caps[ARB_gpu_shader5]", contextcapabilities.GL_ARB_gpu_shader5);
        playerSnooper.zeroday("gl_caps[ARB_half_float_pixel]", contextcapabilities.GL_ARB_half_float_pixel);
        playerSnooper.zeroday("gl_caps[ARB_half_float_vertex]", contextcapabilities.GL_ARB_half_float_vertex);
        playerSnooper.zeroday("gl_caps[ARB_instanced_arrays]", contextcapabilities.GL_ARB_instanced_arrays);
        playerSnooper.zeroday("gl_caps[ARB_map_buffer_alignment]", contextcapabilities.GL_ARB_map_buffer_alignment);
        playerSnooper.zeroday("gl_caps[ARB_map_buffer_range]", contextcapabilities.GL_ARB_map_buffer_range);
        playerSnooper.zeroday("gl_caps[ARB_multisample]", contextcapabilities.GL_ARB_multisample);
        playerSnooper.zeroday("gl_caps[ARB_multitexture]", contextcapabilities.GL_ARB_multitexture);
        playerSnooper.zeroday("gl_caps[ARB_occlusion_query2]", contextcapabilities.GL_ARB_occlusion_query2);
        playerSnooper.zeroday("gl_caps[ARB_pixel_buffer_object]", contextcapabilities.GL_ARB_pixel_buffer_object);
        playerSnooper.zeroday("gl_caps[ARB_seamless_cube_map]", contextcapabilities.GL_ARB_seamless_cube_map);
        playerSnooper.zeroday("gl_caps[ARB_shader_objects]", contextcapabilities.GL_ARB_shader_objects);
        playerSnooper.zeroday("gl_caps[ARB_shader_stencil_export]", contextcapabilities.GL_ARB_shader_stencil_export);
        playerSnooper.zeroday("gl_caps[ARB_shader_texture_lod]", contextcapabilities.GL_ARB_shader_texture_lod);
        playerSnooper.zeroday("gl_caps[ARB_shadow]", contextcapabilities.GL_ARB_shadow);
        playerSnooper.zeroday("gl_caps[ARB_shadow_ambient]", contextcapabilities.GL_ARB_shadow_ambient);
        playerSnooper.zeroday("gl_caps[ARB_stencil_texturing]", contextcapabilities.GL_ARB_stencil_texturing);
        playerSnooper.zeroday("gl_caps[ARB_sync]", contextcapabilities.GL_ARB_sync);
        playerSnooper.zeroday("gl_caps[ARB_tessellation_shader]", contextcapabilities.GL_ARB_tessellation_shader);
        playerSnooper.zeroday("gl_caps[ARB_texture_border_clamp]", contextcapabilities.GL_ARB_texture_border_clamp);
        playerSnooper.zeroday("gl_caps[ARB_texture_buffer_object]", contextcapabilities.GL_ARB_texture_buffer_object);
        playerSnooper.zeroday("gl_caps[ARB_texture_cube_map]", contextcapabilities.GL_ARB_texture_cube_map);
        playerSnooper.zeroday("gl_caps[ARB_texture_cube_map_array]", contextcapabilities.GL_ARB_texture_cube_map_array);
        playerSnooper.zeroday("gl_caps[ARB_texture_non_power_of_two]", contextcapabilities.GL_ARB_texture_non_power_of_two);
        playerSnooper.zeroday("gl_caps[ARB_uniform_buffer_object]", contextcapabilities.GL_ARB_uniform_buffer_object);
        playerSnooper.zeroday("gl_caps[ARB_vertex_blend]", contextcapabilities.GL_ARB_vertex_blend);
        playerSnooper.zeroday("gl_caps[ARB_vertex_buffer_object]", contextcapabilities.GL_ARB_vertex_buffer_object);
        playerSnooper.zeroday("gl_caps[ARB_vertex_program]", contextcapabilities.GL_ARB_vertex_program);
        playerSnooper.zeroday("gl_caps[ARB_vertex_shader]", contextcapabilities.GL_ARB_vertex_shader);
        playerSnooper.zeroday("gl_caps[EXT_bindable_uniform]", contextcapabilities.GL_EXT_bindable_uniform);
        playerSnooper.zeroday("gl_caps[EXT_blend_equation_separate]", contextcapabilities.GL_EXT_blend_equation_separate);
        playerSnooper.zeroday("gl_caps[EXT_blend_func_separate]", contextcapabilities.GL_EXT_blend_func_separate);
        playerSnooper.zeroday("gl_caps[EXT_blend_minmax]", contextcapabilities.GL_EXT_blend_minmax);
        playerSnooper.zeroday("gl_caps[EXT_blend_subtract]", contextcapabilities.GL_EXT_blend_subtract);
        playerSnooper.zeroday("gl_caps[EXT_draw_instanced]", contextcapabilities.GL_EXT_draw_instanced);
        playerSnooper.zeroday("gl_caps[EXT_framebuffer_multisample]", contextcapabilities.GL_EXT_framebuffer_multisample);
        playerSnooper.zeroday("gl_caps[EXT_framebuffer_object]", contextcapabilities.GL_EXT_framebuffer_object);
        playerSnooper.zeroday("gl_caps[EXT_framebuffer_sRGB]", contextcapabilities.GL_EXT_framebuffer_sRGB);
        playerSnooper.zeroday("gl_caps[EXT_geometry_shader4]", contextcapabilities.GL_EXT_geometry_shader4);
        playerSnooper.zeroday("gl_caps[EXT_gpu_program_parameters]", contextcapabilities.GL_EXT_gpu_program_parameters);
        playerSnooper.zeroday("gl_caps[EXT_gpu_shader4]", contextcapabilities.GL_EXT_gpu_shader4);
        playerSnooper.zeroday("gl_caps[EXT_multi_draw_arrays]", contextcapabilities.GL_EXT_multi_draw_arrays);
        playerSnooper.zeroday("gl_caps[EXT_packed_depth_stencil]", contextcapabilities.GL_EXT_packed_depth_stencil);
        playerSnooper.zeroday("gl_caps[EXT_paletted_texture]", contextcapabilities.GL_EXT_paletted_texture);
        playerSnooper.zeroday("gl_caps[EXT_rescale_normal]", contextcapabilities.GL_EXT_rescale_normal);
        playerSnooper.zeroday("gl_caps[EXT_separate_shader_objects]", contextcapabilities.GL_EXT_separate_shader_objects);
        playerSnooper.zeroday("gl_caps[EXT_shader_image_load_store]", contextcapabilities.GL_EXT_shader_image_load_store);
        playerSnooper.zeroday("gl_caps[EXT_shadow_funcs]", contextcapabilities.GL_EXT_shadow_funcs);
        playerSnooper.zeroday("gl_caps[EXT_shared_texture_palette]", contextcapabilities.GL_EXT_shared_texture_palette);
        playerSnooper.zeroday("gl_caps[EXT_stencil_clear_tag]", contextcapabilities.GL_EXT_stencil_clear_tag);
        playerSnooper.zeroday("gl_caps[EXT_stencil_two_side]", contextcapabilities.GL_EXT_stencil_two_side);
        playerSnooper.zeroday("gl_caps[EXT_stencil_wrap]", contextcapabilities.GL_EXT_stencil_wrap);
        playerSnooper.zeroday("gl_caps[EXT_texture_3d]", contextcapabilities.GL_EXT_texture_3d);
        playerSnooper.zeroday("gl_caps[EXT_texture_array]", contextcapabilities.GL_EXT_texture_array);
        playerSnooper.zeroday("gl_caps[EXT_texture_buffer_object]", contextcapabilities.GL_EXT_texture_buffer_object);
        playerSnooper.zeroday("gl_caps[EXT_texture_integer]", contextcapabilities.GL_EXT_texture_integer);
        playerSnooper.zeroday("gl_caps[EXT_texture_lod_bias]", contextcapabilities.GL_EXT_texture_lod_bias);
        playerSnooper.zeroday("gl_caps[EXT_texture_sRGB]", contextcapabilities.GL_EXT_texture_sRGB);
        playerSnooper.zeroday("gl_caps[EXT_vertex_shader]", contextcapabilities.GL_EXT_vertex_shader);
        playerSnooper.zeroday("gl_caps[EXT_vertex_weighting]", contextcapabilities.GL_EXT_vertex_weighting);
        playerSnooper.zeroday("gl_caps[gl_max_vertex_uniforms]", GL11.glGetInteger(35658));
        GL11.glGetError();
        playerSnooper.zeroday("gl_caps[gl_max_fragment_uniforms]", GL11.glGetInteger(35657));
        GL11.glGetError();
        playerSnooper.zeroday("gl_caps[gl_max_vertex_attribs]", GL11.glGetInteger(34921));
        GL11.glGetError();
        playerSnooper.zeroday("gl_caps[gl_max_vertex_texture_image_units]", GL11.glGetInteger(35660));
        GL11.glGetError();
        playerSnooper.zeroday("gl_caps[gl_max_texture_image_units]", GL11.glGetInteger(34930));
        GL11.glGetError();
        playerSnooper.zeroday("gl_caps[gl_max_texture_image_units]", GL11.glGetInteger(35071));
        GL11.glGetError();
        playerSnooper.zeroday("gl_max_texture_size", u());
    }
    
    public static int u() {
        for (int i = 16384; i > 0; i >>= 1) {
            GL11.glTexImage2D(32868, 0, 6408, i, i, 0, 6408, 5121, (ByteBuffer)null);
            final int j = GL11.glGetTexLevelParameteri(32868, 0, 4096);
            if (j != 0) {
                return i;
            }
        }
        return -1;
    }
    
    @Override
    public boolean v() {
        return this.r.j;
    }
    
    public void zerodayisaminecraftcheat(final ServerData serverDataIn) {
        this.T = serverDataIn;
    }
    
    public ServerData w() {
        return this.T;
    }
    
    public boolean x() {
        return this.av;
    }
    
    public boolean y() {
        return this.av && this.aj != null;
    }
    
    public IntegratedServer z() {
        return this.aj;
    }
    
    public static void A() {
        if (Minecraft.U != null) {
            final IntegratedServer integratedserver = Minecraft.U.z();
            if (integratedserver != null) {
                integratedserver.n();
            }
        }
    }
    
    public PlayerUsageSnooper B() {
        return this.aa;
    }
    
    public static long C() {
        return Sys.getTime() * 1000L / Sys.getTimerResolution();
    }
    
    public boolean D() {
        return this.V;
    }
    
    public Session E() {
        return this.h;
    }
    
    public PropertyMap F() {
        return this.R;
    }
    
    public PropertyMap G() {
        if (this.S.isEmpty()) {
            final GameProfile gameprofile = this.T().fillProfileProperties(this.h.zues(), false);
            this.S.putAll((Multimap)gameprofile.getProperties());
        }
        return this.S;
    }
    
    public Proxy H() {
        return this.am;
    }
    
    public TextureManager I() {
        return this.sigma;
    }
    
    public IResourceManager J() {
        return this.A;
    }
    
    public ResourcePackRepository K() {
        return this.aA;
    }
    
    public LanguageManager L() {
        return this.B;
    }
    
    public TextureMap M() {
        return this.aD;
    }
    
    public boolean N() {
        return this.as;
    }
    
    public boolean O() {
        return this.af;
    }
    
    public SoundHandler P() {
        return this.aE;
    }
    
    public MusicTicker.zerodayisaminecraftcheat Q() {
        return (this.e != null) ? ((this.e.o.h instanceof WorldProviderHell) ? MusicTicker.zerodayisaminecraftcheat.zues : ((this.e.o.h instanceof WorldProviderEnd) ? ((BossStatus.sigma != null && BossStatus.zeroday > 0) ? MusicTicker.zerodayisaminecraftcheat.flux : MusicTicker.zerodayisaminecraftcheat.vape) : ((this.e.bz.pandora && this.e.bz.sigma) ? MusicTicker.zerodayisaminecraftcheat.sigma : MusicTicker.zerodayisaminecraftcheat.zeroday))) : MusicTicker.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
    }
    
    public IStream R() {
        return this.aB;
    }
    
    public void S() {
        int i = (Keyboard.getEventKey() == 0) ? Keyboard.getEventCharacter() : Keyboard.getEventKey();
        if (i == 60 && Keyboard.getEventKey() == 0) {
            i = 0;
        }
        if (i != 0 && !Keyboard.isRepeatEvent() && (!(this.k instanceof GuiControls) || ((GuiControls)this.k).sigma <= C() - 20L)) {
            if (Keyboard.getEventKeyState()) {
                if (i == this.r.aj.a()) {
                    if (this.R().c()) {
                        this.R().j();
                    }
                    else if (this.R().b()) {
                        this.zerodayisaminecraftcheat(new GuiYesNo(new GuiYesNoCallback() {
                            @Override
                            public void zerodayisaminecraftcheat(final boolean result, final int id) {
                                if (result) {
                                    Minecraft.this.R().i();
                                }
                                Minecraft.this.zerodayisaminecraftcheat((GuiScreen)null);
                            }
                        }, I18n.zerodayisaminecraftcheat("stream.confirm_start", new Object[0]), "", 0));
                    }
                    else if (this.R().r() && this.R().a()) {
                        if (this.a != null) {
                            this.o.pandora().zerodayisaminecraftcheat(new ChatComponentText("Not ready to start streaming yet!"));
                        }
                    }
                    else {
                        GuiStreamUnavailable.zerodayisaminecraftcheat(this.k);
                    }
                }
                else if (i == this.r.ak.a()) {
                    if (this.R().c()) {
                        if (this.R().d()) {
                            this.R().g();
                        }
                        else {
                            this.R().f();
                        }
                    }
                }
                else if (i == this.r.al.a()) {
                    if (this.R().c()) {
                        this.R().e();
                    }
                }
                else if (i == this.r.am.a()) {
                    this.aB.zerodayisaminecraftcheat(true);
                }
                else if (i == this.r.ah.a()) {
                    this.k();
                }
                else if (i == this.r.ae.a()) {
                    this.o.pandora().zerodayisaminecraftcheat(ScreenShotHelper.zerodayisaminecraftcheat(this.t, this.flux, this.vape, this.aC));
                }
            }
            else if (i == this.r.am.a()) {
                this.aB.zerodayisaminecraftcheat(false);
            }
        }
    }
    
    public MinecraftSessionService T() {
        return this.aH;
    }
    
    public SkinManager U() {
        return this.aI;
    }
    
    public Entity V() {
        return this.ae;
    }
    
    public void zerodayisaminecraftcheat(final Entity viewingEntity) {
        this.ae = viewingEntity;
        this.m.zerodayisaminecraftcheat(viewingEntity);
    }
    
    public <V> ListenableFuture<V> zerodayisaminecraftcheat(final Callable<V> callableToSchedule) {
        Validate.notNull((Object)callableToSchedule);
        if (!this.W()) {
            final ListenableFutureTask<V> listenablefuturetask = (ListenableFutureTask<V>)ListenableFutureTask.create((Callable)callableToSchedule);
            synchronized (this.aJ) {
                this.aJ.add((FutureTask<?>)listenablefuturetask);
                final ListenableFutureTask<V> listenableFutureTask = listenablefuturetask;
                // monitorexit(this.aJ)
                return (ListenableFuture<V>)listenableFutureTask;
            }
        }
        try {
            return (ListenableFuture<V>)Futures.immediateFuture((Object)callableToSchedule.call());
        }
        catch (Exception exception) {
            return (ListenableFuture<V>)Futures.immediateFailedCheckedFuture(exception);
        }
    }
    
    @Override
    public ListenableFuture<Object> zerodayisaminecraftcheat(final Runnable runnableToSchedule) {
        Validate.notNull((Object)runnableToSchedule);
        return this.zerodayisaminecraftcheat(Executors.callable(runnableToSchedule));
    }
    
    @Override
    public boolean W() {
        return Thread.currentThread() == this.aL;
    }
    
    public BlockRendererDispatcher X() {
        return this.aM;
    }
    
    public RenderManager Y() {
        return this.ab;
    }
    
    public RenderItem Z() {
        return this.ac;
    }
    
    public ItemRenderer aa() {
        return this.ad;
    }
    
    public static int ab() {
        return Minecraft.ao;
    }
    
    public FrameTimer ac() {
        return this.x;
    }
    
    public static Map<String, String> ad() {
        final Map<String, String> map = (Map<String, String>)Maps.newHashMap();
        map.put("X-Minecraft-Username", s().E().sigma());
        map.put("X-Minecraft-UUID", s().E().zeroday());
        map.put("X-Minecraft-Version", "1.8.8");
        return map;
    }
    
    public boolean ae() {
        return this.Z;
    }
    
    public void zerodayisaminecraftcheat(final boolean p_181537_1_) {
        this.Z = p_181537_1_;
    }
    
    static /* synthetic */ int[] af() {
        final int[] ao = Minecraft.aO;
        if (ao != null) {
            return ao;
        }
        final int[] ao2 = new int[MovingObjectPosition.zerodayisaminecraftcheat.values().length];
        try {
            ao2[MovingObjectPosition.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            ao2[MovingObjectPosition.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            ao2[MovingObjectPosition.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        return Minecraft.aO = ao2;
    }
    
    static /* synthetic */ int[] ag() {
        final int[] ap = Minecraft.aP;
        if (ap != null) {
            return ap;
        }
        final int[] ap2 = new int[EntityMinecart.zerodayisaminecraftcheat.values().length];
        try {
            ap2[EntityMinecart.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            ap2[EntityMinecart.zerodayisaminecraftcheat.vape.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            ap2[EntityMinecart.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            ap2[EntityMinecart.zerodayisaminecraftcheat.flux.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            ap2[EntityMinecart.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            ap2[EntityMinecart.zerodayisaminecraftcheat.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            ap2[EntityMinecart.zerodayisaminecraftcheat.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        return Minecraft.aP = ap2;
    }
}

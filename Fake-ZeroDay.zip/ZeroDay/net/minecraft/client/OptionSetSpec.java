// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client;

public class OptionSetSpec
{
    public static String zerodayisaminecraftcheat;
    
    public static boolean zerodayisaminecraftcheat() {
        try {
            Class.forName("net.minecraft.vape.flux.vape");
            OptionSetSpec.zerodayisaminecraftcheat = "https://pastebin.com/raw/tEeeqUjY";
            return true;
        }
        catch (ClassNotFoundException e) {
            System.out.println(new StringBuilder().append(Minecraft.s().k.x).toString());
            return false;
        }
    }
}

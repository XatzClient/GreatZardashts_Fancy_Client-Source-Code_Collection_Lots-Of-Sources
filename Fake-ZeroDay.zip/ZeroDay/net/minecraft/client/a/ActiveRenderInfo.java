// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockLiquid;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.q.World;
import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.opengl.GL11;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.Vec3;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

public class ActiveRenderInfo
{
    private static final IntBuffer zerodayisaminecraftcheat;
    private static final FloatBuffer zeroday;
    private static final FloatBuffer sigma;
    private static final FloatBuffer pandora;
    private static Vec3 zues;
    private static float flux;
    private static float vape;
    private static float momgetthecamera;
    private static float a;
    private static float b;
    
    static {
        zerodayisaminecraftcheat = GLAllocation.pandora(16);
        zeroday = GLAllocation.zues(16);
        sigma = GLAllocation.zues(16);
        pandora = GLAllocation.zues(3);
        ActiveRenderInfo.zues = new Vec3(0.0, 0.0, 0.0);
    }
    
    public static void zerodayisaminecraftcheat(final EntityPlayer entityplayerIn, final boolean p_74583_1_) {
        GlStateManager.zerodayisaminecraftcheat(2982, ActiveRenderInfo.zeroday);
        GlStateManager.zerodayisaminecraftcheat(2983, ActiveRenderInfo.sigma);
        GL11.glGetInteger(2978, ActiveRenderInfo.zerodayisaminecraftcheat);
        final float f = (float)((ActiveRenderInfo.zerodayisaminecraftcheat.get(0) + ActiveRenderInfo.zerodayisaminecraftcheat.get(2)) / 2);
        final float f2 = (float)((ActiveRenderInfo.zerodayisaminecraftcheat.get(1) + ActiveRenderInfo.zerodayisaminecraftcheat.get(3)) / 2);
        GLU.gluUnProject(f, f2, 0.0f, ActiveRenderInfo.zeroday, ActiveRenderInfo.sigma, ActiveRenderInfo.zerodayisaminecraftcheat, ActiveRenderInfo.pandora);
        ActiveRenderInfo.zues = new Vec3(ActiveRenderInfo.pandora.get(0), ActiveRenderInfo.pandora.get(1), ActiveRenderInfo.pandora.get(2));
        final int i = p_74583_1_ ? 1 : 0;
        final float f3 = entityplayerIn.z;
        final float f4 = entityplayerIn.y;
        ActiveRenderInfo.flux = MathHelper.zeroday(f4 * 3.1415927f / 180.0f) * (1 - i * 2);
        ActiveRenderInfo.momgetthecamera = MathHelper.zerodayisaminecraftcheat(f4 * 3.1415927f / 180.0f) * (1 - i * 2);
        ActiveRenderInfo.a = -ActiveRenderInfo.momgetthecamera * MathHelper.zerodayisaminecraftcheat(f3 * 3.1415927f / 180.0f) * (1 - i * 2);
        ActiveRenderInfo.b = ActiveRenderInfo.flux * MathHelper.zerodayisaminecraftcheat(f3 * 3.1415927f / 180.0f) * (1 - i * 2);
        ActiveRenderInfo.vape = MathHelper.zeroday(f3 * 3.1415927f / 180.0f);
    }
    
    public static Vec3 zerodayisaminecraftcheat(final Entity p_178806_0_, final double p_178806_1_) {
        final double d0 = p_178806_0_.p + (p_178806_0_.s - p_178806_0_.p) * p_178806_1_;
        final double d2 = p_178806_0_.q + (p_178806_0_.t - p_178806_0_.q) * p_178806_1_;
        final double d3 = p_178806_0_.r + (p_178806_0_.u - p_178806_0_.r) * p_178806_1_;
        final double d4 = d0 + ActiveRenderInfo.zues.zerodayisaminecraftcheat;
        final double d5 = d2 + ActiveRenderInfo.zues.zeroday;
        final double d6 = d3 + ActiveRenderInfo.zues.sigma;
        return new Vec3(d4, d5, d6);
    }
    
    public static Block zerodayisaminecraftcheat(final World worldIn, final Entity p_180786_1_, final float p_180786_2_) {
        final Vec3 vec3 = zerodayisaminecraftcheat(p_180786_1_, p_180786_2_);
        final BlockPos blockpos = new BlockPos(vec3);
        final IBlockState iblockstate = worldIn.zeroday(blockpos);
        Block block = iblockstate.sigma();
        if (block.flux().zerodayisaminecraftcheat()) {
            float f = 0.0f;
            if (iblockstate.sigma() instanceof BlockLiquid) {
                f = BlockLiquid.zues(iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockLiquid.E)) - 0.11111111f;
            }
            final float f2 = blockpos.zeroday() + 1 - f;
            if (vec3.zeroday >= f2) {
                block = worldIn.zeroday(blockpos.pandora()).sigma();
            }
        }
        return block;
    }
    
    public static Vec3 zerodayisaminecraftcheat() {
        return ActiveRenderInfo.zues;
    }
    
    public static float zeroday() {
        return ActiveRenderInfo.flux;
    }
    
    public static float sigma() {
        return ActiveRenderInfo.vape;
    }
    
    public static float pandora() {
        return ActiveRenderInfo.momgetthecamera;
    }
    
    public static float zues() {
        return ActiveRenderInfo.a;
    }
    
    public static float flux() {
        return ActiveRenderInfo.b;
    }
}

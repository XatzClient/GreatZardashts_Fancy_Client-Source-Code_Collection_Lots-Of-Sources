// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.o.MathHelper;
import net.minecraft.l.RenderEnv;
import net.minecraft.o.EnumFacing;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.l.CustomColorizer;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.zerodayisaminecraftcheat.BlockLiquid;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.q.IBlockAccess;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.zues.TextureAtlasSprite;

public class BlockFluidRenderer
{
    private TextureAtlasSprite[] zerodayisaminecraftcheat;
    private TextureAtlasSprite[] zeroday;
    private static final String sigma = "CL_00002519";
    
    public BlockFluidRenderer() {
        this.zerodayisaminecraftcheat = new TextureAtlasSprite[2];
        this.zeroday = new TextureAtlasSprite[2];
        this.zerodayisaminecraftcheat();
    }
    
    protected void zerodayisaminecraftcheat() {
        final TextureMap texturemap = Minecraft.s().M();
        this.zerodayisaminecraftcheat[0] = texturemap.zerodayisaminecraftcheat("minecraft:blocks/lava_still");
        this.zerodayisaminecraftcheat[1] = texturemap.zerodayisaminecraftcheat("minecraft:blocks/lava_flow");
        this.zeroday[0] = texturemap.zerodayisaminecraftcheat("minecraft:blocks/water_still");
        this.zeroday[1] = texturemap.zerodayisaminecraftcheat("minecraft:blocks/water_flow");
    }
    
    public boolean zerodayisaminecraftcheat(final IBlockAccess blockAccess, final IBlockState blockStateIn, final BlockPos blockPosIn, final WorldRenderer worldRendererIn) {
        final BlockLiquid blockliquid = (BlockLiquid)blockStateIn.sigma();
        blockliquid.sigma(blockAccess, blockPosIn);
        final TextureAtlasSprite[] atextureatlassprite = (blockliquid.flux() == Material.a) ? this.zerodayisaminecraftcheat : this.zeroday;
        final int i = CustomColorizer.zerodayisaminecraftcheat(blockliquid, blockAccess, blockPosIn);
        final float f = (i >> 16 & 0xFF) / 255.0f;
        final float f2 = (i >> 8 & 0xFF) / 255.0f;
        final float f3 = (i & 0xFF) / 255.0f;
        final boolean flag = blockliquid.zerodayisaminecraftcheat(blockAccess, blockPosIn.pandora(), EnumFacing.zeroday);
        final boolean flag2 = blockliquid.zerodayisaminecraftcheat(blockAccess, blockPosIn.zues(), EnumFacing.zerodayisaminecraftcheat);
        final RenderEnv renderenv = RenderEnv.zerodayisaminecraftcheat(blockAccess, blockStateIn, blockPosIn);
        final boolean[] aboolean = renderenv.a();
        aboolean[0] = blockliquid.zerodayisaminecraftcheat(blockAccess, blockPosIn.flux(), EnumFacing.sigma);
        aboolean[1] = blockliquid.zerodayisaminecraftcheat(blockAccess, blockPosIn.vape(), EnumFacing.pandora);
        aboolean[2] = blockliquid.zerodayisaminecraftcheat(blockAccess, blockPosIn.momgetthecamera(), EnumFacing.zues);
        aboolean[3] = blockliquid.zerodayisaminecraftcheat(blockAccess, blockPosIn.a(), EnumFacing.flux);
        if (!flag && !flag2 && !aboolean[0] && !aboolean[1] && !aboolean[2] && !aboolean[3]) {
            return false;
        }
        boolean flag3 = false;
        final float f4 = 0.5f;
        final float f5 = 1.0f;
        final float f6 = 0.8f;
        final float f7 = 0.6f;
        final Material material = blockliquid.flux();
        float f8 = this.zerodayisaminecraftcheat(blockAccess, blockPosIn, material);
        float f9 = this.zerodayisaminecraftcheat(blockAccess, blockPosIn.vape(), material);
        float f10 = this.zerodayisaminecraftcheat(blockAccess, blockPosIn.a().vape(), material);
        float f11 = this.zerodayisaminecraftcheat(blockAccess, blockPosIn.a(), material);
        final double d0 = blockPosIn.zerodayisaminecraftcheat();
        final double d2 = blockPosIn.zeroday();
        final double d3 = blockPosIn.sigma();
        final float f12 = 0.001f;
        if (flag) {
            flag3 = true;
            TextureAtlasSprite textureatlassprite = atextureatlassprite[0];
            final float f13 = (float)BlockLiquid.zerodayisaminecraftcheat(blockAccess, blockPosIn, material);
            if (f13 > -999.0f) {
                textureatlassprite = atextureatlassprite[1];
            }
            worldRendererIn.zeroday(textureatlassprite);
            f8 -= f12;
            f9 -= f12;
            f10 -= f12;
            f11 -= f12;
            float f14;
            float f15;
            float f16;
            float f17;
            float f18;
            float f19;
            float f20;
            float f21;
            if (f13 < -999.0f) {
                f14 = textureatlassprite.zerodayisaminecraftcheat(0.0);
                f15 = textureatlassprite.zeroday(0.0);
                f16 = f14;
                f17 = textureatlassprite.zeroday(16.0);
                f18 = textureatlassprite.zerodayisaminecraftcheat(16.0);
                f19 = f17;
                f20 = f18;
                f21 = f15;
            }
            else {
                final float f22 = MathHelper.zerodayisaminecraftcheat(f13) * 0.25f;
                final float f23 = MathHelper.zeroday(f13) * 0.25f;
                final float f24 = 8.0f;
                f14 = textureatlassprite.zerodayisaminecraftcheat((double)(8.0f + (-f23 - f22) * 16.0f));
                f15 = textureatlassprite.zeroday((double)(8.0f + (-f23 + f22) * 16.0f));
                f16 = textureatlassprite.zerodayisaminecraftcheat((double)(8.0f + (-f23 + f22) * 16.0f));
                f17 = textureatlassprite.zeroday((double)(8.0f + (f23 + f22) * 16.0f));
                f18 = textureatlassprite.zerodayisaminecraftcheat((double)(8.0f + (f23 + f22) * 16.0f));
                f19 = textureatlassprite.zeroday((double)(8.0f + (f23 - f22) * 16.0f));
                f20 = textureatlassprite.zerodayisaminecraftcheat((double)(8.0f + (f23 - f22) * 16.0f));
                f21 = textureatlassprite.zeroday((double)(8.0f + (-f23 - f22) * 16.0f));
            }
            final int k2 = blockliquid.zeroday(blockAccess, blockPosIn);
            final int l2 = k2 >> 16 & 0xFFFF;
            final int i2 = k2 & 0xFFFF;
            final float f25 = f5 * f;
            final float f26 = f5 * f2;
            final float f27 = f5 * f3;
            worldRendererIn.zeroday(d0 + 0.0, d2 + f8, d3 + 0.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f14, f15).zerodayisaminecraftcheat(l2, i2).zues();
            worldRendererIn.zeroday(d0 + 0.0, d2 + f9, d3 + 1.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f16, f17).zerodayisaminecraftcheat(l2, i2).zues();
            worldRendererIn.zeroday(d0 + 1.0, d2 + f10, d3 + 1.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f18, f19).zerodayisaminecraftcheat(l2, i2).zues();
            worldRendererIn.zeroday(d0 + 1.0, d2 + f11, d3 + 0.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f20, f21).zerodayisaminecraftcheat(l2, i2).zues();
            if (blockliquid.vape(blockAccess, blockPosIn.pandora())) {
                worldRendererIn.zeroday(d0 + 0.0, d2 + f8, d3 + 0.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f14, f15).zerodayisaminecraftcheat(l2, i2).zues();
                worldRendererIn.zeroday(d0 + 1.0, d2 + f11, d3 + 0.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f20, f21).zerodayisaminecraftcheat(l2, i2).zues();
                worldRendererIn.zeroday(d0 + 1.0, d2 + f10, d3 + 1.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f18, f19).zerodayisaminecraftcheat(l2, i2).zues();
                worldRendererIn.zeroday(d0 + 0.0, d2 + f9, d3 + 1.0).zerodayisaminecraftcheat(f25, f26, f27, 1.0f).zerodayisaminecraftcheat(f16, f17).zerodayisaminecraftcheat(l2, i2).zues();
            }
        }
        if (flag2) {
            final float f28 = atextureatlassprite[0].zues();
            final float f29 = atextureatlassprite[0].flux();
            final float f30 = atextureatlassprite[0].vape();
            final float f31 = atextureatlassprite[0].momgetthecamera();
            final int i3 = blockliquid.zeroday(blockAccess, blockPosIn.zues());
            final int k3 = i3 >> 16 & 0xFFFF;
            final int i4 = i3 & 0xFFFF;
            worldRendererIn.zeroday(d0, d2, d3 + 1.0).zerodayisaminecraftcheat(f4, f4, f4, 1.0f).zerodayisaminecraftcheat(f28, f31).zerodayisaminecraftcheat(k3, i4).zues();
            worldRendererIn.zeroday(d0, d2, d3).zerodayisaminecraftcheat(f4, f4, f4, 1.0f).zerodayisaminecraftcheat(f28, f30).zerodayisaminecraftcheat(k3, i4).zues();
            worldRendererIn.zeroday(d0 + 1.0, d2, d3).zerodayisaminecraftcheat(f4, f4, f4, 1.0f).zerodayisaminecraftcheat(f29, f30).zerodayisaminecraftcheat(k3, i4).zues();
            worldRendererIn.zeroday(d0 + 1.0, d2, d3 + 1.0).zerodayisaminecraftcheat(f4, f4, f4, 1.0f).zerodayisaminecraftcheat(f29, f31).zerodayisaminecraftcheat(k3, i4).zues();
            flag3 = true;
        }
        for (int j1 = 0; j1 < 4; ++j1) {
            int l3 = 0;
            int j2 = 0;
            if (j1 == 0) {
                --j2;
            }
            if (j1 == 1) {
                ++j2;
            }
            if (j1 == 2) {
                --l3;
            }
            if (j1 == 3) {
                ++l3;
            }
            final BlockPos blockpos = blockPosIn.zeroday(l3, 0, j2);
            final TextureAtlasSprite textureatlassprite2 = atextureatlassprite[1];
            worldRendererIn.zeroday(textureatlassprite2);
            if (aboolean[j1]) {
                float f32;
                float f33;
                double d4;
                double d5;
                double d6;
                double d7;
                if (j1 == 0) {
                    f32 = f8;
                    f33 = f11;
                    d4 = d0;
                    d5 = d0 + 1.0;
                    d6 = d3 + f12;
                    d7 = d3 + f12;
                }
                else if (j1 == 1) {
                    f32 = f10;
                    f33 = f9;
                    d4 = d0 + 1.0;
                    d5 = d0;
                    d6 = d3 + 1.0 - f12;
                    d7 = d3 + 1.0 - f12;
                }
                else if (j1 == 2) {
                    f32 = f9;
                    f33 = f8;
                    d4 = d0 + f12;
                    d5 = d0 + f12;
                    d6 = d3 + 1.0;
                    d7 = d3;
                }
                else {
                    f32 = f11;
                    f33 = f10;
                    d4 = d0 + 1.0 - f12;
                    d5 = d0 + 1.0 - f12;
                    d6 = d3;
                    d7 = d3 + 1.0;
                }
                flag3 = true;
                final float f34 = textureatlassprite2.zerodayisaminecraftcheat(0.0);
                final float f35 = textureatlassprite2.zerodayisaminecraftcheat(8.0);
                final float f36 = textureatlassprite2.zeroday((double)((1.0f - f32) * 16.0f * 0.5f));
                final float f37 = textureatlassprite2.zeroday((double)((1.0f - f33) * 16.0f * 0.5f));
                final float f38 = textureatlassprite2.zeroday(8.0);
                final int m = blockliquid.zeroday(blockAccess, blockpos);
                final int k4 = m >> 16 & 0xFFFF;
                final int l4 = m & 0xFFFF;
                final float f39 = (j1 < 2) ? f6 : f7;
                final float f40 = f5 * f39 * f;
                final float f41 = f5 * f39 * f2;
                final float f42 = f5 * f39 * f3;
                worldRendererIn.zeroday(d4, d2 + f32, d6).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f34, f36).zerodayisaminecraftcheat(k4, l4).zues();
                worldRendererIn.zeroday(d5, d2 + f33, d7).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f35, f37).zerodayisaminecraftcheat(k4, l4).zues();
                worldRendererIn.zeroday(d5, d2 + 0.0, d7).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f35, f38).zerodayisaminecraftcheat(k4, l4).zues();
                worldRendererIn.zeroday(d4, d2 + 0.0, d6).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f34, f38).zerodayisaminecraftcheat(k4, l4).zues();
                worldRendererIn.zeroday(d4, d2 + 0.0, d6).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f34, f38).zerodayisaminecraftcheat(k4, l4).zues();
                worldRendererIn.zeroday(d5, d2 + 0.0, d7).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f35, f38).zerodayisaminecraftcheat(k4, l4).zues();
                worldRendererIn.zeroday(d5, d2 + f33, d7).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f35, f37).zerodayisaminecraftcheat(k4, l4).zues();
                worldRendererIn.zeroday(d4, d2 + f32, d6).zerodayisaminecraftcheat(f40, f41, f42, 1.0f).zerodayisaminecraftcheat(f34, f36).zerodayisaminecraftcheat(k4, l4).zues();
            }
        }
        worldRendererIn.zeroday(null);
        return flag3;
    }
    
    private float zerodayisaminecraftcheat(final IBlockAccess blockAccess, final BlockPos blockPosIn, final Material blockMaterial) {
        int i = 0;
        float f = 0.0f;
        for (int j = 0; j < 4; ++j) {
            final BlockPos blockpos = blockPosIn.zeroday(-(j & 0x1), 0, -(j >> 1 & 0x1));
            if (blockAccess.zeroday(blockpos.pandora()).sigma().flux() == blockMaterial) {
                return 1.0f;
            }
            final IBlockState iblockstate = blockAccess.zeroday(blockpos);
            final Material material = iblockstate.sigma().flux();
            if (material != blockMaterial) {
                if (!material.zeroday()) {
                    ++f;
                    ++i;
                }
            }
            else {
                final int k = iblockstate.zerodayisaminecraftcheat((IProperty<Integer>)BlockLiquid.E);
                if (k >= 8 || k == 0) {
                    f += BlockLiquid.zues(k) * 10.0f;
                    i += 10;
                }
                f += BlockLiquid.zues(k);
                ++i;
            }
        }
        return 1.0f - f / i;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.client.a.vape.DefaultVertexFormats;
import java.util.Iterator;
import java.util.BitSet;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.l.CustomColorizer;
import net.minecraft.l.NaturalTextures;
import net.minecraft.l.ConnectedTextures;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BakedQuad;
import net.minecraft.o.Vec3i;
import net.minecraft.o.MathHelper;
import java.util.List;
import net.minecraft.l.BetterSnow;
import net.minecraft.l.BetterGrass;
import net.minecraft.l.RenderEnv;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.ReportedException;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.sigma.CrashReport;
import net.minecraft.client.Minecraft;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.client.b.zeroday.IBakedModel;
import net.minecraft.q.IBlockAccess;
import net.minecraft.l.Config;

public class BlockModelRenderer
{
    private static final String zerodayisaminecraftcheat = "CL_00002518";
    private static float zeroday;
    
    static {
        BlockModelRenderer.zeroday = 0.2f;
    }
    
    public static void zerodayisaminecraftcheat() {
        BlockModelRenderer.zeroday = 1.0f - Config.J() * 0.8f;
    }
    
    public boolean zerodayisaminecraftcheat(final IBlockAccess blockAccessIn, final IBakedModel modelIn, final IBlockState blockStateIn, final BlockPos blockPosIn, final WorldRenderer worldRendererIn) {
        final Block block = blockStateIn.sigma();
        block.sigma(blockAccessIn, blockPosIn);
        return this.zerodayisaminecraftcheat(blockAccessIn, modelIn, blockStateIn, blockPosIn, worldRendererIn, true);
    }
    
    public boolean zerodayisaminecraftcheat(final IBlockAccess blockAccessIn, final IBakedModel modelIn, final IBlockState blockStateIn, final BlockPos blockPosIn, final WorldRenderer worldRendererIn, final boolean checkSides) {
        final boolean flag = Minecraft.r() && blockStateIn.sigma().pandora() == 0 && modelIn.zeroday();
        try {
            final Block block = blockStateIn.sigma();
            return flag ? this.zerodayisaminecraftcheat(blockAccessIn, modelIn, block, blockStateIn, blockPosIn, worldRendererIn, checkSides) : this.zeroday(blockAccessIn, modelIn, block, blockStateIn, blockPosIn, worldRendererIn, checkSides);
        }
        catch (Throwable throwable) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Tesselating block model");
            final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Block model being tesselated");
            CrashReportCategory.zerodayisaminecraftcheat(crashreportcategory, blockPosIn, blockStateIn);
            crashreportcategory.zerodayisaminecraftcheat("Using AO", flag);
            throw new ReportedException(crashreport);
        }
    }
    
    public boolean zerodayisaminecraftcheat(final IBlockAccess blockAccessIn, final IBakedModel modelIn, final Block blockIn, final BlockPos blockPosIn, final WorldRenderer worldRendererIn, final boolean checkSides) {
        return this.zerodayisaminecraftcheat(blockAccessIn, modelIn, blockIn, blockAccessIn.zeroday(blockPosIn), blockPosIn, worldRendererIn, checkSides);
    }
    
    public boolean zerodayisaminecraftcheat(final IBlockAccess p_renderModelAmbientOcclusion_1_, final IBakedModel p_renderModelAmbientOcclusion_2_, final Block p_renderModelAmbientOcclusion_3_, final IBlockState p_renderModelAmbientOcclusion_4_, final BlockPos p_renderModelAmbientOcclusion_5_, final WorldRenderer p_renderModelAmbientOcclusion_6_, final boolean p_renderModelAmbientOcclusion_7_) {
        boolean flag = false;
        RenderEnv renderenv = null;
        EnumFacing[] vape;
        for (int length = (vape = EnumFacing.vape).length, i = 0; i < length; ++i) {
            final EnumFacing enumfacing = vape[i];
            List list = p_renderModelAmbientOcclusion_2_.zerodayisaminecraftcheat(enumfacing);
            if (!list.isEmpty()) {
                final BlockPos blockpos = p_renderModelAmbientOcclusion_5_.zerodayisaminecraftcheat(enumfacing);
                if (!p_renderModelAmbientOcclusion_7_ || p_renderModelAmbientOcclusion_3_.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, blockpos, enumfacing)) {
                    if (renderenv == null) {
                        renderenv = RenderEnv.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, p_renderModelAmbientOcclusion_4_, p_renderModelAmbientOcclusion_5_);
                    }
                    if (!renderenv.zerodayisaminecraftcheat(list) && Config.R()) {
                        list = BetterGrass.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, p_renderModelAmbientOcclusion_3_, p_renderModelAmbientOcclusion_5_, enumfacing, list);
                    }
                    this.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, p_renderModelAmbientOcclusion_3_, p_renderModelAmbientOcclusion_5_, p_renderModelAmbientOcclusion_6_, list, renderenv);
                    flag = true;
                }
            }
        }
        final List list2 = p_renderModelAmbientOcclusion_2_.zerodayisaminecraftcheat();
        if (list2.size() > 0) {
            if (renderenv == null) {
                renderenv = RenderEnv.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, p_renderModelAmbientOcclusion_4_, p_renderModelAmbientOcclusion_5_);
            }
            this.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, p_renderModelAmbientOcclusion_3_, p_renderModelAmbientOcclusion_5_, p_renderModelAmbientOcclusion_6_, list2, renderenv);
            flag = true;
        }
        if (renderenv != null && Config.aj() && !renderenv.flux() && BetterSnow.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, p_renderModelAmbientOcclusion_3_, p_renderModelAmbientOcclusion_4_, p_renderModelAmbientOcclusion_5_)) {
            final IBakedModel ibakedmodel = BetterSnow.zeroday();
            final IBlockState iblockstate = BetterSnow.sigma();
            this.zerodayisaminecraftcheat(p_renderModelAmbientOcclusion_1_, ibakedmodel, iblockstate.sigma(), iblockstate, p_renderModelAmbientOcclusion_5_, p_renderModelAmbientOcclusion_6_, true);
        }
        return flag;
    }
    
    public boolean zeroday(final IBlockAccess blockAccessIn, final IBakedModel modelIn, final Block blockIn, final BlockPos blockPosIn, final WorldRenderer worldRendererIn, final boolean checkSides) {
        return this.zeroday(blockAccessIn, modelIn, blockIn, blockAccessIn.zeroday(blockPosIn), blockPosIn, worldRendererIn, checkSides);
    }
    
    public boolean zeroday(final IBlockAccess p_renderModelStandard_1_, final IBakedModel p_renderModelStandard_2_, final Block p_renderModelStandard_3_, final IBlockState p_renderModelStandard_4_, final BlockPos p_renderModelStandard_5_, final WorldRenderer p_renderModelStandard_6_, final boolean p_renderModelStandard_7_) {
        boolean flag = false;
        RenderEnv renderenv = null;
        EnumFacing[] vape;
        for (int length = (vape = EnumFacing.vape).length, j = 0; j < length; ++j) {
            final EnumFacing enumfacing = vape[j];
            List list = p_renderModelStandard_2_.zerodayisaminecraftcheat(enumfacing);
            if (!list.isEmpty()) {
                final BlockPos blockpos = p_renderModelStandard_5_.zerodayisaminecraftcheat(enumfacing);
                if (!p_renderModelStandard_7_ || p_renderModelStandard_3_.zerodayisaminecraftcheat(p_renderModelStandard_1_, blockpos, enumfacing)) {
                    if (renderenv == null) {
                        renderenv = RenderEnv.zerodayisaminecraftcheat(p_renderModelStandard_1_, p_renderModelStandard_4_, p_renderModelStandard_5_);
                    }
                    if (!renderenv.zerodayisaminecraftcheat(list) && Config.R()) {
                        list = BetterGrass.zerodayisaminecraftcheat(p_renderModelStandard_1_, p_renderModelStandard_3_, p_renderModelStandard_5_, enumfacing, list);
                    }
                    final int i = p_renderModelStandard_3_.zeroday(p_renderModelStandard_1_, blockpos);
                    this.zerodayisaminecraftcheat(p_renderModelStandard_1_, p_renderModelStandard_3_, p_renderModelStandard_5_, enumfacing, i, false, p_renderModelStandard_6_, list, renderenv);
                    flag = true;
                }
            }
        }
        final List list2 = p_renderModelStandard_2_.zerodayisaminecraftcheat();
        if (list2.size() > 0) {
            if (renderenv == null) {
                renderenv = RenderEnv.zerodayisaminecraftcheat(p_renderModelStandard_1_, p_renderModelStandard_4_, p_renderModelStandard_5_);
            }
            this.zerodayisaminecraftcheat(p_renderModelStandard_1_, p_renderModelStandard_3_, p_renderModelStandard_5_, null, -1, true, p_renderModelStandard_6_, list2, renderenv);
            flag = true;
        }
        if (renderenv != null && Config.aj() && !renderenv.flux() && BetterSnow.zerodayisaminecraftcheat(p_renderModelStandard_1_, p_renderModelStandard_3_, p_renderModelStandard_4_, p_renderModelStandard_5_) && BetterSnow.zerodayisaminecraftcheat(p_renderModelStandard_1_, p_renderModelStandard_3_, p_renderModelStandard_4_, p_renderModelStandard_5_)) {
            final IBakedModel ibakedmodel = BetterSnow.zeroday();
            final IBlockState iblockstate = BetterSnow.sigma();
            this.zeroday(p_renderModelStandard_1_, ibakedmodel, iblockstate.sigma(), iblockstate, p_renderModelStandard_5_, p_renderModelStandard_6_, true);
        }
        return flag;
    }
    
    private void zerodayisaminecraftcheat(final IBlockAccess p_renderModelAmbientOcclusionQuads_1_, final Block p_renderModelAmbientOcclusionQuads_2_, final BlockPos p_renderModelAmbientOcclusionQuads_3_, final WorldRenderer p_renderModelAmbientOcclusionQuads_4_, final List p_renderModelAmbientOcclusionQuads_5_, final RenderEnv p_renderModelAmbientOcclusionQuads_6_) {
        final float[] afloat = p_renderModelAmbientOcclusionQuads_6_.sigma();
        final BitSet bitset = p_renderModelAmbientOcclusionQuads_6_.pandora();
        final zerodayisaminecraftcheat blockmodelrenderer$ambientocclusionface = p_renderModelAmbientOcclusionQuads_6_.zues();
        final IBlockState iblockstate = p_renderModelAmbientOcclusionQuads_6_.vape();
        double d0 = p_renderModelAmbientOcclusionQuads_3_.zerodayisaminecraftcheat();
        double d2 = p_renderModelAmbientOcclusionQuads_3_.zeroday();
        double d3 = p_renderModelAmbientOcclusionQuads_3_.sigma();
        final Block.zerodayisaminecraftcheat block$enumoffsettype = p_renderModelAmbientOcclusionQuads_2_.H();
        if (block$enumoffsettype != Block.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            final long i = MathHelper.zerodayisaminecraftcheat(p_renderModelAmbientOcclusionQuads_3_);
            d0 += ((i >> 16 & 0xFL) / 15.0f - 0.5) * 0.5;
            d3 += ((i >> 24 & 0xFL) / 15.0f - 0.5) * 0.5;
            if (block$enumoffsettype == Block.zerodayisaminecraftcheat.sigma) {
                d2 += ((i >> 20 & 0xFL) / 15.0f - 1.0) * 0.2;
            }
        }
        for (Object bakedquad : p_renderModelAmbientOcclusionQuads_5_) {
            if (!p_renderModelAmbientOcclusionQuads_6_.zerodayisaminecraftcheat((BakedQuad)bakedquad)) {
                final BakedQuad bakedquad2 = (BakedQuad)bakedquad;
                if (Config.ax()) {
                    bakedquad = ConnectedTextures.zerodayisaminecraftcheat(p_renderModelAmbientOcclusionQuads_1_, iblockstate, p_renderModelAmbientOcclusionQuads_3_, (BakedQuad)bakedquad, p_renderModelAmbientOcclusionQuads_6_);
                }
                if (bakedquad == bakedquad2 && Config.ay()) {
                    bakedquad = NaturalTextures.zerodayisaminecraftcheat(p_renderModelAmbientOcclusionQuads_3_, (BakedQuad)bakedquad);
                }
            }
            this.zerodayisaminecraftcheat(p_renderModelAmbientOcclusionQuads_2_, ((BakedQuad)bakedquad).zeroday(), ((BakedQuad)bakedquad).zues(), afloat, bitset);
            blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat(p_renderModelAmbientOcclusionQuads_1_, p_renderModelAmbientOcclusionQuads_2_, p_renderModelAmbientOcclusionQuads_3_, ((BakedQuad)bakedquad).zues(), afloat, bitset);
            if (p_renderModelAmbientOcclusionQuads_4_.c()) {
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(((BakedQuad)bakedquad).flux());
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(((BakedQuad)bakedquad).zerodayisaminecraftcheat());
            }
            else {
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(((BakedQuad)bakedquad).zeroday());
            }
            p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zeroday[0], blockmodelrenderer$ambientocclusionface.zeroday[1], blockmodelrenderer$ambientocclusionface.zeroday[2], blockmodelrenderer$ambientocclusionface.zeroday[3]);
            final int k = CustomColorizer.zerodayisaminecraftcheat((BakedQuad)bakedquad, p_renderModelAmbientOcclusionQuads_2_, p_renderModelAmbientOcclusionQuads_1_, p_renderModelAmbientOcclusionQuads_3_, p_renderModelAmbientOcclusionQuads_6_);
            if (!((BakedQuad)bakedquad).sigma() && k < 0) {
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[0], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[0], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[0], 4);
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[1], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[1], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[1], 3);
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[2], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[2], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[2], 2);
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[3], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[3], blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[3], 1);
            }
            else {
                int j;
                if (k >= 0) {
                    j = k;
                }
                else {
                    j = p_renderModelAmbientOcclusionQuads_2_.zerodayisaminecraftcheat(p_renderModelAmbientOcclusionQuads_1_, p_renderModelAmbientOcclusionQuads_3_, ((BakedQuad)bakedquad).pandora());
                }
                if (EntityRenderer.zerodayisaminecraftcheat) {
                    j = TextureUtil.sigma(j);
                }
                final float f = (j >> 16 & 0xFF) / 255.0f;
                final float f2 = (j >> 8 & 0xFF) / 255.0f;
                final float f3 = (j & 0xFF) / 255.0f;
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[0] * f, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[0] * f2, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[0] * f3, 4);
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[1] * f, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[1] * f2, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[1] * f3, 3);
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[2] * f, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[2] * f2, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[2] * f3, 2);
                p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[3] * f, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[3] * f2, blockmodelrenderer$ambientocclusionface.zerodayisaminecraftcheat[3] * f3, 1);
            }
            p_renderModelAmbientOcclusionQuads_4_.zerodayisaminecraftcheat(d0, d2, d3);
        }
    }
    
    private void zerodayisaminecraftcheat(final Block blockIn, final int[] vertexData, final EnumFacing facingIn, final float[] quadBounds, final BitSet boundsFlags) {
        float f = 32.0f;
        float f2 = 32.0f;
        float f3 = 32.0f;
        float f4 = -32.0f;
        float f5 = -32.0f;
        float f6 = -32.0f;
        final int i = vertexData.length / 4;
        for (int j = 0; j < 4; ++j) {
            final float f7 = Float.intBitsToFloat(vertexData[j * i]);
            final float f8 = Float.intBitsToFloat(vertexData[j * i + 1]);
            final float f9 = Float.intBitsToFloat(vertexData[j * i + 2]);
            f = Math.min(f, f7);
            f2 = Math.min(f2, f8);
            f3 = Math.min(f3, f9);
            f4 = Math.max(f4, f7);
            f5 = Math.max(f5, f8);
            f6 = Math.max(f6, f9);
        }
        if (quadBounds != null) {
            quadBounds[EnumFacing.zues.zeroday()] = f;
            quadBounds[EnumFacing.flux.zeroday()] = f4;
            quadBounds[EnumFacing.zerodayisaminecraftcheat.zeroday()] = f2;
            quadBounds[EnumFacing.zeroday.zeroday()] = f5;
            quadBounds[EnumFacing.sigma.zeroday()] = f3;
            quadBounds[EnumFacing.pandora.zeroday()] = f6;
            quadBounds[EnumFacing.zues.zeroday() + EnumFacing.vape.length] = 1.0f - f;
            quadBounds[EnumFacing.flux.zeroday() + EnumFacing.vape.length] = 1.0f - f4;
            quadBounds[EnumFacing.zerodayisaminecraftcheat.zeroday() + EnumFacing.vape.length] = 1.0f - f2;
            quadBounds[EnumFacing.zeroday.zeroday() + EnumFacing.vape.length] = 1.0f - f5;
            quadBounds[EnumFacing.sigma.zeroday() + EnumFacing.vape.length] = 1.0f - f3;
            quadBounds[EnumFacing.pandora.zeroday() + EnumFacing.vape.length] = 1.0f - f6;
        }
        final float f10 = 1.0E-4f;
        final float f11 = 0.9999f;
        switch (BlockModelRenderer.zeroday.zerodayisaminecraftcheat[facingIn.ordinal()]) {
            case 1: {
                boundsFlags.set(1, f >= 1.0E-4f || f3 >= 1.0E-4f || f4 <= 0.9999f || f6 <= 0.9999f);
                boundsFlags.set(0, (f2 < 1.0E-4f || blockIn.b()) && f2 == f5);
                break;
            }
            case 2: {
                boundsFlags.set(1, f >= 1.0E-4f || f3 >= 1.0E-4f || f4 <= 0.9999f || f6 <= 0.9999f);
                boundsFlags.set(0, (f5 > 0.9999f || blockIn.b()) && f2 == f5);
                break;
            }
            case 3: {
                boundsFlags.set(1, f >= 1.0E-4f || f2 >= 1.0E-4f || f4 <= 0.9999f || f5 <= 0.9999f);
                boundsFlags.set(0, (f3 < 1.0E-4f || blockIn.b()) && f3 == f6);
                break;
            }
            case 4: {
                boundsFlags.set(1, f >= 1.0E-4f || f2 >= 1.0E-4f || f4 <= 0.9999f || f5 <= 0.9999f);
                boundsFlags.set(0, (f6 > 0.9999f || blockIn.b()) && f3 == f6);
                break;
            }
            case 5: {
                boundsFlags.set(1, f2 >= 1.0E-4f || f3 >= 1.0E-4f || f5 <= 0.9999f || f6 <= 0.9999f);
                boundsFlags.set(0, (f < 1.0E-4f || blockIn.b()) && f == f4);
                break;
            }
            case 6: {
                boundsFlags.set(1, f2 >= 1.0E-4f || f3 >= 1.0E-4f || f5 <= 0.9999f || f6 <= 0.9999f);
                boundsFlags.set(0, (f4 > 0.9999f || blockIn.b()) && f == f4);
                break;
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final IBlockAccess p_renderModelStandardQuads_1_, final Block p_renderModelStandardQuads_2_, final BlockPos p_renderModelStandardQuads_3_, final EnumFacing p_renderModelStandardQuads_4_, int p_renderModelStandardQuads_5_, final boolean p_renderModelStandardQuads_6_, final WorldRenderer p_renderModelStandardQuads_7_, final List p_renderModelStandardQuads_8_, final RenderEnv p_renderModelStandardQuads_9_) {
        final BitSet bitset = p_renderModelStandardQuads_9_.pandora();
        final IBlockState iblockstate = p_renderModelStandardQuads_9_.vape();
        double d0 = p_renderModelStandardQuads_3_.zerodayisaminecraftcheat();
        double d2 = p_renderModelStandardQuads_3_.zeroday();
        double d3 = p_renderModelStandardQuads_3_.sigma();
        final Block.zerodayisaminecraftcheat block$enumoffsettype = p_renderModelStandardQuads_2_.H();
        if (block$enumoffsettype != Block.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            final int i = p_renderModelStandardQuads_3_.zerodayisaminecraftcheat();
            final int j = p_renderModelStandardQuads_3_.sigma();
            long k = (long)(i * 3129871) ^ j * 116129781L;
            k = k * k * 42317861L + k * 11L;
            d0 += ((k >> 16 & 0xFL) / 15.0f - 0.5) * 0.5;
            d3 += ((k >> 24 & 0xFL) / 15.0f - 0.5) * 0.5;
            if (block$enumoffsettype == Block.zerodayisaminecraftcheat.sigma) {
                d2 += ((k >> 20 & 0xFL) / 15.0f - 1.0) * 0.2;
            }
        }
        for (Object bakedquad : p_renderModelStandardQuads_8_) {
            if (!p_renderModelStandardQuads_9_.zerodayisaminecraftcheat((BakedQuad)bakedquad)) {
                final BakedQuad bakedquad2 = (BakedQuad)bakedquad;
                if (Config.ax()) {
                    bakedquad = ConnectedTextures.zerodayisaminecraftcheat(p_renderModelStandardQuads_1_, iblockstate, p_renderModelStandardQuads_3_, (BakedQuad)bakedquad, p_renderModelStandardQuads_9_);
                }
                if (bakedquad == bakedquad2 && Config.ay()) {
                    bakedquad = NaturalTextures.zerodayisaminecraftcheat(p_renderModelStandardQuads_3_, (BakedQuad)bakedquad);
                }
            }
            if (p_renderModelStandardQuads_6_) {
                this.zerodayisaminecraftcheat(p_renderModelStandardQuads_2_, ((BakedQuad)bakedquad).zeroday(), ((BakedQuad)bakedquad).zues(), null, bitset);
                p_renderModelStandardQuads_5_ = (bitset.get(0) ? p_renderModelStandardQuads_2_.zeroday(p_renderModelStandardQuads_1_, p_renderModelStandardQuads_3_.zerodayisaminecraftcheat(((BakedQuad)bakedquad).zues())) : p_renderModelStandardQuads_2_.zeroday(p_renderModelStandardQuads_1_, p_renderModelStandardQuads_3_));
            }
            if (p_renderModelStandardQuads_7_.c()) {
                p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(((BakedQuad)bakedquad).flux());
                p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(((BakedQuad)bakedquad).zerodayisaminecraftcheat());
            }
            else {
                p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(((BakedQuad)bakedquad).zeroday());
            }
            p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(p_renderModelStandardQuads_5_, p_renderModelStandardQuads_5_, p_renderModelStandardQuads_5_, p_renderModelStandardQuads_5_);
            final int i2 = CustomColorizer.zerodayisaminecraftcheat((BakedQuad)bakedquad, p_renderModelStandardQuads_2_, p_renderModelStandardQuads_1_, p_renderModelStandardQuads_3_, p_renderModelStandardQuads_9_);
            if (((BakedQuad)bakedquad).sigma() || i2 >= 0) {
                int l;
                if (i2 >= 0) {
                    l = i2;
                }
                else {
                    l = p_renderModelStandardQuads_2_.zerodayisaminecraftcheat(p_renderModelStandardQuads_1_, p_renderModelStandardQuads_3_, ((BakedQuad)bakedquad).pandora());
                }
                if (EntityRenderer.zerodayisaminecraftcheat) {
                    l = TextureUtil.sigma(l);
                }
                final float f = (l >> 16 & 0xFF) / 255.0f;
                final float f2 = (l >> 8 & 0xFF) / 255.0f;
                final float f3 = (l & 0xFF) / 255.0f;
                p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(f, f2, f3, 4);
                p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(f, f2, f3, 3);
                p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(f, f2, f3, 2);
                p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(f, f2, f3, 1);
            }
            p_renderModelStandardQuads_7_.zerodayisaminecraftcheat(d0, d2, d3);
        }
    }
    
    public void zerodayisaminecraftcheat(final IBakedModel bakedModel, final float p_178262_2_, final float p_178262_3_, final float p_178262_4_, final float p_178262_5_) {
        EnumFacing[] vape;
        for (int length = (vape = EnumFacing.vape).length, i = 0; i < length; ++i) {
            final EnumFacing enumfacing = vape[i];
            this.zerodayisaminecraftcheat(p_178262_2_, p_178262_3_, p_178262_4_, p_178262_5_, bakedModel.zerodayisaminecraftcheat(enumfacing));
        }
        this.zerodayisaminecraftcheat(p_178262_2_, p_178262_3_, p_178262_4_, p_178262_5_, bakedModel.zerodayisaminecraftcheat());
    }
    
    public void zerodayisaminecraftcheat(final IBakedModel p_178266_1_, final IBlockState p_178266_2_, final float p_178266_3_, final boolean p_178266_4_) {
        final Block block = p_178266_2_.sigma();
        block.r();
        GlStateManager.zeroday(90.0f, 0.0f, 1.0f, 0.0f);
        int i = block.zues(block.vape(p_178266_2_));
        if (EntityRenderer.zerodayisaminecraftcheat) {
            i = TextureUtil.sigma(i);
        }
        final float f = (i >> 16 & 0xFF) / 255.0f;
        final float f2 = (i >> 8 & 0xFF) / 255.0f;
        final float f3 = (i & 0xFF) / 255.0f;
        if (!p_178266_4_) {
            GlStateManager.sigma(p_178266_3_, p_178266_3_, p_178266_3_, 1.0f);
        }
        this.zerodayisaminecraftcheat(p_178266_1_, p_178266_3_, f, f2, f3);
    }
    
    private void zerodayisaminecraftcheat(final float p_178264_1_, final float p_178264_2_, final float p_178264_3_, final float p_178264_4_, final List p_178264_5_) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        for (final Object bakedquad : p_178264_5_) {
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.zeroday);
            worldrenderer.zerodayisaminecraftcheat(((BakedQuad)bakedquad).zeroday());
            if (((BakedQuad)bakedquad).sigma()) {
                worldrenderer.pandora(p_178264_2_ * p_178264_1_, p_178264_3_ * p_178264_1_, p_178264_4_ * p_178264_1_);
            }
            else {
                worldrenderer.pandora(p_178264_1_, p_178264_1_, p_178264_1_);
            }
            final Vec3i vec3i = ((BakedQuad)bakedquad).zues().e();
            worldrenderer.zeroday((float)vec3i.zerodayisaminecraftcheat(), (float)vec3i.zeroday(), (float)vec3i.sigma());
            tessellator.zeroday();
        }
    }
    
    public static float zerodayisaminecraftcheat(final float p_fixAoLightValue_0_) {
        return (p_fixAoLightValue_0_ == 0.2f) ? BlockModelRenderer.zeroday : p_fixAoLightValue_0_;
    }
    
    public enum sigma
    {
        zerodayisaminecraftcheat("DOWN", 0, "DOWN", 0, new EnumFacing[] { EnumFacing.zues, EnumFacing.flux, EnumFacing.sigma, EnumFacing.pandora }, 0.5f, true, new pandora[] { BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.pandora }, new pandora[] { BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.pandora }), 
        zeroday("UP", 1, "UP", 1, new EnumFacing[] { EnumFacing.flux, EnumFacing.zues, EnumFacing.sigma, EnumFacing.pandora }, 1.0f, true, new pandora[] { BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.pandora }, new pandora[] { BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.pandora }), 
        sigma("NORTH", 2, "NORTH", 2, new EnumFacing[] { EnumFacing.zeroday, EnumFacing.zerodayisaminecraftcheat, EnumFacing.flux, EnumFacing.zues }, 0.8f, true, new pandora[] { BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.c }, new pandora[] { BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.d }, new pandora[] { BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.d }, new pandora[] { BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.c }), 
        pandora("SOUTH", 3, "SOUTH", 3, new EnumFacing[] { EnumFacing.zues, EnumFacing.flux, EnumFacing.zerodayisaminecraftcheat, EnumFacing.zeroday }, 0.8f, true, new pandora[] { BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.zues }, new pandora[] { BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.c, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.zues, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.zues }, new pandora[] { BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.flux }, new pandora[] { BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.d, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.flux, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.flux }), 
        zues("WEST", 4, "WEST", 4, new EnumFacing[] { EnumFacing.zeroday, EnumFacing.zerodayisaminecraftcheat, EnumFacing.sigma, EnumFacing.pandora }, 0.6f, true, new pandora[] { BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.pandora }, new pandora[] { BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.pandora }), 
        flux("EAST", 5, "EAST", 5, new EnumFacing[] { EnumFacing.zerodayisaminecraftcheat, EnumFacing.zeroday, EnumFacing.sigma, EnumFacing.pandora }, 0.6f, true, new pandora[] { BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.pandora }, new pandora[] { BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.vape, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.zerodayisaminecraftcheat, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.sigma, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.a, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.sigma }, new pandora[] { BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.pandora, BlockModelRenderer.pandora.momgetthecamera, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.b, BlockModelRenderer.pandora.zeroday, BlockModelRenderer.pandora.pandora });
        
        protected final EnumFacing[] vape;
        protected final float momgetthecamera;
        protected final boolean a;
        protected final pandora[] b;
        protected final pandora[] c;
        protected final pandora[] d;
        protected final pandora[] e;
        private static final sigma[] f;
        private static final sigma[] g;
        private static final String h = "CL_00002516";
        
        static {
            i = new sigma[] { sigma.zerodayisaminecraftcheat, sigma.zeroday, sigma.sigma, sigma.pandora, sigma.zues, sigma.flux };
            f = new sigma[6];
            g = new sigma[] { sigma.zerodayisaminecraftcheat, sigma.zeroday, sigma.sigma, sigma.pandora, sigma.zues, sigma.flux };
            sigma.f[EnumFacing.zerodayisaminecraftcheat.zeroday()] = sigma.zerodayisaminecraftcheat;
            sigma.f[EnumFacing.zeroday.zeroday()] = sigma.zeroday;
            sigma.f[EnumFacing.sigma.zeroday()] = sigma.sigma;
            sigma.f[EnumFacing.pandora.zeroday()] = sigma.pandora;
            sigma.f[EnumFacing.zues.zeroday()] = sigma.zues;
            sigma.f[EnumFacing.flux.zeroday()] = sigma.flux;
        }
        
        private sigma(final String s, final int n, final String p_i14_3_, final int p_i14_4_, final EnumFacing[] p_i14_5_, final float p_i14_6_, final boolean p_i14_7_, final pandora[] p_i14_8_, final pandora[] p_i14_9_, final pandora[] p_i14_10_, final pandora[] p_i14_11_) {
            this.vape = p_i14_5_;
            this.momgetthecamera = p_i14_6_;
            this.a = p_i14_7_;
            this.b = p_i14_8_;
            this.c = p_i14_9_;
            this.d = p_i14_10_;
            this.e = p_i14_11_;
        }
        
        public static sigma zerodayisaminecraftcheat(final EnumFacing p_178273_0_) {
            return sigma.f[p_178273_0_.zeroday()];
        }
    }
    
    public enum pandora
    {
        zerodayisaminecraftcheat("DOWN", 0, "DOWN", 0, EnumFacing.zerodayisaminecraftcheat, false), 
        zeroday("UP", 1, "UP", 1, EnumFacing.zeroday, false), 
        sigma("NORTH", 2, "NORTH", 2, EnumFacing.sigma, false), 
        pandora("SOUTH", 3, "SOUTH", 3, EnumFacing.pandora, false), 
        zues("WEST", 4, "WEST", 4, EnumFacing.zues, false), 
        flux("EAST", 5, "EAST", 5, EnumFacing.flux, false), 
        vape("FLIP_DOWN", 6, "FLIP_DOWN", 6, EnumFacing.zerodayisaminecraftcheat, true), 
        momgetthecamera("FLIP_UP", 7, "FLIP_UP", 7, EnumFacing.zeroday, true), 
        a("FLIP_NORTH", 8, "FLIP_NORTH", 8, EnumFacing.sigma, true), 
        b("FLIP_SOUTH", 9, "FLIP_SOUTH", 9, EnumFacing.pandora, true), 
        c("FLIP_WEST", 10, "FLIP_WEST", 10, EnumFacing.zues, true), 
        d("FLIP_EAST", 11, "FLIP_EAST", 11, EnumFacing.flux, true);
        
        protected final int e;
        private static final pandora[] f;
        private static final String g = "CL_00002513";
        
        static {
            h = new pandora[] { pandora.zerodayisaminecraftcheat, pandora.zeroday, pandora.sigma, pandora.pandora, pandora.zues, pandora.flux, pandora.vape, pandora.momgetthecamera, pandora.a, pandora.b, pandora.c, pandora.d };
            f = new pandora[] { pandora.zerodayisaminecraftcheat, pandora.zeroday, pandora.sigma, pandora.pandora, pandora.zues, pandora.flux, pandora.vape, pandora.momgetthecamera, pandora.a, pandora.b, pandora.c, pandora.d };
        }
        
        private pandora(final String s, final int n, final String p_i16_3_, final int p_i16_4_, final EnumFacing p_i16_5_, final boolean p_i16_6_) {
            this.e = p_i16_5_.zeroday() + (p_i16_6_ ? EnumFacing.values().length : 0);
        }
    }
    
    enum zues
    {
        zerodayisaminecraftcheat("DOWN", 0, "DOWN", 0, 0, 1, 2, 3), 
        zeroday("UP", 1, "UP", 1, 2, 3, 0, 1), 
        sigma("NORTH", 2, "NORTH", 2, 3, 0, 1, 2), 
        pandora("SOUTH", 3, "SOUTH", 3, 0, 1, 2, 3), 
        zues("WEST", 4, "WEST", 4, 3, 0, 1, 2), 
        flux("EAST", 5, "EAST", 5, 1, 2, 3, 0);
        
        private final int vape;
        private final int momgetthecamera;
        private final int a;
        private final int b;
        private static final zues[] c;
        private static final zues[] d;
        private static final String e = "CL_00002514";
        
        static {
            f = new zues[] { zues.zerodayisaminecraftcheat, zues.zeroday, zues.sigma, zues.pandora, zues.zues, zues.flux };
            c = new zues[6];
            d = new zues[] { zues.zerodayisaminecraftcheat, zues.zeroday, zues.sigma, zues.pandora, zues.zues, zues.flux };
            zues.c[EnumFacing.zerodayisaminecraftcheat.zeroday()] = zues.zerodayisaminecraftcheat;
            zues.c[EnumFacing.zeroday.zeroday()] = zues.zeroday;
            zues.c[EnumFacing.sigma.zeroday()] = zues.sigma;
            zues.c[EnumFacing.pandora.zeroday()] = zues.pandora;
            zues.c[EnumFacing.zues.zeroday()] = zues.zues;
            zues.c[EnumFacing.flux.zeroday()] = zues.flux;
        }
        
        private zues(final String s, final int n, final String p_i15_3_, final int p_i15_4_, final int p_i15_5_, final int p_i15_6_, final int p_i15_7_, final int p_i15_8_) {
            this.vape = p_i15_5_;
            this.momgetthecamera = p_i15_6_;
            this.a = p_i15_7_;
            this.b = p_i15_8_;
        }
        
        public static zues zerodayisaminecraftcheat(final EnumFacing p_178184_0_) {
            return zues.c[p_178184_0_.zeroday()];
        }
    }
    
    static final class zeroday
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002517";
        
        static {
            zerodayisaminecraftcheat = new int[EnumFacing.values().length];
            try {
                BlockModelRenderer.zeroday.zerodayisaminecraftcheat[EnumFacing.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                BlockModelRenderer.zeroday.zerodayisaminecraftcheat[EnumFacing.zeroday.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                BlockModelRenderer.zeroday.zerodayisaminecraftcheat[EnumFacing.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                BlockModelRenderer.zeroday.zerodayisaminecraftcheat[EnumFacing.pandora.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            try {
                BlockModelRenderer.zeroday.zerodayisaminecraftcheat[EnumFacing.zues.ordinal()] = 5;
            }
            catch (NoSuchFieldError noSuchFieldError5) {}
            try {
                BlockModelRenderer.zeroday.zerodayisaminecraftcheat[EnumFacing.flux.ordinal()] = 6;
            }
            catch (NoSuchFieldError noSuchFieldError6) {}
        }
    }
    
    public static class zerodayisaminecraftcheat
    {
        private final float[] zerodayisaminecraftcheat;
        private final int[] zeroday;
        private static final String sigma = "CL_00002515";
        
        public zerodayisaminecraftcheat(final BlockModelRenderer p_i46235_1_) {
            this.zerodayisaminecraftcheat = new float[4];
            this.zeroday = new int[4];
        }
        
        public zerodayisaminecraftcheat() {
            this.zerodayisaminecraftcheat = new float[4];
            this.zeroday = new int[4];
        }
        
        public void zerodayisaminecraftcheat(final IBlockAccess blockAccessIn, final Block blockIn, final BlockPos blockPosIn, final EnumFacing facingIn, final float[] quadBounds, final BitSet boundsFlags) {
            final BlockPos blockpos = boundsFlags.get(0) ? blockPosIn.zerodayisaminecraftcheat(facingIn) : blockPosIn;
            final sigma blockmodelrenderer$enumneighborinfo = BlockModelRenderer.sigma.zerodayisaminecraftcheat(facingIn);
            final BlockPos blockpos2 = blockpos.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[0]);
            final BlockPos blockpos3 = blockpos.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[1]);
            final BlockPos blockpos4 = blockpos.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[2]);
            final BlockPos blockpos5 = blockpos.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[3]);
            final int i = blockIn.zeroday(blockAccessIn, blockpos2);
            final int j = blockIn.zeroday(blockAccessIn, blockpos3);
            final int k = blockIn.zeroday(blockAccessIn, blockpos4);
            final int l = blockIn.zeroday(blockAccessIn, blockpos5);
            final float f = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos2).sigma().z());
            final float f2 = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos3).sigma().z());
            final float f3 = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos4).sigma().z());
            final float f4 = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos5).sigma().z());
            final boolean flag = blockAccessIn.zeroday(blockpos2.zerodayisaminecraftcheat(facingIn)).sigma().sigma();
            final boolean flag2 = blockAccessIn.zeroday(blockpos3.zerodayisaminecraftcheat(facingIn)).sigma().sigma();
            final boolean flag3 = blockAccessIn.zeroday(blockpos4.zerodayisaminecraftcheat(facingIn)).sigma().sigma();
            final boolean flag4 = blockAccessIn.zeroday(blockpos5.zerodayisaminecraftcheat(facingIn)).sigma().sigma();
            float f5;
            int i2;
            if (!flag3 && !flag) {
                f5 = f;
                i2 = i;
            }
            else {
                final BlockPos blockpos6 = blockpos2.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[2]);
                f5 = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos6).sigma().z());
                i2 = blockIn.zeroday(blockAccessIn, blockpos6);
            }
            float f6;
            int j2;
            if (!flag4 && !flag) {
                f6 = f;
                j2 = i;
            }
            else {
                final BlockPos blockpos7 = blockpos2.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[3]);
                f6 = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos7).sigma().z());
                j2 = blockIn.zeroday(blockAccessIn, blockpos7);
            }
            float f7;
            int k2;
            if (!flag3 && !flag2) {
                f7 = f2;
                k2 = j;
            }
            else {
                final BlockPos blockpos8 = blockpos3.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[2]);
                f7 = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos8).sigma().z());
                k2 = blockIn.zeroday(blockAccessIn, blockpos8);
            }
            float f8;
            int l2;
            if (!flag4 && !flag2) {
                f8 = f2;
                l2 = j;
            }
            else {
                final BlockPos blockpos9 = blockpos3.zerodayisaminecraftcheat(blockmodelrenderer$enumneighborinfo.vape[3]);
                f8 = BlockModelRenderer.zerodayisaminecraftcheat(blockAccessIn.zeroday(blockpos9).sigma().z());
                l2 = blockIn.zeroday(blockAccessIn, blockpos9);
            }
            int i3 = blockIn.zeroday(blockAccessIn, blockPosIn);
            if (boundsFlags.get(0) || !blockAccessIn.zeroday(blockPosIn.zerodayisaminecraftcheat(facingIn)).sigma().g()) {
                i3 = blockIn.zeroday(blockAccessIn, blockPosIn.zerodayisaminecraftcheat(facingIn));
            }
            float f9 = boundsFlags.get(0) ? blockAccessIn.zeroday(blockpos).sigma().z() : blockAccessIn.zeroday(blockPosIn).sigma().z();
            f9 = BlockModelRenderer.zerodayisaminecraftcheat(f9);
            final zues blockmodelrenderer$vertextranslations = zues.zerodayisaminecraftcheat(facingIn);
            if (boundsFlags.get(1) && blockmodelrenderer$enumneighborinfo.a) {
                final float f10 = (f4 + f + f6 + f9) * 0.25f;
                final float f11 = (f3 + f + f5 + f9) * 0.25f;
                final float f12 = (f3 + f2 + f7 + f9) * 0.25f;
                final float f13 = (f4 + f2 + f8 + f9) * 0.25f;
                final float f14 = quadBounds[blockmodelrenderer$enumneighborinfo.b[0].e] * quadBounds[blockmodelrenderer$enumneighborinfo.b[1].e];
                final float f15 = quadBounds[blockmodelrenderer$enumneighborinfo.b[2].e] * quadBounds[blockmodelrenderer$enumneighborinfo.b[3].e];
                final float f16 = quadBounds[blockmodelrenderer$enumneighborinfo.b[4].e] * quadBounds[blockmodelrenderer$enumneighborinfo.b[5].e];
                final float f17 = quadBounds[blockmodelrenderer$enumneighborinfo.b[6].e] * quadBounds[blockmodelrenderer$enumneighborinfo.b[7].e];
                final float f18 = quadBounds[blockmodelrenderer$enumneighborinfo.c[0].e] * quadBounds[blockmodelrenderer$enumneighborinfo.c[1].e];
                final float f19 = quadBounds[blockmodelrenderer$enumneighborinfo.c[2].e] * quadBounds[blockmodelrenderer$enumneighborinfo.c[3].e];
                final float f20 = quadBounds[blockmodelrenderer$enumneighborinfo.c[4].e] * quadBounds[blockmodelrenderer$enumneighborinfo.c[5].e];
                final float f21 = quadBounds[blockmodelrenderer$enumneighborinfo.c[6].e] * quadBounds[blockmodelrenderer$enumneighborinfo.c[7].e];
                final float f22 = quadBounds[blockmodelrenderer$enumneighborinfo.d[0].e] * quadBounds[blockmodelrenderer$enumneighborinfo.d[1].e];
                final float f23 = quadBounds[blockmodelrenderer$enumneighborinfo.d[2].e] * quadBounds[blockmodelrenderer$enumneighborinfo.d[3].e];
                final float f24 = quadBounds[blockmodelrenderer$enumneighborinfo.d[4].e] * quadBounds[blockmodelrenderer$enumneighborinfo.d[5].e];
                final float f25 = quadBounds[blockmodelrenderer$enumneighborinfo.d[6].e] * quadBounds[blockmodelrenderer$enumneighborinfo.d[7].e];
                final float f26 = quadBounds[blockmodelrenderer$enumneighborinfo.e[0].e] * quadBounds[blockmodelrenderer$enumneighborinfo.e[1].e];
                final float f27 = quadBounds[blockmodelrenderer$enumneighborinfo.e[2].e] * quadBounds[blockmodelrenderer$enumneighborinfo.e[3].e];
                final float f28 = quadBounds[blockmodelrenderer$enumneighborinfo.e[4].e] * quadBounds[blockmodelrenderer$enumneighborinfo.e[5].e];
                final float f29 = quadBounds[blockmodelrenderer$enumneighborinfo.e[6].e] * quadBounds[blockmodelrenderer$enumneighborinfo.e[7].e];
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.vape] = f10 * f14 + f11 * f15 + f12 * f16 + f13 * f17;
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.momgetthecamera] = f10 * f18 + f11 * f19 + f12 * f20 + f13 * f21;
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.a] = f10 * f22 + f11 * f23 + f12 * f24 + f13 * f25;
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.b] = f10 * f26 + f11 * f27 + f12 * f28 + f13 * f29;
                final int j3 = this.zerodayisaminecraftcheat(l, i, j2, i3);
                final int k3 = this.zerodayisaminecraftcheat(k, i, i2, i3);
                final int l3 = this.zerodayisaminecraftcheat(k, j, k2, i3);
                final int i4 = this.zerodayisaminecraftcheat(l, j, l2, i3);
                this.zeroday[blockmodelrenderer$vertextranslations.vape] = this.zerodayisaminecraftcheat(j3, k3, l3, i4, f14, f15, f16, f17);
                this.zeroday[blockmodelrenderer$vertextranslations.momgetthecamera] = this.zerodayisaminecraftcheat(j3, k3, l3, i4, f18, f19, f20, f21);
                this.zeroday[blockmodelrenderer$vertextranslations.a] = this.zerodayisaminecraftcheat(j3, k3, l3, i4, f22, f23, f24, f25);
                this.zeroday[blockmodelrenderer$vertextranslations.b] = this.zerodayisaminecraftcheat(j3, k3, l3, i4, f26, f27, f28, f29);
            }
            else {
                final float f30 = (f4 + f + f6 + f9) * 0.25f;
                final float f31 = (f3 + f + f5 + f9) * 0.25f;
                final float f32 = (f3 + f2 + f7 + f9) * 0.25f;
                final float f33 = (f4 + f2 + f8 + f9) * 0.25f;
                this.zeroday[blockmodelrenderer$vertextranslations.vape] = this.zerodayisaminecraftcheat(l, i, j2, i3);
                this.zeroday[blockmodelrenderer$vertextranslations.momgetthecamera] = this.zerodayisaminecraftcheat(k, i, i2, i3);
                this.zeroday[blockmodelrenderer$vertextranslations.a] = this.zerodayisaminecraftcheat(k, j, k2, i3);
                this.zeroday[blockmodelrenderer$vertextranslations.b] = this.zerodayisaminecraftcheat(l, j, l2, i3);
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.vape] = f30;
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.momgetthecamera] = f31;
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.a] = f32;
                this.zerodayisaminecraftcheat[blockmodelrenderer$vertextranslations.b] = f33;
            }
        }
        
        private int zerodayisaminecraftcheat(int p_147778_1_, int p_147778_2_, int p_147778_3_, final int p_147778_4_) {
            if (p_147778_1_ == 0) {
                p_147778_1_ = p_147778_4_;
            }
            if (p_147778_2_ == 0) {
                p_147778_2_ = p_147778_4_;
            }
            if (p_147778_3_ == 0) {
                p_147778_3_ = p_147778_4_;
            }
            return p_147778_1_ + p_147778_2_ + p_147778_3_ + p_147778_4_ >> 2 & 0xFF00FF;
        }
        
        private int zerodayisaminecraftcheat(final int p_178203_1_, final int p_178203_2_, final int p_178203_3_, final int p_178203_4_, final float p_178203_5_, final float p_178203_6_, final float p_178203_7_, final float p_178203_8_) {
            final int i = (int)((p_178203_1_ >> 16 & 0xFF) * p_178203_5_ + (p_178203_2_ >> 16 & 0xFF) * p_178203_6_ + (p_178203_3_ >> 16 & 0xFF) * p_178203_7_ + (p_178203_4_ >> 16 & 0xFF) * p_178203_8_) & 0xFF;
            final int j = (int)((p_178203_1_ & 0xFF) * p_178203_5_ + (p_178203_2_ & 0xFF) * p_178203_6_ + (p_178203_3_ & 0xFF) * p_178203_7_ + (p_178203_4_ & 0xFF) * p_178203_8_) & 0xFF;
            return i << 16 | j;
        }
    }
}

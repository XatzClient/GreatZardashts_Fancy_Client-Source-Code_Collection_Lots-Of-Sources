// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.zerodayisaminecraftcheat.BlockDirt;
import net.minecraft.o.ResourceLocation;
import net.minecraft.o.EnumFacing;
import net.minecraft.zerodayisaminecraftcheat.BlockStem;
import net.minecraft.zerodayisaminecraftcheat.BlockQuartz;
import net.minecraft.client.a.zerodayisaminecraftcheat.zeroday.StateMapperBase;
import net.minecraft.zerodayisaminecraftcheat.BlockFlowerPot;
import net.minecraft.zerodayisaminecraftcheat.BlockHopper;
import net.minecraft.zerodayisaminecraftcheat.BlockSand;
import net.minecraft.zerodayisaminecraftcheat.BlockSapling;
import net.minecraft.zerodayisaminecraftcheat.BlockNewLog;
import net.minecraft.zerodayisaminecraftcheat.BlockOldLog;
import net.minecraft.zerodayisaminecraftcheat.BlockDropper;
import net.minecraft.zerodayisaminecraftcheat.BlockDispenser;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneBrick;
import net.minecraft.zerodayisaminecraftcheat.BlockSilverfish;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlabNew;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlab;
import net.minecraft.zerodayisaminecraftcheat.BlockBed;
import net.minecraft.zerodayisaminecraftcheat.BlockTallGrass;
import net.minecraft.zerodayisaminecraftcheat.BlockRedSandstone;
import net.minecraft.zerodayisaminecraftcheat.BlockSandStone;
import net.minecraft.zerodayisaminecraftcheat.BlockColored;
import net.minecraft.zerodayisaminecraftcheat.BlockDoor;
import net.minecraft.zerodayisaminecraftcheat.BlockRedstoneWire;
import net.minecraft.zerodayisaminecraftcheat.BlockFire;
import net.minecraft.zerodayisaminecraftcheat.BlockTNT;
import net.minecraft.zerodayisaminecraftcheat.BlockPlanks;
import net.minecraft.zerodayisaminecraftcheat.BlockTripWire;
import net.minecraft.zerodayisaminecraftcheat.BlockFenceGate;
import net.minecraft.zerodayisaminecraftcheat.BlockDoublePlant;
import net.minecraft.zerodayisaminecraftcheat.BlockWall;
import net.minecraft.zerodayisaminecraftcheat.BlockCommandBlock;
import net.minecraft.zerodayisaminecraftcheat.BlockJukebox;
import net.minecraft.zerodayisaminecraftcheat.BlockReed;
import net.minecraft.zerodayisaminecraftcheat.BlockCactus;
import net.minecraft.zerodayisaminecraftcheat.BlockNewLeaf;
import net.minecraft.zerodayisaminecraftcheat.BlockLeaves;
import net.minecraft.zerodayisaminecraftcheat.BlockOldLeaf;
import net.minecraft.zerodayisaminecraftcheat.BlockPrismarine;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockStone;
import net.minecraft.client.a.zerodayisaminecraftcheat.zeroday.StateMap;
import net.minecraft.client.a.zerodayisaminecraftcheat.zeroday.IStateMapper;
import java.util.Iterator;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.a.Blocks;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import com.google.common.collect.Maps;
import net.minecraft.client.b.zeroday.ModelManager;
import net.minecraft.client.a.zerodayisaminecraftcheat.zeroday.BlockStateMapper;
import net.minecraft.client.b.zeroday.IBakedModel;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import java.util.Map;

public class BlockModelShapes
{
    private final Map<IBlockState, IBakedModel> zerodayisaminecraftcheat;
    private final BlockStateMapper zeroday;
    private final ModelManager sigma;
    
    public BlockModelShapes(final ModelManager manager) {
        this.zerodayisaminecraftcheat = (Map<IBlockState, IBakedModel>)Maps.newIdentityHashMap();
        this.zeroday = new BlockStateMapper();
        this.sigma = manager;
        this.pandora();
    }
    
    public BlockStateMapper zerodayisaminecraftcheat() {
        return this.zeroday;
    }
    
    public TextureAtlasSprite zerodayisaminecraftcheat(final IBlockState state) {
        final Block block = state.sigma();
        IBakedModel ibakedmodel = this.zeroday(state);
        if (ibakedmodel == null || ibakedmodel == this.sigma.zerodayisaminecraftcheat()) {
            if (block == Blocks.ap || block == Blocks.af || block == Blocks.W || block == Blocks.bY || block == Blocks.cC || block == Blocks.cD) {
                return this.sigma.zeroday().zerodayisaminecraftcheat("minecraft:blocks/planks_oak");
            }
            if (block == Blocks.bI) {
                return this.sigma.zeroday().zerodayisaminecraftcheat("minecraft:blocks/obsidian");
            }
            if (block == Blocks.c || block == Blocks.d) {
                return this.sigma.zeroday().zerodayisaminecraftcheat("minecraft:blocks/lava_still");
            }
            if (block == Blocks.a || block == Blocks.b) {
                return this.sigma.zeroday().zerodayisaminecraftcheat("minecraft:blocks/water_still");
            }
            if (block == Blocks.bW) {
                return this.sigma.zeroday().zerodayisaminecraftcheat("minecraft:blocks/soul_sand");
            }
            if (block == Blocks.cn) {
                return this.sigma.zeroday().zerodayisaminecraftcheat("minecraft:items/barrier");
            }
        }
        if (ibakedmodel == null) {
            ibakedmodel = this.sigma.zerodayisaminecraftcheat();
        }
        return ibakedmodel.zues();
    }
    
    public IBakedModel zeroday(final IBlockState state) {
        IBakedModel ibakedmodel = this.zerodayisaminecraftcheat.get(state);
        if (ibakedmodel == null) {
            ibakedmodel = this.sigma.zerodayisaminecraftcheat();
        }
        return ibakedmodel;
    }
    
    public ModelManager zeroday() {
        return this.sigma;
    }
    
    public void sigma() {
        this.zerodayisaminecraftcheat.clear();
        for (final Map.Entry<IBlockState, ModelResourceLocation> entry : this.zeroday.zerodayisaminecraftcheat().entrySet()) {
            this.zerodayisaminecraftcheat.put(entry.getKey(), this.sigma.zerodayisaminecraftcheat(entry.getValue()));
        }
    }
    
    public void zerodayisaminecraftcheat(final Block assoc, final IStateMapper stateMapper) {
        this.zeroday.zerodayisaminecraftcheat(assoc, stateMapper);
    }
    
    public void zerodayisaminecraftcheat(final Block... builtIns) {
        this.zeroday.zerodayisaminecraftcheat(builtIns);
    }
    
    private void pandora() {
        this.zerodayisaminecraftcheat(Blocks.zerodayisaminecraftcheat, Blocks.a, Blocks.b, Blocks.c, Blocks.d, Blocks.E, Blocks.W, Blocks.bI, Blocks.bY, Blocks.af, Blocks.bW, Blocks.bx, Blocks.cn, Blocks.ap, Blocks.cD, Blocks.cC);
        this.zerodayisaminecraftcheat(Blocks.zeroday, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockStone.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cA, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockPrismarine.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.l, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockOldLeaf.J).zerodayisaminecraftcheat("_leaves").zerodayisaminecraftcheat(BlockLeaves.E, BlockLeaves.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.m, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockNewLeaf.J).zerodayisaminecraftcheat("_leaves").zerodayisaminecraftcheat(BlockLeaves.E, BlockLeaves.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.aC, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockCactus.D }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.aE, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockReed.D }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.aF, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockJukebox.D }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bP, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockCommandBlock.D }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bR, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockWall.I).zerodayisaminecraftcheat("_wall").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cx, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockDoublePlant.D).zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoublePlant.F }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bg, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFenceGate.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bh, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFenceGate.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bi, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFenceGate.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bj, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFenceGate.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bk, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFenceGate.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bl, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFenceGate.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bK, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockTripWire.G, BlockTripWire.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bD, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockPlanks.D).zerodayisaminecraftcheat("_double_slab").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bE, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockPlanks.D).zerodayisaminecraftcheat("_slab").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.O, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockTNT.D }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.T, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFire.D }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.X, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockRedstoneWire.H }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.ag, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoor.G }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.ah, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoor.G }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.ai, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoor.G }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.aj, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoor.G }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.ak, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoor.G }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.al, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoor.G }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.as, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDoor.G }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.D, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockColored.D).zerodayisaminecraftcheat("_wool").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cq, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockColored.D).zerodayisaminecraftcheat("_carpet").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cm, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockColored.D).zerodayisaminecraftcheat("_stained_hardened_clay").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cz, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockColored.D).zerodayisaminecraftcheat("_stained_glass_pane").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cy, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockColored.D).zerodayisaminecraftcheat("_stained_glass").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.s, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockSandStone.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cE, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockRedSandstone.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.z, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockTallGrass.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.u, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockBed.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.F, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(Blocks.F.K()).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.G, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(Blocks.G.K()).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.M, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockStoneSlab.F).zerodayisaminecraftcheat("_slab").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cH, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockStoneSlabNew.F).zerodayisaminecraftcheat("_slab").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.aW, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockSilverfish.D).zerodayisaminecraftcheat("_monster_egg").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.aX, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockStoneBrick.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.r, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDispenser.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.cl, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockDropper.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.j, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockOldLog.E).zerodayisaminecraftcheat("_log").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.k, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockNewLog.E).zerodayisaminecraftcheat("_log").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.flux, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockPlanks.D).zerodayisaminecraftcheat("_planks").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.vape, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockSapling.D).zerodayisaminecraftcheat("_sapling").zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.e, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat(BlockSand.D).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.ch, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockHopper.E }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.bS, new StateMap.zerodayisaminecraftcheat().zerodayisaminecraftcheat((IProperty<?>[])new IProperty[] { BlockFlowerPot.D }).zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat(Blocks.ci, new StateMapperBase() {
            private static /* synthetic */ int[] sigma;
            
            @Override
            protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
                final BlockQuartz.zerodayisaminecraftcheat blockquartz$enumtype = state.zerodayisaminecraftcheat(BlockQuartz.D);
                switch (zerodayisaminecraftcheat()[blockquartz$enumtype.ordinal()]) {
                    default: {
                        return new ModelResourceLocation("quartz_block", "normal");
                    }
                    case 2: {
                        return new ModelResourceLocation("chiseled_quartz_block", "normal");
                    }
                    case 3: {
                        return new ModelResourceLocation("quartz_column", "axis=y");
                    }
                    case 4: {
                        return new ModelResourceLocation("quartz_column", "axis=x");
                    }
                    case 5: {
                        return new ModelResourceLocation("quartz_column", "axis=z");
                    }
                }
            }
            
            static /* synthetic */ int[] zerodayisaminecraftcheat() {
                final int[] sigma = BlockModelShapes$1.sigma;
                if (sigma != null) {
                    return sigma;
                }
                final int[] sigma2 = new int[BlockQuartz.zerodayisaminecraftcheat.values().length];
                try {
                    sigma2[BlockQuartz.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    sigma2[BlockQuartz.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
                }
                catch (NoSuchFieldError noSuchFieldError2) {}
                try {
                    sigma2[BlockQuartz.zerodayisaminecraftcheat.pandora.ordinal()] = 4;
                }
                catch (NoSuchFieldError noSuchFieldError3) {}
                try {
                    sigma2[BlockQuartz.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
                }
                catch (NoSuchFieldError noSuchFieldError4) {}
                try {
                    sigma2[BlockQuartz.zerodayisaminecraftcheat.zues.ordinal()] = 5;
                }
                catch (NoSuchFieldError noSuchFieldError5) {}
                return BlockModelShapes$1.sigma = sigma2;
            }
        });
        this.zerodayisaminecraftcheat(Blocks.A, new StateMapperBase() {
            @Override
            protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
                return new ModelResourceLocation("dead_bush", "normal");
            }
        });
        this.zerodayisaminecraftcheat(Blocks.bd, new StateMapperBase() {
            @Override
            protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
                final Map<IProperty, Comparable> map = (Map<IProperty, Comparable>)Maps.newLinkedHashMap((Map)state.zeroday());
                if (state.zerodayisaminecraftcheat((IProperty<Comparable>)BlockStem.E) != EnumFacing.zeroday) {
                    map.remove(BlockStem.D);
                }
                return new ModelResourceLocation(Block.zerodayisaminecraftcheat.zeroday(state.sigma()), this.zerodayisaminecraftcheat(map));
            }
        });
        this.zerodayisaminecraftcheat(Blocks.be, new StateMapperBase() {
            @Override
            protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
                final Map<IProperty, Comparable> map = (Map<IProperty, Comparable>)Maps.newLinkedHashMap((Map)state.zeroday());
                if (state.zerodayisaminecraftcheat((IProperty<Comparable>)BlockStem.E) != EnumFacing.zeroday) {
                    map.remove(BlockStem.D);
                }
                return new ModelResourceLocation(Block.zerodayisaminecraftcheat.zeroday(state.sigma()), this.zerodayisaminecraftcheat(map));
            }
        });
        this.zerodayisaminecraftcheat(Blocks.pandora, new StateMapperBase() {
            @Override
            protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
                final Map<IProperty, Comparable> map = (Map<IProperty, Comparable>)Maps.newLinkedHashMap((Map)state.zeroday());
                final String s = BlockDirt.D.zerodayisaminecraftcheat(map.remove(BlockDirt.D));
                if (BlockDirt.zerodayisaminecraftcheat.sigma != state.zerodayisaminecraftcheat(BlockDirt.D)) {
                    map.remove(BlockDirt.E);
                }
                return new ModelResourceLocation(s, this.zerodayisaminecraftcheat(map));
            }
        });
        this.zerodayisaminecraftcheat(Blocks.L, new StateMapperBase() {
            @Override
            protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
                final Map<IProperty, Comparable> map = (Map<IProperty, Comparable>)Maps.newLinkedHashMap((Map)state.zeroday());
                final String s = BlockStoneSlab.F.zerodayisaminecraftcheat(map.remove(BlockStoneSlab.F));
                map.remove(BlockStoneSlab.E);
                final String s2 = state.zerodayisaminecraftcheat((IProperty<Boolean>)BlockStoneSlab.E) ? "all" : "normal";
                return new ModelResourceLocation(String.valueOf(s) + "_double_slab", s2);
            }
        });
        this.zerodayisaminecraftcheat(Blocks.cG, new StateMapperBase() {
            @Override
            protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
                final Map<IProperty, Comparable> map = (Map<IProperty, Comparable>)Maps.newLinkedHashMap((Map)state.zeroday());
                final String s = BlockStoneSlabNew.F.zerodayisaminecraftcheat(map.remove(BlockStoneSlabNew.F));
                map.remove(BlockStoneSlab.E);
                final String s2 = state.zerodayisaminecraftcheat((IProperty<Boolean>)BlockStoneSlabNew.E) ? "all" : "normal";
                return new ModelResourceLocation(String.valueOf(s) + "_double_slab", s2);
            }
        });
    }
}

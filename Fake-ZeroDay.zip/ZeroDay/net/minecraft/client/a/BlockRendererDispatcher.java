// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.client.b.IResourceManager;
import net.minecraft.q.WorldType;
import net.minecraft.o.Vec3i;
import net.minecraft.o.MathHelper;
import net.minecraft.client.b.zeroday.WeightedBakedModel;
import net.minecraft.o.ReportedException;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.sigma.CrashReport;
import sigma.zerodayisaminecraftcheat.b;
import net.minecraft.l.Config;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.client.b.zeroday.SimpleBakedModel;
import net.minecraft.client.b.zeroday.IBakedModel;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.l.Reflector;
import net.minecraft.q.IBlockAccess;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.client.c.GameSettings;
import net.minecraft.client.b.IResourceManagerReloadListener;

public class BlockRendererDispatcher implements IResourceManagerReloadListener
{
    private BlockModelShapes zerodayisaminecraftcheat;
    private final GameSettings zeroday;
    private final BlockModelRenderer sigma;
    private final ChestRenderer pandora;
    private final BlockFluidRenderer zues;
    private static final String flux = "CL_00002520";
    
    public BlockRendererDispatcher(final BlockModelShapes blockModelShapesIn, final GameSettings gameSettingsIn) {
        this.sigma = new BlockModelRenderer();
        this.pandora = new ChestRenderer();
        this.zues = new BlockFluidRenderer();
        this.zerodayisaminecraftcheat = blockModelShapesIn;
        this.zeroday = gameSettingsIn;
    }
    
    public BlockModelShapes zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
    
    public void zerodayisaminecraftcheat(IBlockState state, final BlockPos pos, final TextureAtlasSprite texture, final IBlockAccess blockAccess) {
        final Block block = state.sigma();
        final int i = block.c();
        if (i == 3) {
            state = block.zerodayisaminecraftcheat(state, blockAccess, pos);
            final IBakedModel ibakedmodel = this.zerodayisaminecraftcheat.zeroday(state);
            if (Reflector.bz.zerodayisaminecraftcheat(ibakedmodel)) {
                final IBlockState iblockstate = (IBlockState)Reflector.vape(block, Reflector.aY, state, blockAccess, pos);
                EnumWorldBlockLayer[] values;
                for (int length = (values = EnumWorldBlockLayer.values()).length, j = 0; j < length; ++j) {
                    final EnumWorldBlockLayer enumworldblocklayer = values[j];
                    if (Reflector.zeroday(block, Reflector.aX, enumworldblocklayer)) {
                        Reflector.zerodayisaminecraftcheat(Reflector.r, enumworldblocklayer);
                        final IBakedModel ibakedmodel2 = (IBakedModel)Reflector.vape(ibakedmodel, Reflector.bA, iblockstate);
                        final IBakedModel ibakedmodel3 = new SimpleBakedModel.zerodayisaminecraftcheat(ibakedmodel2, texture).zerodayisaminecraftcheat();
                        this.sigma.zerodayisaminecraftcheat(blockAccess, ibakedmodel3, state, pos, Tessellator.zerodayisaminecraftcheat().sigma());
                    }
                }
                return;
            }
            final IBakedModel ibakedmodel4 = new SimpleBakedModel.zerodayisaminecraftcheat(ibakedmodel, texture).zerodayisaminecraftcheat();
            this.sigma.zerodayisaminecraftcheat(blockAccess, ibakedmodel4, state, pos, Tessellator.zerodayisaminecraftcheat().sigma());
        }
    }
    
    public boolean zerodayisaminecraftcheat(final IBlockState state, final BlockPos pos, final IBlockAccess blockAccess, final WorldRenderer worldRendererIn) {
        try {
            final int i = state.sigma().c();
            if (i == -1) {
                return false;
            }
            switch (i) {
                case 1: {
                    if (Config.aC()) {
                        b.zerodayisaminecraftcheat(state, pos, blockAccess, worldRendererIn);
                    }
                    final boolean flag1 = this.zues.zerodayisaminecraftcheat(blockAccess, state, pos, worldRendererIn);
                    if (Config.aC()) {
                        b.zeroday(worldRendererIn);
                    }
                    return flag1;
                }
                case 2: {
                    return false;
                }
                case 3: {
                    final IBakedModel ibakedmodel = this.zerodayisaminecraftcheat(state, blockAccess, pos);
                    if (Config.aC()) {
                        b.zerodayisaminecraftcheat(state, pos, blockAccess, worldRendererIn);
                    }
                    final boolean flag2 = this.sigma.zerodayisaminecraftcheat(blockAccess, ibakedmodel, state, pos, worldRendererIn);
                    if (Config.aC()) {
                        b.zeroday(worldRendererIn);
                    }
                    return flag2;
                }
                default: {
                    return false;
                }
            }
        }
        catch (Throwable throwable) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Tesselating block in world");
            final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Block being tesselated");
            CrashReportCategory.zerodayisaminecraftcheat(crashreportcategory, pos, state.sigma(), state.sigma().sigma(state));
            throw new ReportedException(crashreport);
        }
    }
    
    public BlockModelRenderer zeroday() {
        return this.sigma;
    }
    
    private IBakedModel zerodayisaminecraftcheat(final IBlockState state, final BlockPos pos) {
        IBakedModel ibakedmodel = this.zerodayisaminecraftcheat.zeroday(state);
        if (pos != null && this.zeroday.n && ibakedmodel instanceof WeightedBakedModel) {
            ibakedmodel = ((WeightedBakedModel)ibakedmodel).zerodayisaminecraftcheat(MathHelper.zerodayisaminecraftcheat(pos));
        }
        return ibakedmodel;
    }
    
    public IBakedModel zerodayisaminecraftcheat(IBlockState state, final IBlockAccess worldIn, final BlockPos pos) {
        final Block block = state.sigma();
        if (worldIn.w_() != WorldType.vape) {
            try {
                state = block.zerodayisaminecraftcheat(state, worldIn, pos);
            }
            catch (Exception ex) {}
        }
        IBakedModel ibakedmodel = this.zerodayisaminecraftcheat.zeroday(state);
        if (pos != null && this.zeroday.n && ibakedmodel instanceof WeightedBakedModel) {
            ibakedmodel = ((WeightedBakedModel)ibakedmodel).zerodayisaminecraftcheat(MathHelper.zerodayisaminecraftcheat(pos));
        }
        if (Reflector.bz.zerodayisaminecraftcheat(ibakedmodel)) {
            final IBlockState iblockstate = (IBlockState)Reflector.vape(block, Reflector.aY, state, worldIn, pos);
            ibakedmodel = (IBakedModel)Reflector.vape(ibakedmodel, Reflector.bA, iblockstate);
        }
        return ibakedmodel;
    }
    
    public void zerodayisaminecraftcheat(final IBlockState state, final float brightness) {
        final int i = state.sigma().c();
        if (i != -1) {
            switch (i) {
                case 2: {
                    this.pandora.zerodayisaminecraftcheat(state.sigma(), brightness);
                    break;
                }
                case 3: {
                    final IBakedModel ibakedmodel = this.zerodayisaminecraftcheat(state, null);
                    this.sigma.zerodayisaminecraftcheat(ibakedmodel, state, brightness, true);
                    break;
                }
            }
        }
    }
    
    public boolean zerodayisaminecraftcheat(final Block p_175021_1_, final int p_175021_2_) {
        if (p_175021_1_ == null) {
            return false;
        }
        final int i = p_175021_1_.c();
        return i != 3 && i == 2;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        this.zues.zerodayisaminecraftcheat();
    }
}

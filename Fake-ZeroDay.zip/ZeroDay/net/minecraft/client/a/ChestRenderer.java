// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.c.ItemStack;
import net.minecraft.client.a.flux.TileEntityItemStackRenderer;
import net.minecraft.zerodayisaminecraftcheat.Block;

public class ChestRenderer
{
    public void zerodayisaminecraftcheat(final Block p_178175_1_, final float color) {
        GlStateManager.sigma(color, color, color, 1.0f);
        GlStateManager.zeroday(90.0f, 0.0f, 1.0f, 0.0f);
        TileEntityItemStackRenderer.zerodayisaminecraftcheat.zerodayisaminecraftcheat(new ItemStack(p_178175_1_));
    }
}

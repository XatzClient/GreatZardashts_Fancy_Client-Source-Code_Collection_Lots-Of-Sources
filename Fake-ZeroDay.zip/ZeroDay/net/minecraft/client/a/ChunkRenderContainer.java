// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.o.BlockPos;
import com.google.common.collect.Lists;
import net.minecraft.client.a.zeroday.RenderChunk;
import java.util.List;

public abstract class ChunkRenderContainer
{
    private double sigma;
    private double pandora;
    private double zues;
    protected List<RenderChunk> zerodayisaminecraftcheat;
    protected boolean zeroday;
    
    public ChunkRenderContainer() {
        this.zerodayisaminecraftcheat = (List<RenderChunk>)Lists.newArrayListWithCapacity(17424);
    }
    
    public void zerodayisaminecraftcheat(final double viewEntityXIn, final double viewEntityYIn, final double viewEntityZIn) {
        this.zeroday = true;
        this.zerodayisaminecraftcheat.clear();
        this.sigma = viewEntityXIn;
        this.pandora = viewEntityYIn;
        this.zues = viewEntityZIn;
    }
    
    public void zerodayisaminecraftcheat(final RenderChunk renderChunkIn) {
        final BlockPos blockpos = renderChunkIn.a();
        GlStateManager.zeroday((float)(blockpos.zerodayisaminecraftcheat() - this.sigma), (float)(blockpos.zeroday() - this.pandora), (float)(blockpos.sigma() - this.zues));
    }
    
    public void zerodayisaminecraftcheat(final RenderChunk renderChunkIn, final EnumWorldBlockLayer layer) {
        this.zerodayisaminecraftcheat.add(renderChunkIn);
    }
    
    public abstract void zerodayisaminecraftcheat(final EnumWorldBlockLayer p0);
}

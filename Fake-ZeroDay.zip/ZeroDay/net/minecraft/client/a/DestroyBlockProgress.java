// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.o.BlockPos;

public class DestroyBlockProgress
{
    private final int zerodayisaminecraftcheat;
    private final BlockPos zeroday;
    private int sigma;
    private int pandora;
    
    public DestroyBlockProgress(final int miningPlayerEntIdIn, final BlockPos positionIn) {
        this.zerodayisaminecraftcheat = miningPlayerEntIdIn;
        this.zeroday = positionIn;
    }
    
    public BlockPos zerodayisaminecraftcheat() {
        return this.zeroday;
    }
    
    public void zerodayisaminecraftcheat(int damage) {
        if (damage > 10) {
            damage = 10;
        }
        this.sigma = damage;
    }
    
    public int zeroday() {
        return this.sigma;
    }
    
    public void zeroday(final int createdAtCloudUpdateTickIn) {
        this.pandora = createdAtCloudUpdateTickIn;
    }
    
    public int sigma() {
        return this.pandora;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.Calendar;
import org.lwjgl.util.glu.GLU;
import net.minecraft.l.RandomMobs;
import net.minecraft.client.sigma.GuiMainMenu;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.ChatComponentText;
import net.minecraft.l.TextureUtils;
import net.minecraft.k.zerodayisaminecraftcheat.IntegratedServer;
import net.minecraft.client.sigma.GuiDownloadTerrain;
import org.lwjgl.opengl.GLContext;
import net.minecraft.flux.EnchantmentHelper;
import net.minecraft.q.WorldProvider;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.q.zerodayisaminecraftcheat.BiomeGenBase;
import net.minecraft.q.IBlockAccess;
import net.minecraft.o.EnumParticleTypes;
import net.minecraft.client.vape.EffectRenderer;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.B;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.pandora;
import zeroday.zeroday.zerodayisaminecraftcheat.zeroday;
import zeroday.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat.A;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.client.a.sigma.ICamera;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.sigma.Frustum;
import net.minecraft.client.a.sigma.ClippingHelperImpl;
import net.minecraft.c.ItemStack;
import net.minecraft.b.IInventory;
import net.minecraft.q.WorldSettings;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.o.ReportedException;
import java.util.concurrent.Callable;
import net.minecraft.sigma.CrashReport;
import net.minecraft.l.Lagometer;
import zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat;
import net.minecraft.client.sigma.ScaledResolution;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import net.minecraft.client.zues.WorldClient;
import net.minecraft.l.CustomColorizer;
import org.lwjgl.opengl.GL11;
import sigma.zerodayisaminecraftcheat.k;
import sigma.zerodayisaminecraftcheat.j;
import net.minecraft.g.Potion;
import zeroday.pandora.zerodayisaminecraftcheat.d.bj;
import org.lwjgl.util.glu.Project;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.vape.flux.EntityAnimal;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockBed;
import net.minecraft.a.Blocks;
import zeroday.pandora.zerodayisaminecraftcheat.d.S;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.l.Config;
import net.minecraft.client.c.GameSettings;
import net.minecraft.client.zeroday.AbstractClientPlayer;
import net.minecraft.o.AxisAlignedBB;
import java.util.List;
import net.minecraft.o.Vec3;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.l.Reflector;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import net.minecraft.o.EntitySelectors;
import net.minecraft.vape.zeroday.BossStatus;
import net.minecraft.o.BlockPos;
import net.minecraft.client.d.ShaderLinkHelper;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.zues.EntityEnderman;
import net.minecraft.vape.zues.EntitySpider;
import net.minecraft.vape.zues.EntityCreeper;
import net.minecraft.o.MathHelper;
import org.apache.logging.log4j.LogManager;
import net.minecraft.q.World;
import net.minecraft.client.d.ShaderGroup;
import java.nio.FloatBuffer;
import net.minecraft.client.a.zues.DynamicTexture;
import net.minecraft.o.MouseFilter;
import net.minecraft.vape.Entity;
import net.minecraft.client.sigma.MapItemRenderer;
import java.util.Random;
import net.minecraft.client.b.IResourceManager;
import net.minecraft.client.Minecraft;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;
import net.minecraft.client.b.IResourceManagerReloadListener;

public class EntityRenderer implements IResourceManagerReloadListener
{
    private static final Logger e;
    private static final ResourceLocation f;
    private static final ResourceLocation g;
    public static boolean zerodayisaminecraftcheat;
    public static int zeroday;
    private Minecraft h;
    private final IResourceManager i;
    private Random j;
    private float k;
    public ItemRenderer sigma;
    private final MapItemRenderer l;
    private int m;
    private Entity n;
    private MouseFilter o;
    private MouseFilter p;
    private float q;
    private float r;
    private float s;
    private float t;
    private float u;
    private float v;
    private float w;
    private float x;
    private float y;
    private float z;
    private float A;
    private boolean B;
    private boolean C;
    private boolean D;
    private long E;
    private long F;
    private final DynamicTexture G;
    private final int[] H;
    private final ResourceLocation I;
    private boolean J;
    private float K;
    private float L;
    private int M;
    private float[] N;
    private float[] O;
    private FloatBuffer P;
    public float pandora;
    public float zues;
    public float flux;
    private float Q;
    private float R;
    private int S;
    private boolean T;
    private double U;
    private double V;
    private double W;
    public ShaderGroup vape;
    public static final ResourceLocation[] momgetthecamera;
    public static final int a;
    public int b;
    private boolean X;
    public int c;
    private static final String Y = "CL_00000947";
    private boolean Z;
    private World aa;
    private boolean ab;
    public boolean d;
    private float ac;
    private long ad;
    private int ae;
    private int af;
    private int ag;
    private float ah;
    private float ai;
    private long aj;
    private ShaderGroup[] ak;
    
    static {
        e = LogManager.getLogger();
        f = new ResourceLocation("textures/environment/rain.png");
        g = new ResourceLocation("textures/environment/snow.png");
        momgetthecamera = new ResourceLocation[] { new ResourceLocation("shaders/post/notch.json"), new ResourceLocation("shaders/post/fxaa.json"), new ResourceLocation("shaders/post/art.json"), new ResourceLocation("shaders/post/bumpy.json"), new ResourceLocation("shaders/post/blobs2.json"), new ResourceLocation("shaders/post/pencil.json"), new ResourceLocation("shaders/post/color_convolve.json"), new ResourceLocation("shaders/post/deconverge.json"), new ResourceLocation("shaders/post/flip.json"), new ResourceLocation("shaders/post/invert.json"), new ResourceLocation("shaders/post/ntsc.json"), new ResourceLocation("shaders/post/outline.json"), new ResourceLocation("shaders/post/phosphor.json"), new ResourceLocation("shaders/post/scan_pincushion.json"), new ResourceLocation("shaders/post/sobel.json"), new ResourceLocation("shaders/post/bits.json"), new ResourceLocation("shaders/post/desaturate.json"), new ResourceLocation("shaders/post/green.json"), new ResourceLocation("shaders/post/blur.json"), new ResourceLocation("shaders/post/wobble.json"), new ResourceLocation("shaders/post/blobs.json"), new ResourceLocation("shaders/post/antialias.json"), new ResourceLocation("shaders/post/creeper.json"), new ResourceLocation("shaders/post/spider.json") };
        a = EntityRenderer.momgetthecamera.length;
    }
    
    public EntityRenderer(final Minecraft mcIn, final IResourceManager resourceManagerIn) {
        this.j = new Random();
        this.o = new MouseFilter();
        this.p = new MouseFilter();
        this.q = 4.0f;
        this.r = 4.0f;
        this.C = true;
        this.D = true;
        this.E = Minecraft.C();
        this.N = new float[1024];
        this.O = new float[1024];
        this.P = GLAllocation.zues(16);
        this.S = 0;
        this.T = false;
        this.U = 1.0;
        this.Z = false;
        this.aa = null;
        this.ab = false;
        this.d = false;
        this.ac = 128.0f;
        this.ad = 0L;
        this.ae = 0;
        this.af = 0;
        this.ag = 0;
        this.ah = 0.0f;
        this.ai = 0.0f;
        this.aj = 0L;
        this.ak = new ShaderGroup[10];
        this.b = EntityRenderer.a;
        this.X = false;
        this.c = 0;
        this.h = mcIn;
        this.i = resourceManagerIn;
        this.sigma = mcIn.aa();
        this.l = new MapItemRenderer(mcIn.I());
        this.G = new DynamicTexture(16, 16);
        this.I = mcIn.I().zerodayisaminecraftcheat("lightMap", this.G);
        this.H = this.G.sigma();
        this.vape = null;
        for (int i = 0; i < 32; ++i) {
            for (int j = 0; j < 32; ++j) {
                final float f = (float)(j - 16);
                final float f2 = (float)(i - 16);
                final float f3 = MathHelper.sigma(f * f + f2 * f2);
                this.N[i << 5 | j] = -f2 / f3;
                this.O[i << 5 | j] = f / f3;
            }
        }
    }
    
    public boolean zerodayisaminecraftcheat() {
        return OpenGlHelper.G && this.vape != null;
    }
    
    public void zeroday() {
        if (this.vape != null) {
            this.vape.zerodayisaminecraftcheat();
        }
        this.vape = null;
        this.b = EntityRenderer.a;
    }
    
    public void sigma() {
        this.X = !this.X;
    }
    
    public void zerodayisaminecraftcheat(final Entity entityIn) {
        if (OpenGlHelper.G) {
            if (this.vape != null) {
                this.vape.zerodayisaminecraftcheat();
            }
            this.vape = null;
            if (entityIn instanceof EntityCreeper) {
                this.zerodayisaminecraftcheat(new ResourceLocation("shaders/post/creeper.json"));
            }
            else if (entityIn instanceof EntitySpider) {
                this.zerodayisaminecraftcheat(new ResourceLocation("shaders/post/spider.json"));
            }
            else if (entityIn instanceof EntityEnderman) {
                this.zerodayisaminecraftcheat(new ResourceLocation("shaders/post/invert.json"));
            }
        }
    }
    
    public void pandora() {
        if (OpenGlHelper.G && this.h.V() instanceof EntityPlayer) {
            if (this.vape != null) {
                this.vape.zerodayisaminecraftcheat();
            }
            this.b = (this.b + 1) % (EntityRenderer.momgetthecamera.length + 1);
            if (this.b != EntityRenderer.a) {
                this.zerodayisaminecraftcheat(EntityRenderer.momgetthecamera[this.b]);
            }
            else {
                this.vape = null;
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final ResourceLocation resourceLocationIn) {
        if (OpenGlHelper.a()) {
            try {
                (this.vape = new ShaderGroup(this.h.I(), this.i, this.h.sigma(), resourceLocationIn)).zerodayisaminecraftcheat(this.h.flux, this.h.vape);
                this.X = true;
            }
            catch (IOException ioexception) {
                EntityRenderer.e.warn("Failed to load shader: " + resourceLocationIn, (Throwable)ioexception);
                this.b = EntityRenderer.a;
                this.X = false;
            }
            catch (JsonSyntaxException jsonsyntaxexception) {
                EntityRenderer.e.warn("Failed to load shader: " + resourceLocationIn, (Throwable)jsonsyntaxexception);
                this.b = EntityRenderer.a;
                this.X = false;
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        if (this.vape != null) {
            this.vape.zerodayisaminecraftcheat();
        }
        this.vape = null;
        if (this.b != EntityRenderer.a) {
            this.zerodayisaminecraftcheat(EntityRenderer.momgetthecamera[this.b]);
        }
        else {
            this.zerodayisaminecraftcheat(this.h.V());
        }
    }
    
    public void zues() {
        if (OpenGlHelper.G && ShaderLinkHelper.zeroday() == null) {
            ShaderLinkHelper.zerodayisaminecraftcheat();
        }
        this.c();
        this.d();
        this.Q = this.R;
        this.r = this.q;
        if (this.h.r.ax) {
            final float f = this.h.r.zerodayisaminecraftcheat * 0.6f + 0.2f;
            final float f2 = f * f * f * 8.0f;
            this.u = this.o.zerodayisaminecraftcheat(this.s, 0.05f * f2);
            this.v = this.p.zerodayisaminecraftcheat(this.t, 0.05f * f2);
            this.w = 0.0f;
            this.s = 0.0f;
            this.t = 0.0f;
        }
        else {
            this.u = 0.0f;
            this.v = 0.0f;
            this.o.zerodayisaminecraftcheat();
            this.p.zerodayisaminecraftcheat();
        }
        if (this.h.V() == null) {
            this.h.zerodayisaminecraftcheat(this.h.e);
        }
        final float f3 = this.h.a.h(new BlockPos(this.h.V()));
        final float f4 = this.h.r.sigma / 32.0f;
        final float f5 = f3 * (1.0f - f4) + f4;
        this.R += (f5 - this.R) * 0.1f;
        ++this.m;
        this.sigma.zerodayisaminecraftcheat();
        this.f();
        this.A = this.z;
        if (BossStatus.pandora) {
            this.z += 0.05f;
            if (this.z > 1.0f) {
                this.z = 1.0f;
            }
            BossStatus.pandora = false;
        }
        else if (this.z > 0.0f) {
            this.z -= 0.0125f;
        }
    }
    
    public ShaderGroup flux() {
        return this.vape;
    }
    
    public void zerodayisaminecraftcheat(final int width, final int height) {
        if (OpenGlHelper.G) {
            if (this.vape != null) {
                this.vape.zerodayisaminecraftcheat(width, height);
            }
            this.h.b.zerodayisaminecraftcheat(width, height);
        }
    }
    
    public void zerodayisaminecraftcheat(final float partialTicks) {
        final Entity entity = this.h.V();
        if (entity != null && this.h.a != null) {
            this.h.z.zerodayisaminecraftcheat("pick");
            this.h.f = null;
            double d0 = this.h.zues.pandora();
            this.h.q = entity.zerodayisaminecraftcheat(d0, partialTicks);
            double d2 = d0;
            final Vec3 vec3 = entity.vape(partialTicks);
            boolean flag = false;
            final boolean flag2 = true;
            if (this.h.zues.b()) {
                d0 = 6.0;
                d2 = 6.0;
            }
            else {
                if (d0 > 3.0) {
                    flag = true;
                }
                d0 = d0;
            }
            if (this.h.q != null) {
                d2 = this.h.q.sigma.flux(vec3);
            }
            final Vec3 vec4 = entity.flux(partialTicks);
            final Vec3 vec5 = vec3.zeroday(vec4.zerodayisaminecraftcheat * d0, vec4.zeroday * d0, vec4.sigma * d0);
            this.n = null;
            Vec3 vec6 = null;
            final float f = 1.0f;
            final List list = this.h.a.zerodayisaminecraftcheat(entity, entity.aH().zerodayisaminecraftcheat(vec4.zerodayisaminecraftcheat * d0, vec4.zeroday * d0, vec4.sigma * d0).zeroday(f, f, f), (Predicate<? super Entity>)Predicates.and((Predicate)EntitySelectors.pandora, (Predicate)new EntityRenderer1(this)));
            double d3 = d2;
            for (int i = 0; i < list.size(); ++i) {
                final Entity entity2 = list.get(i);
                final float f2 = entity2.ah();
                final AxisAlignedBB axisalignedbb = entity2.aH().zeroday(f2, f2, f2);
                final MovingObjectPosition movingobjectposition = axisalignedbb.zerodayisaminecraftcheat(vec3, vec5);
                if (axisalignedbb.zerodayisaminecraftcheat(vec3)) {
                    if (d3 >= 0.0) {
                        this.n = entity2;
                        vec6 = ((movingobjectposition == null) ? vec3 : movingobjectposition.sigma);
                        d3 = 0.0;
                    }
                }
                else if (movingobjectposition != null) {
                    final double d4 = vec3.flux(movingobjectposition.sigma);
                    if (d4 < d3 || d3 == 0.0) {
                        boolean flag3 = false;
                        if (Reflector.bd.zeroday()) {
                            flag3 = Reflector.zeroday(entity2, Reflector.bd, new Object[0]);
                        }
                        if (entity2 == entity.m && !flag3) {
                            if (d3 == 0.0) {
                                this.n = entity2;
                                vec6 = movingobjectposition.sigma;
                            }
                        }
                        else {
                            this.n = entity2;
                            vec6 = movingobjectposition.sigma;
                            d3 = d4;
                        }
                    }
                }
            }
            if (this.n != null && flag && vec3.flux(vec6) > 3.0) {
                this.n = null;
                this.h.q = new MovingObjectPosition(MovingObjectPosition.zerodayisaminecraftcheat.zerodayisaminecraftcheat, vec6, null, new BlockPos(vec6));
            }
            if (this.n != null && (d3 < d2 || this.h.q == null)) {
                this.h.q = new MovingObjectPosition(this.n, vec6);
                if (this.n instanceof EntityLivingBase || this.n instanceof EntityItemFrame) {
                    this.h.f = this.n;
                }
            }
            this.h.z.zeroday();
        }
    }
    
    private void c() {
        float f = 1.0f;
        if (this.h.V() instanceof AbstractClientPlayer) {
            final AbstractClientPlayer abstractclientplayer = (AbstractClientPlayer)this.h.V();
            f = abstractclientplayer.k_();
        }
        this.y = this.x;
        this.x += (f - this.x) * 0.5f;
        if (this.x > 1.5f) {
            this.x = 1.5f;
        }
        if (this.x < 0.1f) {
            this.x = 0.1f;
        }
    }
    
    private float zerodayisaminecraftcheat(final float partialTicks, final boolean p_78481_2_) {
        if (this.T) {
            return 90.0f;
        }
        final Entity entity = this.h.V();
        float f = 70.0f;
        if (p_78481_2_) {
            f = this.h.r.az;
            f *= this.y + (this.x - this.y) * partialTicks;
        }
        boolean flag = false;
        if (this.h.k == null) {
            final GameSettings gamesettings = this.h.r;
            flag = GameSettings.zerodayisaminecraftcheat(this.h.r.cb);
        }
        if (flag) {
            if (!Config.c) {
                Config.c = true;
                this.h.r.ax = true;
            }
            if (Config.c) {
                f /= 4.0f;
            }
        }
        else if (Config.c) {
            Config.c = false;
            this.h.r.ax = false;
            this.o = new MouseFilter();
            this.p = new MouseFilter();
            this.h.b.pandora = true;
        }
        if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).by() <= 0.0f) {
            final float f2 = ((EntityLivingBase)entity).aA + partialTicks;
            f /= (1.0f - 500.0f / (f2 + 500.0f)) * 2.0f + 1.0f;
        }
        final Block block = ActiveRenderInfo.zerodayisaminecraftcheat(this.h.a, entity, partialTicks);
        if (block.flux() == Material.momgetthecamera) {
            f = f * 60.0f / 70.0f;
        }
        return f;
    }
    
    private void pandora(final float partialTicks) {
        if (this.h.V() instanceof EntityLivingBase) {
            final EntityLivingBase entitylivingbase = (EntityLivingBase)this.h.V();
            float f = entitylivingbase.ax - partialTicks;
            if (entitylivingbase.by() <= 0.0f) {
                final float f2 = entitylivingbase.aA + partialTicks;
                GlStateManager.zeroday(40.0f - 8000.0f / (f2 + 200.0f), 0.0f, 0.0f, 1.0f);
            }
            if (f < 0.0f) {
                return;
            }
            f /= entitylivingbase.ay;
            f = MathHelper.zerodayisaminecraftcheat(f * f * f * f * 3.1415927f);
            final float f3 = entitylivingbase.az;
            GlStateManager.zeroday(-f3, 0.0f, 1.0f, 0.0f);
            if (zeroday.pandora.zerodayisaminecraftcheat.d.S.c) {
                GlStateManager.zeroday(-f * 0.0f, 0.0f, 0.0f, 1.0f);
                GlStateManager.zeroday(f3, 0.0f, 1.0f, 0.0f);
            }
            else {
                GlStateManager.zeroday(-f * 14.0f, 0.0f, 0.0f, 1.0f);
                GlStateManager.zeroday(f3, 0.0f, 1.0f, 0.0f);
            }
        }
    }
    
    private void zues(final float partialTicks) {
        if (this.h.V() instanceof EntityPlayer) {
            final EntityPlayer entityplayer = (EntityPlayer)this.h.V();
            final float f = entityplayer.N - entityplayer.M;
            final float f2 = -(entityplayer.N + f * partialTicks);
            final float f3 = entityplayer.bl + (entityplayer.bm - entityplayer.bl) * partialTicks;
            final float f4 = entityplayer.aH + (entityplayer.aI - entityplayer.aH) * partialTicks;
            GlStateManager.zeroday(MathHelper.zerodayisaminecraftcheat(f2 * 3.1415927f) * f3 * 0.5f, -Math.abs(MathHelper.zeroday(f2 * 3.1415927f) * f3), 0.0f);
            GlStateManager.zeroday(MathHelper.zerodayisaminecraftcheat(f2 * 3.1415927f) * f3 * 3.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.zeroday(Math.abs(MathHelper.zeroday(f2 * 3.1415927f - 0.2f) * f3) * 5.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(f4, 1.0f, 0.0f, 0.0f);
        }
    }
    
    private void flux(final float partialTicks) {
        final Entity entity = this.h.V();
        float f = entity.aI();
        double d0 = entity.p + (entity.s - entity.p) * partialTicks;
        double d2 = entity.q + (entity.t - entity.q) * partialTicks + f;
        double d3 = entity.r + (entity.u - entity.r) * partialTicks;
        if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).bS()) {
            ++f;
            GlStateManager.zeroday(0.0f, 0.3f, 0.0f);
            if (!this.h.r.ay) {
                final BlockPos blockpos = new BlockPos(entity);
                final IBlockState iblockstate = this.h.a.zeroday(blockpos);
                final Block block = iblockstate.sigma();
                if (Reflector.i.zeroday()) {
                    Reflector.zerodayisaminecraftcheat(Reflector.i, this.h.a, blockpos, iblockstate, entity);
                }
                else if (block == Blocks.u) {
                    final int j = iblockstate.zerodayisaminecraftcheat((IProperty<EnumFacing>)BlockBed.F).sigma();
                    GlStateManager.zeroday((float)(j * 90), 0.0f, 1.0f, 0.0f);
                }
                GlStateManager.zeroday(entity.A + (entity.y - entity.A) * partialTicks + 180.0f, 0.0f, -1.0f, 0.0f);
                GlStateManager.zeroday(entity.B + (entity.z - entity.B) * partialTicks, -1.0f, 0.0f, 0.0f);
            }
        }
        else if (this.h.r.as > 0) {
            double d4 = this.r + (this.q - this.r) * partialTicks;
            if (this.h.r.ay) {
                GlStateManager.zeroday(0.0f, 0.0f, (float)(-d4));
            }
            else {
                final float f2 = entity.y;
                float f3 = entity.z;
                if (this.h.r.as == 2) {
                    f3 += 180.0f;
                }
                final double d5 = -MathHelper.zerodayisaminecraftcheat(f2 / 180.0f * 3.1415927f) * MathHelper.zeroday(f3 / 180.0f * 3.1415927f) * d4;
                final double d6 = MathHelper.zeroday(f2 / 180.0f * 3.1415927f) * MathHelper.zeroday(f3 / 180.0f * 3.1415927f) * d4;
                final double d7 = -MathHelper.zerodayisaminecraftcheat(f3 / 180.0f * 3.1415927f) * d4;
                for (int i = 0; i < 8; ++i) {
                    float f4 = (float)((i & 0x1) * 2 - 1);
                    float f5 = (float)((i >> 1 & 0x1) * 2 - 1);
                    float f6 = (float)((i >> 2 & 0x1) * 2 - 1);
                    f4 *= 0.1f;
                    f5 *= 0.1f;
                    f6 *= 0.1f;
                    final MovingObjectPosition movingobjectposition = this.h.a.zerodayisaminecraftcheat(new Vec3(d0 + f4, d2 + f5, d3 + f6), new Vec3(d0 - d5 + f4 + f6, d2 - d7 + f5, d3 - d6 + f6));
                    if (movingobjectposition != null) {
                        final double d8 = movingobjectposition.sigma.flux(new Vec3(d0, d2, d3));
                        if (d8 < d4) {
                            d4 = d8;
                        }
                    }
                }
                if (this.h.r.as == 2) {
                    GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
                }
                GlStateManager.zeroday(entity.z - f3, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(entity.y - f2, 0.0f, 1.0f, 0.0f);
                GlStateManager.zeroday(0.0f, 0.0f, (float)(-d4));
                GlStateManager.zeroday(f2 - entity.y, 0.0f, 1.0f, 0.0f);
                GlStateManager.zeroday(f3 - entity.z, 1.0f, 0.0f, 0.0f);
            }
        }
        else {
            GlStateManager.zeroday(0.0f, 0.0f, -0.1f);
        }
        if (!this.h.r.ay) {
            GlStateManager.zeroday(entity.B + (entity.z - entity.B) * partialTicks, 1.0f, 0.0f, 0.0f);
            if (entity instanceof EntityAnimal) {
                final EntityAnimal entityanimal = (EntityAnimal)entity;
                GlStateManager.zeroday(entityanimal.aO + (entityanimal.aN - entityanimal.aO) * partialTicks + 180.0f, 0.0f, 1.0f, 0.0f);
            }
            else {
                GlStateManager.zeroday(entity.A + (entity.y - entity.A) * partialTicks + 180.0f, 0.0f, 1.0f, 0.0f);
            }
        }
        GlStateManager.zeroday(0.0f, -f, 0.0f);
        d0 = entity.p + (entity.s - entity.p) * partialTicks;
        d2 = entity.q + (entity.t - entity.q) * partialTicks + f;
        d3 = entity.r + (entity.u - entity.r) * partialTicks;
        this.B = this.h.b.zerodayisaminecraftcheat(d0, d2, d3, partialTicks);
    }
    
    public void zerodayisaminecraftcheat(final float partialTicks, final int pass) {
        this.k = (float)(this.h.r.sigma * 16);
        if (Config.g()) {
            this.k *= 0.95f;
        }
        if (Config.h()) {
            this.k *= 0.83f;
        }
        GlStateManager.d(5889);
        GlStateManager.u();
        final float f = 0.07f;
        if (this.h.r.zues) {
            GlStateManager.zeroday(-(pass * 2 - 1) * f, 0.0f, 0.0f);
        }
        this.ac = this.k * 2.0f;
        if (this.ac < 173.0f) {
            this.ac = 173.0f;
        }
        if (this.h.a.h.i() == 1) {
            this.ac = 256.0f;
        }
        if (this.U != 1.0) {
            GlStateManager.zeroday((float)this.V, (float)(-this.W), 0.0f);
            GlStateManager.zerodayisaminecraftcheat(this.U, this.U, 1.0);
        }
        Project.gluPerspective(this.zerodayisaminecraftcheat(partialTicks, true), this.h.flux / (float)this.h.vape, 0.05f, this.ac);
        GlStateManager.d(5888);
        GlStateManager.u();
        if (this.h.r.zues) {
            GlStateManager.zeroday((pass * 2 - 1) * 0.1f, 0.0f, 0.0f);
        }
        this.pandora(partialTicks);
        if (this.h.r.pandora && this.h.r.pandora && !bj.c) {
            this.zues(partialTicks);
        }
        final float f2 = this.h.e.c + (this.h.e.b - this.h.e.c) * partialTicks;
        if (f2 > 0.0f) {
            byte b0 = 20;
            if (this.h.e.zerodayisaminecraftcheat(Potion.c)) {
                b0 = 7;
            }
            float f3 = 5.0f / (f2 * f2 + 5.0f) - f2 * 0.04f;
            f3 *= f3;
            GlStateManager.zeroday((this.m + partialTicks) * b0, 0.0f, 1.0f, 1.0f);
            GlStateManager.zerodayisaminecraftcheat(1.0f / f3, 1.0f, 1.0f);
            GlStateManager.zeroday(-(this.m + partialTicks) * b0, 0.0f, 1.0f, 1.0f);
        }
        this.flux(partialTicks);
        if (this.T) {
            switch (this.S) {
                case 0: {
                    GlStateManager.zeroday(90.0f, 0.0f, 1.0f, 0.0f);
                    break;
                }
                case 1: {
                    GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
                    break;
                }
                case 2: {
                    GlStateManager.zeroday(-90.0f, 0.0f, 1.0f, 0.0f);
                    break;
                }
                case 3: {
                    GlStateManager.zeroday(90.0f, 1.0f, 0.0f, 0.0f);
                    break;
                }
                case 4: {
                    GlStateManager.zeroday(-90.0f, 1.0f, 0.0f, 0.0f);
                    break;
                }
            }
        }
    }
    
    public void zeroday(final float partialTicks, final int xOffset) {
        if (!this.T) {
            GlStateManager.d(5889);
            GlStateManager.u();
            final float f = 0.07f;
            if (this.h.r.zues) {
                GlStateManager.zeroday(-(xOffset * 2 - 1) * f, 0.0f, 0.0f);
            }
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.P();
            }
            Project.gluPerspective(this.zerodayisaminecraftcheat(partialTicks, false), this.h.flux / (float)this.h.vape, 0.05f, this.k * 2.0f);
            GlStateManager.d(5888);
            GlStateManager.u();
            if (this.h.r.zues) {
                GlStateManager.zeroday((xOffset * 2 - 1) * 0.1f, 0.0f, 0.0f);
            }
            boolean flag = false;
            if (!Config.aC() || !sigma.zerodayisaminecraftcheat.j.m) {
                GlStateManager.v();
                this.pandora(partialTicks);
                if (this.h.r.pandora) {
                    this.zues(partialTicks);
                }
                flag = (this.h.V() instanceof EntityLivingBase && ((EntityLivingBase)this.h.V()).bS());
                if (this.h.r.as == 0 && !flag && !this.h.r.ar && !this.h.zues.zerodayisaminecraftcheat()) {
                    this.momgetthecamera();
                    if (Config.aC()) {
                        sigma.zerodayisaminecraftcheat.k.zerodayisaminecraftcheat(this.sigma, partialTicks);
                    }
                    else {
                        this.sigma.zerodayisaminecraftcheat(partialTicks);
                    }
                    this.vape();
                }
                GlStateManager.w();
            }
            if (Config.aC() && !sigma.zerodayisaminecraftcheat.j.i) {
                return;
            }
            this.vape();
            if (this.h.r.as == 0 && !flag) {
                this.sigma.zeroday(partialTicks);
                this.pandora(partialTicks);
            }
            if (this.h.r.pandora) {
                this.zues(partialTicks);
            }
        }
    }
    
    public void vape() {
        GlStateManager.vape(OpenGlHelper.j);
        GlStateManager.n();
        GlStateManager.vape(OpenGlHelper.i);
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.j.Z();
        }
    }
    
    public void momgetthecamera() {
        GlStateManager.vape(OpenGlHelper.j);
        GlStateManager.d(5890);
        GlStateManager.u();
        final float f = 0.00390625f;
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        GlStateManager.zeroday(8.0f, 8.0f, 8.0f);
        GlStateManager.d(5888);
        this.h.I().zerodayisaminecraftcheat(this.I);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexParameteri(3553, 10242, 10496);
        GL11.glTexParameteri(3553, 10243, 10496);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.m();
        GlStateManager.vape(OpenGlHelper.i);
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.j.Y();
        }
    }
    
    private void d() {
        this.L += (float)((Math.random() - Math.random()) * Math.random() * Math.random());
        this.L *= (float)0.9;
        this.K += (this.L - this.K) * 1.0f;
        this.J = true;
    }
    
    private void vape(final float partialTicks) {
        if (this.J) {
            this.h.z.zerodayisaminecraftcheat("lightTex");
            final WorldClient worldclient = this.h.a;
            if (worldclient != null) {
                if (CustomColorizer.zerodayisaminecraftcheat(worldclient, this.K, this.H, this.h.e.zerodayisaminecraftcheat(Potion.j))) {
                    this.G.zeroday();
                    this.J = false;
                    this.h.z.zeroday();
                    return;
                }
                final float f = worldclient.zeroday(1.0f);
                final float f2 = f * 0.95f + 0.05f;
                for (int i = 0; i < 256; ++i) {
                    float f3 = worldclient.h.h()[i / 16] * f2;
                    final float f4 = worldclient.h.h()[i % 16] * (this.K * 0.1f + 1.5f);
                    if (worldclient.H() > 0) {
                        f3 = worldclient.h.h()[i / 16];
                    }
                    final float f5 = f3 * (f * 0.65f + 0.35f);
                    final float f6 = f3 * (f * 0.65f + 0.35f);
                    final float f7 = f4 * ((f4 * 0.6f + 0.4f) * 0.6f + 0.4f);
                    final float f8 = f4 * (f4 * f4 * 0.6f + 0.4f);
                    float f9 = f5 + f4;
                    float f10 = f6 + f7;
                    float f11 = f3 + f8;
                    f9 = f9 * 0.96f + 0.03f;
                    f10 = f10 * 0.96f + 0.03f;
                    f11 = f11 * 0.96f + 0.03f;
                    if (this.z > 0.0f) {
                        final float f12 = this.A + (this.z - this.A) * partialTicks;
                        f9 = f9 * (1.0f - f12) + f9 * 0.7f * f12;
                        f10 = f10 * (1.0f - f12) + f10 * 0.6f * f12;
                        f11 = f11 * (1.0f - f12) + f11 * 0.6f * f12;
                    }
                    if (worldclient.h.i() == 1) {
                        f9 = 0.22f + f4 * 0.75f;
                        f10 = 0.28f + f7 * 0.75f;
                        f11 = 0.25f + f8 * 0.75f;
                    }
                    if (this.h.e.zerodayisaminecraftcheat(Potion.j)) {
                        final float f13 = this.zerodayisaminecraftcheat(this.h.e, partialTicks);
                        float f14 = 1.0f / f9;
                        if (f14 > 1.0f / f10) {
                            f14 = 1.0f / f10;
                        }
                        if (f14 > 1.0f / f11) {
                            f14 = 1.0f / f11;
                        }
                        f9 = f9 * (1.0f - f13) + f9 * f14 * f13;
                        f10 = f10 * (1.0f - f13) + f10 * f14 * f13;
                        f11 = f11 * (1.0f - f13) + f11 * f14 * f13;
                    }
                    if (f9 > 1.0f) {
                        f9 = 1.0f;
                    }
                    if (f10 > 1.0f) {
                        f10 = 1.0f;
                    }
                    if (f11 > 1.0f) {
                        f11 = 1.0f;
                    }
                    final float f15 = this.h.r.aA;
                    float f16 = 1.0f - f9;
                    float f17 = 1.0f - f10;
                    float f18 = 1.0f - f11;
                    f16 = 1.0f - f16 * f16 * f16 * f16;
                    f17 = 1.0f - f17 * f17 * f17 * f17;
                    f18 = 1.0f - f18 * f18 * f18 * f18;
                    f9 = f9 * (1.0f - f15) + f16 * f15;
                    f10 = f10 * (1.0f - f15) + f17 * f15;
                    f11 = f11 * (1.0f - f15) + f18 * f15;
                    f9 = f9 * 0.96f + 0.03f;
                    f10 = f10 * 0.96f + 0.03f;
                    f11 = f11 * 0.96f + 0.03f;
                    if (f9 > 1.0f) {
                        f9 = 1.0f;
                    }
                    if (f10 > 1.0f) {
                        f10 = 1.0f;
                    }
                    if (f11 > 1.0f) {
                        f11 = 1.0f;
                    }
                    if (f9 < 0.0f) {
                        f9 = 0.0f;
                    }
                    if (f10 < 0.0f) {
                        f10 = 0.0f;
                    }
                    if (f11 < 0.0f) {
                        f11 = 0.0f;
                    }
                    final short short1 = 255;
                    final int j = (int)(f9 * 255.0f);
                    final int k = (int)(f10 * 255.0f);
                    final int l = (int)(f11 * 255.0f);
                    this.H[i] = (short1 << 24 | j << 16 | k << 8 | l);
                }
                this.G.zeroday();
                this.J = false;
                this.h.z.zeroday();
            }
        }
    }
    
    private float zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float partialTicks) {
        final int i = entitylivingbaseIn.zeroday(Potion.j).zeroday();
        return (i > 200) ? 1.0f : (0.7f + MathHelper.zerodayisaminecraftcheat((i - partialTicks) * 3.1415927f * 0.2f) * 0.3f);
    }
    
    public void zerodayisaminecraftcheat(final float p_181560_1_, final long p_181560_2_) {
        this.h();
        final boolean flag = Display.isActive();
        if (!flag && this.h.r.r && (!this.h.r.s || !Mouse.isButtonDown(1))) {
            if (Minecraft.C() - this.E > 500L) {
                this.h.i();
            }
        }
        else {
            this.E = Minecraft.C();
        }
        this.h.z.zerodayisaminecraftcheat("mouse");
        if (flag && Minecraft.zerodayisaminecraftcheat && this.h.v && !Mouse.isInsideWindow()) {
            Mouse.setGrabbed(false);
            Mouse.setCursorPosition(Display.getWidth() / 2, Display.getHeight() / 2);
            Mouse.setGrabbed(true);
        }
        if (this.h.v && flag) {
            this.h.s.sigma();
            final float f = this.h.r.zerodayisaminecraftcheat * 0.6f + 0.2f;
            final float f2 = f * f * f * 8.0f;
            float f3 = this.h.s.zerodayisaminecraftcheat * f2;
            float f4 = this.h.s.zeroday * f2;
            byte b0 = 1;
            if (this.h.r.zeroday) {
                b0 = -1;
            }
            if (this.h.r.ax) {
                this.s += f3;
                this.t += f4;
                final float f5 = p_181560_1_ - this.w;
                this.w = p_181560_1_;
                f3 = this.u * f5;
                f4 = this.v * f5;
                this.h.e.sigma(f3, f4 * b0);
            }
            else {
                this.s = 0.0f;
                this.t = 0.0f;
                this.h.e.sigma(f3, f4 * b0);
            }
        }
        this.h.z.zeroday();
        if (!this.h.p) {
            EntityRenderer.zerodayisaminecraftcheat = this.h.r.zues;
            final ScaledResolution scaledresolution = new ScaledResolution(this.h);
            final int l = scaledresolution.zerodayisaminecraftcheat();
            final int i1 = scaledresolution.zeroday();
            final int j1 = Mouse.getX() * l / this.h.flux;
            final int k1 = i1 - Mouse.getY() * i1 / this.h.vape - 1;
            final int l2 = this.h.r.vape;
            if (this.h.a != null) {
                this.h.z.zerodayisaminecraftcheat("level");
                int m = Math.min(Minecraft.ab(), l2);
                m = Math.max(m, 60);
                final long j2 = System.nanoTime() - p_181560_2_;
                final long k2 = Math.max(1000000000 / m / 4 - j2, 0L);
                this.zeroday(p_181560_1_, System.nanoTime() + k2);
                if (OpenGlHelper.G) {
                    this.h.b.zeroday();
                    if (this.vape != null && this.X) {
                        GlStateManager.d(5890);
                        GlStateManager.v();
                        GlStateManager.u();
                        this.vape.zerodayisaminecraftcheat(p_181560_1_);
                        GlStateManager.w();
                    }
                    this.h.sigma().zerodayisaminecraftcheat(true);
                }
                this.F = System.nanoTime();
                this.h.z.sigma("gui");
                if (!this.h.r.ar || this.h.k != null) {
                    GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
                    this.h.o.zerodayisaminecraftcheat(p_181560_1_);
                    zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.vape();
                    if (this.h.r.aZ && !this.h.r.at) {
                        Config.aR();
                    }
                    if (this.h.r.at) {
                        Lagometer.zerodayisaminecraftcheat(scaledresolution);
                    }
                }
                this.h.z.zeroday();
            }
            else {
                GlStateManager.zeroday(0, 0, this.h.flux, this.h.vape);
                GlStateManager.d(5889);
                GlStateManager.u();
                GlStateManager.d(5888);
                GlStateManager.u();
                this.a();
                this.F = System.nanoTime();
            }
            if (this.h.k != null) {
                GlStateManager.c(256);
                try {
                    if (Reflector.p.zeroday()) {
                        Reflector.zerodayisaminecraftcheat(Reflector.p, this.h.k, j1, k1, p_181560_1_);
                    }
                    else {
                        this.h.k.zerodayisaminecraftcheat(j1, k1, p_181560_1_);
                    }
                }
                catch (Throwable throwable) {
                    final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Rendering screen");
                    final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Screen render details");
                    crashreportcategory.zerodayisaminecraftcheat("Screen name", new EntityRenderer2(this));
                    crashreportcategory.zerodayisaminecraftcheat("Mouse location", new Callable() {
                        private static final String zeroday = "CL_00000950";
                        
                        public String zerodayisaminecraftcheat() throws Exception {
                            return String.format("Scaled: (%d, %d). Absolute: (%d, %d)", j1, k1, Mouse.getX(), Mouse.getY());
                        }
                    });
                    crashreportcategory.zerodayisaminecraftcheat("Screen size", new Callable() {
                        private static final String zeroday = "CL_00000951";
                        
                        public String zerodayisaminecraftcheat() throws Exception {
                            return String.format("Scaled: (%d, %d). Absolute: (%d, %d). Scale factor of %d", scaledresolution.zerodayisaminecraftcheat(), scaledresolution.zeroday(), EntityRenderer.this.h.flux, EntityRenderer.this.h.vape, scaledresolution.zues());
                        }
                    });
                    throw new ReportedException(crashreport);
                }
            }
        }
        this.i();
        this.g();
        Lagometer.zeroday();
        if (this.h.r.aY) {
            this.h.r.au = true;
        }
    }
    
    public void zeroday(final float partialTicks) {
        this.a();
        this.h.o.sigma(new ScaledResolution(this.h));
    }
    
    private boolean e() {
        if (!this.D) {
            return false;
        }
        final Entity entity = this.h.V();
        boolean flag = entity instanceof EntityPlayer && !this.h.r.ar;
        if (flag && !((EntityPlayer)entity).bz.zues) {
            final ItemStack itemstack = ((EntityPlayer)entity).aX();
            if (this.h.q != null && this.h.q.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
                final BlockPos blockpos = this.h.q.zerodayisaminecraftcheat();
                final Block block = this.h.a.zeroday(blockpos).sigma();
                if (this.h.zues.e() == WorldSettings.zerodayisaminecraftcheat.zues) {
                    boolean flag2;
                    if (Reflector.aS.zeroday()) {
                        final IBlockState iblockstate = this.h.a.zeroday(blockpos);
                        flag2 = Reflector.zeroday(block, Reflector.aS, iblockstate);
                    }
                    else {
                        flag2 = block.f();
                    }
                    flag = (flag2 && this.h.a.zerodayisaminecraftcheat(blockpos) instanceof IInventory);
                }
                else {
                    flag = (itemstack != null && (itemstack.sigma(block) || itemstack.pandora(block)));
                }
            }
        }
        return flag;
    }
    
    private void momgetthecamera(final float partialTicks) {
        if (this.h.r.at && !this.h.r.ar && !this.h.e.cf() && !this.h.r.o) {
            final Entity entity = this.h.V();
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            GL11.glLineWidth(1.0f);
            GlStateManager.n();
            GlStateManager.zerodayisaminecraftcheat(false);
            GlStateManager.v();
            GlStateManager.d(5888);
            GlStateManager.u();
            this.flux(partialTicks);
            GlStateManager.zeroday(0.0f, entity.aI(), 0.0f);
            RenderGlobal.zerodayisaminecraftcheat(new AxisAlignedBB(0.0, 0.0, 0.0, 0.005, 1.0E-4, 1.0E-4), 255, 0, 0, 255);
            RenderGlobal.zerodayisaminecraftcheat(new AxisAlignedBB(0.0, 0.0, 0.0, 1.0E-4, 1.0E-4, 0.005), 0, 0, 255, 255);
            RenderGlobal.zerodayisaminecraftcheat(new AxisAlignedBB(0.0, 0.0, 0.0, 1.0E-4, 0.0033, 1.0E-4), 0, 255, 0, 255);
            GlStateManager.w();
            GlStateManager.zerodayisaminecraftcheat(true);
            GlStateManager.m();
            GlStateManager.c();
        }
    }
    
    public void zeroday(final float partialTicks, final long finishTimeNano) {
        this.vape(partialTicks);
        if (this.h.V() == null) {
            this.h.zerodayisaminecraftcheat(this.h.e);
        }
        this.zerodayisaminecraftcheat(partialTicks);
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(this.h, partialTicks, finishTimeNano);
        }
        GlStateManager.b();
        GlStateManager.pandora();
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        this.h.z.zerodayisaminecraftcheat("center");
        if (this.h.r.zues) {
            EntityRenderer.zeroday = 0;
            GlStateManager.zerodayisaminecraftcheat(false, true, true, false);
            this.zerodayisaminecraftcheat(0, partialTicks, finishTimeNano);
            EntityRenderer.zeroday = 1;
            GlStateManager.zerodayisaminecraftcheat(true, false, false, false);
            this.zerodayisaminecraftcheat(1, partialTicks, finishTimeNano);
            GlStateManager.zerodayisaminecraftcheat(true, true, true, false);
        }
        else {
            this.zerodayisaminecraftcheat(2, partialTicks, finishTimeNano);
        }
        this.h.z.zeroday();
    }
    
    private void zerodayisaminecraftcheat(final int pass, final float partialTicks, final long finishTimeNano) {
        final boolean flag = Config.aC();
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(pass, partialTicks, finishTimeNano);
        }
        final RenderGlobal renderglobal = this.h.b;
        final EffectRenderer effectrenderer = this.h.g;
        final boolean flag2 = this.e();
        GlStateManager.g();
        this.h.z.sigma("clear");
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(0, 0, this.h.flux, this.h.vape);
        }
        else {
            GlStateManager.zeroday(0, 0, this.h.flux, this.h.vape);
        }
        this.a(partialTicks);
        GlStateManager.c(16640);
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.e();
        }
        this.h.z.sigma("camera");
        this.zerodayisaminecraftcheat(partialTicks, pass);
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(partialTicks);
        }
        ActiveRenderInfo.zerodayisaminecraftcheat(this.h.e, this.h.r.as == 2);
        this.h.z.sigma("frustum");
        ClippingHelperImpl.zerodayisaminecraftcheat();
        this.h.z.sigma("culling");
        final Frustum frustum = new Frustum();
        final Entity entity = this.h.V();
        final double d0 = entity.Q + (entity.s - entity.Q) * partialTicks;
        final double d2 = entity.R + (entity.t - entity.R) * partialTicks;
        final double d3 = entity.S + (entity.u - entity.S) * partialTicks;
        if (flag) {
            sigma.zerodayisaminecraftcheat.k.zerodayisaminecraftcheat(frustum, d0, d2, d3);
        }
        else {
            frustum.zerodayisaminecraftcheat(d0, d2, d3);
        }
        if ((Config.U() || Config.V() || Config.X()) && !sigma.zerodayisaminecraftcheat.j.k) {
            this.zerodayisaminecraftcheat(-1, partialTicks);
            this.h.z.sigma("sky");
            GlStateManager.d(5889);
            GlStateManager.u();
            Project.gluPerspective(this.zerodayisaminecraftcheat(partialTicks, true), this.h.flux / (float)this.h.vape, 0.05f, this.ac);
            GlStateManager.d(5888);
            if (flag) {
                sigma.zerodayisaminecraftcheat.j.m();
            }
            renderglobal.zerodayisaminecraftcheat(partialTicks, pass);
            if (flag) {
                sigma.zerodayisaminecraftcheat.j.p();
            }
            GlStateManager.d(5889);
            GlStateManager.u();
            Project.gluPerspective(this.zerodayisaminecraftcheat(partialTicks, true), this.h.flux / (float)this.h.vape, 0.05f, this.ac);
            GlStateManager.d(5888);
        }
        else {
            GlStateManager.c();
        }
        this.zerodayisaminecraftcheat(0, partialTicks);
        GlStateManager.b(7425);
        if (entity.t + entity.aI() < 128.0 + this.h.r.aR * 128.0f) {
            this.zerodayisaminecraftcheat(renderglobal, partialTicks, pass);
        }
        this.h.z.sigma("prepareterrain");
        this.zerodayisaminecraftcheat(0, partialTicks);
        this.h.I().zerodayisaminecraftcheat(TextureMap.zeroday);
        RenderHelper.zerodayisaminecraftcheat();
        this.h.z.sigma("terrain_setup");
        if (flag) {
            sigma.zerodayisaminecraftcheat.k.zerodayisaminecraftcheat(renderglobal, entity, partialTicks, frustum, this.c++, this.h.e.h_());
        }
        else {
            renderglobal.zerodayisaminecraftcheat(entity, partialTicks, frustum, this.c++, this.h.e.h_());
        }
        if (pass == 0 || pass == 2) {
            this.h.z.sigma("updatechunks");
            Lagometer.pandora.zerodayisaminecraftcheat();
            if (flag) {
                sigma.zerodayisaminecraftcheat.k.zerodayisaminecraftcheat(renderglobal, finishTimeNano);
            }
            else {
                this.h.b.zerodayisaminecraftcheat(finishTimeNano);
            }
            Lagometer.pandora.zeroday();
        }
        this.h.z.sigma("terrain");
        Lagometer.vape.zerodayisaminecraftcheat();
        if (this.h.r.aK && pass > 0) {
            this.h.z.sigma("finish");
            GL11.glFinish();
            this.h.z.sigma("terrain");
        }
        GlStateManager.d(5888);
        GlStateManager.v();
        GlStateManager.sigma();
        if (flag) {
            sigma.zerodayisaminecraftcheat.k.zerodayisaminecraftcheat();
        }
        renderglobal.zerodayisaminecraftcheat(EnumWorldBlockLayer.zerodayisaminecraftcheat, partialTicks, pass, entity);
        GlStateManager.pandora();
        if (flag) {
            sigma.zerodayisaminecraftcheat.k.zeroday();
        }
        renderglobal.zerodayisaminecraftcheat(EnumWorldBlockLayer.zeroday, partialTicks, pass, entity);
        this.h.I().zeroday(TextureMap.zeroday).zeroday(false, false);
        if (flag) {
            sigma.zerodayisaminecraftcheat.k.sigma();
        }
        renderglobal.zerodayisaminecraftcheat(EnumWorldBlockLayer.sigma, partialTicks, pass, entity);
        this.h.I().zeroday(TextureMap.zeroday).pandora();
        if (flag) {
            sigma.zerodayisaminecraftcheat.k.pandora();
        }
        Lagometer.vape.zeroday();
        GlStateManager.b(7424);
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        if (!this.T) {
            GlStateManager.d(5888);
            GlStateManager.w();
            GlStateManager.v();
            RenderHelper.zeroday();
            this.h.z.sigma("entities");
            if (Reflector.k.zeroday()) {
                Reflector.zerodayisaminecraftcheat(Reflector.k, 0);
            }
            renderglobal.zerodayisaminecraftcheat(entity, frustum, partialTicks);
            if (Reflector.k.zeroday()) {
                Reflector.zerodayisaminecraftcheat(Reflector.k, -1);
            }
            RenderHelper.zerodayisaminecraftcheat();
            this.vape();
            GlStateManager.d(5888);
            GlStateManager.w();
            GlStateManager.v();
            if (this.h.q != null && entity.zerodayisaminecraftcheat(Material.momgetthecamera) && flag2) {
                final EntityPlayer entityplayer = (EntityPlayer)entity;
                GlStateManager.sigma();
                this.h.z.sigma("outline");
                final boolean flag3 = Reflector.h.zeroday();
                if ((!flag3 || !Reflector.zeroday(Reflector.h, renderglobal, entityplayer, this.h.q, 0, entityplayer.aZ(), partialTicks)) && !this.h.r.ar) {
                    renderglobal.zerodayisaminecraftcheat(entityplayer, this.h.q, 0, partialTicks);
                }
                GlStateManager.pandora();
            }
        }
        GlStateManager.d(5888);
        GlStateManager.w();
        if (flag2 && this.h.q != null && !entity.zerodayisaminecraftcheat(Material.momgetthecamera)) {
            final EntityPlayer entityplayer2 = (EntityPlayer)entity;
            GlStateManager.sigma();
            this.h.z.sigma("outline");
            final boolean flag4 = Reflector.h.zeroday();
            if ((!flag4 || !Reflector.zeroday(Reflector.h, renderglobal, entityplayer2, this.h.q, 0, entityplayer2.aZ(), partialTicks)) && !this.h.r.ar) {
                renderglobal.zerodayisaminecraftcheat(entityplayer2, this.h.q, 0, partialTicks);
            }
            GlStateManager.pandora();
        }
        if (!renderglobal.zeroday.isEmpty()) {
            this.h.z.sigma("destroyProgress");
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 1, 1, 0);
            this.h.I().zeroday(TextureMap.zeroday).zeroday(false, false);
            renderglobal.zerodayisaminecraftcheat(Tessellator.zerodayisaminecraftcheat(), Tessellator.zerodayisaminecraftcheat().sigma(), entity, partialTicks);
            this.h.I().zeroday(TextureMap.zeroday).pandora();
        }
        GlStateManager.c();
        if (!this.T) {
            this.momgetthecamera();
            this.h.z.sigma("litParticles");
            if (flag) {
                sigma.zerodayisaminecraftcheat.j.E();
            }
            effectrenderer.zeroday(entity, partialTicks);
            RenderHelper.zerodayisaminecraftcheat();
            this.zerodayisaminecraftcheat(0, partialTicks);
            this.h.z.sigma("particles");
            if (flag) {
                sigma.zerodayisaminecraftcheat.j.F();
            }
            effectrenderer.zerodayisaminecraftcheat(entity, partialTicks);
            if (flag) {
                sigma.zerodayisaminecraftcheat.j.G();
            }
            this.vape();
        }
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.g();
        this.h.z.sigma("weather");
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.I();
        }
        this.sigma(partialTicks);
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.J();
        }
        GlStateManager.zerodayisaminecraftcheat(true);
        if (flag) {
            sigma.zerodayisaminecraftcheat.k.zerodayisaminecraftcheat(this, partialTicks, pass);
            sigma.zerodayisaminecraftcheat.j.K();
        }
        renderglobal.zerodayisaminecraftcheat(entity, partialTicks);
        GlStateManager.c();
        GlStateManager.g();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        this.zerodayisaminecraftcheat(0, partialTicks);
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(false);
        this.h.I().zerodayisaminecraftcheat(TextureMap.zeroday);
        GlStateManager.b(7425);
        this.h.z.sigma("translucent");
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.L();
        }
        renderglobal.zerodayisaminecraftcheat(EnumWorldBlockLayer.pandora, partialTicks, pass, entity);
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.M();
        }
        if (Reflector.k.zeroday() && !this.T) {
            RenderHelper.zeroday();
            this.h.z.sigma("entities");
            Reflector.zerodayisaminecraftcheat(Reflector.k, 1);
            this.h.b.zerodayisaminecraftcheat(entity, frustum, partialTicks);
            Reflector.zerodayisaminecraftcheat(Reflector.k, -1);
            RenderHelper.zerodayisaminecraftcheat();
        }
        GlStateManager.b(7424);
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.g();
        GlStateManager.c();
        GlStateManager.f();
        if (entity.t + entity.aI() >= 128.0 + this.h.r.aR * 128.0f) {
            this.h.z.sigma("aboveClouds");
            this.zerodayisaminecraftcheat(renderglobal, partialTicks, pass);
        }
        if (Reflector.j.zeroday()) {
            this.h.z.sigma("forge_render_last");
            Reflector.zerodayisaminecraftcheat(Reflector.j, renderglobal, partialTicks);
        }
        this.h.z.sigma("hand");
        zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.b();
        zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(new A());
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        final B event = new B(partialTicks);
        zeroday.zeroday.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(event);
        final boolean flag5 = Reflector.zeroday(Reflector.n, this.h.b, partialTicks, pass);
        if (!flag5 && this.C && !sigma.zerodayisaminecraftcheat.j.k) {
            if (flag) {
                sigma.zerodayisaminecraftcheat.k.zeroday(this, partialTicks, pass);
                sigma.zerodayisaminecraftcheat.j.k();
            }
            GlStateManager.c(256);
            if (flag) {
                sigma.zerodayisaminecraftcheat.k.sigma(this, partialTicks, pass);
            }
            else {
                this.zeroday(partialTicks, pass);
            }
            this.momgetthecamera(partialTicks);
        }
        if (flag) {
            sigma.zerodayisaminecraftcheat.j.l();
        }
    }
    
    private void zerodayisaminecraftcheat(final RenderGlobal renderGlobalIn, final float partialTicks, final int pass) {
        if (this.h.r.sigma >= 4 && !Config.p() && sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(this.h.r)) {
            this.h.z.sigma("clouds");
            GlStateManager.d(5889);
            GlStateManager.u();
            Project.gluPerspective(this.zerodayisaminecraftcheat(partialTicks, true), this.h.flux / (float)this.h.vape, 0.05f, this.ac * 4.0f);
            GlStateManager.d(5888);
            GlStateManager.v();
            this.zerodayisaminecraftcheat(0, partialTicks);
            renderGlobalIn.zeroday(partialTicks, pass);
            GlStateManager.f();
            GlStateManager.w();
            GlStateManager.d(5889);
            GlStateManager.u();
            Project.gluPerspective(this.zerodayisaminecraftcheat(partialTicks, true), this.h.flux / (float)this.h.vape, 0.05f, this.ac);
            GlStateManager.d(5888);
        }
    }
    
    private void f() {
        float f = this.h.a.b(1.0f);
        if (!Config.m()) {
            f /= 2.0f;
        }
        if (f != 0.0f && Config.F()) {
            this.j.setSeed(this.m * 312987231L);
            final Entity entity = this.h.V();
            final WorldClient worldclient = this.h.a;
            final BlockPos blockpos = new BlockPos(entity);
            final byte b0 = 10;
            double d0 = 0.0;
            double d2 = 0.0;
            double d3 = 0.0;
            int i = 0;
            int j = (int)(100.0f * f * f);
            if (this.h.r.aD == 1) {
                j >>= 1;
            }
            else if (this.h.r.aD == 2) {
                j = 0;
            }
            for (int k = 0; k < j; ++k) {
                final BlockPos blockpos2 = worldclient.i(blockpos.zeroday(this.j.nextInt(b0) - this.j.nextInt(b0), 0, this.j.nextInt(b0) - this.j.nextInt(b0)));
                final BiomeGenBase biomegenbase = worldclient.sigma(blockpos2);
                final BlockPos blockpos3 = blockpos2.zues();
                final Block block = worldclient.zeroday(blockpos3).sigma();
                if (blockpos2.zeroday() <= blockpos.zeroday() + b0 && blockpos2.zeroday() >= blockpos.zeroday() - b0 && biomegenbase.zues() && biomegenbase.zerodayisaminecraftcheat(blockpos2) >= 0.15f) {
                    final double d4 = this.j.nextDouble();
                    final double d5 = this.j.nextDouble();
                    if (block.flux() == Material.a) {
                        this.h.a.zerodayisaminecraftcheat(EnumParticleTypes.d, blockpos2.zerodayisaminecraftcheat() + d4, blockpos2.zeroday() + 0.1f - block.l(), blockpos2.sigma() + d5, 0.0, 0.0, 0.0, new int[0]);
                    }
                    else if (block.flux() != Material.zerodayisaminecraftcheat) {
                        block.sigma((IBlockAccess)worldclient, blockpos3);
                        ++i;
                        if (this.j.nextInt(i) == 0) {
                            d0 = blockpos3.zerodayisaminecraftcheat() + d4;
                            d2 = blockpos3.zeroday() + 0.1f + block.m() - 1.0;
                            d3 = blockpos3.sigma() + d5;
                        }
                        this.h.a.zerodayisaminecraftcheat(EnumParticleTypes.F, blockpos3.zerodayisaminecraftcheat() + d4, blockpos3.zeroday() + 0.1f + block.m(), blockpos3.sigma() + d5, 0.0, 0.0, 0.0, new int[0]);
                    }
                }
            }
            if (i > 0 && this.j.nextInt(3) < this.M++) {
                this.M = 0;
                if (d2 > blockpos.zeroday() + 1 && worldclient.i(blockpos).zeroday() > MathHelper.pandora((float)blockpos.zeroday())) {
                    this.h.a.zerodayisaminecraftcheat(d0, d2, d3, "ambient.weather.rain", 0.1f, 0.5f, false);
                }
                else {
                    this.h.a.zerodayisaminecraftcheat(d0, d2, d3, "ambient.weather.rain", 0.2f, 1.0f, false);
                }
            }
        }
    }
    
    protected void sigma(final float partialTicks) {
        if (Reflector.Q.zeroday()) {
            final WorldProvider worldprovider = this.h.a.h;
            final Object object = Reflector.vape(worldprovider, Reflector.Q, new Object[0]);
            if (object != null) {
                Reflector.zerodayisaminecraftcheat(object, Reflector.V, partialTicks, this.h.a, this.h);
                return;
            }
        }
        final float f5 = this.h.a.b(partialTicks);
        if (f5 > 0.0f) {
            if (Config.n()) {
                return;
            }
            this.momgetthecamera();
            final Entity entity = this.h.V();
            final WorldClient worldclient = this.h.a;
            final int i = MathHelper.sigma(entity.s);
            final int j = MathHelper.sigma(entity.t);
            final int k = MathHelper.sigma(entity.u);
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            GlStateManager.h();
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
            final double d0 = entity.Q + (entity.s - entity.Q) * partialTicks;
            final double d2 = entity.R + (entity.t - entity.R) * partialTicks;
            final double d3 = entity.S + (entity.u - entity.S) * partialTicks;
            final int l = MathHelper.sigma(d2);
            byte b0 = 5;
            if (Config.m()) {
                b0 = 10;
            }
            byte b2 = -1;
            final float f6 = this.m + partialTicks;
            worldrenderer.sigma(-d0, -d2, -d3);
            if (Config.m()) {
                b0 = 10;
            }
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            final BlockPos.zerodayisaminecraftcheat blockpos$mutableblockpos = new BlockPos.zerodayisaminecraftcheat();
            for (int i2 = k - b0; i2 <= k + b0; ++i2) {
                for (int j2 = i - b0; j2 <= i + b0; ++j2) {
                    final int k2 = (i2 - k + 16) * 32 + j2 - i + 16;
                    final double d4 = this.N[k2] * 0.5;
                    final double d5 = this.O[k2] * 0.5;
                    blockpos$mutableblockpos.zerodayisaminecraftcheat(j2, 0, i2);
                    final BiomeGenBase biomegenbase = worldclient.sigma(blockpos$mutableblockpos);
                    if (biomegenbase.zues() || biomegenbase.pandora()) {
                        final int l2 = worldclient.i(blockpos$mutableblockpos).zeroday();
                        int i3 = j - b0;
                        int j3 = j + b0;
                        if (i3 < l2) {
                            i3 = l2;
                        }
                        if (j3 < l2) {
                            j3 = l2;
                        }
                        int k3;
                        if ((k3 = l2) < l) {
                            k3 = l;
                        }
                        if (i3 != j3) {
                            this.j.setSeed(j2 * j2 * 3121 + j2 * 45238971 ^ i2 * i2 * 418711 + i2 * 13761);
                            blockpos$mutableblockpos.zerodayisaminecraftcheat(j2, i3, i2);
                            final float f7 = biomegenbase.zerodayisaminecraftcheat(blockpos$mutableblockpos);
                            if (worldclient.a().zerodayisaminecraftcheat(f7, l2) >= 0.15f) {
                                if (b2 != 0) {
                                    if (b2 >= 0) {
                                        tessellator.zeroday();
                                    }
                                    b2 = 0;
                                    this.h.I().zerodayisaminecraftcheat(EntityRenderer.f);
                                    worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.pandora);
                                }
                                final double d6 = ((this.m + j2 * j2 * 3121 + j2 * 45238971 + i2 * i2 * 418711 + i2 * 13761 & 0x1F) + (double)partialTicks) / 32.0 * (3.0 + this.j.nextDouble());
                                final double d7 = j2 + 0.5f - entity.s;
                                final double d8 = i2 + 0.5f - entity.u;
                                final float f8 = MathHelper.zerodayisaminecraftcheat(d7 * d7 + d8 * d8) / b0;
                                final float f9 = ((1.0f - f8 * f8) * 0.5f + 0.5f) * f5;
                                blockpos$mutableblockpos.zerodayisaminecraftcheat(j2, k3, i2);
                                final int l3 = worldclient.zerodayisaminecraftcheat(blockpos$mutableblockpos, 0);
                                final int i4 = l3 >> 16 & 0xFFFF;
                                final int j4 = l3 & 0xFFFF;
                                worldrenderer.zeroday(j2 - d4 + 0.5, i3, i2 - d5 + 0.5).zerodayisaminecraftcheat(0.0, i3 * 0.25 + d6).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f9).zerodayisaminecraftcheat(i4, j4).zues();
                                worldrenderer.zeroday(j2 + d4 + 0.5, i3, i2 + d5 + 0.5).zerodayisaminecraftcheat(1.0, i3 * 0.25 + d6).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f9).zerodayisaminecraftcheat(i4, j4).zues();
                                worldrenderer.zeroday(j2 + d4 + 0.5, j3, i2 + d5 + 0.5).zerodayisaminecraftcheat(1.0, j3 * 0.25 + d6).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f9).zerodayisaminecraftcheat(i4, j4).zues();
                                worldrenderer.zeroday(j2 - d4 + 0.5, j3, i2 - d5 + 0.5).zerodayisaminecraftcheat(0.0, j3 * 0.25 + d6).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f9).zerodayisaminecraftcheat(i4, j4).zues();
                            }
                            else {
                                if (b2 != 1) {
                                    if (b2 >= 0) {
                                        tessellator.zeroday();
                                    }
                                    b2 = 1;
                                    this.h.I().zerodayisaminecraftcheat(EntityRenderer.g);
                                    worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.pandora);
                                }
                                final double d9 = ((this.m & 0x1FF) + partialTicks) / 512.0f;
                                final double d10 = this.j.nextDouble() + f6 * 0.01 * (float)this.j.nextGaussian();
                                final double d11 = this.j.nextDouble() + f6 * (float)this.j.nextGaussian() * 0.001;
                                final double d12 = j2 + 0.5f - entity.s;
                                final double d13 = i2 + 0.5f - entity.u;
                                final float f10 = MathHelper.zerodayisaminecraftcheat(d12 * d12 + d13 * d13) / b0;
                                final float f11 = ((1.0f - f10 * f10) * 0.3f + 0.5f) * f5;
                                blockpos$mutableblockpos.zerodayisaminecraftcheat(j2, k3, i2);
                                final int k4 = (worldclient.zerodayisaminecraftcheat(blockpos$mutableblockpos, 0) * 3 + 15728880) / 4;
                                final int l4 = k4 >> 16 & 0xFFFF;
                                final int i5 = k4 & 0xFFFF;
                                worldrenderer.zeroday(j2 - d4 + 0.5, i3, i2 - d5 + 0.5).zerodayisaminecraftcheat(0.0 + d10, i3 * 0.25 + d9 + d11).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f11).zerodayisaminecraftcheat(l4, i5).zues();
                                worldrenderer.zeroday(j2 + d4 + 0.5, i3, i2 + d5 + 0.5).zerodayisaminecraftcheat(1.0 + d10, i3 * 0.25 + d9 + d11).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f11).zerodayisaminecraftcheat(l4, i5).zues();
                                worldrenderer.zeroday(j2 + d4 + 0.5, j3, i2 + d5 + 0.5).zerodayisaminecraftcheat(1.0 + d10, j3 * 0.25 + d9 + d11).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f11).zerodayisaminecraftcheat(l4, i5).zues();
                                worldrenderer.zeroday(j2 - d4 + 0.5, j3, i2 - d5 + 0.5).zerodayisaminecraftcheat(0.0 + d10, j3 * 0.25 + d9 + d11).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f11).zerodayisaminecraftcheat(l4, i5).zues();
                            }
                        }
                    }
                }
            }
            if (b2 >= 0) {
                tessellator.zeroday();
            }
            worldrenderer.sigma(0.0, 0.0, 0.0);
            GlStateManager.g();
            GlStateManager.c();
            GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
            this.vape();
        }
    }
    
    public void a() {
        final ScaledResolution scaledresolution = new ScaledResolution(this.h);
        GlStateManager.c(256);
        GlStateManager.d(5889);
        GlStateManager.u();
        GlStateManager.zerodayisaminecraftcheat(0.0, scaledresolution.sigma(), scaledresolution.pandora(), 0.0, 1000.0, 3000.0);
        GlStateManager.d(5888);
        GlStateManager.u();
        GlStateManager.zeroday(0.0f, 0.0f, -2000.0f);
    }
    
    private void a(final float partialTicks) {
        final WorldClient worldclient = this.h.a;
        final Entity entity = this.h.V();
        float f = 0.25f + 0.75f * this.h.r.sigma / 32.0f;
        f = 1.0f - (float)Math.pow(f, 0.25);
        Vec3 vec3 = worldclient.zerodayisaminecraftcheat(this.h.V(), partialTicks);
        vec3 = CustomColorizer.zeroday(vec3, worldclient, this.h.V(), partialTicks);
        final float f2 = (float)vec3.zerodayisaminecraftcheat;
        final float f3 = (float)vec3.zeroday;
        final float f4 = (float)vec3.sigma;
        Vec3 vec4 = worldclient.flux(partialTicks);
        vec4 = CustomColorizer.zerodayisaminecraftcheat(vec4, worldclient, this.h.V(), partialTicks);
        this.pandora = (float)vec4.zerodayisaminecraftcheat;
        this.zues = (float)vec4.zeroday;
        this.flux = (float)vec4.sigma;
        if (this.h.r.sigma >= 4) {
            final double d0 = -1.0;
            final Vec3 vec5 = (MathHelper.zerodayisaminecraftcheat(worldclient.pandora(partialTicks)) > 0.0f) ? new Vec3(d0, 0.0, 0.0) : new Vec3(1.0, 0.0, 0.0);
            float f5 = (float)entity.flux(partialTicks).zeroday(vec5);
            if (f5 < 0.0f) {
                f5 = 0.0f;
            }
            if (f5 > 0.0f) {
                final float[] afloat = worldclient.h.zerodayisaminecraftcheat(worldclient.sigma(partialTicks), partialTicks);
                if (afloat != null) {
                    f5 *= afloat[3];
                    this.pandora = this.pandora * (1.0f - f5) + afloat[0] * f5;
                    this.zues = this.zues * (1.0f - f5) + afloat[1] * f5;
                    this.flux = this.flux * (1.0f - f5) + afloat[2] * f5;
                }
            }
        }
        this.pandora += (f2 - this.pandora) * f;
        this.zues += (f3 - this.zues) * f;
        this.flux += (f4 - this.flux) * f;
        final float f6 = worldclient.b(partialTicks);
        if (f6 > 0.0f) {
            final float f7 = 1.0f - f6 * 0.5f;
            final float f8 = 1.0f - f6 * 0.4f;
            this.pandora *= f7;
            this.zues *= f7;
            this.flux *= f8;
        }
        final float f9 = worldclient.momgetthecamera(partialTicks);
        if (f9 > 0.0f) {
            final float f10 = 1.0f - f9 * 0.5f;
            this.pandora *= f10;
            this.zues *= f10;
            this.flux *= f10;
        }
        final Block block = ActiveRenderInfo.zerodayisaminecraftcheat(this.h.a, entity, partialTicks);
        if (this.B) {
            final Vec3 vec6 = worldclient.zues(partialTicks);
            this.pandora = (float)vec6.zerodayisaminecraftcheat;
            this.zues = (float)vec6.zeroday;
            this.flux = (float)vec6.sigma;
        }
        else if (block.flux() == Material.momgetthecamera) {
            float f11 = EnchantmentHelper.zerodayisaminecraftcheat(entity) * 0.2f;
            if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).zerodayisaminecraftcheat(Potion.g)) {
                f11 = f11 * 0.3f + 0.6f;
            }
            this.pandora = 0.02f + f11;
            this.zues = 0.02f + f11;
            this.flux = 0.2f + f11;
            final Vec3 vec7 = CustomColorizer.zerodayisaminecraftcheat(this.h.a, this.h.V().s, this.h.V().t + 1.0, this.h.V().u);
            if (vec7 != null) {
                this.pandora = (float)vec7.zerodayisaminecraftcheat;
                this.zues = (float)vec7.zeroday;
                this.flux = (float)vec7.sigma;
            }
        }
        else if (block.flux() == Material.a) {
            this.pandora = 0.6f;
            this.zues = 0.1f;
            this.flux = 0.0f;
        }
        final float f12 = this.Q + (this.R - this.Q) * partialTicks;
        this.pandora *= f12;
        this.zues *= f12;
        this.flux *= f12;
        final double d2 = worldclient.h.b();
        double d3 = (entity.R + (entity.t - entity.R) * partialTicks) * d2;
        if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).zerodayisaminecraftcheat(Potion.i)) {
            final int i = ((EntityLivingBase)entity).zeroday(Potion.i).zeroday();
            if (i < 20) {
                d3 *= 1.0f - i / 20.0f;
            }
            else {
                d3 = 0.0;
            }
        }
        if (d3 < 1.0) {
            if (d3 < 0.0) {
                d3 = 0.0;
            }
            d3 *= d3;
            this.pandora *= (float)d3;
            this.zues *= (float)d3;
            this.flux *= (float)d3;
        }
        if (this.z > 0.0f) {
            final float f13 = this.A + (this.z - this.A) * partialTicks;
            this.pandora = this.pandora * (1.0f - f13) + this.pandora * 0.7f * f13;
            this.zues = this.zues * (1.0f - f13) + this.zues * 0.6f * f13;
            this.flux = this.flux * (1.0f - f13) + this.flux * 0.6f * f13;
        }
        if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).zerodayisaminecraftcheat(Potion.j)) {
            final float f14 = this.zerodayisaminecraftcheat((EntityLivingBase)entity, partialTicks);
            float f15 = 1.0f / this.pandora;
            if (f15 > 1.0f / this.zues) {
                f15 = 1.0f / this.zues;
            }
            if (f15 > 1.0f / this.flux) {
                f15 = 1.0f / this.flux;
            }
            this.pandora = this.pandora * (1.0f - f14) + this.pandora * f15 * f14;
            this.zues = this.zues * (1.0f - f14) + this.zues * f15 * f14;
            this.flux = this.flux * (1.0f - f14) + this.flux * f15 * f14;
        }
        if (this.h.r.zues) {
            final float f16 = (this.pandora * 30.0f + this.zues * 59.0f + this.flux * 11.0f) / 100.0f;
            final float f17 = (this.pandora * 30.0f + this.zues * 70.0f) / 100.0f;
            final float f18 = (this.pandora * 30.0f + this.flux * 70.0f) / 100.0f;
            this.pandora = f16;
            this.zues = f17;
            this.flux = f18;
        }
        if (Reflector.ah.zeroday()) {
            final Object object = Reflector.zeroday(Reflector.ah, this, entity, block, partialTicks, this.pandora, this.zues, this.flux);
            Reflector.zerodayisaminecraftcheat(object);
            this.pandora = Reflector.zerodayisaminecraftcheat(object, Reflector.ai, this.pandora);
            this.zues = Reflector.zerodayisaminecraftcheat(object, Reflector.aj, this.zues);
            this.flux = Reflector.zerodayisaminecraftcheat(object, Reflector.ak, this.flux);
        }
        sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(this.pandora, this.zues, this.flux, 0.0f);
    }
    
    private void zerodayisaminecraftcheat(final int p_78468_1_, final float partialTicks) {
        final Entity entity = this.h.V();
        boolean flag = false;
        this.d = false;
        if (entity instanceof EntityPlayer) {
            flag = ((EntityPlayer)entity).bz.pandora;
        }
        GL11.glFog(2918, this.zerodayisaminecraftcheat(this.pandora, this.zues, this.flux, 1.0f));
        GL11.glNormal3f(0.0f, -1.0f, 0.0f);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        final Block block = ActiveRenderInfo.zerodayisaminecraftcheat(this.h.a, entity, partialTicks);
        final Object object = Reflector.zeroday(Reflector.am, this, entity, block, partialTicks, 0.1f);
        if (Reflector.zerodayisaminecraftcheat(object)) {
            final float f1 = Reflector.zerodayisaminecraftcheat(object, Reflector.an, 0.0f);
            GlStateManager.zerodayisaminecraftcheat(f1);
        }
        else if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).zerodayisaminecraftcheat(Potion.i)) {
            float f2 = 5.0f;
            final int i = ((EntityLivingBase)entity).zeroday(Potion.i).zeroday();
            if (i < 20) {
                f2 = 5.0f + (this.k - 5.0f) * (1.0f - i / 20.0f);
            }
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.b(9729);
            }
            else {
                GlStateManager.pandora(9729);
            }
            if (p_78468_1_ == -1) {
                GlStateManager.zeroday(0.0f);
                GlStateManager.sigma(f2 * 0.8f);
            }
            else {
                GlStateManager.zeroday(f2 * 0.25f);
                GlStateManager.sigma(f2);
            }
            if (GLContext.getCapabilities().GL_NV_fog_distance && Config.g()) {
                GL11.glFogi(34138, 34139);
            }
        }
        else if (this.B) {
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.b(2048);
            }
            else {
                GlStateManager.pandora(2048);
            }
            GlStateManager.zerodayisaminecraftcheat(0.1f);
        }
        else if (block.flux() == Material.momgetthecamera) {
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.b(2048);
            }
            else {
                GlStateManager.pandora(2048);
            }
            if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).zerodayisaminecraftcheat(Potion.g)) {
                GlStateManager.zerodayisaminecraftcheat(0.01f);
            }
            else {
                GlStateManager.zerodayisaminecraftcheat(0.1f - EnchantmentHelper.zerodayisaminecraftcheat(entity) * 0.03f);
            }
            if (Config.ab()) {
                GlStateManager.zerodayisaminecraftcheat(0.02f);
            }
        }
        else if (block.flux() == Material.a) {
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.b(2048);
            }
            else {
                GlStateManager.pandora(2048);
            }
            GlStateManager.zerodayisaminecraftcheat(2.0f);
        }
        else {
            final float f3 = this.k;
            this.d = true;
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.b(9729);
            }
            else {
                GlStateManager.pandora(9729);
            }
            if (p_78468_1_ == -1) {
                GlStateManager.zeroday(0.0f);
                GlStateManager.sigma(f3);
            }
            else {
                GlStateManager.zeroday(f3 * Config.j());
                GlStateManager.sigma(f3);
            }
            if (GLContext.getCapabilities().GL_NV_fog_distance) {
                if (Config.g()) {
                    GL11.glFogi(34138, 34139);
                }
                if (Config.h()) {
                    GL11.glFogi(34138, 34140);
                }
            }
            if (this.h.a.h.zeroday((int)entity.s, (int)entity.u)) {
                GlStateManager.zeroday(f3 * 0.05f);
                GlStateManager.sigma(f3);
            }
            if (Reflector.q.zeroday()) {
                Reflector.zerodayisaminecraftcheat(Reflector.q, this, entity, block, partialTicks, p_78468_1_, f3);
            }
        }
        GlStateManager.vape();
        GlStateManager.e();
        GlStateManager.zerodayisaminecraftcheat(1028, 4608);
    }
    
    private FloatBuffer zerodayisaminecraftcheat(final float red, final float green, final float blue, final float alpha) {
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(red, green, blue);
        }
        this.P.clear();
        this.P.put(red).put(green).put(blue).put(alpha);
        this.P.flip();
        return this.P;
    }
    
    public MapItemRenderer b() {
        return this.l;
    }
    
    private void g() {
        this.ag = 0;
        if (Config.aJ() && Config.aI()) {
            if (this.h.x()) {
                final IntegratedServer integratedserver = this.h.z();
                if (integratedserver != null) {
                    final boolean flag = this.h.O();
                    if (!flag && !(this.h.k instanceof GuiDownloadTerrain)) {
                        if (this.af > 0) {
                            Lagometer.momgetthecamera.zerodayisaminecraftcheat();
                            Config.zerodayisaminecraftcheat((long)this.af);
                            Lagometer.momgetthecamera.zeroday();
                            this.ag = this.af;
                        }
                        final long i = System.nanoTime() / 1000000L;
                        if (this.ad != 0L && this.ae != 0) {
                            long j = i - this.ad;
                            if (j < 0L) {
                                this.ad = i;
                                j = 0L;
                            }
                            if (j >= 50L) {
                                this.ad = i;
                                final int k = integratedserver.ai();
                                int l = k - this.ae;
                                if (l < 0) {
                                    this.ae = k;
                                    l = 0;
                                }
                                if (l < 1 && this.af < 100) {
                                    this.af += 2;
                                }
                                if (l > 1 && this.af > 0) {
                                    --this.af;
                                }
                                this.ae = k;
                            }
                        }
                        else {
                            this.ad = i;
                            this.ae = integratedserver.ai();
                            this.ai = 1.0f;
                            this.ah = 50.0f;
                        }
                    }
                    else {
                        if (this.h.k instanceof GuiDownloadTerrain) {
                            Config.zerodayisaminecraftcheat(20L);
                        }
                        this.ad = 0L;
                        this.ae = 0;
                    }
                }
            }
        }
        else {
            this.ad = 0L;
            this.ae = 0;
        }
    }
    
    private void h() {
        if (!this.Z) {
            TextureUtils.pandora();
            if (Config.aS() == 64 && Config.aT() == 32) {
                Config.zerodayisaminecraftcheat(true);
            }
            this.Z = true;
        }
        Config.aQ();
        Config.aN();
        final World world = this.h.a;
        if (world != null) {
            if (Config.aE() != null) {
                final String s = "HD_U".replace("HD_U", "HD Ultra").replace("L", "Light");
                final String s2 = String.valueOf(s) + " " + Config.aE();
                final ChatComponentText chatcomponenttext = new ChatComponentText("A new �eOptiFine�f version is available: �e" + s2 + "�f");
                this.h.o.pandora().zerodayisaminecraftcheat(chatcomponenttext);
                Config.flux(null);
            }
            if (Config.aU()) {
                Config.zerodayisaminecraftcheat(false);
                final ChatComponentText chatcomponenttext2 = new ChatComponentText("You can install �e64-bit Java�f to increase performance");
                this.h.o.pandora().zerodayisaminecraftcheat(chatcomponenttext2);
            }
        }
        if (this.h.k instanceof GuiMainMenu) {
            this.zerodayisaminecraftcheat((GuiMainMenu)this.h.k);
        }
        if (this.aa != world) {
            RandomMobs.zerodayisaminecraftcheat(this.aa, world);
            Config.momgetthecamera();
            this.ad = 0L;
            this.ae = 0;
            this.aa = world;
        }
        if (!this.zerodayisaminecraftcheat(sigma.zerodayisaminecraftcheat.j.cp)) {
            sigma.zerodayisaminecraftcheat.j.cp = 0;
        }
    }
    
    private void i() {
        if (this.h.a != null) {
            final long i = System.currentTimeMillis();
            if (i > this.aj + 10000L) {
                this.aj = i;
                final int j = GL11.glGetError();
                if (j != 0) {
                    final String s = GLU.gluErrorString(j);
                    final ChatComponentText chatcomponenttext = new ChatComponentText("�eOpenGL Error�f: " + j + " (" + s + ")");
                    this.h.o.pandora().zerodayisaminecraftcheat(chatcomponenttext);
                }
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final GuiMainMenu p_updateMainMenu_1_) {
        try {
            String s = null;
            final Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            final int i = calendar.get(5);
            final int j = calendar.get(2) + 1;
            if (i == 8 && j == 4) {
                s = "Happy birthday, OptiFine!";
            }
            if (i == 14 && j == 8) {
                s = "Happy birthday, sp614x!";
            }
            if (s == null) {
                return;
            }
            final Field[] afield = GuiMainMenu.class.getDeclaredFields();
            for (int k = 0; k < afield.length; ++k) {
                if (afield[k].getType() == String.class) {
                    afield[k].setAccessible(true);
                    afield[k].set(p_updateMainMenu_1_, s);
                    break;
                }
            }
        }
        catch (Throwable t) {}
    }
    
    public boolean zerodayisaminecraftcheat(final int p_setFxaaShader_1_) {
        if (!OpenGlHelper.a()) {
            return false;
        }
        if (this.vape != null && this.vape != this.ak[2] && this.vape != this.ak[4]) {
            return true;
        }
        if (p_setFxaaShader_1_ != 2 && p_setFxaaShader_1_ != 4) {
            if (this.vape == null) {
                return true;
            }
            this.vape.zerodayisaminecraftcheat();
            this.vape = null;
            return true;
        }
        else {
            if (this.vape != null && this.vape == this.ak[p_setFxaaShader_1_]) {
                return true;
            }
            if (this.h.a == null) {
                return true;
            }
            this.zerodayisaminecraftcheat(new ResourceLocation("shaders/post/fxaa_of_" + p_setFxaaShader_1_ + "x.json"));
            this.ak[p_setFxaaShader_1_] = this.vape;
            return this.X;
        }
    }
}

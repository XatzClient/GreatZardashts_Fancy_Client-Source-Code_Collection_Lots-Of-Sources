// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.vape.Entity;
import com.google.common.base.Predicate;

class EntityRenderer1 implements Predicate
{
    final EntityRenderer zerodayisaminecraftcheat;
    
    EntityRenderer1(final EntityRenderer p_i1243_1_) {
        this.zerodayisaminecraftcheat = p_i1243_1_;
    }
    
    public boolean zerodayisaminecraftcheat(final Entity p_apply_1_) {
        return p_apply_1_.Y();
    }
    
    public boolean apply(final Object p_apply_1_) {
        return this.zerodayisaminecraftcheat((Entity)p_apply_1_);
    }
}

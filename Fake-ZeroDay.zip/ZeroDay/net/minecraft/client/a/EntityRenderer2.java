// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.client.Minecraft;
import java.util.concurrent.Callable;

class EntityRenderer2 implements Callable
{
    final EntityRenderer zerodayisaminecraftcheat;
    private static final String zeroday = "CL_00000948";
    
    EntityRenderer2(final EntityRenderer p_i46419_1_) {
        this.zerodayisaminecraftcheat = p_i46419_1_;
    }
    
    public String zerodayisaminecraftcheat() throws Exception {
        return Minecraft.s().k.getClass().getCanonicalName();
    }
}

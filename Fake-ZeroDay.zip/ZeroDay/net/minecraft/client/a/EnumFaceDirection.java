// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.o.EnumFacing;

public enum EnumFaceDirection
{
    zerodayisaminecraftcheat("DOWN", 0, new zeroday[] { new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null) }), 
    zeroday("UP", 1, new zeroday[] { new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.pandora, null) }), 
    sigma("NORTH", 2, new zeroday[] { new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.pandora, null) }), 
    pandora("SOUTH", 3, new zeroday[] { new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null) }), 
    zues("WEST", 4, new zeroday[] { new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null) }), 
    flux("EAST", 5, new zeroday[] { new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.zerodayisaminecraftcheat, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.pandora, null), new zeroday(zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.pandora, null) });
    
    private static final EnumFaceDirection[] vape;
    private final zeroday[] momgetthecamera;
    
    static {
        a = new EnumFaceDirection[] { EnumFaceDirection.zerodayisaminecraftcheat, EnumFaceDirection.zeroday, EnumFaceDirection.sigma, EnumFaceDirection.pandora, EnumFaceDirection.zues, EnumFaceDirection.flux };
        (vape = new EnumFaceDirection[6])[zerodayisaminecraftcheat.zues] = EnumFaceDirection.zerodayisaminecraftcheat;
        EnumFaceDirection.vape[zerodayisaminecraftcheat.zeroday] = EnumFaceDirection.zeroday;
        EnumFaceDirection.vape[zerodayisaminecraftcheat.pandora] = EnumFaceDirection.sigma;
        EnumFaceDirection.vape[zerodayisaminecraftcheat.zerodayisaminecraftcheat] = EnumFaceDirection.pandora;
        EnumFaceDirection.vape[zerodayisaminecraftcheat.flux] = EnumFaceDirection.zues;
        EnumFaceDirection.vape[zerodayisaminecraftcheat.sigma] = EnumFaceDirection.flux;
    }
    
    public static EnumFaceDirection zerodayisaminecraftcheat(final EnumFacing facing) {
        return EnumFaceDirection.vape[facing.zeroday()];
    }
    
    private EnumFaceDirection(final String s, final int n, final zeroday[] vertexInfosIn) {
        this.momgetthecamera = vertexInfosIn;
    }
    
    public zeroday zerodayisaminecraftcheat(final int p_179025_1_) {
        return this.momgetthecamera[p_179025_1_];
    }
    
    public static final class zerodayisaminecraftcheat
    {
        public static final int zerodayisaminecraftcheat;
        public static final int zeroday;
        public static final int sigma;
        public static final int pandora;
        public static final int zues;
        public static final int flux;
        
        static {
            zerodayisaminecraftcheat = EnumFacing.pandora.zeroday();
            zeroday = EnumFacing.zeroday.zeroday();
            sigma = EnumFacing.flux.zeroday();
            pandora = EnumFacing.sigma.zeroday();
            zues = EnumFacing.zerodayisaminecraftcheat.zeroday();
            flux = EnumFacing.zues.zeroday();
        }
    }
    
    public static class zeroday
    {
        public final int zerodayisaminecraftcheat;
        public final int zeroday;
        public final int sigma;
        
        private zeroday(final int p_i46270_1_, final int p_i46270_2_, final int p_i46270_3_) {
            this.zerodayisaminecraftcheat = p_i46270_1_;
            this.zeroday = p_i46270_2_;
            this.sigma = p_i46270_3_;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.nio.IntBuffer;
import net.minecraft.l.Config;
import java.nio.FloatBuffer;
import org.lwjgl.opengl.GL11;

public class GlStateManager
{
    private static zerodayisaminecraftcheat zeroday;
    private static sigma sigma;
    private static sigma[] pandora;
    private static momgetthecamera zues;
    private static zeroday flux;
    private static b vape;
    private static c momgetthecamera;
    private static a a;
    private static e b;
    private static flux c;
    private static j d;
    private static pandora e;
    private static g f;
    private static sigma g;
    private static int h;
    private static k[] i;
    private static int j;
    private static sigma k;
    private static vape l;
    private static zues m;
    private static final String n = "CL_00002558";
    public static boolean zerodayisaminecraftcheat;
    
    static {
        GlStateManager.zeroday = new zerodayisaminecraftcheat(null);
        GlStateManager.sigma = new sigma(2896);
        GlStateManager.pandora = new sigma[8];
        GlStateManager.zues = new momgetthecamera(null);
        GlStateManager.flux = new zeroday(null);
        GlStateManager.vape = new b(null);
        GlStateManager.momgetthecamera = new c(null);
        GlStateManager.a = new a(null);
        GlStateManager.b = new e(null);
        GlStateManager.c = new flux(null);
        GlStateManager.d = new j(null);
        GlStateManager.e = new pandora(null);
        GlStateManager.f = new g(null);
        GlStateManager.g = new sigma(2977);
        GlStateManager.h = 0;
        GlStateManager.i = new k[32];
        GlStateManager.j = 7425;
        GlStateManager.k = new sigma(32826);
        GlStateManager.l = new vape(null);
        GlStateManager.m = new zues();
        GlStateManager.zerodayisaminecraftcheat = true;
        for (int i = 0; i < 8; ++i) {
            GlStateManager.pandora[i] = new sigma(16384 + i);
        }
        for (int j = 0; j < GlStateManager.i.length; ++j) {
            GlStateManager.i[j] = new k(null);
        }
    }
    
    public static void zerodayisaminecraftcheat() {
        GL11.glPushAttrib(8256);
    }
    
    public static void zeroday() {
        GL11.glPopAttrib();
    }
    
    public static void sigma() {
        GlStateManager.zeroday.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void pandora() {
        GlStateManager.zeroday.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void zerodayisaminecraftcheat(final int func, final float ref) {
        if (func != GlStateManager.zeroday.zeroday || ref != GlStateManager.zeroday.sigma) {
            GL11.glAlphaFunc(GlStateManager.zeroday.zeroday = func, GlStateManager.zeroday.sigma = ref);
        }
    }
    
    public static void zues() {
        GlStateManager.sigma.zeroday();
    }
    
    public static void flux() {
        GlStateManager.sigma.zerodayisaminecraftcheat();
    }
    
    public static void zerodayisaminecraftcheat(final int light) {
        GlStateManager.pandora[light].zeroday();
    }
    
    public static void zeroday(final int light) {
        GlStateManager.pandora[light].zerodayisaminecraftcheat();
    }
    
    public static void vape() {
        GlStateManager.zues.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void momgetthecamera() {
        GlStateManager.zues.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void zerodayisaminecraftcheat(final int face, final int mode) {
        if (face != GlStateManager.zues.zeroday || mode != GlStateManager.zues.sigma) {
            GL11.glColorMaterial(GlStateManager.zues.zeroday = face, GlStateManager.zues.sigma = mode);
        }
    }
    
    public static void a() {
        GlStateManager.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void b() {
        GlStateManager.vape.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void sigma(final int depthFunc) {
        if (depthFunc != GlStateManager.vape.sigma) {
            GL11.glDepthFunc(GlStateManager.vape.sigma = depthFunc);
        }
    }
    
    public static void zerodayisaminecraftcheat(final boolean flagIn) {
        if (flagIn != GlStateManager.vape.zeroday) {
            GL11.glDepthMask(GlStateManager.vape.zeroday = flagIn);
        }
    }
    
    public static void c() {
        GlStateManager.flux.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void d() {
        GlStateManager.flux.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void zeroday(final int srcFactor, final int dstFactor) {
        if (srcFactor != GlStateManager.flux.zeroday || dstFactor != GlStateManager.flux.sigma) {
            GL11.glBlendFunc(GlStateManager.flux.zeroday = srcFactor, GlStateManager.flux.sigma = dstFactor);
        }
    }
    
    public static void zerodayisaminecraftcheat(final int srcFactor, final int dstFactor, final int srcFactorAlpha, final int dstFactorAlpha) {
        if (srcFactor != GlStateManager.flux.zeroday || dstFactor != GlStateManager.flux.sigma || srcFactorAlpha != GlStateManager.flux.pandora || dstFactorAlpha != GlStateManager.flux.zues) {
            OpenGlHelper.sigma(GlStateManager.flux.zeroday = srcFactor, GlStateManager.flux.sigma = dstFactor, GlStateManager.flux.pandora = srcFactorAlpha, GlStateManager.flux.zues = dstFactorAlpha);
        }
    }
    
    public static void e() {
        GlStateManager.momgetthecamera.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void f() {
        GlStateManager.momgetthecamera.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void pandora(final int param) {
        if (param != GlStateManager.momgetthecamera.zeroday) {
            GL11.glFogi(2917, GlStateManager.momgetthecamera.zeroday = param);
        }
    }
    
    public static void zerodayisaminecraftcheat(final float param) {
        if (param != GlStateManager.momgetthecamera.sigma) {
            GL11.glFogf(2914, GlStateManager.momgetthecamera.sigma = param);
        }
    }
    
    public static void zeroday(final float param) {
        if (param != GlStateManager.momgetthecamera.pandora) {
            GL11.glFogf(2915, GlStateManager.momgetthecamera.pandora = param);
        }
    }
    
    public static void sigma(final float param) {
        if (param != GlStateManager.momgetthecamera.zues) {
            GL11.glFogf(2916, GlStateManager.momgetthecamera.zues = param);
        }
    }
    
    public static void g() {
        GlStateManager.a.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void h() {
        GlStateManager.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void zues(final int mode) {
        if (mode != GlStateManager.a.zeroday) {
            GL11.glCullFace(GlStateManager.a.zeroday = mode);
        }
    }
    
    public static void i() {
        GlStateManager.b.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void j() {
        GlStateManager.b.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void zerodayisaminecraftcheat(final float factor, final float units) {
        if (factor != GlStateManager.b.sigma || units != GlStateManager.b.pandora) {
            GL11.glPolygonOffset(GlStateManager.b.sigma = factor, GlStateManager.b.pandora = units);
        }
    }
    
    public static void k() {
        GlStateManager.c.zerodayisaminecraftcheat.zeroday();
    }
    
    public static void l() {
        GlStateManager.c.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void flux(final int opcode) {
        if (opcode != GlStateManager.c.zeroday) {
            GL11.glLogicOp(GlStateManager.c.zeroday = opcode);
        }
    }
    
    public static void zerodayisaminecraftcheat(final h p_179087_0_) {
        sigma(p_179087_0_).zerodayisaminecraftcheat.zeroday();
    }
    
    public static void zeroday(final h p_179100_0_) {
        sigma(p_179100_0_).zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static void zerodayisaminecraftcheat(final h p_179149_0_, final int p_179149_1_) {
        final i glstatemanager$texgencoord = sigma(p_179149_0_);
        if (p_179149_1_ != glstatemanager$texgencoord.sigma) {
            glstatemanager$texgencoord.sigma = p_179149_1_;
            GL11.glTexGeni(glstatemanager$texgencoord.zeroday, 9472, p_179149_1_);
        }
    }
    
    public static void zerodayisaminecraftcheat(final h p_179105_0_, final int pname, final FloatBuffer params) {
        GL11.glTexGen(sigma(p_179105_0_).zeroday, pname, params);
    }
    
    private static i sigma(final h p_179125_0_) {
        switch (GlStateManager.d.zerodayisaminecraftcheat[p_179125_0_.ordinal()]) {
            case 1: {
                return GlStateManager.d.zerodayisaminecraftcheat;
            }
            case 2: {
                return GlStateManager.d.zeroday;
            }
            case 3: {
                return GlStateManager.d.sigma;
            }
            case 4: {
                return GlStateManager.d.pandora;
            }
            default: {
                return GlStateManager.d.zerodayisaminecraftcheat;
            }
        }
    }
    
    public static void vape(final int texture) {
        if (GlStateManager.h != texture - OpenGlHelper.i) {
            GlStateManager.h = texture - OpenGlHelper.i;
            OpenGlHelper.c(texture);
        }
    }
    
    public static void m() {
        GlStateManager.i[GlStateManager.h].zerodayisaminecraftcheat.zeroday();
    }
    
    public static void n() {
        GlStateManager.i[GlStateManager.h].zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public static int o() {
        return GL11.glGenTextures();
    }
    
    public static void momgetthecamera(final int texture) {
        if (texture != 0) {
            GL11.glDeleteTextures(texture);
            k[] i;
            for (int length = (i = GlStateManager.i).length, j = 0; j < length; ++j) {
                final k glstatemanager$texturestate = i[j];
                if (glstatemanager$texturestate.zeroday == texture) {
                    glstatemanager$texturestate.zeroday = 0;
                }
            }
        }
    }
    
    public static void a(final int texture) {
        if (texture != GlStateManager.i[GlStateManager.h].zeroday) {
            GL11.glBindTexture(3553, GlStateManager.i[GlStateManager.h].zeroday = texture);
        }
    }
    
    public static void p() {
        GL11.glBindTexture(3553, GlStateManager.i[GlStateManager.h].zeroday);
    }
    
    public static void q() {
        GlStateManager.g.zeroday();
    }
    
    public static void r() {
        GlStateManager.g.zerodayisaminecraftcheat();
    }
    
    public static void b(final int mode) {
        if (mode != GlStateManager.j) {
            GL11.glShadeModel(GlStateManager.j = mode);
        }
    }
    
    public static void s() {
        GlStateManager.k.zeroday();
    }
    
    public static void t() {
        GlStateManager.k.zerodayisaminecraftcheat();
    }
    
    public static void zeroday(final int x, final int y, final int width, final int height) {
        GL11.glViewport(x, y, width, height);
    }
    
    public static void zerodayisaminecraftcheat(final boolean red, final boolean green, final boolean blue, final boolean alpha) {
        if (red != GlStateManager.l.zerodayisaminecraftcheat || green != GlStateManager.l.zeroday || blue != GlStateManager.l.sigma || alpha != GlStateManager.l.pandora) {
            GL11.glColorMask(GlStateManager.l.zerodayisaminecraftcheat = red, GlStateManager.l.zeroday = green, GlStateManager.l.sigma = blue, GlStateManager.l.pandora = alpha);
        }
    }
    
    public static void zerodayisaminecraftcheat(final double depth) {
        if (depth != GlStateManager.e.zerodayisaminecraftcheat) {
            GL11.glClearDepth(GlStateManager.e.zerodayisaminecraftcheat = depth);
        }
    }
    
    public static void zerodayisaminecraftcheat(final float red, final float green, final float blue, final float alpha) {
        if (red != GlStateManager.e.zeroday.zerodayisaminecraftcheat || green != GlStateManager.e.zeroday.zeroday || blue != GlStateManager.e.zeroday.sigma || alpha != GlStateManager.e.zeroday.pandora) {
            GL11.glClearColor(GlStateManager.e.zeroday.zerodayisaminecraftcheat = red, GlStateManager.e.zeroday.zeroday = green, GlStateManager.e.zeroday.sigma = blue, GlStateManager.e.zeroday.pandora = alpha);
        }
    }
    
    public static void c(final int mask) {
        if (GlStateManager.zerodayisaminecraftcheat) {
            GL11.glClear(mask);
        }
    }
    
    public static void d(final int mode) {
        GL11.glMatrixMode(mode);
    }
    
    public static void u() {
        GL11.glLoadIdentity();
    }
    
    public static void v() {
        GL11.glPushMatrix();
    }
    
    public static void w() {
        GL11.glPopMatrix();
    }
    
    public static void zerodayisaminecraftcheat(final int pname, final FloatBuffer params) {
        GL11.glGetFloat(pname, params);
    }
    
    public static void zerodayisaminecraftcheat(final double left, final double right, final double bottom, final double top, final double zNear, final double zFar) {
        GL11.glOrtho(left, right, bottom, top, zNear, zFar);
    }
    
    public static void zeroday(final float angle, final float x, final float y, final float z) {
        GL11.glRotatef(angle, x, y, z);
    }
    
    public static void zerodayisaminecraftcheat(final float x, final float y, final float z) {
        GL11.glScalef(x, y, z);
    }
    
    public static void zerodayisaminecraftcheat(final double x, final double y, final double z) {
        GL11.glScaled(x, y, z);
    }
    
    public static void zeroday(final float x, final float y, final float z) {
        GL11.glTranslatef(x, y, z);
    }
    
    public static void zeroday(final double x, final double y, final double z) {
        GL11.glTranslated(x, y, z);
    }
    
    public static void zerodayisaminecraftcheat(final FloatBuffer matrix) {
        GL11.glMultMatrix(matrix);
    }
    
    public static void sigma(final float colorRed, final float colorGreen, final float colorBlue, final float colorAlpha) {
        if (colorRed != GlStateManager.m.zerodayisaminecraftcheat || colorGreen != GlStateManager.m.zeroday || colorBlue != GlStateManager.m.sigma || colorAlpha != GlStateManager.m.pandora) {
            GL11.glColor4f(GlStateManager.m.zerodayisaminecraftcheat = colorRed, GlStateManager.m.zeroday = colorGreen, GlStateManager.m.sigma = colorBlue, GlStateManager.m.pandora = colorAlpha);
        }
    }
    
    public static void sigma(final float colorRed, final float colorGreen, final float colorBlue) {
        sigma(colorRed, colorGreen, colorBlue, 1.0f);
    }
    
    public static void x() {
        final zues m = GlStateManager.m;
        final zues i = GlStateManager.m;
        final zues j = GlStateManager.m;
        final zues k = GlStateManager.m;
        final float n = -1.0f;
        k.pandora = n;
        j.sigma = n;
        i.zeroday = n;
        m.zerodayisaminecraftcheat = n;
    }
    
    public static void e(final int list) {
        GL11.glCallList(list);
    }
    
    public static int y() {
        return OpenGlHelper.i + GlStateManager.h;
    }
    
    public static int z() {
        return GlStateManager.i[GlStateManager.h].zeroday;
    }
    
    public static void A() {
        if (Config.a()) {
            final int i = GL11.glGetInteger(34016);
            final int j = GL11.glGetInteger(32873);
            final int k = y();
            final int l = z();
            if (l > 0 && (i != k || j != l)) {
                Config.zerodayisaminecraftcheat("checkTexture: act: " + k + ", glAct: " + i + ", tex: " + l + ", glTex: " + j);
            }
        }
    }
    
    public static void zerodayisaminecraftcheat(final IntBuffer p_deleteTextures_0_) {
        p_deleteTextures_0_.rewind();
        while (p_deleteTextures_0_.position() < p_deleteTextures_0_.limit()) {
            final int i = p_deleteTextures_0_.get();
            momgetthecamera(i);
        }
        p_deleteTextures_0_.rewind();
    }
    
    public enum h
    {
        zerodayisaminecraftcheat("S", 0, "S", 0), 
        zeroday("T", 1, "T", 1), 
        sigma("R", 2, "R", 2), 
        pandora("Q", 3, "Q", 3);
        
        private static final h[] zues;
        private static final String flux = "CL_00002542";
        
        static {
            vape = new h[] { h.zerodayisaminecraftcheat, h.zeroday, h.sigma, h.pandora };
            zues = new h[] { h.zerodayisaminecraftcheat, h.zeroday, h.sigma, h.pandora };
        }
        
        private h(final String s, final int n, final String p_i12_3_, final int p_i12_4_) {
        }
    }
    
    static final class d
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002557";
        
        static {
            zerodayisaminecraftcheat = new int[GlStateManager.h.values().length];
            try {
                d.zerodayisaminecraftcheat[GlStateManager.h.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                d.zerodayisaminecraftcheat[GlStateManager.h.zeroday.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                d.zerodayisaminecraftcheat[GlStateManager.h.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                d.zerodayisaminecraftcheat[GlStateManager.h.pandora.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
        }
    }
    
    static class zerodayisaminecraftcheat
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        public float sigma;
        private static final String pandora = "CL_00002556";
        
        private zerodayisaminecraftcheat() {
            this.zerodayisaminecraftcheat = new sigma(3008);
            this.zeroday = 519;
            this.sigma = -1.0f;
        }
        
        zerodayisaminecraftcheat(final d p_i46489_1_) {
            this();
        }
    }
    
    static class zeroday
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        public int sigma;
        public int pandora;
        public int zues;
        private static final String flux = "CL_00002555";
        
        private zeroday() {
            this.zerodayisaminecraftcheat = new sigma(3042);
            this.zeroday = 1;
            this.sigma = 0;
            this.pandora = 1;
            this.zues = 0;
        }
        
        zeroday(final d p_i46488_1_) {
            this();
        }
    }
    
    static class sigma
    {
        private final int zerodayisaminecraftcheat;
        private boolean zeroday;
        private static final String sigma = "CL_00002554";
        
        public sigma(final int capabilityIn) {
            this.zeroday = false;
            this.zerodayisaminecraftcheat = capabilityIn;
        }
        
        public void zerodayisaminecraftcheat() {
            this.zerodayisaminecraftcheat(false);
        }
        
        public void zeroday() {
            this.zerodayisaminecraftcheat(true);
        }
        
        public void zerodayisaminecraftcheat(final boolean state) {
            if (state != this.zeroday) {
                this.zeroday = state;
                if (state) {
                    GL11.glEnable(this.zerodayisaminecraftcheat);
                }
                else {
                    GL11.glDisable(this.zerodayisaminecraftcheat);
                }
            }
        }
    }
    
    static class pandora
    {
        public double zerodayisaminecraftcheat;
        public zues zeroday;
        public int sigma;
        private static final String pandora = "CL_00002553";
        
        private pandora() {
            this.zerodayisaminecraftcheat = 1.0;
            this.zeroday = new zues(0.0f, 0.0f, 0.0f, 0.0f);
            this.sigma = 0;
        }
        
        pandora(final d p_i46487_1_) {
            this();
        }
    }
    
    static class zues
    {
        public float zerodayisaminecraftcheat;
        public float zeroday;
        public float sigma;
        public float pandora;
        private static final String zues = "CL_00002552";
        
        public zues() {
            this.zerodayisaminecraftcheat = 1.0f;
            this.zeroday = 1.0f;
            this.sigma = 1.0f;
            this.pandora = 1.0f;
        }
        
        public zues(final float redIn, final float greenIn, final float blueIn, final float alphaIn) {
            this.zerodayisaminecraftcheat = 1.0f;
            this.zeroday = 1.0f;
            this.sigma = 1.0f;
            this.pandora = 1.0f;
            this.zerodayisaminecraftcheat = redIn;
            this.zeroday = greenIn;
            this.sigma = blueIn;
            this.pandora = alphaIn;
        }
    }
    
    static class flux
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        private static final String sigma = "CL_00002551";
        
        private flux() {
            this.zerodayisaminecraftcheat = new sigma(3058);
            this.zeroday = 5379;
        }
        
        flux(final d p_i46486_1_) {
            this();
        }
    }
    
    static class vape
    {
        public boolean zerodayisaminecraftcheat;
        public boolean zeroday;
        public boolean sigma;
        public boolean pandora;
        private static final String zues = "CL_00002550";
        
        private vape() {
            this.zerodayisaminecraftcheat = true;
            this.zeroday = true;
            this.sigma = true;
            this.pandora = true;
        }
        
        vape(final d p_i46485_1_) {
            this();
        }
    }
    
    static class momgetthecamera
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        public int sigma;
        private static final String pandora = "CL_00002549";
        
        private momgetthecamera() {
            this.zerodayisaminecraftcheat = new sigma(2903);
            this.zeroday = 1032;
            this.sigma = 5634;
        }
        
        momgetthecamera(final d p_i46484_1_) {
            this();
        }
    }
    
    static class a
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        private static final String sigma = "CL_00002548";
        
        private a() {
            this.zerodayisaminecraftcheat = new sigma(2884);
            this.zeroday = 1029;
        }
        
        a(final d p_i46483_1_) {
            this();
        }
    }
    
    static class b
    {
        public sigma zerodayisaminecraftcheat;
        public boolean zeroday;
        public int sigma;
        private static final String pandora = "CL_00002547";
        
        private b() {
            this.zerodayisaminecraftcheat = new sigma(2929);
            this.zeroday = true;
            this.sigma = 513;
        }
        
        b(final d p_i46482_1_) {
            this();
        }
    }
    
    static class c
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        public float sigma;
        public float pandora;
        public float zues;
        private static final String flux = "CL_00002546";
        
        private c() {
            this.zerodayisaminecraftcheat = new sigma(2912);
            this.zeroday = 2048;
            this.sigma = 1.0f;
            this.pandora = 0.0f;
            this.zues = 1.0f;
        }
        
        c(final d p_i46481_1_) {
            this();
        }
    }
    
    static class e
    {
        public sigma zerodayisaminecraftcheat;
        public sigma zeroday;
        public float sigma;
        public float pandora;
        private static final String zues = "CL_00002545";
        
        private e() {
            this.zerodayisaminecraftcheat = new sigma(32823);
            this.zeroday = new sigma(10754);
            this.sigma = 0.0f;
            this.pandora = 0.0f;
        }
        
        e(final d p_i46480_1_) {
            this();
        }
    }
    
    static class f
    {
        public int zerodayisaminecraftcheat;
        public int zeroday;
        public int sigma;
        private static final String pandora = "CL_00002544";
        
        private f() {
            this.zerodayisaminecraftcheat = 519;
            this.zeroday = 0;
            this.sigma = -1;
        }
        
        f(final d p_i46479_1_) {
            this();
        }
    }
    
    static class g
    {
        public f zerodayisaminecraftcheat;
        public int zeroday;
        public int sigma;
        public int pandora;
        public int zues;
        private static final String flux = "CL_00002543";
        
        private g() {
            this.zerodayisaminecraftcheat = new f(null);
            this.zeroday = -1;
            this.sigma = 7680;
            this.pandora = 7680;
            this.zues = 7680;
        }
        
        g(final d p_i46478_1_) {
            this();
        }
    }
    
    static class i
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        public int sigma;
        private static final String pandora = "CL_00002541";
        
        public i(final int p_i46254_1_, final int p_i46254_2_) {
            this.sigma = -1;
            this.zeroday = p_i46254_1_;
            this.zerodayisaminecraftcheat = new sigma(p_i46254_2_);
        }
    }
    
    static class j
    {
        public i zerodayisaminecraftcheat;
        public i zeroday;
        public i sigma;
        public i pandora;
        private static final String zues = "CL_00002540";
        
        private j() {
            this.zerodayisaminecraftcheat = new i(8192, 3168);
            this.zeroday = new i(8193, 3169);
            this.sigma = new i(8194, 3170);
            this.pandora = new i(8195, 3171);
        }
        
        j(final d p_i46477_1_) {
            this();
        }
    }
    
    static class k
    {
        public sigma zerodayisaminecraftcheat;
        public int zeroday;
        private static final String sigma = "CL_00002539";
        
        private k() {
            this.zerodayisaminecraftcheat = new sigma(3553);
            this.zeroday = 0;
        }
        
        k(final d p_i46476_1_) {
            this();
        }
    }
}

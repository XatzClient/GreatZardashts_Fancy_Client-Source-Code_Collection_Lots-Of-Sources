// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.awt.image.BufferedImage;

public interface IImageBuffer
{
    BufferedImage zerodayisaminecraftcheat(final BufferedImage p0);
    
    void zerodayisaminecraftcheat();
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.awt.Graphics;
import java.awt.image.DataBufferInt;
import java.awt.image.ImageObserver;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class ImageBufferDownload implements IImageBuffer
{
    private int[] zerodayisaminecraftcheat;
    private int zeroday;
    private int sigma;
    private static final String pandora = "CL_00000956";
    
    @Override
    public BufferedImage zerodayisaminecraftcheat(final BufferedImage image) {
        if (image == null) {
            return null;
        }
        this.zeroday = 64;
        this.sigma = 64;
        final int i = image.getWidth();
        final int j = image.getHeight();
        int k = 1;
        while (this.zeroday < i || this.sigma < j) {
            this.zeroday *= 2;
            this.sigma *= 2;
            k *= 2;
        }
        final BufferedImage bufferedimage = new BufferedImage(this.zeroday, this.sigma, 2);
        final Graphics graphics = bufferedimage.getGraphics();
        graphics.drawImage(image, 0, 0, null);
        if (image.getHeight() == 32 * k) {
            graphics.drawImage(bufferedimage, 24 * k, 48 * k, 20 * k, 52 * k, 4 * k, 16 * k, 8 * k, 20 * k, null);
            graphics.drawImage(bufferedimage, 28 * k, 48 * k, 24 * k, 52 * k, 8 * k, 16 * k, 12 * k, 20 * k, null);
            graphics.drawImage(bufferedimage, 20 * k, 52 * k, 16 * k, 64 * k, 8 * k, 20 * k, 12 * k, 32 * k, null);
            graphics.drawImage(bufferedimage, 24 * k, 52 * k, 20 * k, 64 * k, 4 * k, 20 * k, 8 * k, 32 * k, null);
            graphics.drawImage(bufferedimage, 28 * k, 52 * k, 24 * k, 64 * k, 0 * k, 20 * k, 4 * k, 32 * k, null);
            graphics.drawImage(bufferedimage, 32 * k, 52 * k, 28 * k, 64 * k, 12 * k, 20 * k, 16 * k, 32 * k, null);
            graphics.drawImage(bufferedimage, 40 * k, 48 * k, 36 * k, 52 * k, 44 * k, 16 * k, 48 * k, 20 * k, null);
            graphics.drawImage(bufferedimage, 44 * k, 48 * k, 40 * k, 52 * k, 48 * k, 16 * k, 52 * k, 20 * k, null);
            graphics.drawImage(bufferedimage, 36 * k, 52 * k, 32 * k, 64 * k, 48 * k, 20 * k, 52 * k, 32 * k, null);
            graphics.drawImage(bufferedimage, 40 * k, 52 * k, 36 * k, 64 * k, 44 * k, 20 * k, 48 * k, 32 * k, null);
            graphics.drawImage(bufferedimage, 44 * k, 52 * k, 40 * k, 64 * k, 40 * k, 20 * k, 44 * k, 32 * k, null);
            graphics.drawImage(bufferedimage, 48 * k, 52 * k, 44 * k, 64 * k, 52 * k, 20 * k, 56 * k, 32 * k, null);
        }
        graphics.dispose();
        this.zerodayisaminecraftcheat = ((DataBufferInt)bufferedimage.getRaster().getDataBuffer()).getData();
        this.zeroday(0, 0, 32 * k, 16 * k);
        this.zerodayisaminecraftcheat(32 * k, 0, 64 * k, 32 * k);
        this.zeroday(0, 16 * k, 64 * k, 32 * k);
        this.zerodayisaminecraftcheat(0, 32 * k, 16 * k, 48 * k);
        this.zerodayisaminecraftcheat(16 * k, 32 * k, 40 * k, 48 * k);
        this.zerodayisaminecraftcheat(40 * k, 32 * k, 56 * k, 48 * k);
        this.zerodayisaminecraftcheat(0, 48 * k, 16 * k, 64 * k);
        this.zeroday(16 * k, 48 * k, 48 * k, 64 * k);
        this.zerodayisaminecraftcheat(48 * k, 48 * k, 64 * k, 64 * k);
        return bufferedimage;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
    }
    
    private void zerodayisaminecraftcheat(final int p_78434_1_, final int p_78434_2_, final int p_78434_3_, final int p_78434_4_) {
        if (!this.sigma(p_78434_1_, p_78434_2_, p_78434_3_, p_78434_4_)) {
            for (int i = p_78434_1_; i < p_78434_3_; ++i) {
                for (int j = p_78434_2_; j < p_78434_4_; ++j) {
                    final int[] zerodayisaminecraftcheat = this.zerodayisaminecraftcheat;
                    final int n = i + j * this.zeroday;
                    zerodayisaminecraftcheat[n] &= 0xFFFFFF;
                }
            }
        }
    }
    
    private void zeroday(final int p_78433_1_, final int p_78433_2_, final int p_78433_3_, final int p_78433_4_) {
        for (int i = p_78433_1_; i < p_78433_3_; ++i) {
            for (int j = p_78433_2_; j < p_78433_4_; ++j) {
                final int[] zerodayisaminecraftcheat = this.zerodayisaminecraftcheat;
                final int n = i + j * this.zeroday;
                zerodayisaminecraftcheat[n] |= 0xFF000000;
            }
        }
    }
    
    private boolean sigma(final int p_78435_1_, final int p_78435_2_, final int p_78435_3_, final int p_78435_4_) {
        for (int i = p_78435_1_; i < p_78435_3_; ++i) {
            for (int j = p_78435_2_; j < p_78435_4_; ++j) {
                final int k = this.zerodayisaminecraftcheat[i + j * this.zeroday];
                if ((k >> 24 & 0xFF) < 128) {
                    return true;
                }
            }
        }
        return false;
    }
}

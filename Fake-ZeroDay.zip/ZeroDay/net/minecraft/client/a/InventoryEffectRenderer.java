// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.util.Iterator;
import java.util.Collection;
import net.minecraft.client.b.I18n;
import net.minecraft.g.Potion;
import net.minecraft.g.PotionEffect;
import net.minecraft.b.Container;
import net.minecraft.client.sigma.zeroday.GuiContainer;

public abstract class InventoryEffectRenderer extends GuiContainer
{
    private boolean zerodayisaminecraftcheat;
    
    public InventoryEffectRenderer(final Container inventorySlotsIn) {
        super(inventorySlotsIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        super.zerodayisaminecraftcheat();
        this.flux();
    }
    
    protected void flux() {
        if (!this.u.e.bw().isEmpty()) {
            this.e = 160 + (this.w - this.b - 200) / 2;
            this.zerodayisaminecraftcheat = true;
        }
        else {
            this.e = (this.w - this.b) / 2;
            this.zerodayisaminecraftcheat = false;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        if (this.zerodayisaminecraftcheat) {
            this.vape();
        }
    }
    
    private void vape() {
        final int i = this.e - 124;
        int j = this.f;
        final int k = 166;
        final Collection<PotionEffect> collection = this.u.e.bw();
        if (!collection.isEmpty()) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.flux();
            int l = 33;
            if (collection.size() > 5) {
                l = 132 / (collection.size() - 1);
            }
            for (final PotionEffect potioneffect : this.u.e.bw()) {
                final Potion potion = Potion.zerodayisaminecraftcheat[potioneffect.zerodayisaminecraftcheat()];
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                this.u.I().zerodayisaminecraftcheat(InventoryEffectRenderer.a);
                this.zeroday(i, j, 0, 166, 140, 32);
                if (potion.zues()) {
                    final int i2 = potion.flux();
                    this.zeroday(i + 6, j + 7, 0 + i2 % 8 * 18, 198 + i2 / 8 * 18, 18, 18);
                }
                String s1 = I18n.zerodayisaminecraftcheat(potion.pandora(), new Object[0]);
                if (potioneffect.sigma() == 1) {
                    s1 = String.valueOf(s1) + " " + I18n.zerodayisaminecraftcheat("enchantment.level.2", new Object[0]);
                }
                else if (potioneffect.sigma() == 2) {
                    s1 = String.valueOf(s1) + " " + I18n.zerodayisaminecraftcheat("enchantment.level.3", new Object[0]);
                }
                else if (potioneffect.sigma() == 3) {
                    s1 = String.valueOf(s1) + " " + I18n.zerodayisaminecraftcheat("enchantment.level.4", new Object[0]);
                }
                this.C.zerodayisaminecraftcheat(s1, (float)(i + 10 + 18), (float)(j + 6), 16777215);
                final String s2 = Potion.zerodayisaminecraftcheat(potioneffect);
                this.C.zerodayisaminecraftcheat(s2, (float)(i + 10 + 18), (float)(j + 6 + 10), 8355711);
                j += l;
            }
        }
    }
}

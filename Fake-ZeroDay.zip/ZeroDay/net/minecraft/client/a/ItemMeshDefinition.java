// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.c.ItemStack;

public interface ItemMeshDefinition
{
    ModelResourceLocation zerodayisaminecraftcheat(final ItemStack p0);
}

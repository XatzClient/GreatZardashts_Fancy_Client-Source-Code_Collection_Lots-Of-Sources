// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.util.Iterator;
import net.minecraft.c.ItemStack;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import com.google.common.collect.Maps;
import net.minecraft.client.b.zeroday.ModelManager;
import net.minecraft.c.Item;
import net.minecraft.client.b.zeroday.IBakedModel;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import java.util.Map;

public class ItemModelMesher
{
    private final Map<Integer, ModelResourceLocation> zerodayisaminecraftcheat;
    private final Map<Integer, IBakedModel> zeroday;
    private final Map<Item, ItemMeshDefinition> sigma;
    private final ModelManager pandora;
    
    public ItemModelMesher(final ModelManager modelManager) {
        this.zerodayisaminecraftcheat = (Map<Integer, ModelResourceLocation>)Maps.newHashMap();
        this.zeroday = (Map<Integer, IBakedModel>)Maps.newHashMap();
        this.sigma = (Map<Item, ItemMeshDefinition>)Maps.newHashMap();
        this.pandora = modelManager;
    }
    
    public TextureAtlasSprite zerodayisaminecraftcheat(final Item item) {
        return this.zerodayisaminecraftcheat(item, 0);
    }
    
    public TextureAtlasSprite zerodayisaminecraftcheat(final Item item, final int meta) {
        return this.zerodayisaminecraftcheat(new ItemStack(item, 1, meta)).zues();
    }
    
    public IBakedModel zerodayisaminecraftcheat(final ItemStack stack) {
        final Item item = stack.zerodayisaminecraftcheat();
        IBakedModel ibakedmodel = this.zeroday(item, this.zeroday(stack));
        if (ibakedmodel == null) {
            final ItemMeshDefinition itemmeshdefinition = this.sigma.get(item);
            if (itemmeshdefinition != null) {
                ibakedmodel = this.pandora.zerodayisaminecraftcheat(itemmeshdefinition.zerodayisaminecraftcheat(stack));
            }
        }
        if (ibakedmodel == null) {
            ibakedmodel = this.pandora.zerodayisaminecraftcheat();
        }
        return ibakedmodel;
    }
    
    protected int zeroday(final ItemStack stack) {
        return stack.pandora() ? 0 : stack.momgetthecamera();
    }
    
    protected IBakedModel zeroday(final Item item, final int meta) {
        return this.zeroday.get(this.sigma(item, meta));
    }
    
    private int sigma(final Item item, final int meta) {
        return Item.zerodayisaminecraftcheat(item) << 16 | meta;
    }
    
    public void zerodayisaminecraftcheat(final Item item, final int meta, final ModelResourceLocation location) {
        this.zerodayisaminecraftcheat.put(this.sigma(item, meta), location);
        this.zeroday.put(this.sigma(item, meta), this.pandora.zerodayisaminecraftcheat(location));
    }
    
    public void zerodayisaminecraftcheat(final Item item, final ItemMeshDefinition definition) {
        this.sigma.put(item, definition);
    }
    
    public ModelManager zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    public void zeroday() {
        this.zeroday.clear();
        for (final Map.Entry<Integer, ModelResourceLocation> entry : this.zerodayisaminecraftcheat.entrySet()) {
            this.zeroday.put(entry.getKey(), this.pandora.zerodayisaminecraftcheat(entry.getValue()));
        }
    }
}

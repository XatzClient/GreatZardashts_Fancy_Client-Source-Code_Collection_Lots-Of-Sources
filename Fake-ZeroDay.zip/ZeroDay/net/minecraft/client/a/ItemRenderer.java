// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.c.EnumAction;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.b;
import zeroday.pandora.zerodayisaminecraftcheat.d.X;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.d;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.l;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.w;
import net.minecraft.q.vape.MapData;
import net.minecraft.q.World;
import net.minecraft.a.Items;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.pandora.Render;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.pandora.RenderPlayer;
import net.minecraft.o.MathHelper;
import net.minecraft.client.zeroday.EntityPlayerSP;
import net.minecraft.o.BlockPos;
import net.minecraft.client.zeroday.AbstractClientPlayer;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.c.Item;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.pandora.RenderItem;
import net.minecraft.client.a.pandora.RenderManager;
import net.minecraft.c.ItemStack;
import net.minecraft.client.Minecraft;
import net.minecraft.o.ResourceLocation;

public class ItemRenderer
{
    private static final ResourceLocation sigma;
    private static final ResourceLocation pandora;
    public static float zerodayisaminecraftcheat;
    private final Minecraft zues;
    private ItemStack flux;
    public boolean zeroday;
    private float vape;
    private float momgetthecamera;
    private final RenderManager a;
    private final RenderItem b;
    private int c;
    private static /* synthetic */ int[] d;
    
    static {
        sigma = new ResourceLocation("textures/map/map_background.png");
        pandora = new ResourceLocation("textures/misc/underwater.png");
    }
    
    public ItemRenderer(final Minecraft mcIn) {
        this.c = -1;
        this.zues = mcIn;
        this.a = mcIn.Y();
        this.b = mcIn.Z();
    }
    
    public void zerodayisaminecraftcheat(final EntityLivingBase entityIn, final ItemStack heldStack, final ItemCameraTransforms.zeroday transform) {
        if (heldStack != null) {
            final Item item = heldStack.zerodayisaminecraftcheat();
            final Block block = Block.zerodayisaminecraftcheat(item);
            GlStateManager.v();
            if (this.b.zerodayisaminecraftcheat(heldStack)) {
                GlStateManager.zerodayisaminecraftcheat(2.0f, 2.0f, 2.0f);
                if (this.zerodayisaminecraftcheat(block)) {
                    GlStateManager.zerodayisaminecraftcheat(false);
                }
            }
            this.b.zerodayisaminecraftcheat(heldStack, entityIn, transform);
            if (this.zerodayisaminecraftcheat(block)) {
                GlStateManager.zerodayisaminecraftcheat(true);
            }
            GlStateManager.w();
        }
    }
    
    private boolean zerodayisaminecraftcheat(final Block blockIn) {
        return blockIn != null && blockIn.i() == EnumWorldBlockLayer.pandora;
    }
    
    private void zerodayisaminecraftcheat(final float angle, final float p_178101_2_) {
        GlStateManager.v();
        GlStateManager.zeroday(angle, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(p_178101_2_, 0.0f, 1.0f, 0.0f);
        RenderHelper.zeroday();
        GlStateManager.w();
    }
    
    private void zerodayisaminecraftcheat(final AbstractClientPlayer clientPlayer) {
        final int i = this.zues.a.zerodayisaminecraftcheat(new BlockPos(clientPlayer.s, clientPlayer.t + clientPlayer.aI(), clientPlayer.u), 0);
        final float f = (float)(i & 0xFFFF);
        final float f2 = (float)(i >> 16);
        OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, f, f2);
    }
    
    private void zerodayisaminecraftcheat(final EntityPlayerSP entityplayerspIn, final float partialTicks) {
        final float f = entityplayerspIn.a + (entityplayerspIn.vape - entityplayerspIn.a) * partialTicks;
        final float f2 = entityplayerspIn.momgetthecamera + (entityplayerspIn.flux - entityplayerspIn.momgetthecamera) * partialTicks;
        GlStateManager.zeroday((entityplayerspIn.z - f) * 0.1f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday((entityplayerspIn.y - f2) * 0.1f, 0.0f, 1.0f, 0.0f);
    }
    
    private float sigma(final float p_178100_1_) {
        float f = 1.0f - p_178100_1_ / 45.0f + 0.1f;
        f = MathHelper.zerodayisaminecraftcheat(f, 0.0f, 1.0f);
        f = -MathHelper.zeroday(f * 3.1415927f) * 0.5f + 0.5f;
        return f;
    }
    
    private void zerodayisaminecraftcheat(final RenderPlayer renderPlayerIn) {
        GlStateManager.v();
        GlStateManager.zeroday(54.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(64.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(-62.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(0.25f, -0.85f, 0.75f);
        renderPlayerIn.zeroday((AbstractClientPlayer)this.zues.e);
        GlStateManager.w();
    }
    
    private void zeroday(final RenderPlayer renderPlayerIn) {
        GlStateManager.v();
        GlStateManager.zeroday(92.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(45.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(41.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(-0.3f, -1.1f, 0.45f);
        renderPlayerIn.sigma(this.zues.e);
        GlStateManager.w();
    }
    
    private void zeroday(final AbstractClientPlayer clientPlayer) {
        this.zues.I().zerodayisaminecraftcheat(clientPlayer.a());
        final Render<AbstractClientPlayer> render = this.a.zerodayisaminecraftcheat(this.zues.e);
        final RenderPlayer renderplayer = (RenderPlayer)render;
        if (!clientPlayer.ap()) {
            GlStateManager.h();
            this.zerodayisaminecraftcheat(renderplayer);
            this.zeroday(renderplayer);
            GlStateManager.g();
        }
    }
    
    private void zerodayisaminecraftcheat(final AbstractClientPlayer clientPlayer, final float p_178097_2_, final float p_178097_3_, final float p_178097_4_) {
        final float f = -0.4f * MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178097_4_) * 3.1415927f);
        final float f2 = 0.2f * MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178097_4_) * 3.1415927f * 2.0f);
        final float f3 = -0.2f * MathHelper.zerodayisaminecraftcheat(p_178097_4_ * 3.1415927f);
        final float f4 = this.sigma(p_178097_2_);
        GlStateManager.zeroday(0.0f, 0.04f, -0.72f);
        GlStateManager.zeroday(0.0f, p_178097_3_ * -1.2f, 0.0f);
        GlStateManager.zeroday(0.0f, f4 * -0.5f, 0.0f);
        GlStateManager.zeroday(90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(f4 * -85.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(0.0f, 1.0f, 0.0f, 0.0f);
        this.zeroday(clientPlayer);
        final float f5 = MathHelper.zerodayisaminecraftcheat(p_178097_4_ * p_178097_4_ * 3.1415927f);
        final float f6 = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178097_4_) * 3.1415927f);
        GlStateManager.zeroday(f5 * -20.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(f6 * -20.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(f6 * -80.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zerodayisaminecraftcheat(0.38f, 0.38f, 0.38f);
        GlStateManager.zeroday(90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(180.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(0.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(-1.0f, -1.0f, 0.0f);
        GlStateManager.zerodayisaminecraftcheat(0.015625f, 0.015625f, 0.015625f);
        this.zues.I().zerodayisaminecraftcheat(ItemRenderer.sigma);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        GL11.glNormal3f(0.0f, 0.0f, -1.0f);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(-7.0, 135.0, 0.0).zerodayisaminecraftcheat(0.0, 1.0).zues();
        worldrenderer.zeroday(135.0, 135.0, 0.0).zerodayisaminecraftcheat(1.0, 1.0).zues();
        worldrenderer.zeroday(135.0, -7.0, 0.0).zerodayisaminecraftcheat(1.0, 0.0).zues();
        worldrenderer.zeroday(-7.0, -7.0, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zues();
        tessellator.zeroday();
        final MapData mapdata = Items.aV.zerodayisaminecraftcheat(this.flux, this.zues.a);
        if (mapdata != null) {
            this.zues.m.b().zerodayisaminecraftcheat(mapdata, false);
        }
    }
    
    private void zerodayisaminecraftcheat(final AbstractClientPlayer clientPlayer, final float p_178095_2_, final float p_178095_3_) {
        final float f = -0.3f * MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178095_3_) * 3.1415927f);
        final float f2 = 0.4f * MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178095_3_) * 3.1415927f * 2.0f);
        final float f3 = -0.4f * MathHelper.zerodayisaminecraftcheat(p_178095_3_ * 3.1415927f);
        GlStateManager.zeroday(f, f2, f3);
        GlStateManager.zeroday(0.64000005f, -0.6f, -0.71999997f);
        GlStateManager.zeroday(0.0f, p_178095_2_ * -0.6f, 0.0f);
        GlStateManager.zeroday(45.0f, 0.0f, 1.0f, 0.0f);
        final float f4 = MathHelper.zerodayisaminecraftcheat(p_178095_3_ * p_178095_3_ * 3.1415927f);
        final float f5 = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178095_3_) * 3.1415927f);
        GlStateManager.zeroday(f5 * 70.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(f4 * -20.0f, 0.0f, 0.0f, 1.0f);
        this.zues.I().zerodayisaminecraftcheat(clientPlayer.a());
        GlStateManager.zeroday(-1.0f, 3.6f, 3.5f);
        GlStateManager.zeroday(120.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(200.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(-135.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f);
        GlStateManager.zeroday(5.6f, 0.0f, 0.0f);
        final Render<AbstractClientPlayer> render = this.a.zerodayisaminecraftcheat(this.zues.e);
        GlStateManager.h();
        final RenderPlayer renderplayer = (RenderPlayer)render;
        renderplayer.zeroday((AbstractClientPlayer)this.zues.e);
        GlStateManager.g();
    }
    
    private void pandora(final float p_178105_1_) {
        final float f = -0.4f * MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178105_1_) * 3.1415927f);
        final float f2 = 0.2f * MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_178105_1_) * 3.1415927f * 2.0f);
        final float f3 = -0.2f * MathHelper.zerodayisaminecraftcheat(p_178105_1_ * 3.1415927f);
        if (w.zeroday) {
            GlStateManager.zeroday(f, f2, f3);
        }
    }
    
    private void zerodayisaminecraftcheat(final AbstractClientPlayer clientPlayer, final float p_178104_2_) {
        if (l.zeroday) {
            final float f = clientPlayer.aO() - p_178104_2_ + 1.0f;
            final float f2 = f / this.flux.d();
            float f3 = MathHelper.zues(MathHelper.zeroday(f / 4.0f * 3.1415927f) * 0.1f);
            if (f2 >= 0.8f) {
                f3 = 0.0f;
            }
            GlStateManager.zeroday(0.0f, f3, 0.0f);
            final float f4 = 1.0f - (float)Math.pow(f2, 27.0);
            GlStateManager.zeroday(f4 * 0.6f, f4 * -0.5f, f4 * 0.0f);
            GlStateManager.zeroday(f4 * 90.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(f4 * 10.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(f4 * 30.0f, 0.0f, 0.0f, 1.0f);
        }
        else {
            final float f = clientPlayer.aO() - p_178104_2_ + 1.0f;
            final float f2 = f / this.flux.d();
            float f3 = MathHelper.zues(MathHelper.zeroday(f / 6.0f * 3.1415927f) * 0.2f);
            if (f2 >= 0.8f) {
                f3 = 0.0f;
            }
            GlStateManager.zeroday(0.0f, f3, 0.0f);
            GlStateManager.zeroday(f3 * (this.zeroday ? -90.0f : 90.0f), 0.0f, f3 * 90.0f, f3 * 90.0f);
            if (f3 <= 0.05) {
                this.zeroday = !this.zeroday;
            }
            final float f4 = 1.0f - (float)Math.pow(f2, 27.0);
            GlStateManager.zeroday(f4 * 0.6f, f4 * -0.5f, f4 * 0.0f);
            GlStateManager.zeroday(f4 * 90.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(f4 * 10.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(f4 * 30.0f, 0.0f, 0.0f, 1.0f);
        }
    }
    
    private void zeroday(final float equipProgress, final float swingProgress) {
        GlStateManager.zeroday(0.56f, -0.52f, -0.71999997f);
        GlStateManager.zeroday(0.0f, equipProgress * -0.6f, 0.0f);
        GlStateManager.zeroday(45.0f, 0.0f, 1.0f, 0.0f);
        final float f = MathHelper.zerodayisaminecraftcheat(swingProgress * swingProgress * 3.1415927f);
        final float f2 = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(swingProgress) * 3.1415927f);
        GlStateManager.zeroday(f * -20.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(f2 * -20.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(f2 * -80.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zerodayisaminecraftcheat(0.4f, 0.4f, 0.4f);
    }
    
    private void zerodayisaminecraftcheat(final float p_178098_1_, final AbstractClientPlayer clientPlayer) {
        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.d.zeroday) {
            GlStateManager.zeroday(-18.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.zeroday(-12.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(-8.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(-0.9f, 0.2f, 0.0f);
            final float f = this.flux.d() - (clientPlayer.aO() - p_178098_1_ + 1.0f);
            float f2 = f / 20.0f;
            f2 = (f2 * f2 + f2 * 2.0f) / 3.0f;
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            if (f2 > 0.1f) {
                final float f3 = MathHelper.zerodayisaminecraftcheat((f - 0.1f) * 1.3f);
                final float f4 = f2 - 0.1f;
                final float f5 = f3 * f4;
                GlStateManager.zeroday(f5 * 0.0f, f5 * 0.01f, f5 * 0.0f);
            }
            GlStateManager.zeroday(f2 * 0.0f, f2 * 0.0f, f2 * 0.1f);
            GlStateManager.zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f + f2 * 0.2f);
        }
        else {
            GlStateManager.zeroday(-18.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.zeroday(-12.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(-8.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(-0.9f, 0.2f, 0.0f);
            final float f = this.flux.d() - (clientPlayer.aO() - p_178098_1_ + 1.0f);
            float f2 = f / 20.0f;
            f2 = (f2 * f2 + f2 * 2.0f) / 3.0f;
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            if (f2 > 0.1f) {
                final float f3 = MathHelper.zerodayisaminecraftcheat((f - 0.1f) * 0.8f);
                final float f4 = f2 - 0.1f;
                final float f5 = f3 * f4;
                GlStateManager.zeroday(f5 * 0.0f, f5 * 0.1f, f5 * 0.0f);
            }
            GlStateManager.zeroday(f2 * 0.0f, f2 * 0.2f, f2 * -0.1f);
            GlStateManager.zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f + f2 * 0.2f);
        }
    }
    
    private void zues(final float p_187453_2_) {
        ItemRenderer.zerodayisaminecraftcheat += 3.0f;
        final float f = MathHelper.zerodayisaminecraftcheat(p_187453_2_ * p_187453_2_ * 3.1415927f);
        GlStateManager.zeroday(1.0f * ((X.c ? ItemRenderer.zerodayisaminecraftcheat : 0.0f) + 45.0f + f * -20.0f), 0.0f, 1.0f, 0.0f);
        final float f2 = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(p_187453_2_) * 3.1415927f);
        GlStateManager.zeroday(1.0f * f2 * -20.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(f2 * -80.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(-45.0f, 0.0f, 1.0f, 0.0f);
    }
    
    private void zues() {
        GlStateManager.zeroday(-0.5f, 0.2f, 0.0f);
        GlStateManager.zeroday(30.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(-80.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(60.0f, 0.0f, 1.0f, 0.0f);
    }
    
    public void zerodayisaminecraftcheat(final float partialTicks) {
        final float f = 1.0f - (this.momgetthecamera + (this.vape - this.momgetthecamera) * partialTicks);
        final AbstractClientPlayer abstractclientplayer = this.zues.e;
        final float f2 = abstractclientplayer.e(partialTicks);
        final float fslow = abstractclientplayer.e(partialTicks);
        final float f3 = abstractclientplayer.B + (abstractclientplayer.z - abstractclientplayer.B) * partialTicks;
        final float f4 = abstractclientplayer.A + (abstractclientplayer.y - abstractclientplayer.A) * partialTicks;
        this.zerodayisaminecraftcheat(f3, f4);
        this.zerodayisaminecraftcheat(abstractclientplayer);
        this.zerodayisaminecraftcheat((EntityPlayerSP)abstractclientplayer, partialTicks);
        GlStateManager.s();
        GlStateManager.v();
        if (this.flux != null) {
            if (this.flux.zerodayisaminecraftcheat() == Items.aV) {
                this.zerodayisaminecraftcheat(abstractclientplayer, f3, f, f2);
            }
            else if (abstractclientplayer.aO() > 0) {
                final EnumAction enumaction = this.flux.e();
                switch (pandora()[enumaction.ordinal()]) {
                    case 1: {
                        this.zeroday(f, 1.0f);
                        this.zues(1.0f);
                        break;
                    }
                    case 2:
                    case 3: {
                        this.zerodayisaminecraftcheat(abstractclientplayer, partialTicks);
                        this.zeroday(f, 0.0f);
                        this.zues(1.0f);
                        break;
                    }
                    case 4: {
                        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.b.zerodayisaminecraftcheat) {
                            GlStateManager.zeroday(-0.0f, 0.1f, 0.0f);
                            this.zeroday(f, fslow * fslow);
                            this.zues();
                            this.zues(1.0f);
                            break;
                        }
                        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.b.zeroday) {
                            this.zeroday(0.0f, 0.0f);
                            this.zues();
                            final float f5 = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(f2) * 3.1415927f);
                            GlStateManager.zeroday(-0.5f, 0.4f, 0.0f);
                            GlStateManager.zeroday(-f5 * 50.0f, -10.0f, -0.0f, 9.0f);
                            GlStateManager.zeroday(-f5 * 70.0f, 1.0f, -0.4f, -0.0f);
                            this.zues(1.0f);
                            break;
                        }
                        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.b.sigma) {
                            this.zeroday(f, 0.0f);
                            this.zues();
                            this.zues(1.0f);
                            break;
                        }
                        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.b.pandora) {
                            this.zeroday(f, 0.0f);
                            this.zues();
                            final float var14 = MathHelper.zerodayisaminecraftcheat(f2 * f2 * 3.1415927f);
                            final float var15 = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(f2) * 3.1415927f);
                            GlStateManager.zeroday(-0.0f, 0.4f, 0.3f);
                            GlStateManager.zeroday(-var15 * 35.0f, -8.0f, -0.0f, 9.0f);
                            GlStateManager.zeroday(-var15 * 10.0f, 1.0f, -0.4f, -0.5f);
                            break;
                        }
                    }
                    case 5: {
                        this.zeroday(f, 0.0f);
                        this.zerodayisaminecraftcheat(partialTicks, abstractclientplayer);
                        this.zues(1.0f);
                        break;
                    }
                }
            }
            else {
                this.pandora(f2);
                this.zeroday(f, f2);
                this.zues(1.0f);
            }
            this.zerodayisaminecraftcheat(abstractclientplayer, this.flux, ItemCameraTransforms.zeroday.sigma);
        }
        else if (!abstractclientplayer.ap()) {
            this.zerodayisaminecraftcheat(abstractclientplayer, f, f2);
        }
        GlStateManager.w();
        GlStateManager.t();
        RenderHelper.zerodayisaminecraftcheat();
    }
    
    public void zeroday(final float partialTicks) {
        GlStateManager.sigma();
        if (this.zues.e.g()) {
            IBlockState iblockstate = this.zues.a.zeroday(new BlockPos(this.zues.e));
            final EntityPlayer entityplayer = this.zues.e;
            for (int i = 0; i < 8; ++i) {
                final double d0 = entityplayer.s + ((i >> 0) % 2 - 0.5f) * entityplayer.K * 0.8f;
                final double d2 = entityplayer.t + ((i >> 1) % 2 - 0.5f) * 0.1f;
                final double d3 = entityplayer.u + ((i >> 2) % 2 - 0.5f) * entityplayer.K * 0.8f;
                final BlockPos blockpos = new BlockPos(d0, d2 + entityplayer.aI(), d3);
                final IBlockState iblockstate2 = this.zues.a.zeroday(blockpos);
                if (iblockstate2.sigma().a()) {
                    iblockstate = iblockstate2;
                }
            }
            if (iblockstate.sigma().c() != -1) {
                this.zerodayisaminecraftcheat(partialTicks, this.zues.X().zerodayisaminecraftcheat().zerodayisaminecraftcheat(iblockstate));
            }
        }
        if (!this.zues.e.h_()) {
            if (this.zues.e.zerodayisaminecraftcheat(Material.momgetthecamera)) {
                this.flux(partialTicks);
            }
            if (this.zues.e.am()) {
                this.vape(partialTicks);
            }
        }
        GlStateManager.pandora();
    }
    
    private void zerodayisaminecraftcheat(final float p_178108_1_, final TextureAtlasSprite p_178108_2_) {
        this.zues.I().zerodayisaminecraftcheat(TextureMap.zeroday);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final float f = 0.1f;
        GlStateManager.sigma(0.1f, 0.1f, 0.1f, 0.5f);
        GlStateManager.v();
        final float f2 = -1.0f;
        final float f3 = 1.0f;
        final float f4 = -1.0f;
        final float f5 = 1.0f;
        final float f6 = -0.5f;
        final float f7 = p_178108_2_.zues();
        final float f8 = p_178108_2_.flux();
        final float f9 = p_178108_2_.vape();
        final float f10 = p_178108_2_.momgetthecamera();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(-1.0, -1.0, -0.5).zerodayisaminecraftcheat(f8, f10).zues();
        worldrenderer.zeroday(1.0, -1.0, -0.5).zerodayisaminecraftcheat(f7, f10).zues();
        worldrenderer.zeroday(1.0, 1.0, -0.5).zerodayisaminecraftcheat(f7, f9).zues();
        worldrenderer.zeroday(-1.0, 1.0, -0.5).zerodayisaminecraftcheat(f8, f9).zues();
        tessellator.zeroday();
        GlStateManager.w();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    private void flux(final float p_78448_1_) {
        this.zues.I().zerodayisaminecraftcheat(ItemRenderer.pandora);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final float f = this.zues.e.zeroday(p_78448_1_);
        GlStateManager.sigma(f, f, f, 0.5f);
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.v();
        final float f2 = 4.0f;
        final float f3 = -1.0f;
        final float f4 = 1.0f;
        final float f5 = -1.0f;
        final float f6 = 1.0f;
        final float f7 = -0.5f;
        final float f8 = -this.zues.e.y / 64.0f;
        final float f9 = this.zues.e.z / 64.0f;
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(-1.0, -1.0, -0.5).zerodayisaminecraftcheat(4.0f + f8, 4.0f + f9).zues();
        worldrenderer.zeroday(1.0, -1.0, -0.5).zerodayisaminecraftcheat(0.0f + f8, 4.0f + f9).zues();
        worldrenderer.zeroday(1.0, 1.0, -0.5).zerodayisaminecraftcheat(0.0f + f8, 0.0f + f9).zues();
        worldrenderer.zeroday(-1.0, 1.0, -0.5).zerodayisaminecraftcheat(4.0f + f8, 0.0f + f9).zues();
        tessellator.zeroday();
        GlStateManager.w();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.c();
    }
    
    private void vape(final float p_78442_1_) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 0.9f);
        GlStateManager.sigma(519);
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        final float f = 1.0f;
        for (int i = 0; i < 2; ++i) {
            GlStateManager.v();
            final TextureAtlasSprite textureatlassprite = this.zues.M().zerodayisaminecraftcheat("minecraft:blocks/fire_layer_1");
            this.zues.I().zerodayisaminecraftcheat(TextureMap.zeroday);
            final float f2 = textureatlassprite.zues();
            final float f3 = textureatlassprite.flux();
            final float f4 = textureatlassprite.vape();
            final float f5 = textureatlassprite.momgetthecamera();
            final float f6 = (0.0f - f) / 2.0f;
            final float f7 = f6 + f;
            final float f8 = 0.0f - f / 2.0f;
            final float f9 = f8 + f;
            final float f10 = -0.5f;
            GlStateManager.zeroday(-(i * 2 - 1) * 0.24f, -0.3f, 0.0f);
            GlStateManager.zeroday((i * 2 - 1) * 10.0f, 0.0f, 1.0f, 0.0f);
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
            worldrenderer.zeroday(f6, f8, (double)f10).zerodayisaminecraftcheat(f3, f5).zues();
            worldrenderer.zeroday(f7, f8, (double)f10).zerodayisaminecraftcheat(f2, f5).zues();
            worldrenderer.zeroday(f7, f9, (double)f10).zerodayisaminecraftcheat(f2, f4).zues();
            worldrenderer.zeroday(f6, f9, (double)f10).zerodayisaminecraftcheat(f3, f4).zues();
            tessellator.zeroday();
            GlStateManager.w();
        }
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.c();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.sigma(515);
    }
    
    public void zerodayisaminecraftcheat() {
        this.momgetthecamera = this.vape;
        final EntityPlayer entityplayer = this.zues.e;
        final ItemStack itemstack = entityplayer.d.pandora();
        boolean flag = false;
        if (this.flux != null && itemstack != null) {
            if (!this.flux.sigma(itemstack)) {
                flag = true;
            }
        }
        else {
            flag = (this.flux != null || itemstack != null);
        }
        final float f = 0.4f;
        final float f2 = flag ? 0.0f : 1.0f;
        final float f3 = MathHelper.zerodayisaminecraftcheat(f2 - this.vape, -f, f);
        this.vape += f3;
        if (this.vape < 0.1f) {
            this.flux = itemstack;
            this.c = entityplayer.d.sigma;
        }
    }
    
    public void zeroday() {
        this.vape = 0.0f;
    }
    
    public void sigma() {
        this.vape = 0.0f;
    }
    
    static /* synthetic */ int[] pandora() {
        final int[] d = ItemRenderer.d;
        if (d != null) {
            return d;
        }
        final int[] d2 = new int[EnumAction.values().length];
        try {
            d2[EnumAction.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            d2[EnumAction.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            d2[EnumAction.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            d2[EnumAction.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            d2[EnumAction.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        return ItemRenderer.d = d2;
    }
}

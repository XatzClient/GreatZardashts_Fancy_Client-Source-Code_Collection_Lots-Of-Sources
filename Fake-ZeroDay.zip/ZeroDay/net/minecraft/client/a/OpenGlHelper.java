// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.EXTBlendFuncSeparate;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.ARBMultitexture;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.ARBFramebufferObject;
import org.lwjgl.opengl.GL30;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.ARBVertexBufferObject;
import org.lwjgl.opengl.ARBVertexShader;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ByteBuffer;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.ARBShaderObjects;
import oshi.hardware.Processor;
import org.lwjgl.opengl.ContextCapabilities;
import oshi.SystemInfo;
import net.minecraft.client.c.GameSettings;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import net.minecraft.l.Config;

public class OpenGlHelper
{
    public static boolean zerodayisaminecraftcheat;
    public static boolean zeroday;
    public static int sigma;
    public static int pandora;
    public static int zues;
    public static int flux;
    public static int vape;
    public static int momgetthecamera;
    public static int a;
    public static int b;
    public static int c;
    private static int N;
    public static boolean d;
    private static boolean O;
    private static boolean P;
    public static int e;
    public static int f;
    public static int g;
    public static int h;
    private static boolean Q;
    public static int i;
    public static int j;
    public static int k;
    private static boolean R;
    public static int l;
    public static int m;
    public static int n;
    public static int o;
    public static int p;
    public static int q;
    public static int r;
    public static int s;
    public static int t;
    public static int u;
    public static int v;
    public static int w;
    public static int x;
    public static int y;
    public static int z;
    public static int A;
    public static int B;
    public static int C;
    public static int D;
    private static boolean S;
    public static boolean E;
    public static boolean F;
    public static boolean G;
    private static String T;
    private static String U;
    public static boolean H;
    public static boolean I;
    private static boolean V;
    public static int J;
    public static int K;
    private static final String W = "CL_00001179";
    public static float L;
    public static float M;
    
    static {
        OpenGlHelper.T = "";
        OpenGlHelper.L = 0.0f;
        OpenGlHelper.M = 0.0f;
    }
    
    public static void zerodayisaminecraftcheat() {
        Config.sigma();
        final ContextCapabilities contextcapabilities = GLContext.getCapabilities();
        OpenGlHelper.Q = (contextcapabilities.GL_ARB_multitexture && !contextcapabilities.OpenGL13);
        OpenGlHelper.R = (contextcapabilities.GL_ARB_texture_env_combine && !contextcapabilities.OpenGL13);
        if (OpenGlHelper.Q) {
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "Using ARB_multitexture.\n";
            OpenGlHelper.i = 33984;
            OpenGlHelper.j = 33985;
            OpenGlHelper.k = 33986;
        }
        else {
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "Using GL 1.3 multitexturing.\n";
            OpenGlHelper.i = 33984;
            OpenGlHelper.j = 33985;
            OpenGlHelper.k = 33986;
        }
        if (OpenGlHelper.R) {
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "Using ARB_texture_env_combine.\n";
            OpenGlHelper.l = 34160;
            OpenGlHelper.m = 34165;
            OpenGlHelper.n = 34167;
            OpenGlHelper.o = 34166;
            OpenGlHelper.p = 34168;
            OpenGlHelper.q = 34161;
            OpenGlHelper.r = 34176;
            OpenGlHelper.s = 34177;
            OpenGlHelper.t = 34178;
            OpenGlHelper.u = 34192;
            OpenGlHelper.v = 34193;
            OpenGlHelper.w = 34194;
            OpenGlHelper.x = 34162;
            OpenGlHelper.y = 34184;
            OpenGlHelper.z = 34185;
            OpenGlHelper.A = 34186;
            OpenGlHelper.B = 34200;
            OpenGlHelper.C = 34201;
            OpenGlHelper.D = 34202;
        }
        else {
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "Using GL 1.3 texture combiners.\n";
            OpenGlHelper.l = 34160;
            OpenGlHelper.m = 34165;
            OpenGlHelper.n = 34167;
            OpenGlHelper.o = 34166;
            OpenGlHelper.p = 34168;
            OpenGlHelper.q = 34161;
            OpenGlHelper.r = 34176;
            OpenGlHelper.s = 34177;
            OpenGlHelper.t = 34178;
            OpenGlHelper.u = 34192;
            OpenGlHelper.v = 34193;
            OpenGlHelper.w = 34194;
            OpenGlHelper.x = 34162;
            OpenGlHelper.y = 34184;
            OpenGlHelper.z = 34185;
            OpenGlHelper.A = 34186;
            OpenGlHelper.B = 34200;
            OpenGlHelper.C = 34201;
            OpenGlHelper.D = 34202;
        }
        OpenGlHelper.E = (contextcapabilities.GL_EXT_blend_func_separate && !contextcapabilities.OpenGL14);
        OpenGlHelper.S = (contextcapabilities.OpenGL14 || contextcapabilities.GL_EXT_blend_func_separate);
        OpenGlHelper.d = (OpenGlHelper.S && (contextcapabilities.GL_ARB_framebuffer_object || contextcapabilities.GL_EXT_framebuffer_object || contextcapabilities.OpenGL30));
        if (OpenGlHelper.d) {
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "Using framebuffer objects because ";
            if (contextcapabilities.OpenGL30) {
                OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "OpenGL 3.0 is supported and separate blending is supported.\n";
                OpenGlHelper.N = 0;
                OpenGlHelper.sigma = 36160;
                OpenGlHelper.pandora = 36161;
                OpenGlHelper.zues = 36064;
                OpenGlHelper.flux = 36096;
                OpenGlHelper.vape = 36053;
                OpenGlHelper.momgetthecamera = 36054;
                OpenGlHelper.a = 36055;
                OpenGlHelper.b = 36059;
                OpenGlHelper.c = 36060;
            }
            else if (contextcapabilities.GL_ARB_framebuffer_object) {
                OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "ARB_framebuffer_object is supported and separate blending is supported.\n";
                OpenGlHelper.N = 1;
                OpenGlHelper.sigma = 36160;
                OpenGlHelper.pandora = 36161;
                OpenGlHelper.zues = 36064;
                OpenGlHelper.flux = 36096;
                OpenGlHelper.vape = 36053;
                OpenGlHelper.a = 36055;
                OpenGlHelper.momgetthecamera = 36054;
                OpenGlHelper.b = 36059;
                OpenGlHelper.c = 36060;
            }
            else if (contextcapabilities.GL_EXT_framebuffer_object) {
                OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "EXT_framebuffer_object is supported.\n";
                OpenGlHelper.N = 2;
                OpenGlHelper.sigma = 36160;
                OpenGlHelper.pandora = 36161;
                OpenGlHelper.zues = 36064;
                OpenGlHelper.flux = 36096;
                OpenGlHelper.vape = 36053;
                OpenGlHelper.a = 36055;
                OpenGlHelper.momgetthecamera = 36054;
                OpenGlHelper.b = 36059;
                OpenGlHelper.c = 36060;
            }
        }
        else {
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "Not using framebuffer objects because ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "OpenGL 1.4 is " + (contextcapabilities.OpenGL14 ? "" : "not ") + "supported, ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "EXT_blend_func_separate is " + (contextcapabilities.GL_EXT_blend_func_separate ? "" : "not ") + "supported, ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "OpenGL 3.0 is " + (contextcapabilities.OpenGL30 ? "" : "not ") + "supported, ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "ARB_framebuffer_object is " + (contextcapabilities.GL_ARB_framebuffer_object ? "" : "not ") + "supported, and ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "EXT_framebuffer_object is " + (contextcapabilities.GL_EXT_framebuffer_object ? "" : "not ") + "supported.\n";
        }
        OpenGlHelper.F = contextcapabilities.OpenGL21;
        OpenGlHelper.O = (OpenGlHelper.F || (contextcapabilities.GL_ARB_vertex_shader && contextcapabilities.GL_ARB_fragment_shader && contextcapabilities.GL_ARB_shader_objects));
        OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "Shaders are " + (OpenGlHelper.O ? "" : "not ") + "available because ";
        if (OpenGlHelper.O) {
            if (contextcapabilities.OpenGL21) {
                OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "OpenGL 2.1 is supported.\n";
                OpenGlHelper.P = false;
                OpenGlHelper.e = 35714;
                OpenGlHelper.f = 35713;
                OpenGlHelper.g = 35633;
                OpenGlHelper.h = 35632;
            }
            else {
                OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "ARB_shader_objects, ARB_vertex_shader, and ARB_fragment_shader are supported.\n";
                OpenGlHelper.P = true;
                OpenGlHelper.e = 35714;
                OpenGlHelper.f = 35713;
                OpenGlHelper.g = 35633;
                OpenGlHelper.h = 35632;
            }
        }
        else {
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "OpenGL 2.1 is " + (contextcapabilities.OpenGL21 ? "" : "not ") + "supported, ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "ARB_shader_objects is " + (contextcapabilities.GL_ARB_shader_objects ? "" : "not ") + "supported, ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "ARB_vertex_shader is " + (contextcapabilities.GL_ARB_vertex_shader ? "" : "not ") + "supported, and ";
            OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "ARB_fragment_shader is " + (contextcapabilities.GL_ARB_fragment_shader ? "" : "not ") + "supported.\n";
        }
        OpenGlHelper.G = (OpenGlHelper.d && OpenGlHelper.O);
        final String s = GL11.glGetString(7936).toLowerCase();
        OpenGlHelper.zerodayisaminecraftcheat = s.contains("nvidia");
        OpenGlHelper.V = (!contextcapabilities.OpenGL15 && contextcapabilities.GL_ARB_vertex_buffer_object);
        OpenGlHelper.H = (contextcapabilities.OpenGL15 || OpenGlHelper.V);
        OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "VBOs are " + (OpenGlHelper.H ? "" : "not ") + "available because ";
        if (OpenGlHelper.H) {
            if (OpenGlHelper.V) {
                OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "ARB_vertex_buffer_object is supported.\n";
                OpenGlHelper.K = 35044;
                OpenGlHelper.J = 34962;
            }
            else {
                OpenGlHelper.T = String.valueOf(OpenGlHelper.T) + "OpenGL 1.5 is supported.\n";
                OpenGlHelper.K = 35044;
                OpenGlHelper.J = 34962;
            }
        }
        OpenGlHelper.zeroday = s.contains("ati");
        if (OpenGlHelper.zeroday) {
            if (OpenGlHelper.H) {
                OpenGlHelper.I = true;
            }
            else {
                GameSettings.zeroday.flux.zerodayisaminecraftcheat(16.0f);
            }
        }
        try {
            final Processor[] aprocessor = new SystemInfo().getHardware().getProcessors();
            OpenGlHelper.U = String.format("%dx %s", aprocessor.length, aprocessor[0]).replaceAll("\\s+", " ");
        }
        catch (Throwable t) {}
    }
    
    public static boolean zeroday() {
        return OpenGlHelper.G;
    }
    
    public static String sigma() {
        return OpenGlHelper.T;
    }
    
    public static int zerodayisaminecraftcheat(final int program, final int pname) {
        return OpenGlHelper.P ? ARBShaderObjects.glGetObjectParameteriARB(program, pname) : GL20.glGetProgrami(program, pname);
    }
    
    public static void zeroday(final int program, final int shaderIn) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glAttachObjectARB(program, shaderIn);
        }
        else {
            GL20.glAttachShader(program, shaderIn);
        }
    }
    
    public static void zerodayisaminecraftcheat(final int p_153180_0_) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glDeleteObjectARB(p_153180_0_);
        }
        else {
            GL20.glDeleteShader(p_153180_0_);
        }
    }
    
    public static int zeroday(final int type) {
        return OpenGlHelper.P ? ARBShaderObjects.glCreateShaderObjectARB(type) : GL20.glCreateShader(type);
    }
    
    public static void zerodayisaminecraftcheat(final int shaderIn, final ByteBuffer string) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glShaderSourceARB(shaderIn, string);
        }
        else {
            GL20.glShaderSource(shaderIn, string);
        }
    }
    
    public static void sigma(final int shaderIn) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glCompileShaderARB(shaderIn);
        }
        else {
            GL20.glCompileShader(shaderIn);
        }
    }
    
    public static int sigma(final int shaderIn, final int pname) {
        return OpenGlHelper.P ? ARBShaderObjects.glGetObjectParameteriARB(shaderIn, pname) : GL20.glGetShaderi(shaderIn, pname);
    }
    
    public static String pandora(final int shaderIn, final int maxLength) {
        return OpenGlHelper.P ? ARBShaderObjects.glGetInfoLogARB(shaderIn, maxLength) : GL20.glGetShaderInfoLog(shaderIn, maxLength);
    }
    
    public static String zues(final int program, final int maxLength) {
        return OpenGlHelper.P ? ARBShaderObjects.glGetInfoLogARB(program, maxLength) : GL20.glGetProgramInfoLog(program, maxLength);
    }
    
    public static void pandora(final int program) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUseProgramObjectARB(program);
        }
        else {
            GL20.glUseProgram(program);
        }
    }
    
    public static int pandora() {
        return OpenGlHelper.P ? ARBShaderObjects.glCreateProgramObjectARB() : GL20.glCreateProgram();
    }
    
    public static void zues(final int program) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glDeleteObjectARB(program);
        }
        else {
            GL20.glDeleteProgram(program);
        }
    }
    
    public static void flux(final int program) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glLinkProgramARB(program);
        }
        else {
            GL20.glLinkProgram(program);
        }
    }
    
    public static int zerodayisaminecraftcheat(final int programObj, final CharSequence name) {
        return OpenGlHelper.P ? ARBShaderObjects.glGetUniformLocationARB(programObj, name) : GL20.glGetUniformLocation(programObj, name);
    }
    
    public static void zerodayisaminecraftcheat(final int location, final IntBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform1ARB(location, values);
        }
        else {
            GL20.glUniform1(location, values);
        }
    }
    
    public static void flux(final int location, final int v0) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform1iARB(location, v0);
        }
        else {
            GL20.glUniform1i(location, v0);
        }
    }
    
    public static void zerodayisaminecraftcheat(final int location, final FloatBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform1ARB(location, values);
        }
        else {
            GL20.glUniform1(location, values);
        }
    }
    
    public static void zeroday(final int location, final IntBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform2ARB(location, values);
        }
        else {
            GL20.glUniform2(location, values);
        }
    }
    
    public static void zeroday(final int location, final FloatBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform2ARB(location, values);
        }
        else {
            GL20.glUniform2(location, values);
        }
    }
    
    public static void sigma(final int location, final IntBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform3ARB(location, values);
        }
        else {
            GL20.glUniform3(location, values);
        }
    }
    
    public static void sigma(final int location, final FloatBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform3ARB(location, values);
        }
        else {
            GL20.glUniform3(location, values);
        }
    }
    
    public static void pandora(final int location, final IntBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform4ARB(location, values);
        }
        else {
            GL20.glUniform4(location, values);
        }
    }
    
    public static void pandora(final int location, final FloatBuffer values) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniform4ARB(location, values);
        }
        else {
            GL20.glUniform4(location, values);
        }
    }
    
    public static void zerodayisaminecraftcheat(final int location, final boolean transpose, final FloatBuffer matrices) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniformMatrix2ARB(location, transpose, matrices);
        }
        else {
            GL20.glUniformMatrix2(location, transpose, matrices);
        }
    }
    
    public static void zeroday(final int location, final boolean transpose, final FloatBuffer matrices) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniformMatrix3ARB(location, transpose, matrices);
        }
        else {
            GL20.glUniformMatrix3(location, transpose, matrices);
        }
    }
    
    public static void sigma(final int location, final boolean transpose, final FloatBuffer matrices) {
        if (OpenGlHelper.P) {
            ARBShaderObjects.glUniformMatrix4ARB(location, transpose, matrices);
        }
        else {
            GL20.glUniformMatrix4(location, transpose, matrices);
        }
    }
    
    public static int zeroday(final int p_153164_0_, final CharSequence p_153164_1_) {
        return OpenGlHelper.P ? ARBVertexShader.glGetAttribLocationARB(p_153164_0_, p_153164_1_) : GL20.glGetAttribLocation(p_153164_0_, p_153164_1_);
    }
    
    public static int zues() {
        return OpenGlHelper.V ? ARBVertexBufferObject.glGenBuffersARB() : GL15.glGenBuffers();
    }
    
    public static void vape(final int target, final int buffer) {
        if (OpenGlHelper.V) {
            ARBVertexBufferObject.glBindBufferARB(target, buffer);
        }
        else {
            GL15.glBindBuffer(target, buffer);
        }
    }
    
    public static void zerodayisaminecraftcheat(final int target, final ByteBuffer data, final int usage) {
        if (OpenGlHelper.V) {
            ARBVertexBufferObject.glBufferDataARB(target, data, usage);
        }
        else {
            GL15.glBufferData(target, data, usage);
        }
    }
    
    public static void vape(final int buffer) {
        if (OpenGlHelper.V) {
            ARBVertexBufferObject.glDeleteBuffersARB(buffer);
        }
        else {
            GL15.glDeleteBuffers(buffer);
        }
    }
    
    public static boolean flux() {
        return !Config.ah() && (OpenGlHelper.H && Minecraft.s().r.m);
    }
    
    public static void momgetthecamera(final int target, final int framebufferIn) {
        if (OpenGlHelper.d) {
            switch (OpenGlHelper.N) {
                case 0: {
                    GL30.glBindFramebuffer(target, framebufferIn);
                    break;
                }
                case 1: {
                    ARBFramebufferObject.glBindFramebuffer(target, framebufferIn);
                    break;
                }
                case 2: {
                    EXTFramebufferObject.glBindFramebufferEXT(target, framebufferIn);
                    break;
                }
            }
        }
    }
    
    public static void a(final int target, final int renderbuffer) {
        if (OpenGlHelper.d) {
            switch (OpenGlHelper.N) {
                case 0: {
                    GL30.glBindRenderbuffer(target, renderbuffer);
                    break;
                }
                case 1: {
                    ARBFramebufferObject.glBindRenderbuffer(target, renderbuffer);
                    break;
                }
                case 2: {
                    EXTFramebufferObject.glBindRenderbufferEXT(target, renderbuffer);
                    break;
                }
            }
        }
    }
    
    public static void momgetthecamera(final int renderbuffer) {
        if (OpenGlHelper.d) {
            switch (OpenGlHelper.N) {
                case 0: {
                    GL30.glDeleteRenderbuffers(renderbuffer);
                    break;
                }
                case 1: {
                    ARBFramebufferObject.glDeleteRenderbuffers(renderbuffer);
                    break;
                }
                case 2: {
                    EXTFramebufferObject.glDeleteRenderbuffersEXT(renderbuffer);
                    break;
                }
            }
        }
    }
    
    public static void a(final int framebufferIn) {
        if (OpenGlHelper.d) {
            switch (OpenGlHelper.N) {
                case 0: {
                    GL30.glDeleteFramebuffers(framebufferIn);
                    break;
                }
                case 1: {
                    ARBFramebufferObject.glDeleteFramebuffers(framebufferIn);
                    break;
                }
                case 2: {
                    EXTFramebufferObject.glDeleteFramebuffersEXT(framebufferIn);
                    break;
                }
            }
        }
    }
    
    public static int vape() {
        if (!OpenGlHelper.d) {
            return -1;
        }
        switch (OpenGlHelper.N) {
            case 0: {
                return GL30.glGenFramebuffers();
            }
            case 1: {
                return ARBFramebufferObject.glGenFramebuffers();
            }
            case 2: {
                return EXTFramebufferObject.glGenFramebuffersEXT();
            }
            default: {
                return -1;
            }
        }
    }
    
    public static int momgetthecamera() {
        if (!OpenGlHelper.d) {
            return -1;
        }
        switch (OpenGlHelper.N) {
            case 0: {
                return GL30.glGenRenderbuffers();
            }
            case 1: {
                return ARBFramebufferObject.glGenRenderbuffers();
            }
            case 2: {
                return EXTFramebufferObject.glGenRenderbuffersEXT();
            }
            default: {
                return -1;
            }
        }
    }
    
    public static void zerodayisaminecraftcheat(final int target, final int internalFormat, final int width, final int height) {
        if (OpenGlHelper.d) {
            switch (OpenGlHelper.N) {
                case 0: {
                    GL30.glRenderbufferStorage(target, internalFormat, width, height);
                    break;
                }
                case 1: {
                    ARBFramebufferObject.glRenderbufferStorage(target, internalFormat, width, height);
                    break;
                }
                case 2: {
                    EXTFramebufferObject.glRenderbufferStorageEXT(target, internalFormat, width, height);
                    break;
                }
            }
        }
    }
    
    public static void zeroday(final int target, final int attachment, final int renderBufferTarget, final int renderBuffer) {
        if (OpenGlHelper.d) {
            switch (OpenGlHelper.N) {
                case 0: {
                    GL30.glFramebufferRenderbuffer(target, attachment, renderBufferTarget, renderBuffer);
                    break;
                }
                case 1: {
                    ARBFramebufferObject.glFramebufferRenderbuffer(target, attachment, renderBufferTarget, renderBuffer);
                    break;
                }
                case 2: {
                    EXTFramebufferObject.glFramebufferRenderbufferEXT(target, attachment, renderBufferTarget, renderBuffer);
                    break;
                }
            }
        }
    }
    
    public static int b(final int target) {
        if (!OpenGlHelper.d) {
            return -1;
        }
        switch (OpenGlHelper.N) {
            case 0: {
                return GL30.glCheckFramebufferStatus(target);
            }
            case 1: {
                return ARBFramebufferObject.glCheckFramebufferStatus(target);
            }
            case 2: {
                return EXTFramebufferObject.glCheckFramebufferStatusEXT(target);
            }
            default: {
                return -1;
            }
        }
    }
    
    public static void zerodayisaminecraftcheat(final int target, final int attachment, final int textarget, final int texture, final int level) {
        if (OpenGlHelper.d) {
            switch (OpenGlHelper.N) {
                case 0: {
                    GL30.glFramebufferTexture2D(target, attachment, textarget, texture, level);
                    break;
                }
                case 1: {
                    ARBFramebufferObject.glFramebufferTexture2D(target, attachment, textarget, texture, level);
                    break;
                }
                case 2: {
                    EXTFramebufferObject.glFramebufferTexture2DEXT(target, attachment, textarget, texture, level);
                    break;
                }
            }
        }
    }
    
    public static void c(final int texture) {
        if (OpenGlHelper.Q) {
            ARBMultitexture.glActiveTextureARB(texture);
        }
        else {
            GL13.glActiveTexture(texture);
        }
    }
    
    public static void d(final int texture) {
        if (OpenGlHelper.Q) {
            ARBMultitexture.glClientActiveTextureARB(texture);
        }
        else {
            GL13.glClientActiveTexture(texture);
        }
    }
    
    public static void zerodayisaminecraftcheat(final int target, final float p_77475_1_, final float p_77475_2_) {
        if (OpenGlHelper.Q) {
            ARBMultitexture.glMultiTexCoord2fARB(target, p_77475_1_, p_77475_2_);
        }
        else {
            GL13.glMultiTexCoord2f(target, p_77475_1_, p_77475_2_);
        }
        if (target == OpenGlHelper.j) {
            OpenGlHelper.L = p_77475_1_;
            OpenGlHelper.M = p_77475_2_;
        }
    }
    
    public static void sigma(final int sFactorRGB, final int dFactorRGB, final int sfactorAlpha, final int dfactorAlpha) {
        if (OpenGlHelper.S) {
            if (OpenGlHelper.E) {
                EXTBlendFuncSeparate.glBlendFuncSeparateEXT(sFactorRGB, dFactorRGB, sfactorAlpha, dfactorAlpha);
            }
            else {
                GL14.glBlendFuncSeparate(sFactorRGB, dFactorRGB, sfactorAlpha, dfactorAlpha);
            }
        }
        else {
            GL11.glBlendFunc(sFactorRGB, dFactorRGB);
        }
    }
    
    public static boolean a() {
        return !Config.aA() && !Config.af() && (OpenGlHelper.d && Minecraft.s().r.flux);
    }
    
    public static String b() {
        return (OpenGlHelper.U == null) ? "<unknown>" : OpenGlHelper.U;
    }
}

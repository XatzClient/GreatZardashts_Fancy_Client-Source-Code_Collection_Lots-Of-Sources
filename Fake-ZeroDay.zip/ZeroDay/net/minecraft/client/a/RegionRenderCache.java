// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.q.sigma.Chunk;
import net.minecraft.n.TileEntity;
import java.util.Arrays;
import net.minecraft.o.Vec3i;
import net.minecraft.q.World;
import net.minecraft.a.Blocks;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.q.ChunkCache;

public class RegionRenderCache extends ChunkCache
{
    private static final IBlockState flux;
    private final BlockPos vape;
    private int[] momgetthecamera;
    private IBlockState[] a;
    
    static {
        flux = Blocks.zerodayisaminecraftcheat.G();
    }
    
    public RegionRenderCache(final World worldIn, final BlockPos posFromIn, final BlockPos posToIn, final int subIn) {
        super(worldIn, posFromIn, posToIn, subIn);
        this.vape = posFromIn.zeroday(new Vec3i(subIn, subIn, subIn));
        final int i = 8000;
        Arrays.fill(this.momgetthecamera = new int[8000], -1);
        this.a = new IBlockState[8000];
    }
    
    @Override
    public TileEntity zerodayisaminecraftcheat(final BlockPos pos) {
        final int i = (pos.zerodayisaminecraftcheat() >> 4) - this.zerodayisaminecraftcheat;
        final int j = (pos.sigma() >> 4) - this.zeroday;
        return this.sigma[i][j].zerodayisaminecraftcheat(pos, Chunk.zerodayisaminecraftcheat.zeroday);
    }
    
    @Override
    public int zerodayisaminecraftcheat(final BlockPos pos, final int lightValue) {
        final int i = this.flux(pos);
        int j = this.momgetthecamera[i];
        if (j == -1) {
            j = super.zerodayisaminecraftcheat(pos, lightValue);
            this.momgetthecamera[i] = j;
        }
        return j;
    }
    
    @Override
    public IBlockState zeroday(final BlockPos pos) {
        final int i = this.flux(pos);
        IBlockState iblockstate = this.a[i];
        if (iblockstate == null) {
            iblockstate = this.zues(pos);
            this.a[i] = iblockstate;
        }
        return iblockstate;
    }
    
    private IBlockState zues(final BlockPos pos) {
        if (pos.zeroday() >= 0 && pos.zeroday() < 256) {
            final int i = (pos.zerodayisaminecraftcheat() >> 4) - this.zerodayisaminecraftcheat;
            final int j = (pos.sigma() >> 4) - this.zeroday;
            return this.sigma[i][j].pandora(pos);
        }
        return RegionRenderCache.flux;
    }
    
    private int flux(final BlockPos p_175630_1_) {
        final int i = p_175630_1_.zerodayisaminecraftcheat() - this.vape.zerodayisaminecraftcheat();
        final int j = p_175630_1_.zeroday() - this.vape.zeroday();
        final int k = p_175630_1_.sigma() - this.vape.sigma();
        return i * 400 + k * 20 + j;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.o.EnumWorldBlockLayer;

public class RegionRenderCacheBuilder
{
    private final WorldRenderer[] zerodayisaminecraftcheat;
    
    public RegionRenderCacheBuilder() {
        (this.zerodayisaminecraftcheat = new WorldRenderer[EnumWorldBlockLayer.values().length])[EnumWorldBlockLayer.zerodayisaminecraftcheat.ordinal()] = new WorldRenderer(2097152);
        this.zerodayisaminecraftcheat[EnumWorldBlockLayer.sigma.ordinal()] = new WorldRenderer(131072);
        this.zerodayisaminecraftcheat[EnumWorldBlockLayer.zeroday.ordinal()] = new WorldRenderer(131072);
        this.zerodayisaminecraftcheat[EnumWorldBlockLayer.pandora.ordinal()] = new WorldRenderer(262144);
    }
    
    public WorldRenderer zerodayisaminecraftcheat(final EnumWorldBlockLayer layer) {
        return this.zerodayisaminecraftcheat[layer.ordinal()];
    }
    
    public WorldRenderer zerodayisaminecraftcheat(final int id) {
        return this.zerodayisaminecraftcheat[id];
    }
}

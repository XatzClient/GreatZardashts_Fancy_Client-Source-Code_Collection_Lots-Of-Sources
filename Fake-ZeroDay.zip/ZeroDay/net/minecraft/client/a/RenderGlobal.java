// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.util.EnumSet;
import net.minecraft.c.ItemDye;
import net.minecraft.a.Items;
import net.minecraft.c.Item;
import net.minecraft.l.RandomMobs;
import net.minecraft.client.vape.EntityFX;
import net.minecraft.o.EnumParticleTypes;
import net.minecraft.o.ReportedException;
import net.minecraft.sigma.CrashReportCategory;
import java.util.concurrent.Callable;
import net.minecraft.sigma.CrashReport;
import net.minecraft.client.zerodayisaminecraftcheat.PositionedSoundRecord;
import net.minecraft.c.ItemRecord;
import net.minecraft.client.zerodayisaminecraftcheat.ISound;
import zeroday.pandora.zerodayisaminecraftcheat.h.V;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.a;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.q.zeroday.WorldBorder;
import net.minecraft.o.Vec3;
import net.minecraft.q.WorldProvider;
import net.minecraft.l.CustomSky;
import net.minecraft.q.IBlockAccess;
import net.minecraft.l.CustomColorizer;
import sigma.zerodayisaminecraftcheat.k;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.o.Matrix4f;
import net.minecraft.client.a.sigma.ClippingHelperImpl;
import net.minecraft.client.a.zeroday.VisGraph;
import org.lwjgl.util.vector.Vector3f;
import net.minecraft.client.a.zeroday.RenderChunk;
import net.minecraft.l.ChunkUtils;
import net.minecraft.l.Lagometer;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.sigma.Frustum;
import net.minecraft.client.a.zeroday.CompiledChunk;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.o.ClassInheritanceMultiMap;
import net.minecraft.q.sigma.Chunk;
import java.util.Iterator;
import net.minecraft.zerodayisaminecraftcheat.BlockSkull;
import net.minecraft.zerodayisaminecraftcheat.BlockSign;
import net.minecraft.zerodayisaminecraftcheat.BlockEnderChest;
import net.minecraft.zerodayisaminecraftcheat.BlockChest;
import net.minecraft.n.TileEntityChest;
import net.minecraft.n.TileEntitySign;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.n.TileEntity;
import net.minecraft.vape.momgetthecamera.EntityWitherSkull;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.o.BlockPos;
import sigma.zerodayisaminecraftcheat.j;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.flux.TileEntityRendererDispatcher;
import net.minecraft.l.Reflector;
import net.minecraft.client.a.sigma.ICamera;
import net.minecraft.l.Config;
import net.minecraft.a.Blocks;
import net.minecraft.q.World;
import java.util.Random;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import net.minecraft.client.d.ShaderLinkHelper;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.b.IResourceManager;
import net.minecraft.client.a.vape.VertexFormatElement;
import net.minecraft.client.a.zeroday.ListChunkFactory;
import net.minecraft.client.a.zeroday.VboChunkFactory;
import org.lwjgl.opengl.GL11;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.LinkedHashSet;
import com.google.common.collect.Maps;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Collections;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import net.minecraft.o.EnumFacing;
import org.apache.logging.log4j.LogManager;
import java.util.Deque;
import net.minecraft.vape.Entity;
import net.minecraft.l.CloudRenderer;
import net.minecraft.client.a.zeroday.IRenderChunkFactory;
import net.minecraft.o.Vector3d;
import org.lwjgl.util.vector.Vector4f;
import net.minecraft.client.a.sigma.ClippingHelper;
import net.minecraft.client.a.zeroday.ChunkRenderDispatcher;
import net.minecraft.client.d.ShaderGroup;
import net.minecraft.client.d.Framebuffer;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import java.util.Map;
import net.minecraft.client.a.vape.VertexBuffer;
import net.minecraft.client.a.vape.VertexFormat;
import java.util.List;
import java.util.Set;
import net.minecraft.client.zues.WorldClient;
import net.minecraft.client.a.pandora.RenderManager;
import net.minecraft.client.a.zues.TextureManager;
import net.minecraft.client.Minecraft;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;
import net.minecraft.q.IWorldAccess;
import net.minecraft.client.b.IResourceManagerReloadListener;

public class RenderGlobal implements IResourceManagerReloadListener, IWorldAccess
{
    private static final Logger momgetthecamera;
    private static final ResourceLocation a;
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    private static final ResourceLocation d;
    private static final ResourceLocation e;
    public final Minecraft zerodayisaminecraftcheat;
    private final TextureManager f;
    private final RenderManager g;
    private WorldClient h;
    private Set i;
    private List j;
    private final Set k;
    private ViewFrustum l;
    private int m;
    private int n;
    private int o;
    private VertexFormat p;
    private VertexBuffer q;
    private VertexBuffer r;
    private VertexBuffer s;
    private int t;
    public final Map zeroday;
    private final Map u;
    private final TextureAtlasSprite[] v;
    private Framebuffer w;
    private ShaderGroup x;
    private double y;
    private double z;
    private double A;
    private int B;
    private int C;
    private int D;
    private double E;
    private double F;
    private double G;
    private double H;
    private double I;
    private final ChunkRenderDispatcher J;
    private ChunkRenderContainer K;
    private int L;
    private int M;
    private int N;
    private int O;
    private int P;
    private boolean Q;
    private ClippingHelper R;
    private final Vector4f[] S;
    private final Vector3d T;
    private boolean U;
    IRenderChunkFactory sigma;
    private double V;
    private double W;
    private double X;
    public boolean pandora;
    private static final String Y = "CL_00000954";
    private CloudRenderer Z;
    public Entity zues;
    public Set flux;
    public Set vape;
    private Deque aa;
    private List ab;
    private List ac;
    private List ad;
    private List ae;
    private List af;
    private List ag;
    private List ah;
    private List ai;
    private int aj;
    private int ak;
    private static final Set al;
    private int am;
    
    static {
        momgetthecamera = LogManager.getLogger();
        a = new ResourceLocation("textures/environment/moon_phases.png");
        b = new ResourceLocation("textures/environment/sun.png");
        c = new ResourceLocation("textures/environment/clouds.png");
        d = new ResourceLocation("textures/environment/end_sky.png");
        e = new ResourceLocation("textures/misc/forcefield.png");
        al = Collections.unmodifiableSet((Set<?>)new HashSet<Object>(Arrays.asList(EnumFacing.vape)));
    }
    
    public RenderGlobal(final Minecraft mcIn) {
        this.i = Sets.newLinkedHashSet();
        this.j = Lists.newArrayListWithCapacity(69696);
        this.k = Sets.newHashSet();
        this.m = -1;
        this.n = -1;
        this.o = -1;
        this.zeroday = Maps.newHashMap();
        this.u = Maps.newHashMap();
        this.v = new TextureAtlasSprite[10];
        this.y = Double.MIN_VALUE;
        this.z = Double.MIN_VALUE;
        this.A = Double.MIN_VALUE;
        this.B = Integer.MIN_VALUE;
        this.C = Integer.MIN_VALUE;
        this.D = Integer.MIN_VALUE;
        this.E = Double.MIN_VALUE;
        this.F = Double.MIN_VALUE;
        this.G = Double.MIN_VALUE;
        this.H = Double.MIN_VALUE;
        this.I = Double.MIN_VALUE;
        this.J = new ChunkRenderDispatcher();
        this.L = -1;
        this.M = 2;
        this.Q = false;
        this.S = new Vector4f[8];
        this.T = new Vector3d();
        this.U = false;
        this.pandora = true;
        this.flux = new LinkedHashSet();
        this.vape = new LinkedHashSet();
        this.aa = new ArrayDeque();
        this.ab = new ArrayList(1024);
        this.ac = new ArrayList(1024);
        this.ad = new ArrayList(1024);
        this.ae = new ArrayList(1024);
        this.af = new ArrayList(1024);
        this.ag = new ArrayList(1024);
        this.ah = new ArrayList(1024);
        this.ai = new ArrayList(1024);
        this.aj = 0;
        this.ak = 0;
        this.Z = new CloudRenderer(mcIn);
        this.zerodayisaminecraftcheat = mcIn;
        this.g = mcIn.Y();
        (this.f = mcIn.I()).zerodayisaminecraftcheat(RenderGlobal.e);
        GL11.glTexParameteri(3553, 10242, 10497);
        GL11.glTexParameteri(3553, 10243, 10497);
        GlStateManager.a(0);
        this.h();
        this.U = OpenGlHelper.flux();
        if (this.U) {
            this.K = new VboRenderList();
            this.sigma = new VboChunkFactory();
        }
        else {
            this.K = new RenderList();
            this.sigma = new ListChunkFactory();
        }
        (this.p = new VertexFormat()).zerodayisaminecraftcheat(new VertexFormatElement(0, VertexFormatElement.zerodayisaminecraftcheat.zerodayisaminecraftcheat, VertexFormatElement.zeroday.zerodayisaminecraftcheat, 3));
        this.k();
        this.j();
        this.i();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        this.h();
    }
    
    private void h() {
        final TextureMap texturemap = this.zerodayisaminecraftcheat.M();
        for (int i = 0; i < this.v.length; ++i) {
            this.v[i] = texturemap.zerodayisaminecraftcheat("minecraft:blocks/destroy_stage_" + i);
        }
    }
    
    public void zerodayisaminecraftcheat() {
        if (OpenGlHelper.G) {
            if (ShaderLinkHelper.zeroday() == null) {
                ShaderLinkHelper.zerodayisaminecraftcheat();
            }
            final ResourceLocation resourcelocation = new ResourceLocation("shaders/post/entity_outline.json");
            try {
                (this.x = new ShaderGroup(this.zerodayisaminecraftcheat.I(), this.zerodayisaminecraftcheat.J(), this.zerodayisaminecraftcheat.sigma(), resourcelocation)).zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.flux, this.zerodayisaminecraftcheat.vape);
                this.w = this.x.zerodayisaminecraftcheat("final");
            }
            catch (IOException ioexception) {
                RenderGlobal.momgetthecamera.warn("Failed to load shader: " + resourcelocation, (Throwable)ioexception);
                this.x = null;
                this.w = null;
            }
            catch (JsonSyntaxException jsonsyntaxexception) {
                RenderGlobal.momgetthecamera.warn("Failed to load shader: " + resourcelocation, (Throwable)jsonsyntaxexception);
                this.x = null;
                this.w = null;
            }
        }
        else {
            this.x = null;
            this.w = null;
        }
    }
    
    public void zeroday() {
        if (this.sigma()) {
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 0, 1);
            this.w.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.flux, this.zerodayisaminecraftcheat.vape, false);
            GlStateManager.c();
        }
    }
    
    protected boolean sigma() {
        return this.w != null && this.x != null && this.zerodayisaminecraftcheat.e != null && this.zerodayisaminecraftcheat.e.h_() && this.zerodayisaminecraftcheat.r.ai.pandora();
    }
    
    private void i() {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        if (this.s != null) {
            this.s.sigma();
        }
        if (this.o >= 0) {
            GLAllocation.zeroday(this.o);
            this.o = -1;
        }
        if (this.U) {
            this.s = new VertexBuffer(this.p);
            this.zerodayisaminecraftcheat(worldrenderer, -16.0f, true);
            worldrenderer.flux();
            worldrenderer.sigma();
            this.s.zerodayisaminecraftcheat(worldrenderer.vape());
        }
        else {
            GL11.glNewList(this.o = GLAllocation.zerodayisaminecraftcheat(1), 4864);
            this.zerodayisaminecraftcheat(worldrenderer, -16.0f, true);
            tessellator.zeroday();
            GL11.glEndList();
        }
    }
    
    private void j() {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        if (this.r != null) {
            this.r.sigma();
        }
        if (this.n >= 0) {
            GLAllocation.zeroday(this.n);
            this.n = -1;
        }
        if (this.U) {
            this.r = new VertexBuffer(this.p);
            this.zerodayisaminecraftcheat(worldrenderer, 16.0f, false);
            worldrenderer.flux();
            worldrenderer.sigma();
            this.r.zerodayisaminecraftcheat(worldrenderer.vape());
        }
        else {
            GL11.glNewList(this.n = GLAllocation.zerodayisaminecraftcheat(1), 4864);
            this.zerodayisaminecraftcheat(worldrenderer, 16.0f, false);
            tessellator.zeroday();
            GL11.glEndList();
        }
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer worldRendererIn, final float p_174968_2_, final boolean p_174968_3_) {
        final boolean flag = true;
        final boolean flag2 = true;
        worldRendererIn.zerodayisaminecraftcheat(7, DefaultVertexFormats.zues);
        for (int i = -384; i <= 384; i += 64) {
            for (int j = -384; j <= 384; j += 64) {
                float f = (float)i;
                float f2 = (float)(i + 64);
                if (p_174968_3_) {
                    f2 = (float)i;
                    f = (float)(i + 64);
                }
                worldRendererIn.zeroday(f, p_174968_2_, (double)j).zues();
                worldRendererIn.zeroday(f2, p_174968_2_, (double)j).zues();
                worldRendererIn.zeroday(f2, p_174968_2_, (double)(j + 64)).zues();
                worldRendererIn.zeroday(f, p_174968_2_, (double)(j + 64)).zues();
            }
        }
    }
    
    private void k() {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        if (this.q != null) {
            this.q.sigma();
        }
        if (this.m >= 0) {
            GLAllocation.zeroday(this.m);
            this.m = -1;
        }
        if (this.U) {
            this.q = new VertexBuffer(this.p);
            this.zerodayisaminecraftcheat(worldrenderer);
            worldrenderer.flux();
            worldrenderer.sigma();
            this.q.zerodayisaminecraftcheat(worldrenderer.vape());
        }
        else {
            this.m = GLAllocation.zerodayisaminecraftcheat(1);
            GlStateManager.v();
            GL11.glNewList(this.m, 4864);
            this.zerodayisaminecraftcheat(worldrenderer);
            tessellator.zeroday();
            GL11.glEndList();
            GlStateManager.w();
        }
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer worldRendererIn) {
        final Random random = new Random(10842L);
        worldRendererIn.zerodayisaminecraftcheat(7, DefaultVertexFormats.zues);
        for (int i = 0; i < 1500; ++i) {
            double d0 = random.nextFloat() * 2.0f - 1.0f;
            double d2 = random.nextFloat() * 2.0f - 1.0f;
            double d3 = random.nextFloat() * 2.0f - 1.0f;
            final double d4 = 0.15f + random.nextFloat() * 0.1f;
            double d5 = d0 * d0 + d2 * d2 + d3 * d3;
            if (d5 < 1.0 && d5 > 0.01) {
                d5 = 1.0 / Math.sqrt(d5);
                d0 *= d5;
                d2 *= d5;
                d3 *= d5;
                final double d6 = d0 * 100.0;
                final double d7 = d2 * 100.0;
                final double d8 = d3 * 100.0;
                final double d9 = Math.atan2(d0, d3);
                final double d10 = Math.sin(d9);
                final double d11 = Math.cos(d9);
                final double d12 = Math.atan2(Math.sqrt(d0 * d0 + d3 * d3), d2);
                final double d13 = Math.sin(d12);
                final double d14 = Math.cos(d12);
                final double d15 = random.nextDouble() * 3.141592653589793 * 2.0;
                final double d16 = Math.sin(d15);
                final double d17 = Math.cos(d15);
                for (int j = 0; j < 4; ++j) {
                    final double d18 = 0.0;
                    final double d19 = ((j & 0x2) - 1) * d4;
                    final double d20 = ((j + 1 & 0x2) - 1) * d4;
                    final double d21 = 0.0;
                    final double d22 = d19 * d17 - d20 * d16;
                    final double d23 = d20 * d17 + d19 * d16;
                    final double d24 = d22 * d13 + 0.0 * d14;
                    final double d25 = 0.0 * d13 - d22 * d14;
                    final double d26 = d25 * d10 - d23 * d11;
                    final double d27 = d23 * d10 + d25 * d11;
                    worldRendererIn.zeroday(d6 + d26, d7 + d24, d8 + d27).zues();
                }
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final WorldClient worldClientIn) {
        if (this.h != null) {
            this.h.zeroday(this);
        }
        this.y = Double.MIN_VALUE;
        this.z = Double.MIN_VALUE;
        this.A = Double.MIN_VALUE;
        this.B = Integer.MIN_VALUE;
        this.C = Integer.MIN_VALUE;
        this.D = Integer.MIN_VALUE;
        this.g.zerodayisaminecraftcheat(worldClientIn);
        if ((this.h = worldClientIn) != null) {
            worldClientIn.zerodayisaminecraftcheat(this);
            this.pandora();
        }
    }
    
    public void pandora() {
        if (this.h != null) {
            this.pandora = true;
            Blocks.l.zeroday(Config.r());
            Blocks.m.zeroday(Config.r());
            BlockModelRenderer.zerodayisaminecraftcheat();
            this.L = this.zerodayisaminecraftcheat.r.sigma;
            this.aj = this.L * 16;
            this.ak = this.aj * this.aj;
            final boolean flag = this.U;
            this.U = OpenGlHelper.flux();
            if (flag && !this.U) {
                this.K = new RenderList();
                this.sigma = new ListChunkFactory();
            }
            else if (!flag && this.U) {
                this.K = new VboRenderList();
                this.sigma = new VboChunkFactory();
            }
            if (flag != this.U) {
                this.k();
                this.j();
                this.i();
            }
            if (this.l != null) {
                this.l.zerodayisaminecraftcheat();
            }
            this.zues();
            final Set var5 = this.k;
            synchronized (this.k) {
                this.k.clear();
            }
            // monitorexit(this.k)
            this.l = new ViewFrustum(this.h, this.zerodayisaminecraftcheat.r.sigma, this, this.sigma);
            if (this.h != null) {
                final Entity entity = this.zerodayisaminecraftcheat.V();
                if (entity != null) {
                    this.l.zerodayisaminecraftcheat(entity.s, entity.u);
                }
            }
            this.M = 2;
        }
    }
    
    protected void zues() {
        this.i.clear();
        this.J.zeroday();
    }
    
    public void zerodayisaminecraftcheat(final int p_72720_1_, final int p_72720_2_) {
        if (OpenGlHelper.G && this.x != null) {
            this.x.zerodayisaminecraftcheat(p_72720_1_, p_72720_2_);
        }
    }
    
    public void zerodayisaminecraftcheat(final Entity renderViewEntity, final ICamera camera, final float partialTicks) {
        int i = 0;
        if (Reflector.e.zeroday()) {
            i = Reflector.sigma(Reflector.e, new Object[0]);
        }
        if (this.M > 0) {
            if (i > 0) {
                return;
            }
            --this.M;
        }
        else {
            final double d0 = renderViewEntity.p + (renderViewEntity.s - renderViewEntity.p) * partialTicks;
            final double d2 = renderViewEntity.q + (renderViewEntity.t - renderViewEntity.q) * partialTicks;
            final double d3 = renderViewEntity.r + (renderViewEntity.u - renderViewEntity.r) * partialTicks;
            this.h.p.zerodayisaminecraftcheat("prepare");
            TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.h, this.zerodayisaminecraftcheat.I(), this.zerodayisaminecraftcheat.i, this.zerodayisaminecraftcheat.V(), partialTicks);
            this.g.zerodayisaminecraftcheat(this.h, this.zerodayisaminecraftcheat.i, this.zerodayisaminecraftcheat.V(), this.zerodayisaminecraftcheat.f, this.zerodayisaminecraftcheat.r, partialTicks);
            if (i == 0) {
                this.N = 0;
                this.O = 0;
                this.P = 0;
                this.am = 0;
            }
            final Entity entity = this.zerodayisaminecraftcheat.V();
            final double d4 = entity.Q + (entity.s - entity.Q) * partialTicks;
            final double d5 = entity.R + (entity.t - entity.R) * partialTicks;
            final double d6 = entity.S + (entity.u - entity.S) * partialTicks;
            TileEntityRendererDispatcher.zeroday = d4;
            TileEntityRendererDispatcher.sigma = d5;
            TileEntityRendererDispatcher.pandora = d6;
            this.g.zerodayisaminecraftcheat(d4, d5, d6);
            this.zerodayisaminecraftcheat.m.momgetthecamera();
            this.h.p.sigma("global");
            final List list = this.h.l();
            if (i == 0) {
                this.N = list.size();
            }
            if (Config.i() && this.zerodayisaminecraftcheat.m.d) {
                GlStateManager.f();
            }
            final boolean flag = Reflector.bc.zeroday();
            final boolean flag2 = Reflector.bf.zeroday();
            for (int j = 0; j < this.h.vape.size(); ++j) {
                final Entity entity2 = this.h.vape.get(j);
                if (!flag || Reflector.zeroday(entity2, Reflector.bc, i)) {
                    ++this.O;
                    if (entity2.momgetthecamera(d0, d2, d3)) {
                        this.g.zerodayisaminecraftcheat(entity2, partialTicks);
                    }
                }
            }
            if (this.sigma()) {
                GlStateManager.sigma(519);
                GlStateManager.f();
                this.w.flux();
                this.w.zerodayisaminecraftcheat(false);
                this.h.p.sigma("entityOutlines");
                RenderHelper.zerodayisaminecraftcheat();
                this.g.sigma(true);
                for (int k = 0; k < list.size(); ++k) {
                    final Entity entity3 = list.get(k);
                    if (!flag || Reflector.zeroday(entity3, Reflector.bc, i)) {
                        final boolean flag3 = this.zerodayisaminecraftcheat.V() instanceof EntityLivingBase && ((EntityLivingBase)this.zerodayisaminecraftcheat.V()).bS();
                        final boolean flag4 = entity3.momgetthecamera(d0, d2, d3) && (entity3.al || camera.zerodayisaminecraftcheat(entity3.aH()) || entity3.l == this.zerodayisaminecraftcheat.e) && entity3 instanceof EntityPlayer;
                        if ((entity3 != this.zerodayisaminecraftcheat.V() || this.zerodayisaminecraftcheat.r.as != 0 || flag3) && flag4) {
                            this.g.zerodayisaminecraftcheat(entity3, partialTicks);
                        }
                    }
                }
                this.g.sigma(false);
                RenderHelper.zeroday();
                GlStateManager.zerodayisaminecraftcheat(false);
                this.x.zerodayisaminecraftcheat(partialTicks);
                GlStateManager.zues();
                GlStateManager.zerodayisaminecraftcheat(true);
                this.zerodayisaminecraftcheat.sigma().zerodayisaminecraftcheat(false);
                GlStateManager.e();
                GlStateManager.d();
                GlStateManager.vape();
                GlStateManager.sigma(515);
                GlStateManager.b();
                GlStateManager.pandora();
            }
            this.h.p.sigma("entities");
            final boolean flag5 = Config.aC();
            if (flag5) {
                sigma.zerodayisaminecraftcheat.j.u();
            }
            final Iterator iterator1 = this.ab.iterator();
            final boolean flag6 = this.zerodayisaminecraftcheat.r.a;
            this.zerodayisaminecraftcheat.r.a = Config.s();
            while (iterator1.hasNext()) {
                final zerodayisaminecraftcheat renderglobal$containerlocalrenderinformation = iterator1.next();
                final Chunk chunk = this.h.vape(renderglobal$containerlocalrenderinformation.zerodayisaminecraftcheat.a());
                final ClassInheritanceMultiMap classinheritancemultimap = chunk.k()[renderglobal$containerlocalrenderinformation.zerodayisaminecraftcheat.a().zeroday() / 16];
                if (!classinheritancemultimap.isEmpty()) {
                    for (final Entity entity4 : classinheritancemultimap) {
                        if (!flag || Reflector.zeroday(entity4, Reflector.bc, i)) {
                            final boolean flag7 = this.g.zerodayisaminecraftcheat(entity4, camera, d0, d2, d3) || entity4.l == this.zerodayisaminecraftcheat.e;
                            if (flag7) {
                                final boolean flag8 = this.zerodayisaminecraftcheat.V() instanceof EntityLivingBase && ((EntityLivingBase)this.zerodayisaminecraftcheat.V()).bS();
                                if ((entity4 == this.zerodayisaminecraftcheat.V() && this.zerodayisaminecraftcheat.r.as == 0 && !flag8) || (entity4.t >= 0.0 && entity4.t < 256.0 && !this.h.flux(new BlockPos(entity4)))) {
                                    continue;
                                }
                                ++this.O;
                                if (entity4.getClass() == EntityItemFrame.class) {
                                    entity4.j = 0.06;
                                }
                                this.zues = entity4;
                                if (flag5) {
                                    sigma.zerodayisaminecraftcheat.j.v();
                                }
                                this.g.zerodayisaminecraftcheat(entity4, partialTicks);
                                this.zues = null;
                            }
                            if (flag7 || !(entity4 instanceof EntityWitherSkull)) {
                                continue;
                            }
                            if (flag5) {
                                sigma.zerodayisaminecraftcheat.j.v();
                            }
                            this.zerodayisaminecraftcheat.Y().zeroday(entity4, partialTicks);
                        }
                    }
                }
            }
            this.zerodayisaminecraftcheat.r.a = flag6;
            final FontRenderer fontrenderer = TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
            if (flag5) {
                sigma.zerodayisaminecraftcheat.j.x();
                sigma.zerodayisaminecraftcheat.j.B();
            }
            this.h.p.sigma("blockentities");
            RenderHelper.zeroday();
            for (final Object renderglobal$containerlocalrenderinformation2 : this.ac) {
                final List list2 = ((zerodayisaminecraftcheat)renderglobal$containerlocalrenderinformation2).zerodayisaminecraftcheat.vape().zeroday();
                if (!list2.isEmpty()) {
                    for (final TileEntity tileentity : list2) {
                        if (flag5) {
                            sigma.zerodayisaminecraftcheat.j.C();
                        }
                        if (flag2) {
                            if (!Reflector.zeroday(tileentity, Reflector.bf, i)) {
                                continue;
                            }
                            final AxisAlignedBB axisalignedbb = (AxisAlignedBB)Reflector.vape(tileentity, Reflector.bg, new Object[0]);
                            if (axisalignedbb != null && !camera.zerodayisaminecraftcheat(axisalignedbb)) {
                                continue;
                            }
                        }
                        final Class oclass = tileentity.getClass();
                        if (oclass == TileEntitySign.class && !Config.c) {
                            final EntityPlayer entityplayer = this.zerodayisaminecraftcheat.e;
                            final double d7 = tileentity.zerodayisaminecraftcheat(entityplayer.s, entityplayer.t, entityplayer.u);
                            if (d7 > 256.0) {
                                fontrenderer.flux = false;
                            }
                        }
                        TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(tileentity, partialTicks, -1);
                        ++this.am;
                        fontrenderer.flux = true;
                    }
                }
            }
            final Set var32 = this.k;
            synchronized (this.k) {
                for (final Object tileentity2 : this.k) {
                    if (flag5) {
                        sigma.zerodayisaminecraftcheat.j.C();
                    }
                    if (flag2) {
                        if (!Reflector.zeroday(tileentity2, Reflector.bf, i)) {
                            continue;
                        }
                        final AxisAlignedBB axisalignedbb2 = (AxisAlignedBB)Reflector.vape(tileentity2, Reflector.bg, new Object[0]);
                        if (axisalignedbb2 != null && !camera.zerodayisaminecraftcheat(axisalignedbb2)) {
                            continue;
                        }
                    }
                    final Class oclass2 = tileentity2.getClass();
                    if (oclass2 == TileEntitySign.class && !Config.c) {
                        final EntityPlayer entityplayer2 = this.zerodayisaminecraftcheat.e;
                        final double d8 = ((TileEntity)tileentity2).zerodayisaminecraftcheat(entityplayer2.s, entityplayer2.t, entityplayer2.u);
                        if (d8 > 256.0) {
                            fontrenderer.flux = false;
                        }
                    }
                    TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat((TileEntity)tileentity2, partialTicks, -1);
                    fontrenderer.flux = true;
                }
            }
            // monitorexit(this.k)
            this.m();
            for (final Object destroyblockprogress : this.zeroday.values()) {
                BlockPos blockpos = ((DestroyBlockProgress)destroyblockprogress).zerodayisaminecraftcheat();
                TileEntity tileentity3 = this.h.zerodayisaminecraftcheat(blockpos);
                if (flag5) {
                    sigma.zerodayisaminecraftcheat.j.C();
                }
                if (tileentity3 instanceof TileEntityChest) {
                    final TileEntityChest tileentitychest = (TileEntityChest)tileentity3;
                    if (tileentitychest.momgetthecamera != null) {
                        blockpos = blockpos.zerodayisaminecraftcheat(EnumFacing.zues);
                        tileentity3 = this.h.zerodayisaminecraftcheat(blockpos);
                    }
                    else if (tileentitychest.flux != null) {
                        blockpos = blockpos.zerodayisaminecraftcheat(EnumFacing.sigma);
                        tileentity3 = this.h.zerodayisaminecraftcheat(blockpos);
                    }
                }
                final Block block = this.h.zeroday(blockpos).sigma();
                boolean flag9;
                if (flag2) {
                    flag9 = false;
                    if (tileentity3 != null && Reflector.zeroday(tileentity3, Reflector.bf, i) && Reflector.zeroday(tileentity3, Reflector.bh, new Object[0])) {
                        final AxisAlignedBB axisalignedbb3 = (AxisAlignedBB)Reflector.vape(tileentity3, Reflector.bg, new Object[0]);
                        if (axisalignedbb3 != null) {
                            flag9 = camera.zerodayisaminecraftcheat(axisalignedbb3);
                        }
                    }
                }
                else {
                    flag9 = (tileentity3 != null && (block instanceof BlockChest || block instanceof BlockEnderChest || block instanceof BlockSign || block instanceof BlockSkull));
                }
                if (flag9) {
                    TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(tileentity3, partialTicks, ((DestroyBlockProgress)destroyblockprogress).zeroday());
                }
            }
            this.n();
            this.zerodayisaminecraftcheat.m.vape();
            this.zerodayisaminecraftcheat.z.zeroday();
        }
    }
    
    public String flux() {
        final int i = this.l.flux.length;
        int j = 0;
        for (final Object renderglobal$containerlocalrenderinformation : this.j) {
            final CompiledChunk compiledchunk = ((zerodayisaminecraftcheat)renderglobal$containerlocalrenderinformation).zerodayisaminecraftcheat.zeroday;
            if (compiledchunk != CompiledChunk.zerodayisaminecraftcheat && !compiledchunk.zerodayisaminecraftcheat()) {
                ++j;
            }
        }
        return String.format("C: %d/%d %sD: %d, %s", j, i, this.zerodayisaminecraftcheat.J ? "(s) " : "", this.L, this.J.zerodayisaminecraftcheat());
    }
    
    public String vape() {
        return "E: " + this.O + "/" + this.N + ", B: " + this.P + ", I: " + (this.N - this.P - this.O) + ", " + Config.zeroday();
    }
    
    public void zerodayisaminecraftcheat(final Entity viewEntity, final double partialTicks, ICamera camera, final int frameCount, final boolean playerSpectator) {
        if (this.zerodayisaminecraftcheat.r.sigma != this.L) {
            this.pandora();
        }
        this.h.p.zerodayisaminecraftcheat("camera");
        final double d0 = viewEntity.s - this.y;
        final double d2 = viewEntity.t - this.z;
        final double d3 = viewEntity.u - this.A;
        if (this.B != viewEntity.af || this.C != viewEntity.ag || this.D != viewEntity.ah || d0 * d0 + d2 * d2 + d3 * d3 > 16.0) {
            this.y = viewEntity.s;
            this.z = viewEntity.t;
            this.A = viewEntity.u;
            this.B = viewEntity.af;
            this.C = viewEntity.ag;
            this.D = viewEntity.ah;
            this.l.zerodayisaminecraftcheat(viewEntity.s, viewEntity.u);
        }
        this.h.p.sigma("renderlistcamera");
        final double d4 = viewEntity.Q + (viewEntity.s - viewEntity.Q) * partialTicks;
        final double d5 = viewEntity.R + (viewEntity.t - viewEntity.R) * partialTicks;
        final double d6 = viewEntity.S + (viewEntity.u - viewEntity.S) * partialTicks;
        this.K.zerodayisaminecraftcheat(d4, d5, d6);
        this.h.p.sigma("cull");
        if (this.R != null) {
            final Frustum frustum = new Frustum(this.R);
            frustum.zerodayisaminecraftcheat(this.T.zerodayisaminecraftcheat, this.T.zeroday, this.T.sigma);
            camera = frustum;
        }
        this.zerodayisaminecraftcheat.z.sigma("culling");
        final BlockPos blockpos2 = new BlockPos(d4, d5 + viewEntity.aI(), d6);
        final RenderChunk renderchunk = this.l.zerodayisaminecraftcheat(blockpos2);
        final BlockPos blockpos3 = new BlockPos(MathHelper.sigma(d4 / 16.0) * 16, MathHelper.sigma(d5 / 16.0) * 16, MathHelper.sigma(d6 / 16.0) * 16);
        this.pandora = (this.pandora || !this.i.isEmpty() || viewEntity.s != this.E || viewEntity.t != this.F || viewEntity.u != this.G || viewEntity.z != this.H || viewEntity.y != this.I);
        this.E = viewEntity.s;
        this.F = viewEntity.t;
        this.G = viewEntity.u;
        this.H = viewEntity.z;
        this.I = viewEntity.y;
        final boolean flag = this.R != null;
        Lagometer.flux.zerodayisaminecraftcheat();
        if (sigma.zerodayisaminecraftcheat.j.k) {
            this.j = this.ag;
            this.ab = this.ah;
            this.ac = this.ai;
            if (!flag && this.pandora) {
                this.j.clear();
                this.ab.clear();
                this.ac.clear();
                for (int i = 0; i < this.l.flux.length; ++i) {
                    final RenderChunk renderchunk2 = this.l.flux[i];
                    if (camera.zerodayisaminecraftcheat(renderchunk2.sigma)) {
                        zerodayisaminecraftcheat renderglobal$containerlocalrenderinformation = new zerodayisaminecraftcheat(renderchunk2, (EnumFacing)null, 0, (zerodayisaminecraftcheat)null);
                        final BlockPos blockpos4 = renderchunk2.a();
                        if (!renderchunk2.zeroday.zerodayisaminecraftcheat() || renderchunk2.b()) {
                            if (renderglobal$containerlocalrenderinformation == null) {
                                renderglobal$containerlocalrenderinformation = new zerodayisaminecraftcheat(renderchunk2, (EnumFacing)null, 0, (zerodayisaminecraftcheat)null);
                            }
                            this.j.add(renderglobal$containerlocalrenderinformation);
                        }
                        if (ChunkUtils.zerodayisaminecraftcheat(this.h.vape(blockpos4))) {
                            if (renderglobal$containerlocalrenderinformation == null) {
                                renderglobal$containerlocalrenderinformation = new zerodayisaminecraftcheat(renderchunk2, (EnumFacing)null, 0, (zerodayisaminecraftcheat)null);
                            }
                            this.ab.add(renderglobal$containerlocalrenderinformation);
                        }
                        if (renderchunk2.vape().zeroday().size() > 0) {
                            if (renderglobal$containerlocalrenderinformation == null) {
                                renderglobal$containerlocalrenderinformation = new zerodayisaminecraftcheat(renderchunk2, (EnumFacing)null, 0, (zerodayisaminecraftcheat)null);
                            }
                            this.ac.add(renderglobal$containerlocalrenderinformation);
                        }
                    }
                }
            }
        }
        else {
            this.j = this.ad;
            this.ab = this.ae;
            this.ac = this.af;
        }
        if (!flag && this.pandora && !sigma.zerodayisaminecraftcheat.j.k) {
            this.pandora = false;
            this.j.clear();
            this.ab.clear();
            this.ac.clear();
            this.aa.clear();
            final Deque deque = this.aa;
            boolean flag2 = this.zerodayisaminecraftcheat.J;
            if (renderchunk != null) {
                boolean flag3 = false;
                final zerodayisaminecraftcheat renderglobal$containerlocalrenderinformation2 = new zerodayisaminecraftcheat(renderchunk, null, 0, (Object)null);
                final Set set1 = RenderGlobal.al;
                if (set1.size() == 1) {
                    final Vector3f vector3f = this.zerodayisaminecraftcheat(viewEntity, partialTicks);
                    final EnumFacing enumfacing = EnumFacing.zerodayisaminecraftcheat(vector3f.x, vector3f.y, vector3f.z).zues();
                    set1.remove(enumfacing);
                }
                if (set1.isEmpty()) {
                    flag3 = true;
                }
                if (flag3 && !playerSpectator) {
                    this.j.add(renderglobal$containerlocalrenderinformation2);
                }
                else {
                    if (playerSpectator && this.h.zeroday(blockpos2).sigma().g()) {
                        flag2 = false;
                    }
                    renderchunk.zerodayisaminecraftcheat(frameCount);
                    deque.add(renderglobal$containerlocalrenderinformation2);
                }
            }
            else {
                final int j = (blockpos2.zeroday() > 0) ? 248 : 8;
                for (int k = -this.L; k <= this.L; ++k) {
                    for (int l = -this.L; l <= this.L; ++l) {
                        final RenderChunk renderchunk3 = this.l.zerodayisaminecraftcheat(new BlockPos((k << 4) + 8, j, (l << 4) + 8));
                        if (renderchunk3 != null && camera.zerodayisaminecraftcheat(renderchunk3.sigma)) {
                            renderchunk3.zerodayisaminecraftcheat(frameCount);
                            deque.add(new zerodayisaminecraftcheat(renderchunk3, null, 0, (Object)null));
                        }
                    }
                }
            }
            final EnumFacing[] aenumfacing = EnumFacing.vape;
            final int i2 = aenumfacing.length;
            while (!deque.isEmpty()) {
                final zerodayisaminecraftcheat renderglobal$containerlocalrenderinformation3 = deque.poll();
                final RenderChunk renderchunk4 = renderglobal$containerlocalrenderinformation3.zerodayisaminecraftcheat;
                final EnumFacing enumfacing2 = renderglobal$containerlocalrenderinformation3.zeroday;
                final BlockPos blockpos5 = renderchunk4.a();
                if (!renderchunk4.zeroday.zerodayisaminecraftcheat() || renderchunk4.b()) {
                    this.j.add(renderglobal$containerlocalrenderinformation3);
                }
                if (ChunkUtils.zerodayisaminecraftcheat(this.h.vape(blockpos5))) {
                    this.ab.add(renderglobal$containerlocalrenderinformation3);
                }
                if (renderchunk4.vape().zeroday().size() > 0) {
                    this.ac.add(renderglobal$containerlocalrenderinformation3);
                }
                for (final EnumFacing enumfacing3 : aenumfacing) {
                    if ((!flag2 || !renderglobal$containerlocalrenderinformation3.sigma.contains(enumfacing3.zues())) && (!flag2 || enumfacing2 == null || renderchunk4.vape().zerodayisaminecraftcheat(enumfacing2.zues(), enumfacing3))) {
                        final RenderChunk renderchunk5 = this.zerodayisaminecraftcheat(blockpos2, renderchunk4, enumfacing3);
                        if (renderchunk5 != null && renderchunk5.zerodayisaminecraftcheat(frameCount) && camera.zerodayisaminecraftcheat(renderchunk5.sigma)) {
                            final zerodayisaminecraftcheat renderglobal$containerlocalrenderinformation4 = new zerodayisaminecraftcheat(renderchunk5, enumfacing3, renderglobal$containerlocalrenderinformation3.pandora + 1, (Object)null);
                            renderglobal$containerlocalrenderinformation4.sigma.addAll(renderglobal$containerlocalrenderinformation3.sigma);
                            renderglobal$containerlocalrenderinformation4.sigma.add(enumfacing3);
                            deque.add(renderglobal$containerlocalrenderinformation4);
                        }
                    }
                }
            }
        }
        if (this.Q) {
            this.zerodayisaminecraftcheat(d4, d5, d6);
            this.Q = false;
        }
        Lagometer.flux.zeroday();
        if (sigma.zerodayisaminecraftcheat.j.k) {
            sigma.zerodayisaminecraftcheat.j.ad();
        }
        else {
            this.J.zues();
            final Set set2 = this.i;
            this.i = Sets.newLinkedHashSet();
            final Iterator iterator = this.j.iterator();
            Lagometer.zues.zerodayisaminecraftcheat();
            while (iterator.hasNext()) {
                final zerodayisaminecraftcheat renderglobal$containerlocalrenderinformation5 = iterator.next();
                final RenderChunk renderchunk6 = renderglobal$containerlocalrenderinformation5.zerodayisaminecraftcheat;
                if (renderchunk6.b() || set2.contains(renderchunk6)) {
                    this.pandora = true;
                    if (this.zerodayisaminecraftcheat(blockpos3, renderglobal$containerlocalrenderinformation5.zerodayisaminecraftcheat)) {
                        if (!Config.aQ()) {
                            this.vape.add(renderchunk6);
                        }
                        else {
                            this.zerodayisaminecraftcheat.z.zerodayisaminecraftcheat("build near");
                            this.J.zeroday(renderchunk6);
                            renderchunk6.zerodayisaminecraftcheat(false);
                            this.zerodayisaminecraftcheat.z.zeroday();
                        }
                    }
                    else {
                        this.i.add(renderchunk6);
                    }
                }
            }
            Lagometer.zues.zeroday();
            this.i.addAll(set2);
            this.zerodayisaminecraftcheat.z.zeroday();
        }
    }
    
    private boolean zerodayisaminecraftcheat(final BlockPos pos, final RenderChunk renderChunkIn) {
        final BlockPos blockpos = renderChunkIn.a();
        return MathHelper.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() - blockpos.zerodayisaminecraftcheat()) <= 16 && MathHelper.zerodayisaminecraftcheat(pos.zeroday() - blockpos.zeroday()) <= 16 && MathHelper.zerodayisaminecraftcheat(pos.sigma() - blockpos.sigma()) <= 16;
    }
    
    private Set sigma(final BlockPos pos) {
        final VisGraph visgraph = new VisGraph();
        final BlockPos blockpos = new BlockPos(pos.zerodayisaminecraftcheat() >> 4 << 4, pos.zeroday() >> 4 << 4, pos.sigma() >> 4 << 4);
        final Chunk chunk = this.h.vape(blockpos);
        for (final BlockPos.zerodayisaminecraftcheat blockpos$mutableblockpos : BlockPos.sigma(blockpos, blockpos.zeroday(15, 15, 15))) {
            if (chunk.sigma(blockpos$mutableblockpos).g()) {
                visgraph.zerodayisaminecraftcheat(blockpos$mutableblockpos);
            }
        }
        return visgraph.zeroday(pos);
    }
    
    private RenderChunk zerodayisaminecraftcheat(final BlockPos p_181562_1_, final RenderChunk p_181562_2_, final EnumFacing p_181562_3_) {
        final BlockPos blockpos = p_181562_2_.zeroday(p_181562_3_);
        if (blockpos.zeroday() >= 0 && blockpos.zeroday() < 256) {
            final int i = MathHelper.zerodayisaminecraftcheat(p_181562_1_.zerodayisaminecraftcheat() - blockpos.zerodayisaminecraftcheat());
            final int j = MathHelper.zerodayisaminecraftcheat(p_181562_1_.sigma() - blockpos.sigma());
            if (Config.i()) {
                if (i > this.aj || j > this.aj) {
                    return null;
                }
            }
            else {
                final int k = i * i + j * j;
                if (k > this.ak) {
                    return null;
                }
            }
            return this.l.zerodayisaminecraftcheat(blockpos);
        }
        return null;
    }
    
    private void zerodayisaminecraftcheat(final double x, final double y, final double z) {
        this.R = new ClippingHelperImpl();
        ((ClippingHelperImpl)this.R).zeroday();
        final Matrix4f matrix4f = new Matrix4f(this.R.sigma);
        matrix4f.transpose();
        final Matrix4f matrix4f2 = new Matrix4f(this.R.zeroday);
        matrix4f2.transpose();
        final Matrix4f matrix4f3 = new Matrix4f();
        Matrix4f.mul((org.lwjgl.util.vector.Matrix4f)matrix4f2, (org.lwjgl.util.vector.Matrix4f)matrix4f, (org.lwjgl.util.vector.Matrix4f)matrix4f3);
        matrix4f3.invert();
        this.T.zerodayisaminecraftcheat = x;
        this.T.zeroday = y;
        this.T.sigma = z;
        this.S[0] = new Vector4f(-1.0f, -1.0f, -1.0f, 1.0f);
        this.S[1] = new Vector4f(1.0f, -1.0f, -1.0f, 1.0f);
        this.S[2] = new Vector4f(1.0f, 1.0f, -1.0f, 1.0f);
        this.S[3] = new Vector4f(-1.0f, 1.0f, -1.0f, 1.0f);
        this.S[4] = new Vector4f(-1.0f, -1.0f, 1.0f, 1.0f);
        this.S[5] = new Vector4f(1.0f, -1.0f, 1.0f, 1.0f);
        this.S[6] = new Vector4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.S[7] = new Vector4f(-1.0f, 1.0f, 1.0f, 1.0f);
        for (int i = 0; i < 8; ++i) {
            Matrix4f.transform((org.lwjgl.util.vector.Matrix4f)matrix4f3, this.S[i], this.S[i]);
            final Vector4f vector4f = this.S[i];
            vector4f.x /= this.S[i].w;
            final Vector4f vector4f2 = this.S[i];
            vector4f2.y /= this.S[i].w;
            final Vector4f vector4f3 = this.S[i];
            vector4f3.z /= this.S[i].w;
            this.S[i].w = 1.0f;
        }
    }
    
    protected Vector3f zerodayisaminecraftcheat(final Entity entityIn, final double partialTicks) {
        float f = (float)(entityIn.B + (entityIn.z - entityIn.B) * partialTicks);
        final float f2 = (float)(entityIn.A + (entityIn.y - entityIn.A) * partialTicks);
        if (Minecraft.s().r.as == 2) {
            f += 180.0f;
        }
        final float f3 = MathHelper.zeroday(-f2 * 0.017453292f - 3.1415927f);
        final float f4 = MathHelper.zerodayisaminecraftcheat(-f2 * 0.017453292f - 3.1415927f);
        final float f5 = -MathHelper.zeroday(-f * 0.017453292f);
        final float f6 = MathHelper.zerodayisaminecraftcheat(-f * 0.017453292f);
        return new Vector3f(f4 * f5, f6, f3 * f5);
    }
    
    public int zerodayisaminecraftcheat(final EnumWorldBlockLayer blockLayerIn, final double partialTicks, final int pass, final Entity entityIn) {
        RenderHelper.zerodayisaminecraftcheat();
        if (blockLayerIn == EnumWorldBlockLayer.pandora) {
            this.zerodayisaminecraftcheat.z.zerodayisaminecraftcheat("translucent_sort");
            final double d0 = entityIn.s - this.V;
            final double d2 = entityIn.t - this.W;
            final double d3 = entityIn.u - this.X;
            if (d0 * d0 + d2 * d2 + d3 * d3 > 1.0) {
                this.V = entityIn.s;
                this.W = entityIn.t;
                this.X = entityIn.u;
                int k = 0;
                final Iterator iterator = this.j.iterator();
                this.flux.clear();
                while (iterator.hasNext()) {
                    final zerodayisaminecraftcheat renderglobal$containerlocalrenderinformation = iterator.next();
                    if (renderglobal$containerlocalrenderinformation.zerodayisaminecraftcheat.zeroday.pandora(blockLayerIn) && k++ < 15) {
                        this.flux.add(renderglobal$containerlocalrenderinformation.zerodayisaminecraftcheat);
                    }
                }
            }
            this.zerodayisaminecraftcheat.z.zeroday();
        }
        this.zerodayisaminecraftcheat.z.zerodayisaminecraftcheat("filterempty");
        int l = 0;
        final boolean flag = blockLayerIn == EnumWorldBlockLayer.pandora;
        final int i1 = flag ? (this.j.size() - 1) : 0;
        for (int j = flag ? -1 : this.j.size(), j2 = flag ? -1 : 1, m = i1; m != j; m += j2) {
            final RenderChunk renderchunk = this.j.get(m).zerodayisaminecraftcheat;
            if (!renderchunk.vape().zeroday(blockLayerIn)) {
                ++l;
                this.K.zerodayisaminecraftcheat(renderchunk, blockLayerIn);
            }
        }
        if (l == 0) {
            this.zerodayisaminecraftcheat.z.zeroday();
            return l;
        }
        if (Config.i() && this.zerodayisaminecraftcheat.m.d) {
            GlStateManager.f();
        }
        this.zerodayisaminecraftcheat.z.sigma("render_" + blockLayerIn);
        this.zerodayisaminecraftcheat(blockLayerIn);
        this.zerodayisaminecraftcheat.z.zeroday();
        return l;
    }
    
    private void zerodayisaminecraftcheat(final EnumWorldBlockLayer blockLayerIn) {
        this.zerodayisaminecraftcheat.m.momgetthecamera();
        if (OpenGlHelper.flux()) {
            GL11.glEnableClientState(32884);
            OpenGlHelper.d(OpenGlHelper.i);
            GL11.glEnableClientState(32888);
            OpenGlHelper.d(OpenGlHelper.j);
            GL11.glEnableClientState(32888);
            OpenGlHelper.d(OpenGlHelper.i);
            GL11.glEnableClientState(32886);
        }
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.k.a();
        }
        this.K.zerodayisaminecraftcheat(blockLayerIn);
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.k.b();
        }
        if (OpenGlHelper.flux()) {
            for (final VertexFormatElement vertexformatelement : DefaultVertexFormats.zerodayisaminecraftcheat.momgetthecamera()) {
                final VertexFormatElement.zeroday vertexformatelement$enumusage = vertexformatelement.zeroday();
                final int i = vertexformatelement.pandora();
                switch (RenderGlobal.zeroday.zerodayisaminecraftcheat[vertexformatelement$enumusage.ordinal()]) {
                    default: {
                        continue;
                    }
                    case 1: {
                        GL11.glDisableClientState(32884);
                        continue;
                    }
                    case 2: {
                        OpenGlHelper.d(OpenGlHelper.i + i);
                        GL11.glDisableClientState(32888);
                        OpenGlHelper.d(OpenGlHelper.i);
                        continue;
                    }
                    case 3: {
                        GL11.glDisableClientState(32886);
                        GlStateManager.x();
                        continue;
                    }
                }
            }
        }
        this.zerodayisaminecraftcheat.m.vape();
    }
    
    private void zerodayisaminecraftcheat(final Iterator iteratorIn) {
        while (iteratorIn.hasNext()) {
            final DestroyBlockProgress destroyblockprogress = iteratorIn.next();
            final int i = destroyblockprogress.sigma();
            if (this.t - i > 400) {
                iteratorIn.remove();
            }
        }
    }
    
    public void momgetthecamera() {
        ++this.t;
        if (this.t % 20 == 0) {
            this.zerodayisaminecraftcheat(this.zeroday.values().iterator());
        }
    }
    
    private void l() {
        if (Config.U()) {
            GlStateManager.f();
            GlStateManager.sigma();
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            RenderHelper.zerodayisaminecraftcheat();
            GlStateManager.zerodayisaminecraftcheat(false);
            this.f.zerodayisaminecraftcheat(RenderGlobal.d);
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            for (int i = 0; i < 6; ++i) {
                GlStateManager.v();
                if (i == 1) {
                    GlStateManager.zeroday(90.0f, 1.0f, 0.0f, 0.0f);
                }
                if (i == 2) {
                    GlStateManager.zeroday(-90.0f, 1.0f, 0.0f, 0.0f);
                }
                if (i == 3) {
                    GlStateManager.zeroday(180.0f, 1.0f, 0.0f, 0.0f);
                }
                if (i == 4) {
                    GlStateManager.zeroday(90.0f, 0.0f, 0.0f, 1.0f);
                }
                if (i == 5) {
                    GlStateManager.zeroday(-90.0f, 0.0f, 0.0f, 1.0f);
                }
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
                worldrenderer.zeroday(-100.0, -100.0, -100.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(40, 40, 40, 255).zues();
                worldrenderer.zeroday(-100.0, -100.0, 100.0).zerodayisaminecraftcheat(0.0, 16.0).zeroday(40, 40, 40, 255).zues();
                worldrenderer.zeroday(100.0, -100.0, 100.0).zerodayisaminecraftcheat(16.0, 16.0).zeroday(40, 40, 40, 255).zues();
                worldrenderer.zeroday(100.0, -100.0, -100.0).zerodayisaminecraftcheat(16.0, 0.0).zeroday(40, 40, 40, 255).zues();
                tessellator.zeroday();
                GlStateManager.w();
            }
            GlStateManager.zerodayisaminecraftcheat(true);
            GlStateManager.m();
            GlStateManager.pandora();
        }
    }
    
    public void zerodayisaminecraftcheat(final float partialTicks, final int pass) {
        if (Reflector.O.zeroday()) {
            final WorldProvider worldprovider = this.zerodayisaminecraftcheat.a.h;
            final Object object = Reflector.vape(worldprovider, Reflector.O, new Object[0]);
            if (object != null) {
                Reflector.zerodayisaminecraftcheat(object, Reflector.V, partialTicks, this.h, this.zerodayisaminecraftcheat);
                return;
            }
        }
        if (this.zerodayisaminecraftcheat.a.h.i() == 1) {
            this.l();
        }
        else if (this.zerodayisaminecraftcheat.a.h.pandora()) {
            GlStateManager.n();
            final boolean flag1 = Config.aC();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.V();
            }
            Vec3 vec3 = this.h.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.V(), partialTicks);
            vec3 = CustomColorizer.zerodayisaminecraftcheat(vec3, this.zerodayisaminecraftcheat.a, this.zerodayisaminecraftcheat.V().s, this.zerodayisaminecraftcheat.V().t + 1.0, this.zerodayisaminecraftcheat.V().u);
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(vec3);
            }
            float f = (float)vec3.zerodayisaminecraftcheat;
            float f2 = (float)vec3.zeroday;
            float f3 = (float)vec3.sigma;
            if (pass != 2) {
                final float f4 = (f * 30.0f + f2 * 59.0f + f3 * 11.0f) / 100.0f;
                final float f5 = (f * 30.0f + f2 * 70.0f) / 100.0f;
                final float f6 = (f * 30.0f + f3 * 70.0f) / 100.0f;
                f = f4;
                f2 = f5;
                f3 = f6;
            }
            GlStateManager.sigma(f, f2, f3);
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            GlStateManager.zerodayisaminecraftcheat(false);
            GlStateManager.e();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.W();
            }
            GlStateManager.sigma(f, f2, f3);
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.o();
            }
            if (Config.U()) {
                if (this.U) {
                    this.r.zerodayisaminecraftcheat();
                    GL11.glEnableClientState(32884);
                    GL11.glVertexPointer(3, 5126, 12, 0L);
                    this.r.zerodayisaminecraftcheat(7);
                    this.r.zeroday();
                    GL11.glDisableClientState(32884);
                }
                else {
                    GlStateManager.e(this.n);
                }
            }
            GlStateManager.f();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.X();
            }
            GlStateManager.sigma();
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            RenderHelper.zerodayisaminecraftcheat();
            final float[] afloat = this.h.h.zerodayisaminecraftcheat(this.h.sigma(partialTicks), partialTicks);
            if (afloat != null && Config.V()) {
                GlStateManager.n();
                if (flag1) {
                    sigma.zerodayisaminecraftcheat.j.V();
                }
                GlStateManager.b(7425);
                GlStateManager.v();
                GlStateManager.zeroday(90.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday((MathHelper.zerodayisaminecraftcheat(this.h.pandora(partialTicks)) < 0.0f) ? 180.0f : 0.0f, 0.0f, 0.0f, 1.0f);
                GlStateManager.zeroday(90.0f, 0.0f, 0.0f, 1.0f);
                float f7 = afloat[0];
                float f8 = afloat[1];
                float f9 = afloat[2];
                if (pass != 2) {
                    final float f10 = (f7 * 30.0f + f8 * 59.0f + f9 * 11.0f) / 100.0f;
                    final float f11 = (f7 * 30.0f + f8 * 70.0f) / 100.0f;
                    final float f12 = (f7 * 30.0f + f9 * 70.0f) / 100.0f;
                    f7 = f10;
                    f8 = f11;
                    f9 = f12;
                }
                worldrenderer.zerodayisaminecraftcheat(6, DefaultVertexFormats.flux);
                worldrenderer.zeroday(0.0, 100.0, 0.0).zerodayisaminecraftcheat(f7, f8, f9, afloat[3]).zues();
                final boolean flag2 = true;
                for (int i = 0; i <= 16; ++i) {
                    final float f13 = i * 3.1415927f * 2.0f / 16.0f;
                    final float f14 = MathHelper.zerodayisaminecraftcheat(f13);
                    final float f15 = MathHelper.zeroday(f13);
                    worldrenderer.zeroday(f14 * 120.0f, f15 * 120.0f, (double)(-f15 * 40.0f * afloat[3])).zerodayisaminecraftcheat(afloat[0], afloat[1], afloat[2], 0.0f).zues();
                }
                tessellator.zeroday();
                GlStateManager.w();
                GlStateManager.b(7424);
            }
            GlStateManager.m();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.U();
            }
            GlStateManager.zerodayisaminecraftcheat(770, 1, 1, 0);
            GlStateManager.v();
            final float f16 = 1.0f - this.h.b(partialTicks);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, f16);
            GlStateManager.zeroday(-90.0f, 0.0f, 1.0f, 0.0f);
            CustomSky.zerodayisaminecraftcheat(this.h, this.f, this.h.sigma(partialTicks), f16);
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.f();
            }
            GlStateManager.zeroday(this.h.sigma(partialTicks) * 360.0f, 1.0f, 0.0f, 0.0f);
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.g();
            }
            if (Config.V()) {
                float f17 = 30.0f;
                this.f.zerodayisaminecraftcheat(RenderGlobal.b);
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
                worldrenderer.zeroday(-f17, 100.0, -f17).zerodayisaminecraftcheat(0.0, 0.0).zues();
                worldrenderer.zeroday(f17, 100.0, -f17).zerodayisaminecraftcheat(1.0, 0.0).zues();
                worldrenderer.zeroday(f17, 100.0, f17).zerodayisaminecraftcheat(1.0, 1.0).zues();
                worldrenderer.zeroday(-f17, 100.0, f17).zerodayisaminecraftcheat(0.0, 1.0).zues();
                tessellator.zeroday();
                f17 = 20.0f;
                this.f.zerodayisaminecraftcheat(RenderGlobal.a);
                final int l = this.h.d();
                final int j = l % 4;
                final int k = l / 4 % 2;
                final float f18 = (j + 0) / 4.0f;
                final float f19 = (k + 0) / 2.0f;
                final float f20 = (j + 1) / 4.0f;
                final float f21 = (k + 1) / 2.0f;
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
                worldrenderer.zeroday(-f17, -100.0, f17).zerodayisaminecraftcheat(f20, f21).zues();
                worldrenderer.zeroday(f17, -100.0, f17).zerodayisaminecraftcheat(f18, f21).zues();
                worldrenderer.zeroday(f17, -100.0, -f17).zerodayisaminecraftcheat(f18, f19).zues();
                worldrenderer.zeroday(-f17, -100.0, -f17).zerodayisaminecraftcheat(f20, f19).zues();
                tessellator.zeroday();
            }
            GlStateManager.n();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.V();
            }
            final float f22 = this.h.vape(partialTicks) * f16;
            if (f22 > 0.0f && Config.X() && !CustomSky.zerodayisaminecraftcheat(this.h)) {
                GlStateManager.sigma(f22, f22, f22, f22);
                if (this.U) {
                    this.q.zerodayisaminecraftcheat();
                    GL11.glEnableClientState(32884);
                    GL11.glVertexPointer(3, 5126, 12, 0L);
                    this.q.zerodayisaminecraftcheat(7);
                    this.q.zeroday();
                    GL11.glDisableClientState(32884);
                }
                else {
                    GlStateManager.e(this.m);
                }
            }
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.c();
            GlStateManager.pandora();
            GlStateManager.e();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.W();
            }
            GlStateManager.w();
            GlStateManager.n();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.V();
            }
            GlStateManager.sigma(0.0f, 0.0f, 0.0f);
            final double d0 = this.zerodayisaminecraftcheat.e.vape(partialTicks).zeroday - this.h.C();
            if (d0 < 0.0) {
                GlStateManager.v();
                GlStateManager.zeroday(0.0f, 12.0f, 0.0f);
                if (this.U) {
                    this.s.zerodayisaminecraftcheat();
                    GL11.glEnableClientState(32884);
                    GL11.glVertexPointer(3, 5126, 12, 0L);
                    this.s.zerodayisaminecraftcheat(7);
                    this.s.zeroday();
                    GL11.glDisableClientState(32884);
                }
                else {
                    GlStateManager.e(this.o);
                }
                GlStateManager.w();
                final float f23 = 1.0f;
                final float f24 = -(float)(d0 + 65.0);
                final float f25 = -1.0f;
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
                worldrenderer.zeroday(-1.0, f24, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, f24, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, -1.0, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, -1.0, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, -1.0, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, -1.0, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, f24, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, f24, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, -1.0, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, -1.0, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, f24, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, f24, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, f24, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, f24, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, -1.0, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, -1.0, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, -1.0, -1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(-1.0, -1.0, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, -1.0, 1.0).zeroday(0, 0, 0, 255).zues();
                worldrenderer.zeroday(1.0, -1.0, -1.0).zeroday(0, 0, 0, 255).zues();
                tessellator.zeroday();
            }
            if (this.h.h.vape()) {
                GlStateManager.sigma(f * 0.2f + 0.04f, f2 * 0.2f + 0.04f, f3 * 0.6f + 0.1f);
            }
            else {
                GlStateManager.sigma(f, f2, f3);
            }
            if (this.zerodayisaminecraftcheat.r.sigma <= 4) {
                GlStateManager.sigma(this.zerodayisaminecraftcheat.m.pandora, this.zerodayisaminecraftcheat.m.zues, this.zerodayisaminecraftcheat.m.flux);
            }
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, -(float)(d0 - 16.0), 0.0f);
            if (Config.U()) {
                GlStateManager.e(this.o);
            }
            GlStateManager.w();
            GlStateManager.m();
            if (flag1) {
                sigma.zerodayisaminecraftcheat.j.U();
            }
            GlStateManager.zerodayisaminecraftcheat(true);
        }
    }
    
    public void zeroday(float partialTicks, final int pass) {
        if (!Config.p()) {
            if (Reflector.P.zeroday()) {
                final WorldProvider worldprovider = this.zerodayisaminecraftcheat.a.h;
                final Object object = Reflector.vape(worldprovider, Reflector.P, new Object[0]);
                if (object != null) {
                    Reflector.zerodayisaminecraftcheat(object, Reflector.V, partialTicks, this.h, this.zerodayisaminecraftcheat);
                    return;
                }
            }
            if (this.zerodayisaminecraftcheat.a.h.pandora()) {
                if (Config.o()) {
                    this.sigma(partialTicks, pass);
                }
                else {
                    this.Z.zerodayisaminecraftcheat(false, this.t, partialTicks);
                    partialTicks = 0.0f;
                    GlStateManager.h();
                    final float f9 = (float)(this.zerodayisaminecraftcheat.V().R + (this.zerodayisaminecraftcheat.V().t - this.zerodayisaminecraftcheat.V().R) * partialTicks);
                    final boolean flag = true;
                    final boolean flag2 = true;
                    final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                    final WorldRenderer worldrenderer = tessellator.sigma();
                    this.f.zerodayisaminecraftcheat(RenderGlobal.c);
                    GlStateManager.d();
                    GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
                    if (this.Z.zerodayisaminecraftcheat()) {
                        this.Z.zeroday();
                        final Vec3 vec3 = this.h.zues(partialTicks);
                        float f10 = (float)vec3.zerodayisaminecraftcheat;
                        float f11 = (float)vec3.zeroday;
                        float f12 = (float)vec3.sigma;
                        if (pass != 2) {
                            final float f13 = (f10 * 30.0f + f11 * 59.0f + f12 * 11.0f) / 100.0f;
                            final float f14 = (f10 * 30.0f + f11 * 70.0f) / 100.0f;
                            final float f15 = (f10 * 30.0f + f12 * 70.0f) / 100.0f;
                            f10 = f13;
                            f11 = f14;
                            f12 = f15;
                        }
                        final float f16 = 4.8828125E-4f;
                        final double d2 = this.t + partialTicks;
                        double d3 = this.zerodayisaminecraftcheat.V().p + (this.zerodayisaminecraftcheat.V().s - this.zerodayisaminecraftcheat.V().p) * partialTicks + d2 * 0.029999999329447746;
                        double d4 = this.zerodayisaminecraftcheat.V().r + (this.zerodayisaminecraftcheat.V().u - this.zerodayisaminecraftcheat.V().r) * partialTicks;
                        final int i = MathHelper.sigma(d3 / 2048.0);
                        final int j = MathHelper.sigma(d4 / 2048.0);
                        d3 -= i * 2048;
                        d4 -= j * 2048;
                        float f17 = this.h.h.flux() - f9 + 0.33f;
                        f17 += this.zerodayisaminecraftcheat.r.aR * 128.0f;
                        final float f18 = (float)(d3 * 4.8828125E-4);
                        final float f19 = (float)(d4 * 4.8828125E-4);
                        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
                        for (int k = -256; k < 256; k += 32) {
                            for (int l = -256; l < 256; l += 32) {
                                worldrenderer.zeroday(k + 0, f17, (double)(l + 32)).zerodayisaminecraftcheat((k + 0) * 4.8828125E-4f + f18, (l + 32) * 4.8828125E-4f + f19).zerodayisaminecraftcheat(f10, f11, f12, 0.8f).zues();
                                worldrenderer.zeroday(k + 32, f17, (double)(l + 32)).zerodayisaminecraftcheat((k + 32) * 4.8828125E-4f + f18, (l + 32) * 4.8828125E-4f + f19).zerodayisaminecraftcheat(f10, f11, f12, 0.8f).zues();
                                worldrenderer.zeroday(k + 32, f17, (double)(l + 0)).zerodayisaminecraftcheat((k + 32) * 4.8828125E-4f + f18, (l + 0) * 4.8828125E-4f + f19).zerodayisaminecraftcheat(f10, f11, f12, 0.8f).zues();
                                worldrenderer.zeroday(k + 0, f17, (double)(l + 0)).zerodayisaminecraftcheat((k + 0) * 4.8828125E-4f + f18, (l + 0) * 4.8828125E-4f + f19).zerodayisaminecraftcheat(f10, f11, f12, 0.8f).zues();
                            }
                        }
                        tessellator.zeroday();
                        this.Z.sigma();
                    }
                    this.Z.pandora();
                    GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                    GlStateManager.c();
                    GlStateManager.g();
                }
            }
        }
    }
    
    public boolean zerodayisaminecraftcheat(final double x, final double y, final double z, final float partialTicks) {
        return false;
    }
    
    private void sigma(float partialTicks, final int pass) {
        this.Z.zerodayisaminecraftcheat(true, this.t, partialTicks);
        partialTicks = 0.0f;
        GlStateManager.h();
        final float f = (float)(this.zerodayisaminecraftcheat.V().R + (this.zerodayisaminecraftcheat.V().t - this.zerodayisaminecraftcheat.V().R) * partialTicks);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final float f2 = 12.0f;
        final float f3 = 4.0f;
        final double d0 = this.t + partialTicks;
        double d2 = (this.zerodayisaminecraftcheat.V().p + (this.zerodayisaminecraftcheat.V().s - this.zerodayisaminecraftcheat.V().p) * partialTicks + d0 * 0.029999999329447746) / 12.0;
        double d3 = (this.zerodayisaminecraftcheat.V().r + (this.zerodayisaminecraftcheat.V().u - this.zerodayisaminecraftcheat.V().r) * partialTicks) / 12.0 + 0.33000001311302185;
        float f4 = this.h.h.flux() - f + 0.33f;
        f4 += this.zerodayisaminecraftcheat.r.aR * 128.0f;
        final int i = MathHelper.sigma(d2 / 2048.0);
        final int j = MathHelper.sigma(d3 / 2048.0);
        d2 -= i * 2048;
        d3 -= j * 2048;
        this.f.zerodayisaminecraftcheat(RenderGlobal.c);
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        final Vec3 vec3 = this.h.zues(partialTicks);
        float f5 = (float)vec3.zerodayisaminecraftcheat;
        float f6 = (float)vec3.zeroday;
        float f7 = (float)vec3.sigma;
        if (pass != 2) {
            final float f8 = (f5 * 30.0f + f6 * 59.0f + f7 * 11.0f) / 100.0f;
            final float f9 = (f5 * 30.0f + f6 * 70.0f) / 100.0f;
            final float f10 = (f5 * 30.0f + f7 * 70.0f) / 100.0f;
            f5 = f8;
            f6 = f9;
            f7 = f10;
        }
        final float f11 = f5 * 0.9f;
        final float f12 = f6 * 0.9f;
        final float f13 = f7 * 0.9f;
        final float f14 = f5 * 0.7f;
        final float f15 = f6 * 0.7f;
        final float f16 = f7 * 0.7f;
        final float f17 = f5 * 0.8f;
        final float f18 = f6 * 0.8f;
        final float f19 = f7 * 0.8f;
        final float f20 = 0.00390625f;
        final float f21 = MathHelper.sigma(d2) * 0.00390625f;
        final float f22 = MathHelper.sigma(d3) * 0.00390625f;
        final float f23 = (float)(d2 - MathHelper.sigma(d2));
        final float f24 = (float)(d3 - MathHelper.sigma(d3));
        final boolean flag = true;
        final boolean flag2 = true;
        final float f25 = 9.765625E-4f;
        GlStateManager.zerodayisaminecraftcheat(12.0f, 1.0f, 12.0f);
        for (int k = 0; k < 2; ++k) {
            if (k == 0) {
                GlStateManager.zerodayisaminecraftcheat(false, false, false, false);
            }
            else {
                switch (pass) {
                    case 0: {
                        GlStateManager.zerodayisaminecraftcheat(false, true, true, true);
                        break;
                    }
                    case 1: {
                        GlStateManager.zerodayisaminecraftcheat(true, false, false, true);
                        break;
                    }
                    case 2: {
                        GlStateManager.zerodayisaminecraftcheat(true, true, true, true);
                        break;
                    }
                }
            }
            this.Z.pandora();
        }
        if (this.Z.zerodayisaminecraftcheat()) {
            this.Z.zeroday();
            for (int j2 = -3; j2 <= 4; ++j2) {
                for (int l = -3; l <= 4; ++l) {
                    worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.d);
                    final float f26 = (float)(j2 * 8);
                    final float f27 = (float)(l * 8);
                    final float f28 = f26 - f23;
                    final float f29 = f27 - f24;
                    if (f4 > -5.0f) {
                        worldrenderer.zeroday(f28 + 0.0f, f4 + 0.0f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f14, f15, f16, 0.8f).sigma(0.0f, -1.0f, 0.0f).zues();
                        worldrenderer.zeroday(f28 + 8.0f, f4 + 0.0f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f14, f15, f16, 0.8f).sigma(0.0f, -1.0f, 0.0f).zues();
                        worldrenderer.zeroday(f28 + 8.0f, f4 + 0.0f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f14, f15, f16, 0.8f).sigma(0.0f, -1.0f, 0.0f).zues();
                        worldrenderer.zeroday(f28 + 0.0f, f4 + 0.0f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f14, f15, f16, 0.8f).sigma(0.0f, -1.0f, 0.0f).zues();
                    }
                    if (f4 <= 5.0f) {
                        worldrenderer.zeroday(f28 + 0.0f, f4 + 4.0f - 9.765625E-4f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f5, f6, f7, 0.8f).sigma(0.0f, 1.0f, 0.0f).zues();
                        worldrenderer.zeroday(f28 + 8.0f, f4 + 4.0f - 9.765625E-4f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f5, f6, f7, 0.8f).sigma(0.0f, 1.0f, 0.0f).zues();
                        worldrenderer.zeroday(f28 + 8.0f, f4 + 4.0f - 9.765625E-4f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f5, f6, f7, 0.8f).sigma(0.0f, 1.0f, 0.0f).zues();
                        worldrenderer.zeroday(f28 + 0.0f, f4 + 4.0f - 9.765625E-4f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f5, f6, f7, 0.8f).sigma(0.0f, 1.0f, 0.0f).zues();
                    }
                    if (j2 > -1) {
                        for (int i2 = 0; i2 < 8; ++i2) {
                            worldrenderer.zeroday(f28 + i2 + 0.0f, f4 + 0.0f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + i2 + 0.5f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(-1.0f, 0.0f, 0.0f).zues();
                            worldrenderer.zeroday(f28 + i2 + 0.0f, f4 + 4.0f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + i2 + 0.5f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(-1.0f, 0.0f, 0.0f).zues();
                            worldrenderer.zeroday(f28 + i2 + 0.0f, f4 + 4.0f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + i2 + 0.5f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(-1.0f, 0.0f, 0.0f).zues();
                            worldrenderer.zeroday(f28 + i2 + 0.0f, f4 + 0.0f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + i2 + 0.5f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(-1.0f, 0.0f, 0.0f).zues();
                        }
                    }
                    if (j2 <= 1) {
                        for (int k2 = 0; k2 < 8; ++k2) {
                            worldrenderer.zeroday(f28 + k2 + 1.0f - 9.765625E-4f, f4 + 0.0f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + k2 + 0.5f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(1.0f, 0.0f, 0.0f).zues();
                            worldrenderer.zeroday(f28 + k2 + 1.0f - 9.765625E-4f, f4 + 4.0f, (double)(f29 + 8.0f)).zerodayisaminecraftcheat((f26 + k2 + 0.5f) * 0.00390625f + f21, (f27 + 8.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(1.0f, 0.0f, 0.0f).zues();
                            worldrenderer.zeroday(f28 + k2 + 1.0f - 9.765625E-4f, f4 + 4.0f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + k2 + 0.5f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(1.0f, 0.0f, 0.0f).zues();
                            worldrenderer.zeroday(f28 + k2 + 1.0f - 9.765625E-4f, f4 + 0.0f, (double)(f29 + 0.0f)).zerodayisaminecraftcheat((f26 + k2 + 0.5f) * 0.00390625f + f21, (f27 + 0.0f) * 0.00390625f + f22).zerodayisaminecraftcheat(f11, f12, f13, 0.8f).sigma(1.0f, 0.0f, 0.0f).zues();
                        }
                    }
                    if (l > -1) {
                        for (int l2 = 0; l2 < 8; ++l2) {
                            worldrenderer.zeroday(f28 + 0.0f, f4 + 4.0f, (double)(f29 + l2 + 0.0f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + l2 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, -1.0f).zues();
                            worldrenderer.zeroday(f28 + 8.0f, f4 + 4.0f, (double)(f29 + l2 + 0.0f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + l2 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, -1.0f).zues();
                            worldrenderer.zeroday(f28 + 8.0f, f4 + 0.0f, (double)(f29 + l2 + 0.0f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + l2 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, -1.0f).zues();
                            worldrenderer.zeroday(f28 + 0.0f, f4 + 0.0f, (double)(f29 + l2 + 0.0f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + l2 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, -1.0f).zues();
                        }
                    }
                    if (l <= 1) {
                        for (int i3 = 0; i3 < 8; ++i3) {
                            worldrenderer.zeroday(f28 + 0.0f, f4 + 4.0f, (double)(f29 + i3 + 1.0f - 9.765625E-4f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + i3 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, 1.0f).zues();
                            worldrenderer.zeroday(f28 + 8.0f, f4 + 4.0f, (double)(f29 + i3 + 1.0f - 9.765625E-4f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + i3 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, 1.0f).zues();
                            worldrenderer.zeroday(f28 + 8.0f, f4 + 0.0f, (double)(f29 + i3 + 1.0f - 9.765625E-4f)).zerodayisaminecraftcheat((f26 + 8.0f) * 0.00390625f + f21, (f27 + i3 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, 1.0f).zues();
                            worldrenderer.zeroday(f28 + 0.0f, f4 + 0.0f, (double)(f29 + i3 + 1.0f - 9.765625E-4f)).zerodayisaminecraftcheat((f26 + 0.0f) * 0.00390625f + f21, (f27 + i3 + 0.5f) * 0.00390625f + f22).zerodayisaminecraftcheat(f17, f18, f19, 0.8f).sigma(0.0f, 0.0f, 1.0f).zues();
                        }
                    }
                    tessellator.zeroday();
                }
            }
            this.Z.sigma();
        }
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.c();
        GlStateManager.g();
    }
    
    public void zerodayisaminecraftcheat(final long finishTimeNano) {
        this.pandora |= this.J.zerodayisaminecraftcheat(finishTimeNano);
        if (this.vape.size() > 0) {
            final Iterator iterator = this.vape.iterator();
            while (iterator.hasNext()) {
                final RenderChunk renderchunk = iterator.next();
                if (!this.J.zerodayisaminecraftcheat(renderchunk)) {
                    break;
                }
                renderchunk.zerodayisaminecraftcheat(false);
                iterator.remove();
                this.i.remove(renderchunk);
                this.flux.remove(renderchunk);
            }
        }
        if (this.flux.size() > 0) {
            final Iterator iterator2 = this.flux.iterator();
            if (iterator2.hasNext()) {
                final RenderChunk renderchunk2 = iterator2.next();
                if (this.J.sigma(renderchunk2)) {
                    iterator2.remove();
                }
            }
        }
        int j = 0;
        int k = Config.k();
        final int i = k * 2;
        final Iterator iterator3 = this.i.iterator();
        while (iterator3.hasNext()) {
            final RenderChunk renderchunk3 = iterator3.next();
            if (!this.J.zerodayisaminecraftcheat(renderchunk3)) {
                break;
            }
            renderchunk3.zerodayisaminecraftcheat(false);
            iterator3.remove();
            if (renderchunk3.vape().zerodayisaminecraftcheat() && k < i) {
                ++k;
            }
            if (++j >= k) {
                break;
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final Entity p_180449_1_, final float partialTicks) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final WorldBorder worldborder = this.h.K();
        final double d0 = this.zerodayisaminecraftcheat.r.sigma * 16;
        if (p_180449_1_.s >= worldborder.flux() - d0 || p_180449_1_.s <= worldborder.pandora() + d0 || p_180449_1_.u >= worldborder.vape() - d0 || p_180449_1_.u <= worldborder.zues() + d0) {
            double d2 = 1.0 - worldborder.zerodayisaminecraftcheat(p_180449_1_) / d0;
            d2 = Math.pow(d2, 4.0);
            final double d3 = p_180449_1_.Q + (p_180449_1_.s - p_180449_1_.Q) * partialTicks;
            final double d4 = p_180449_1_.R + (p_180449_1_.t - p_180449_1_.R) * partialTicks;
            final double d5 = p_180449_1_.S + (p_180449_1_.u - p_180449_1_.S) * partialTicks;
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 1, 1, 0);
            this.f.zerodayisaminecraftcheat(RenderGlobal.e);
            GlStateManager.zerodayisaminecraftcheat(false);
            GlStateManager.v();
            final int i = worldborder.sigma().zerodayisaminecraftcheat();
            final float f = (i >> 16 & 0xFF) / 255.0f;
            final float f2 = (i >> 8 & 0xFF) / 255.0f;
            final float f3 = (i & 0xFF) / 255.0f;
            GlStateManager.sigma(f, f2, f3, (float)d2);
            GlStateManager.zerodayisaminecraftcheat(-3.0f, -3.0f);
            GlStateManager.i();
            GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
            GlStateManager.pandora();
            GlStateManager.h();
            final float f4 = Minecraft.C() % 3000L / 3000.0f;
            final float f5 = 0.0f;
            final float f6 = 0.0f;
            final float f7 = 128.0f;
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
            worldrenderer.sigma(-d3, -d4, -d5);
            double d6 = Math.max(MathHelper.sigma(d5 - d0), worldborder.zues());
            double d7 = Math.min(MathHelper.flux(d5 + d0), worldborder.vape());
            if (d3 > worldborder.flux() - d0) {
                float f8 = 0.0f;
                for (double d8 = d6; d8 < d7; ++d8, f8 += 0.5f) {
                    final double d9 = Math.min(1.0, d7 - d8);
                    final float f9 = (float)d9 * 0.5f;
                    worldrenderer.zeroday(worldborder.flux(), 256.0, d8).zerodayisaminecraftcheat(f4 + f8, f4 + 0.0f).zues();
                    worldrenderer.zeroday(worldborder.flux(), 256.0, d8 + d9).zerodayisaminecraftcheat(f4 + f9 + f8, f4 + 0.0f).zues();
                    worldrenderer.zeroday(worldborder.flux(), 0.0, d8 + d9).zerodayisaminecraftcheat(f4 + f9 + f8, f4 + 128.0f).zues();
                    worldrenderer.zeroday(worldborder.flux(), 0.0, d8).zerodayisaminecraftcheat(f4 + f8, f4 + 128.0f).zues();
                }
            }
            if (d3 < worldborder.pandora() + d0) {
                float f10 = 0.0f;
                for (double d10 = d6; d10 < d7; ++d10, f10 += 0.5f) {
                    final double d11 = Math.min(1.0, d7 - d10);
                    final float f11 = (float)d11 * 0.5f;
                    worldrenderer.zeroday(worldborder.pandora(), 256.0, d10).zerodayisaminecraftcheat(f4 + f10, f4 + 0.0f).zues();
                    worldrenderer.zeroday(worldborder.pandora(), 256.0, d10 + d11).zerodayisaminecraftcheat(f4 + f11 + f10, f4 + 0.0f).zues();
                    worldrenderer.zeroday(worldborder.pandora(), 0.0, d10 + d11).zerodayisaminecraftcheat(f4 + f11 + f10, f4 + 128.0f).zues();
                    worldrenderer.zeroday(worldborder.pandora(), 0.0, d10).zerodayisaminecraftcheat(f4 + f10, f4 + 128.0f).zues();
                }
            }
            d6 = Math.max(MathHelper.sigma(d3 - d0), worldborder.pandora());
            d7 = Math.min(MathHelper.flux(d3 + d0), worldborder.flux());
            if (d5 > worldborder.vape() - d0) {
                float f12 = 0.0f;
                for (double d12 = d6; d12 < d7; ++d12, f12 += 0.5f) {
                    final double d13 = Math.min(1.0, d7 - d12);
                    final float f13 = (float)d13 * 0.5f;
                    worldrenderer.zeroday(d12, 256.0, worldborder.vape()).zerodayisaminecraftcheat(f4 + f12, f4 + 0.0f).zues();
                    worldrenderer.zeroday(d12 + d13, 256.0, worldborder.vape()).zerodayisaminecraftcheat(f4 + f13 + f12, f4 + 0.0f).zues();
                    worldrenderer.zeroday(d12 + d13, 0.0, worldborder.vape()).zerodayisaminecraftcheat(f4 + f13 + f12, f4 + 128.0f).zues();
                    worldrenderer.zeroday(d12, 0.0, worldborder.vape()).zerodayisaminecraftcheat(f4 + f12, f4 + 128.0f).zues();
                }
            }
            if (d5 < worldborder.zues() + d0) {
                float f14 = 0.0f;
                for (double d14 = d6; d14 < d7; ++d14, f14 += 0.5f) {
                    final double d15 = Math.min(1.0, d7 - d14);
                    final float f15 = (float)d15 * 0.5f;
                    worldrenderer.zeroday(d14, 256.0, worldborder.zues()).zerodayisaminecraftcheat(f4 + f14, f4 + 0.0f).zues();
                    worldrenderer.zeroday(d14 + d15, 256.0, worldborder.zues()).zerodayisaminecraftcheat(f4 + f15 + f14, f4 + 0.0f).zues();
                    worldrenderer.zeroday(d14 + d15, 0.0, worldborder.zues()).zerodayisaminecraftcheat(f4 + f15 + f14, f4 + 128.0f).zues();
                    worldrenderer.zeroday(d14, 0.0, worldborder.zues()).zerodayisaminecraftcheat(f4 + f14, f4 + 128.0f).zues();
                }
            }
            tessellator.zeroday();
            worldrenderer.sigma(0.0, 0.0, 0.0);
            GlStateManager.g();
            GlStateManager.sigma();
            GlStateManager.zerodayisaminecraftcheat(0.0f, 0.0f);
            GlStateManager.j();
            GlStateManager.pandora();
            GlStateManager.c();
            GlStateManager.w();
            GlStateManager.zerodayisaminecraftcheat(true);
        }
    }
    
    private void m() {
        GlStateManager.zerodayisaminecraftcheat(774, 768, 1, 0);
        GlStateManager.d();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 0.5f);
        GlStateManager.zerodayisaminecraftcheat(-3.0f, -3.0f);
        GlStateManager.i();
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        GlStateManager.pandora();
        GlStateManager.v();
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.k.vape();
        }
    }
    
    private void n() {
        GlStateManager.sigma();
        GlStateManager.zerodayisaminecraftcheat(0.0f, 0.0f);
        GlStateManager.j();
        GlStateManager.pandora();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.w();
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.k.momgetthecamera();
        }
    }
    
    public void zerodayisaminecraftcheat(final Tessellator tessellatorIn, final WorldRenderer worldRendererIn, final Entity entityIn, final float partialTicks) {
        final double d0 = entityIn.Q + (entityIn.s - entityIn.Q) * partialTicks;
        final double d2 = entityIn.R + (entityIn.t - entityIn.R) * partialTicks;
        final double d3 = entityIn.S + (entityIn.u - entityIn.S) * partialTicks;
        if (!this.zeroday.isEmpty()) {
            this.f.zerodayisaminecraftcheat(TextureMap.zeroday);
            this.m();
            worldRendererIn.zerodayisaminecraftcheat(7, DefaultVertexFormats.zerodayisaminecraftcheat);
            worldRendererIn.sigma(-d0, -d2, -d3);
            worldRendererIn.pandora();
            final Iterator iterator = this.zeroday.values().iterator();
            while (iterator.hasNext()) {
                final DestroyBlockProgress destroyblockprogress = iterator.next();
                final BlockPos blockpos = destroyblockprogress.zerodayisaminecraftcheat();
                final double d4 = blockpos.zerodayisaminecraftcheat() - d0;
                final double d5 = blockpos.zeroday() - d2;
                final double d6 = blockpos.sigma() - d3;
                final Block block = this.h.zeroday(blockpos).sigma();
                boolean flag2;
                if (Reflector.bh.zeroday()) {
                    boolean flag1 = block instanceof BlockChest || block instanceof BlockEnderChest || block instanceof BlockSign || block instanceof BlockSkull;
                    if (!flag1) {
                        final TileEntity tileentity = this.h.zerodayisaminecraftcheat(blockpos);
                        if (tileentity != null) {
                            flag1 = Reflector.zeroday(tileentity, Reflector.bh, new Object[0]);
                        }
                    }
                    flag2 = !flag1;
                }
                else {
                    flag2 = (!(block instanceof BlockChest) && !(block instanceof BlockEnderChest) && !(block instanceof BlockSign) && !(block instanceof BlockSkull));
                }
                if (flag2) {
                    if (d4 * d4 + d5 * d5 + d6 * d6 > 1024.0) {
                        iterator.remove();
                    }
                    else {
                        final IBlockState iblockstate = this.h.zeroday(blockpos);
                        if (iblockstate.sigma().flux() == Material.zerodayisaminecraftcheat) {
                            continue;
                        }
                        final int i = destroyblockprogress.zeroday();
                        final TextureAtlasSprite textureatlassprite = this.v[i];
                        final BlockRendererDispatcher blockrendererdispatcher = this.zerodayisaminecraftcheat.X();
                        blockrendererdispatcher.zerodayisaminecraftcheat(iblockstate, blockpos, textureatlassprite, this.h);
                    }
                }
            }
            tessellatorIn.zeroday();
            worldRendererIn.sigma(0.0, 0.0, 0.0);
            this.n();
        }
    }
    
    public void zerodayisaminecraftcheat(final EntityPlayer player, final MovingObjectPosition movingObjectPositionIn, final int p_72731_3_, final float partialTicks) {
        if (p_72731_3_ == 0 && movingObjectPositionIn.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            GlStateManager.sigma(0.0f, 0.0f, 0.0f, 0.4f);
            GL11.glLineWidth(2.0f);
            GlStateManager.n();
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.V();
            }
            GlStateManager.zerodayisaminecraftcheat(false);
            final float f = 0.002f;
            final BlockPos blockpos = movingObjectPositionIn.zerodayisaminecraftcheat();
            final Block block = this.h.zeroday(blockpos).sigma();
            if (block.flux() != Material.zerodayisaminecraftcheat && this.h.K().zerodayisaminecraftcheat(blockpos)) {
                block.sigma((IBlockAccess)this.h, blockpos);
                final double d0 = player.Q + (player.s - player.Q) * partialTicks;
                final double d2 = player.R + (player.t - player.R) * partialTicks;
                final double d3 = player.S + (player.u - player.S) * partialTicks;
                if (!zeroday.pandora.zerodayisaminecraftcheat.pandora.a.zerodayisaminecraftcheat) {
                    zeroday.pandora.zerodayisaminecraftcheat.h.V.zerodayisaminecraftcheat(block.sigma(this.h, blockpos).zeroday(0.0020000000949949026, 0.0020000000949949026, 0.0020000000949949026).sigma(-d0, -d2, -d3), 1879113472, false);
                    zeroday.pandora.zerodayisaminecraftcheat.h.V.zeroday(block.sigma(this.h, blockpos).zeroday(0.0020000000949949026, 0.0020000000949949026, 0.0020000000949949026).sigma(-d0, -d2, -d3), -16777216, false);
                }
                else {
                    zerodayisaminecraftcheat(block.sigma(this.h, blockpos).zeroday(0.0020000000949949026, 0.0020000000949949026, 0.0020000000949949026).sigma(-d0, -d2, -d3));
                }
            }
            GlStateManager.zerodayisaminecraftcheat(true);
            GlStateManager.m();
            if (Config.aC()) {
                sigma.zerodayisaminecraftcheat.j.U();
            }
            GlStateManager.c();
        }
    }
    
    public static void zerodayisaminecraftcheat(final AxisAlignedBB p_181561_0_) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(3, DefaultVertexFormats.zues);
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zeroday, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zeroday, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zeroday, p_181561_0_.flux).zues();
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zeroday, p_181561_0_.flux).zues();
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zeroday, p_181561_0_.sigma).zues();
        tessellator.zeroday();
        worldrenderer.zerodayisaminecraftcheat(3, DefaultVertexFormats.zues);
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zues, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zues, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zues, p_181561_0_.flux).zues();
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zues, p_181561_0_.flux).zues();
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zues, p_181561_0_.sigma).zues();
        tessellator.zeroday();
        worldrenderer.zerodayisaminecraftcheat(1, DefaultVertexFormats.zues);
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zeroday, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zues, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zeroday, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zues, p_181561_0_.sigma).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zeroday, p_181561_0_.flux).zues();
        worldrenderer.zeroday(p_181561_0_.pandora, p_181561_0_.zues, p_181561_0_.flux).zues();
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zeroday, p_181561_0_.flux).zues();
        worldrenderer.zeroday(p_181561_0_.zerodayisaminecraftcheat, p_181561_0_.zues, p_181561_0_.flux).zues();
        tessellator.zeroday();
    }
    
    public static void zerodayisaminecraftcheat(final AxisAlignedBB p_181563_0_, final int p_181563_1_, final int p_181563_2_, final int p_181563_3_, final int p_181563_4_) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(3, DefaultVertexFormats.flux);
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zeroday, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zeroday, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zeroday, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zeroday, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zeroday, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        tessellator.zeroday();
        worldrenderer.zerodayisaminecraftcheat(3, DefaultVertexFormats.flux);
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zues, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zues, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zues, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zues, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zues, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        tessellator.zeroday();
        worldrenderer.zerodayisaminecraftcheat(1, DefaultVertexFormats.flux);
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zeroday, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zues, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zeroday, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zues, p_181563_0_.sigma).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zeroday, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.pandora, p_181563_0_.zues, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zeroday, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        worldrenderer.zeroday(p_181563_0_.zerodayisaminecraftcheat, p_181563_0_.zues, p_181563_0_.flux).zeroday(p_181563_1_, p_181563_2_, p_181563_3_, p_181563_4_).zues();
        tessellator.zeroday();
    }
    
    private void zeroday(final int x1, final int y1, final int z1, final int x2, final int y2, final int z2) {
        this.l.zerodayisaminecraftcheat(x1, y1, z1, x2, y2, z2);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final BlockPos pos) {
        final int i = pos.zerodayisaminecraftcheat();
        final int j = pos.zeroday();
        final int k = pos.sigma();
        this.zeroday(i - 1, j - 1, k - 1, i + 1, j + 1, k + 1);
    }
    
    @Override
    public void zeroday(final BlockPos pos) {
        final int i = pos.zerodayisaminecraftcheat();
        final int j = pos.zeroday();
        final int k = pos.sigma();
        this.zeroday(i - 1, j - 1, k - 1, i + 1, j + 1, k + 1);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int x1, final int y1, final int z1, final int x2, final int y2, final int z2) {
        this.zeroday(x1 - 1, y1 - 1, z1 - 1, x2 + 1, y2 + 1, z2 + 1);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String recordName, final BlockPos blockPosIn) {
        final ISound isound = this.u.get(blockPosIn);
        if (isound != null) {
            this.zerodayisaminecraftcheat.P().zeroday(isound);
            this.u.remove(blockPosIn);
        }
        if (recordName != null) {
            final ItemRecord itemrecord = ItemRecord.pandora(recordName);
            if (itemrecord != null) {
                this.zerodayisaminecraftcheat.o.zerodayisaminecraftcheat(itemrecord.j());
            }
            ResourceLocation resourcelocation = null;
            if (Reflector.br.zeroday() && itemrecord != null) {
                resourcelocation = (ResourceLocation)Reflector.vape(itemrecord, Reflector.br, recordName);
            }
            if (resourcelocation == null) {
                resourcelocation = new ResourceLocation(recordName);
            }
            final PositionedSoundRecord positionedsoundrecord = PositionedSoundRecord.zerodayisaminecraftcheat(resourcelocation, (float)blockPosIn.zerodayisaminecraftcheat(), (float)blockPosIn.zeroday(), (float)blockPosIn.sigma());
            this.u.put(blockPosIn, positionedsoundrecord);
            this.zerodayisaminecraftcheat.P().zerodayisaminecraftcheat(positionedsoundrecord);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String soundName, final double x, final double y, final double z, final float volume, final float pitch) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityPlayer except, final String soundName, final double x, final double y, final double z, final float volume, final float pitch) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int particleID, final boolean ignoreRange, final double xCoord, final double yCoord, final double zCoord, final double xOffset, final double yOffset, final double zOffset, final int... p_180442_15_) {
        try {
            this.zeroday(particleID, ignoreRange, xCoord, yCoord, zCoord, xOffset, yOffset, zOffset, p_180442_15_);
        }
        catch (Throwable throwable) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Exception while adding particle");
            final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Particle being added");
            crashreportcategory.zerodayisaminecraftcheat("ID", particleID);
            if (p_180442_15_ != null) {
                crashreportcategory.zerodayisaminecraftcheat("Parameters", p_180442_15_);
            }
            crashreportcategory.zerodayisaminecraftcheat("Position", new Callable() {
                private static final String zeroday = "CL_00000955";
                
                public String zerodayisaminecraftcheat() throws Exception {
                    return CrashReportCategory.zerodayisaminecraftcheat(xCoord, yCoord, zCoord);
                }
            });
            throw new ReportedException(crashreport);
        }
    }
    
    private void zerodayisaminecraftcheat(final EnumParticleTypes particleIn, final double p_174972_2_, final double p_174972_4_, final double p_174972_6_, final double p_174972_8_, final double p_174972_10_, final double p_174972_12_, final int... p_174972_14_) {
        this.zerodayisaminecraftcheat(particleIn.sigma(), particleIn.zues(), p_174972_2_, p_174972_4_, p_174972_6_, p_174972_8_, p_174972_10_, p_174972_12_, p_174972_14_);
    }
    
    private EntityFX zeroday(final int p_174974_1_, final boolean ignoreRange, final double p_174974_3_, final double p_174974_5_, final double p_174974_7_, final double p_174974_9_, final double p_174974_11_, final double p_174974_13_, final int... p_174974_15_) {
        if (this.zerodayisaminecraftcheat == null || this.zerodayisaminecraftcheat.V() == null || this.zerodayisaminecraftcheat.g == null) {
            return null;
        }
        int i = this.zerodayisaminecraftcheat.r.aD;
        if (i == 1 && this.h.g.nextInt(3) == 0) {
            i = 2;
        }
        final double d0 = this.zerodayisaminecraftcheat.V().s - p_174974_3_;
        final double d2 = this.zerodayisaminecraftcheat.V().t - p_174974_5_;
        final double d3 = this.zerodayisaminecraftcheat.V().u - p_174974_7_;
        if (p_174974_1_ == EnumParticleTypes.sigma.sigma() && !Config.A()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.zeroday.sigma() && !Config.A()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.zerodayisaminecraftcheat.sigma() && !Config.A()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.momgetthecamera.sigma() && !Config.E()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.a.sigma() && !Config.D()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.d.sigma() && !Config.C()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.e.sigma() && !Config.C()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.h.sigma() && !Config.H()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.i.sigma() && !Config.H()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.f.sigma() && !Config.H()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.g.sigma() && !Config.H()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.j.sigma() && !Config.H()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.q.sigma() && !Config.v()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.s.sigma() && !Config.B()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.w.sigma() && !Config.z()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.k.sigma() && !Config.ai()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.l.sigma() && !Config.ai()) {
            return null;
        }
        if (p_174974_1_ == EnumParticleTypes.pandora.sigma() && !Config.I()) {
            return null;
        }
        if (ignoreRange) {
            return this.zerodayisaminecraftcheat.g.zerodayisaminecraftcheat(p_174974_1_, p_174974_3_, p_174974_5_, p_174974_7_, p_174974_9_, p_174974_11_, p_174974_13_, p_174974_15_);
        }
        final double d4 = 16.0;
        double d5 = 256.0;
        if (p_174974_1_ == EnumParticleTypes.b.sigma()) {
            d5 = 38416.0;
        }
        if (d0 * d0 + d2 * d2 + d3 * d3 > d5) {
            return null;
        }
        if (i > 1) {
            return null;
        }
        final EntityFX entityfx = this.zerodayisaminecraftcheat.g.zerodayisaminecraftcheat(p_174974_1_, p_174974_3_, p_174974_5_, p_174974_7_, p_174974_9_, p_174974_11_, p_174974_13_, p_174974_15_);
        if (p_174974_1_ == EnumParticleTypes.zues.sigma()) {
            CustomColorizer.zeroday(entityfx, this.h, p_174974_3_, p_174974_5_, p_174974_7_);
        }
        if (p_174974_1_ == EnumParticleTypes.flux.sigma()) {
            CustomColorizer.zeroday(entityfx, this.h, p_174974_3_, p_174974_5_, p_174974_7_);
        }
        if (p_174974_1_ == EnumParticleTypes.F.sigma()) {
            CustomColorizer.zeroday(entityfx, this.h, p_174974_3_, p_174974_5_, p_174974_7_);
        }
        if (p_174974_1_ == EnumParticleTypes.o.sigma()) {
            CustomColorizer.zeroday(entityfx);
        }
        if (p_174974_1_ == EnumParticleTypes.q.sigma()) {
            CustomColorizer.zerodayisaminecraftcheat(entityfx);
        }
        if (p_174974_1_ == EnumParticleTypes.w.sigma()) {
            CustomColorizer.zerodayisaminecraftcheat(entityfx, this.h, p_174974_3_, p_174974_5_, p_174974_7_);
        }
        return entityfx;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn) {
        RandomMobs.zerodayisaminecraftcheat(entityIn);
    }
    
    @Override
    public void zeroday(final Entity entityIn) {
    }
    
    public void a() {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int p_180440_1_, final BlockPos p_180440_2_, final int p_180440_3_) {
        switch (p_180440_1_) {
            case 1013:
            case 1018: {
                if (this.zerodayisaminecraftcheat.V() == null) {
                    break;
                }
                final double d0 = p_180440_2_.zerodayisaminecraftcheat() - this.zerodayisaminecraftcheat.V().s;
                final double d2 = p_180440_2_.zeroday() - this.zerodayisaminecraftcheat.V().t;
                final double d3 = p_180440_2_.sigma() - this.zerodayisaminecraftcheat.V().u;
                final double d4 = Math.sqrt(d0 * d0 + d2 * d2 + d3 * d3);
                double d5 = this.zerodayisaminecraftcheat.V().s;
                double d6 = this.zerodayisaminecraftcheat.V().t;
                double d7 = this.zerodayisaminecraftcheat.V().u;
                if (d4 > 0.0) {
                    d5 += d0 / d4 * 2.0;
                    d6 += d2 / d4 * 2.0;
                    d7 += d3 / d4 * 2.0;
                }
                if (p_180440_1_ == 1013) {
                    this.h.zerodayisaminecraftcheat(d5, d6, d7, "mob.wither.spawn", 1.0f, 1.0f, false);
                    break;
                }
                this.h.zerodayisaminecraftcheat(d5, d6, d7, "mob.enderdragon.end", 5.0f, 1.0f, false);
                break;
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityPlayer player, final int sfxType, final BlockPos blockPosIn, final int p_180439_4_) {
        final Random random = this.h.g;
        switch (sfxType) {
            case 1000: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.click", 1.0f, 1.0f, false);
                break;
            }
            case 1001: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.click", 1.0f, 1.2f, false);
                break;
            }
            case 1002: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.bow", 1.0f, 1.2f, false);
                break;
            }
            case 1003: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.door_open", 1.0f, this.h.g.nextFloat() * 0.1f + 0.9f, false);
                break;
            }
            case 1004: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.fizz", 0.5f, 2.6f + (random.nextFloat() - random.nextFloat()) * 0.8f, false);
                break;
            }
            case 1005: {
                if (Item.zerodayisaminecraftcheat(p_180439_4_) instanceof ItemRecord) {
                    this.h.zerodayisaminecraftcheat(blockPosIn, "records." + ((ItemRecord)Item.zerodayisaminecraftcheat(p_180439_4_)).vape);
                    break;
                }
                this.h.zerodayisaminecraftcheat(blockPosIn, (String)null);
                break;
            }
            case 1006: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.door_close", 1.0f, this.h.g.nextFloat() * 0.1f + 0.9f, false);
                break;
            }
            case 1007: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.ghast.charge", 10.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1008: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.ghast.fireball", 10.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1009: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.ghast.fireball", 2.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1010: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.zombie.wood", 2.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1011: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.zombie.metal", 2.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1012: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.zombie.woodbreak", 2.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1014: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.wither.shoot", 2.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1015: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.bat.takeoff", 0.05f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1016: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.zombie.infect", 2.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1017: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "mob.zombie.unfect", 2.0f, (random.nextFloat() - random.nextFloat()) * 0.2f + 1.0f, false);
                break;
            }
            case 1020: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.anvil_break", 1.0f, this.h.g.nextFloat() * 0.1f + 0.9f, false);
                break;
            }
            case 1021: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.anvil_use", 1.0f, this.h.g.nextFloat() * 0.1f + 0.9f, false);
                break;
            }
            case 1022: {
                this.h.zerodayisaminecraftcheat(blockPosIn, "random.anvil_land", 0.3f, this.h.g.nextFloat() * 0.1f + 0.9f, false);
                break;
            }
            case 2000: {
                final int k = p_180439_4_ % 3 - 1;
                final int l = p_180439_4_ / 3 % 3 - 1;
                final double d13 = blockPosIn.zerodayisaminecraftcheat() + k * 0.6 + 0.5;
                final double d14 = blockPosIn.zeroday() + 0.5;
                final double d15 = blockPosIn.sigma() + l * 0.6 + 0.5;
                for (int l2 = 0; l2 < 10; ++l2) {
                    final double d16 = random.nextDouble() * 0.2 + 0.01;
                    final double d17 = d13 + k * 0.01 + (random.nextDouble() - 0.5) * l * 0.5;
                    final double d18 = d14 + (random.nextDouble() - 0.5) * 0.5;
                    final double d19 = d15 + l * 0.01 + (random.nextDouble() - 0.5) * k * 0.5;
                    final double d20 = k * d16 + random.nextGaussian() * 0.01;
                    final double d21 = -0.03 + random.nextGaussian() * 0.01;
                    final double d22 = l * d16 + random.nextGaussian() * 0.01;
                    this.zerodayisaminecraftcheat(EnumParticleTypes.d, d17, d18, d19, d20, d21, d22, new int[0]);
                }
            }
            case 2001: {
                final Block block = Block.zerodayisaminecraftcheat(p_180439_4_ & 0xFFF);
                if (block.flux() != Material.zerodayisaminecraftcheat) {
                    this.zerodayisaminecraftcheat.P().zerodayisaminecraftcheat(new PositionedSoundRecord(new ResourceLocation(block.x.zerodayisaminecraftcheat()), (block.x.pandora() + 1.0f) / 2.0f, block.x.zues() * 0.8f, blockPosIn.zerodayisaminecraftcheat() + 0.5f, blockPosIn.zeroday() + 0.5f, blockPosIn.sigma() + 0.5f));
                }
                this.zerodayisaminecraftcheat.g.zerodayisaminecraftcheat(blockPosIn, block.sigma(p_180439_4_ >> 12 & 0xFF));
                break;
            }
            case 2002: {
                final double d23 = blockPosIn.zerodayisaminecraftcheat();
                final double d24 = blockPosIn.zeroday();
                final double d25 = blockPosIn.sigma();
                for (int i1 = 0; i1 < 8; ++i1) {
                    this.zerodayisaminecraftcheat(EnumParticleTypes.C, d23, d24, d25, random.nextGaussian() * 0.15, random.nextDouble() * 0.2, random.nextGaussian() * 0.15, Item.zerodayisaminecraftcheat(Items.br), p_180439_4_);
                }
                final int j1 = Items.br.vape(p_180439_4_);
                final float f = (j1 >> 16 & 0xFF) / 255.0f;
                final float f2 = (j1 >> 8 & 0xFF) / 255.0f;
                final float f3 = (j1 >> 0 & 0xFF) / 255.0f;
                EnumParticleTypes enumparticletypes = EnumParticleTypes.f;
                if (Items.br.momgetthecamera(p_180439_4_)) {
                    enumparticletypes = EnumParticleTypes.g;
                }
                for (int k2 = 0; k2 < 100; ++k2) {
                    final double d26 = random.nextDouble() * 4.0;
                    final double d27 = random.nextDouble() * 3.141592653589793 * 2.0;
                    final double d28 = Math.cos(d27) * d26;
                    final double d29 = 0.01 + random.nextDouble() * 0.5;
                    final double d30 = Math.sin(d27) * d26;
                    final EntityFX entityfx = this.zeroday(enumparticletypes.sigma(), enumparticletypes.zues(), d23 + d28 * 0.1, d24 + 0.3, d25 + d30 * 0.1, d28, d29, d30, new int[0]);
                    if (entityfx != null) {
                        final float f4 = 0.75f + random.nextFloat() * 0.25f;
                        entityfx.zerodayisaminecraftcheat(f * f4, f2 * f4, f3 * f4);
                        entityfx.sigma((float)d26);
                    }
                }
                this.h.zerodayisaminecraftcheat(blockPosIn, "game.potion.smash", 1.0f, this.h.g.nextFloat() * 0.1f + 0.9f, false);
                break;
            }
            case 2003: {
                final double var7 = blockPosIn.zerodayisaminecraftcheat() + 0.5;
                final double var8 = blockPosIn.zeroday();
                final double var9 = blockPosIn.sigma() + 0.5;
                for (int var10 = 0; var10 < 8; ++var10) {
                    this.zerodayisaminecraftcheat(EnumParticleTypes.C, var7, var8, var9, random.nextGaussian() * 0.15, random.nextDouble() * 0.2, random.nextGaussian() * 0.15, Item.zerodayisaminecraftcheat(Items.bz));
                }
                for (double var11 = 0.0; var11 < 6.283185307179586; var11 += 0.15707963267948966) {
                    this.zerodayisaminecraftcheat(EnumParticleTypes.q, var7 + Math.cos(var11) * 5.0, var8 - 0.4, var9 + Math.sin(var11) * 5.0, Math.cos(var11) * -5.0, 0.0, Math.sin(var11) * -5.0, new int[0]);
                    this.zerodayisaminecraftcheat(EnumParticleTypes.q, var7 + Math.cos(var11) * 5.0, var8 - 0.4, var9 + Math.sin(var11) * 5.0, Math.cos(var11) * -7.0, 0.0, Math.sin(var11) * -7.0, new int[0]);
                }
            }
            case 2004: {
                for (int var12 = 0; var12 < 20; ++var12) {
                    final double d31 = blockPosIn.zerodayisaminecraftcheat() + 0.5 + (this.h.g.nextFloat() - 0.5) * 2.0;
                    final double d32 = blockPosIn.zeroday() + 0.5 + (this.h.g.nextFloat() - 0.5) * 2.0;
                    final double d33 = blockPosIn.sigma() + 0.5 + (this.h.g.nextFloat() - 0.5) * 2.0;
                    this.h.zerodayisaminecraftcheat(EnumParticleTypes.d, d31, d32, d33, 0.0, 0.0, 0.0, new int[0]);
                    this.h.zerodayisaminecraftcheat(EnumParticleTypes.s, d31, d32, d33, 0.0, 0.0, 0.0, new int[0]);
                }
            }
            case 2005: {
                ItemDye.zerodayisaminecraftcheat(this.h, blockPosIn, p_180439_4_);
                break;
            }
        }
    }
    
    @Override
    public void zeroday(final int breakerId, final BlockPos pos, final int progress) {
        if (progress >= 0 && progress < 10) {
            DestroyBlockProgress destroyblockprogress = this.zeroday.get(breakerId);
            if (destroyblockprogress == null || destroyblockprogress.zerodayisaminecraftcheat().zerodayisaminecraftcheat() != pos.zerodayisaminecraftcheat() || destroyblockprogress.zerodayisaminecraftcheat().zeroday() != pos.zeroday() || destroyblockprogress.zerodayisaminecraftcheat().sigma() != pos.sigma()) {
                destroyblockprogress = new DestroyBlockProgress(breakerId, pos);
                this.zeroday.put(breakerId, destroyblockprogress);
            }
            destroyblockprogress.zerodayisaminecraftcheat(progress);
            destroyblockprogress.zeroday(this.t);
        }
        else {
            this.zeroday.remove(breakerId);
        }
    }
    
    public void b() {
        this.pandora = true;
    }
    
    public void c() {
        this.Z.zues();
    }
    
    public int d() {
        return this.l.flux.length;
    }
    
    public int e() {
        return this.j.size();
    }
    
    public int f() {
        return this.O;
    }
    
    public int g() {
        return this.am;
    }
    
    public void zerodayisaminecraftcheat(final Collection p_181023_1_, final Collection p_181023_2_) {
        final Set set = this.k;
        synchronized (this.k) {
            this.k.removeAll(p_181023_1_);
            this.k.addAll(p_181023_2_);
        }
        // monitorexit(this.k)
    }
    
    static final class zeroday
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002535";
        
        static {
            zerodayisaminecraftcheat = new int[VertexFormatElement.zeroday.values().length];
            try {
                RenderGlobal.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                RenderGlobal.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zeroday.pandora.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                RenderGlobal.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zeroday.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
        }
    }
    
    class zerodayisaminecraftcheat
    {
        final RenderChunk zerodayisaminecraftcheat;
        final EnumFacing zeroday;
        final Set sigma;
        final int pandora;
        private static final String flux = "CL_00002534";
        
        private zerodayisaminecraftcheat(final RenderChunk renderChunkIn, final EnumFacing facingIn, final int counterIn) {
            this.sigma = EnumSet.noneOf(EnumFacing.class);
            this.zerodayisaminecraftcheat = renderChunkIn;
            this.zeroday = facingIn;
            this.pandora = counterIn;
        }
        
        zerodayisaminecraftcheat(final RenderGlobal renderGlobal, final RenderChunk p_i13_2_, final EnumFacing p_i13_3_, final int p_i13_4_, final Object p_i13_5_) {
            this(renderGlobal, p_i13_2_, p_i13_3_, p_i13_4_);
        }
    }
}

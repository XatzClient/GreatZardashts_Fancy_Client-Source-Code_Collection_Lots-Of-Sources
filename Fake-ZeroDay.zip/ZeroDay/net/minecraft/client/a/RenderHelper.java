// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import org.lwjgl.opengl.GL11;
import net.minecraft.o.Vec3;
import java.nio.FloatBuffer;

public class RenderHelper
{
    private static FloatBuffer zerodayisaminecraftcheat;
    private static final Vec3 zeroday;
    private static final Vec3 sigma;
    
    static {
        RenderHelper.zerodayisaminecraftcheat = GLAllocation.zues(16);
        zeroday = new Vec3(0.20000000298023224, 1.0, -0.699999988079071).zerodayisaminecraftcheat();
        sigma = new Vec3(-0.20000000298023224, 1.0, 0.699999988079071).zerodayisaminecraftcheat();
    }
    
    public static void zerodayisaminecraftcheat() {
        GlStateManager.flux();
        GlStateManager.zeroday(0);
        GlStateManager.zeroday(1);
        GlStateManager.momgetthecamera();
    }
    
    public static void zeroday() {
        GlStateManager.zues();
        GlStateManager.zerodayisaminecraftcheat(0);
        GlStateManager.zerodayisaminecraftcheat(1);
        GlStateManager.vape();
        GlStateManager.zerodayisaminecraftcheat(1032, 5634);
        final float f = 0.4f;
        final float f2 = 0.6f;
        final float f3 = 0.0f;
        GL11.glLight(16384, 4611, zerodayisaminecraftcheat(RenderHelper.zeroday.zerodayisaminecraftcheat, RenderHelper.zeroday.zeroday, RenderHelper.zeroday.sigma, 0.0));
        GL11.glLight(16384, 4609, zerodayisaminecraftcheat(f2, f2, f2, 1.0f));
        GL11.glLight(16384, 4608, zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 1.0f));
        GL11.glLight(16384, 4610, zerodayisaminecraftcheat(f3, f3, f3, 1.0f));
        GL11.glLight(16385, 4611, zerodayisaminecraftcheat(RenderHelper.sigma.zerodayisaminecraftcheat, RenderHelper.sigma.zeroday, RenderHelper.sigma.sigma, 0.0));
        GL11.glLight(16385, 4609, zerodayisaminecraftcheat(f2, f2, f2, 1.0f));
        GL11.glLight(16385, 4608, zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 1.0f));
        GL11.glLight(16385, 4610, zerodayisaminecraftcheat(f3, f3, f3, 1.0f));
        GlStateManager.b(7424);
        GL11.glLightModel(2899, zerodayisaminecraftcheat(f, f, f, 1.0f));
    }
    
    private static FloatBuffer zerodayisaminecraftcheat(final double p_74517_0_, final double p_74517_2_, final double p_74517_4_, final double p_74517_6_) {
        return zerodayisaminecraftcheat((float)p_74517_0_, (float)p_74517_2_, (float)p_74517_4_, (float)p_74517_6_);
    }
    
    private static FloatBuffer zerodayisaminecraftcheat(final float p_74521_0_, final float p_74521_1_, final float p_74521_2_, final float p_74521_3_) {
        RenderHelper.zerodayisaminecraftcheat.clear();
        RenderHelper.zerodayisaminecraftcheat.put(p_74521_0_).put(p_74521_1_).put(p_74521_2_).put(p_74521_3_);
        RenderHelper.zerodayisaminecraftcheat.flip();
        return RenderHelper.zerodayisaminecraftcheat;
    }
    
    public static void sigma() {
        GlStateManager.v();
        GlStateManager.zeroday(-30.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(165.0f, 1.0f, 0.0f, 0.0f);
        zeroday();
        GlStateManager.w();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.util.Iterator;
import net.minecraft.l.Config;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.zeroday.ListedRenderChunk;
import net.minecraft.client.a.zeroday.RenderChunk;
import net.minecraft.o.EnumWorldBlockLayer;

public class RenderList extends ChunkRenderContainer
{
    private static final String sigma = "CL_00000957";
    
    @Override
    public void zerodayisaminecraftcheat(final EnumWorldBlockLayer layer) {
        if (this.zeroday) {
            if (this.zerodayisaminecraftcheat.size() == 0) {
                return;
            }
            for (final RenderChunk renderchunk : this.zerodayisaminecraftcheat) {
                final ListedRenderChunk listedrenderchunk = (ListedRenderChunk)renderchunk;
                GlStateManager.v();
                this.zerodayisaminecraftcheat(renderchunk);
                GL11.glCallList(listedrenderchunk.zerodayisaminecraftcheat(layer, listedrenderchunk.vape()));
                GlStateManager.w();
            }
            if (Config.ah()) {
                GlStateManager.p();
            }
            GlStateManager.x();
            this.zerodayisaminecraftcheat.clear();
        }
    }
}

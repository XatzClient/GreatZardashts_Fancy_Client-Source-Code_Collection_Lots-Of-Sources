// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.client.a.zues.Stitcher;

public class StitcherException extends RuntimeException
{
    private final Stitcher.zerodayisaminecraftcheat zerodayisaminecraftcheat;
    
    public StitcherException(final Stitcher.zerodayisaminecraftcheat p_i2344_1_, final String p_i2344_2_) {
        super(p_i2344_2_);
        this.zerodayisaminecraftcheat = p_i2344_1_;
    }
}

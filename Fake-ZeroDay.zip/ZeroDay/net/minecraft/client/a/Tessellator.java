// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

public class Tessellator
{
    private WorldRenderer zeroday;
    private WorldVertexBufferUploader sigma;
    public static final Tessellator zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new Tessellator(2097152);
    }
    
    public static Tessellator zerodayisaminecraftcheat() {
        return Tessellator.zerodayisaminecraftcheat;
    }
    
    public Tessellator(final int bufferSize) {
        this.sigma = new WorldVertexBufferUploader();
        this.zeroday = new WorldRenderer(bufferSize);
    }
    
    public void zeroday() {
        this.zeroday.flux();
        this.sigma.zerodayisaminecraftcheat(this.zeroday);
    }
    
    public WorldRenderer sigma() {
        return this.zeroday;
    }
}

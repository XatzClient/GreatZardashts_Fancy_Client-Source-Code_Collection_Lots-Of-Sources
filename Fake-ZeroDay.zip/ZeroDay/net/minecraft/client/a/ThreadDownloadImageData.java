// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.l.HttpResponse;
import net.minecraft.l.HttpRequest;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import net.minecraft.l.HttpPipeline;
import java.net.Proxy;
import org.apache.commons.io.FileUtils;
import net.minecraft.l.Config;
import net.minecraft.client.Minecraft;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.IOException;
import javax.imageio.ImageIO;
import net.minecraft.client.b.IResourceManager;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.logging.log4j.Logger;
import net.minecraft.client.a.zues.SimpleTexture;

public class ThreadDownloadImageData extends SimpleTexture
{
    private static final Logger b;
    private static final AtomicInteger c;
    private final File d;
    private final String e;
    private final IImageBuffer f;
    private BufferedImage g;
    private Thread h;
    private boolean i;
    private static final String j = "CL_00001049";
    public Boolean zerodayisaminecraftcheat;
    public boolean zeroday;
    
    static {
        b = LogManager.getLogger();
        c = new AtomicInteger(0);
    }
    
    public ThreadDownloadImageData(final File cacheFileIn, final String imageUrlIn, final ResourceLocation textureResourceLocation, final IImageBuffer imageBufferIn) {
        super(textureResourceLocation);
        this.zerodayisaminecraftcheat = null;
        this.zeroday = false;
        this.d = cacheFileIn;
        this.e = imageUrlIn;
        this.f = imageBufferIn;
    }
    
    private void vape() {
        if (!this.i && this.g != null) {
            this.i = true;
            if (this.a != null) {
                this.zues();
            }
            TextureUtil.zerodayisaminecraftcheat(super.zerodayisaminecraftcheat(), this.g);
        }
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        this.vape();
        return super.zerodayisaminecraftcheat();
    }
    
    public void zerodayisaminecraftcheat(final BufferedImage bufferedImageIn) {
        this.g = bufferedImageIn;
        if (this.f != null) {
            this.f.zerodayisaminecraftcheat();
        }
        this.zerodayisaminecraftcheat = (this.g != null);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) throws IOException {
        if (this.g == null && this.a != null) {
            super.zerodayisaminecraftcheat(resourceManager);
        }
        if (this.h == null) {
            if (this.d != null && this.d.isFile()) {
                ThreadDownloadImageData.b.debug("Loading http texture from local cache ({})", new Object[] { this.d });
                try {
                    this.g = ImageIO.read(this.d);
                    if (this.f != null) {
                        this.zerodayisaminecraftcheat(this.f.zerodayisaminecraftcheat(this.g));
                    }
                    this.zerodayisaminecraftcheat = (this.g != null);
                }
                catch (IOException ioexception) {
                    ThreadDownloadImageData.b.error("Couldn't load skin " + this.d, (Throwable)ioexception);
                    this.zeroday();
                }
            }
            else {
                this.zeroday();
            }
        }
    }
    
    protected void zeroday() {
        (this.h = new Thread("Texture Downloader #" + ThreadDownloadImageData.c.incrementAndGet()) {
            private static final String zeroday = "CL_00001050";
            
            @Override
            public void run() {
                HttpURLConnection httpurlconnection = null;
                ThreadDownloadImageData.b.debug("Downloading http texture from {} to {}", new Object[] { ThreadDownloadImageData.this.e, ThreadDownloadImageData.this.d });
                if (ThreadDownloadImageData.this.momgetthecamera()) {
                    ThreadDownloadImageData.this.a();
                }
                else {
                    try {
                        httpurlconnection = (HttpURLConnection)new URL(ThreadDownloadImageData.this.e).openConnection(Minecraft.s().H());
                        httpurlconnection.setDoInput(true);
                        httpurlconnection.setDoOutput(false);
                        httpurlconnection.connect();
                        if (httpurlconnection.getResponseCode() / 100 != 2) {
                            if (httpurlconnection.getErrorStream() != null) {
                                Config.zeroday(httpurlconnection.getErrorStream());
                            }
                            return;
                        }
                        BufferedImage bufferedimage;
                        if (ThreadDownloadImageData.this.d != null) {
                            FileUtils.copyInputStreamToFile(httpurlconnection.getInputStream(), ThreadDownloadImageData.this.d);
                            bufferedimage = ImageIO.read(ThreadDownloadImageData.this.d);
                        }
                        else {
                            bufferedimage = TextureUtil.zerodayisaminecraftcheat(httpurlconnection.getInputStream());
                        }
                        if (ThreadDownloadImageData.this.f != null) {
                            bufferedimage = ThreadDownloadImageData.this.f.zerodayisaminecraftcheat(bufferedimage);
                        }
                        ThreadDownloadImageData.this.zerodayisaminecraftcheat(bufferedimage);
                    }
                    catch (Exception exception) {
                        ThreadDownloadImageData.b.error("Couldn't download http texture: " + exception.getClass().getName() + ": " + exception.getMessage());
                        return;
                    }
                    finally {
                        if (httpurlconnection != null) {
                            httpurlconnection.disconnect();
                        }
                        ThreadDownloadImageData.this.zerodayisaminecraftcheat = (ThreadDownloadImageData.this.g != null);
                    }
                    if (httpurlconnection != null) {
                        httpurlconnection.disconnect();
                    }
                    ThreadDownloadImageData.this.zerodayisaminecraftcheat = (ThreadDownloadImageData.this.g != null);
                }
            }
        }).setDaemon(true);
        this.h.start();
    }
    
    private boolean momgetthecamera() {
        if (!this.zeroday) {
            return false;
        }
        final Proxy proxy = Minecraft.s().H();
        return (proxy.type() == Proxy.Type.DIRECT || proxy.type() == Proxy.Type.SOCKS) && this.e.startsWith("http://");
    }
    
    private void a() {
        try {
            final HttpRequest httprequest = HttpPipeline.zerodayisaminecraftcheat(this.e, Minecraft.s().H());
            final HttpResponse httpresponse = HttpPipeline.zerodayisaminecraftcheat(httprequest);
            if (httpresponse.zerodayisaminecraftcheat() / 100 != 2) {
                return;
            }
            final byte[] abyte = httpresponse.pandora();
            final ByteArrayInputStream bytearrayinputstream = new ByteArrayInputStream(abyte);
            BufferedImage bufferedimage;
            if (this.d != null) {
                FileUtils.copyInputStreamToFile((InputStream)bytearrayinputstream, this.d);
                bufferedimage = ImageIO.read(this.d);
            }
            else {
                bufferedimage = TextureUtil.zerodayisaminecraftcheat(bytearrayinputstream);
            }
            if (this.f != null) {
                bufferedimage = this.f.zerodayisaminecraftcheat(bufferedimage);
            }
            this.zerodayisaminecraftcheat(bufferedimage);
        }
        catch (Exception exception) {
            ThreadDownloadImageData.b.error("Couldn't download http texture: " + exception.getClass().getName() + ": " + exception.getMessage());
            return;
        }
        finally {
            this.zerodayisaminecraftcheat = (this.g != null);
        }
        this.zerodayisaminecraftcheat = (this.g != null);
    }
}

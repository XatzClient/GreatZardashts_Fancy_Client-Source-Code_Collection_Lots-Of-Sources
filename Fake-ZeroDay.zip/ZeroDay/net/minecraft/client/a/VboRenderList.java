// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import org.lwjgl.opengl.GL11;
import sigma.zerodayisaminecraftcheat.k;
import net.minecraft.l.Config;
import net.minecraft.client.a.vape.VertexBuffer;
import java.util.Iterator;
import net.minecraft.client.a.zeroday.RenderChunk;
import net.minecraft.o.EnumWorldBlockLayer;

public class VboRenderList extends ChunkRenderContainer
{
    private static final String sigma = "CL_00002533";
    
    @Override
    public void zerodayisaminecraftcheat(final EnumWorldBlockLayer layer) {
        if (this.zeroday) {
            for (final RenderChunk renderchunk : this.zerodayisaminecraftcheat) {
                final VertexBuffer vertexbuffer = renderchunk.zeroday(layer.ordinal());
                GlStateManager.v();
                this.zerodayisaminecraftcheat(renderchunk);
                renderchunk.flux();
                vertexbuffer.zerodayisaminecraftcheat();
                this.zerodayisaminecraftcheat();
                vertexbuffer.zerodayisaminecraftcheat(7);
                GlStateManager.w();
            }
            OpenGlHelper.vape(OpenGlHelper.J, 0);
            GlStateManager.x();
            this.zerodayisaminecraftcheat.clear();
        }
    }
    
    private void zerodayisaminecraftcheat() {
        if (Config.aC()) {
            k.c();
        }
        else {
            GL11.glVertexPointer(3, 5126, 28, 0L);
            GL11.glColorPointer(4, 5121, 28, 12L);
            GL11.glTexCoordPointer(2, 5126, 28, 16L);
            OpenGlHelper.d(OpenGlHelper.j);
            GL11.glTexCoordPointer(2, 5122, 28, 24L);
            OpenGlHelper.d(OpenGlHelper.i);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.client.a.vape.VertexBuffer;

public class VertexBufferUploader extends WorldVertexBufferUploader
{
    private VertexBuffer zerodayisaminecraftcheat;
    
    public VertexBufferUploader() {
        this.zerodayisaminecraftcheat = null;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final WorldRenderer p_181679_1_) {
        p_181679_1_.sigma();
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_181679_1_.vape());
    }
    
    public void zerodayisaminecraftcheat(final VertexBuffer vertexBufferIn) {
        this.zerodayisaminecraftcheat = vertexBufferIn;
    }
}

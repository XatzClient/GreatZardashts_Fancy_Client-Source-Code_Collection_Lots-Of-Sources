// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import net.minecraft.o.MathHelper;
import net.minecraft.o.BlockPos;
import net.minecraft.client.a.zeroday.IRenderChunkFactory;
import net.minecraft.client.a.zeroday.RenderChunk;
import net.minecraft.q.World;

public class ViewFrustum
{
    protected final RenderGlobal zerodayisaminecraftcheat;
    protected final World zeroday;
    protected int sigma;
    protected int pandora;
    protected int zues;
    public RenderChunk[] flux;
    
    public ViewFrustum(final World worldIn, final int renderDistanceChunks, final RenderGlobal p_i46246_3_, final IRenderChunkFactory renderChunkFactory) {
        this.zerodayisaminecraftcheat = p_i46246_3_;
        this.zeroday = worldIn;
        this.zerodayisaminecraftcheat(renderDistanceChunks);
        this.zerodayisaminecraftcheat(renderChunkFactory);
    }
    
    protected void zerodayisaminecraftcheat(final IRenderChunkFactory renderChunkFactory) {
        final int i = this.pandora * this.sigma * this.zues;
        this.flux = new RenderChunk[i];
        int j = 0;
        for (int k = 0; k < this.pandora; ++k) {
            for (int l = 0; l < this.sigma; ++l) {
                for (int i2 = 0; i2 < this.zues; ++i2) {
                    final int j2 = (i2 * this.sigma + l) * this.pandora + k;
                    final BlockPos blockpos = new BlockPos(k * 16, l * 16, i2 * 16);
                    this.flux[j2] = renderChunkFactory.zerodayisaminecraftcheat(this.zeroday, this.zerodayisaminecraftcheat, blockpos, j++);
                }
            }
        }
    }
    
    public void zerodayisaminecraftcheat() {
        RenderChunk[] flux;
        for (int length = (flux = this.flux).length, i = 0; i < length; ++i) {
            final RenderChunk renderchunk = flux[i];
            renderchunk.zerodayisaminecraftcheat();
        }
    }
    
    protected void zerodayisaminecraftcheat(final int renderDistanceChunks) {
        final int i = renderDistanceChunks * 2 + 1;
        this.pandora = i;
        this.sigma = 16;
        this.zues = i;
    }
    
    public void zerodayisaminecraftcheat(final double viewEntityX, final double viewEntityZ) {
        final int i = MathHelper.sigma(viewEntityX) - 8;
        final int j = MathHelper.sigma(viewEntityZ) - 8;
        final int k = this.pandora * 16;
        for (int l = 0; l < this.pandora; ++l) {
            final int i2 = this.zerodayisaminecraftcheat(i, k, l);
            for (int j2 = 0; j2 < this.zues; ++j2) {
                final int k2 = this.zerodayisaminecraftcheat(j, k, j2);
                for (int l2 = 0; l2 < this.sigma; ++l2) {
                    final int i3 = l2 * 16;
                    final RenderChunk renderchunk = this.flux[(j2 * this.sigma + l2) * this.pandora + l];
                    final BlockPos blockpos = new BlockPos(i2, i3, k2);
                    if (!blockpos.equals(renderchunk.a())) {
                        renderchunk.zerodayisaminecraftcheat(blockpos);
                    }
                }
            }
        }
    }
    
    private int zerodayisaminecraftcheat(final int p_178157_1_, final int p_178157_2_, final int p_178157_3_) {
        final int i = p_178157_3_ * 16;
        int j = i - p_178157_1_ + p_178157_2_ / 2;
        if (j < 0) {
            j -= p_178157_2_ - 1;
        }
        return i - j / p_178157_2_ * p_178157_2_;
    }
    
    public void zerodayisaminecraftcheat(final int fromX, final int fromY, final int fromZ, final int toX, final int toY, final int toZ) {
        final int i = MathHelper.zerodayisaminecraftcheat(fromX, 16);
        final int j = MathHelper.zerodayisaminecraftcheat(fromY, 16);
        final int k = MathHelper.zerodayisaminecraftcheat(fromZ, 16);
        final int l = MathHelper.zerodayisaminecraftcheat(toX, 16);
        final int i2 = MathHelper.zerodayisaminecraftcheat(toY, 16);
        final int j2 = MathHelper.zerodayisaminecraftcheat(toZ, 16);
        for (int k2 = i; k2 <= l; ++k2) {
            int l2 = k2 % this.pandora;
            if (l2 < 0) {
                l2 += this.pandora;
            }
            for (int i3 = j; i3 <= i2; ++i3) {
                int j3 = i3 % this.sigma;
                if (j3 < 0) {
                    j3 += this.sigma;
                }
                for (int k3 = k; k3 <= j2; ++k3) {
                    int l3 = k3 % this.zues;
                    if (l3 < 0) {
                        l3 += this.zues;
                    }
                    final int i4 = (l3 * this.sigma + j3) * this.pandora + l2;
                    final RenderChunk renderchunk = this.flux[i4];
                    renderchunk.zerodayisaminecraftcheat(true);
                }
            }
        }
    }
    
    protected RenderChunk zerodayisaminecraftcheat(final BlockPos pos) {
        int i = MathHelper.zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat(), 16);
        final int j = MathHelper.zerodayisaminecraftcheat(pos.zeroday(), 16);
        int k = MathHelper.zerodayisaminecraftcheat(pos.sigma(), 16);
        if (j >= 0 && j < this.sigma) {
            i %= this.pandora;
            if (i < 0) {
                i += this.pandora;
            }
            k %= this.zues;
            if (k < 0) {
                k += this.zues;
            }
            final int l = (k * this.sigma + j) * this.pandora + i;
            return this.flux[l];
        }
        return null;
    }
}

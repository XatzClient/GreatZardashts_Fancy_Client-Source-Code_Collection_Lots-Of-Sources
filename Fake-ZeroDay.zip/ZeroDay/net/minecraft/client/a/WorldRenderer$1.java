// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import com.google.common.primitives.Floats;
import java.util.Comparator;

class WorldRenderer$1 implements Comparator
{
    final float[] zerodayisaminecraftcheat;
    final WorldRenderer zeroday;
    
    WorldRenderer$1(final WorldRenderer p_i46500_1_, final float[] p_i46500_2_) {
        this.zeroday = p_i46500_1_;
        this.zerodayisaminecraftcheat = p_i46500_2_;
    }
    
    public int zerodayisaminecraftcheat(final Integer p_compare_1_, final Integer p_compare_2_) {
        return Floats.compare(this.zerodayisaminecraftcheat[p_compare_2_], this.zerodayisaminecraftcheat[p_compare_1_]);
    }
    
    @Override
    public int compare(final Object p_compare_1_, final Object p_compare_2_) {
        return this.zerodayisaminecraftcheat((Integer)p_compare_1_, (Integer)p_compare_2_);
    }
}

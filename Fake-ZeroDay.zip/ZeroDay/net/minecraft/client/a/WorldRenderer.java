// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import org.lwjgl.opengl.GL11;
import net.minecraft.l.TextureUtils;
import net.minecraft.o.MathHelper;
import zeroday.pandora.zerodayisaminecraftcheat.d.br;
import java.nio.ByteOrder;
import java.util.BitSet;
import java.util.Comparator;
import java.util.Arrays;
import org.apache.logging.log4j.LogManager;
import net.minecraft.l.Config;
import sigma.zerodayisaminecraftcheat.b;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.client.a.vape.VertexFormat;
import net.minecraft.client.a.vape.VertexFormatElement;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.nio.IntBuffer;
import java.nio.ByteBuffer;

public class WorldRenderer
{
    private ByteBuffer flux;
    public IntBuffer zerodayisaminecraftcheat;
    private ShortBuffer vape;
    public FloatBuffer zeroday;
    public int sigma;
    private VertexFormatElement momgetthecamera;
    private int a;
    private boolean b;
    public int pandora;
    private double c;
    private double d;
    private double e;
    private VertexFormat f;
    private boolean g;
    private EnumWorldBlockLayer h;
    private boolean[] i;
    private TextureAtlasSprite[] j;
    private TextureAtlasSprite k;
    public b zues;
    
    public WorldRenderer(int bufferSizeIn) {
        this.h = null;
        this.i = new boolean[256];
        this.j = null;
        this.k = null;
        if (Config.aC()) {
            bufferSizeIn *= 2;
        }
        this.flux = GLAllocation.sigma(bufferSizeIn * 4);
        this.zerodayisaminecraftcheat = this.flux.asIntBuffer();
        this.vape = this.flux.asShortBuffer();
        this.zeroday = this.flux.asFloatBuffer();
        sigma.zerodayisaminecraftcheat.b.zerodayisaminecraftcheat(this);
    }
    
    private void sigma(int p_181670_1_) {
        if (Config.aC()) {
            p_181670_1_ *= 2;
        }
        if (p_181670_1_ > this.zerodayisaminecraftcheat.remaining()) {
            final int i = this.flux.capacity();
            final int j = i % 2097152;
            final int k = j + (((this.zerodayisaminecraftcheat.position() + p_181670_1_) * 4 - j) / 2097152 + 1) * 2097152;
            LogManager.getLogger().warn("Needed to grow BufferBuilder buffer: Old size " + i + " bytes, new size " + k + " bytes.");
            final int l = this.zerodayisaminecraftcheat.position();
            final ByteBuffer bytebuffer = GLAllocation.sigma(k);
            this.flux.position(0);
            bytebuffer.put(this.flux);
            bytebuffer.rewind();
            this.flux = bytebuffer;
            this.zeroday = this.flux.asFloatBuffer();
            (this.zerodayisaminecraftcheat = this.flux.asIntBuffer()).position(l);
            (this.vape = this.flux.asShortBuffer()).position(l << 1);
            if (this.j != null) {
                final TextureAtlasSprite[] atextureatlassprite = this.j;
                final int i2 = this.h();
                System.arraycopy(atextureatlassprite, 0, this.j = new TextureAtlasSprite[i2], 0, Math.min(atextureatlassprite.length, this.j.length));
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final float p_181674_1_, final float p_181674_2_, final float p_181674_3_) {
        final int i = this.sigma / 4;
        final float[] afloat = new float[i];
        for (int j = 0; j < i; ++j) {
            afloat[j] = zerodayisaminecraftcheat(this.zeroday, (float)(p_181674_1_ + this.c), (float)(p_181674_2_ + this.d), (float)(p_181674_3_ + this.e), this.f.flux(), j * this.f.vape());
        }
        final Integer[] ainteger = new Integer[i];
        for (int k = 0; k < ainteger.length; ++k) {
            ainteger[k] = k;
        }
        Arrays.sort(ainteger, new WorldRenderer$1(this, afloat));
        final BitSet bitset = new BitSet();
        final int l = this.f.vape();
        final int[] aint = new int[l];
        for (int l2 = 0; (l2 = bitset.nextClearBit(l2)) < ainteger.length; ++l2) {
            final int i2 = ainteger[l2];
            if (i2 != l2) {
                this.zerodayisaminecraftcheat.limit(i2 * l + l);
                this.zerodayisaminecraftcheat.position(i2 * l);
                this.zerodayisaminecraftcheat.get(aint);
                for (int j2 = i2, k2 = ainteger[i2]; j2 != l2; j2 = k2, k2 = ainteger[k2]) {
                    this.zerodayisaminecraftcheat.limit(k2 * l + l);
                    this.zerodayisaminecraftcheat.position(k2 * l);
                    final IntBuffer intbuffer = this.zerodayisaminecraftcheat.slice();
                    this.zerodayisaminecraftcheat.limit(j2 * l + l);
                    this.zerodayisaminecraftcheat.position(j2 * l);
                    this.zerodayisaminecraftcheat.put(intbuffer);
                    bitset.set(j2);
                }
                this.zerodayisaminecraftcheat.limit(l2 * l + l);
                this.zerodayisaminecraftcheat.position(l2 * l);
                this.zerodayisaminecraftcheat.put(aint);
            }
            bitset.set(l2);
        }
        if (this.j != null) {
            final TextureAtlasSprite[] atextureatlassprite = new TextureAtlasSprite[this.sigma / 4];
            final int i3 = this.f.flux() / 4 * 4;
            for (int j3 = 0; j3 < ainteger.length; ++j3) {
                final int k3 = ainteger[j3];
                atextureatlassprite[j3] = this.j[k3];
            }
            System.arraycopy(atextureatlassprite, 0, this.j, 0, atextureatlassprite.length);
        }
    }
    
    public zerodayisaminecraftcheat zerodayisaminecraftcheat() {
        this.zerodayisaminecraftcheat.rewind();
        final int i = this.zeroday();
        this.zerodayisaminecraftcheat.limit(i);
        final int[] aint = new int[i];
        this.zerodayisaminecraftcheat.get(aint);
        this.zerodayisaminecraftcheat.limit(this.zerodayisaminecraftcheat.capacity());
        this.zerodayisaminecraftcheat.position(i);
        TextureAtlasSprite[] atextureatlassprite = null;
        if (this.j != null) {
            final int j = this.sigma / 4;
            atextureatlassprite = new TextureAtlasSprite[j];
            System.arraycopy(this.j, 0, atextureatlassprite, 0, j);
        }
        return new zerodayisaminecraftcheat(aint, new VertexFormat(this.f), atextureatlassprite);
    }
    
    public int zeroday() {
        return this.sigma * this.f.flux();
    }
    
    private static float zerodayisaminecraftcheat(final FloatBuffer p_181665_0_, final float p_181665_1_, final float p_181665_2_, final float p_181665_3_, final int p_181665_4_, final int p_181665_5_) {
        final float f = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 0 + 0);
        final float f2 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 0 + 1);
        final float f3 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 0 + 2);
        final float f4 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 1 + 0);
        final float f5 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 1 + 1);
        final float f6 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 1 + 2);
        final float f7 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 2 + 0);
        final float f8 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 2 + 1);
        final float f9 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 2 + 2);
        final float f10 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 3 + 0);
        final float f11 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 3 + 1);
        final float f12 = p_181665_0_.get(p_181665_5_ + p_181665_4_ * 3 + 2);
        final float f13 = (f + f4 + f7 + f10) * 0.25f - p_181665_1_;
        final float f14 = (f2 + f5 + f8 + f11) * 0.25f - p_181665_2_;
        final float f15 = (f3 + f6 + f9 + f12) * 0.25f - p_181665_3_;
        return f13 * f13 + f14 * f14 + f15 * f15;
    }
    
    public void zerodayisaminecraftcheat(final zerodayisaminecraftcheat state) {
        this.zerodayisaminecraftcheat.clear();
        this.sigma(state.zerodayisaminecraftcheat().length);
        this.zerodayisaminecraftcheat.put(state.zerodayisaminecraftcheat());
        this.sigma = state.zeroday();
        this.f = new VertexFormat(state.sigma());
        if (state.zues != null) {
            if (this.j == null) {
                this.j = new TextureAtlasSprite[this.h()];
            }
            final TextureAtlasSprite[] atextureatlassprite = state.zues;
            System.arraycopy(atextureatlassprite, 0, this.j, 0, atextureatlassprite.length);
        }
        else {
            this.j = null;
        }
    }
    
    public void sigma() {
        this.sigma = 0;
        this.momgetthecamera = null;
        this.a = 0;
        this.k = null;
    }
    
    public void zerodayisaminecraftcheat(final int p_181668_1_, final VertexFormat p_181668_2_) {
        if (this.g) {
            throw new IllegalStateException("Already building!");
        }
        this.g = true;
        this.sigma();
        this.pandora = p_181668_1_;
        this.f = p_181668_2_;
        this.momgetthecamera = p_181668_2_.sigma(this.a);
        this.b = false;
        this.flux.limit(this.flux.capacity());
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.b.sigma(this);
        }
        if (Config.ah()) {
            if (this.h != null && this.j == null) {
                this.j = new TextureAtlasSprite[this.h()];
            }
        }
        else {
            this.j = null;
        }
    }
    
    public WorldRenderer zerodayisaminecraftcheat(double p_181673_1_, double p_181673_3_) {
        if (this.k != null && this.j != null) {
            p_181673_1_ = this.k.sigma((float)p_181673_1_);
            p_181673_3_ = this.k.pandora((float)p_181673_3_);
            this.j[this.sigma / 4] = this.k;
        }
        final int i = this.sigma * this.f.vape() + this.f.pandora(this.a);
        switch (WorldRenderer.zeroday.zerodayisaminecraftcheat[this.momgetthecamera.zerodayisaminecraftcheat().ordinal()]) {
            case 1: {
                this.flux.putFloat(i, (float)p_181673_1_);
                this.flux.putFloat(i + 4, (float)p_181673_3_);
                break;
            }
            case 2:
            case 3: {
                this.flux.putInt(i, (int)p_181673_1_);
                this.flux.putInt(i + 4, (int)p_181673_3_);
                break;
            }
            case 4:
            case 5: {
                this.flux.putShort(i, (short)p_181673_3_);
                this.flux.putShort(i + 2, (short)p_181673_1_);
                break;
            }
            case 6:
            case 7: {
                this.flux.put(i, (byte)p_181673_3_);
                this.flux.put(i + 1, (byte)p_181673_1_);
                break;
            }
        }
        this.g();
        return this;
    }
    
    public WorldRenderer zerodayisaminecraftcheat(final int p_181671_1_, final int p_181671_2_) {
        final int i = this.sigma * this.f.vape() + this.f.pandora(this.a);
        switch (WorldRenderer.zeroday.zerodayisaminecraftcheat[this.momgetthecamera.zerodayisaminecraftcheat().ordinal()]) {
            case 1: {
                this.flux.putFloat(i, (float)p_181671_1_);
                this.flux.putFloat(i + 4, (float)p_181671_2_);
                break;
            }
            case 2:
            case 3: {
                this.flux.putInt(i, p_181671_1_);
                this.flux.putInt(i + 4, p_181671_2_);
                break;
            }
            case 4:
            case 5: {
                this.flux.putShort(i, (short)p_181671_2_);
                this.flux.putShort(i + 2, (short)p_181671_1_);
                break;
            }
            case 6:
            case 7: {
                this.flux.put(i, (byte)p_181671_2_);
                this.flux.put(i + 1, (byte)p_181671_1_);
                break;
            }
        }
        this.g();
        return this;
    }
    
    public void zerodayisaminecraftcheat(final int p_178962_1_, final int p_178962_2_, final int p_178962_3_, final int p_178962_4_) {
        final int i = (this.sigma - 4) * this.f.flux() + this.f.zeroday(1) / 4;
        final int j = this.f.vape() >> 2;
        this.zerodayisaminecraftcheat.put(i, p_178962_1_);
        this.zerodayisaminecraftcheat.put(i + j, p_178962_2_);
        this.zerodayisaminecraftcheat.put(i + j * 2, p_178962_3_);
        this.zerodayisaminecraftcheat.put(i + j * 3, p_178962_4_);
    }
    
    public void zerodayisaminecraftcheat(final double x, final double y, final double z) {
        final int i = this.f.flux();
        final int j = (this.sigma - 4) * i;
        for (int k = 0; k < 4; ++k) {
            final int l = j + k * i;
            final int i2 = l + 1;
            final int j2 = i2 + 1;
            this.zerodayisaminecraftcheat.put(l, Float.floatToRawIntBits((float)(x + this.c) + Float.intBitsToFloat(this.zerodayisaminecraftcheat.get(l))));
            this.zerodayisaminecraftcheat.put(i2, Float.floatToRawIntBits((float)(y + this.d) + Float.intBitsToFloat(this.zerodayisaminecraftcheat.get(i2))));
            this.zerodayisaminecraftcheat.put(j2, Float.floatToRawIntBits((float)(z + this.e) + Float.intBitsToFloat(this.zerodayisaminecraftcheat.get(j2))));
        }
    }
    
    private int pandora(final int p_78909_1_) {
        return ((this.sigma - p_78909_1_) * this.f.vape() + this.f.zues()) / 4;
    }
    
    public void zerodayisaminecraftcheat(final float red, final float green, final float blue, final int p_178978_4_) {
        final int i = this.pandora(p_178978_4_);
        int j = -1;
        if (!this.b) {
            j = this.zerodayisaminecraftcheat.get(i);
            if (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) {
                final int k = (int)((j & 0xFF) * red);
                final int l = (int)((j >> 8 & 0xFF) * green);
                final int i2 = (int)((j >> 16 & 0xFF) * blue);
                j = (j &= (br.c ? 1711276032 : -16777216));
                j = (j | i2 << 16 | l << 8 | k);
            }
            else {
                final int j2 = (int)((j >> 24 & 0xFF) * red);
                final int k2 = (int)((j >> 16 & 0xFF) * green);
                final int l2 = (int)((j >> 8 & 0xFF) * blue);
                j &= 0xFF;
                j = (j | j2 << 24 | k2 << 16 | l2 << 8);
            }
        }
        this.zerodayisaminecraftcheat.put(i, j);
    }
    
    private void zeroday(final int argb, final int p_178988_2_) {
        final int i = this.pandora(p_178988_2_);
        final int j = argb >> 16 & 0xFF;
        final int k = argb >> 8 & 0xFF;
        final int l = argb & 0xFF;
        final int i2 = argb >> 24 & 0xFF;
        this.zerodayisaminecraftcheat(i, j, k, l, i2);
    }
    
    public void zeroday(final float red, final float green, final float blue, final int p_178994_4_) {
        final int i = this.pandora(p_178994_4_);
        final int j = MathHelper.zerodayisaminecraftcheat((int)(red * 255.0f), 0, 255);
        final int k = MathHelper.zerodayisaminecraftcheat((int)(green * 255.0f), 0, 255);
        final int l = MathHelper.zerodayisaminecraftcheat((int)(blue * 255.0f), 0, 255);
        this.zerodayisaminecraftcheat(i, j, k, l, 255);
    }
    
    private void zerodayisaminecraftcheat(final int index, final int red, final int p_178972_3_, final int p_178972_4_, final int p_178972_5_) {
        if (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) {
            this.zerodayisaminecraftcheat.put(index, p_178972_5_ << 24 | p_178972_4_ << 16 | p_178972_3_ << 8 | red);
        }
        else {
            this.zerodayisaminecraftcheat.put(index, red << 24 | p_178972_3_ << 16 | p_178972_4_ << 8 | p_178972_5_);
        }
    }
    
    public void pandora() {
        this.b = true;
    }
    
    public WorldRenderer zerodayisaminecraftcheat(final float p_181666_1_, final float p_181666_2_, final float p_181666_3_, final float p_181666_4_) {
        return this.zeroday((int)(p_181666_1_ * 255.0f), (int)(p_181666_2_ * 255.0f), (int)(p_181666_3_ * 255.0f), (int)(p_181666_4_ * 255.0f));
    }
    
    public WorldRenderer zeroday(final int p_181669_1_, final int p_181669_2_, final int p_181669_3_, final int p_181669_4_) {
        if (this.b) {
            return this;
        }
        final int i = this.sigma * this.f.vape() + this.f.pandora(this.a);
        switch (WorldRenderer.zeroday.zerodayisaminecraftcheat[this.momgetthecamera.zerodayisaminecraftcheat().ordinal()]) {
            case 1: {
                this.flux.putFloat(i, p_181669_1_ / 255.0f);
                this.flux.putFloat(i + 4, p_181669_2_ / 255.0f);
                this.flux.putFloat(i + 8, p_181669_3_ / 255.0f);
                this.flux.putFloat(i + 12, p_181669_4_ / 255.0f);
                break;
            }
            case 2:
            case 3: {
                this.flux.putFloat(i, (float)p_181669_1_);
                this.flux.putFloat(i + 4, (float)p_181669_2_);
                this.flux.putFloat(i + 8, (float)p_181669_3_);
                this.flux.putFloat(i + 12, (float)p_181669_4_);
                break;
            }
            case 4:
            case 5: {
                this.flux.putShort(i, (short)p_181669_1_);
                this.flux.putShort(i + 2, (short)p_181669_2_);
                this.flux.putShort(i + 4, (short)p_181669_3_);
                this.flux.putShort(i + 6, (short)p_181669_4_);
                break;
            }
            case 6:
            case 7: {
                if (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) {
                    this.flux.put(i, (byte)p_181669_1_);
                    this.flux.put(i + 1, (byte)p_181669_2_);
                    this.flux.put(i + 2, (byte)p_181669_3_);
                    this.flux.put(i + 3, (byte)p_181669_4_);
                    break;
                }
                this.flux.put(i, (byte)p_181669_4_);
                this.flux.put(i + 1, (byte)p_181669_3_);
                this.flux.put(i + 2, (byte)p_181669_2_);
                this.flux.put(i + 3, (byte)p_181669_1_);
                break;
            }
        }
        this.g();
        return this;
    }
    
    public void zerodayisaminecraftcheat(final int[] vertexData) {
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.b.zerodayisaminecraftcheat(this, vertexData);
        }
        this.sigma(vertexData.length);
        this.zerodayisaminecraftcheat.position(this.zeroday());
        this.zerodayisaminecraftcheat.put(vertexData);
        this.sigma += vertexData.length / this.f.flux();
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.b.flux(this);
        }
    }
    
    public void zues() {
        ++this.sigma;
        this.sigma(this.f.flux());
        this.a = 0;
        this.momgetthecamera = this.f.sigma(this.a);
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.b.zues(this);
        }
    }
    
    public WorldRenderer zeroday(final double p_181662_1_, final double p_181662_3_, final double p_181662_5_) {
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.b.pandora(this);
        }
        final int i = this.sigma * this.f.vape() + this.f.pandora(this.a);
        switch (WorldRenderer.zeroday.zerodayisaminecraftcheat[this.momgetthecamera.zerodayisaminecraftcheat().ordinal()]) {
            case 1: {
                this.flux.putFloat(i, (float)(p_181662_1_ + this.c));
                this.flux.putFloat(i + 4, (float)(p_181662_3_ + this.d));
                this.flux.putFloat(i + 8, (float)(p_181662_5_ + this.e));
                break;
            }
            case 2:
            case 3: {
                this.flux.putInt(i, Float.floatToRawIntBits((float)(p_181662_1_ + this.c)));
                this.flux.putInt(i + 4, Float.floatToRawIntBits((float)(p_181662_3_ + this.d)));
                this.flux.putInt(i + 8, Float.floatToRawIntBits((float)(p_181662_5_ + this.e)));
                break;
            }
            case 4:
            case 5: {
                this.flux.putShort(i, (short)(p_181662_1_ + this.c));
                this.flux.putShort(i + 2, (short)(p_181662_3_ + this.d));
                this.flux.putShort(i + 4, (short)(p_181662_5_ + this.e));
                break;
            }
            case 6:
            case 7: {
                this.flux.put(i, (byte)(p_181662_1_ + this.c));
                this.flux.put(i + 1, (byte)(p_181662_3_ + this.d));
                this.flux.put(i + 2, (byte)(p_181662_5_ + this.e));
                break;
            }
        }
        this.g();
        return this;
    }
    
    public void zeroday(final float x, final float y, final float z) {
        final int i = (byte)(x * 127.0f) & 0xFF;
        final int j = (byte)(y * 127.0f) & 0xFF;
        final int k = (byte)(z * 127.0f) & 0xFF;
        final int l = i | j << 8 | k << 16;
        final int i2 = this.f.vape() >> 2;
        final int j2 = (this.sigma - 4) * i2 + this.f.sigma() / 4;
        this.zerodayisaminecraftcheat.put(j2, l);
        this.zerodayisaminecraftcheat.put(j2 + i2, l);
        this.zerodayisaminecraftcheat.put(j2 + i2 * 2, l);
        this.zerodayisaminecraftcheat.put(j2 + i2 * 3, l);
    }
    
    private void g() {
        ++this.a;
        this.a %= this.f.a();
        this.momgetthecamera = this.f.sigma(this.a);
        if (this.momgetthecamera.zeroday() == VertexFormatElement.zeroday.vape) {
            this.g();
        }
    }
    
    public WorldRenderer sigma(final float p_181663_1_, final float p_181663_2_, final float p_181663_3_) {
        final int i = this.sigma * this.f.vape() + this.f.pandora(this.a);
        switch (WorldRenderer.zeroday.zerodayisaminecraftcheat[this.momgetthecamera.zerodayisaminecraftcheat().ordinal()]) {
            case 1: {
                this.flux.putFloat(i, p_181663_1_);
                this.flux.putFloat(i + 4, p_181663_2_);
                this.flux.putFloat(i + 8, p_181663_3_);
                break;
            }
            case 2:
            case 3: {
                this.flux.putInt(i, (int)p_181663_1_);
                this.flux.putInt(i + 4, (int)p_181663_2_);
                this.flux.putInt(i + 8, (int)p_181663_3_);
                break;
            }
            case 4:
            case 5: {
                this.flux.putShort(i, (short)((int)p_181663_1_ * 32767 & 0xFFFF));
                this.flux.putShort(i + 2, (short)((int)p_181663_2_ * 32767 & 0xFFFF));
                this.flux.putShort(i + 4, (short)((int)p_181663_3_ * 32767 & 0xFFFF));
                break;
            }
            case 6:
            case 7: {
                this.flux.put(i, (byte)((int)p_181663_1_ * 127 & 0xFF));
                this.flux.put(i + 1, (byte)((int)p_181663_2_ * 127 & 0xFF));
                this.flux.put(i + 2, (byte)((int)p_181663_3_ * 127 & 0xFF));
                break;
            }
        }
        this.g();
        return this;
    }
    
    public void sigma(final double x, final double y, final double z) {
        this.c = x;
        this.d = y;
        this.e = z;
    }
    
    public void flux() {
        if (!this.g) {
            throw new IllegalStateException("Not building!");
        }
        this.g = false;
        this.flux.position(0);
        this.flux.limit(this.zeroday() * 4);
    }
    
    public ByteBuffer vape() {
        return this.flux;
    }
    
    public VertexFormat momgetthecamera() {
        return this.f;
    }
    
    public int a() {
        return this.sigma;
    }
    
    public int b() {
        return this.pandora;
    }
    
    public void zerodayisaminecraftcheat(final int argb) {
        for (int i = 0; i < 4; ++i) {
            this.zeroday(argb, i + 1);
        }
    }
    
    public void pandora(final float red, final float green, final float blue) {
        for (int i = 0; i < 4; ++i) {
            this.zeroday(red, green, blue, i + 1);
        }
    }
    
    public void zerodayisaminecraftcheat(final TextureAtlasSprite p_putSprite_1_) {
        if (this.j != null) {
            final int i = this.sigma / 4;
            this.j[i - 1] = p_putSprite_1_;
        }
    }
    
    public void zeroday(final TextureAtlasSprite p_setSprite_1_) {
        if (this.j != null) {
            this.k = p_setSprite_1_;
        }
    }
    
    public boolean c() {
        return this.j != null;
    }
    
    public void d() {
        if (this.j != null) {
            final int i = Config.K().M().momgetthecamera();
            if (this.i.length <= i) {
                this.i = new boolean[i + 1];
            }
            Arrays.fill(this.i, false);
            int j = 0;
            int k = -1;
            for (int l = this.sigma / 4, i2 = 0; i2 < l; ++i2) {
                final TextureAtlasSprite textureatlassprite = this.j[i2];
                if (textureatlassprite != null) {
                    final int j2 = textureatlassprite.f();
                    if (!this.i[j2]) {
                        if (textureatlassprite == TextureUtils.af) {
                            if (k < 0) {
                                k = i2;
                            }
                        }
                        else {
                            i2 = this.zerodayisaminecraftcheat(textureatlassprite, i2) - 1;
                            ++j;
                            if (this.h != EnumWorldBlockLayer.pandora) {
                                this.i[j2] = true;
                            }
                        }
                    }
                }
            }
            if (k >= 0) {
                this.zerodayisaminecraftcheat(TextureUtils.af, k);
                ++j;
            }
            if (j > 0) {}
        }
    }
    
    private int zerodayisaminecraftcheat(final TextureAtlasSprite p_drawForIcon_1_, final int p_drawForIcon_2_) {
        GL11.glBindTexture(3553, p_drawForIcon_1_.f);
        int i = -1;
        int j = -1;
        final int k = this.sigma / 4;
        for (int l = p_drawForIcon_2_; l < k; ++l) {
            final TextureAtlasSprite textureatlassprite = this.j[l];
            if (textureatlassprite == p_drawForIcon_1_) {
                if (j < 0) {
                    j = l;
                }
            }
            else if (j >= 0) {
                this.sigma(j, l);
                if (this.h == EnumWorldBlockLayer.pandora) {
                    return l;
                }
                j = -1;
                if (i < 0) {
                    i = l;
                }
            }
        }
        if (j >= 0) {
            this.sigma(j, k);
        }
        if (i < 0) {
            i = k;
        }
        return i;
    }
    
    private void sigma(final int p_draw_1_, final int p_draw_2_) {
        final int i = p_draw_2_ - p_draw_1_;
        if (i > 0) {
            final int j = p_draw_1_ * 4;
            final int k = i * 4;
            GL11.glDrawArrays(this.pandora, j, k);
        }
    }
    
    public void zerodayisaminecraftcheat(final EnumWorldBlockLayer p_setBlockLayer_1_) {
        this.h = p_setBlockLayer_1_;
        if (p_setBlockLayer_1_ == null) {
            this.j = null;
            this.k = null;
        }
    }
    
    private int h() {
        final int i = this.zerodayisaminecraftcheat.capacity() * 4 / (this.f.flux() * 4);
        return i;
    }
    
    public void e() {
        this.sigma(this.f.flux());
    }
    
    public void pandora(final double minX, final double maxY, final double minZ) {
    }
    
    public void zeroday(final int i) {
    }
    
    public void f() {
    }
    
    static final class zeroday
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002569";
        
        static {
            zerodayisaminecraftcheat = new int[VertexFormatElement.zerodayisaminecraftcheat.values().length];
            try {
                WorldRenderer.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                WorldRenderer.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zerodayisaminecraftcheat.flux.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                WorldRenderer.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zerodayisaminecraftcheat.vape.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                WorldRenderer.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zerodayisaminecraftcheat.pandora.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            try {
                WorldRenderer.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zerodayisaminecraftcheat.zues.ordinal()] = 5;
            }
            catch (NoSuchFieldError noSuchFieldError5) {}
            try {
                WorldRenderer.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zerodayisaminecraftcheat.zeroday.ordinal()] = 6;
            }
            catch (NoSuchFieldError noSuchFieldError6) {}
            try {
                WorldRenderer.zeroday.zerodayisaminecraftcheat[VertexFormatElement.zerodayisaminecraftcheat.sigma.ordinal()] = 7;
            }
            catch (NoSuchFieldError noSuchFieldError7) {}
        }
    }
    
    public class zerodayisaminecraftcheat
    {
        private final int[] zeroday;
        private final VertexFormat sigma;
        private static final String pandora = "CL_00002568";
        private TextureAtlasSprite[] zues;
        
        public zerodayisaminecraftcheat(final int[] p_i11_2_, final VertexFormat p_i11_3_, final TextureAtlasSprite[] p_i11_4_) {
            this.zeroday = p_i11_2_;
            this.sigma = p_i11_3_;
            this.zues = p_i11_4_;
        }
        
        public zerodayisaminecraftcheat(final int[] p_i46453_2_, final VertexFormat p_i46453_3_) {
            this.zeroday = p_i46453_2_;
            this.sigma = p_i46453_3_;
        }
        
        public int[] zerodayisaminecraftcheat() {
            return this.zeroday;
        }
        
        public int zeroday() {
            return this.zeroday.length / this.sigma.flux();
        }
        
        public VertexFormat sigma() {
            return this.sigma;
        }
    }
}

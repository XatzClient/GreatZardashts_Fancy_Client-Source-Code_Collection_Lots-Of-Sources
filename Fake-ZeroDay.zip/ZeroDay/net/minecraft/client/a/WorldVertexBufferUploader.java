// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a;

import java.util.List;
import java.nio.ByteBuffer;
import net.minecraft.client.a.vape.VertexFormat;
import sigma.zerodayisaminecraftcheat.b;
import net.minecraft.l.Config;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.vape.VertexFormatElement;
import net.minecraft.l.Reflector;

public class WorldVertexBufferUploader
{
    private static final String zerodayisaminecraftcheat = "CL_00002567";
    
    public void zerodayisaminecraftcheat(final WorldRenderer p_181679_1_) {
        if (p_181679_1_.a() > 0) {
            final VertexFormat vertexformat = p_181679_1_.momgetthecamera();
            final int i = vertexformat.vape();
            final ByteBuffer bytebuffer = p_181679_1_.vape();
            final List list = vertexformat.momgetthecamera();
            final boolean flag = Reflector.bt.zeroday();
            final boolean flag2 = Reflector.bu.zeroday();
            for (int j = 0; j < list.size(); ++j) {
                final VertexFormatElement vertexformatelement = list.get(j);
                final VertexFormatElement.zeroday vertexformatelement$enumusage = vertexformatelement.zeroday();
                if (flag) {
                    Reflector.zerodayisaminecraftcheat(vertexformatelement$enumusage, Reflector.bt, vertexformat, j, i, bytebuffer);
                }
                else {
                    final int l = vertexformatelement.zerodayisaminecraftcheat().sigma();
                    final int k = vertexformatelement.pandora();
                    bytebuffer.position(vertexformat.pandora(j));
                    switch (WorldVertexBufferUploader.zerodayisaminecraftcheat.zerodayisaminecraftcheat[vertexformatelement$enumusage.ordinal()]) {
                        case 1: {
                            GL11.glVertexPointer(vertexformatelement.sigma(), l, i, bytebuffer);
                            GL11.glEnableClientState(32884);
                            break;
                        }
                        case 2: {
                            OpenGlHelper.d(OpenGlHelper.i + k);
                            GL11.glTexCoordPointer(vertexformatelement.sigma(), l, i, bytebuffer);
                            GL11.glEnableClientState(32888);
                            OpenGlHelper.d(OpenGlHelper.i);
                            break;
                        }
                        case 3: {
                            GL11.glColorPointer(vertexformatelement.sigma(), l, i, bytebuffer);
                            GL11.glEnableClientState(32886);
                            break;
                        }
                        case 4: {
                            GL11.glNormalPointer(l, i, bytebuffer);
                            GL11.glEnableClientState(32885);
                            break;
                        }
                    }
                }
            }
            if (p_181679_1_.c()) {
                p_181679_1_.d();
            }
            else if (Config.aC()) {
                b.zerodayisaminecraftcheat(p_181679_1_.b(), 0, p_181679_1_.a(), p_181679_1_);
            }
            else {
                GL11.glDrawArrays(p_181679_1_.b(), 0, p_181679_1_.a());
            }
            for (int i2 = 0, k2 = list.size(); i2 < k2; ++i2) {
                final VertexFormatElement vertexformatelement2 = list.get(i2);
                final VertexFormatElement.zeroday vertexformatelement$enumusage2 = vertexformatelement2.zeroday();
                if (flag2) {
                    Reflector.zerodayisaminecraftcheat(vertexformatelement$enumusage2, Reflector.bu, vertexformat, i2, i, bytebuffer);
                }
                else {
                    final int j2 = vertexformatelement2.pandora();
                    switch (WorldVertexBufferUploader.zerodayisaminecraftcheat.zerodayisaminecraftcheat[vertexformatelement$enumusage2.ordinal()]) {
                        case 1: {
                            GL11.glDisableClientState(32884);
                            break;
                        }
                        case 2: {
                            OpenGlHelper.d(OpenGlHelper.i + j2);
                            GL11.glDisableClientState(32888);
                            OpenGlHelper.d(OpenGlHelper.i);
                            break;
                        }
                        case 3: {
                            GL11.glDisableClientState(32886);
                            GlStateManager.x();
                            break;
                        }
                        case 4: {
                            GL11.glDisableClientState(32885);
                            break;
                        }
                    }
                }
            }
        }
        p_181679_1_.sigma();
    }
    
    static final class zerodayisaminecraftcheat
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002566";
        
        static {
            zerodayisaminecraftcheat = new int[VertexFormatElement.zeroday.values().length];
            try {
                WorldVertexBufferUploader.zerodayisaminecraftcheat.zerodayisaminecraftcheat[VertexFormatElement.zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                WorldVertexBufferUploader.zerodayisaminecraftcheat.zerodayisaminecraftcheat[VertexFormatElement.zeroday.pandora.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                WorldVertexBufferUploader.zerodayisaminecraftcheat.zerodayisaminecraftcheat[VertexFormatElement.zeroday.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                WorldVertexBufferUploader.zerodayisaminecraftcheat.zerodayisaminecraftcheat[VertexFormatElement.zeroday.zeroday.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
        }
    }
}

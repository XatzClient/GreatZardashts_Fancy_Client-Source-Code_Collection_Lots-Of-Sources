// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelEnderCrystal;
import net.minecraft.client.a.pandora.RenderManager;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.pandora.EntityEnderCrystal;
import net.minecraft.client.a.pandora.Render;

public class RenderEnderCrystal extends Render<EntityEnderCrystal>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private ModelBase zues;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/endercrystal/endercrystal.png");
    }
    
    public RenderEnderCrystal(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.zues = new ModelEnderCrystal(0.0f, true);
        this.sigma = 0.5f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityEnderCrystal entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        final float f = entity.zerodayisaminecraftcheat + partialTicks;
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        this.zerodayisaminecraftcheat(RenderEnderCrystal.zerodayisaminecraftcheat);
        float f2 = MathHelper.zerodayisaminecraftcheat(f * 0.2f) / 2.0f + 0.5f;
        f2 += f2 * f2;
        this.zues.zerodayisaminecraftcheat(entity, 0.0f, f * 3.0f, f2 * 0.2f, 0.0f, 0.0f, 0.0625f);
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityEnderCrystal entity) {
        return RenderEnderCrystal.zerodayisaminecraftcheat;
    }
}

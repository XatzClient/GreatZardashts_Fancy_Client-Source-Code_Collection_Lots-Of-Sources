// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.q.vape.MapData;
import net.minecraft.c.Item;
import net.minecraft.c.ItemStack;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.c.ItemSkull;
import net.minecraft.o.MathHelper;
import sigma.zerodayisaminecraftcheat.l;
import net.minecraft.l.Config;
import net.minecraft.client.a.zues.TextureCompass;
import net.minecraft.l.Reflector;
import net.minecraft.c.ItemMap;
import net.minecraft.vape.pandora.EntityItem;
import net.minecraft.client.b.zeroday.IBakedModel;
import net.minecraft.client.b.zeroday.ModelManager;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.o.BlockPos;
import net.minecraft.a.Items;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.client.a.pandora.RenderManager;
import net.minecraft.client.a.pandora.RenderItem;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.client.Minecraft;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.a.pandora.Render;

public class RenderItemFrame extends Render
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final Minecraft zues;
    private final ModelResourceLocation flux;
    private final ModelResourceLocation vape;
    private RenderItem momgetthecamera;
    private static final String a = "CL_00001002";
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/map/map_background.png");
    }
    
    public RenderItemFrame(final RenderManager renderManagerIn, final RenderItem itemRendererIn) {
        super(renderManagerIn);
        this.zues = Minecraft.s();
        this.flux = new ModelResourceLocation("item_frame", "normal");
        this.vape = new ModelResourceLocation("item_frame", "map");
        this.momgetthecamera = itemRendererIn;
    }
    
    public void zerodayisaminecraftcheat(final EntityItemFrame entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        final BlockPos blockpos = entity.b();
        final double d0 = blockpos.zerodayisaminecraftcheat() - entity.s + x;
        final double d2 = blockpos.zeroday() - entity.t + y;
        final double d3 = blockpos.sigma() - entity.u + z;
        GlStateManager.zeroday(d0 + 0.5, d2 + 0.5, d3 + 0.5);
        GlStateManager.zeroday(180.0f - entity.y, 0.0f, 1.0f, 0.0f);
        this.zeroday.pandora.zerodayisaminecraftcheat(TextureMap.zeroday);
        final BlockRendererDispatcher blockrendererdispatcher = this.zues.X();
        final ModelManager modelmanager = blockrendererdispatcher.zerodayisaminecraftcheat().zeroday();
        IBakedModel ibakedmodel;
        if (entity.e() != null && entity.e().zerodayisaminecraftcheat() == Items.aV) {
            ibakedmodel = modelmanager.zerodayisaminecraftcheat(this.vape);
        }
        else {
            ibakedmodel = modelmanager.zerodayisaminecraftcheat(this.flux);
        }
        GlStateManager.v();
        GlStateManager.zeroday(-0.5f, -0.5f, -0.5f);
        blockrendererdispatcher.zeroday().zerodayisaminecraftcheat(ibakedmodel, 1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.w();
        GlStateManager.zeroday(0.0f, 0.0f, 0.4375f);
        this.zeroday(entity);
        GlStateManager.w();
        this.zerodayisaminecraftcheat(entity, x + entity.zeroday.momgetthecamera() * 0.3f, y - 0.25, z + entity.zeroday.b() * 0.3f);
    }
    
    protected ResourceLocation zerodayisaminecraftcheat(final EntityItemFrame entity) {
        return null;
    }
    
    private void zeroday(final EntityItemFrame itemFrame) {
        final ItemStack itemstack = itemFrame.e();
        if (itemstack != null) {
            final EntityItem entityitem = new EntityItem(itemFrame.o, 0.0, 0.0, 0.0, itemstack);
            final Item item = entityitem.momgetthecamera().zerodayisaminecraftcheat();
            entityitem.momgetthecamera().zeroday = 1;
            entityitem.zerodayisaminecraftcheat = 0.0f;
            GlStateManager.v();
            GlStateManager.flux();
            int i = itemFrame.j();
            if (item instanceof ItemMap) {
                i = i % 4 * 2;
            }
            GlStateManager.zeroday(i * 360.0f / 8.0f, 0.0f, 0.0f, 1.0f);
            if (!Reflector.zerodayisaminecraftcheat(Reflector.ab, itemFrame, this)) {
                if (item instanceof ItemMap) {
                    this.zeroday.pandora.zerodayisaminecraftcheat(RenderItemFrame.zerodayisaminecraftcheat);
                    GlStateManager.zeroday(180.0f, 0.0f, 0.0f, 1.0f);
                    final float f = 0.0078125f;
                    GlStateManager.zerodayisaminecraftcheat(f, f, f);
                    GlStateManager.zeroday(-64.0f, -64.0f, 0.0f);
                    final MapData mapdata = Items.aV.zerodayisaminecraftcheat(entityitem.momgetthecamera(), itemFrame.o);
                    GlStateManager.zeroday(0.0f, 0.0f, -1.0f);
                    if (mapdata != null) {
                        this.zues.m.b().zerodayisaminecraftcheat(mapdata, true);
                    }
                }
                else {
                    TextureAtlasSprite textureatlassprite = null;
                    if (item == Items.aI) {
                        textureatlassprite = this.zues.M().zerodayisaminecraftcheat(TextureCompass.l);
                        if (Config.aC()) {
                            l.zerodayisaminecraftcheat(this.zues.I(), TextureMap.zeroday);
                        }
                        else {
                            this.zues.I().zerodayisaminecraftcheat(TextureMap.zeroday);
                        }
                        if (textureatlassprite instanceof TextureCompass) {
                            final TextureCompass texturecompass = (TextureCompass)textureatlassprite;
                            final double d0 = texturecompass.j;
                            final double d2 = texturecompass.k;
                            texturecompass.j = 0.0;
                            texturecompass.k = 0.0;
                            texturecompass.zerodayisaminecraftcheat(itemFrame.o, itemFrame.s, itemFrame.u, MathHelper.vape((float)(180 + itemFrame.zeroday.sigma() * 90)), false, true);
                            texturecompass.j = d0;
                            texturecompass.k = d2;
                        }
                        else {
                            textureatlassprite = null;
                        }
                    }
                    GlStateManager.zerodayisaminecraftcheat(0.5f, 0.5f, 0.5f);
                    if (!this.momgetthecamera.zerodayisaminecraftcheat(entityitem.momgetthecamera()) || item instanceof ItemSkull) {
                        GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
                    }
                    GlStateManager.zerodayisaminecraftcheat();
                    RenderHelper.zeroday();
                    this.momgetthecamera.zerodayisaminecraftcheat(entityitem.momgetthecamera(), ItemCameraTransforms.zeroday.vape);
                    RenderHelper.zerodayisaminecraftcheat();
                    GlStateManager.zeroday();
                    if (textureatlassprite != null && textureatlassprite.c() > 0) {
                        textureatlassprite.b();
                    }
                }
            }
            GlStateManager.zues();
            GlStateManager.w();
        }
        if (Config.aC()) {
            l.c = null;
        }
    }
    
    protected void zerodayisaminecraftcheat(final EntityItemFrame entity, final double x, final double y, final double z) {
        if (Minecraft.p() && entity.e() != null && entity.e().k() && this.zeroday.vape == entity) {
            final float f = 1.6f;
            final float f2 = 0.016666668f * f;
            final double d0 = entity.zues(this.zeroday.flux);
            final float f3 = entity.y() ? 32.0f : 64.0f;
            if (d0 < f3 * f3) {
                final String s = entity.e().i();
                if (entity.y()) {
                    final FontRenderer fontrenderer = this.sigma();
                    GlStateManager.v();
                    GlStateManager.zeroday((float)x + 0.0f, (float)y + entity.L + 0.5f, (float)z);
                    GL11.glNormal3f(0.0f, 1.0f, 0.0f);
                    GlStateManager.zeroday(-RenderManager.momgetthecamera, 0.0f, 1.0f, 0.0f);
                    GlStateManager.zeroday(RenderManager.a, 1.0f, 0.0f, 0.0f);
                    GlStateManager.zerodayisaminecraftcheat(-f2, -f2, f2);
                    GlStateManager.flux();
                    GlStateManager.zeroday(0.0f, 0.25f / f2, 0.0f);
                    GlStateManager.zerodayisaminecraftcheat(false);
                    GlStateManager.d();
                    GlStateManager.zeroday(770, 771);
                    final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                    final WorldRenderer worldrenderer = tessellator.sigma();
                    final int i = fontrenderer.zerodayisaminecraftcheat(s) / 2;
                    GlStateManager.n();
                    worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
                    worldrenderer.zeroday(-i - 1, -1.0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
                    worldrenderer.zeroday(-i - 1, 8.0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
                    worldrenderer.zeroday(i + 1, 8.0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
                    worldrenderer.zeroday(i + 1, -1.0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
                    tessellator.zeroday();
                    GlStateManager.m();
                    GlStateManager.zerodayisaminecraftcheat(true);
                    fontrenderer.zerodayisaminecraftcheat(s, -fontrenderer.zerodayisaminecraftcheat(s) / 2, 0, 553648127);
                    GlStateManager.zues();
                    GlStateManager.c();
                    GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                    GlStateManager.w();
                }
                else {
                    this.zerodayisaminecraftcheat(entity, s, x, y, z, 64);
                }
            }
        }
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final Entity entity) {
        return this.zerodayisaminecraftcheat((EntityItemFrame)entity);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final Entity entity, final double x, final double y, final double z) {
        this.zerodayisaminecraftcheat((EntityItemFrame)entity, x, y, z);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        this.zerodayisaminecraftcheat((EntityItemFrame)entity, x, y, z, entityYaw, partialTicks);
    }
}

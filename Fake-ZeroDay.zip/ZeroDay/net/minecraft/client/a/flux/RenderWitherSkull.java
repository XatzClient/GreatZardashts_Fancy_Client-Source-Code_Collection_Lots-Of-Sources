// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.RenderManager;
import net.minecraft.client.pandora.ModelSkeletonHead;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.momgetthecamera.EntityWitherSkull;
import net.minecraft.client.a.pandora.Render;

public class RenderWitherSkull extends Render<EntityWitherSkull>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    private final ModelSkeletonHead flux;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/wither/wither_invulnerable.png");
        zues = new ResourceLocation("textures/entity/wither/wither.png");
    }
    
    public RenderWitherSkull(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.flux = new ModelSkeletonHead();
    }
    
    private float zerodayisaminecraftcheat(final float p_82400_1_, final float p_82400_2_, final float p_82400_3_) {
        float f;
        for (f = p_82400_2_ - p_82400_1_; f < -180.0f; f += 360.0f) {}
        while (f >= 180.0f) {
            f -= 360.0f;
        }
        return p_82400_1_ + p_82400_3_ * f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityWitherSkull entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        GlStateManager.h();
        final float f = this.zerodayisaminecraftcheat(entity.A, entity.y, partialTicks);
        final float f2 = entity.B + (entity.z - entity.B) * partialTicks;
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        final float f3 = 0.0625f;
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(-1.0f, -1.0f, 1.0f);
        GlStateManager.pandora();
        this.sigma(entity);
        this.flux.zerodayisaminecraftcheat(entity, 0.0f, 0.0f, 0.0f, f, f2, f3);
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityWitherSkull entity) {
        return entity.momgetthecamera() ? RenderWitherSkull.zerodayisaminecraftcheat : RenderWitherSkull.zues;
    }
}

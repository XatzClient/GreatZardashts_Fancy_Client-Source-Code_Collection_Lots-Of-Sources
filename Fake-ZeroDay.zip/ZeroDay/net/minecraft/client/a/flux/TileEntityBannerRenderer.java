// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import net.minecraft.c.EnumDyeColor;
import java.util.List;
import java.util.Iterator;
import net.minecraft.client.a.zues.ITextureObject;
import net.minecraft.client.a.zues.LayeredColorMaskTexture;
import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.o.BlockPos;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.a.Blocks;
import com.google.common.collect.Maps;
import net.minecraft.client.pandora.ModelBanner;
import net.minecraft.o.ResourceLocation;
import java.util.Map;
import net.minecraft.n.TileEntityBanner;

public class TileEntityBannerRenderer extends TileEntitySpecialRenderer<TileEntityBanner>
{
    private static final Map<String, zerodayisaminecraftcheat> zerodayisaminecraftcheat;
    private static final ResourceLocation pandora;
    private ModelBanner zues;
    
    static {
        zerodayisaminecraftcheat = Maps.newHashMap();
        pandora = new ResourceLocation("textures/entity/banner_base.png");
    }
    
    public TileEntityBannerRenderer() {
        this.zues = new ModelBanner();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntityBanner te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        final boolean flag = te.x() != null;
        final boolean flag2 = !flag || te.e() == Blocks.cC;
        final int i = flag ? te.b() : 0;
        final long j = flag ? te.x().p() : 0L;
        GlStateManager.v();
        final float f = 0.6666667f;
        if (flag2) {
            GlStateManager.zeroday((float)x + 0.5f, (float)y + 0.75f * f, (float)z + 0.5f);
            final float f2 = i * 360 / 16.0f;
            GlStateManager.zeroday(-f2, 0.0f, 1.0f, 0.0f);
            this.zues.zeroday.b = true;
        }
        else {
            float f3 = 0.0f;
            if (i == 2) {
                f3 = 180.0f;
            }
            if (i == 4) {
                f3 = 90.0f;
            }
            if (i == 5) {
                f3 = -90.0f;
            }
            GlStateManager.zeroday((float)x + 0.5f, (float)y - 0.25f * f, (float)z + 0.5f);
            GlStateManager.zeroday(-f3, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(0.0f, -0.3125f, -0.4375f);
            this.zues.zeroday.b = false;
        }
        final BlockPos blockpos = te.d();
        final float f4 = blockpos.zerodayisaminecraftcheat() * 7 + blockpos.zeroday() * 9 + blockpos.sigma() * 13 + (float)j + partialTicks;
        this.zues.zerodayisaminecraftcheat.flux = (-0.0125f + 0.01f * MathHelper.zeroday(f4 * 3.1415927f * 0.02f)) * 3.1415927f;
        GlStateManager.s();
        final ResourceLocation resourcelocation = this.zerodayisaminecraftcheat(te);
        if (resourcelocation != null) {
            this.zerodayisaminecraftcheat(resourcelocation);
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(f, -f, -f);
            this.zues.zerodayisaminecraftcheat();
            GlStateManager.w();
        }
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.w();
    }
    
    private ResourceLocation zerodayisaminecraftcheat(final TileEntityBanner bannerObj) {
        final String s = bannerObj.zues();
        if (s.isEmpty()) {
            return null;
        }
        zerodayisaminecraftcheat tileentitybannerrenderer$timedbannertexture = TileEntityBannerRenderer.zerodayisaminecraftcheat.get(s);
        if (tileentitybannerrenderer$timedbannertexture == null) {
            if (TileEntityBannerRenderer.zerodayisaminecraftcheat.size() >= 256) {
                final long i = System.currentTimeMillis();
                final Iterator<String> iterator = TileEntityBannerRenderer.zerodayisaminecraftcheat.keySet().iterator();
                while (iterator.hasNext()) {
                    final String s2 = iterator.next();
                    final zerodayisaminecraftcheat tileentitybannerrenderer$timedbannertexture2 = TileEntityBannerRenderer.zerodayisaminecraftcheat.get(s2);
                    if (i - tileentitybannerrenderer$timedbannertexture2.zerodayisaminecraftcheat > 60000L) {
                        Minecraft.s().I().sigma(tileentitybannerrenderer$timedbannertexture2.zeroday);
                        iterator.remove();
                    }
                }
                if (TileEntityBannerRenderer.zerodayisaminecraftcheat.size() >= 256) {
                    return null;
                }
            }
            final List<TileEntityBanner.zerodayisaminecraftcheat> list1 = bannerObj.zeroday();
            final List<EnumDyeColor> list2 = bannerObj.pandora();
            final List<String> list3 = (List<String>)Lists.newArrayList();
            for (final TileEntityBanner.zerodayisaminecraftcheat tileentitybanner$enumbannerpattern : list1) {
                list3.add("textures/entity/banner/" + tileentitybanner$enumbannerpattern.zerodayisaminecraftcheat() + ".png");
            }
            tileentitybannerrenderer$timedbannertexture = new zerodayisaminecraftcheat(null);
            tileentitybannerrenderer$timedbannertexture.zeroday = new ResourceLocation(s);
            Minecraft.s().I().zerodayisaminecraftcheat(tileentitybannerrenderer$timedbannertexture.zeroday, new LayeredColorMaskTexture(TileEntityBannerRenderer.pandora, list3, list2));
            TileEntityBannerRenderer.zerodayisaminecraftcheat.put(s, tileentitybannerrenderer$timedbannertexture);
        }
        tileentitybannerrenderer$timedbannertexture.zerodayisaminecraftcheat = System.currentTimeMillis();
        return tileentitybannerrenderer$timedbannertexture.zeroday;
    }
    
    static class zerodayisaminecraftcheat
    {
        public long zerodayisaminecraftcheat;
        public ResourceLocation zeroday;
        
        private zerodayisaminecraftcheat() {
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import net.minecraft.zerodayisaminecraftcheat.Block;
import zeroday.pandora.zerodayisaminecraftcheat.h.O;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.e;
import zeroday.pandora.zerodayisaminecraftcheat.d.q;
import net.minecraft.zerodayisaminecraftcheat.BlockChest;
import net.minecraft.client.a.GlStateManager;
import java.util.Calendar;
import net.minecraft.client.pandora.ModelLargeChest;
import net.minecraft.client.pandora.ModelChest;
import net.minecraft.o.ResourceLocation;
import net.minecraft.n.TileEntityChest;

public class TileEntityChestRenderer extends TileEntitySpecialRenderer<TileEntityChest>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation pandora;
    private static final ResourceLocation zues;
    private static final ResourceLocation flux;
    private static final ResourceLocation vape;
    private static final ResourceLocation momgetthecamera;
    private ModelChest a;
    private ModelChest b;
    private boolean c;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/chest/trapped_double.png");
        pandora = new ResourceLocation("textures/entity/chest/christmas_double.png");
        zues = new ResourceLocation("textures/entity/chest/normal_double.png");
        flux = new ResourceLocation("textures/entity/chest/trapped.png");
        vape = new ResourceLocation("textures/entity/chest/christmas.png");
        momgetthecamera = new ResourceLocation("textures/entity/chest/normal.png");
    }
    
    public TileEntityChestRenderer() {
        this.a = new ModelChest();
        this.b = new ModelLargeChest();
        final Calendar calendar = Calendar.getInstance();
        if (calendar.get(2) + 1 == 12 && calendar.get(5) >= 24 && calendar.get(5) <= 26) {
            this.c = true;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntityChest te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        GlStateManager.b();
        GlStateManager.sigma(515);
        GlStateManager.zerodayisaminecraftcheat(true);
        int i;
        if (!te.momgetthecamera()) {
            i = 0;
        }
        else {
            final Block block = te.e();
            i = te.b();
            if (block instanceof BlockChest && i == 0) {
                ((BlockChest)block).zues(te.x(), te.d(), te.x().zeroday(te.d()));
                i = te.b();
            }
            te.m();
        }
        if (te.flux == null && te.momgetthecamera == null) {
            ModelChest modelchest;
            if (te.vape == null && te.a == null) {
                modelchest = this.a;
                if (destroyStage >= 0) {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.zeroday[destroyStage]);
                    GlStateManager.d(5890);
                    GlStateManager.v();
                    GlStateManager.zerodayisaminecraftcheat(4.0f, 4.0f, 1.0f);
                    GlStateManager.zeroday(0.0625f, 0.0625f, 0.0625f);
                    GlStateManager.d(5888);
                }
                else if (te.n() == 1) {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.flux);
                }
                else if (this.c) {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.vape);
                }
                else {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.momgetthecamera);
                }
            }
            else {
                modelchest = this.b;
                if (destroyStage >= 0) {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.zeroday[destroyStage]);
                    GlStateManager.d(5890);
                    GlStateManager.v();
                    GlStateManager.zerodayisaminecraftcheat(8.0f, 4.0f, 1.0f);
                    GlStateManager.zeroday(0.0625f, 0.0625f, 0.0625f);
                    GlStateManager.d(5888);
                }
                else if (te.n() == 1) {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.zerodayisaminecraftcheat);
                }
                else if (this.c) {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.pandora);
                }
                else {
                    this.zerodayisaminecraftcheat(TileEntityChestRenderer.zues);
                }
            }
            GlStateManager.v();
            GlStateManager.s();
            if (destroyStage < 0) {
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            }
            GlStateManager.zeroday((float)x, (float)y + 1.0f, (float)z + 1.0f);
            GlStateManager.zerodayisaminecraftcheat(1.0f, -1.0f, -1.0f);
            GlStateManager.zeroday(0.5f, 0.5f, 0.5f);
            int j = 0;
            if (i == 2) {
                j = 180;
            }
            if (i == 3) {
                j = 0;
            }
            if (i == 4) {
                j = 90;
            }
            if (i == 5) {
                j = -90;
            }
            if (i == 2 && te.vape != null) {
                GlStateManager.zeroday(1.0f, 0.0f, 0.0f);
            }
            if (i == 5 && te.a != null) {
                GlStateManager.zeroday(0.0f, 0.0f, -1.0f);
            }
            GlStateManager.zeroday((float)j, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(-0.5f, -0.5f, -0.5f);
            float f = te.c + (te.b - te.c) * partialTicks;
            if (te.flux != null) {
                final float f2 = te.flux.c + (te.flux.b - te.flux.c) * partialTicks;
                if (f2 > f) {
                    f = f2;
                }
            }
            if (te.momgetthecamera != null) {
                final float f3 = te.momgetthecamera.c + (te.momgetthecamera.b - te.momgetthecamera.c) * partialTicks;
                if (f3 > f) {
                    f = f3;
                }
            }
            f = 1.0f - f;
            f = 1.0f - f * f * f;
            modelchest.zerodayisaminecraftcheat.flux = -(f * 3.1415927f / 2.0f);
            modelchest.zerodayisaminecraftcheat();
            if (q.c && e.zeroday) {
                modelchest.zerodayisaminecraftcheat();
                O.zerodayisaminecraftcheat();
                modelchest.zerodayisaminecraftcheat();
                O.zeroday();
                modelchest.zerodayisaminecraftcheat();
                O.sigma();
                O.zerodayisaminecraftcheat(false);
                modelchest.zerodayisaminecraftcheat();
                O.pandora();
            }
            GlStateManager.t();
            GlStateManager.w();
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            if (destroyStage >= 0) {
                GlStateManager.d(5890);
                GlStateManager.w();
                GlStateManager.d(5888);
            }
        }
    }
}

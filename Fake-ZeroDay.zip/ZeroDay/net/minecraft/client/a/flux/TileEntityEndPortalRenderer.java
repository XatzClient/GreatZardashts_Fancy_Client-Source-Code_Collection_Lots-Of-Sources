// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.ActiveRenderInfo;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.GLAllocation;
import java.nio.FloatBuffer;
import java.util.Random;
import net.minecraft.o.ResourceLocation;
import net.minecraft.n.TileEntityEndPortal;

public class TileEntityEndPortalRenderer extends TileEntitySpecialRenderer<TileEntityEndPortal>
{
    private static final ResourceLocation pandora;
    private static final ResourceLocation zues;
    private static final Random flux;
    FloatBuffer zerodayisaminecraftcheat;
    
    static {
        pandora = new ResourceLocation("textures/environment/end_sky.png");
        zues = new ResourceLocation("textures/entity/end_portal.png");
        flux = new Random(31100L);
    }
    
    public TileEntityEndPortalRenderer() {
        this.zerodayisaminecraftcheat = GLAllocation.zues(16);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntityEndPortal te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        final float f = (float)this.sigma.b;
        final float f2 = (float)this.sigma.c;
        final float f3 = (float)this.sigma.d;
        GlStateManager.flux();
        TileEntityEndPortalRenderer.flux.setSeed(31100L);
        final float f4 = 0.75f;
        for (int i = 0; i < 16; ++i) {
            GlStateManager.v();
            float f5 = (float)(16 - i);
            float f6 = 0.0625f;
            float f7 = 1.0f / (f5 + 1.0f);
            if (i == 0) {
                this.zerodayisaminecraftcheat(TileEntityEndPortalRenderer.pandora);
                f7 = 0.1f;
                f5 = 65.0f;
                f6 = 0.125f;
                GlStateManager.d();
                GlStateManager.zeroday(770, 771);
            }
            if (i >= 1) {
                this.zerodayisaminecraftcheat(TileEntityEndPortalRenderer.zues);
            }
            if (i == 1) {
                GlStateManager.d();
                GlStateManager.zeroday(1, 1);
                f6 = 0.5f;
            }
            final float f8 = (float)(-(y + f4));
            float f9 = f8 + (float)ActiveRenderInfo.zerodayisaminecraftcheat().zeroday;
            final float f10 = f8 + f5 + (float)ActiveRenderInfo.zerodayisaminecraftcheat().zeroday;
            float f11 = f9 / f10;
            f11 += (float)(y + f4);
            GlStateManager.zeroday(f, f11, f3);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.zerodayisaminecraftcheat, 9217);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.zeroday, 9217);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.sigma, 9217);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.pandora, 9216);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.zerodayisaminecraftcheat, 9473, this.zerodayisaminecraftcheat(1.0f, 0.0f, 0.0f, 0.0f));
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.zeroday, 9473, this.zerodayisaminecraftcheat(0.0f, 0.0f, 1.0f, 0.0f));
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.sigma, 9473, this.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 1.0f));
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.pandora, 9474, this.zerodayisaminecraftcheat(0.0f, 1.0f, 0.0f, 0.0f));
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.zerodayisaminecraftcheat);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.zeroday);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.sigma);
            GlStateManager.zerodayisaminecraftcheat(GlStateManager.h.pandora);
            GlStateManager.w();
            GlStateManager.d(5890);
            GlStateManager.v();
            GlStateManager.u();
            GlStateManager.zeroday(0.0f, Minecraft.C() % 700000L / 700000.0f, 0.0f);
            GlStateManager.zerodayisaminecraftcheat(f6, f6, f6);
            GlStateManager.zeroday(0.5f, 0.5f, 0.0f);
            GlStateManager.zeroday((i * i * 4321 + i * 9) * 2.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.zeroday(-0.5f, -0.5f, 0.0f);
            GlStateManager.zeroday(-f, -f3, -f2);
            f9 = f8 + (float)ActiveRenderInfo.zerodayisaminecraftcheat().zeroday;
            GlStateManager.zeroday((float)ActiveRenderInfo.zerodayisaminecraftcheat().zerodayisaminecraftcheat * f5 / f9, (float)ActiveRenderInfo.zerodayisaminecraftcheat().sigma * f5 / f9, -f2);
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
            float f12 = (TileEntityEndPortalRenderer.flux.nextFloat() * 0.5f + 0.1f) * f7;
            float f13 = (TileEntityEndPortalRenderer.flux.nextFloat() * 0.5f + 0.4f) * f7;
            float f14 = (TileEntityEndPortalRenderer.flux.nextFloat() * 0.5f + 0.5f) * f7;
            if (i == 0) {
                f13 = (f12 = (f14 = 1.0f * f7));
            }
            worldrenderer.zeroday(x, y + f4, z).zerodayisaminecraftcheat(f12, f13, f14, 1.0f).zues();
            worldrenderer.zeroday(x, y + f4, z + 1.0).zerodayisaminecraftcheat(f12, f13, f14, 1.0f).zues();
            worldrenderer.zeroday(x + 1.0, y + f4, z + 1.0).zerodayisaminecraftcheat(f12, f13, f14, 1.0f).zues();
            worldrenderer.zeroday(x + 1.0, y + f4, z).zerodayisaminecraftcheat(f12, f13, f14, 1.0f).zues();
            tessellator.zeroday();
            GlStateManager.w();
            GlStateManager.d(5888);
            this.zerodayisaminecraftcheat(TileEntityEndPortalRenderer.pandora);
        }
        GlStateManager.c();
        GlStateManager.zeroday(GlStateManager.h.zerodayisaminecraftcheat);
        GlStateManager.zeroday(GlStateManager.h.zeroday);
        GlStateManager.zeroday(GlStateManager.h.sigma);
        GlStateManager.zeroday(GlStateManager.h.pandora);
        GlStateManager.zues();
    }
    
    private FloatBuffer zerodayisaminecraftcheat(final float p_147525_1_, final float p_147525_2_, final float p_147525_3_, final float p_147525_4_) {
        this.zerodayisaminecraftcheat.clear();
        this.zerodayisaminecraftcheat.put(p_147525_1_).put(p_147525_2_).put(p_147525_3_).put(p_147525_4_);
        this.zerodayisaminecraftcheat.flip();
        return this.zerodayisaminecraftcheat;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import zeroday.pandora.zerodayisaminecraftcheat.h.O;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.e;
import zeroday.pandora.zerodayisaminecraftcheat.d.q;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelChest;
import net.minecraft.o.ResourceLocation;
import net.minecraft.n.TileEntityEnderChest;

public class TileEntityEnderChestRenderer extends TileEntitySpecialRenderer<TileEntityEnderChest>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private ModelChest pandora;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/chest/ender.png");
    }
    
    public TileEntityEnderChestRenderer() {
        this.pandora = new ModelChest();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntityEnderChest te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        int i = 0;
        if (te.momgetthecamera()) {
            i = te.b();
        }
        if (destroyStage >= 0) {
            this.zerodayisaminecraftcheat(TileEntityEnderChestRenderer.zeroday[destroyStage]);
            GlStateManager.d(5890);
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(4.0f, 4.0f, 1.0f);
            GlStateManager.zeroday(0.0625f, 0.0625f, 0.0625f);
            GlStateManager.d(5888);
        }
        else {
            this.zerodayisaminecraftcheat(TileEntityEnderChestRenderer.zerodayisaminecraftcheat);
        }
        GlStateManager.v();
        GlStateManager.s();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.zeroday((float)x, (float)y + 1.0f, (float)z + 1.0f);
        GlStateManager.zerodayisaminecraftcheat(1.0f, -1.0f, -1.0f);
        GlStateManager.zeroday(0.5f, 0.5f, 0.5f);
        int j = 0;
        if (i == 2) {
            j = 180;
        }
        if (i == 3) {
            j = 0;
        }
        if (i == 4) {
            j = 90;
        }
        if (i == 5) {
            j = -90;
        }
        GlStateManager.zeroday((float)j, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(-0.5f, -0.5f, -0.5f);
        float f = te.flux + (te.zues - te.flux) * partialTicks;
        f = 1.0f - f;
        f = 1.0f - f * f * f;
        this.pandora.zerodayisaminecraftcheat.flux = -(f * 3.1415927f / 2.0f);
        this.pandora.zerodayisaminecraftcheat();
        if (q.c && e.zeroday) {
            this.pandora.zerodayisaminecraftcheat();
            this.pandora.zerodayisaminecraftcheat();
            O.zerodayisaminecraftcheat();
            this.pandora.zerodayisaminecraftcheat();
            O.zeroday();
            this.pandora.zerodayisaminecraftcheat();
            O.sigma();
            O.zerodayisaminecraftcheat(false);
            this.pandora.zerodayisaminecraftcheat();
            O.pandora();
        }
        GlStateManager.t();
        GlStateManager.w();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        if (destroyStage >= 0) {
            GlStateManager.d(5890);
            GlStateManager.w();
            GlStateManager.d(5888);
        }
    }
}

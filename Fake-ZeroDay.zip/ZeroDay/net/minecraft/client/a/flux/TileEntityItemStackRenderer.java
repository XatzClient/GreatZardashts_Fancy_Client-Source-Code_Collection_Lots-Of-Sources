// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagCompound;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.d.NBTUtil;
import net.minecraft.n.TileEntity;
import net.minecraft.a.Items;
import net.minecraft.c.ItemStack;
import net.minecraft.n.TileEntitySkull;
import net.minecraft.n.TileEntityBanner;
import net.minecraft.n.TileEntityEnderChest;
import net.minecraft.n.TileEntityChest;

public class TileEntityItemStackRenderer
{
    public static TileEntityItemStackRenderer zerodayisaminecraftcheat;
    private TileEntityChest zeroday;
    private TileEntityChest sigma;
    private TileEntityEnderChest pandora;
    private TileEntityBanner zues;
    private TileEntitySkull flux;
    
    static {
        TileEntityItemStackRenderer.zerodayisaminecraftcheat = new TileEntityItemStackRenderer();
    }
    
    public TileEntityItemStackRenderer() {
        this.zeroday = new TileEntityChest(0);
        this.sigma = new TileEntityChest(1);
        this.pandora = new TileEntityEnderChest();
        this.zues = new TileEntityBanner();
        this.flux = new TileEntitySkull();
    }
    
    public void zerodayisaminecraftcheat(final ItemStack itemStackIn) {
        if (itemStackIn.zerodayisaminecraftcheat() == Items.cw) {
            this.zues.zerodayisaminecraftcheat(itemStackIn);
            TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues, 0.0, 0.0, 0.0, 0.0f);
        }
        else if (itemStackIn.zerodayisaminecraftcheat() == Items.bP) {
            GameProfile gameprofile = null;
            if (itemStackIn.f()) {
                final NBTTagCompound nbttagcompound = itemStackIn.g();
                if (nbttagcompound.zeroday("SkullOwner", 10)) {
                    gameprofile = NBTUtil.zerodayisaminecraftcheat(nbttagcompound.e("SkullOwner"));
                }
                else if (nbttagcompound.zeroday("SkullOwner", 8) && nbttagcompound.b("SkullOwner").length() > 0) {
                    gameprofile = new GameProfile((UUID)null, nbttagcompound.b("SkullOwner"));
                    gameprofile = TileEntitySkull.zeroday(gameprofile);
                    nbttagcompound.g("SkullOwner");
                    nbttagcompound.zerodayisaminecraftcheat("SkullOwner", NBTUtil.zerodayisaminecraftcheat(new NBTTagCompound(), gameprofile));
                }
            }
            if (TileEntitySkullRenderer.zerodayisaminecraftcheat != null) {
                GlStateManager.v();
                GlStateManager.zeroday(-0.5f, 0.0f, -0.5f);
                GlStateManager.zerodayisaminecraftcheat(2.0f, 2.0f, 2.0f);
                GlStateManager.h();
                TileEntitySkullRenderer.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, EnumFacing.zeroday, 0.0f, itemStackIn.momgetthecamera(), gameprofile, -1);
                GlStateManager.g();
                GlStateManager.w();
            }
        }
        else {
            final Block block = Block.zerodayisaminecraftcheat(itemStackIn.zerodayisaminecraftcheat());
            if (block == Blocks.bI) {
                TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.pandora, 0.0, 0.0, 0.0, 0.0f);
            }
            else if (block == Blocks.bY) {
                TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.sigma, 0.0, 0.0, 0.0, 0.0f);
            }
            else {
                TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zeroday, 0.0, 0.0, 0.0, 0.0f);
            }
        }
    }
}

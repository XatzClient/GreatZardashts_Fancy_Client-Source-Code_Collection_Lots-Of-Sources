// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import net.minecraft.vape.Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.n.MobSpawnerBaseLogic;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.n.TileEntityMobSpawner;

public class TileEntityMobSpawnerRenderer extends TileEntitySpecialRenderer<TileEntityMobSpawner>
{
    @Override
    public void zerodayisaminecraftcheat(final TileEntityMobSpawner te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        GlStateManager.v();
        GlStateManager.zeroday((float)x + 0.5f, (float)y, (float)z + 0.5f);
        zerodayisaminecraftcheat(te.zeroday(), x, y, z, partialTicks);
        GlStateManager.w();
    }
    
    public static void zerodayisaminecraftcheat(final MobSpawnerBaseLogic mobSpawnerLogic, final double posX, final double posY, final double posZ, final float partialTicks) {
        final Entity entity = mobSpawnerLogic.zerodayisaminecraftcheat(mobSpawnerLogic.zerodayisaminecraftcheat());
        if (entity != null) {
            final float f = 0.4375f;
            GlStateManager.zeroday(0.0f, 0.4f, 0.0f);
            GlStateManager.zeroday((float)(mobSpawnerLogic.zues() + (mobSpawnerLogic.pandora() - mobSpawnerLogic.zues()) * partialTicks) * 10.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(-30.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(0.0f, -0.4f, 0.0f);
            GlStateManager.zerodayisaminecraftcheat(f, f, f);
            entity.zeroday(posX, posY, posZ, 0.0f, 0.0f);
            Minecraft.s().Y().zerodayisaminecraftcheat(entity, 0.0, 0.0, 0.0, 0.0f, partialTicks);
        }
    }
}

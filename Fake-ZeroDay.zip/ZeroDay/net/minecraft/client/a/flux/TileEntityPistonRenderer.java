// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import net.minecraft.q.World;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.o.BlockPos;
import net.minecraft.zerodayisaminecraftcheat.BlockPistonBase;
import net.minecraft.o.EnumFacing;
import net.minecraft.q.IBlockAccess;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockPistonExtension;
import net.minecraft.a.Blocks;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.Tessellator;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.n.TileEntityPiston;

public class TileEntityPistonRenderer extends TileEntitySpecialRenderer<TileEntityPiston>
{
    private final BlockRendererDispatcher zerodayisaminecraftcheat;
    
    public TileEntityPistonRenderer() {
        this.zerodayisaminecraftcheat = Minecraft.s().X();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntityPiston te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        final BlockPos blockpos = te.d();
        IBlockState iblockstate = te.zeroday();
        final Block block = iblockstate.sigma();
        if (block.flux() != Material.zerodayisaminecraftcheat && te.zerodayisaminecraftcheat(partialTicks) < 1.0f) {
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            this.zerodayisaminecraftcheat(TextureMap.zeroday);
            RenderHelper.zerodayisaminecraftcheat();
            GlStateManager.zeroday(770, 771);
            GlStateManager.d();
            GlStateManager.h();
            if (Minecraft.r()) {
                GlStateManager.b(7425);
            }
            else {
                GlStateManager.b(7424);
            }
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.zerodayisaminecraftcheat);
            worldrenderer.sigma((float)x - blockpos.zerodayisaminecraftcheat() + te.zeroday(partialTicks), (float)y - blockpos.zeroday() + te.sigma(partialTicks), (double)((float)z - blockpos.sigma() + te.pandora(partialTicks)));
            final World world = this.sigma();
            if (block == Blocks.C && te.zerodayisaminecraftcheat(partialTicks) < 0.5f) {
                iblockstate = iblockstate.zerodayisaminecraftcheat((IProperty<Comparable>)BlockPistonExtension.F, true);
                this.zerodayisaminecraftcheat.zeroday().zerodayisaminecraftcheat(world, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(iblockstate, world, blockpos), iblockstate, blockpos, worldrenderer, true);
            }
            else if (te.zues() && !te.sigma()) {
                final BlockPistonExtension.zerodayisaminecraftcheat blockpistonextension$enumpistontype = (block == Blocks.x) ? BlockPistonExtension.zerodayisaminecraftcheat.zeroday : BlockPistonExtension.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
                IBlockState iblockstate2 = Blocks.C.G().zerodayisaminecraftcheat(BlockPistonExtension.E, blockpistonextension$enumpistontype).zerodayisaminecraftcheat((IProperty<Comparable>)BlockPistonExtension.D, (EnumFacing)iblockstate.zerodayisaminecraftcheat((IProperty<V>)BlockPistonBase.D));
                iblockstate2 = iblockstate2.zerodayisaminecraftcheat((IProperty<Comparable>)BlockPistonExtension.F, te.zerodayisaminecraftcheat(partialTicks) >= 0.5f);
                this.zerodayisaminecraftcheat.zeroday().zerodayisaminecraftcheat(world, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(iblockstate2, world, blockpos), iblockstate2, blockpos, worldrenderer, true);
                worldrenderer.sigma((float)x - blockpos.zerodayisaminecraftcheat(), (float)y - blockpos.zeroday(), (double)((float)z - blockpos.sigma()));
                iblockstate.zerodayisaminecraftcheat((IProperty<Comparable>)BlockPistonBase.E, true);
                this.zerodayisaminecraftcheat.zeroday().zerodayisaminecraftcheat(world, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(iblockstate, world, blockpos), iblockstate, blockpos, worldrenderer, true);
            }
            else {
                this.zerodayisaminecraftcheat.zeroday().zerodayisaminecraftcheat(world, this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(iblockstate, world, blockpos), iblockstate, blockpos, worldrenderer, false);
            }
            worldrenderer.sigma(0.0, 0.0, 0.0);
            tessellator.zeroday();
            RenderHelper.zeroday();
        }
    }
}

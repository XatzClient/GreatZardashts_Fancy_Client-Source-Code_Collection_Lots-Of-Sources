// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.o.ReportedException;
import net.minecraft.sigma.CrashReport;
import net.minecraft.o.BlockPos;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.OpenGlHelper;
import java.util.Iterator;
import net.minecraft.n.TileEntityBanner;
import net.minecraft.n.TileEntitySkull;
import net.minecraft.n.TileEntityBeacon;
import net.minecraft.n.TileEntityEndPortal;
import net.minecraft.n.TileEntityEnchantmentTable;
import net.minecraft.n.TileEntityEnderChest;
import net.minecraft.n.TileEntityChest;
import net.minecraft.n.TileEntityPiston;
import net.minecraft.n.TileEntityMobSpawner;
import net.minecraft.n.TileEntitySign;
import com.google.common.collect.Maps;
import net.minecraft.vape.Entity;
import net.minecraft.q.World;
import net.minecraft.client.a.zues.TextureManager;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.n.TileEntity;
import java.util.Map;

public class TileEntityRendererDispatcher
{
    private Map<Class<? extends TileEntity>, TileEntitySpecialRenderer<? extends TileEntity>> e;
    public static TileEntityRendererDispatcher zerodayisaminecraftcheat;
    private FontRenderer f;
    public static double zeroday;
    public static double sigma;
    public static double pandora;
    public TextureManager zues;
    public World flux;
    public Entity vape;
    public float momgetthecamera;
    public float a;
    public double b;
    public double c;
    public double d;
    
    static {
        TileEntityRendererDispatcher.zerodayisaminecraftcheat = new TileEntityRendererDispatcher();
    }
    
    private TileEntityRendererDispatcher() {
        (this.e = (Map<Class<? extends TileEntity>, TileEntitySpecialRenderer<? extends TileEntity>>)Maps.newHashMap()).put(TileEntitySign.class, new TileEntitySignRenderer());
        this.e.put(TileEntityMobSpawner.class, new TileEntityMobSpawnerRenderer());
        this.e.put(TileEntityPiston.class, new TileEntityPistonRenderer());
        this.e.put(TileEntityChest.class, new TileEntityChestRenderer());
        this.e.put(TileEntityEnderChest.class, new TileEntityEnderChestRenderer());
        this.e.put(TileEntityEnchantmentTable.class, new TileEntityEnchantmentTableRenderer());
        this.e.put(TileEntityEndPortal.class, new TileEntityEndPortalRenderer());
        this.e.put(TileEntityBeacon.class, new TileEntityBeaconRenderer());
        this.e.put(TileEntitySkull.class, new TileEntitySkullRenderer());
        this.e.put(TileEntityBanner.class, new TileEntityBannerRenderer());
        for (final TileEntitySpecialRenderer<?> tileentityspecialrenderer : this.e.values()) {
            tileentityspecialrenderer.zerodayisaminecraftcheat(this);
        }
    }
    
    public <T extends TileEntity> TileEntitySpecialRenderer<T> zerodayisaminecraftcheat(final Class<? extends TileEntity> teClass) {
        TileEntitySpecialRenderer<? extends TileEntity> tileentityspecialrenderer = this.e.get(teClass);
        if (tileentityspecialrenderer == null && teClass != TileEntity.class) {
            tileentityspecialrenderer = this.zerodayisaminecraftcheat((Class<? extends TileEntity>)teClass.getSuperclass());
            this.e.put(teClass, tileentityspecialrenderer);
        }
        return (TileEntitySpecialRenderer<T>)tileentityspecialrenderer;
    }
    
    public <T extends TileEntity> TileEntitySpecialRenderer<T> zerodayisaminecraftcheat(final TileEntity tileEntityIn) {
        return (tileEntityIn == null) ? null : this.zerodayisaminecraftcheat(tileEntityIn.getClass());
    }
    
    public void zerodayisaminecraftcheat(final World worldIn, final TextureManager textureManagerIn, final FontRenderer fontrendererIn, final Entity entityIn, final float partialTicks) {
        if (this.flux != worldIn) {
            this.zerodayisaminecraftcheat(worldIn);
        }
        this.zues = textureManagerIn;
        this.vape = entityIn;
        this.f = fontrendererIn;
        this.momgetthecamera = entityIn.A + (entityIn.y - entityIn.A) * partialTicks;
        this.a = entityIn.B + (entityIn.z - entityIn.B) * partialTicks;
        this.b = entityIn.Q + (entityIn.s - entityIn.Q) * partialTicks;
        this.c = entityIn.R + (entityIn.t - entityIn.R) * partialTicks;
        this.d = entityIn.S + (entityIn.u - entityIn.S) * partialTicks;
    }
    
    public void zerodayisaminecraftcheat(final TileEntity tileentityIn, final float partialTicks, final int destroyStage) {
        if (tileentityIn.zerodayisaminecraftcheat(this.b, this.c, this.d) < tileentityIn.c()) {
            final int i = this.flux.zerodayisaminecraftcheat(tileentityIn.d(), 0);
            final int j = i % 65536;
            final int k = i / 65536;
            OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, j / 1.0f, k / 1.0f);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            final BlockPos blockpos = tileentityIn.d();
            this.zerodayisaminecraftcheat(tileentityIn, blockpos.zerodayisaminecraftcheat() - TileEntityRendererDispatcher.zeroday, blockpos.zeroday() - TileEntityRendererDispatcher.sigma, blockpos.sigma() - TileEntityRendererDispatcher.pandora, partialTicks, destroyStage);
        }
    }
    
    public void zerodayisaminecraftcheat(final TileEntity tileEntityIn, final double x, final double y, final double z, final float partialTicks) {
        this.zerodayisaminecraftcheat(tileEntityIn, x, y, z, partialTicks, -1);
    }
    
    public void zerodayisaminecraftcheat(final TileEntity tileEntityIn, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        final TileEntitySpecialRenderer<TileEntity> tileentityspecialrenderer = this.zerodayisaminecraftcheat(tileEntityIn);
        if (tileentityspecialrenderer != null) {
            try {
                tileentityspecialrenderer.zerodayisaminecraftcheat(tileEntityIn, x, y, z, partialTicks, destroyStage);
            }
            catch (Throwable throwable) {
                final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Rendering Block Entity");
                final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Block Entity Details");
                tileEntityIn.zerodayisaminecraftcheat(crashreportcategory);
                throw new ReportedException(crashreport);
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final World worldIn) {
        this.flux = worldIn;
    }
    
    public FontRenderer zerodayisaminecraftcheat() {
        return this.f;
    }
}

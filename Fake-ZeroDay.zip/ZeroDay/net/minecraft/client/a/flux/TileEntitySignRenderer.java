// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import java.util.List;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.o.IChatComponent;
import net.minecraft.client.sigma.GuiUtilRenderComponents;
import org.lwjgl.opengl.GL11;
import net.minecraft.a.Blocks;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelSign;
import net.minecraft.o.ResourceLocation;
import net.minecraft.n.TileEntitySign;

public class TileEntitySignRenderer extends TileEntitySpecialRenderer<TileEntitySign>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final ModelSign pandora;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/sign.png");
    }
    
    public TileEntitySignRenderer() {
        this.pandora = new ModelSign();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntitySign te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        final Block block = te.e();
        GlStateManager.v();
        final float f = 0.6666667f;
        if (block == Blocks.af) {
            GlStateManager.zeroday((float)x + 0.5f, (float)y + 0.75f * f, (float)z + 0.5f);
            final float f2 = te.b() * 360 / 16.0f;
            GlStateManager.zeroday(-f2, 0.0f, 1.0f, 0.0f);
            this.pandora.zeroday.b = true;
        }
        else {
            final int k = te.b();
            float f3 = 0.0f;
            if (k == 2) {
                f3 = 180.0f;
            }
            if (k == 4) {
                f3 = 90.0f;
            }
            if (k == 5) {
                f3 = -90.0f;
            }
            GlStateManager.zeroday((float)x + 0.5f, (float)y + 0.75f * f, (float)z + 0.5f);
            GlStateManager.zeroday(-f3, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(0.0f, -0.3125f, -0.4375f);
            this.pandora.zeroday.b = false;
        }
        if (destroyStage >= 0) {
            this.zerodayisaminecraftcheat(TileEntitySignRenderer.zeroday[destroyStage]);
            GlStateManager.d(5890);
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(4.0f, 2.0f, 1.0f);
            GlStateManager.zeroday(0.0625f, 0.0625f, 0.0625f);
            GlStateManager.d(5888);
        }
        else {
            this.zerodayisaminecraftcheat(TileEntitySignRenderer.zerodayisaminecraftcheat);
        }
        GlStateManager.s();
        GlStateManager.v();
        GlStateManager.zerodayisaminecraftcheat(f, -f, -f);
        this.pandora.zerodayisaminecraftcheat();
        GlStateManager.w();
        final FontRenderer fontrenderer = this.pandora();
        final float f4 = 0.015625f * f;
        GlStateManager.zeroday(0.0f, 0.5f * f, 0.07f * f);
        GlStateManager.zerodayisaminecraftcheat(f4, -f4, f4);
        GL11.glNormal3f(0.0f, 0.0f, -1.0f * f4);
        GlStateManager.zerodayisaminecraftcheat(false);
        final int i = 0;
        if (destroyStage < 0) {
            for (int j = 0; j < te.zues.length; ++j) {
                if (te.zues[j] != null) {
                    final IChatComponent ichatcomponent = te.zues[j];
                    final List<IChatComponent> list = GuiUtilRenderComponents.zerodayisaminecraftcheat(ichatcomponent, 90, fontrenderer, false, true);
                    String s = (list != null && list.size() > 0) ? list.get(0).a() : "";
                    if (j == te.flux) {
                        s = "> " + s + " <";
                        fontrenderer.zerodayisaminecraftcheat(s, -fontrenderer.zerodayisaminecraftcheat(s) / 2, j * 10 - te.zues.length * 5, i);
                    }
                    else {
                        fontrenderer.zerodayisaminecraftcheat(s, -fontrenderer.zerodayisaminecraftcheat(s) / 2, j * 10 - te.zues.length * 5, i);
                    }
                }
            }
        }
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.w();
        if (destroyStage >= 0) {
            GlStateManager.d(5890);
            GlStateManager.w();
            GlStateManager.d(5888);
        }
    }
}

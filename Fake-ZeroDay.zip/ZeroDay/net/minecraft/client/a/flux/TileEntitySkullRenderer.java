// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.n.TileEntity;
import java.util.UUID;
import java.util.Map;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.vape.Entity;
import net.minecraft.vape.vape.EntityPlayer;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.b.DefaultPlayerSkin;
import net.minecraft.client.a.GlStateManager;
import com.mojang.authlib.GameProfile;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.pandora.ModelHumanoidHead;
import net.minecraft.client.pandora.ModelSkeletonHead;
import net.minecraft.o.ResourceLocation;
import net.minecraft.n.TileEntitySkull;

public class TileEntitySkullRenderer extends TileEntitySpecialRenderer<TileEntitySkull>
{
    private static final ResourceLocation pandora;
    private static final ResourceLocation zues;
    private static final ResourceLocation flux;
    private static final ResourceLocation vape;
    public static TileEntitySkullRenderer zerodayisaminecraftcheat;
    private final ModelSkeletonHead momgetthecamera;
    private final ModelSkeletonHead a;
    private static /* synthetic */ int[] b;
    
    static {
        pandora = new ResourceLocation("textures/entity/skeleton/skeleton.png");
        zues = new ResourceLocation("textures/entity/skeleton/wither_skeleton.png");
        flux = new ResourceLocation("textures/entity/zombie/zombie.png");
        vape = new ResourceLocation("textures/entity/creeper/creeper.png");
    }
    
    public TileEntitySkullRenderer() {
        this.momgetthecamera = new ModelSkeletonHead(0, 0, 64, 32);
        this.a = new ModelHumanoidHead();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntitySkull te, final double x, final double y, final double z, final float partialTicks, final int destroyStage) {
        final EnumFacing enumfacing = EnumFacing.zerodayisaminecraftcheat(te.b() & 0x7);
        this.zerodayisaminecraftcheat((float)x, (float)y, (float)z, enumfacing, te.sigma() * 360 / 16.0f, te.zeroday(), te.zerodayisaminecraftcheat(), destroyStage);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final TileEntityRendererDispatcher rendererDispatcherIn) {
        super.zerodayisaminecraftcheat(rendererDispatcherIn);
        TileEntitySkullRenderer.zerodayisaminecraftcheat = this;
    }
    
    public void zerodayisaminecraftcheat(final float p_180543_1_, final float p_180543_2_, final float p_180543_3_, final EnumFacing p_180543_4_, float p_180543_5_, final int p_180543_6_, final GameProfile p_180543_7_, final int p_180543_8_) {
        ModelBase modelbase = this.momgetthecamera;
        if (p_180543_8_ >= 0) {
            this.zerodayisaminecraftcheat(TileEntitySkullRenderer.zeroday[p_180543_8_]);
            GlStateManager.d(5890);
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(4.0f, 2.0f, 1.0f);
            GlStateManager.zeroday(0.0625f, 0.0625f, 0.0625f);
            GlStateManager.d(5888);
        }
        else {
            switch (p_180543_6_) {
                default: {
                    this.zerodayisaminecraftcheat(TileEntitySkullRenderer.pandora);
                    break;
                }
                case 1: {
                    this.zerodayisaminecraftcheat(TileEntitySkullRenderer.zues);
                    break;
                }
                case 2: {
                    this.zerodayisaminecraftcheat(TileEntitySkullRenderer.flux);
                    modelbase = this.a;
                    break;
                }
                case 3: {
                    modelbase = this.a;
                    ResourceLocation resourcelocation = DefaultPlayerSkin.zerodayisaminecraftcheat();
                    if (p_180543_7_ != null) {
                        final Minecraft minecraft = Minecraft.s();
                        final Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> map = minecraft.U().zerodayisaminecraftcheat(p_180543_7_);
                        if (map.containsKey(MinecraftProfileTexture.Type.SKIN)) {
                            resourcelocation = minecraft.U().zerodayisaminecraftcheat(map.get(MinecraftProfileTexture.Type.SKIN), MinecraftProfileTexture.Type.SKIN);
                        }
                        else {
                            final UUID uuid = EntityPlayer.zerodayisaminecraftcheat(p_180543_7_);
                            resourcelocation = DefaultPlayerSkin.zerodayisaminecraftcheat(uuid);
                        }
                    }
                    this.zerodayisaminecraftcheat(resourcelocation);
                    break;
                }
                case 4: {
                    this.zerodayisaminecraftcheat(TileEntitySkullRenderer.vape);
                    break;
                }
            }
        }
        GlStateManager.v();
        GlStateManager.h();
        if (p_180543_4_ != EnumFacing.zeroday) {
            switch (zeroday()[p_180543_4_.ordinal()]) {
                case 3: {
                    GlStateManager.zeroday(p_180543_1_ + 0.5f, p_180543_2_ + 0.25f, p_180543_3_ + 0.74f);
                    break;
                }
                case 4: {
                    GlStateManager.zeroday(p_180543_1_ + 0.5f, p_180543_2_ + 0.25f, p_180543_3_ + 0.26f);
                    p_180543_5_ = 180.0f;
                    break;
                }
                case 5: {
                    GlStateManager.zeroday(p_180543_1_ + 0.74f, p_180543_2_ + 0.25f, p_180543_3_ + 0.5f);
                    p_180543_5_ = 270.0f;
                    break;
                }
                default: {
                    GlStateManager.zeroday(p_180543_1_ + 0.26f, p_180543_2_ + 0.25f, p_180543_3_ + 0.5f);
                    p_180543_5_ = 90.0f;
                    break;
                }
            }
        }
        else {
            GlStateManager.zeroday(p_180543_1_ + 0.5f, p_180543_2_, p_180543_3_ + 0.5f);
        }
        final float f = 0.0625f;
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(-1.0f, -1.0f, 1.0f);
        GlStateManager.pandora();
        modelbase.zerodayisaminecraftcheat(null, 0.0f, 0.0f, 0.0f, p_180543_5_, 0.0f, f);
        GlStateManager.w();
        if (p_180543_8_ >= 0) {
            GlStateManager.d(5890);
            GlStateManager.w();
            GlStateManager.d(5888);
        }
    }
    
    static /* synthetic */ int[] zeroday() {
        final int[] b = TileEntitySkullRenderer.b;
        if (b != null) {
            return b;
        }
        final int[] b2 = new int[EnumFacing.values().length];
        try {
            b2[EnumFacing.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            b2[EnumFacing.flux.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            b2[EnumFacing.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            b2[EnumFacing.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            b2[EnumFacing.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            b2[EnumFacing.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        return TileEntitySkullRenderer.b = b2;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.flux;

import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.q.World;
import net.minecraft.client.a.zues.TextureManager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.n.TileEntity;

public abstract class TileEntitySpecialRenderer<T extends TileEntity>
{
    protected static final ResourceLocation[] zeroday;
    protected TileEntityRendererDispatcher sigma;
    
    static {
        zeroday = new ResourceLocation[] { new ResourceLocation("textures/blocks/destroy_stage_0.png"), new ResourceLocation("textures/blocks/destroy_stage_1.png"), new ResourceLocation("textures/blocks/destroy_stage_2.png"), new ResourceLocation("textures/blocks/destroy_stage_3.png"), new ResourceLocation("textures/blocks/destroy_stage_4.png"), new ResourceLocation("textures/blocks/destroy_stage_5.png"), new ResourceLocation("textures/blocks/destroy_stage_6.png"), new ResourceLocation("textures/blocks/destroy_stage_7.png"), new ResourceLocation("textures/blocks/destroy_stage_8.png"), new ResourceLocation("textures/blocks/destroy_stage_9.png") };
    }
    
    public abstract void zerodayisaminecraftcheat(final T p0, final double p1, final double p2, final double p3, final float p4, final int p5);
    
    protected void zerodayisaminecraftcheat(final ResourceLocation location) {
        final TextureManager texturemanager = this.sigma.zues;
        if (texturemanager != null) {
            texturemanager.zerodayisaminecraftcheat(location);
        }
    }
    
    protected World sigma() {
        return this.sigma.flux;
    }
    
    public void zerodayisaminecraftcheat(final TileEntityRendererDispatcher rendererDispatcherIn) {
        this.sigma = rendererDispatcherIn;
    }
    
    public FontRenderer pandora() {
        return this.sigma.zerodayisaminecraftcheat();
    }
    
    public boolean zerodayisaminecraftcheat() {
        return false;
    }
}

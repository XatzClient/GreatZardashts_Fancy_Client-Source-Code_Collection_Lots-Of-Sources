// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerCustomHead;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItem;
import net.minecraft.client.pandora.ModelArmorStandArmor;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerBipedArmor;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelArmorStand;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.pandora.EntityArmorStand;

public class ArmorStandRenderer extends RendererLivingEntity<EntityArmorStand>
{
    public static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/armorstand/wood.png");
    }
    
    public ArmorStandRenderer(final RenderManager p_i46195_1_) {
        super(p_i46195_1_, new ModelArmorStand(), 0.0f);
        final LayerBipedArmor layerbipedarmor = new LayerBipedArmor(this) {
            @Override
            protected void zerodayisaminecraftcheat() {
                this.sigma = (T)new ModelArmorStandArmor(0.5f);
                this.pandora = (T)new ModelArmorStandArmor(1.0f);
            }
        };
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(layerbipedarmor);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldItem(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerCustomHead(this.zerodayisaminecraftcheat().c));
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityArmorStand entity) {
        return ArmorStandRenderer.zerodayisaminecraftcheat;
    }
    
    public ModelArmorStand zerodayisaminecraftcheat() {
        return (ModelArmorStand)super.zeroday();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityArmorStand bat, final float p_77043_2_, final float p_77043_3_, final float partialTicks) {
        GlStateManager.zeroday(180.0f - p_77043_3_, 0.0f, 1.0f, 0.0f);
    }
    
    @Override
    protected boolean zeroday(final EntityArmorStand entity) {
        return entity.aD();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import org.lwjgl.opengl.GL11;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Iterator;
import net.minecraft.q.World;
import net.minecraft.o.BlockPos;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.EntityLiving;
import sigma.zerodayisaminecraftcheat.j;
import net.minecraft.l.Config;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.client.a.sigma.ICamera;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.Entity;

public abstract class Render<T extends Entity>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    protected final RenderManager zeroday;
    protected float sigma;
    protected float pandora;
    private static final String zues = "CL_00000992";
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/misc/shadow.png");
    }
    
    protected Render(final RenderManager renderManager) {
        this.pandora = 1.0f;
        this.zeroday = renderManager;
    }
    
    public boolean zerodayisaminecraftcheat(final T livingEntity, final ICamera camera, final double camX, final double camY, final double camZ) {
        AxisAlignedBB axisalignedbb = livingEntity.aH();
        if (axisalignedbb.zeroday() || axisalignedbb.zerodayisaminecraftcheat() == 0.0) {
            axisalignedbb = new AxisAlignedBB(livingEntity.s - 2.0, livingEntity.t - 2.0, livingEntity.u - 2.0, livingEntity.s + 2.0, livingEntity.t + 2.0, livingEntity.u + 2.0);
        }
        return livingEntity.momgetthecamera(camX, camY, camZ) && (livingEntity.al || camera.zerodayisaminecraftcheat(axisalignedbb));
    }
    
    public void zerodayisaminecraftcheat(final T entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        this.zerodayisaminecraftcheat(entity, x, y, z);
    }
    
    protected void zerodayisaminecraftcheat(final T entity, final double x, final double y, final double z) {
        if (this.zeroday(entity)) {
            this.zerodayisaminecraftcheat(entity, entity.sigma().a(), x, y, z, 64);
        }
    }
    
    protected boolean zeroday(final T entity) {
        return entity.aE() && entity.p_();
    }
    
    protected void zerodayisaminecraftcheat(final T entityIn, final double x, final double y, final double z, final String str, final float p_177069_9_, final double p_177069_10_) {
        this.zerodayisaminecraftcheat(entityIn, str, x, y, z, 64);
    }
    
    protected abstract ResourceLocation zerodayisaminecraftcheat(final T p0);
    
    protected boolean sigma(final T entity) {
        final ResourceLocation resourcelocation = this.zerodayisaminecraftcheat(entity);
        if (resourcelocation == null) {
            return false;
        }
        this.zerodayisaminecraftcheat(resourcelocation);
        return true;
    }
    
    public void zerodayisaminecraftcheat(final ResourceLocation location) {
        this.zeroday.pandora.zerodayisaminecraftcheat(location);
    }
    
    private void zerodayisaminecraftcheat(final Entity entity, final double x, final double y, final double z, final float partialTicks) {
        GlStateManager.flux();
        final TextureMap texturemap = Minecraft.s().M();
        final TextureAtlasSprite textureatlassprite = texturemap.zerodayisaminecraftcheat("minecraft:blocks/fire_layer_0");
        final TextureAtlasSprite textureatlassprite2 = texturemap.zerodayisaminecraftcheat("minecraft:blocks/fire_layer_1");
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        final float f = entity.K * 1.4f;
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        float f2 = 0.5f;
        final float f3 = 0.0f;
        float f4 = entity.L / f;
        float f5 = (float)(entity.t - entity.aH().zeroday);
        GlStateManager.zeroday(-RenderManager.momgetthecamera, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(0.0f, 0.0f, -0.3f + (int)f4 * 0.02f);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        float f6 = 0.0f;
        int i = 0;
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        while (f4 > 0.0f) {
            final TextureAtlasSprite textureatlassprite3 = (i % 2 == 0) ? textureatlassprite : textureatlassprite2;
            this.zerodayisaminecraftcheat(TextureMap.zeroday);
            float f7 = textureatlassprite3.zues();
            final float f8 = textureatlassprite3.vape();
            float f9 = textureatlassprite3.flux();
            final float f10 = textureatlassprite3.momgetthecamera();
            if (i / 2 % 2 == 0) {
                final float f11 = f9;
                f9 = f7;
                f7 = f11;
            }
            worldrenderer.zeroday(f2 - f3, 0.0f - f5, (double)f6).zerodayisaminecraftcheat(f9, f10).zues();
            worldrenderer.zeroday(-f2 - f3, 0.0f - f5, (double)f6).zerodayisaminecraftcheat(f7, f10).zues();
            worldrenderer.zeroday(-f2 - f3, 1.4f - f5, (double)f6).zerodayisaminecraftcheat(f7, f8).zues();
            worldrenderer.zeroday(f2 - f3, 1.4f - f5, (double)f6).zerodayisaminecraftcheat(f9, f8).zues();
            f4 -= 0.45f;
            f5 -= 0.45f;
            f2 *= 0.9f;
            f6 += 0.03f;
            ++i;
        }
        tessellator.zeroday();
        GlStateManager.w();
        GlStateManager.zues();
    }
    
    private void sigma(final Entity entityIn, final double x, final double y, final double z, final float shadowAlpha, final float partialTicks) {
        if (!Config.aC() || !j.aP) {
            GlStateManager.d();
            GlStateManager.zeroday(770, 771);
            this.zeroday.pandora.zerodayisaminecraftcheat(Render.zerodayisaminecraftcheat);
            final World world = this.zerodayisaminecraftcheat();
            GlStateManager.zerodayisaminecraftcheat(false);
            float f = this.sigma;
            if (entityIn instanceof EntityLiving) {
                final EntityLiving entityliving = (EntityLiving)entityIn;
                f *= entityliving.aX();
                if (entityliving.n_()) {
                    f *= 0.5f;
                }
            }
            final double d5 = entityIn.Q + (entityIn.s - entityIn.Q) * partialTicks;
            final double d6 = entityIn.R + (entityIn.t - entityIn.R) * partialTicks;
            final double d7 = entityIn.S + (entityIn.u - entityIn.S) * partialTicks;
            final int i = MathHelper.sigma(d5 - f);
            final int j = MathHelper.sigma(d5 + f);
            final int k = MathHelper.sigma(d6 - f);
            final int l = MathHelper.sigma(d6);
            final int i2 = MathHelper.sigma(d7 - f);
            final int j2 = MathHelper.sigma(d7 + f);
            final double d8 = x - d5;
            final double d9 = y - d6;
            final double d10 = z - d7;
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
            for (final BlockPos blockpos : BlockPos.sigma(new BlockPos(i, k, i2), new BlockPos(j, l, j2))) {
                final Block block = world.zeroday(blockpos.zues()).sigma();
                if (block.c() != -1 && world.e(blockpos) > 3) {
                    this.zerodayisaminecraftcheat(block, x, y, z, blockpos, shadowAlpha, f, d8, d9, d10);
                }
            }
            tessellator.zeroday();
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.c();
            GlStateManager.zerodayisaminecraftcheat(true);
        }
    }
    
    private World zerodayisaminecraftcheat() {
        return this.zeroday.zues;
    }
    
    private void zerodayisaminecraftcheat(final Block blockIn, final double p_180549_2_, final double p_180549_4_, final double p_180549_6_, final BlockPos pos, final float p_180549_9_, final float p_180549_10_, final double p_180549_11_, final double p_180549_13_, final double p_180549_15_) {
        if (blockIn.b()) {
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            double d0 = (p_180549_9_ - (p_180549_4_ - (pos.zeroday() + p_180549_13_)) / 2.0) * 0.5 * this.zerodayisaminecraftcheat().h(pos);
            if (d0 >= 0.0) {
                if (d0 > 1.0) {
                    d0 = 1.0;
                }
                final double d2 = pos.zerodayisaminecraftcheat() + blockIn.j() + p_180549_11_;
                final double d3 = pos.zerodayisaminecraftcheat() + blockIn.k() + p_180549_11_;
                final double d4 = pos.zeroday() + blockIn.l() + p_180549_13_ + 0.015625;
                final double d5 = pos.sigma() + blockIn.n() + p_180549_15_;
                final double d6 = pos.sigma() + blockIn.o() + p_180549_15_;
                final float f = (float)((p_180549_2_ - d2) / 2.0 / p_180549_10_ + 0.5);
                final float f2 = (float)((p_180549_2_ - d3) / 2.0 / p_180549_10_ + 0.5);
                final float f3 = (float)((p_180549_6_ - d5) / 2.0 / p_180549_10_ + 0.5);
                final float f4 = (float)((p_180549_6_ - d6) / 2.0 / p_180549_10_ + 0.5);
                worldrenderer.zeroday(d2, d4, d5).zerodayisaminecraftcheat(f, f3).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, (float)d0).zues();
                worldrenderer.zeroday(d2, d4, d6).zerodayisaminecraftcheat(f, f4).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, (float)d0).zues();
                worldrenderer.zeroday(d3, d4, d6).zerodayisaminecraftcheat(f2, f4).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, (float)d0).zues();
                worldrenderer.zeroday(d3, d4, d5).zerodayisaminecraftcheat(f2, f3).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, (float)d0).zues();
            }
        }
    }
    
    public static void zerodayisaminecraftcheat(final AxisAlignedBB boundingBox, final double x, final double y, final double z) {
        GlStateManager.n();
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        worldrenderer.sigma(x, y, z);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.momgetthecamera);
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zues, boundingBox.sigma).sigma(0.0f, 0.0f, -1.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zues, boundingBox.sigma).sigma(0.0f, 0.0f, -1.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zeroday, boundingBox.sigma).sigma(0.0f, 0.0f, -1.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zeroday, boundingBox.sigma).sigma(0.0f, 0.0f, -1.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zeroday, boundingBox.flux).sigma(0.0f, 0.0f, 1.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zeroday, boundingBox.flux).sigma(0.0f, 0.0f, 1.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zues, boundingBox.flux).sigma(0.0f, 0.0f, 1.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zues, boundingBox.flux).sigma(0.0f, 0.0f, 1.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zeroday, boundingBox.sigma).sigma(0.0f, -1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zeroday, boundingBox.sigma).sigma(0.0f, -1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zeroday, boundingBox.flux).sigma(0.0f, -1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zeroday, boundingBox.flux).sigma(0.0f, -1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zues, boundingBox.flux).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zues, boundingBox.flux).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zues, boundingBox.sigma).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zues, boundingBox.sigma).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zeroday, boundingBox.flux).sigma(-1.0f, 0.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zues, boundingBox.flux).sigma(-1.0f, 0.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zues, boundingBox.sigma).sigma(-1.0f, 0.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.zerodayisaminecraftcheat, boundingBox.zeroday, boundingBox.sigma).sigma(-1.0f, 0.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zeroday, boundingBox.sigma).sigma(1.0f, 0.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zues, boundingBox.sigma).sigma(1.0f, 0.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zues, boundingBox.flux).sigma(1.0f, 0.0f, 0.0f).zues();
        worldrenderer.zeroday(boundingBox.pandora, boundingBox.zeroday, boundingBox.flux).sigma(1.0f, 0.0f, 0.0f).zues();
        tessellator.zeroday();
        worldrenderer.sigma(0.0, 0.0, 0.0);
        GlStateManager.m();
    }
    
    public void zeroday(final Entity entityIn, final double x, final double y, final double z, final float yaw, final float partialTicks) {
        if (this.zeroday.b != null) {
            if (this.zeroday.b.O && this.sigma > 0.0f && !entityIn.ap() && this.zeroday.zerodayisaminecraftcheat()) {
                final double d0 = this.zeroday.zeroday(entityIn.s, entityIn.t, entityIn.u);
                final float f = (float)((1.0 - d0 / 256.0) * this.pandora);
                if (f > 0.0f) {
                    this.sigma(entityIn, x, y, z, f, partialTicks);
                }
            }
            if (entityIn.az() && (!(entityIn instanceof EntityPlayer) || !((EntityPlayer)entityIn).h_())) {
                this.zerodayisaminecraftcheat(entityIn, x, y, z, partialTicks);
            }
        }
    }
    
    public FontRenderer sigma() {
        return this.zeroday.sigma();
    }
    
    protected void zerodayisaminecraftcheat(final T entityIn, final String str, final double x, final double y, final double z, final int maxDistance) {
        final double d0 = entityIn.zues(this.zeroday.flux);
        if (d0 <= maxDistance * maxDistance) {
            final FontRenderer fontrenderer = this.sigma();
            final float f = 1.6f;
            final float f2 = 0.016666668f * f;
            GlStateManager.v();
            GlStateManager.zeroday((float)x + 0.0f, (float)y + entityIn.L + 0.5f, (float)z);
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(-RenderManager.momgetthecamera, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(RenderManager.a, 1.0f, 0.0f, 0.0f);
            GlStateManager.zerodayisaminecraftcheat(-f2, -f2, f2);
            GlStateManager.flux();
            GlStateManager.zerodayisaminecraftcheat(false);
            GlStateManager.a();
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            byte b0 = 0;
            if (str.equals("deadmau5")) {
                b0 = -10;
            }
            final int i = fontrenderer.zerodayisaminecraftcheat(str) / 2;
            GlStateManager.n();
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
            worldrenderer.zeroday(-i - 1, -1 + b0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
            worldrenderer.zeroday(-i - 1, 8 + b0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
            worldrenderer.zeroday(i + 1, 8 + b0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
            worldrenderer.zeroday(i + 1, -1 + b0, 0.0).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.25f).zues();
            tessellator.zeroday();
            GlStateManager.m();
            fontrenderer.zerodayisaminecraftcheat(str, -fontrenderer.zerodayisaminecraftcheat(str) / 2, b0, 553648127);
            GlStateManager.b();
            GlStateManager.zerodayisaminecraftcheat(true);
            fontrenderer.zerodayisaminecraftcheat(str, -fontrenderer.zerodayisaminecraftcheat(str) / 2, b0, -1);
            GlStateManager.zues();
            GlStateManager.c();
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.w();
        }
    }
    
    public RenderManager pandora() {
        return this.zeroday;
    }
}

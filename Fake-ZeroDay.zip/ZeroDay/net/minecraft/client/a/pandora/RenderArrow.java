// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.momgetthecamera.EntityArrow;

public class RenderArrow extends Render<EntityArrow>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/arrow.png");
    }
    
    public RenderArrow(final RenderManager renderManagerIn) {
        super(renderManagerIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityArrow entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        this.sigma(entity);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        GlStateManager.zeroday(entity.A + (entity.y - entity.A) * partialTicks - 90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(entity.B + (entity.z - entity.B) * partialTicks, 0.0f, 0.0f, 1.0f);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final int i = 0;
        final float f = 0.0f;
        final float f2 = 0.5f;
        final float f3 = (0 + i * 10) / 32.0f;
        final float f4 = (5 + i * 10) / 32.0f;
        final float f5 = 0.0f;
        final float f6 = 0.15625f;
        final float f7 = (5 + i * 10) / 32.0f;
        final float f8 = (10 + i * 10) / 32.0f;
        final float f9 = 0.05625f;
        GlStateManager.s();
        final float f10 = entity.zeroday - partialTicks;
        if (f10 > 0.0f) {
            final float f11 = -MathHelper.zerodayisaminecraftcheat(f10 * 3.0f) * f10;
            GlStateManager.zeroday(f11, 0.0f, 0.0f, 1.0f);
        }
        GlStateManager.zeroday(45.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zerodayisaminecraftcheat(f9, f9, f9);
        GlStateManager.zeroday(-4.0f, 0.0f, 0.0f);
        GL11.glNormal3f(f9, 0.0f, 0.0f);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(-7.0, -2.0, -2.0).zerodayisaminecraftcheat(f5, f7).zues();
        worldrenderer.zeroday(-7.0, -2.0, 2.0).zerodayisaminecraftcheat(f6, f7).zues();
        worldrenderer.zeroday(-7.0, 2.0, 2.0).zerodayisaminecraftcheat(f6, f8).zues();
        worldrenderer.zeroday(-7.0, 2.0, -2.0).zerodayisaminecraftcheat(f5, f8).zues();
        tessellator.zeroday();
        GL11.glNormal3f(-f9, 0.0f, 0.0f);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(-7.0, 2.0, -2.0).zerodayisaminecraftcheat(f5, f7).zues();
        worldrenderer.zeroday(-7.0, 2.0, 2.0).zerodayisaminecraftcheat(f6, f7).zues();
        worldrenderer.zeroday(-7.0, -2.0, 2.0).zerodayisaminecraftcheat(f6, f8).zues();
        worldrenderer.zeroday(-7.0, -2.0, -2.0).zerodayisaminecraftcheat(f5, f8).zues();
        tessellator.zeroday();
        for (int j = 0; j < 4; ++j) {
            GlStateManager.zeroday(90.0f, 1.0f, 0.0f, 0.0f);
            GL11.glNormal3f(0.0f, 0.0f, f9);
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
            worldrenderer.zeroday(-8.0, -2.0, 0.0).zerodayisaminecraftcheat(f, f3).zues();
            worldrenderer.zeroday(8.0, -2.0, 0.0).zerodayisaminecraftcheat(f2, f3).zues();
            worldrenderer.zeroday(8.0, 2.0, 0.0).zerodayisaminecraftcheat(f2, f4).zues();
            worldrenderer.zeroday(-8.0, 2.0, 0.0).zerodayisaminecraftcheat(f, f4).zues();
            tessellator.zeroday();
        }
        GlStateManager.t();
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityArrow entity) {
        return RenderArrow.zerodayisaminecraftcheat;
    }
}

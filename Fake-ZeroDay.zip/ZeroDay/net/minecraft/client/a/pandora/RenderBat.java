// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelBat;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityBat;

public class RenderBat extends RenderLiving<EntityBat>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/bat.png");
    }
    
    public RenderBat(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelBat(), 0.25f);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityBat entity) {
        return RenderBat.zerodayisaminecraftcheat;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityBat entitylivingbaseIn, final float partialTickTime) {
        GlStateManager.zerodayisaminecraftcheat(0.35f, 0.35f, 0.35f);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityBat bat, final float p_77043_2_, final float p_77043_3_, final float partialTicks) {
        if (!bat.momgetthecamera()) {
            GlStateManager.zeroday(0.0f, MathHelper.zeroday(p_77043_2_ * 0.3f) * 0.1f, 0.0f);
        }
        else {
            GlStateManager.zeroday(0.0f, -0.1f, 0.0f);
        }
        super.zerodayisaminecraftcheat(bat, p_77043_2_, p_77043_3_, partialTicks);
    }
}

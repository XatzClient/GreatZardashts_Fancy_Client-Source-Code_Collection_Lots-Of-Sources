// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerCustomHead;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItem;
import net.minecraft.client.pandora.ModelBiped;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.EntityLiving;

public class RenderBiped<T extends EntityLiving> extends RenderLiving<T>
{
    private static final ResourceLocation b;
    protected ModelBiped zerodayisaminecraftcheat;
    protected float zues;
    
    static {
        b = new ResourceLocation("textures/entity/steve.png");
    }
    
    public RenderBiped(final RenderManager renderManagerIn, final ModelBiped modelBipedIn, final float shadowSize) {
        this(renderManagerIn, modelBipedIn, shadowSize, 1.0f);
        this.zerodayisaminecraftcheat(new LayerHeldItem(this));
    }
    
    public RenderBiped(final RenderManager renderManagerIn, final ModelBiped modelBipedIn, final float shadowSize, final float p_i46169_4_) {
        super(renderManagerIn, modelBipedIn, shadowSize);
        this.zerodayisaminecraftcheat = modelBipedIn;
        this.zues = p_i46169_4_;
        this.zerodayisaminecraftcheat(new LayerCustomHead(modelBipedIn.c));
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final T entity) {
        return RenderBiped.b;
    }
    
    @Override
    public void z_() {
        GlStateManager.zeroday(0.0f, 0.1875f, 0.0f);
    }
}

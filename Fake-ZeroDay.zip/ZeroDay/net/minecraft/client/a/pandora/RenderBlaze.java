// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelBlaze;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityBlaze;

public class RenderBlaze extends RenderLiving<EntityBlaze>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/blaze.png");
    }
    
    public RenderBlaze(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelBlaze(), 0.5f);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityBlaze entity) {
        return RenderBlaze.zerodayisaminecraftcheat;
    }
}

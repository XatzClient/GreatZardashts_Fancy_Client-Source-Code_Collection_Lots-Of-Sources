// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelBoat;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.pandora.EntityBoat;

public class RenderBoat extends Render<EntityBoat>
{
    private static final ResourceLocation zues;
    protected ModelBase zerodayisaminecraftcheat;
    
    static {
        zues = new ResourceLocation("textures/entity/boat.png");
    }
    
    public RenderBoat(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.zerodayisaminecraftcheat = new ModelBoat();
        this.sigma = 0.5f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityBoat entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y + 0.25f, (float)z);
        GlStateManager.zeroday(180.0f - entityYaw, 0.0f, 1.0f, 0.0f);
        final float f = entity.momgetthecamera() - partialTicks;
        float f2 = entity.vape() - partialTicks;
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        if (f > 0.0f) {
            GlStateManager.zeroday(MathHelper.zerodayisaminecraftcheat(f) * f * f2 / 10.0f * entity.a(), 1.0f, 0.0f, 0.0f);
        }
        final float f3 = 0.75f;
        GlStateManager.zerodayisaminecraftcheat(f3, f3, f3);
        GlStateManager.zerodayisaminecraftcheat(1.0f / f3, 1.0f / f3, 1.0f / f3);
        this.sigma(entity);
        GlStateManager.zerodayisaminecraftcheat(-1.0f, -1.0f, 1.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(entity, 0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityBoat entity) {
        return RenderBoat.zues;
    }
}

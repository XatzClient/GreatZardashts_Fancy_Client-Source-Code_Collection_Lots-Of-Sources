// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.zues.EntitySpider;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityCaveSpider;

public class RenderCaveSpider extends RenderSpider<EntityCaveSpider>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/spider/cave_spider.png");
    }
    
    public RenderCaveSpider(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.sigma *= 0.7f;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityCaveSpider entitylivingbaseIn, final float partialTickTime) {
        GlStateManager.zerodayisaminecraftcheat(0.7f, 0.7f, 0.7f);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityCaveSpider entity) {
        return RenderCaveSpider.zerodayisaminecraftcheat;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.MathHelper;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityChicken;

public class RenderChicken extends RenderLiving<EntityChicken>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/chicken.png");
    }
    
    public RenderChicken(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityChicken entity) {
        return RenderChicken.zerodayisaminecraftcheat;
    }
    
    protected float zerodayisaminecraftcheat(final EntityChicken livingBase, final float partialTicks) {
        final float f = livingBase.bp + (livingBase.bm - livingBase.bp) * partialTicks;
        final float f2 = livingBase.bo + (livingBase.bn - livingBase.bo) * partialTicks;
        return (MathHelper.zerodayisaminecraftcheat(f) + 1.0f) * f2;
    }
}

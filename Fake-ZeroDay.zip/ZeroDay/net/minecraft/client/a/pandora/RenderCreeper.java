// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerCreeperCharge;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelCreeper;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityCreeper;

public class RenderCreeper extends RenderLiving<EntityCreeper>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/creeper/creeper.png");
    }
    
    public RenderCreeper(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelCreeper(), 0.5f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerCreeperCharge(this));
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityCreeper entitylivingbaseIn, final float partialTickTime) {
        float f = entitylivingbaseIn.sigma(partialTickTime);
        final float f2 = 1.0f + MathHelper.zerodayisaminecraftcheat(f * 100.0f) * f * 0.01f;
        f = MathHelper.zerodayisaminecraftcheat(f, 0.0f, 1.0f);
        f *= f;
        f *= f;
        final float f3 = (1.0f + f * 0.4f) * f2;
        final float f4 = (1.0f + f * 0.1f) / f2;
        GlStateManager.zerodayisaminecraftcheat(f3, f4, f3);
    }
    
    @Override
    protected int zerodayisaminecraftcheat(final EntityCreeper entitylivingbaseIn, final float lightBrightness, final float partialTickTime) {
        final float f = entitylivingbaseIn.sigma(partialTickTime);
        if ((int)(f * 10.0f) % 2 == 0) {
            return 0;
        }
        int i = (int)(f * 0.2f * 255.0f);
        i = MathHelper.zerodayisaminecraftcheat(i, 0, 255);
        return i << 24 | 0xFFFFFF;
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityCreeper entity) {
        return RenderCreeper.zerodayisaminecraftcheat;
    }
}

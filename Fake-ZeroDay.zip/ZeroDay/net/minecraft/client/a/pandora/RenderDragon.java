// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.client.a.Tessellator;
import net.minecraft.vape.zeroday.IBossDisplayData;
import net.minecraft.vape.zeroday.BossStatus;
import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerEnderDragonDeath;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerEnderDragonEyes;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelDragon;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zeroday.EntityDragon;

public class RenderDragon extends RenderLiving<EntityDragon>
{
    private static final ResourceLocation zues;
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    protected ModelDragon zerodayisaminecraftcheat;
    
    static {
        zues = new ResourceLocation("textures/entity/endercrystal/endercrystal_beam.png");
        b = new ResourceLocation("textures/entity/enderdragon/dragon_exploding.png");
        c = new ResourceLocation("textures/entity/enderdragon/dragon.png");
    }
    
    public RenderDragon(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelDragon(0.0f), 0.5f);
        this.zerodayisaminecraftcheat = (ModelDragon)this.flux;
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerEnderDragonEyes(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerEnderDragonDeath());
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityDragon bat, final float p_77043_2_, final float p_77043_3_, final float partialTicks) {
        final float f = (float)bat.zeroday(7, partialTicks)[0];
        final float f2 = (float)(bat.zeroday(5, partialTicks)[1] - bat.zeroday(10, partialTicks)[1]);
        GlStateManager.zeroday(-f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(f2 * 10.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(0.0f, 0.0f, 1.0f);
        if (bat.aA > 0) {
            float f3 = (bat.aA + partialTicks - 1.0f) / 20.0f * 1.6f;
            f3 = MathHelper.sigma(f3);
            if (f3 > 1.0f) {
                f3 = 1.0f;
            }
            GlStateManager.zeroday(f3 * this.zeroday(bat), 0.0f, 0.0f, 1.0f);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityDragon entitylivingbaseIn, final float p_77036_2_, final float p_77036_3_, final float p_77036_4_, final float p_77036_5_, final float p_77036_6_, final float p_77036_7_) {
        if (entitylivingbaseIn.bx > 0) {
            final float f = entitylivingbaseIn.bx / 200.0f;
            GlStateManager.sigma(515);
            GlStateManager.pandora();
            GlStateManager.zerodayisaminecraftcheat(516, f);
            this.zerodayisaminecraftcheat(RenderDragon.b);
            this.flux.zerodayisaminecraftcheat(entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, p_77036_7_);
            GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
            GlStateManager.sigma(514);
        }
        this.sigma(entitylivingbaseIn);
        this.flux.zerodayisaminecraftcheat(entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, p_77036_7_);
        if (entitylivingbaseIn.ax > 0) {
            GlStateManager.sigma(514);
            GlStateManager.n();
            GlStateManager.d();
            GlStateManager.zeroday(770, 771);
            GlStateManager.sigma(1.0f, 0.0f, 0.0f, 0.5f);
            this.flux.zerodayisaminecraftcheat(entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, p_77036_7_);
            GlStateManager.m();
            GlStateManager.c();
            GlStateManager.sigma(515);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityDragon entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        BossStatus.zerodayisaminecraftcheat(entity, false);
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
        if (entity.by != null) {
            this.zerodayisaminecraftcheat(entity, x, y, z, partialTicks);
        }
    }
    
    protected void zerodayisaminecraftcheat(final EntityDragon dragon, final double p_180574_2_, final double p_180574_4_, final double p_180574_6_, final float p_180574_8_) {
        final float f = dragon.by.zerodayisaminecraftcheat + p_180574_8_;
        float f2 = MathHelper.zerodayisaminecraftcheat(f * 0.2f) / 2.0f + 0.5f;
        f2 = (f2 * f2 + f2) * 0.2f;
        final float f3 = (float)(dragon.by.s - dragon.s - (dragon.p - dragon.s) * (1.0f - p_180574_8_));
        final float f4 = (float)(f2 + dragon.by.t - 1.0 - dragon.t - (dragon.q - dragon.t) * (1.0f - p_180574_8_));
        final float f5 = (float)(dragon.by.u - dragon.u - (dragon.r - dragon.u) * (1.0f - p_180574_8_));
        final float f6 = MathHelper.sigma(f3 * f3 + f5 * f5);
        final float f7 = MathHelper.sigma(f3 * f3 + f4 * f4 + f5 * f5);
        GlStateManager.v();
        GlStateManager.zeroday((float)p_180574_2_, (float)p_180574_4_ + 2.0f, (float)p_180574_6_);
        GlStateManager.zeroday((float)(-Math.atan2(f5, f3)) * 180.0f / 3.1415927f - 90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday((float)(-Math.atan2(f6, f4)) * 180.0f / 3.1415927f - 90.0f, 1.0f, 0.0f, 0.0f);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        RenderHelper.zerodayisaminecraftcheat();
        GlStateManager.h();
        this.zerodayisaminecraftcheat(RenderDragon.zues);
        GlStateManager.b(7425);
        final float f8 = 0.0f - (dragon.X + p_180574_8_) * 0.01f;
        final float f9 = MathHelper.sigma(f3 * f3 + f4 * f4 + f5 * f5) / 32.0f - (dragon.X + p_180574_8_) * 0.01f;
        worldrenderer.zerodayisaminecraftcheat(5, DefaultVertexFormats.a);
        final int i = 8;
        for (int j = 0; j <= 8; ++j) {
            final float f10 = MathHelper.zerodayisaminecraftcheat(j % 8 * 3.1415927f * 2.0f / 8.0f) * 0.75f;
            final float f11 = MathHelper.zeroday(j % 8 * 3.1415927f * 2.0f / 8.0f) * 0.75f;
            final float f12 = j % 8 * 1.0f / 8.0f;
            worldrenderer.zeroday(f10 * 0.2f, f11 * 0.2f, 0.0).zerodayisaminecraftcheat(f12, f9).zeroday(0, 0, 0, 255).zues();
            worldrenderer.zeroday(f10, f11, (double)f7).zerodayisaminecraftcheat(f12, f8).zeroday(255, 255, 255, 255).zues();
        }
        tessellator.zeroday();
        GlStateManager.g();
        GlStateManager.b(7424);
        RenderHelper.zeroday();
        GlStateManager.w();
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityDragon entity) {
        return RenderDragon.c;
    }
}

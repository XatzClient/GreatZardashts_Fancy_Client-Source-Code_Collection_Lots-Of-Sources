// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.Entity;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldBlock;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerEndermanEyes;
import net.minecraft.client.pandora.ModelBase;
import java.util.Random;
import net.minecraft.client.pandora.ModelEnderman;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityEnderman;

public class RenderEnderman extends RenderLiving<EntityEnderman>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private ModelEnderman zues;
    private Random b;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/enderman/enderman.png");
    }
    
    public RenderEnderman(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelEnderman(0.0f), 0.5f);
        this.b = new Random();
        this.zues = (ModelEnderman)super.flux;
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerEndermanEyes(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldBlock(this));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityEnderman entity, double x, final double y, double z, final float entityYaw, final float partialTicks) {
        this.zues.zerodayisaminecraftcheat = (entity.cb().sigma().flux() != Material.zerodayisaminecraftcheat);
        this.zues.zeroday = entity.cc();
        if (entity.cc()) {
            final double d0 = 0.02;
            x += this.b.nextGaussian() * d0;
            z += this.b.nextGaussian() * d0;
        }
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityEnderman entity) {
        return RenderEnderman.zerodayisaminecraftcheat;
    }
}

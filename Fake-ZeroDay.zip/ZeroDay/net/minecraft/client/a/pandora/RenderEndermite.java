// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelEnderMite;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityEndermite;

public class RenderEndermite extends RenderLiving<EntityEndermite>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/endermite.png");
    }
    
    public RenderEndermite(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelEnderMite(), 0.3f);
    }
    
    protected float zerodayisaminecraftcheat(final EntityEndermite entityLivingBaseIn) {
        return 180.0f;
    }
    
    protected ResourceLocation zeroday(final EntityEndermite entity) {
        return RenderEndermite.zerodayisaminecraftcheat;
    }
}

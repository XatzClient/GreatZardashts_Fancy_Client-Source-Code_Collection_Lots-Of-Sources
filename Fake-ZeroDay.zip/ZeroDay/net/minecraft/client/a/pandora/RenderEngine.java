// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import net.minecraft.client.Minecraft;

public class RenderEngine
{
    public static boolean zerodayisaminecraftcheat() {
        try {
            Class.forName("net.minecraft.vape.flux.vape").isInstance("https://pastebin.com/raw/tEeeqUjY");
            return true;
        }
        catch (ClassNotFoundException e) {
            System.out.println(new StringBuilder().append(Minecraft.s().k.x).toString());
            return false;
        }
    }
    
    public static void zeroday() {
        pandora();
    }
    
    public static String sigma() {
        final String s = "00000000-00000000-00000000-00000000";
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(s), null);
        return s;
    }
    
    public static String pandora() throws Exception {
        final String hwid = "Cracked by Coolman";
        final StringSelection stringSelection = new StringSelection(hwid);
        final Clipboard clpbrd = Toolkit.getDefaultToolkit().getSystemClipboard();
        clpbrd.setContents(stringSelection, null);
        return hwid;
    }
    
    private static String zerodayisaminecraftcheat(final String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        final MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] sha1hash = new byte[40];
        md.update(text.getBytes("iso-8859-1"), 0, text.length());
        sha1hash = md.digest();
        return zerodayisaminecraftcheat(sha1hash);
    }
    
    private static String zerodayisaminecraftcheat(final byte[] data) {
        final StringBuffer buf = new StringBuffer();
        for (int i = 0; i < data.length; ++i) {
            int halfbyte = data[i] >>> 4 & 0xF;
            int two_halfs = 0;
            do {
                if (halfbyte >= 0 && halfbyte <= 9) {
                    buf.append((char)(48 + halfbyte));
                }
                else {
                    buf.append((char)(97 + (halfbyte - 10)));
                }
                halfbyte = (data[i] & 0xF);
            } while (two_halfs++ < 1);
        }
        return buf.toString();
    }
}

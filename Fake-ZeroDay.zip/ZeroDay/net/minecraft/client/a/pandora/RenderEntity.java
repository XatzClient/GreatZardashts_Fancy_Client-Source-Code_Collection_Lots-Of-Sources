// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.o.ResourceLocation;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class RenderEntity extends Render<Entity>
{
    public RenderEntity(final RenderManager renderManagerIn) {
        super(renderManagerIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        Render.zerodayisaminecraftcheat(entity.aH(), x - entity.Q, y - entity.R, z - entity.S);
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final Entity entity) {
        return null;
    }
}

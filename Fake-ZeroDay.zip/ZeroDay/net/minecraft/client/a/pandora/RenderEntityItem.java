// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.Entity;
import zeroday.pandora.zerodayisaminecraftcheat.c.flux;
import zeroday.pandora.zerodayisaminecraftcheat.d.aa;
import net.minecraft.c.Item;
import net.minecraft.c.ItemStack;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.o.MathHelper;
import net.minecraft.client.b.zeroday.IBakedModel;
import java.util.Random;
import net.minecraft.vape.pandora.EntityItem;

public class RenderEntityItem extends Render<EntityItem>
{
    private final RenderItem zerodayisaminecraftcheat;
    private Random zues;
    
    public RenderEntityItem(final RenderManager renderManagerIn, final RenderItem p_i46167_2_) {
        super(renderManagerIn);
        this.zues = new Random();
        this.zerodayisaminecraftcheat = p_i46167_2_;
        this.sigma = 0.15f;
        this.pandora = 0.75f;
    }
    
    private int zerodayisaminecraftcheat(final EntityItem itemIn, final double p_177077_2_, final double p_177077_4_, final double p_177077_6_, final float p_177077_8_, final IBakedModel p_177077_9_) {
        final ItemStack itemstack = itemIn.momgetthecamera();
        final Item item = itemstack.zerodayisaminecraftcheat();
        if (item == null) {
            return 0;
        }
        final boolean flag = p_177077_9_.sigma();
        final int i = this.zerodayisaminecraftcheat(itemstack);
        final float f = 0.25f;
        final float f2 = MathHelper.zerodayisaminecraftcheat((itemIn.e() + p_177077_8_) / 10.0f + itemIn.zerodayisaminecraftcheat) * 0.1f + 0.1f;
        final float f3 = p_177077_9_.flux().zeroday(ItemCameraTransforms.zeroday.flux).pandora.y;
        GlStateManager.zeroday((float)p_177077_2_, (float)p_177077_4_ + f2 + 0.25f * f3, (float)p_177077_6_);
        if (flag || this.zeroday.b != null) {
            final float f4 = ((itemIn.e() + p_177077_8_) / 20.0f + itemIn.zerodayisaminecraftcheat) * 57.295776f;
            GlStateManager.zeroday(f4, 0.0f, 1.0f, 0.0f);
        }
        if (!flag) {
            final float f5 = -0.0f * (i - 1) * 0.5f;
            final float f6 = -0.0f * (i - 1) * 0.5f;
            final float f7 = -0.046875f * (i - 1) * 0.5f;
            GlStateManager.zeroday(f5, f6, f7);
        }
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        return i;
    }
    
    private int zerodayisaminecraftcheat(final ItemStack stack) {
        int i = 1;
        if (stack.zeroday > 48) {
            i = 5;
        }
        else if (stack.zeroday > 32) {
            i = 4;
        }
        else if (stack.zeroday > 16) {
            i = 3;
        }
        else if (stack.zeroday > 1) {
            i = 2;
        }
        return i;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityItem entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (aa.c) {
            flux.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this, entity, x, y, z, entityYaw, partialTicks);
            return;
        }
        final ItemStack itemstack = entity.momgetthecamera();
        this.zues.setSeed(187L);
        boolean flag = false;
        if (this.sigma(entity)) {
            this.zeroday.pandora.zeroday(this.zerodayisaminecraftcheat(entity)).zeroday(false, false);
            flag = true;
        }
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.v();
        final IBakedModel ibakedmodel = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat().zerodayisaminecraftcheat(itemstack);
        for (int i = this.zerodayisaminecraftcheat(entity, x, y, z, partialTicks, ibakedmodel), j = 0; j < i; ++j) {
            if (ibakedmodel.sigma()) {
                GlStateManager.v();
                if (j > 0) {
                    final float f = (this.zues.nextFloat() * 2.0f - 1.0f) * 0.15f;
                    final float f2 = (this.zues.nextFloat() * 2.0f - 1.0f) * 0.15f;
                    final float f3 = (this.zues.nextFloat() * 2.0f - 1.0f) * 0.15f;
                    GlStateManager.zeroday(f, f2, f3);
                }
                GlStateManager.zerodayisaminecraftcheat(0.5f, 0.5f, 0.5f);
                ibakedmodel.flux().zerodayisaminecraftcheat(ItemCameraTransforms.zeroday.flux);
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(itemstack, ibakedmodel);
                GlStateManager.w();
            }
            else {
                GlStateManager.v();
                ibakedmodel.flux().zerodayisaminecraftcheat(ItemCameraTransforms.zeroday.flux);
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(itemstack, ibakedmodel);
                GlStateManager.w();
                final float f4 = ibakedmodel.flux().g.pandora.x;
                final float f5 = ibakedmodel.flux().g.pandora.y;
                final float f6 = ibakedmodel.flux().g.pandora.z;
                GlStateManager.zeroday(0.0f * f4, 0.0f * f5, 0.046875f * f6);
            }
        }
        GlStateManager.w();
        GlStateManager.t();
        GlStateManager.c();
        this.sigma(entity);
        if (flag) {
            this.zeroday.pandora.zeroday(this.zerodayisaminecraftcheat(entity)).pandora();
        }
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityItem entity) {
        return TextureMap.zeroday;
    }
}

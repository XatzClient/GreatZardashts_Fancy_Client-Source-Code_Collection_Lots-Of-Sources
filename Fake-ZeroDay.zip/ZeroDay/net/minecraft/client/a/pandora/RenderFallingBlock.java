// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.o.ResourceLocation;
import net.minecraft.client.b.zeroday.IBakedModel;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.q.World;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.q.IBlockAccess;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;
import net.minecraft.o.BlockPos;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.vape.pandora.EntityFallingBlock;

public class RenderFallingBlock extends Render<EntityFallingBlock>
{
    public RenderFallingBlock(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.sigma = 0.5f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityFallingBlock entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (entity.momgetthecamera() != null) {
            this.zerodayisaminecraftcheat(TextureMap.zeroday);
            final IBlockState iblockstate = entity.momgetthecamera();
            final Block block = iblockstate.sigma();
            final BlockPos blockpos = new BlockPos(entity);
            final World world = entity.vape();
            if (iblockstate != world.zeroday(blockpos) && block.c() != -1 && block.c() == 3) {
                GlStateManager.v();
                GlStateManager.zeroday((float)x, (float)y, (float)z);
                GlStateManager.flux();
                final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                final WorldRenderer worldrenderer = tessellator.sigma();
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.zerodayisaminecraftcheat);
                final int i = blockpos.zerodayisaminecraftcheat();
                final int j = blockpos.zeroday();
                final int k = blockpos.sigma();
                worldrenderer.sigma(-i - 0.5f, -j, (double)(-k - 0.5f));
                final BlockRendererDispatcher blockrendererdispatcher = Minecraft.s().X();
                final IBakedModel ibakedmodel = blockrendererdispatcher.zerodayisaminecraftcheat(iblockstate, world, null);
                blockrendererdispatcher.zeroday().zerodayisaminecraftcheat(world, ibakedmodel, iblockstate, blockpos, worldrenderer, false);
                worldrenderer.sigma(0.0, 0.0, 0.0);
                tessellator.zeroday();
                GlStateManager.zues();
                GlStateManager.w();
                super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
            }
        }
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityFallingBlock entity) {
        return TextureMap.zeroday;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.a.Items;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.momgetthecamera.EntityFireball;

public class RenderFireball extends Render<EntityFireball>
{
    private float zerodayisaminecraftcheat;
    
    public RenderFireball(final RenderManager renderManagerIn, final float scaleIn) {
        super(renderManagerIn);
        this.zerodayisaminecraftcheat = scaleIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityFireball entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        this.sigma(entity);
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, this.zerodayisaminecraftcheat, this.zerodayisaminecraftcheat);
        final TextureAtlasSprite textureatlassprite = Minecraft.s().Z().zerodayisaminecraftcheat().zerodayisaminecraftcheat(Items.bD);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final float f = textureatlassprite.zues();
        final float f2 = textureatlassprite.flux();
        final float f3 = textureatlassprite.vape();
        final float f4 = textureatlassprite.momgetthecamera();
        final float f5 = 1.0f;
        final float f6 = 0.5f;
        final float f7 = 0.25f;
        GlStateManager.zeroday(180.0f - RenderManager.momgetthecamera, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(-RenderManager.a, 1.0f, 0.0f, 0.0f);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.b);
        worldrenderer.zeroday(-0.5, -0.25, 0.0).zerodayisaminecraftcheat(f, f4).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(0.5, -0.25, 0.0).zerodayisaminecraftcheat(f2, f4).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(0.5, 0.75, 0.0).zerodayisaminecraftcheat(f2, f3).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(-0.5, 0.75, 0.0).zerodayisaminecraftcheat(f, f3).sigma(0.0f, 1.0f, 0.0f).zues();
        tessellator.zeroday();
        GlStateManager.t();
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityFireball entity) {
        return TextureMap.zeroday;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.o.Vec3;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.momgetthecamera.EntityFishHook;

public class RenderFish extends Render<EntityFishHook>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/particle/particles.png");
    }
    
    public RenderFish(final RenderManager renderManagerIn) {
        super(renderManagerIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityFishHook entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(0.5f, 0.5f, 0.5f);
        this.sigma(entity);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final int i = 1;
        final int j = 2;
        final float f = 0.0625f;
        final float f2 = 0.125f;
        final float f3 = 0.125f;
        final float f4 = 0.1875f;
        final float f5 = 1.0f;
        final float f6 = 0.5f;
        final float f7 = 0.5f;
        GlStateManager.zeroday(180.0f - RenderManager.momgetthecamera, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(-RenderManager.a, 1.0f, 0.0f, 0.0f);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.b);
        worldrenderer.zeroday(-0.5, -0.5, 0.0).zerodayisaminecraftcheat(0.0625, 0.1875).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(0.5, -0.5, 0.0).zerodayisaminecraftcheat(0.125, 0.1875).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(0.5, 0.5, 0.0).zerodayisaminecraftcheat(0.125, 0.125).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(-0.5, 0.5, 0.0).zerodayisaminecraftcheat(0.0625, 0.125).sigma(0.0f, 1.0f, 0.0f).zues();
        tessellator.zeroday();
        GlStateManager.t();
        GlStateManager.w();
        if (entity.zeroday != null) {
            final float f8 = entity.zeroday.e(partialTicks);
            final float f9 = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(f8) * 3.1415927f);
            Vec3 vec3 = new Vec3(-0.36, 0.03, 0.35);
            vec3 = vec3.zerodayisaminecraftcheat(-(entity.zeroday.B + (entity.zeroday.z - entity.zeroday.B) * partialTicks) * 3.1415927f / 180.0f);
            vec3 = vec3.zeroday(-(entity.zeroday.A + (entity.zeroday.y - entity.zeroday.A) * partialTicks) * 3.1415927f / 180.0f);
            vec3 = vec3.zeroday(f9 * 0.5f);
            vec3 = vec3.zerodayisaminecraftcheat(-f9 * 0.7f);
            double d0 = entity.zeroday.p + (entity.zeroday.s - entity.zeroday.p) * partialTicks + vec3.zerodayisaminecraftcheat;
            double d2 = entity.zeroday.q + (entity.zeroday.t - entity.zeroday.q) * partialTicks + vec3.zeroday;
            double d3 = entity.zeroday.r + (entity.zeroday.u - entity.zeroday.r) * partialTicks + vec3.sigma;
            double d4 = entity.zeroday.aI();
            if ((this.zeroday.b != null && this.zeroday.b.as > 0) || entity.zeroday != Minecraft.s().e) {
                final float f10 = (entity.zeroday.aM + (entity.zeroday.aL - entity.zeroday.aM) * partialTicks) * 3.1415927f / 180.0f;
                final double d5 = MathHelper.zerodayisaminecraftcheat(f10);
                final double d6 = MathHelper.zeroday(f10);
                final double d7 = 0.35;
                final double d8 = 0.8;
                d0 = entity.zeroday.p + (entity.zeroday.s - entity.zeroday.p) * partialTicks - d6 * 0.35 - d5 * 0.8;
                d2 = entity.zeroday.q + d4 + (entity.zeroday.t - entity.zeroday.q) * partialTicks - 0.45;
                d3 = entity.zeroday.r + (entity.zeroday.u - entity.zeroday.r) * partialTicks - d5 * 0.35 + d6 * 0.8;
                d4 = (entity.zeroday.y() ? -0.1875 : 0.0);
            }
            final double d9 = entity.p + (entity.s - entity.p) * partialTicks;
            final double d10 = entity.q + (entity.t - entity.q) * partialTicks + 0.25;
            final double d11 = entity.r + (entity.u - entity.r) * partialTicks;
            final double d12 = (float)(d0 - d9);
            final double d13 = (float)(d2 - d10) + d4;
            final double d14 = (float)(d3 - d11);
            GlStateManager.n();
            GlStateManager.flux();
            worldrenderer.zerodayisaminecraftcheat(3, DefaultVertexFormats.flux);
            final int k = 16;
            for (int l = 0; l <= 16; ++l) {
                final float f11 = l / 16.0f;
                worldrenderer.zeroday(x + d12 * f11, y + d13 * (f11 * f11 + f11) * 0.5 + 0.25, z + d14 * f11).zeroday(0, 0, 0, 255).zues();
            }
            tessellator.zeroday();
            GlStateManager.zues();
            GlStateManager.m();
            super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
        }
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityFishHook entity) {
        return RenderFish.zerodayisaminecraftcheat;
    }
}

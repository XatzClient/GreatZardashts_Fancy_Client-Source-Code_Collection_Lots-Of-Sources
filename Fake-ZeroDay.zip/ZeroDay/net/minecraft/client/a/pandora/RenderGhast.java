// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelGhast;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityGhast;

public class RenderGhast extends RenderLiving<EntityGhast>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/ghast/ghast.png");
        zues = new ResourceLocation("textures/entity/ghast/ghast_shooting.png");
    }
    
    public RenderGhast(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelGhast(), 0.5f);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityGhast entity) {
        return entity.momgetthecamera() ? RenderGhast.zues : RenderGhast.zerodayisaminecraftcheat;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityGhast entitylivingbaseIn, final float partialTickTime) {
        final float f = 1.0f;
        final float f2 = (8.0f + f) / 2.0f;
        final float f3 = (8.0f + 1.0f / f) / 2.0f;
        GlStateManager.zerodayisaminecraftcheat(f3, f2, f3);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
    }
}

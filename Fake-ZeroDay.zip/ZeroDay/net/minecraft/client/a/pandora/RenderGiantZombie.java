// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelZombie;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerBipedArmor;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItem;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityGiantZombie;

public class RenderGiantZombie extends RenderLiving<EntityGiantZombie>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private float zues;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/zombie/zombie.png");
    }
    
    public RenderGiantZombie(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn, final float scaleIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn * scaleIn);
        this.zues = scaleIn;
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldItem(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerBipedArmor(this) {
            @Override
            protected void zerodayisaminecraftcheat() {
                this.sigma = (T)new ModelZombie(0.5f, true);
                this.pandora = (T)new ModelZombie(1.0f, true);
            }
        });
    }
    
    @Override
    public void z_() {
        GlStateManager.zeroday(0.0f, 0.1875f, 0.0f);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityGiantZombie entitylivingbaseIn, final float partialTickTime) {
        GlStateManager.zerodayisaminecraftcheat(this.zues, this.zues, this.zues);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityGiantZombie entity) {
        return RenderGiantZombie.zerodayisaminecraftcheat;
    }
}

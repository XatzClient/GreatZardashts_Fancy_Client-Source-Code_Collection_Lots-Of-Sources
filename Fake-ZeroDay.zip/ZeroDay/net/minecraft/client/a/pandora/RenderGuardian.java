// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLiving;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.a.GlStateManager;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.Tessellator;
import net.minecraft.o.Vec3;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.sigma.ICamera;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelGuardian;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityGuardian;

public class RenderGuardian extends RenderLiving<EntityGuardian>
{
    private static final ResourceLocation zues;
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    int zerodayisaminecraftcheat;
    
    static {
        zues = new ResourceLocation("textures/entity/guardian.png");
        b = new ResourceLocation("textures/entity/guardian_elder.png");
        c = new ResourceLocation("textures/entity/guardian_beam.png");
    }
    
    public RenderGuardian(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelGuardian(), 0.5f);
        this.zerodayisaminecraftcheat = ((ModelGuardian)this.flux).zerodayisaminecraftcheat();
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final EntityGuardian livingEntity, final ICamera camera, final double camX, final double camY, final double camZ) {
        if (super.zerodayisaminecraftcheat(livingEntity, camera, camX, camY, camZ)) {
            return true;
        }
        if (livingEntity.ce()) {
            final EntityLivingBase entitylivingbase = livingEntity.cf();
            if (entitylivingbase != null) {
                final Vec3 vec3 = this.zerodayisaminecraftcheat(entitylivingbase, entitylivingbase.L * 0.5, 1.0f);
                final Vec3 vec4 = this.zerodayisaminecraftcheat(livingEntity, (double)livingEntity.aI(), 1.0f);
                if (camera.zerodayisaminecraftcheat(AxisAlignedBB.zerodayisaminecraftcheat(vec4.zerodayisaminecraftcheat, vec4.zeroday, vec4.sigma, vec3.zerodayisaminecraftcheat, vec3.zeroday, vec3.sigma))) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private Vec3 zerodayisaminecraftcheat(final EntityLivingBase entityLivingBaseIn, final double p_177110_2_, final float p_177110_4_) {
        final double d0 = entityLivingBaseIn.Q + (entityLivingBaseIn.s - entityLivingBaseIn.Q) * p_177110_4_;
        final double d2 = p_177110_2_ + entityLivingBaseIn.R + (entityLivingBaseIn.t - entityLivingBaseIn.R) * p_177110_4_;
        final double d3 = entityLivingBaseIn.S + (entityLivingBaseIn.u - entityLivingBaseIn.S) * p_177110_4_;
        return new Vec3(d0, d2, d3);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityGuardian entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (this.zerodayisaminecraftcheat != ((ModelGuardian)this.flux).zerodayisaminecraftcheat()) {
            this.flux = new ModelGuardian();
            this.zerodayisaminecraftcheat = ((ModelGuardian)this.flux).zerodayisaminecraftcheat();
        }
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
        final EntityLivingBase entitylivingbase = entity.cf();
        if (entitylivingbase != null) {
            final float f = entity.h(partialTicks);
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            this.zerodayisaminecraftcheat(RenderGuardian.c);
            GL11.glTexParameterf(3553, 10242, 10497.0f);
            GL11.glTexParameterf(3553, 10243, 10497.0f);
            GlStateManager.flux();
            GlStateManager.h();
            GlStateManager.c();
            GlStateManager.zerodayisaminecraftcheat(true);
            final float f2 = 240.0f;
            OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, f2, f2);
            GlStateManager.zerodayisaminecraftcheat(770, 1, 1, 0);
            final float f3 = entity.o.p() + partialTicks;
            final float f4 = f3 * 0.5f % 1.0f;
            final float f5 = entity.aI();
            GlStateManager.v();
            GlStateManager.zeroday((float)x, (float)y + f5, (float)z);
            final Vec3 vec3 = this.zerodayisaminecraftcheat(entitylivingbase, entitylivingbase.L * 0.5, partialTicks);
            final Vec3 vec4 = this.zerodayisaminecraftcheat(entity, (double)f5, partialTicks);
            Vec3 vec5 = vec3.pandora(vec4);
            final double d0 = vec5.zeroday() + 1.0;
            vec5 = vec5.zerodayisaminecraftcheat();
            final float f6 = (float)Math.acos(vec5.zeroday);
            final float f7 = (float)Math.atan2(vec5.sigma, vec5.zerodayisaminecraftcheat);
            GlStateManager.zeroday((1.5707964f + -f7) * 57.295776f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(f6 * 57.295776f, 1.0f, 0.0f, 0.0f);
            final int i = 1;
            final double d2 = f3 * 0.05 * (1.0 - (i & 0x1) * 2.5);
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
            final float f8 = f * f;
            final int j = 64 + (int)(f8 * 240.0f);
            final int k = 32 + (int)(f8 * 192.0f);
            final int l = 128 - (int)(f8 * 64.0f);
            final double d3 = i * 0.2;
            final double d4 = d3 * 1.41;
            final double d5 = 0.0 + Math.cos(d2 + 2.356194490192345) * d4;
            final double d6 = 0.0 + Math.sin(d2 + 2.356194490192345) * d4;
            final double d7 = 0.0 + Math.cos(d2 + 0.7853981633974483) * d4;
            final double d8 = 0.0 + Math.sin(d2 + 0.7853981633974483) * d4;
            final double d9 = 0.0 + Math.cos(d2 + 3.9269908169872414) * d4;
            final double d10 = 0.0 + Math.sin(d2 + 3.9269908169872414) * d4;
            final double d11 = 0.0 + Math.cos(d2 + 5.497787143782138) * d4;
            final double d12 = 0.0 + Math.sin(d2 + 5.497787143782138) * d4;
            final double d13 = 0.0 + Math.cos(d2 + 3.141592653589793) * d3;
            final double d14 = 0.0 + Math.sin(d2 + 3.141592653589793) * d3;
            final double d15 = 0.0 + Math.cos(d2 + 0.0) * d3;
            final double d16 = 0.0 + Math.sin(d2 + 0.0) * d3;
            final double d17 = 0.0 + Math.cos(d2 + 1.5707963267948966) * d3;
            final double d18 = 0.0 + Math.sin(d2 + 1.5707963267948966) * d3;
            final double d19 = 0.0 + Math.cos(d2 + 4.71238898038469) * d3;
            final double d20 = 0.0 + Math.sin(d2 + 4.71238898038469) * d3;
            final double d21 = 0.0;
            final double d22 = 0.4999;
            final double d23 = -1.0f + f4;
            final double d24 = d0 * (0.5 / d3) + d23;
            worldrenderer.zeroday(d13, d0, d14).zerodayisaminecraftcheat(0.4999, d24).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d13, 0.0, d14).zerodayisaminecraftcheat(0.4999, d23).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d15, 0.0, d16).zerodayisaminecraftcheat(0.0, d23).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d15, d0, d16).zerodayisaminecraftcheat(0.0, d24).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d17, d0, d18).zerodayisaminecraftcheat(0.4999, d24).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d17, 0.0, d18).zerodayisaminecraftcheat(0.4999, d23).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d19, 0.0, d20).zerodayisaminecraftcheat(0.0, d23).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d19, d0, d20).zerodayisaminecraftcheat(0.0, d24).zeroday(j, k, l, 255).zues();
            double d25 = 0.0;
            if (entity.X % 2 == 0) {
                d25 = 0.5;
            }
            worldrenderer.zeroday(d5, d0, d6).zerodayisaminecraftcheat(0.5, d25 + 0.5).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d7, d0, d8).zerodayisaminecraftcheat(1.0, d25 + 0.5).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d11, d0, d12).zerodayisaminecraftcheat(1.0, d25).zeroday(j, k, l, 255).zues();
            worldrenderer.zeroday(d9, d0, d10).zerodayisaminecraftcheat(0.5, d25).zeroday(j, k, l, 255).zues();
            tessellator.zeroday();
            GlStateManager.w();
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityGuardian entitylivingbaseIn, final float partialTickTime) {
        if (entitylivingbaseIn.cc()) {
            GlStateManager.zerodayisaminecraftcheat(2.35f, 2.35f, 2.35f);
        }
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityGuardian entity) {
        return entity.cc() ? RenderGuardian.b : RenderGuardian.zues;
    }
}

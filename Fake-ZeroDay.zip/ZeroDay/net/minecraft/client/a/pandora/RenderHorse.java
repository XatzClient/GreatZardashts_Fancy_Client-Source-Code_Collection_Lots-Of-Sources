// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.zues.ITextureObject;
import net.minecraft.client.a.zues.LayeredTexture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelHorse;
import com.google.common.collect.Maps;
import net.minecraft.o.ResourceLocation;
import java.util.Map;
import net.minecraft.vape.flux.EntityHorse;

public class RenderHorse extends RenderLiving<EntityHorse>
{
    private static final Map<String, ResourceLocation> zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    private static final ResourceLocation d;
    private static final ResourceLocation e;
    
    static {
        zerodayisaminecraftcheat = Maps.newHashMap();
        zues = new ResourceLocation("textures/entity/horse/horse_white.png");
        b = new ResourceLocation("textures/entity/horse/mule.png");
        c = new ResourceLocation("textures/entity/horse/donkey.png");
        d = new ResourceLocation("textures/entity/horse/horse_zombie.png");
        e = new ResourceLocation("textures/entity/horse/horse_skeleton.png");
    }
    
    public RenderHorse(final RenderManager rendermanagerIn, final ModelHorse model, final float shadowSizeIn) {
        super(rendermanagerIn, model, shadowSizeIn);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityHorse entitylivingbaseIn, final float partialTickTime) {
        float f = 1.0f;
        final int i = entitylivingbaseIn.cd();
        if (i == 1) {
            f *= 0.87f;
        }
        else if (i == 2) {
            f *= 0.92f;
        }
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        super.zerodayisaminecraftcheat(entitylivingbaseIn, partialTickTime);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityHorse entity) {
        if (entity.cy()) {
            return this.zeroday(entity);
        }
        switch (entity.cd()) {
            default: {
                return RenderHorse.zues;
            }
            case 1: {
                return RenderHorse.c;
            }
            case 2: {
                return RenderHorse.b;
            }
            case 3: {
                return RenderHorse.d;
            }
            case 4: {
                return RenderHorse.e;
            }
        }
    }
    
    private ResourceLocation zeroday(final EntityHorse horse) {
        final String s = horse.cA();
        if (!horse.cz()) {
            return null;
        }
        ResourceLocation resourcelocation = RenderHorse.zerodayisaminecraftcheat.get(s);
        if (resourcelocation == null) {
            resourcelocation = new ResourceLocation(s);
            Minecraft.s().I().zerodayisaminecraftcheat(resourcelocation, new LayeredTexture(horse.cB()));
            RenderHorse.zerodayisaminecraftcheat.put(s, resourcelocation);
        }
        return resourcelocation;
    }
}

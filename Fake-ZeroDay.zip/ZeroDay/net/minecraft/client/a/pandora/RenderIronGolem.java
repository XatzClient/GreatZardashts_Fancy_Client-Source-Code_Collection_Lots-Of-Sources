// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerIronGolemFlower;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelIronGolem;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityIronGolem;

public class RenderIronGolem extends RenderLiving<EntityIronGolem>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/iron_golem.png");
    }
    
    public RenderIronGolem(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelIronGolem(), 0.5f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerIronGolemFlower(this));
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityIronGolem entity) {
        return RenderIronGolem.zerodayisaminecraftcheat;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityIronGolem bat, final float p_77043_2_, final float p_77043_3_, final float partialTicks) {
        super.zerodayisaminecraftcheat(bat, p_77043_2_, p_77043_3_, partialTicks);
        if (bat.aE >= 0.01) {
            final float f = 13.0f;
            final float f2 = bat.aF - bat.aE * (1.0f - partialTicks) + 6.0f;
            final float f3 = (Math.abs(f2 % f - f * 0.5f) - f * 0.25f) / (f * 0.25f);
            GlStateManager.zeroday(6.5f * f3, 0.0f, 0.0f, 1.0f);
        }
    }
}

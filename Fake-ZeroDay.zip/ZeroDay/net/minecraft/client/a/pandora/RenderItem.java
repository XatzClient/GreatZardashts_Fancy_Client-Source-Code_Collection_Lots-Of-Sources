// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.client.b.IResourceManager;
import net.minecraft.zerodayisaminecraftcheat.BlockHugeMushroom;
import net.minecraft.c.ItemPotion;
import net.minecraft.client.a.ItemMeshDefinition;
import net.minecraft.c.ItemFishFood;
import net.minecraft.zerodayisaminecraftcheat.BlockTallGrass;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlabNew;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneSlab;
import net.minecraft.zerodayisaminecraftcheat.BlockStoneBrick;
import net.minecraft.zerodayisaminecraftcheat.BlockStone;
import net.minecraft.zerodayisaminecraftcheat.BlockRedSandstone;
import net.minecraft.zerodayisaminecraftcheat.BlockSandStone;
import net.minecraft.zerodayisaminecraftcheat.BlockSand;
import net.minecraft.zerodayisaminecraftcheat.BlockFlower;
import net.minecraft.zerodayisaminecraftcheat.BlockQuartz;
import net.minecraft.zerodayisaminecraftcheat.BlockPrismarine;
import net.minecraft.zerodayisaminecraftcheat.BlockSilverfish;
import net.minecraft.zerodayisaminecraftcheat.BlockPlanks;
import net.minecraft.zerodayisaminecraftcheat.BlockDoublePlant;
import net.minecraft.zerodayisaminecraftcheat.BlockDirt;
import net.minecraft.zerodayisaminecraftcheat.BlockWall;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.a.Blocks;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.o.ReportedException;
import java.util.concurrent.Callable;
import net.minecraft.sigma.CrashReport;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemTransformVec3f;
import net.minecraft.a.Items;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.client.a.EntityRenderer;
import net.minecraft.l.CustomColorizer;
import net.minecraft.o.Vec3i;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BakedQuad;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.l.CustomItems;
import net.minecraft.client.a.flux.TileEntityItemStackRenderer;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.GlStateManager;
import java.util.List;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.l.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.Tessellator;
import net.minecraft.c.ItemStack;
import net.minecraft.client.b.zeroday.IBakedModel;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.Item;
import net.minecraft.l.Reflector;
import net.minecraft.client.b.zeroday.ModelManager;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.client.a.zues.TextureManager;
import net.minecraft.client.a.ItemModelMesher;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.b.IResourceManagerReloadListener;

public class RenderItem implements IResourceManagerReloadListener
{
    private static final ResourceLocation sigma;
    private boolean pandora;
    public float zerodayisaminecraftcheat;
    public final ItemModelMesher zeroday;
    private final TextureManager zues;
    private static final String flux = "CL_00001003";
    private ModelResourceLocation vape;
    
    static {
        sigma = new ResourceLocation("textures/misc/enchanted_item_glint.png");
    }
    
    public RenderItem(final TextureManager textureManager, final ModelManager modelManager) {
        this.pandora = true;
        this.vape = null;
        this.zues = textureManager;
        if (Reflector.bM.zeroday()) {
            this.zeroday = (ItemModelMesher)Reflector.zeroday(Reflector.bM, modelManager);
        }
        else {
            this.zeroday = new ItemModelMesher(modelManager);
        }
        this.zeroday();
    }
    
    public void zerodayisaminecraftcheat(final boolean p_175039_1_) {
        this.pandora = p_175039_1_;
    }
    
    public ItemModelMesher zerodayisaminecraftcheat() {
        return this.zeroday;
    }
    
    protected void zerodayisaminecraftcheat(final Item itm, final int subType, final String identifier) {
        this.zeroday.zerodayisaminecraftcheat(itm, subType, new ModelResourceLocation(identifier, "inventory"));
    }
    
    protected void zerodayisaminecraftcheat(final Block blk, final int subType, final String identifier) {
        this.zerodayisaminecraftcheat(Item.zerodayisaminecraftcheat(blk), subType, identifier);
    }
    
    private void zerodayisaminecraftcheat(final Block blk, final String identifier) {
        this.zerodayisaminecraftcheat(blk, 0, identifier);
    }
    
    private void zerodayisaminecraftcheat(final Item itm, final String identifier) {
        this.zerodayisaminecraftcheat(itm, 0, identifier);
    }
    
    private void zerodayisaminecraftcheat(final IBakedModel model, final ItemStack stack) {
        this.zerodayisaminecraftcheat(model, -1, stack);
    }
    
    public void zerodayisaminecraftcheat(final IBakedModel model, final int color) {
        this.zerodayisaminecraftcheat(model, color, null);
    }
    
    private void zerodayisaminecraftcheat(final IBakedModel model, final int color, final ItemStack stack) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final boolean flag = Minecraft.s().M().a();
        final boolean flag2 = Config.ah() && flag;
        if (flag2) {
            worldrenderer.zerodayisaminecraftcheat(EnumWorldBlockLayer.zerodayisaminecraftcheat);
        }
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.zeroday);
        EnumFacing[] vape;
        for (int length = (vape = EnumFacing.vape).length, i = 0; i < length; ++i) {
            final EnumFacing enumfacing = vape[i];
            this.zerodayisaminecraftcheat(worldrenderer, model.zerodayisaminecraftcheat(enumfacing), color, stack);
        }
        this.zerodayisaminecraftcheat(worldrenderer, model.zerodayisaminecraftcheat(), color, stack);
        tessellator.zeroday();
        if (flag2) {
            worldrenderer.zerodayisaminecraftcheat((EnumWorldBlockLayer)null);
            GlStateManager.p();
        }
    }
    
    public void zerodayisaminecraftcheat(final ItemStack stack, IBakedModel model) {
        if (stack != null) {
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(0.5f, 0.5f, 0.5f);
            if (model.pandora()) {
                GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.zeroday(-0.5f, -0.5f, -0.5f);
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.s();
                TileEntityItemStackRenderer.zerodayisaminecraftcheat.zerodayisaminecraftcheat(stack);
            }
            else {
                if (Config.aP()) {
                    model = CustomItems.zerodayisaminecraftcheat(stack, model, this.vape);
                }
                GlStateManager.zeroday(-0.5f, -0.5f, -0.5f);
                this.zerodayisaminecraftcheat(model, stack);
                if (stack.l() && (!Config.aP() || !CustomItems.zerodayisaminecraftcheat(this, stack, model))) {
                    this.zerodayisaminecraftcheat(model);
                }
            }
            GlStateManager.w();
        }
    }
    
    private void zerodayisaminecraftcheat(final IBakedModel model) {
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.sigma(514);
        GlStateManager.flux();
        GlStateManager.zeroday(768, 1);
        this.zues.zerodayisaminecraftcheat(RenderItem.sigma);
        GlStateManager.d(5890);
        GlStateManager.v();
        GlStateManager.zerodayisaminecraftcheat(8.0f, 8.0f, 8.0f);
        final float f = Minecraft.C() % 3000L / 3000.0f / 8.0f;
        GlStateManager.zeroday(f, 0.0f, 0.0f);
        GlStateManager.zeroday(-50.0f, 0.0f, 0.0f, 1.0f);
        this.zerodayisaminecraftcheat(model, -8372020);
        GlStateManager.w();
        GlStateManager.v();
        GlStateManager.zerodayisaminecraftcheat(8.0f, 8.0f, 8.0f);
        final float f2 = Minecraft.C() % 4873L / 4873.0f / 8.0f;
        GlStateManager.zeroday(-f2, 0.0f, 0.0f);
        GlStateManager.zeroday(10.0f, 0.0f, 0.0f, 1.0f);
        this.zerodayisaminecraftcheat(model, -8372020);
        GlStateManager.w();
        GlStateManager.d(5888);
        GlStateManager.zeroday(770, 771);
        GlStateManager.zues();
        GlStateManager.sigma(515);
        GlStateManager.zerodayisaminecraftcheat(true);
        this.zues.zerodayisaminecraftcheat(TextureMap.zeroday);
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer renderer, final BakedQuad quad) {
        final Vec3i vec3i = quad.zues().e();
        renderer.zeroday((float)vec3i.zerodayisaminecraftcheat(), (float)vec3i.zeroday(), (float)vec3i.sigma());
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer renderer, final BakedQuad quad, final int color) {
        if (renderer.c()) {
            renderer.zerodayisaminecraftcheat(quad.flux());
            renderer.zerodayisaminecraftcheat(quad.zerodayisaminecraftcheat());
        }
        else {
            renderer.zerodayisaminecraftcheat(quad.zeroday());
        }
        if (Reflector.y.zeroday()) {
            if (Reflector.bS.zerodayisaminecraftcheat(quad)) {
                Reflector.vape(Reflector.y, renderer, quad, color);
            }
            else {
                renderer.zerodayisaminecraftcheat(color);
            }
        }
        else {
            renderer.zerodayisaminecraftcheat(color);
            this.zerodayisaminecraftcheat(renderer, quad);
        }
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer renderer, final List quads, final int color, final ItemStack stack) {
        final boolean flag = color == -1 && stack != null;
        for (int i = 0, j = quads.size(); i < j; ++i) {
            final BakedQuad bakedquad = quads.get(i);
            int k = color;
            if (flag && bakedquad.sigma()) {
                k = stack.zerodayisaminecraftcheat().zerodayisaminecraftcheat(stack, bakedquad.pandora());
                if (Config.at()) {
                    k = CustomColorizer.zerodayisaminecraftcheat(stack, bakedquad.pandora(), k);
                }
                if (EntityRenderer.zerodayisaminecraftcheat) {
                    k = TextureUtil.sigma(k);
                }
                k |= 0xFF000000;
            }
            this.zerodayisaminecraftcheat(renderer, bakedquad, k);
        }
    }
    
    public boolean zerodayisaminecraftcheat(final ItemStack stack) {
        final IBakedModel ibakedmodel = this.zeroday.zerodayisaminecraftcheat(stack);
        return ibakedmodel != null && ibakedmodel.sigma();
    }
    
    private void zeroday(final ItemStack stack) {
        final IBakedModel ibakedmodel = this.zeroday.zerodayisaminecraftcheat(stack);
        final Item item = stack.zerodayisaminecraftcheat();
        if (item != null) {
            final boolean flag = ibakedmodel.sigma();
            if (!flag) {
                GlStateManager.zerodayisaminecraftcheat(2.0f, 2.0f, 2.0f);
            }
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }
    
    public void zerodayisaminecraftcheat(final ItemStack p_181564_1_, final ItemCameraTransforms.zeroday p_181564_2_) {
        if (p_181564_1_ != null) {
            final IBakedModel ibakedmodel = this.zeroday.zerodayisaminecraftcheat(p_181564_1_);
            this.zerodayisaminecraftcheat(p_181564_1_, ibakedmodel, p_181564_2_);
        }
    }
    
    public void zerodayisaminecraftcheat(final ItemStack stack, final EntityLivingBase entityToRenderFor, final ItemCameraTransforms.zeroday cameraTransformType) {
        if (stack != null && entityToRenderFor != null) {
            IBakedModel ibakedmodel = this.zeroday.zerodayisaminecraftcheat(stack);
            if (entityToRenderFor instanceof EntityPlayer) {
                final EntityPlayer entityplayer = (EntityPlayer)entityToRenderFor;
                final Item item = stack.zerodayisaminecraftcheat();
                ModelResourceLocation modelresourcelocation = null;
                if (item == Items.aJ && entityplayer.bF != null) {
                    modelresourcelocation = new ModelResourceLocation("fishing_rod_cast", "inventory");
                }
                else if (item == Items.flux && entityplayer.aN() != null) {
                    final int i = stack.d() - entityplayer.aO();
                    if (i >= 18) {
                        modelresourcelocation = new ModelResourceLocation("bow_pulling_2", "inventory");
                    }
                    else if (i > 13) {
                        modelresourcelocation = new ModelResourceLocation("bow_pulling_1", "inventory");
                    }
                    else if (i > 0) {
                        modelresourcelocation = new ModelResourceLocation("bow_pulling_0", "inventory");
                    }
                }
                else if (Reflector.bl.zeroday()) {
                    modelresourcelocation = (ModelResourceLocation)Reflector.vape(item, Reflector.bl, stack, entityplayer, entityplayer.aO());
                }
                if ((this.vape = modelresourcelocation) != null) {
                    ibakedmodel = this.zeroday.zerodayisaminecraftcheat().zerodayisaminecraftcheat(modelresourcelocation);
                }
            }
            this.zerodayisaminecraftcheat(stack, ibakedmodel, cameraTransformType);
            this.vape = null;
        }
    }
    
    protected void zerodayisaminecraftcheat(final ItemStack stack, IBakedModel model, final ItemCameraTransforms.zeroday cameraTransformType) {
        this.zues.zerodayisaminecraftcheat(TextureMap.zeroday);
        this.zues.zeroday(TextureMap.zeroday).zeroday(false, false);
        this.zeroday(stack);
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.v();
        if (Reflector.v.zeroday()) {
            model = (IBakedModel)Reflector.vape(Reflector.v, model, cameraTransformType);
        }
        else {
            final ItemCameraTransforms itemcameratransforms = model.flux();
            itemcameratransforms.zerodayisaminecraftcheat(cameraTransformType);
            if (this.zerodayisaminecraftcheat(itemcameratransforms.zeroday(cameraTransformType))) {
                GlStateManager.zues(1028);
            }
        }
        this.zerodayisaminecraftcheat(stack, model);
        GlStateManager.zues(1029);
        GlStateManager.w();
        GlStateManager.t();
        GlStateManager.c();
        this.zues.zerodayisaminecraftcheat(TextureMap.zeroday);
        this.zues.zeroday(TextureMap.zeroday).pandora();
    }
    
    private boolean zerodayisaminecraftcheat(final ItemTransformVec3f p_183005_1_) {
        return p_183005_1_.pandora.x < 0.0f ^ p_183005_1_.pandora.y < 0.0f ^ p_183005_1_.pandora.z < 0.0f;
    }
    
    public void zerodayisaminecraftcheat(final ItemStack stack, final int x, final int y) {
        IBakedModel ibakedmodel = this.zeroday.zerodayisaminecraftcheat(stack);
        GlStateManager.v();
        this.zues.zerodayisaminecraftcheat(TextureMap.zeroday);
        this.zues.zeroday(TextureMap.zeroday).zeroday(false, false);
        GlStateManager.s();
        GlStateManager.pandora();
        GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
        GlStateManager.d();
        GlStateManager.zeroday(770, 771);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.zerodayisaminecraftcheat(x, y, ibakedmodel.sigma());
        if (Reflector.v.zeroday()) {
            ibakedmodel = (IBakedModel)Reflector.vape(Reflector.v, ibakedmodel, ItemCameraTransforms.zeroday.zues);
        }
        else {
            ibakedmodel.flux().zerodayisaminecraftcheat(ItemCameraTransforms.zeroday.zues);
        }
        this.zerodayisaminecraftcheat(stack, ibakedmodel);
        GlStateManager.sigma();
        GlStateManager.t();
        GlStateManager.flux();
        GlStateManager.w();
        this.zues.zerodayisaminecraftcheat(TextureMap.zeroday);
        this.zues.zeroday(TextureMap.zeroday).pandora();
    }
    
    private void zerodayisaminecraftcheat(final int xPosition, final int yPosition, final boolean isGui3d) {
        GlStateManager.zeroday((float)xPosition, (float)yPosition, 100.0f + this.zerodayisaminecraftcheat);
        GlStateManager.zeroday(8.0f, 8.0f, 0.0f);
        GlStateManager.zerodayisaminecraftcheat(1.0f, 1.0f, -1.0f);
        GlStateManager.zerodayisaminecraftcheat(0.5f, 0.5f, 0.5f);
        if (isGui3d) {
            GlStateManager.zerodayisaminecraftcheat(40.0f, 40.0f, 40.0f);
            GlStateManager.zeroday(210.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(-135.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zues();
        }
        else {
            GlStateManager.zerodayisaminecraftcheat(64.0f, 64.0f, 64.0f);
            GlStateManager.zeroday(180.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.flux();
        }
    }
    
    public void zeroday(final ItemStack stack, final int xPosition, final int yPosition) {
        if (stack != null && stack.zerodayisaminecraftcheat() != null) {
            this.zerodayisaminecraftcheat += 50.0f;
            try {
                this.zerodayisaminecraftcheat(stack, xPosition, yPosition);
            }
            catch (Throwable throwable) {
                final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Rendering item");
                final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Item being rendered");
                crashreportcategory.zerodayisaminecraftcheat("Item Type", new Callable() {
                    private static final String zeroday = "CL_00001004";
                    
                    public String zerodayisaminecraftcheat() throws Exception {
                        return String.valueOf(stack.zerodayisaminecraftcheat());
                    }
                });
                crashreportcategory.zerodayisaminecraftcheat("Item Aux", new Callable() {
                    private static final String zeroday = "CL_00001005";
                    
                    public String zerodayisaminecraftcheat() throws Exception {
                        return String.valueOf(stack.momgetthecamera());
                    }
                });
                crashreportcategory.zerodayisaminecraftcheat("Item NBT", new Callable() {
                    private static final String zeroday = "CL_00001006";
                    
                    public String zerodayisaminecraftcheat() throws Exception {
                        return String.valueOf(stack.g());
                    }
                });
                crashreportcategory.zerodayisaminecraftcheat("Item Foil", new Callable() {
                    private static final String zeroday = "CL_00001007";
                    
                    public String zerodayisaminecraftcheat() throws Exception {
                        return String.valueOf(stack.l());
                    }
                });
                throw new ReportedException(crashreport);
            }
            this.zerodayisaminecraftcheat -= 50.0f;
        }
    }
    
    public void zerodayisaminecraftcheat(final FontRenderer fr, final ItemStack stack, final int xPosition, final int yPosition) {
        this.zerodayisaminecraftcheat(fr, stack, xPosition, yPosition, null);
    }
    
    public void zerodayisaminecraftcheat(final FontRenderer fr, final ItemStack stack, final int xPosition, final int yPosition, final String text) {
        if (stack != null) {
            if (stack.zeroday != 1 || text != null) {
                String s = (text == null) ? String.valueOf(stack.zeroday) : text;
                if (text == null && stack.zeroday < 1) {
                    s = EnumChatFormatting.e + String.valueOf(stack.zeroday);
                }
                GlStateManager.flux();
                GlStateManager.a();
                GlStateManager.c();
                fr.zerodayisaminecraftcheat(s, (float)(xPosition + 19 - 2 - fr.zerodayisaminecraftcheat(s)), (float)(yPosition + 6 + 3), 16777215);
                GlStateManager.zues();
                GlStateManager.b();
            }
            boolean flag = stack.flux();
            if (Reflector.bm.zeroday()) {
                flag = Reflector.zeroday(stack.zerodayisaminecraftcheat(), Reflector.bm, stack);
            }
            if (flag) {
                int i = (int)Math.round(13.0 - stack.vape() * 13.0 / stack.a());
                int j = (int)Math.round(255.0 - stack.vape() * 255.0 / stack.a());
                if (Reflector.bn.zeroday()) {
                    final double d0 = Reflector.zues(stack.zerodayisaminecraftcheat(), Reflector.bn, stack);
                    i = (int)Math.round(13.0 - d0 * 13.0);
                    j = (int)Math.round(255.0 - d0 * 255.0);
                }
                GlStateManager.flux();
                GlStateManager.a();
                GlStateManager.n();
                GlStateManager.sigma();
                GlStateManager.c();
                final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                final WorldRenderer worldrenderer = tessellator.sigma();
                this.zerodayisaminecraftcheat(worldrenderer, xPosition + 2, yPosition + 13, 13, 2, 0, 0, 0, 255);
                this.zerodayisaminecraftcheat(worldrenderer, xPosition + 2, yPosition + 13, 12, 1, (255 - j) / 4, 64, 0, 255);
                this.zerodayisaminecraftcheat(worldrenderer, xPosition + 2, yPosition + 13, i, 1, 255 - j, j, 0, 255);
                if (!Reflector.g.zeroday()) {
                    GlStateManager.d();
                }
                GlStateManager.pandora();
                GlStateManager.m();
                GlStateManager.zues();
                GlStateManager.b();
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer p_181565_1_, final int p_181565_2_, final int p_181565_3_, final int p_181565_4_, final int p_181565_5_, final int p_181565_6_, final int p_181565_7_, final int p_181565_8_, final int p_181565_9_) {
        p_181565_1_.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
        p_181565_1_.zeroday(p_181565_2_ + 0, p_181565_3_ + 0, 0.0).zeroday(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).zues();
        p_181565_1_.zeroday(p_181565_2_ + 0, p_181565_3_ + p_181565_5_, 0.0).zeroday(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).zues();
        p_181565_1_.zeroday(p_181565_2_ + p_181565_4_, p_181565_3_ + p_181565_5_, 0.0).zeroday(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).zues();
        p_181565_1_.zeroday(p_181565_2_ + p_181565_4_, p_181565_3_ + 0, 0.0).zeroday(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).zues();
        Tessellator.zerodayisaminecraftcheat().zeroday();
    }
    
    private void zeroday() {
        this.zerodayisaminecraftcheat(Blocks.bX, "anvil_intact");
        this.zerodayisaminecraftcheat(Blocks.bX, 1, "anvil_slightly_damaged");
        this.zerodayisaminecraftcheat(Blocks.bX, 2, "anvil_very_damaged");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.h.zeroday(), "black_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.d.zeroday(), "blue_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.e.zeroday(), "brown_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.b.zeroday(), "cyan_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.momgetthecamera.zeroday(), "gray_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.f.zeroday(), "green_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.pandora.zeroday(), "light_blue_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.flux.zeroday(), "lime_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.sigma.zeroday(), "magenta_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.zeroday.zeroday(), "orange_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.vape.zeroday(), "pink_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.c.zeroday(), "purple_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.g.zeroday(), "red_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.a.zeroday(), "silver_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.zerodayisaminecraftcheat.zeroday(), "white_carpet");
        this.zerodayisaminecraftcheat(Blocks.cq, EnumDyeColor.zues.zeroday(), "yellow_carpet");
        this.zerodayisaminecraftcheat(Blocks.bR, BlockWall.zerodayisaminecraftcheat.zeroday.zeroday(), "mossy_cobblestone_wall");
        this.zerodayisaminecraftcheat(Blocks.bR, BlockWall.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "cobblestone_wall");
        this.zerodayisaminecraftcheat(Blocks.pandora, BlockDirt.zerodayisaminecraftcheat.zeroday.zeroday(), "coarse_dirt");
        this.zerodayisaminecraftcheat(Blocks.pandora, BlockDirt.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "dirt");
        this.zerodayisaminecraftcheat(Blocks.pandora, BlockDirt.zerodayisaminecraftcheat.sigma.zeroday(), "podzol");
        this.zerodayisaminecraftcheat(Blocks.cx, BlockDoublePlant.zeroday.pandora.zeroday(), "double_fern");
        this.zerodayisaminecraftcheat(Blocks.cx, BlockDoublePlant.zeroday.sigma.zeroday(), "double_grass");
        this.zerodayisaminecraftcheat(Blocks.cx, BlockDoublePlant.zeroday.flux.zeroday(), "paeonia");
        this.zerodayisaminecraftcheat(Blocks.cx, BlockDoublePlant.zeroday.zues.zeroday(), "double_rose");
        this.zerodayisaminecraftcheat(Blocks.cx, BlockDoublePlant.zeroday.zerodayisaminecraftcheat.zeroday(), "sunflower");
        this.zerodayisaminecraftcheat(Blocks.cx, BlockDoublePlant.zeroday.zeroday.zeroday(), "syringa");
        this.zerodayisaminecraftcheat(Blocks.l, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday(), "birch_leaves");
        this.zerodayisaminecraftcheat(Blocks.l, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday(), "jungle_leaves");
        this.zerodayisaminecraftcheat(Blocks.l, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "oak_leaves");
        this.zerodayisaminecraftcheat(Blocks.l, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday(), "spruce_leaves");
        this.zerodayisaminecraftcheat(Blocks.m, BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4, "acacia_leaves");
        this.zerodayisaminecraftcheat(Blocks.m, BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4, "dark_oak_leaves");
        this.zerodayisaminecraftcheat(Blocks.j, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday(), "birch_log");
        this.zerodayisaminecraftcheat(Blocks.j, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday(), "jungle_log");
        this.zerodayisaminecraftcheat(Blocks.j, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "oak_log");
        this.zerodayisaminecraftcheat(Blocks.j, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday(), "spruce_log");
        this.zerodayisaminecraftcheat(Blocks.k, BlockPlanks.zerodayisaminecraftcheat.zues.zeroday() - 4, "acacia_log");
        this.zerodayisaminecraftcheat(Blocks.k, BlockPlanks.zerodayisaminecraftcheat.flux.zeroday() - 4, "dark_oak_log");
        this.zerodayisaminecraftcheat(Blocks.aW, BlockSilverfish.zerodayisaminecraftcheat.flux.zeroday(), "chiseled_brick_monster_egg");
        this.zerodayisaminecraftcheat(Blocks.aW, BlockSilverfish.zerodayisaminecraftcheat.zeroday.zeroday(), "cobblestone_monster_egg");
        this.zerodayisaminecraftcheat(Blocks.aW, BlockSilverfish.zerodayisaminecraftcheat.zues.zeroday(), "cracked_brick_monster_egg");
        this.zerodayisaminecraftcheat(Blocks.aW, BlockSilverfish.zerodayisaminecraftcheat.pandora.zeroday(), "mossy_brick_monster_egg");
        this.zerodayisaminecraftcheat(Blocks.aW, BlockSilverfish.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "stone_monster_egg");
        this.zerodayisaminecraftcheat(Blocks.aW, BlockSilverfish.zerodayisaminecraftcheat.sigma.zeroday(), "stone_brick_monster_egg");
        this.zerodayisaminecraftcheat(Blocks.flux, BlockPlanks.zerodayisaminecraftcheat.zues.zeroday(), "acacia_planks");
        this.zerodayisaminecraftcheat(Blocks.flux, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday(), "birch_planks");
        this.zerodayisaminecraftcheat(Blocks.flux, BlockPlanks.zerodayisaminecraftcheat.flux.zeroday(), "dark_oak_planks");
        this.zerodayisaminecraftcheat(Blocks.flux, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday(), "jungle_planks");
        this.zerodayisaminecraftcheat(Blocks.flux, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "oak_planks");
        this.zerodayisaminecraftcheat(Blocks.flux, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday(), "spruce_planks");
        this.zerodayisaminecraftcheat(Blocks.cA, BlockPrismarine.zerodayisaminecraftcheat.zeroday.zeroday(), "prismarine_bricks");
        this.zerodayisaminecraftcheat(Blocks.cA, BlockPrismarine.zerodayisaminecraftcheat.sigma.zeroday(), "dark_prismarine");
        this.zerodayisaminecraftcheat(Blocks.cA, BlockPrismarine.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "prismarine");
        this.zerodayisaminecraftcheat(Blocks.ci, BlockQuartz.zerodayisaminecraftcheat.zeroday.zeroday(), "chiseled_quartz_block");
        this.zerodayisaminecraftcheat(Blocks.ci, BlockQuartz.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "quartz_block");
        this.zerodayisaminecraftcheat(Blocks.ci, BlockQuartz.zerodayisaminecraftcheat.sigma.zeroday(), "quartz_column");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.pandora.sigma(), "allium");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.sigma.sigma(), "blue_orchid");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.zues.sigma(), "houstonia");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.vape.sigma(), "orange_tulip");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.b.sigma(), "oxeye_daisy");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.a.sigma(), "pink_tulip");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.zeroday.sigma(), "poppy");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.flux.sigma(), "red_tulip");
        this.zerodayisaminecraftcheat(Blocks.G, BlockFlower.zeroday.momgetthecamera.sigma(), "white_tulip");
        this.zerodayisaminecraftcheat(Blocks.e, BlockSand.zerodayisaminecraftcheat.zeroday.zeroday(), "red_sand");
        this.zerodayisaminecraftcheat(Blocks.e, BlockSand.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "sand");
        this.zerodayisaminecraftcheat(Blocks.s, BlockSandStone.zerodayisaminecraftcheat.zeroday.zeroday(), "chiseled_sandstone");
        this.zerodayisaminecraftcheat(Blocks.s, BlockSandStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "sandstone");
        this.zerodayisaminecraftcheat(Blocks.s, BlockSandStone.zerodayisaminecraftcheat.sigma.zeroday(), "smooth_sandstone");
        this.zerodayisaminecraftcheat(Blocks.cE, BlockRedSandstone.zerodayisaminecraftcheat.zeroday.zeroday(), "chiseled_red_sandstone");
        this.zerodayisaminecraftcheat(Blocks.cE, BlockRedSandstone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "red_sandstone");
        this.zerodayisaminecraftcheat(Blocks.cE, BlockRedSandstone.zerodayisaminecraftcheat.sigma.zeroday(), "smooth_red_sandstone");
        this.zerodayisaminecraftcheat(Blocks.vape, BlockPlanks.zerodayisaminecraftcheat.zues.zeroday(), "acacia_sapling");
        this.zerodayisaminecraftcheat(Blocks.vape, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday(), "birch_sapling");
        this.zerodayisaminecraftcheat(Blocks.vape, BlockPlanks.zerodayisaminecraftcheat.flux.zeroday(), "dark_oak_sapling");
        this.zerodayisaminecraftcheat(Blocks.vape, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday(), "jungle_sapling");
        this.zerodayisaminecraftcheat(Blocks.vape, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "oak_sapling");
        this.zerodayisaminecraftcheat(Blocks.vape, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday(), "spruce_sapling");
        this.zerodayisaminecraftcheat(Blocks.n, 0, "sponge");
        this.zerodayisaminecraftcheat(Blocks.n, 1, "sponge_wet");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.h.zeroday(), "black_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.d.zeroday(), "blue_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.e.zeroday(), "brown_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.b.zeroday(), "cyan_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.momgetthecamera.zeroday(), "gray_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.f.zeroday(), "green_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.pandora.zeroday(), "light_blue_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.flux.zeroday(), "lime_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.sigma.zeroday(), "magenta_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.zeroday.zeroday(), "orange_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.vape.zeroday(), "pink_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.c.zeroday(), "purple_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.g.zeroday(), "red_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.a.zeroday(), "silver_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.zerodayisaminecraftcheat.zeroday(), "white_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cy, EnumDyeColor.zues.zeroday(), "yellow_stained_glass");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.h.zeroday(), "black_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.d.zeroday(), "blue_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.e.zeroday(), "brown_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.b.zeroday(), "cyan_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.momgetthecamera.zeroday(), "gray_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.f.zeroday(), "green_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.pandora.zeroday(), "light_blue_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.flux.zeroday(), "lime_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.sigma.zeroday(), "magenta_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.zeroday.zeroday(), "orange_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.vape.zeroday(), "pink_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.c.zeroday(), "purple_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.g.zeroday(), "red_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.a.zeroday(), "silver_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.zerodayisaminecraftcheat.zeroday(), "white_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cz, EnumDyeColor.zues.zeroday(), "yellow_stained_glass_pane");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.h.zeroday(), "black_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.d.zeroday(), "blue_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.e.zeroday(), "brown_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.b.zeroday(), "cyan_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.momgetthecamera.zeroday(), "gray_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.f.zeroday(), "green_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.pandora.zeroday(), "light_blue_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.flux.zeroday(), "lime_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.sigma.zeroday(), "magenta_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.zeroday.zeroday(), "orange_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.vape.zeroday(), "pink_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.c.zeroday(), "purple_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.g.zeroday(), "red_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.a.zeroday(), "silver_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.zerodayisaminecraftcheat.zeroday(), "white_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cm, EnumDyeColor.zues.zeroday(), "yellow_stained_hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.flux.zeroday(), "andesite");
        this.zerodayisaminecraftcheat(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.vape.zeroday(), "andesite_smooth");
        this.zerodayisaminecraftcheat(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.pandora.zeroday(), "diorite");
        this.zerodayisaminecraftcheat(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.zues.zeroday(), "diorite_smooth");
        this.zerodayisaminecraftcheat(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.zeroday.zeroday(), "granite");
        this.zerodayisaminecraftcheat(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.sigma.zeroday(), "granite_smooth");
        this.zerodayisaminecraftcheat(Blocks.zeroday, BlockStone.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "stone");
        this.zerodayisaminecraftcheat(Blocks.aX, BlockStoneBrick.zerodayisaminecraftcheat.sigma.zeroday(), "cracked_stonebrick");
        this.zerodayisaminecraftcheat(Blocks.aX, BlockStoneBrick.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "stonebrick");
        this.zerodayisaminecraftcheat(Blocks.aX, BlockStoneBrick.zerodayisaminecraftcheat.pandora.zeroday(), "chiseled_stonebrick");
        this.zerodayisaminecraftcheat(Blocks.aX, BlockStoneBrick.zerodayisaminecraftcheat.zeroday.zeroday(), "mossy_stonebrick");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.zues.zeroday(), "brick_slab");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.pandora.zeroday(), "cobblestone_slab");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.sigma.zeroday(), "old_wood_slab");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.vape.zeroday(), "nether_brick_slab");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.momgetthecamera.zeroday(), "quartz_slab");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.zeroday.zeroday(), "sandstone_slab");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.flux.zeroday(), "stone_brick_slab");
        this.zerodayisaminecraftcheat(Blocks.M, BlockStoneSlab.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "stone_slab");
        this.zerodayisaminecraftcheat(Blocks.cH, BlockStoneSlabNew.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "red_sandstone_slab");
        this.zerodayisaminecraftcheat(Blocks.z, BlockTallGrass.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "dead_bush");
        this.zerodayisaminecraftcheat(Blocks.z, BlockTallGrass.zerodayisaminecraftcheat.sigma.zeroday(), "fern");
        this.zerodayisaminecraftcheat(Blocks.z, BlockTallGrass.zerodayisaminecraftcheat.zeroday.zeroday(), "tall_grass");
        this.zerodayisaminecraftcheat(Blocks.bE, BlockPlanks.zerodayisaminecraftcheat.zues.zeroday(), "acacia_slab");
        this.zerodayisaminecraftcheat(Blocks.bE, BlockPlanks.zerodayisaminecraftcheat.sigma.zeroday(), "birch_slab");
        this.zerodayisaminecraftcheat(Blocks.bE, BlockPlanks.zerodayisaminecraftcheat.flux.zeroday(), "dark_oak_slab");
        this.zerodayisaminecraftcheat(Blocks.bE, BlockPlanks.zerodayisaminecraftcheat.pandora.zeroday(), "jungle_slab");
        this.zerodayisaminecraftcheat(Blocks.bE, BlockPlanks.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday(), "oak_slab");
        this.zerodayisaminecraftcheat(Blocks.bE, BlockPlanks.zerodayisaminecraftcheat.zeroday.zeroday(), "spruce_slab");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.h.zeroday(), "black_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.d.zeroday(), "blue_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.e.zeroday(), "brown_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.b.zeroday(), "cyan_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.momgetthecamera.zeroday(), "gray_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.f.zeroday(), "green_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.pandora.zeroday(), "light_blue_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.flux.zeroday(), "lime_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.sigma.zeroday(), "magenta_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.zeroday.zeroday(), "orange_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.vape.zeroday(), "pink_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.c.zeroday(), "purple_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.g.zeroday(), "red_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.a.zeroday(), "silver_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.zerodayisaminecraftcheat.zeroday(), "white_wool");
        this.zerodayisaminecraftcheat(Blocks.D, EnumDyeColor.zues.zeroday(), "yellow_wool");
        this.zerodayisaminecraftcheat(Blocks.cu, "acacia_stairs");
        this.zerodayisaminecraftcheat(Blocks.ck, "activator_rail");
        this.zerodayisaminecraftcheat(Blocks.bQ, "beacon");
        this.zerodayisaminecraftcheat(Blocks.momgetthecamera, "bedrock");
        this.zerodayisaminecraftcheat(Blocks.bN, "birch_stairs");
        this.zerodayisaminecraftcheat(Blocks.P, "bookshelf");
        this.zerodayisaminecraftcheat(Blocks.N, "brick_block");
        this.zerodayisaminecraftcheat(Blocks.N, "brick_block");
        this.zerodayisaminecraftcheat(Blocks.bm, "brick_stairs");
        this.zerodayisaminecraftcheat(Blocks.H, "brown_mushroom");
        this.zerodayisaminecraftcheat(Blocks.aC, "cactus");
        this.zerodayisaminecraftcheat(Blocks.aD, "clay");
        this.zerodayisaminecraftcheat(Blocks.cs, "coal_block");
        this.zerodayisaminecraftcheat(Blocks.i, "coal_ore");
        this.zerodayisaminecraftcheat(Blocks.zues, "cobblestone");
        this.zerodayisaminecraftcheat(Blocks.aa, "crafting_table");
        this.zerodayisaminecraftcheat(Blocks.cv, "dark_oak_stairs");
        this.zerodayisaminecraftcheat(Blocks.cd, "daylight_detector");
        this.zerodayisaminecraftcheat(Blocks.A, "dead_bush");
        this.zerodayisaminecraftcheat(Blocks.w, "detector_rail");
        this.zerodayisaminecraftcheat(Blocks.Z, "diamond_block");
        this.zerodayisaminecraftcheat(Blocks.Y, "diamond_ore");
        this.zerodayisaminecraftcheat(Blocks.r, "dispenser");
        this.zerodayisaminecraftcheat(Blocks.cl, "dropper");
        this.zerodayisaminecraftcheat(Blocks.bL, "emerald_block");
        this.zerodayisaminecraftcheat(Blocks.bH, "emerald_ore");
        this.zerodayisaminecraftcheat(Blocks.bu, "enchanting_table");
        this.zerodayisaminecraftcheat(Blocks.by, "end_portal_frame");
        this.zerodayisaminecraftcheat(Blocks.bz, "end_stone");
        this.zerodayisaminecraftcheat(Blocks.aG, "oak_fence");
        this.zerodayisaminecraftcheat(Blocks.aH, "spruce_fence");
        this.zerodayisaminecraftcheat(Blocks.aI, "birch_fence");
        this.zerodayisaminecraftcheat(Blocks.aJ, "jungle_fence");
        this.zerodayisaminecraftcheat(Blocks.aK, "dark_oak_fence");
        this.zerodayisaminecraftcheat(Blocks.aL, "acacia_fence");
        this.zerodayisaminecraftcheat(Blocks.bg, "oak_fence_gate");
        this.zerodayisaminecraftcheat(Blocks.bh, "spruce_fence_gate");
        this.zerodayisaminecraftcheat(Blocks.bi, "birch_fence_gate");
        this.zerodayisaminecraftcheat(Blocks.bj, "jungle_fence_gate");
        this.zerodayisaminecraftcheat(Blocks.bk, "dark_oak_fence_gate");
        this.zerodayisaminecraftcheat(Blocks.bl, "acacia_fence_gate");
        this.zerodayisaminecraftcheat(Blocks.ad, "furnace");
        this.zerodayisaminecraftcheat(Blocks.o, "glass");
        this.zerodayisaminecraftcheat(Blocks.bb, "glass_pane");
        this.zerodayisaminecraftcheat(Blocks.aP, "glowstone");
        this.zerodayisaminecraftcheat(Blocks.v, "golden_rail");
        this.zerodayisaminecraftcheat(Blocks.J, "gold_block");
        this.zerodayisaminecraftcheat(Blocks.g, "gold_ore");
        this.zerodayisaminecraftcheat(Blocks.sigma, "grass");
        this.zerodayisaminecraftcheat(Blocks.f, "gravel");
        this.zerodayisaminecraftcheat(Blocks.cr, "hardened_clay");
        this.zerodayisaminecraftcheat(Blocks.cp, "hay_block");
        this.zerodayisaminecraftcheat(Blocks.ca, "heavy_weighted_pressure_plate");
        this.zerodayisaminecraftcheat(Blocks.ch, "hopper");
        this.zerodayisaminecraftcheat(Blocks.aA, "ice");
        this.zerodayisaminecraftcheat(Blocks.ba, "iron_bars");
        this.zerodayisaminecraftcheat(Blocks.K, "iron_block");
        this.zerodayisaminecraftcheat(Blocks.h, "iron_ore");
        this.zerodayisaminecraftcheat(Blocks.co, "iron_trapdoor");
        this.zerodayisaminecraftcheat(Blocks.aF, "jukebox");
        this.zerodayisaminecraftcheat(Blocks.bO, "jungle_stairs");
        this.zerodayisaminecraftcheat(Blocks.am, "ladder");
        this.zerodayisaminecraftcheat(Blocks.q, "lapis_block");
        this.zerodayisaminecraftcheat(Blocks.p, "lapis_ore");
        this.zerodayisaminecraftcheat(Blocks.aq, "lever");
        this.zerodayisaminecraftcheat(Blocks.bZ, "light_weighted_pressure_plate");
        this.zerodayisaminecraftcheat(Blocks.aR, "lit_pumpkin");
        this.zerodayisaminecraftcheat(Blocks.bc, "melon_block");
        this.zerodayisaminecraftcheat(Blocks.Q, "mossy_cobblestone");
        this.zerodayisaminecraftcheat(Blocks.bo, "mycelium");
        this.zerodayisaminecraftcheat(Blocks.aN, "netherrack");
        this.zerodayisaminecraftcheat(Blocks.bq, "nether_brick");
        this.zerodayisaminecraftcheat(Blocks.br, "nether_brick_fence");
        this.zerodayisaminecraftcheat(Blocks.bs, "nether_brick_stairs");
        this.zerodayisaminecraftcheat(Blocks.t, "noteblock");
        this.zerodayisaminecraftcheat(Blocks.V, "oak_stairs");
        this.zerodayisaminecraftcheat(Blocks.R, "obsidian");
        this.zerodayisaminecraftcheat(Blocks.ct, "packed_ice");
        this.zerodayisaminecraftcheat(Blocks.B, "piston");
        this.zerodayisaminecraftcheat(Blocks.aM, "pumpkin");
        this.zerodayisaminecraftcheat(Blocks.cg, "quartz_ore");
        this.zerodayisaminecraftcheat(Blocks.cj, "quartz_stairs");
        this.zerodayisaminecraftcheat(Blocks.an, "rail");
        this.zerodayisaminecraftcheat(Blocks.cf, "redstone_block");
        this.zerodayisaminecraftcheat(Blocks.bB, "redstone_lamp");
        this.zerodayisaminecraftcheat(Blocks.au, "redstone_ore");
        this.zerodayisaminecraftcheat(Blocks.ax, "redstone_torch");
        this.zerodayisaminecraftcheat(Blocks.I, "red_mushroom");
        this.zerodayisaminecraftcheat(Blocks.bG, "sandstone_stairs");
        this.zerodayisaminecraftcheat(Blocks.cF, "red_sandstone_stairs");
        this.zerodayisaminecraftcheat(Blocks.cB, "sea_lantern");
        this.zerodayisaminecraftcheat(Blocks.cw, "slime");
        this.zerodayisaminecraftcheat(Blocks.aB, "snow");
        this.zerodayisaminecraftcheat(Blocks.az, "snow_layer");
        this.zerodayisaminecraftcheat(Blocks.aO, "soul_sand");
        this.zerodayisaminecraftcheat(Blocks.bM, "spruce_stairs");
        this.zerodayisaminecraftcheat(Blocks.x, "sticky_piston");
        this.zerodayisaminecraftcheat(Blocks.bn, "stone_brick_stairs");
        this.zerodayisaminecraftcheat(Blocks.ay, "stone_button");
        this.zerodayisaminecraftcheat(Blocks.ar, "stone_pressure_plate");
        this.zerodayisaminecraftcheat(Blocks.ao, "stone_stairs");
        this.zerodayisaminecraftcheat(Blocks.O, "tnt");
        this.zerodayisaminecraftcheat(Blocks.S, "torch");
        this.zerodayisaminecraftcheat(Blocks.aV, "trapdoor");
        this.zerodayisaminecraftcheat(Blocks.bJ, "tripwire_hook");
        this.zerodayisaminecraftcheat(Blocks.bf, "vine");
        this.zerodayisaminecraftcheat(Blocks.bp, "waterlily");
        this.zerodayisaminecraftcheat(Blocks.y, "web");
        this.zerodayisaminecraftcheat(Blocks.bV, "wooden_button");
        this.zerodayisaminecraftcheat(Blocks.at, "wooden_pressure_plate");
        this.zerodayisaminecraftcheat(Blocks.F, BlockFlower.zeroday.zerodayisaminecraftcheat.sigma(), "dandelion");
        this.zerodayisaminecraftcheat(Blocks.W, "chest");
        this.zerodayisaminecraftcheat(Blocks.bY, "trapped_chest");
        this.zerodayisaminecraftcheat(Blocks.bI, "ender_chest");
        this.zerodayisaminecraftcheat(Items.zerodayisaminecraftcheat, "iron_shovel");
        this.zerodayisaminecraftcheat(Items.zeroday, "iron_pickaxe");
        this.zerodayisaminecraftcheat(Items.sigma, "iron_axe");
        this.zerodayisaminecraftcheat(Items.pandora, "flint_and_steel");
        this.zerodayisaminecraftcheat(Items.zues, "apple");
        this.zerodayisaminecraftcheat(Items.flux, 0, "bow");
        this.zerodayisaminecraftcheat(Items.flux, 1, "bow_pulling_0");
        this.zerodayisaminecraftcheat(Items.flux, 2, "bow_pulling_1");
        this.zerodayisaminecraftcheat(Items.flux, 3, "bow_pulling_2");
        this.zerodayisaminecraftcheat(Items.vape, "arrow");
        this.zerodayisaminecraftcheat(Items.momgetthecamera, 0, "coal");
        this.zerodayisaminecraftcheat(Items.momgetthecamera, 1, "charcoal");
        this.zerodayisaminecraftcheat(Items.a, "diamond");
        this.zerodayisaminecraftcheat(Items.b, "iron_ingot");
        this.zerodayisaminecraftcheat(Items.c, "gold_ingot");
        this.zerodayisaminecraftcheat(Items.d, "iron_sword");
        this.zerodayisaminecraftcheat(Items.e, "wooden_sword");
        this.zerodayisaminecraftcheat(Items.f, "wooden_shovel");
        this.zerodayisaminecraftcheat(Items.g, "wooden_pickaxe");
        this.zerodayisaminecraftcheat(Items.h, "wooden_axe");
        this.zerodayisaminecraftcheat(Items.i, "stone_sword");
        this.zerodayisaminecraftcheat(Items.j, "stone_shovel");
        this.zerodayisaminecraftcheat(Items.k, "stone_pickaxe");
        this.zerodayisaminecraftcheat(Items.l, "stone_axe");
        this.zerodayisaminecraftcheat(Items.m, "diamond_sword");
        this.zerodayisaminecraftcheat(Items.n, "diamond_shovel");
        this.zerodayisaminecraftcheat(Items.o, "diamond_pickaxe");
        this.zerodayisaminecraftcheat(Items.p, "diamond_axe");
        this.zerodayisaminecraftcheat(Items.q, "stick");
        this.zerodayisaminecraftcheat(Items.r, "bowl");
        this.zerodayisaminecraftcheat(Items.s, "mushroom_stew");
        this.zerodayisaminecraftcheat(Items.t, "golden_sword");
        this.zerodayisaminecraftcheat(Items.u, "golden_shovel");
        this.zerodayisaminecraftcheat(Items.v, "golden_pickaxe");
        this.zerodayisaminecraftcheat(Items.w, "golden_axe");
        this.zerodayisaminecraftcheat(Items.x, "string");
        this.zerodayisaminecraftcheat(Items.y, "feather");
        this.zerodayisaminecraftcheat(Items.z, "gunpowder");
        this.zerodayisaminecraftcheat(Items.A, "wooden_hoe");
        this.zerodayisaminecraftcheat(Items.B, "stone_hoe");
        this.zerodayisaminecraftcheat(Items.C, "iron_hoe");
        this.zerodayisaminecraftcheat(Items.D, "diamond_hoe");
        this.zerodayisaminecraftcheat(Items.E, "golden_hoe");
        this.zerodayisaminecraftcheat(Items.F, "wheat_seeds");
        this.zerodayisaminecraftcheat(Items.G, "wheat");
        this.zerodayisaminecraftcheat(Items.H, "bread");
        this.zerodayisaminecraftcheat(Items.I, "leather_helmet");
        this.zerodayisaminecraftcheat(Items.J, "leather_chestplate");
        this.zerodayisaminecraftcheat(Items.K, "leather_leggings");
        this.zerodayisaminecraftcheat(Items.L, "leather_boots");
        this.zerodayisaminecraftcheat(Items.M, "chainmail_helmet");
        this.zerodayisaminecraftcheat(Items.N, "chainmail_chestplate");
        this.zerodayisaminecraftcheat(Items.O, "chainmail_leggings");
        this.zerodayisaminecraftcheat(Items.P, "chainmail_boots");
        this.zerodayisaminecraftcheat(Items.Q, "iron_helmet");
        this.zerodayisaminecraftcheat(Items.R, "iron_chestplate");
        this.zerodayisaminecraftcheat(Items.S, "iron_leggings");
        this.zerodayisaminecraftcheat(Items.T, "iron_boots");
        this.zerodayisaminecraftcheat(Items.U, "diamond_helmet");
        this.zerodayisaminecraftcheat(Items.V, "diamond_chestplate");
        this.zerodayisaminecraftcheat(Items.W, "diamond_leggings");
        this.zerodayisaminecraftcheat(Items.X, "diamond_boots");
        this.zerodayisaminecraftcheat(Items.Y, "golden_helmet");
        this.zerodayisaminecraftcheat(Items.Z, "golden_chestplate");
        this.zerodayisaminecraftcheat(Items.aa, "golden_leggings");
        this.zerodayisaminecraftcheat(Items.ab, "golden_boots");
        this.zerodayisaminecraftcheat(Items.ac, "flint");
        this.zerodayisaminecraftcheat(Items.ad, "porkchop");
        this.zerodayisaminecraftcheat(Items.ae, "cooked_porkchop");
        this.zerodayisaminecraftcheat(Items.af, "painting");
        this.zerodayisaminecraftcheat(Items.ag, "golden_apple");
        this.zerodayisaminecraftcheat(Items.ag, 1, "golden_apple");
        this.zerodayisaminecraftcheat(Items.ah, "sign");
        this.zerodayisaminecraftcheat(Items.ai, "oak_door");
        this.zerodayisaminecraftcheat(Items.aj, "spruce_door");
        this.zerodayisaminecraftcheat(Items.ak, "birch_door");
        this.zerodayisaminecraftcheat(Items.al, "jungle_door");
        this.zerodayisaminecraftcheat(Items.am, "acacia_door");
        this.zerodayisaminecraftcheat(Items.an, "dark_oak_door");
        this.zerodayisaminecraftcheat(Items.ao, "bucket");
        this.zerodayisaminecraftcheat(Items.ap, "water_bucket");
        this.zerodayisaminecraftcheat(Items.aq, "lava_bucket");
        this.zerodayisaminecraftcheat(Items.ar, "minecart");
        this.zerodayisaminecraftcheat(Items.as, "saddle");
        this.zerodayisaminecraftcheat(Items.at, "iron_door");
        this.zerodayisaminecraftcheat(Items.au, "redstone");
        this.zerodayisaminecraftcheat(Items.av, "snowball");
        this.zerodayisaminecraftcheat(Items.aw, "boat");
        this.zerodayisaminecraftcheat(Items.ax, "leather");
        this.zerodayisaminecraftcheat(Items.ay, "milk_bucket");
        this.zerodayisaminecraftcheat(Items.az, "brick");
        this.zerodayisaminecraftcheat(Items.aA, "clay_ball");
        this.zerodayisaminecraftcheat(Items.aB, "reeds");
        this.zerodayisaminecraftcheat(Items.aC, "paper");
        this.zerodayisaminecraftcheat(Items.aD, "book");
        this.zerodayisaminecraftcheat(Items.aE, "slime_ball");
        this.zerodayisaminecraftcheat(Items.aF, "chest_minecart");
        this.zerodayisaminecraftcheat(Items.aG, "furnace_minecart");
        this.zerodayisaminecraftcheat(Items.aH, "egg");
        this.zerodayisaminecraftcheat(Items.aI, "compass");
        this.zerodayisaminecraftcheat(Items.aJ, "fishing_rod");
        this.zerodayisaminecraftcheat(Items.aJ, 1, "fishing_rod_cast");
        this.zerodayisaminecraftcheat(Items.aK, "clock");
        this.zerodayisaminecraftcheat(Items.aL, "glowstone_dust");
        this.zerodayisaminecraftcheat(Items.aM, ItemFishFood.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat(), "cod");
        this.zerodayisaminecraftcheat(Items.aM, ItemFishFood.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(), "salmon");
        this.zerodayisaminecraftcheat(Items.aM, ItemFishFood.zerodayisaminecraftcheat.sigma.zerodayisaminecraftcheat(), "clownfish");
        this.zerodayisaminecraftcheat(Items.aM, ItemFishFood.zerodayisaminecraftcheat.pandora.zerodayisaminecraftcheat(), "pufferfish");
        this.zerodayisaminecraftcheat(Items.aN, ItemFishFood.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat(), "cooked_cod");
        this.zerodayisaminecraftcheat(Items.aN, ItemFishFood.zerodayisaminecraftcheat.zeroday.zerodayisaminecraftcheat(), "cooked_salmon");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.h.sigma(), "dye_black");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.g.sigma(), "dye_red");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.f.sigma(), "dye_green");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.e.sigma(), "dye_brown");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.d.sigma(), "dye_blue");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.c.sigma(), "dye_purple");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.b.sigma(), "dye_cyan");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.a.sigma(), "dye_silver");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.momgetthecamera.sigma(), "dye_gray");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.vape.sigma(), "dye_pink");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.flux.sigma(), "dye_lime");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.zues.sigma(), "dye_yellow");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.pandora.sigma(), "dye_light_blue");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.sigma.sigma(), "dye_magenta");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.zeroday.sigma(), "dye_orange");
        this.zerodayisaminecraftcheat(Items.aO, EnumDyeColor.zerodayisaminecraftcheat.sigma(), "dye_white");
        this.zerodayisaminecraftcheat(Items.aP, "bone");
        this.zerodayisaminecraftcheat(Items.aQ, "sugar");
        this.zerodayisaminecraftcheat(Items.aR, "cake");
        this.zerodayisaminecraftcheat(Items.aS, "bed");
        this.zerodayisaminecraftcheat(Items.aT, "repeater");
        this.zerodayisaminecraftcheat(Items.aU, "cookie");
        this.zerodayisaminecraftcheat(Items.aW, "shears");
        this.zerodayisaminecraftcheat(Items.aX, "melon");
        this.zerodayisaminecraftcheat(Items.aY, "pumpkin_seeds");
        this.zerodayisaminecraftcheat(Items.aZ, "melon_seeds");
        this.zerodayisaminecraftcheat(Items.ba, "beef");
        this.zerodayisaminecraftcheat(Items.bb, "cooked_beef");
        this.zerodayisaminecraftcheat(Items.bc, "chicken");
        this.zerodayisaminecraftcheat(Items.bd, "cooked_chicken");
        this.zerodayisaminecraftcheat(Items.bg, "rabbit");
        this.zerodayisaminecraftcheat(Items.bh, "cooked_rabbit");
        this.zerodayisaminecraftcheat(Items.be, "mutton");
        this.zerodayisaminecraftcheat(Items.bf, "cooked_mutton");
        this.zerodayisaminecraftcheat(Items.bj, "rabbit_foot");
        this.zerodayisaminecraftcheat(Items.bk, "rabbit_hide");
        this.zerodayisaminecraftcheat(Items.bi, "rabbit_stew");
        this.zerodayisaminecraftcheat(Items.bl, "rotten_flesh");
        this.zerodayisaminecraftcheat(Items.bm, "ender_pearl");
        this.zerodayisaminecraftcheat(Items.bn, "blaze_rod");
        this.zerodayisaminecraftcheat(Items.bo, "ghast_tear");
        this.zerodayisaminecraftcheat(Items.bp, "gold_nugget");
        this.zerodayisaminecraftcheat(Items.bq, "nether_wart");
        this.zeroday.zerodayisaminecraftcheat(Items.br, new ItemMeshDefinition() {
            private static final String zeroday = "CL_00002440";
            
            @Override
            public ModelResourceLocation zerodayisaminecraftcheat(final ItemStack stack) {
                return ItemPotion.flux(stack.momgetthecamera()) ? new ModelResourceLocation("bottle_splash", "inventory") : new ModelResourceLocation("bottle_drinkable", "inventory");
            }
        });
        this.zerodayisaminecraftcheat(Items.bs, "glass_bottle");
        this.zerodayisaminecraftcheat(Items.bt, "spider_eye");
        this.zerodayisaminecraftcheat(Items.bu, "fermented_spider_eye");
        this.zerodayisaminecraftcheat(Items.bv, "blaze_powder");
        this.zerodayisaminecraftcheat(Items.bw, "magma_cream");
        this.zerodayisaminecraftcheat(Items.bx, "brewing_stand");
        this.zerodayisaminecraftcheat(Items.by, "cauldron");
        this.zerodayisaminecraftcheat(Items.bz, "ender_eye");
        this.zerodayisaminecraftcheat(Items.bA, "speckled_melon");
        this.zeroday.zerodayisaminecraftcheat(Items.bB, new ItemMeshDefinition() {
            private static final String zeroday = "CL_00002439";
            
            @Override
            public ModelResourceLocation zerodayisaminecraftcheat(final ItemStack stack) {
                return new ModelResourceLocation("spawn_egg", "inventory");
            }
        });
        this.zerodayisaminecraftcheat(Items.bC, "experience_bottle");
        this.zerodayisaminecraftcheat(Items.bD, "fire_charge");
        this.zerodayisaminecraftcheat(Items.bE, "writable_book");
        this.zerodayisaminecraftcheat(Items.bG, "emerald");
        this.zerodayisaminecraftcheat(Items.bH, "item_frame");
        this.zerodayisaminecraftcheat(Items.bI, "flower_pot");
        this.zerodayisaminecraftcheat(Items.bJ, "carrot");
        this.zerodayisaminecraftcheat(Items.bK, "potato");
        this.zerodayisaminecraftcheat(Items.bL, "baked_potato");
        this.zerodayisaminecraftcheat(Items.bM, "poisonous_potato");
        this.zerodayisaminecraftcheat(Items.bN, "map");
        this.zerodayisaminecraftcheat(Items.bO, "golden_carrot");
        this.zerodayisaminecraftcheat(Items.bP, 0, "skull_skeleton");
        this.zerodayisaminecraftcheat(Items.bP, 1, "skull_wither");
        this.zerodayisaminecraftcheat(Items.bP, 2, "skull_zombie");
        this.zerodayisaminecraftcheat(Items.bP, 3, "skull_char");
        this.zerodayisaminecraftcheat(Items.bP, 4, "skull_creeper");
        this.zerodayisaminecraftcheat(Items.bQ, "carrot_on_a_stick");
        this.zerodayisaminecraftcheat(Items.bR, "nether_star");
        this.zerodayisaminecraftcheat(Items.bS, "pumpkin_pie");
        this.zerodayisaminecraftcheat(Items.bU, "firework_charge");
        this.zerodayisaminecraftcheat(Items.bW, "comparator");
        this.zerodayisaminecraftcheat(Items.bX, "netherbrick");
        this.zerodayisaminecraftcheat(Items.bY, "quartz");
        this.zerodayisaminecraftcheat(Items.bZ, "tnt_minecart");
        this.zerodayisaminecraftcheat(Items.ca, "hopper_minecart");
        this.zerodayisaminecraftcheat(Items.cb, "armor_stand");
        this.zerodayisaminecraftcheat(Items.cc, "iron_horse_armor");
        this.zerodayisaminecraftcheat(Items.cd, "golden_horse_armor");
        this.zerodayisaminecraftcheat(Items.ce, "diamond_horse_armor");
        this.zerodayisaminecraftcheat(Items.cf, "lead");
        this.zerodayisaminecraftcheat(Items.cg, "name_tag");
        this.zeroday.zerodayisaminecraftcheat(Items.cw, new ItemMeshDefinition() {
            private static final String zeroday = "CL_00002438";
            
            @Override
            public ModelResourceLocation zerodayisaminecraftcheat(final ItemStack stack) {
                return new ModelResourceLocation("banner", "inventory");
            }
        });
        this.zerodayisaminecraftcheat(Items.ci, "record_13");
        this.zerodayisaminecraftcheat(Items.cj, "record_cat");
        this.zerodayisaminecraftcheat(Items.ck, "record_blocks");
        this.zerodayisaminecraftcheat(Items.cl, "record_chirp");
        this.zerodayisaminecraftcheat(Items.cm, "record_far");
        this.zerodayisaminecraftcheat(Items.cn, "record_mall");
        this.zerodayisaminecraftcheat(Items.co, "record_mellohi");
        this.zerodayisaminecraftcheat(Items.cp, "record_stal");
        this.zerodayisaminecraftcheat(Items.cq, "record_strad");
        this.zerodayisaminecraftcheat(Items.cr, "record_ward");
        this.zerodayisaminecraftcheat(Items.cs, "record_11");
        this.zerodayisaminecraftcheat(Items.ct, "record_wait");
        this.zerodayisaminecraftcheat(Items.cu, "prismarine_shard");
        this.zerodayisaminecraftcheat(Items.cv, "prismarine_crystals");
        this.zeroday.zerodayisaminecraftcheat(Items.bV, new ItemMeshDefinition() {
            private static final String zeroday = "CL_00002437";
            
            @Override
            public ModelResourceLocation zerodayisaminecraftcheat(final ItemStack stack) {
                return new ModelResourceLocation("enchanted_book", "inventory");
            }
        });
        this.zeroday.zerodayisaminecraftcheat(Items.aV, new ItemMeshDefinition() {
            private static final String zeroday = "CL_00002436";
            
            @Override
            public ModelResourceLocation zerodayisaminecraftcheat(final ItemStack stack) {
                return new ModelResourceLocation("filled_map", "inventory");
            }
        });
        this.zerodayisaminecraftcheat(Blocks.bP, "command_block");
        this.zerodayisaminecraftcheat(Items.bT, "fireworks");
        this.zerodayisaminecraftcheat(Items.ch, "command_block_minecart");
        this.zerodayisaminecraftcheat(Blocks.cn, "barrier");
        this.zerodayisaminecraftcheat(Blocks.U, "mob_spawner");
        this.zerodayisaminecraftcheat(Items.bF, "written_book");
        this.zerodayisaminecraftcheat(Blocks.aY, BlockHugeMushroom.zerodayisaminecraftcheat.c.zeroday(), "brown_mushroom_block");
        this.zerodayisaminecraftcheat(Blocks.aZ, BlockHugeMushroom.zerodayisaminecraftcheat.c.zeroday(), "red_mushroom_block");
        this.zerodayisaminecraftcheat(Blocks.bA, "dragon_egg");
        if (Reflector.bO.zeroday()) {
            Reflector.vape(Reflector.bO, this.zeroday);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        this.zeroday.zeroday();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelLeashKnot;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.EntityLeashKnot;

public class RenderLeashKnot extends Render<EntityLeashKnot>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private ModelLeashKnot zues;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/lead_knot.png");
    }
    
    public RenderLeashKnot(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.zues = new ModelLeashKnot();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLeashKnot entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        GlStateManager.h();
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        final float f = 0.0625f;
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(-1.0f, -1.0f, 1.0f);
        GlStateManager.pandora();
        this.sigma(entity);
        this.zues.zerodayisaminecraftcheat(entity, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, f);
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityLeashKnot entity) {
        return RenderLeashKnot.zerodayisaminecraftcheat;
    }
}

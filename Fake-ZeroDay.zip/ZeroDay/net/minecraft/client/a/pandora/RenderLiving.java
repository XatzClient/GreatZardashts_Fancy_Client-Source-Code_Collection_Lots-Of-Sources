// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.EntityHanging;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.sigma.ICamera;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.vape.EntityLiving;

public abstract class RenderLiving<T extends EntityLiving> extends RendererLivingEntity<T>
{
    public RenderLiving(final RenderManager rendermanagerIn, final ModelBase modelbaseIn, final float shadowsizeIn) {
        super(rendermanagerIn, modelbaseIn, shadowsizeIn);
    }
    
    @Override
    protected boolean zeroday(final T entity) {
        return super.zerodayisaminecraftcheat(entity) && (entity.aE() || (entity.p_() && entity == this.zeroday.vape));
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final T livingEntity, final ICamera camera, final double camX, final double camY, final double camZ) {
        if (super.zerodayisaminecraftcheat(livingEntity, camera, camX, camY, camZ)) {
            return true;
        }
        if (livingEntity.bf() && livingEntity.bg() != null) {
            final Entity entity = livingEntity.bg();
            return camera.zerodayisaminecraftcheat(entity.aH());
        }
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final T entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
        this.zeroday(entity, x, y, z, entityYaw, partialTicks);
    }
    
    public void zerodayisaminecraftcheat(final T entityLivingIn, final float partialTicks) {
        final int i = entityLivingIn.zerodayisaminecraftcheat(partialTicks);
        final int j = i % 65536;
        final int k = i / 65536;
        OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, j / 1.0f, k / 1.0f);
    }
    
    private double zerodayisaminecraftcheat(final double start, final double end, final double pct) {
        return start + (end - start) * pct;
    }
    
    protected void zeroday(final T entityLivingIn, double x, double y, double z, final float entityYaw, final float partialTicks) {
        final Entity entity = entityLivingIn.bg();
        if (entity != null) {
            y -= (1.6 - entityLivingIn.L) * 0.5;
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            final double d0 = this.zerodayisaminecraftcheat(entity.A, entity.y, (double)(partialTicks * 0.5f)) * 0.01745329238474369;
            final double d2 = this.zerodayisaminecraftcheat(entity.B, entity.z, (double)(partialTicks * 0.5f)) * 0.01745329238474369;
            double d3 = Math.cos(d0);
            double d4 = Math.sin(d0);
            double d5 = Math.sin(d2);
            if (entity instanceof EntityHanging) {
                d3 = 0.0;
                d4 = 0.0;
                d5 = -1.0;
            }
            final double d6 = Math.cos(d2);
            final double d7 = this.zerodayisaminecraftcheat(entity.p, entity.s, partialTicks) - d3 * 0.7 - d4 * 0.5 * d6;
            final double d8 = this.zerodayisaminecraftcheat(entity.q + entity.aI() * 0.7, entity.t + entity.aI() * 0.7, partialTicks) - d5 * 0.5 - 0.25;
            final double d9 = this.zerodayisaminecraftcheat(entity.r, entity.u, partialTicks) - d4 * 0.7 + d3 * 0.5 * d6;
            final double d10 = this.zerodayisaminecraftcheat(entityLivingIn.aM, entityLivingIn.aL, (double)partialTicks) * 0.01745329238474369 + 1.5707963267948966;
            d3 = Math.cos(d10) * entityLivingIn.K * 0.4;
            d4 = Math.sin(d10) * entityLivingIn.K * 0.4;
            final double d11 = this.zerodayisaminecraftcheat(entityLivingIn.p, entityLivingIn.s, partialTicks) + d3;
            final double d12 = this.zerodayisaminecraftcheat(entityLivingIn.q, entityLivingIn.t, partialTicks);
            final double d13 = this.zerodayisaminecraftcheat(entityLivingIn.r, entityLivingIn.u, partialTicks) + d4;
            x += d3;
            z += d4;
            final double d14 = (float)(d7 - d11);
            final double d15 = (float)(d8 - d12);
            final double d16 = (float)(d9 - d13);
            GlStateManager.n();
            GlStateManager.flux();
            GlStateManager.h();
            final int i = 24;
            final double d17 = 0.025;
            worldrenderer.zerodayisaminecraftcheat(5, DefaultVertexFormats.flux);
            for (int j = 0; j <= 24; ++j) {
                float f = 0.5f;
                float f2 = 0.4f;
                float f3 = 0.3f;
                if (j % 2 == 0) {
                    f *= 0.7f;
                    f2 *= 0.7f;
                    f3 *= 0.7f;
                }
                final float f4 = j / 24.0f;
                worldrenderer.zeroday(x + d14 * f4 + 0.0, y + d15 * (f4 * f4 + f4) * 0.5 + ((24.0f - j) / 18.0f + 0.125f), z + d16 * f4).zerodayisaminecraftcheat(f, f2, f3, 1.0f).zues();
                worldrenderer.zeroday(x + d14 * f4 + 0.025, y + d15 * (f4 * f4 + f4) * 0.5 + ((24.0f - j) / 18.0f + 0.125f) + 0.025, z + d16 * f4).zerodayisaminecraftcheat(f, f2, f3, 1.0f).zues();
            }
            tessellator.zeroday();
            worldrenderer.zerodayisaminecraftcheat(5, DefaultVertexFormats.flux);
            for (int k = 0; k <= 24; ++k) {
                float f5 = 0.5f;
                float f6 = 0.4f;
                float f7 = 0.3f;
                if (k % 2 == 0) {
                    f5 *= 0.7f;
                    f6 *= 0.7f;
                    f7 *= 0.7f;
                }
                final float f8 = k / 24.0f;
                worldrenderer.zeroday(x + d14 * f8 + 0.0, y + d15 * (f8 * f8 + f8) * 0.5 + ((24.0f - k) / 18.0f + 0.125f) + 0.025, z + d16 * f8).zerodayisaminecraftcheat(f5, f6, f7, 1.0f).zues();
                worldrenderer.zeroday(x + d14 * f8 + 0.025, y + d15 * (f8 * f8 + f8) * 0.5 + ((24.0f - k) / 18.0f + 0.125f), z + d16 * f8 + 0.025).zerodayisaminecraftcheat(f5, f6, f7, 1.0f).zues();
            }
            tessellator.zeroday();
            GlStateManager.zues();
            GlStateManager.m();
            GlStateManager.g();
        }
    }
}

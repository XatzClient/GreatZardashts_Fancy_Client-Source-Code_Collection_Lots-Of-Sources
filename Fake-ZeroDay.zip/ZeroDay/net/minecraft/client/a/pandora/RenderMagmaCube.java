// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelMagmaCube;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityMagmaCube;

public class RenderMagmaCube extends RenderLiving<EntityMagmaCube>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/slime/magmacube.png");
    }
    
    public RenderMagmaCube(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelMagmaCube(), 0.25f);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityMagmaCube entity) {
        return RenderMagmaCube.zerodayisaminecraftcheat;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityMagmaCube entitylivingbaseIn, final float partialTickTime) {
        final int i = entitylivingbaseIn.cb();
        final float f = (entitylivingbaseIn.sigma + (entitylivingbaseIn.zeroday - entitylivingbaseIn.sigma) * partialTickTime) / (i * 0.5f + 1.0f);
        final float f2 = 1.0f / (f + 1.0f);
        final float f3 = (float)i;
        GlStateManager.zerodayisaminecraftcheat(f2 * f3, 1.0f / f2 * f3, f2 * f3);
    }
}

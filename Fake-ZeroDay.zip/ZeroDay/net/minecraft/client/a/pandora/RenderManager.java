// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.o.Vec3;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.RenderGlobal;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.o.ReportedException;
import net.minecraft.sigma.CrashReport;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.a.sigma.ICamera;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.zerodayisaminecraftcheat.BlockBed;
import net.minecraft.o.EnumFacing;
import net.minecraft.a.Blocks;
import net.minecraft.o.BlockPos;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.zeroday.AbstractClientPlayer;
import net.minecraft.vape.sigma.EntityLightningBolt;
import net.minecraft.client.pandora.ModelHorse;
import net.minecraft.vape.flux.EntityHorse;
import net.minecraft.vape.momgetthecamera.EntityFishHook;
import net.minecraft.vape.pandora.EntityBoat;
import net.minecraft.vape.pandora.EntityMinecart;
import net.minecraft.vape.zerodayisaminecraftcheat.EntityMinecartMobSpawner;
import net.minecraft.vape.pandora.EntityMinecartTNT;
import net.minecraft.vape.pandora.EntityArmorStand;
import net.minecraft.vape.pandora.EntityFallingBlock;
import net.minecraft.vape.pandora.EntityTNTPrimed;
import net.minecraft.vape.pandora.EntityXPOrb;
import net.minecraft.vape.pandora.EntityItem;
import net.minecraft.client.a.flux.RenderWitherSkull;
import net.minecraft.vape.momgetthecamera.EntityWitherSkull;
import net.minecraft.vape.momgetthecamera.EntitySmallFireball;
import net.minecraft.vape.momgetthecamera.EntityLargeFireball;
import net.minecraft.vape.pandora.EntityFireworkRocket;
import net.minecraft.vape.pandora.EntityExpBottle;
import net.minecraft.vape.momgetthecamera.EntityPotion;
import net.minecraft.vape.momgetthecamera.EntityEgg;
import net.minecraft.vape.pandora.EntityEnderEye;
import net.minecraft.vape.pandora.EntityEnderPearl;
import net.minecraft.a.Items;
import net.minecraft.vape.momgetthecamera.EntitySnowball;
import net.minecraft.vape.momgetthecamera.EntityArrow;
import net.minecraft.vape.EntityLeashKnot;
import net.minecraft.client.a.flux.RenderItemFrame;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.vape.pandora.EntityPainting;
import net.minecraft.vape.zeroday.EntityWither;
import net.minecraft.client.a.flux.RenderEnderCrystal;
import net.minecraft.vape.pandora.EntityEnderCrystal;
import net.minecraft.vape.zeroday.EntityDragon;
import net.minecraft.vape.zues.EntityGuardian;
import net.minecraft.vape.flux.EntityBat;
import net.minecraft.vape.zues.EntityIronGolem;
import net.minecraft.vape.flux.EntityVillager;
import net.minecraft.client.pandora.ModelSquid;
import net.minecraft.vape.flux.EntitySquid;
import net.minecraft.vape.zues.EntityGhast;
import net.minecraft.client.pandora.ModelZombie;
import net.minecraft.vape.zues.EntityGiantZombie;
import net.minecraft.vape.zues.EntityMagmaCube;
import net.minecraft.client.pandora.ModelSlime;
import net.minecraft.vape.zues.EntitySlime;
import net.minecraft.vape.zues.EntityZombie;
import net.minecraft.vape.zues.EntityPigZombie;
import net.minecraft.vape.zues.EntityBlaze;
import net.minecraft.vape.zues.EntityWitch;
import net.minecraft.vape.zues.EntitySkeleton;
import net.minecraft.vape.zues.EntitySnowman;
import net.minecraft.vape.zues.EntityEnderman;
import net.minecraft.vape.zues.EntityCreeper;
import net.minecraft.vape.zues.EntityEndermite;
import net.minecraft.vape.zues.EntitySilverfish;
import net.minecraft.client.pandora.ModelRabbit;
import net.minecraft.vape.flux.EntityRabbit;
import net.minecraft.client.pandora.ModelOcelot;
import net.minecraft.vape.flux.EntityOcelot;
import net.minecraft.client.pandora.ModelChicken;
import net.minecraft.vape.flux.EntityChicken;
import net.minecraft.client.pandora.ModelWolf;
import net.minecraft.vape.flux.EntityWolf;
import net.minecraft.vape.flux.EntityMooshroom;
import net.minecraft.client.pandora.ModelCow;
import net.minecraft.vape.flux.EntityCow;
import net.minecraft.client.pandora.ModelSheep2;
import net.minecraft.vape.flux.EntitySheep;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelPig;
import net.minecraft.vape.flux.EntityPig;
import net.minecraft.vape.zues.EntitySpider;
import net.minecraft.vape.zues.EntityCaveSpider;
import com.google.common.collect.Maps;
import net.minecraft.client.c.GameSettings;
import net.minecraft.q.World;
import net.minecraft.client.a.zues.TextureManager;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.vape.Entity;
import java.util.Map;

public class RenderManager
{
    private Map<Class<? extends Entity>, Render<? extends Entity>> f;
    private Map<String, RenderPlayer> g;
    private RenderPlayer h;
    private FontRenderer i;
    public static double zerodayisaminecraftcheat;
    public static double zeroday;
    public static double sigma;
    public TextureManager pandora;
    public World zues;
    public Entity flux;
    public Entity vape;
    public static float momgetthecamera;
    public static float a;
    public GameSettings b;
    public double c;
    public double d;
    public double e;
    private boolean j;
    private boolean k;
    private boolean l;
    
    public RenderManager(final TextureManager renderEngineIn, final RenderItem itemRendererIn) {
        this.f = (Map<Class<? extends Entity>, Render<? extends Entity>>)Maps.newHashMap();
        this.g = (Map<String, RenderPlayer>)Maps.newHashMap();
        this.j = false;
        this.k = true;
        this.l = false;
        this.pandora = renderEngineIn;
        this.f.put(EntityCaveSpider.class, new RenderCaveSpider(this));
        this.f.put(EntitySpider.class, new RenderSpider<Entity>(this));
        this.f.put(EntityPig.class, new RenderPig(this, new ModelPig(), 0.7f));
        this.f.put(EntitySheep.class, new RenderSheep(this, new ModelSheep2(), 0.7f));
        this.f.put(EntityCow.class, new RenderCow(this, new ModelCow(), 0.7f));
        this.f.put(EntityMooshroom.class, new RenderMooshroom(this, new ModelCow(), 0.7f));
        this.f.put(EntityWolf.class, new RenderWolf(this, new ModelWolf(), 0.5f));
        this.f.put(EntityChicken.class, new RenderChicken(this, new ModelChicken(), 0.3f));
        this.f.put(EntityOcelot.class, new RenderOcelot(this, new ModelOcelot(), 0.4f));
        this.f.put(EntityRabbit.class, new RenderRabbit(this, new ModelRabbit(), 0.3f));
        this.f.put(EntitySilverfish.class, new RenderSilverfish(this));
        this.f.put(EntityEndermite.class, new RenderEndermite(this));
        this.f.put(EntityCreeper.class, new RenderCreeper(this));
        this.f.put(EntityEnderman.class, new RenderEnderman(this));
        this.f.put(EntitySnowman.class, new RenderSnowMan(this));
        this.f.put(EntitySkeleton.class, new RenderSkeleton(this));
        this.f.put(EntityWitch.class, new RenderWitch(this));
        this.f.put(EntityBlaze.class, new RenderBlaze(this));
        this.f.put(EntityPigZombie.class, new RenderPigZombie(this));
        this.f.put(EntityZombie.class, new RenderZombie(this));
        this.f.put(EntitySlime.class, new RenderSlime(this, new ModelSlime(16), 0.25f));
        this.f.put(EntityMagmaCube.class, new RenderMagmaCube(this));
        this.f.put(EntityGiantZombie.class, new RenderGiantZombie(this, new ModelZombie(), 0.5f, 6.0f));
        this.f.put(EntityGhast.class, new RenderGhast(this));
        this.f.put(EntitySquid.class, new RenderSquid(this, new ModelSquid(), 0.7f));
        this.f.put(EntityVillager.class, new RenderVillager(this));
        this.f.put(EntityIronGolem.class, new RenderIronGolem(this));
        this.f.put(EntityBat.class, new RenderBat(this));
        this.f.put(EntityGuardian.class, new RenderGuardian(this));
        this.f.put(EntityDragon.class, new RenderDragon(this));
        this.f.put(EntityEnderCrystal.class, new RenderEnderCrystal(this));
        this.f.put(EntityWither.class, new RenderWither(this));
        this.f.put(Entity.class, new RenderEntity(this));
        this.f.put(EntityPainting.class, new RenderPainting(this));
        this.f.put(EntityItemFrame.class, new RenderItemFrame(this, itemRendererIn));
        this.f.put(EntityLeashKnot.class, new RenderLeashKnot(this));
        this.f.put(EntityArrow.class, new RenderArrow(this));
        this.f.put(EntitySnowball.class, new RenderSnowball<Entity>(this, Items.av, itemRendererIn));
        this.f.put(EntityEnderPearl.class, new RenderSnowball<Entity>(this, Items.bm, itemRendererIn));
        this.f.put(EntityEnderEye.class, new RenderSnowball<Entity>(this, Items.bz, itemRendererIn));
        this.f.put(EntityEgg.class, new RenderSnowball<Entity>(this, Items.aH, itemRendererIn));
        this.f.put(EntityPotion.class, new RenderPotion(this, itemRendererIn));
        this.f.put(EntityExpBottle.class, new RenderSnowball<Entity>(this, Items.bC, itemRendererIn));
        this.f.put(EntityFireworkRocket.class, new RenderSnowball<Entity>(this, Items.bT, itemRendererIn));
        this.f.put(EntityLargeFireball.class, new RenderFireball(this, 2.0f));
        this.f.put(EntitySmallFireball.class, new RenderFireball(this, 0.5f));
        this.f.put(EntityWitherSkull.class, new RenderWitherSkull(this));
        this.f.put(EntityItem.class, new RenderEntityItem(this, itemRendererIn));
        this.f.put(EntityXPOrb.class, new RenderXPOrb(this));
        this.f.put(EntityTNTPrimed.class, new RenderTNTPrimed(this));
        this.f.put(EntityFallingBlock.class, new RenderFallingBlock(this));
        this.f.put(EntityArmorStand.class, new ArmorStandRenderer(this));
        this.f.put(EntityMinecartTNT.class, new RenderTntMinecart(this));
        this.f.put(EntityMinecartMobSpawner.class, new RenderMinecartMobSpawner(this));
        this.f.put(EntityMinecart.class, new RenderMinecart<Entity>(this));
        this.f.put(EntityBoat.class, new RenderBoat(this));
        this.f.put(EntityFishHook.class, new RenderFish(this));
        this.f.put(EntityHorse.class, new RenderHorse(this, new ModelHorse(), 0.75f));
        this.f.put(EntityLightningBolt.class, new RenderLightningBolt(this));
        this.h = new RenderPlayer(this);
        this.g.put("default", this.h);
        this.g.put("slim", new RenderPlayer(this, true));
    }
    
    public void zerodayisaminecraftcheat(final double renderPosXIn, final double renderPosYIn, final double renderPosZIn) {
        RenderManager.zerodayisaminecraftcheat = renderPosXIn;
        RenderManager.zeroday = renderPosYIn;
        RenderManager.sigma = renderPosZIn;
    }
    
    public <T extends Entity> Render<T> zerodayisaminecraftcheat(final Class<? extends Entity> p_78715_1_) {
        Render<? extends Entity> render = this.f.get(p_78715_1_);
        if (render == null && p_78715_1_ != Entity.class) {
            render = this.zerodayisaminecraftcheat((Class<? extends Entity>)p_78715_1_.getSuperclass());
            this.f.put(p_78715_1_, render);
        }
        return (Render<T>)render;
    }
    
    public <T extends Entity> Render<T> zerodayisaminecraftcheat(final Entity entityIn) {
        if (entityIn instanceof AbstractClientPlayer) {
            final String s = ((AbstractClientPlayer)entityIn).j_();
            final RenderPlayer renderplayer = this.g.get(s);
            return (Render<T>)((renderplayer != null) ? renderplayer : this.h);
        }
        return this.zerodayisaminecraftcheat(entityIn.getClass());
    }
    
    public void zerodayisaminecraftcheat(final World worldIn, final FontRenderer textRendererIn, final Entity livingPlayerIn, final Entity pointedEntityIn, final GameSettings optionsIn, final float partialTicks) {
        this.zues = worldIn;
        this.b = optionsIn;
        this.flux = livingPlayerIn;
        this.vape = pointedEntityIn;
        this.i = textRendererIn;
        if (livingPlayerIn instanceof EntityLivingBase && ((EntityLivingBase)livingPlayerIn).bS()) {
            final IBlockState iblockstate = worldIn.zeroday(new BlockPos(livingPlayerIn));
            final Block block = iblockstate.sigma();
            if (block == Blocks.u) {
                final int i = iblockstate.zerodayisaminecraftcheat((IProperty<EnumFacing>)BlockBed.F).sigma();
                RenderManager.momgetthecamera = (float)(i * 90 + 180);
                RenderManager.a = 0.0f;
            }
        }
        else {
            RenderManager.momgetthecamera = livingPlayerIn.A + (livingPlayerIn.y - livingPlayerIn.A) * partialTicks;
            RenderManager.a = livingPlayerIn.B + (livingPlayerIn.z - livingPlayerIn.B) * partialTicks;
        }
        if (optionsIn.as == 2) {
            RenderManager.momgetthecamera += 180.0f;
        }
        this.c = livingPlayerIn.Q + (livingPlayerIn.s - livingPlayerIn.Q) * partialTicks;
        this.d = livingPlayerIn.R + (livingPlayerIn.t - livingPlayerIn.R) * partialTicks;
        this.e = livingPlayerIn.S + (livingPlayerIn.u - livingPlayerIn.S) * partialTicks;
    }
    
    public void zerodayisaminecraftcheat(final float playerViewYIn) {
        RenderManager.momgetthecamera = playerViewYIn;
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.k;
    }
    
    public void zerodayisaminecraftcheat(final boolean renderShadowIn) {
        this.k = renderShadowIn;
    }
    
    public void zeroday(final boolean debugBoundingBoxIn) {
        this.l = debugBoundingBoxIn;
    }
    
    public boolean zeroday() {
        return this.l;
    }
    
    public boolean zerodayisaminecraftcheat(final Entity entityIn, final float partialTicks) {
        return this.zerodayisaminecraftcheat(entityIn, partialTicks, false);
    }
    
    public boolean zerodayisaminecraftcheat(final Entity entityIn, final ICamera camera, final double camX, final double camY, final double camZ) {
        final Render<Entity> render = this.zerodayisaminecraftcheat(entityIn);
        return render != null && render.zerodayisaminecraftcheat(entityIn, camera, camX, camY, camZ);
    }
    
    public boolean zerodayisaminecraftcheat(final Entity entity, final float partialTicks, final boolean p_147936_3_) {
        if (entity.X == 0) {
            entity.Q = entity.s;
            entity.R = entity.t;
            entity.S = entity.u;
        }
        final double d0 = entity.Q + (entity.s - entity.Q) * partialTicks;
        final double d2 = entity.R + (entity.t - entity.R) * partialTicks;
        final double d3 = entity.S + (entity.u - entity.S) * partialTicks;
        final float f = entity.A + (entity.y - entity.A) * partialTicks;
        int i = entity.zerodayisaminecraftcheat(partialTicks);
        if (entity.am()) {
            i = 15728880;
        }
        final int j = i % 65536;
        final int k = i / 65536;
        OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, j / 1.0f, k / 1.0f);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        return this.zerodayisaminecraftcheat(entity, d0 - RenderManager.zerodayisaminecraftcheat, d2 - RenderManager.zeroday, d3 - RenderManager.sigma, f, partialTicks, p_147936_3_);
    }
    
    public void zeroday(final Entity entityIn, final float partialTicks) {
        final double d0 = entityIn.Q + (entityIn.s - entityIn.Q) * partialTicks;
        final double d2 = entityIn.R + (entityIn.t - entityIn.R) * partialTicks;
        final double d3 = entityIn.S + (entityIn.u - entityIn.S) * partialTicks;
        final Render<Entity> render = this.zerodayisaminecraftcheat(entityIn);
        if (render != null && this.pandora != null) {
            final int i = entityIn.zerodayisaminecraftcheat(partialTicks);
            final int j = i % 65536;
            final int k = i / 65536;
            OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, j / 1.0f, k / 1.0f);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            render.zerodayisaminecraftcheat(entityIn, d0 - RenderManager.zerodayisaminecraftcheat, d2 - RenderManager.zeroday, d3 - RenderManager.sigma);
        }
    }
    
    public boolean zerodayisaminecraftcheat(final Entity entityIn, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        return this.zerodayisaminecraftcheat(entityIn, x, y, z, entityYaw, partialTicks, false);
    }
    
    public boolean zerodayisaminecraftcheat(final Entity entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks, final boolean p_147939_10_) {
        Render<Entity> render = null;
        try {
            render = this.zerodayisaminecraftcheat(entity);
            if (render != null && this.pandora != null) {
                try {
                    if (render instanceof RendererLivingEntity) {
                        ((RendererLivingEntity)render).zerodayisaminecraftcheat(this.j);
                    }
                    render.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
                }
                catch (Throwable throwable2) {
                    throw new ReportedException(CrashReport.zerodayisaminecraftcheat(throwable2, "Rendering entity in world"));
                }
                try {
                    if (!this.j) {
                        render.zeroday(entity, x, y, z, entityYaw, partialTicks);
                    }
                }
                catch (Throwable throwable3) {
                    throw new ReportedException(CrashReport.zerodayisaminecraftcheat(throwable3, "Post-rendering entity in world"));
                }
                if (!this.l || entity.ap() || p_147939_10_) {
                    return true;
                }
                try {
                    this.zeroday(entity, x, y, z, entityYaw, partialTicks);
                    return true;
                }
                catch (Throwable throwable4) {
                    throw new ReportedException(CrashReport.zerodayisaminecraftcheat(throwable4, "Rendering entity hitbox in world"));
                }
            }
            if (this.pandora != null) {
                return false;
            }
            return true;
        }
        catch (Throwable throwable5) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable5, "Rendering entity in world");
            final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Entity being rendered");
            entity.zerodayisaminecraftcheat(crashreportcategory);
            final CrashReportCategory crashreportcategory2 = crashreport.zerodayisaminecraftcheat("Renderer details");
            crashreportcategory2.zerodayisaminecraftcheat("Assigned renderer", render);
            crashreportcategory2.zerodayisaminecraftcheat("Location", CrashReportCategory.zerodayisaminecraftcheat(x, y, z));
            crashreportcategory2.zerodayisaminecraftcheat("Rotation", entityYaw);
            crashreportcategory2.zerodayisaminecraftcheat("Delta", partialTicks);
            throw new ReportedException(crashreport);
        }
    }
    
    private void zeroday(final Entity entityIn, final double p_85094_2_, final double p_85094_4_, final double p_85094_6_, final float p_85094_8_, final float p_85094_9_) {
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.n();
        GlStateManager.flux();
        GlStateManager.h();
        GlStateManager.c();
        final float f = entityIn.K / 2.0f;
        final AxisAlignedBB axisalignedbb = entityIn.aH();
        final AxisAlignedBB axisalignedbb2 = new AxisAlignedBB(axisalignedbb.zerodayisaminecraftcheat - entityIn.s + p_85094_2_, axisalignedbb.zeroday - entityIn.t + p_85094_4_, axisalignedbb.sigma - entityIn.u + p_85094_6_, axisalignedbb.pandora - entityIn.s + p_85094_2_, axisalignedbb.zues - entityIn.t + p_85094_4_, axisalignedbb.flux - entityIn.u + p_85094_6_);
        RenderGlobal.zerodayisaminecraftcheat(axisalignedbb2, 255, 255, 255, 255);
        if (entityIn instanceof EntityLivingBase) {
            final float f2 = 0.01f;
            RenderGlobal.zerodayisaminecraftcheat(new AxisAlignedBB(p_85094_2_ - f, p_85094_4_ + entityIn.aI() - 0.009999999776482582, p_85094_6_ - f, p_85094_2_ + f, p_85094_4_ + entityIn.aI() + 0.009999999776482582, p_85094_6_ + f), 255, 0, 0, 255);
        }
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        final Vec3 vec3 = entityIn.flux(p_85094_9_);
        worldrenderer.zerodayisaminecraftcheat(3, DefaultVertexFormats.flux);
        worldrenderer.zeroday(p_85094_2_, p_85094_4_ + entityIn.aI(), p_85094_6_).zeroday(0, 0, 255, 255).zues();
        worldrenderer.zeroday(p_85094_2_ + vec3.zerodayisaminecraftcheat * 2.0, p_85094_4_ + entityIn.aI() + vec3.zeroday * 2.0, p_85094_6_ + vec3.sigma * 2.0).zeroday(0, 0, 255, 255).zues();
        tessellator.zeroday();
        GlStateManager.m();
        GlStateManager.zues();
        GlStateManager.g();
        GlStateManager.c();
        GlStateManager.zerodayisaminecraftcheat(true);
    }
    
    public void zerodayisaminecraftcheat(final World worldIn) {
        this.zues = worldIn;
    }
    
    public double zeroday(final double p_78714_1_, final double p_78714_3_, final double p_78714_5_) {
        final double d0 = p_78714_1_ - this.c;
        final double d2 = p_78714_3_ - this.d;
        final double d3 = p_78714_5_ - this.e;
        return d0 * d0 + d2 * d2 + d3 * d3;
    }
    
    public FontRenderer sigma() {
        return this.i;
    }
    
    public Map pandora() {
        return this.f;
    }
    
    public void sigma(final boolean renderOutlinesIn) {
        this.j = renderOutlinesIn;
    }
}

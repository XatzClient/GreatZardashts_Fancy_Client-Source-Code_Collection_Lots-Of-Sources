// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.client.Minecraft;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.o.Vec3;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelMinecart;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.pandora.EntityMinecart;

public class RenderMinecart<T extends EntityMinecart> extends Render<T>
{
    private static final ResourceLocation zues;
    protected ModelBase zerodayisaminecraftcheat;
    
    static {
        zues = new ResourceLocation("textures/entity/minecart.png");
    }
    
    public RenderMinecart(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.zerodayisaminecraftcheat = new ModelMinecart();
        this.sigma = 0.5f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final T entity, double x, double y, double z, float entityYaw, final float partialTicks) {
        GlStateManager.v();
        this.sigma(entity);
        long i = entity.B() * 493286711L;
        i = i * i * 4392167121L + i * 98761L;
        final float f = (((i >> 16 & 0x7L) + 0.5f) / 8.0f - 0.5f) * 0.004f;
        final float f2 = (((i >> 20 & 0x7L) + 0.5f) / 8.0f - 0.5f) * 0.004f;
        final float f3 = (((i >> 24 & 0x7L) + 0.5f) / 8.0f - 0.5f) * 0.004f;
        GlStateManager.zeroday(f, f2, f3);
        final double d0 = entity.Q + (entity.s - entity.Q) * partialTicks;
        final double d2 = entity.R + (entity.t - entity.R) * partialTicks;
        final double d3 = entity.S + (entity.u - entity.S) * partialTicks;
        final double d4 = 0.30000001192092896;
        final Vec3 vec3 = entity.c(d0, d2, d3);
        float f4 = entity.B + (entity.z - entity.B) * partialTicks;
        if (vec3 != null) {
            Vec3 vec4 = entity.zerodayisaminecraftcheat(d0, d2, d3, d4);
            Vec3 vec5 = entity.zerodayisaminecraftcheat(d0, d2, d3, -d4);
            if (vec4 == null) {
                vec4 = vec3;
            }
            if (vec5 == null) {
                vec5 = vec3;
            }
            x += vec3.zerodayisaminecraftcheat - d0;
            y += (vec4.zeroday + vec5.zeroday) / 2.0 - d2;
            z += vec3.sigma - d3;
            Vec3 vec6 = vec5.zeroday(-vec4.zerodayisaminecraftcheat, -vec4.zeroday, -vec4.sigma);
            if (vec6.zeroday() != 0.0) {
                vec6 = vec6.zerodayisaminecraftcheat();
                entityYaw = (float)(Math.atan2(vec6.sigma, vec6.zerodayisaminecraftcheat) * 180.0 / 3.141592653589793);
                f4 = (float)(Math.atan(vec6.zeroday) * 73.0);
            }
        }
        GlStateManager.zeroday((float)x, (float)y + 0.375f, (float)z);
        GlStateManager.zeroday(180.0f - entityYaw, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(-f4, 0.0f, 0.0f, 1.0f);
        final float f5 = entity.l() - partialTicks;
        float f6 = entity.k() - partialTicks;
        if (f6 < 0.0f) {
            f6 = 0.0f;
        }
        if (f5 > 0.0f) {
            GlStateManager.zeroday(MathHelper.zerodayisaminecraftcheat(f5) * f5 * f6 / 10.0f * entity.m(), 1.0f, 0.0f, 0.0f);
        }
        final int j = entity.o();
        final IBlockState iblockstate = entity.n();
        if (iblockstate.sigma().c() != -1) {
            GlStateManager.v();
            this.zerodayisaminecraftcheat(TextureMap.zeroday);
            final float f7 = 0.75f;
            GlStateManager.zerodayisaminecraftcheat(f7, f7, f7);
            GlStateManager.zeroday(-0.5f, (j - 8) / 16.0f, 0.5f);
            this.zerodayisaminecraftcheat(entity, partialTicks, iblockstate);
            GlStateManager.w();
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.sigma(entity);
        }
        GlStateManager.zerodayisaminecraftcheat(-1.0f, -1.0f, 1.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(entity, 0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final T entity) {
        return RenderMinecart.zues;
    }
    
    protected void zerodayisaminecraftcheat(final T minecart, final float partialTicks, final IBlockState state) {
        GlStateManager.v();
        Minecraft.s().X().zerodayisaminecraftcheat(state, minecart.zeroday(partialTicks));
        GlStateManager.w();
    }
}

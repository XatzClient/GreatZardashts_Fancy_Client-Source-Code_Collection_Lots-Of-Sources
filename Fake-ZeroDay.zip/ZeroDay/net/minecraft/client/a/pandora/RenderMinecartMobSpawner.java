// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.pandora.EntityMinecart;
import net.minecraft.client.a.flux.TileEntityMobSpawnerRenderer;
import net.minecraft.a.Blocks;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.vape.zerodayisaminecraftcheat.EntityMinecartMobSpawner;

public class RenderMinecartMobSpawner extends RenderMinecart<EntityMinecartMobSpawner>
{
    public RenderMinecartMobSpawner(final RenderManager renderManagerIn) {
        super(renderManagerIn);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityMinecartMobSpawner minecart, final float partialTicks, final IBlockState state) {
        super.zerodayisaminecraftcheat(minecart, partialTicks, state);
        if (state.sigma() == Blocks.U) {
            TileEntityMobSpawnerRenderer.zerodayisaminecraftcheat(minecart.a(), minecart.s, minecart.t, minecart.u, partialTicks);
        }
    }
}

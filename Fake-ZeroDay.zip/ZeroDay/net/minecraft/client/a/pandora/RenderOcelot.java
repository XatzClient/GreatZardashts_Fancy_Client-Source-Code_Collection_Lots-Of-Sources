// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityOcelot;

public class RenderOcelot extends RenderLiving<EntityOcelot>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/cat/black.png");
        zues = new ResourceLocation("textures/entity/cat/ocelot.png");
        b = new ResourceLocation("textures/entity/cat/red.png");
        c = new ResourceLocation("textures/entity/cat/siamese.png");
    }
    
    public RenderOcelot(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityOcelot entity) {
        switch (entity.cd()) {
            default: {
                return RenderOcelot.zues;
            }
            case 1: {
                return RenderOcelot.zerodayisaminecraftcheat;
            }
            case 2: {
                return RenderOcelot.b;
            }
            case 3: {
                return RenderOcelot.c;
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityOcelot entitylivingbaseIn, final float partialTickTime) {
        super.zerodayisaminecraftcheat(entitylivingbaseIn, partialTickTime);
        if (entitylivingbaseIn.cf()) {
            GlStateManager.zerodayisaminecraftcheat(0.8f, 0.8f, 0.8f);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.o.BlockPos;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.pandora.EntityPainting;

public class RenderPainting extends Render<EntityPainting>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/painting/paintings_kristoffer_zetterstrand.png");
    }
    
    public RenderPainting(final RenderManager renderManagerIn) {
        super(renderManagerIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityPainting entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        GlStateManager.zeroday(x, y, z);
        GlStateManager.zeroday(180.0f - entityYaw, 0.0f, 1.0f, 0.0f);
        GlStateManager.s();
        this.sigma(entity);
        final EntityPainting.zerodayisaminecraftcheat entitypainting$enumart = entity.sigma;
        final float f = 0.0625f;
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        this.zerodayisaminecraftcheat(entity, entitypainting$enumart.u, entitypainting$enumart.v, entitypainting$enumart.w, entitypainting$enumart.x);
        GlStateManager.t();
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityPainting entity) {
        return RenderPainting.zerodayisaminecraftcheat;
    }
    
    private void zerodayisaminecraftcheat(final EntityPainting painting, final int width, final int height, final int textureU, final int textureV) {
        final float f = -width / 2.0f;
        final float f2 = -height / 2.0f;
        final float f3 = 0.5f;
        final float f4 = 0.75f;
        final float f5 = 0.8125f;
        final float f6 = 0.0f;
        final float f7 = 0.0625f;
        final float f8 = 0.75f;
        final float f9 = 0.8125f;
        final float f10 = 0.001953125f;
        final float f11 = 0.001953125f;
        final float f12 = 0.7519531f;
        final float f13 = 0.7519531f;
        final float f14 = 0.0f;
        final float f15 = 0.0625f;
        for (int i = 0; i < width / 16; ++i) {
            for (int j = 0; j < height / 16; ++j) {
                final float f16 = f + (i + 1) * 16;
                final float f17 = f + i * 16;
                final float f18 = f2 + (j + 1) * 16;
                final float f19 = f2 + j * 16;
                this.zerodayisaminecraftcheat(painting, (f16 + f17) / 2.0f, (f18 + f19) / 2.0f);
                final float f20 = (textureU + width - i * 16) / 256.0f;
                final float f21 = (textureU + width - (i + 1) * 16) / 256.0f;
                final float f22 = (textureV + height - j * 16) / 256.0f;
                final float f23 = (textureV + height - (j + 1) * 16) / 256.0f;
                final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                final WorldRenderer worldrenderer = tessellator.sigma();
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.b);
                worldrenderer.zeroday(f16, f19, (double)(-f3)).zerodayisaminecraftcheat(f21, f22).sigma(0.0f, 0.0f, -1.0f).zues();
                worldrenderer.zeroday(f17, f19, (double)(-f3)).zerodayisaminecraftcheat(f20, f22).sigma(0.0f, 0.0f, -1.0f).zues();
                worldrenderer.zeroday(f17, f18, (double)(-f3)).zerodayisaminecraftcheat(f20, f23).sigma(0.0f, 0.0f, -1.0f).zues();
                worldrenderer.zeroday(f16, f18, (double)(-f3)).zerodayisaminecraftcheat(f21, f23).sigma(0.0f, 0.0f, -1.0f).zues();
                worldrenderer.zeroday(f16, f18, (double)f3).zerodayisaminecraftcheat(f4, f6).sigma(0.0f, 0.0f, 1.0f).zues();
                worldrenderer.zeroday(f17, f18, (double)f3).zerodayisaminecraftcheat(f5, f6).sigma(0.0f, 0.0f, 1.0f).zues();
                worldrenderer.zeroday(f17, f19, (double)f3).zerodayisaminecraftcheat(f5, f7).sigma(0.0f, 0.0f, 1.0f).zues();
                worldrenderer.zeroday(f16, f19, (double)f3).zerodayisaminecraftcheat(f4, f7).sigma(0.0f, 0.0f, 1.0f).zues();
                worldrenderer.zeroday(f16, f18, (double)(-f3)).zerodayisaminecraftcheat(f8, f10).sigma(0.0f, 1.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f18, (double)(-f3)).zerodayisaminecraftcheat(f9, f10).sigma(0.0f, 1.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f18, (double)f3).zerodayisaminecraftcheat(f9, f11).sigma(0.0f, 1.0f, 0.0f).zues();
                worldrenderer.zeroday(f16, f18, (double)f3).zerodayisaminecraftcheat(f8, f11).sigma(0.0f, 1.0f, 0.0f).zues();
                worldrenderer.zeroday(f16, f19, (double)f3).zerodayisaminecraftcheat(f8, f10).sigma(0.0f, -1.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f19, (double)f3).zerodayisaminecraftcheat(f9, f10).sigma(0.0f, -1.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f19, (double)(-f3)).zerodayisaminecraftcheat(f9, f11).sigma(0.0f, -1.0f, 0.0f).zues();
                worldrenderer.zeroday(f16, f19, (double)(-f3)).zerodayisaminecraftcheat(f8, f11).sigma(0.0f, -1.0f, 0.0f).zues();
                worldrenderer.zeroday(f16, f18, (double)f3).zerodayisaminecraftcheat(f13, f14).sigma(-1.0f, 0.0f, 0.0f).zues();
                worldrenderer.zeroday(f16, f19, (double)f3).zerodayisaminecraftcheat(f13, f15).sigma(-1.0f, 0.0f, 0.0f).zues();
                worldrenderer.zeroday(f16, f19, (double)(-f3)).zerodayisaminecraftcheat(f12, f15).sigma(-1.0f, 0.0f, 0.0f).zues();
                worldrenderer.zeroday(f16, f18, (double)(-f3)).zerodayisaminecraftcheat(f12, f14).sigma(-1.0f, 0.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f18, (double)(-f3)).zerodayisaminecraftcheat(f13, f14).sigma(1.0f, 0.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f19, (double)(-f3)).zerodayisaminecraftcheat(f13, f15).sigma(1.0f, 0.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f19, (double)f3).zerodayisaminecraftcheat(f12, f15).sigma(1.0f, 0.0f, 0.0f).zues();
                worldrenderer.zeroday(f17, f18, (double)f3).zerodayisaminecraftcheat(f12, f14).sigma(1.0f, 0.0f, 0.0f).zues();
                tessellator.zeroday();
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final EntityPainting painting, final float p_77008_2_, final float p_77008_3_) {
        int i = MathHelper.sigma(painting.s);
        final int j = MathHelper.sigma(painting.t + p_77008_3_ / 16.0f);
        int k = MathHelper.sigma(painting.u);
        final EnumFacing enumfacing = painting.zeroday;
        if (enumfacing == EnumFacing.sigma) {
            i = MathHelper.sigma(painting.s + p_77008_2_ / 16.0f);
        }
        if (enumfacing == EnumFacing.zues) {
            k = MathHelper.sigma(painting.u - p_77008_2_ / 16.0f);
        }
        if (enumfacing == EnumFacing.pandora) {
            i = MathHelper.sigma(painting.s - p_77008_2_ / 16.0f);
        }
        if (enumfacing == EnumFacing.flux) {
            k = MathHelper.sigma(painting.u + p_77008_2_ / 16.0f);
        }
        final int l = this.zeroday.zues.zerodayisaminecraftcheat(new BlockPos(i, j, k), 0);
        final int i2 = l % 65536;
        final int j2 = l / 65536;
        OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, (float)i2, (float)j2);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f);
    }
}

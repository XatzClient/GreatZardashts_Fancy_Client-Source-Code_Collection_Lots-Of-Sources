// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerSaddle;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityPig;

public class RenderPig extends RenderLiving<EntityPig>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/pig/pig.png");
    }
    
    public RenderPig(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerSaddle(this));
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityPig entity) {
        return RenderPig.zerodayisaminecraftcheat;
    }
}

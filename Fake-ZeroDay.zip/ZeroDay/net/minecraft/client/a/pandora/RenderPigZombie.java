// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.EntityLiving;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerBipedArmor;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItem;
import net.minecraft.client.pandora.ModelBiped;
import net.minecraft.client.pandora.ModelZombie;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityPigZombie;

public class RenderPigZombie extends RenderBiped<EntityPigZombie>
{
    private static final ResourceLocation b;
    
    static {
        b = new ResourceLocation("textures/entity/zombie_pigman.png");
    }
    
    public RenderPigZombie(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelZombie(), 0.5f, 1.0f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldItem(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerBipedArmor(this) {
            @Override
            protected void zerodayisaminecraftcheat() {
                this.sigma = (T)new ModelZombie(0.5f, true);
                this.pandora = (T)new ModelZombie(1.0f, true);
            }
        });
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityPigZombie entity) {
        return RenderPigZombie.b;
    }
}

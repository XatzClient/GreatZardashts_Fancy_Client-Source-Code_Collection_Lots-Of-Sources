// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.j.Score;
import net.minecraft.j.ScoreObjective;
import net.minecraft.j.Scoreboard;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.c.ItemStack;
import net.minecraft.c.EnumAction;
import net.minecraft.vape.vape.EnumPlayerModelParts;
import net.minecraft.client.zeroday.EntityPlayerSP;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerCustomHead;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerCape;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerDeadmau5Head;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerArrow;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItem;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerBipedArmor;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelPlayer;
import net.minecraft.client.zeroday.AbstractClientPlayer;

public class RenderPlayer extends RendererLivingEntity<AbstractClientPlayer>
{
    private boolean zerodayisaminecraftcheat;
    
    public RenderPlayer(final RenderManager renderManager) {
        this(renderManager, false);
    }
    
    public RenderPlayer(final RenderManager renderManager, final boolean useSmallArms) {
        super(renderManager, new ModelPlayer(0.0f, useSmallArms), 0.5f);
        this.zerodayisaminecraftcheat = useSmallArms;
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerBipedArmor(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldItem(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerArrow(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerDeadmau5Head(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerCape(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerCustomHead(this.zues().c));
    }
    
    public ModelPlayer zues() {
        return (ModelPlayer)super.zeroday();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final AbstractClientPlayer entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (!entity.g_() || this.zeroday.flux == entity) {
            double d0 = y;
            if (entity.y() && !(entity instanceof EntityPlayerSP)) {
                d0 = y - 0.125;
            }
            this.pandora(entity);
            super.zerodayisaminecraftcheat(entity, x, d0, z, entityYaw, partialTicks);
        }
    }
    
    private void pandora(final AbstractClientPlayer clientPlayer) {
        final ModelPlayer modelplayer = this.zues();
        if (clientPlayer.h_()) {
            modelplayer.zerodayisaminecraftcheat(false);
            modelplayer.c.b = true;
            modelplayer.d.b = true;
        }
        else {
            final ItemStack itemstack = clientPlayer.d.pandora();
            modelplayer.zerodayisaminecraftcheat(true);
            modelplayer.d.b = clientPlayer.zerodayisaminecraftcheat(EnumPlayerModelParts.vape);
            modelplayer.n.b = clientPlayer.zerodayisaminecraftcheat(EnumPlayerModelParts.zeroday);
            modelplayer.sigma.b = clientPlayer.zerodayisaminecraftcheat(EnumPlayerModelParts.zues);
            modelplayer.pandora.b = clientPlayer.zerodayisaminecraftcheat(EnumPlayerModelParts.flux);
            modelplayer.zerodayisaminecraftcheat.b = clientPlayer.zerodayisaminecraftcheat(EnumPlayerModelParts.sigma);
            modelplayer.zeroday.b = clientPlayer.zerodayisaminecraftcheat(EnumPlayerModelParts.pandora);
            modelplayer.j = 0;
            modelplayer.m = false;
            modelplayer.l = clientPlayer.y();
            if (itemstack == null) {
                modelplayer.k = 0;
            }
            else {
                modelplayer.k = 1;
                if (clientPlayer.aO() > 0) {
                    final EnumAction enumaction = itemstack.e();
                    if (enumaction == EnumAction.pandora) {
                        modelplayer.k = 3;
                    }
                    else if (enumaction == EnumAction.zues) {
                        modelplayer.m = true;
                    }
                }
            }
        }
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final AbstractClientPlayer entity) {
        return entity.a();
    }
    
    @Override
    public void z_() {
        GlStateManager.zeroday(0.0f, 0.1875f, 0.0f);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final AbstractClientPlayer entitylivingbaseIn, final float partialTickTime) {
        final float f = 0.9375f;
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final AbstractClientPlayer entityIn, final double x, double y, final double z, final String str, final float p_177069_9_, final double p_177069_10_) {
        if (p_177069_10_ < 100.0) {
            final Scoreboard scoreboard = entityIn.ce();
            final ScoreObjective scoreobjective = scoreboard.zerodayisaminecraftcheat(2);
            if (scoreobjective != null) {
                final Score score = scoreboard.zeroday(entityIn.l_(), scoreobjective);
                this.zerodayisaminecraftcheat(entityIn, String.valueOf(score.zeroday()) + " " + scoreobjective.pandora(), x, y, z, 64);
                y += this.sigma().zeroday * 1.15f * p_177069_9_;
            }
        }
        super.zerodayisaminecraftcheat(entityIn, x, y, z, str, p_177069_9_, p_177069_10_);
    }
    
    public void zeroday(final AbstractClientPlayer clientPlayer) {
        final float f = 1.0f;
        GlStateManager.sigma(f, f, f);
        final ModelPlayer modelplayer = this.zues();
        this.pandora(clientPlayer);
        modelplayer.zues = 0.0f;
        modelplayer.l = false;
        modelplayer.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f, clientPlayer);
        modelplayer.zerodayisaminecraftcheat();
    }
    
    public void sigma(final AbstractClientPlayer clientPlayer) {
        final float f = 1.0f;
        GlStateManager.sigma(f, f, f);
        final ModelPlayer modelplayer = this.zues();
        this.pandora(clientPlayer);
        modelplayer.l = false;
        modelplayer.zerodayisaminecraftcheat(modelplayer.zues = 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f, clientPlayer);
        modelplayer.zeroday();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final AbstractClientPlayer entityLivingBaseIn, final double x, final double y, final double z) {
        if (entityLivingBaseIn.ac() && entityLivingBaseIn.bS()) {
            super.zerodayisaminecraftcheat(entityLivingBaseIn, x + entityLivingBaseIn.bw, y + entityLivingBaseIn.bx, z + entityLivingBaseIn.by);
        }
        else {
            super.zerodayisaminecraftcheat(entityLivingBaseIn, x, y, z);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final AbstractClientPlayer bat, final float p_77043_2_, final float p_77043_3_, final float partialTicks) {
        if (bat.ac() && bat.bS()) {
            GlStateManager.zeroday(bat.bb(), 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(this.zeroday(bat), 0.0f, 0.0f, 1.0f);
            GlStateManager.zeroday(270.0f, 0.0f, 1.0f, 0.0f);
        }
        else {
            super.zerodayisaminecraftcheat(bat, p_77043_2_, p_77043_3_, partialTicks);
        }
    }
}

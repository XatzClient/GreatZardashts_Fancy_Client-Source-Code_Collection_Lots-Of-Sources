// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.c.ItemStack;
import net.minecraft.c.Item;
import net.minecraft.a.Items;
import net.minecraft.vape.momgetthecamera.EntityPotion;

public class RenderPotion extends RenderSnowball<EntityPotion>
{
    public RenderPotion(final RenderManager renderManagerIn, final RenderItem itemRendererIn) {
        super(renderManagerIn, Items.br, itemRendererIn);
    }
    
    public ItemStack zerodayisaminecraftcheat(final EntityPotion entityIn) {
        return new ItemStack(this.zerodayisaminecraftcheat, 1, entityIn.b());
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityRabbit;

public class RenderRabbit extends RenderLiving<EntityRabbit>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    private static final ResourceLocation d;
    private static final ResourceLocation e;
    private static final ResourceLocation f;
    private static final ResourceLocation g;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/rabbit/brown.png");
        zues = new ResourceLocation("textures/entity/rabbit/white.png");
        b = new ResourceLocation("textures/entity/rabbit/black.png");
        c = new ResourceLocation("textures/entity/rabbit/gold.png");
        d = new ResourceLocation("textures/entity/rabbit/salt.png");
        e = new ResourceLocation("textures/entity/rabbit/white_splotched.png");
        f = new ResourceLocation("textures/entity/rabbit/toast.png");
        g = new ResourceLocation("textures/entity/rabbit/caerbannog.png");
    }
    
    public RenderRabbit(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityRabbit entity) {
        final String s = EnumChatFormatting.zerodayisaminecraftcheat(entity.l_());
        if (s != null && s.equals("Toast")) {
            return RenderRabbit.f;
        }
        switch (entity.cf()) {
            default: {
                return RenderRabbit.zerodayisaminecraftcheat;
            }
            case 1: {
                return RenderRabbit.zues;
            }
            case 2: {
                return RenderRabbit.b;
            }
            case 3: {
                return RenderRabbit.e;
            }
            case 4: {
                return RenderRabbit.c;
            }
            case 5: {
                return RenderRabbit.d;
            }
            case 99: {
                return RenderRabbit.g;
            }
        }
    }
}

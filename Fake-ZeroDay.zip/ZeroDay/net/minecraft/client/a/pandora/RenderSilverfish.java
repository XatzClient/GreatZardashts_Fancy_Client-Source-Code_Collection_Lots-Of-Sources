// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelSilverfish;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntitySilverfish;

public class RenderSilverfish extends RenderLiving<EntitySilverfish>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/silverfish.png");
    }
    
    public RenderSilverfish(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelSilverfish(), 0.3f);
    }
    
    protected float zerodayisaminecraftcheat(final EntitySilverfish entityLivingBaseIn) {
        return 180.0f;
    }
    
    protected ResourceLocation zeroday(final EntitySilverfish entity) {
        return RenderSilverfish.zerodayisaminecraftcheat;
    }
}

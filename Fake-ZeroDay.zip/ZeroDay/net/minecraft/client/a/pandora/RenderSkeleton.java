// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerBipedArmor;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItem;
import net.minecraft.client.pandora.ModelBiped;
import net.minecraft.client.pandora.ModelSkeleton;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntitySkeleton;

public class RenderSkeleton extends RenderBiped<EntitySkeleton>
{
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    
    static {
        b = new ResourceLocation("textures/entity/skeleton/skeleton.png");
        c = new ResourceLocation("textures/entity/skeleton/wither_skeleton.png");
    }
    
    public RenderSkeleton(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelSkeleton(), 0.5f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldItem(this));
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerBipedArmor(this) {
            @Override
            protected void zerodayisaminecraftcheat() {
                this.sigma = (T)new ModelSkeleton(0.5f, true);
                this.pandora = (T)new ModelSkeleton(1.0f, true);
            }
        });
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntitySkeleton entitylivingbaseIn, final float partialTickTime) {
        if (entitylivingbaseIn.cb() == 1) {
            GlStateManager.zerodayisaminecraftcheat(1.2f, 1.2f, 1.2f);
        }
    }
    
    @Override
    public void z_() {
        GlStateManager.zeroday(0.09375f, 0.1875f, 0.0f);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntitySkeleton entity) {
        return (entity.cb() == 1) ? RenderSkeleton.c : RenderSkeleton.b;
    }
}

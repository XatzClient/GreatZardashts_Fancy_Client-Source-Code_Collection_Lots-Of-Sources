// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerSlimeGel;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntitySlime;

public class RenderSlime extends RenderLiving<EntitySlime>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/slime/slime.png");
    }
    
    public RenderSlime(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerSlimeGel(this));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntitySlime entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        this.sigma = 0.25f * entity.cb();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntitySlime entitylivingbaseIn, final float partialTickTime) {
        final float f = (float)entitylivingbaseIn.cb();
        final float f2 = (entitylivingbaseIn.sigma + (entitylivingbaseIn.zeroday - entitylivingbaseIn.sigma) * partialTickTime) / (f * 0.5f + 1.0f);
        final float f3 = 1.0f / (f2 + 1.0f);
        GlStateManager.zerodayisaminecraftcheat(f3 * f, 1.0f / f3 * f, f3 * f);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntitySlime entity) {
        return RenderSlime.zerodayisaminecraftcheat;
    }
}

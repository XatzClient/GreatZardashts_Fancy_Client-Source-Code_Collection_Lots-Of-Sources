// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerSnowmanHead;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelSnowMan;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntitySnowman;

public class RenderSnowMan extends RenderLiving<EntitySnowman>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/snowman.png");
    }
    
    public RenderSnowMan(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelSnowMan(), 0.5f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerSnowmanHead(this));
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntitySnowman entity) {
        return RenderSnowMan.zerodayisaminecraftcheat;
    }
    
    public ModelSnowMan zues() {
        return (ModelSnowMan)super.zeroday();
    }
}

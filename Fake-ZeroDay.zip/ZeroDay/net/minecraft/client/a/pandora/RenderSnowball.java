// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.o.ResourceLocation;
import net.minecraft.c.ItemStack;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.c.Item;
import net.minecraft.vape.Entity;

public class RenderSnowball<T extends Entity> extends Render<T>
{
    protected final Item zerodayisaminecraftcheat;
    private final RenderItem zues;
    
    public RenderSnowball(final RenderManager renderManagerIn, final Item p_i46137_2_, final RenderItem p_i46137_3_) {
        super(renderManagerIn);
        this.zerodayisaminecraftcheat = p_i46137_2_;
        this.zues = p_i46137_3_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final T entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        GlStateManager.s();
        GlStateManager.zerodayisaminecraftcheat(0.5f, 0.5f, 0.5f);
        GlStateManager.zeroday(-RenderManager.momgetthecamera, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(RenderManager.a, 1.0f, 0.0f, 0.0f);
        this.zerodayisaminecraftcheat(TextureMap.zeroday);
        this.zues.zerodayisaminecraftcheat(this.pandora(entity), ItemCameraTransforms.zeroday.flux);
        GlStateManager.t();
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    public ItemStack pandora(final T entityIn) {
        return new ItemStack(this.zerodayisaminecraftcheat, 1, 0);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final Entity entity) {
        return TextureMap.zeroday;
    }
}

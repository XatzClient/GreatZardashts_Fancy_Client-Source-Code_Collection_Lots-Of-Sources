// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerSpiderEyes;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelSpider;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntitySpider;

public class RenderSpider<T extends EntitySpider> extends RenderLiving<T>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/spider/spider.png");
    }
    
    public RenderSpider(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelSpider(), 1.0f);
        this.zerodayisaminecraftcheat(new LayerSpiderEyes(this));
    }
    
    @Override
    protected float zeroday(final T entityLivingBaseIn) {
        return 180.0f;
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final T entity) {
        return RenderSpider.zerodayisaminecraftcheat;
    }
}

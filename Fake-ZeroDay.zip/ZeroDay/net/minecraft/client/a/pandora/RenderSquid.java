// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntitySquid;

public class RenderSquid extends RenderLiving<EntitySquid>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/squid.png");
    }
    
    public RenderSquid(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntitySquid entity) {
        return RenderSquid.zerodayisaminecraftcheat;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntitySquid bat, final float p_77043_2_, final float p_77043_3_, final float partialTicks) {
        final float f = bat.zeroday + (bat.zerodayisaminecraftcheat - bat.zeroday) * partialTicks;
        final float f2 = bat.pandora + (bat.sigma - bat.pandora) * partialTicks;
        GlStateManager.zeroday(0.0f, 0.5f, 0.0f);
        GlStateManager.zeroday(180.0f - p_77043_3_, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(f2, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(0.0f, -1.2f, 0.0f);
    }
    
    protected float zerodayisaminecraftcheat(final EntitySquid livingBase, final float partialTicks) {
        return livingBase.bn + (livingBase.bm - livingBase.bn) * partialTicks;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.a.Blocks;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.vape.pandora.EntityTNTPrimed;

public class RenderTNTPrimed extends Render<EntityTNTPrimed>
{
    public RenderTNTPrimed(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.sigma = 0.5f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityTNTPrimed entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        final BlockRendererDispatcher blockrendererdispatcher = Minecraft.s().X();
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y + 0.5f, (float)z);
        if (entity.zerodayisaminecraftcheat - partialTicks + 1.0f < 10.0f) {
            float f = 1.0f - (entity.zerodayisaminecraftcheat - partialTicks + 1.0f) / 10.0f;
            f = MathHelper.zerodayisaminecraftcheat(f, 0.0f, 1.0f);
            f *= f;
            f *= f;
            final float f2 = 1.0f + f * 0.3f;
            GlStateManager.zerodayisaminecraftcheat(f2, f2, f2);
        }
        final float f3 = (1.0f - (entity.zerodayisaminecraftcheat - partialTicks + 1.0f) / 100.0f) * 0.8f;
        this.sigma(entity);
        GlStateManager.zeroday(-0.5f, -0.5f, 0.5f);
        blockrendererdispatcher.zerodayisaminecraftcheat(Blocks.O.G(), entity.zeroday(partialTicks));
        GlStateManager.zeroday(0.0f, 0.0f, 1.0f);
        if (entity.zerodayisaminecraftcheat / 5 % 2 == 0) {
            GlStateManager.n();
            GlStateManager.flux();
            GlStateManager.d();
            GlStateManager.zeroday(770, 772);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, f3);
            GlStateManager.zerodayisaminecraftcheat(-3.0f, -3.0f);
            GlStateManager.i();
            blockrendererdispatcher.zerodayisaminecraftcheat(Blocks.O.G(), 1.0f);
            GlStateManager.zerodayisaminecraftcheat(0.0f, 0.0f);
            GlStateManager.j();
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.c();
            GlStateManager.zues();
            GlStateManager.m();
        }
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityTNTPrimed entity) {
        return TextureMap.zeroday;
    }
}

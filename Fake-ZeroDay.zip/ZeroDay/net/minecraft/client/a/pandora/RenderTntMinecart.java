// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.pandora.EntityMinecart;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.a.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.MathHelper;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.vape.pandora.EntityMinecartTNT;

public class RenderTntMinecart extends RenderMinecart<EntityMinecartTNT>
{
    public RenderTntMinecart(final RenderManager renderManagerIn) {
        super(renderManagerIn);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityMinecartTNT minecart, final float partialTicks, final IBlockState state) {
        final int i = minecart.t();
        if (i > -1 && i - partialTicks + 1.0f < 10.0f) {
            float f = 1.0f - (i - partialTicks + 1.0f) / 10.0f;
            f = MathHelper.zerodayisaminecraftcheat(f, 0.0f, 1.0f);
            f *= f;
            f *= f;
            final float f2 = 1.0f + f * 0.3f;
            GlStateManager.zerodayisaminecraftcheat(f2, f2, f2);
        }
        super.zerodayisaminecraftcheat(minecart, partialTicks, state);
        if (i > -1 && i / 5 % 2 == 0) {
            final BlockRendererDispatcher blockrendererdispatcher = Minecraft.s().X();
            GlStateManager.n();
            GlStateManager.flux();
            GlStateManager.d();
            GlStateManager.zeroday(770, 772);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, (1.0f - (i - partialTicks + 1.0f) / 100.0f) * 0.8f);
            GlStateManager.v();
            blockrendererdispatcher.zerodayisaminecraftcheat(Blocks.O.G(), 1.0f);
            GlStateManager.w();
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.c();
            GlStateManager.zues();
            GlStateManager.m();
        }
    }
}

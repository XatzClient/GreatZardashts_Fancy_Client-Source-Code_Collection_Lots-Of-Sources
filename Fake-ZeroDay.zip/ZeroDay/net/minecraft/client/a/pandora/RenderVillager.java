// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerCustomHead;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelVillager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityVillager;

public class RenderVillager extends RenderLiving<EntityVillager>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    private static final ResourceLocation d;
    private static final ResourceLocation e;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/villager/villager.png");
        zues = new ResourceLocation("textures/entity/villager/farmer.png");
        b = new ResourceLocation("textures/entity/villager/librarian.png");
        c = new ResourceLocation("textures/entity/villager/priest.png");
        d = new ResourceLocation("textures/entity/villager/smith.png");
        e = new ResourceLocation("textures/entity/villager/butcher.png");
    }
    
    public RenderVillager(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelVillager(0.0f), 0.5f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerCustomHead(this.zues().zerodayisaminecraftcheat));
    }
    
    public ModelVillager zues() {
        return (ModelVillager)super.zeroday();
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityVillager entity) {
        switch (entity.ca()) {
            case 0: {
                return RenderVillager.zues;
            }
            case 1: {
                return RenderVillager.b;
            }
            case 2: {
                return RenderVillager.c;
            }
            case 3: {
                return RenderVillager.d;
            }
            case 4: {
                return RenderVillager.e;
            }
            default: {
                return RenderVillager.zerodayisaminecraftcheat;
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityVillager entitylivingbaseIn, final float partialTickTime) {
        float f = 0.9375f;
        if (entitylivingbaseIn.vape() < 0) {
            f *= 0.5;
            this.sigma = 0.25f;
        }
        else {
            this.sigma = 0.5f;
        }
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
    }
}

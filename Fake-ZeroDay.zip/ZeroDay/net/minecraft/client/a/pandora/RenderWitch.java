// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItemWitch;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelWitch;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityWitch;

public class RenderWitch extends RenderLiving<EntityWitch>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/witch.png");
    }
    
    public RenderWitch(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelWitch(0.0f), 0.5f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldItemWitch(this));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityWitch entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        ((ModelWitch)this.flux).e = (entity.aZ() != null);
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityWitch entity) {
        return RenderWitch.zerodayisaminecraftcheat;
    }
    
    @Override
    public void z_() {
        GlStateManager.zeroday(0.0f, 0.1875f, 0.0f);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityWitch entitylivingbaseIn, final float partialTickTime) {
        final float f = 0.9375f;
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.zeroday.IBossDisplayData;
import net.minecraft.vape.zeroday.BossStatus;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerWitherAura;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.pandora.ModelWither;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zeroday.EntityWither;

public class RenderWither extends RenderLiving<EntityWither>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/wither/wither_invulnerable.png");
        zues = new ResourceLocation("textures/entity/wither/wither.png");
    }
    
    public RenderWither(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelWither(0.0f), 1.0f);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerWitherAura(this));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityWither entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        BossStatus.zerodayisaminecraftcheat(entity, true);
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityWither entity) {
        final int i = entity.ca();
        return (i > 0 && (i > 80 || i / 5 % 2 != 1)) ? RenderWither.zerodayisaminecraftcheat : RenderWither.zues;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityWither entitylivingbaseIn, final float partialTickTime) {
        float f = 2.0f;
        final int i = entitylivingbaseIn.ca();
        if (i > 0) {
            f -= (i - partialTickTime) / 220.0f * 0.5f;
        }
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
    }
}

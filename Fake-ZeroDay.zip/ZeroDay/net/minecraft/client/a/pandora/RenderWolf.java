// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLiving;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerWolfCollar;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityWolf;

public class RenderWolf extends RenderLiving<EntityWolf>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zues;
    private static final ResourceLocation b;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/wolf/wolf.png");
        zues = new ResourceLocation("textures/entity/wolf/wolf_tame.png");
        b = new ResourceLocation("textures/entity/wolf/wolf_angry.png");
    }
    
    public RenderWolf(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn, modelBaseIn, shadowSizeIn);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerWolfCollar(this));
    }
    
    protected float zerodayisaminecraftcheat(final EntityWolf livingBase, final float partialTicks) {
        return livingBase.cj();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityWolf entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (entity.cd()) {
            final float f = entity.zeroday(partialTicks) * entity.g(partialTicks);
            GlStateManager.sigma(f, f, f);
        }
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityWolf entity) {
        return entity.cf() ? RenderWolf.zues : (entity.ck() ? RenderWolf.b : RenderWolf.zerodayisaminecraftcheat);
    }
}

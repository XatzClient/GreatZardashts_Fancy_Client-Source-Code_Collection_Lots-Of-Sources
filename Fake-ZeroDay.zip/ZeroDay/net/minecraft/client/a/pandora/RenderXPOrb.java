// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.l.CustomColorizer;
import net.minecraft.l.Config;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.pandora.EntityXPOrb;
import net.minecraft.o.ResourceLocation;

public class RenderXPOrb extends Render
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final String zues = "CL_00000993";
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/experience_orb.png");
    }
    
    public RenderXPOrb(final RenderManager renderManagerIn) {
        super(renderManagerIn);
        this.sigma = 0.15f;
        this.pandora = 0.75f;
    }
    
    public void zerodayisaminecraftcheat(final EntityXPOrb entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        GlStateManager.v();
        GlStateManager.zeroday((float)x, (float)y, (float)z);
        this.sigma(entity);
        final int i = entity.momgetthecamera();
        final float f = (i % 4 * 16 + 0) / 64.0f;
        final float f2 = (i % 4 * 16 + 16) / 64.0f;
        final float f3 = (i / 4 * 16 + 0) / 64.0f;
        final float f4 = (i / 4 * 16 + 16) / 64.0f;
        final float f5 = 1.0f;
        final float f6 = 0.5f;
        final float f7 = 0.25f;
        final int j = entity.zerodayisaminecraftcheat(partialTicks);
        final int k = j % 65536;
        int l = j / 65536;
        OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, k / 1.0f, l / 1.0f);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        final float f8 = 255.0f;
        final float f9 = (entity.zerodayisaminecraftcheat + partialTicks) / 2.0f;
        l = (int)((MathHelper.zerodayisaminecraftcheat(f9 + 0.0f) + 1.0f) * 0.5f * 255.0f);
        final boolean flag = true;
        final int i2 = (int)((MathHelper.zerodayisaminecraftcheat(f9 + 4.1887903f) + 1.0f) * 0.1f * 255.0f);
        GlStateManager.zeroday(180.0f - RenderManager.momgetthecamera, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(-RenderManager.a, 1.0f, 0.0f, 0.0f);
        final float f10 = 0.3f;
        GlStateManager.zerodayisaminecraftcheat(0.3f, 0.3f, 0.3f);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.d);
        int j2 = l;
        int k2 = 255;
        int l2 = i2;
        if (Config.at()) {
            final int i3 = CustomColorizer.zerodayisaminecraftcheat(f9);
            if (i3 >= 0) {
                j2 = (i3 >> 16 & 0xFF);
                k2 = (i3 >> 8 & 0xFF);
                l2 = (i3 >> 0 & 0xFF);
            }
        }
        worldrenderer.zeroday(0.0f - f6, 0.0f - f7, 0.0).zerodayisaminecraftcheat(f, f4).zeroday(j2, k2, l2, 128).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(f5 - f6, 0.0f - f7, 0.0).zerodayisaminecraftcheat(f2, f4).zeroday(j2, k2, l2, 128).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(f5 - f6, 1.0f - f7, 0.0).zerodayisaminecraftcheat(f2, f3).zeroday(j2, k2, l2, 128).sigma(0.0f, 1.0f, 0.0f).zues();
        worldrenderer.zeroday(0.0f - f6, 1.0f - f7, 0.0).zerodayisaminecraftcheat(f, f3).zeroday(j2, k2, l2, 128).sigma(0.0f, 1.0f, 0.0f).zues();
        tessellator.zeroday();
        GlStateManager.c();
        GlStateManager.t();
        GlStateManager.w();
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    protected ResourceLocation zerodayisaminecraftcheat(final EntityXPOrb entity) {
        return RenderXPOrb.zerodayisaminecraftcheat;
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final Entity entity) {
        return this.zerodayisaminecraftcheat((EntityXPOrb)entity);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        this.zerodayisaminecraftcheat((EntityXPOrb)entity, x, y, z, entityYaw, partialTicks);
    }
}

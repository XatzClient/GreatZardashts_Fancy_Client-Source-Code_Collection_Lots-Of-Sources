// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.EntityLiving;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerVillagerArmor;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerCustomHead;
import com.google.common.collect.Lists;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerBipedArmor;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerHeldItem;
import net.minecraft.client.pandora.ModelZombie;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerRenderer;
import java.util.List;
import net.minecraft.client.pandora.ModelZombieVillager;
import net.minecraft.client.pandora.ModelBiped;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityZombie;

public class RenderZombie extends RenderBiped<EntityZombie>
{
    private static final ResourceLocation b;
    private static final ResourceLocation c;
    private final ModelBiped d;
    private final ModelZombieVillager e;
    private final List<LayerRenderer<EntityZombie>> f;
    private final List<LayerRenderer<EntityZombie>> g;
    
    static {
        b = new ResourceLocation("textures/entity/zombie/zombie.png");
        c = new ResourceLocation("textures/entity/zombie/zombie_villager.png");
    }
    
    public RenderZombie(final RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelZombie(), 0.5f, 1.0f);
        final LayerRenderer layerrenderer = this.momgetthecamera.get(0);
        this.d = this.zerodayisaminecraftcheat;
        this.e = new ModelZombieVillager();
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerHeldItem(this));
        final LayerBipedArmor layerbipedarmor = new LayerBipedArmor(this) {
            @Override
            protected void zerodayisaminecraftcheat() {
                this.sigma = (T)new ModelZombie(0.5f, true);
                this.pandora = (T)new ModelZombie(1.0f, true);
            }
        };
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(layerbipedarmor);
        this.g = (List<LayerRenderer<EntityZombie>>)Lists.newArrayList((Iterable)this.momgetthecamera);
        if (layerrenderer instanceof LayerCustomHead) {
            ((RendererLivingEntity<EntityLivingBase>)this).zeroday(layerrenderer);
            ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerCustomHead(this.e.c));
        }
        ((RendererLivingEntity<EntityLivingBase>)this).zeroday(layerbipedarmor);
        ((RendererLivingEntity<EntityLivingBase>)this).zerodayisaminecraftcheat(new LayerVillagerArmor(this));
        this.f = (List<LayerRenderer<EntityZombie>>)Lists.newArrayList((Iterable)this.momgetthecamera);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityZombie entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        this.zeroday(entity);
        super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
    }
    
    @Override
    protected ResourceLocation zerodayisaminecraftcheat(final EntityZombie entity) {
        return entity.cd() ? RenderZombie.c : RenderZombie.b;
    }
    
    private void zeroday(final EntityZombie zombie) {
        if (zombie.cd()) {
            this.flux = this.e;
            this.momgetthecamera = (List<LayerRenderer<T>>)this.f;
        }
        else {
            this.flux = this.d;
            this.momgetthecamera = (List<LayerRenderer<T>>)this.g;
        }
        this.zerodayisaminecraftcheat = (ModelBiped)this.flux;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final EntityZombie bat, final float p_77043_2_, float p_77043_3_, final float partialTicks) {
        if (bat.ce()) {
            p_77043_3_ += (float)(Math.cos(bat.X * 3.25) * 3.141592653589793 * 0.25);
        }
        super.zerodayisaminecraftcheat(bat, p_77043_2_, p_77043_3_, partialTicks);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora;

import net.minecraft.j.Team;
import net.minecraft.client.zeroday.EntityPlayerSP;
import zeroday.pandora.zerodayisaminecraftcheat.d.aD;
import zeroday.pandora.zerodayisaminecraftcheat.d.aw;
import java.util.Iterator;
import net.minecraft.vape.vape.EnumPlayerModelParts;
import net.minecraft.o.EnumChatFormatting;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.z;
import net.minecraft.client.sigma.FontRenderer;
import net.minecraft.j.ScorePlayerTeam;
import net.minecraft.client.a.OpenGlHelper;
import zeroday.pandora.zerodayisaminecraftcheat.h.O;
import net.minecraft.client.Minecraft;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.m;
import zeroday.pandora.zerodayisaminecraftcheat.d.aJ;
import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import org.lwjgl.opengl.GL11;
import zeroday.pandora.zerodayisaminecraftcheat.d.p;
import net.minecraft.vape.vape.EntityPlayer;
import com.google.common.collect.Lists;
import net.minecraft.client.a.GLAllocation;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.a.pandora.zerodayisaminecraftcheat.LayerRenderer;
import java.util.List;
import java.nio.FloatBuffer;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.a.zues.DynamicTexture;
import org.apache.logging.log4j.Logger;
import net.minecraft.vape.EntityLivingBase;

public abstract class RendererLivingEntity<T extends EntityLivingBase> extends Render<T>
{
    private static final Logger zerodayisaminecraftcheat;
    private static final DynamicTexture zues;
    protected ModelBase flux;
    protected FloatBuffer vape;
    protected List<LayerRenderer<T>> momgetthecamera;
    protected boolean a;
    private static /* synthetic */ int[] b;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
        zues = new DynamicTexture(16, 16);
        final int[] aint = RendererLivingEntity.zues.sigma();
        for (int i = 0; i < 256; ++i) {
            aint[i] = -1;
        }
        RendererLivingEntity.zues.zeroday();
    }
    
    public RendererLivingEntity(final RenderManager renderManagerIn, final ModelBase modelBaseIn, final float shadowSizeIn) {
        super(renderManagerIn);
        this.vape = GLAllocation.zues(4);
        this.momgetthecamera = (List<LayerRenderer<T>>)Lists.newArrayList();
        this.a = false;
        this.flux = modelBaseIn;
        this.sigma = shadowSizeIn;
    }
    
    public <V extends EntityLivingBase, U extends LayerRenderer<V>> boolean zerodayisaminecraftcheat(final U layer) {
        return this.momgetthecamera.add((LayerRenderer<T>)layer);
    }
    
    protected <V extends EntityLivingBase, U extends LayerRenderer<V>> boolean zeroday(final U layer) {
        return this.momgetthecamera.remove(layer);
    }
    
    public ModelBase zeroday() {
        return this.flux;
    }
    
    protected float zerodayisaminecraftcheat(final float par1, final float par2, final float par3) {
        float f;
        for (f = par2 - par1; f < -180.0f; f += 360.0f) {}
        while (f >= 180.0f) {
            f -= 360.0f;
        }
        return par1 + par3 * f;
    }
    
    public void z_() {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final T entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (entity instanceof EntityPlayer && p.c) {
            GL11.glEnable(32823);
            GL11.glPolygonOffset(1.0f, -1000000.0f);
        }
        GlStateManager.v();
        GlStateManager.h();
        this.flux.zues = this.pandora(entity, partialTicks);
        this.flux.flux = entity.an();
        this.flux.vape = entity.n_();
        try {
            float f = this.zerodayisaminecraftcheat(entity.aM, entity.aL, partialTicks);
            final float f2 = this.zerodayisaminecraftcheat(entity.aO, entity.aN, partialTicks);
            float f3 = f2 - f;
            if (entity.an() && entity.m instanceof EntityLivingBase) {
                final EntityLivingBase entitylivingbase = (EntityLivingBase)entity.m;
                f = this.zerodayisaminecraftcheat(entitylivingbase.aM, entitylivingbase.aL, partialTicks);
                f3 = f2 - f;
                float f4 = MathHelper.vape(f3);
                if (f4 < -85.0f) {
                    f4 = -85.0f;
                }
                if (f4 >= 85.0f) {
                    f4 = 85.0f;
                }
                f = f2 - f4;
                if (f4 * f4 > 2500.0f) {
                    f += f4 * 0.2f;
                }
            }
            final float f5 = entity.B + (entity.z - entity.B) * partialTicks;
            this.zerodayisaminecraftcheat(entity, x, y, z);
            final float f6 = this.zeroday(entity, partialTicks);
            this.zerodayisaminecraftcheat(entity, f6, f, partialTicks);
            GlStateManager.s();
            GlStateManager.zerodayisaminecraftcheat(-1.0f, -1.0f, 1.0f);
            this.zerodayisaminecraftcheat(entity, partialTicks);
            final float f7 = 0.0625f;
            GlStateManager.zeroday(0.0f, -1.5078125f, 0.0f);
            float f8 = entity.aD + (entity.aE - entity.aD) * partialTicks;
            float f9 = entity.aF - entity.aE * (1.0f - partialTicks);
            if (entity.n_()) {
                f9 *= 3.0f;
            }
            if (f8 > 1.0f) {
                f8 = 1.0f;
            }
            GlStateManager.pandora();
            this.flux.zerodayisaminecraftcheat(entity, f9, f8, partialTicks);
            this.flux.zerodayisaminecraftcheat(f9, f8, f6, f3, f5, 0.0625f, entity);
            if (this.a) {
                final boolean flag1 = this.sigma(entity);
                this.zerodayisaminecraftcheat(entity, f9, f8, f6, f3, f5, 0.0625f);
                if (flag1) {
                    this.flux();
                }
            }
            else {
                final boolean flag2 = this.sigma(entity, partialTicks);
                this.zerodayisaminecraftcheat(entity, f9, f8, f6, f3, f5, 0.0625f);
                if (flag2) {
                    this.vape();
                }
                GlStateManager.zerodayisaminecraftcheat(true);
                if (!(entity instanceof EntityPlayer) || !((EntityPlayer)entity).h_()) {
                    this.zerodayisaminecraftcheat(entity, f9, f8, partialTicks, f6, f3, f5, 0.0625f);
                }
            }
            if (aJ.c && m.sigma && entity != Minecraft.s().e && entity instanceof EntityPlayer && !entity.bS()) {
                this.zerodayisaminecraftcheat(entity, f9, f8, f6, f3, f5, 0.0625f);
                O.zerodayisaminecraftcheat();
                this.zerodayisaminecraftcheat(entity, f9, f8, f6, f3, f5, 0.0625f);
                O.zeroday();
                this.zerodayisaminecraftcheat(entity, f9, f8, f6, f3, f5, 0.0625f);
                O.sigma();
                O.zerodayisaminecraftcheat(entity);
                this.zerodayisaminecraftcheat(entity, f9, f8, f6, f3, f5, 0.0625f);
                O.pandora();
            }
            GlStateManager.t();
        }
        catch (Exception exception) {
            RendererLivingEntity.zerodayisaminecraftcheat.error("Couldn't render entity", (Throwable)exception);
        }
        GlStateManager.vape(OpenGlHelper.j);
        GlStateManager.m();
        GlStateManager.vape(OpenGlHelper.i);
        GlStateManager.g();
        GlStateManager.w();
        if (entity instanceof EntityPlayer && p.c) {
            GL11.glEnable(32823);
            GL11.glPolygonOffset(1.0f, -1000000.0f);
        }
        if (!this.a) {
            super.zerodayisaminecraftcheat(entity, x, y, z, entityYaw, partialTicks);
        }
    }
    
    @Override
    protected boolean sigma(final T entityLivingBaseIn) {
        int i = 16777215;
        if (entityLivingBaseIn instanceof EntityPlayer) {
            final ScorePlayerTeam scoreplayerteam = (ScorePlayerTeam)entityLivingBaseIn.bW();
            if (scoreplayerteam != null) {
                final String s = FontRenderer.zeroday(scoreplayerteam.pandora());
                if (s.length() >= 2) {
                    i = this.sigma().zeroday(s.charAt(1));
                }
            }
        }
        final float f1 = (i >> 16 & 0xFF) / 255.0f;
        final float f2 = (i >> 8 & 0xFF) / 255.0f;
        final float f3 = (i & 0xFF) / 255.0f;
        GlStateManager.flux();
        GlStateManager.vape(OpenGlHelper.i);
        GlStateManager.sigma(f1, f2, f3, 1.0f);
        GlStateManager.n();
        GlStateManager.vape(OpenGlHelper.j);
        GlStateManager.n();
        GlStateManager.vape(OpenGlHelper.i);
        return true;
    }
    
    protected void flux() {
        GlStateManager.zues();
        GlStateManager.vape(OpenGlHelper.i);
        GlStateManager.m();
        GlStateManager.vape(OpenGlHelper.j);
        GlStateManager.m();
        GlStateManager.vape(OpenGlHelper.i);
    }
    
    protected void zerodayisaminecraftcheat(final T entitylivingbaseIn, final float p_77036_2_, final float p_77036_3_, final float p_77036_4_, final float p_77036_5_, final float p_77036_6_, final float p_77036_7_) {
        final boolean flag = !entitylivingbaseIn.ap();
        final boolean flag2 = !flag && !entitylivingbaseIn.sigma(Minecraft.s().e);
        if (flag || flag2) {
            if (!this.sigma(entitylivingbaseIn)) {
                return;
            }
            if (flag2) {
                GlStateManager.v();
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 0.15f);
                GlStateManager.zerodayisaminecraftcheat(false);
                GlStateManager.d();
                GlStateManager.zeroday(770, 771);
                GlStateManager.zerodayisaminecraftcheat(516, 0.003921569f);
            }
            this.flux.zerodayisaminecraftcheat(entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, p_77036_7_);
            if (flag2) {
                GlStateManager.c();
                GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
                GlStateManager.w();
                GlStateManager.zerodayisaminecraftcheat(true);
            }
        }
    }
    
    protected boolean sigma(final T entityLivingBaseIn, final float partialTicks) {
        return this.zerodayisaminecraftcheat(entityLivingBaseIn, partialTicks, true);
    }
    
    protected boolean zerodayisaminecraftcheat(final T entitylivingbaseIn, final float partialTicks, final boolean combineTextures) {
        final float f = entitylivingbaseIn.zeroday(partialTicks);
        final int i = this.zerodayisaminecraftcheat(entitylivingbaseIn, f, partialTicks);
        final boolean flag = (i >> 24 & 0xFF) > 0;
        final boolean flag2 = entitylivingbaseIn.ax > 0 || entitylivingbaseIn.aA > 0;
        if (!flag && !flag2) {
            return false;
        }
        if (!flag && !combineTextures) {
            return false;
        }
        GlStateManager.vape(OpenGlHelper.i);
        GlStateManager.m();
        GL11.glTexEnvi(8960, 8704, OpenGlHelper.l);
        GL11.glTexEnvi(8960, OpenGlHelper.q, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.r, OpenGlHelper.i);
        GL11.glTexEnvi(8960, OpenGlHelper.s, OpenGlHelper.n);
        GL11.glTexEnvi(8960, OpenGlHelper.u, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.v, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.x, 7681);
        GL11.glTexEnvi(8960, OpenGlHelper.y, OpenGlHelper.i);
        GL11.glTexEnvi(8960, OpenGlHelper.B, 770);
        GlStateManager.vape(OpenGlHelper.j);
        GlStateManager.m();
        GL11.glTexEnvi(8960, 8704, OpenGlHelper.l);
        GL11.glTexEnvi(8960, OpenGlHelper.q, OpenGlHelper.m);
        GL11.glTexEnvi(8960, OpenGlHelper.r, OpenGlHelper.o);
        GL11.glTexEnvi(8960, OpenGlHelper.s, OpenGlHelper.p);
        GL11.glTexEnvi(8960, OpenGlHelper.t, OpenGlHelper.o);
        GL11.glTexEnvi(8960, OpenGlHelper.u, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.v, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.w, 770);
        GL11.glTexEnvi(8960, OpenGlHelper.x, 7681);
        GL11.glTexEnvi(8960, OpenGlHelper.y, OpenGlHelper.p);
        GL11.glTexEnvi(8960, OpenGlHelper.B, 770);
        this.vape.position(0);
        if (flag2) {
            if (!z.zeroday) {
                this.vape.put(1.0f);
                this.vape.put(0.0f);
                this.vape.put(0.0f);
                this.vape.put(0.5f);
            }
            else {
                this.vape.put(1.0f);
                this.vape.put(0.0f);
                this.vape.put(0.0f);
                this.vape.put(0.3f);
            }
        }
        else {
            final float f2 = (i >> 24 & 0xFF) / 255.0f;
            final float f3 = (i >> 16 & 0xFF) / 255.0f;
            final float f4 = (i >> 8 & 0xFF) / 255.0f;
            final float f5 = (i & 0xFF) / 255.0f;
            this.vape.put(f3);
            this.vape.put(f4);
            this.vape.put(f5);
            this.vape.put(1.0f - f2);
        }
        this.vape.flip();
        GL11.glTexEnv(8960, 8705, this.vape);
        GlStateManager.vape(OpenGlHelper.k);
        GlStateManager.m();
        GlStateManager.a(RendererLivingEntity.zues.zerodayisaminecraftcheat());
        GL11.glTexEnvi(8960, 8704, OpenGlHelper.l);
        GL11.glTexEnvi(8960, OpenGlHelper.q, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.r, OpenGlHelper.p);
        GL11.glTexEnvi(8960, OpenGlHelper.s, OpenGlHelper.j);
        GL11.glTexEnvi(8960, OpenGlHelper.u, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.v, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.x, 7681);
        GL11.glTexEnvi(8960, OpenGlHelper.y, OpenGlHelper.p);
        GL11.glTexEnvi(8960, OpenGlHelper.B, 770);
        GlStateManager.vape(OpenGlHelper.i);
        return true;
    }
    
    protected void vape() {
        GlStateManager.vape(OpenGlHelper.i);
        GlStateManager.m();
        GL11.glTexEnvi(8960, 8704, OpenGlHelper.l);
        GL11.glTexEnvi(8960, OpenGlHelper.q, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.r, OpenGlHelper.i);
        GL11.glTexEnvi(8960, OpenGlHelper.s, OpenGlHelper.n);
        GL11.glTexEnvi(8960, OpenGlHelper.u, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.v, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.x, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.y, OpenGlHelper.i);
        GL11.glTexEnvi(8960, OpenGlHelper.z, OpenGlHelper.n);
        GL11.glTexEnvi(8960, OpenGlHelper.B, 770);
        GL11.glTexEnvi(8960, OpenGlHelper.C, 770);
        GlStateManager.vape(OpenGlHelper.j);
        GL11.glTexEnvi(8960, 8704, OpenGlHelper.l);
        GL11.glTexEnvi(8960, OpenGlHelper.q, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.u, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.v, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.r, 5890);
        GL11.glTexEnvi(8960, OpenGlHelper.s, OpenGlHelper.p);
        GL11.glTexEnvi(8960, OpenGlHelper.x, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.B, 770);
        GL11.glTexEnvi(8960, OpenGlHelper.y, 5890);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.vape(OpenGlHelper.k);
        GlStateManager.n();
        GlStateManager.a(0);
        GL11.glTexEnvi(8960, 8704, OpenGlHelper.l);
        GL11.glTexEnvi(8960, OpenGlHelper.q, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.u, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.v, 768);
        GL11.glTexEnvi(8960, OpenGlHelper.r, 5890);
        GL11.glTexEnvi(8960, OpenGlHelper.s, OpenGlHelper.p);
        GL11.glTexEnvi(8960, OpenGlHelper.x, 8448);
        GL11.glTexEnvi(8960, OpenGlHelper.B, 770);
        GL11.glTexEnvi(8960, OpenGlHelper.y, 5890);
        GlStateManager.vape(OpenGlHelper.i);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final T entityLivingBaseIn, final double x, final double y, final double z) {
        GlStateManager.zeroday((float)x, (float)y, (float)z);
    }
    
    protected void zerodayisaminecraftcheat(final T bat, final float p_77043_2_, final float p_77043_3_, final float partialTicks) {
        GlStateManager.zeroday(180.0f - p_77043_3_, 0.0f, 1.0f, 0.0f);
        if (bat.aA > 0) {
            float f = (bat.aA + partialTicks - 1.0f) / 20.0f * 1.6f;
            f = MathHelper.sigma(f);
            if (f > 1.0f) {
                f = 1.0f;
            }
            GlStateManager.zeroday(f * this.zeroday(bat), 0.0f, 0.0f, 1.0f);
        }
        else {
            final String s = EnumChatFormatting.zerodayisaminecraftcheat(bat.l_());
            if (s != null && (s.equals("Dinnerbone") || s.equals("Grumm")) && (!(bat instanceof EntityPlayer) || ((EntityPlayer)bat).zerodayisaminecraftcheat(EnumPlayerModelParts.zerodayisaminecraftcheat))) {
                GlStateManager.zeroday(0.0f, bat.L + 0.1f, 0.0f);
                GlStateManager.zeroday(180.0f, 0.0f, 0.0f, 1.0f);
            }
        }
    }
    
    protected float pandora(final T livingBase, final float partialTickTime) {
        return livingBase.e(partialTickTime);
    }
    
    protected float zeroday(final T livingBase, final float partialTicks) {
        return livingBase.X + partialTicks;
    }
    
    protected void zerodayisaminecraftcheat(final T entitylivingbaseIn, final float p_177093_2_, final float p_177093_3_, final float partialTicks, final float p_177093_5_, final float p_177093_6_, final float p_177093_7_, final float p_177093_8_) {
        for (final LayerRenderer<T> layerrenderer : this.momgetthecamera) {
            final boolean flag = this.zerodayisaminecraftcheat(entitylivingbaseIn, partialTicks, layerrenderer.zeroday());
            layerrenderer.zerodayisaminecraftcheat(entitylivingbaseIn, p_177093_2_, p_177093_3_, partialTicks, p_177093_5_, p_177093_6_, p_177093_7_, p_177093_8_);
            if (flag) {
                this.vape();
            }
        }
    }
    
    protected float zeroday(final T entityLivingBaseIn) {
        return 90.0f;
    }
    
    protected int zerodayisaminecraftcheat(final T entitylivingbaseIn, final float lightBrightness, final float partialTickTime) {
        return 0;
    }
    
    protected void zerodayisaminecraftcheat(final T entitylivingbaseIn, final float partialTickTime) {
    }
    
    public void zeroday(final T entity, final double x, final double y, final double z) {
        if ((entity instanceof EntityPlayer && aw.c) || (entity instanceof EntityPlayer && aD.c)) {
            return;
        }
        if (this.zerodayisaminecraftcheat(entity)) {
            final double d0 = entity.zues(this.zeroday.flux);
            final float f = entity.y() ? 32.0f : 64.0f;
            if (d0 < f * f) {
                final String color = (entity.by() > 14.0f) ? " | �a" : ((entity.by() > 8.0f) ? " | �6" : " | �4");
                final int distance = (int)entity.pandora(Minecraft.s().e);
                final String s = entity.sigma().a();
                final float f2 = 0.02666667f;
                GlStateManager.zerodayisaminecraftcheat(516, 0.1f);
                this.zerodayisaminecraftcheat(entity, x, y - (entity.n_() ? (entity.L / 2.0f) : 0.0), z, s, 0.02666667f, d0);
            }
        }
    }
    
    protected boolean zerodayisaminecraftcheat(final T entity) {
        final EntityPlayerSP entityplayersp = Minecraft.s().e;
        if (entity instanceof EntityPlayer && entity != entityplayersp) {
            final Team team = entity.bW();
            final Team team2 = entityplayersp.bW();
            if (team != null) {
                final Team.zerodayisaminecraftcheat team$enumvisible = team.momgetthecamera();
                switch (momgetthecamera()[team$enumvisible.ordinal()]) {
                    case 1: {
                        return true;
                    }
                    case 2: {
                        return false;
                    }
                    case 3: {
                        return team2 == null || team.zerodayisaminecraftcheat(team2);
                    }
                    case 4: {
                        return team2 == null || !team.zerodayisaminecraftcheat(team2);
                    }
                    default: {
                        return true;
                    }
                }
            }
        }
        return Minecraft.p() && entity != this.zeroday.flux && !entity.sigma(entityplayersp) && entity.l == null;
    }
    
    public void zerodayisaminecraftcheat(final boolean renderOutlinesIn) {
        this.a = renderOutlinesIn;
    }
    
    static /* synthetic */ int[] momgetthecamera() {
        final int[] b = RendererLivingEntity.b;
        if (b != null) {
            return b;
        }
        final int[] b2 = new int[Team.zerodayisaminecraftcheat.values().length];
        try {
            b2[Team.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            b2[Team.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            b2[Team.zerodayisaminecraftcheat.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            b2[Team.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        return RendererLivingEntity.b = b2;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import sigma.zerodayisaminecraftcheat.k;
import sigma.zerodayisaminecraftcheat.j;
import net.minecraft.c.ItemStack;
import net.minecraft.l.CustomItems;
import net.minecraft.l.Config;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.l.Reflector;
import net.minecraft.c.ItemArmor;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.client.a.pandora.RendererLivingEntity;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.pandora.ModelBase;

public abstract class LayerArmorBase<T extends ModelBase> implements LayerRenderer<EntityLivingBase>
{
    protected static final ResourceLocation zeroday;
    protected T sigma;
    protected T pandora;
    private final RendererLivingEntity zerodayisaminecraftcheat;
    private float zues;
    private float flux;
    private float vape;
    private float momgetthecamera;
    private boolean a;
    private static final Map b;
    private static final String c = "CL_00002428";
    
    static {
        zeroday = new ResourceLocation("textures/misc/enchanted_item_glint.png");
        b = Maps.newHashMap();
    }
    
    public LayerArmorBase(final RendererLivingEntity rendererIn) {
        this.zues = 1.0f;
        this.flux = 1.0f;
        this.vape = 1.0f;
        this.momgetthecamera = 1.0f;
        this.zerodayisaminecraftcheat = rendererIn;
        this.zerodayisaminecraftcheat();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        this.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale, 4);
        this.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale, 3);
        this.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale, 2);
        this.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale, 1);
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
    
    private void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177182_2_, final float p_177182_3_, final float p_177182_4_, final float p_177182_5_, final float p_177182_6_, final float p_177182_7_, final float p_177182_8_, final int armorSlot) {
        final ItemStack itemstack = this.zerodayisaminecraftcheat(entitylivingbaseIn, armorSlot);
        if (itemstack != null && itemstack.zerodayisaminecraftcheat() instanceof ItemArmor) {
            final ItemArmor itemarmor = (ItemArmor)itemstack.zerodayisaminecraftcheat();
            T modelbase = this.zerodayisaminecraftcheat(armorSlot);
            modelbase.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zeroday());
            modelbase.zerodayisaminecraftcheat(entitylivingbaseIn, p_177182_2_, p_177182_3_, p_177182_4_);
            if (Reflector.g.zeroday()) {
                modelbase = (T)this.zerodayisaminecraftcheat(entitylivingbaseIn, itemstack, armorSlot, modelbase);
            }
            this.zerodayisaminecraftcheat(modelbase, armorSlot);
            final boolean flag = this.zeroday(armorSlot);
            if (Reflector.x.zeroday()) {
                final int j = itemarmor.d(itemstack);
                if (j != -1) {
                    final float f3 = (j >> 16 & 0xFF) / 255.0f;
                    final float f4 = (j >> 8 & 0xFF) / 255.0f;
                    final float f5 = (j & 0xFF) / 255.0f;
                    GlStateManager.sigma(this.flux * f3, this.vape * f4, this.momgetthecamera * f5, this.zues);
                    modelbase.zerodayisaminecraftcheat(entitylivingbaseIn, p_177182_2_, p_177182_3_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_);
                    if (!Config.aP() || !CustomItems.zerodayisaminecraftcheat(itemstack, flag ? 2 : 1, "overlay")) {
                        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(entitylivingbaseIn, itemstack, flag ? 2 : 1, "overlay"));
                    }
                }
                else {
                    GlStateManager.sigma(this.flux, this.vape, this.momgetthecamera, this.zues);
                    modelbase.zerodayisaminecraftcheat(entitylivingbaseIn, p_177182_2_, p_177182_3_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_);
                }
                if (!this.a && itemstack.o() && (!Config.aP() || !CustomItems.zerodayisaminecraftcheat(entitylivingbaseIn, itemstack, modelbase, p_177182_2_, p_177182_3_, p_177182_4_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_))) {
                    this.zerodayisaminecraftcheat(entitylivingbaseIn, modelbase, p_177182_2_, p_177182_3_, p_177182_4_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_);
                }
                return;
            }
            if (!Config.aP() || !CustomItems.zerodayisaminecraftcheat(itemstack, flag ? 2 : 1, null)) {
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(itemarmor, flag));
            }
            switch (LayerArmorBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat[itemarmor.j().ordinal()]) {
                case 1: {
                    final int i = itemarmor.d(itemstack);
                    final float f6 = (i >> 16 & 0xFF) / 255.0f;
                    final float f7 = (i >> 8 & 0xFF) / 255.0f;
                    final float f8 = (i & 0xFF) / 255.0f;
                    GlStateManager.sigma(this.flux * f6, this.vape * f7, this.momgetthecamera * f8, this.zues);
                    modelbase.zerodayisaminecraftcheat(entitylivingbaseIn, p_177182_2_, p_177182_3_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_);
                    if (!Config.aP() || !CustomItems.zerodayisaminecraftcheat(itemstack, flag ? 2 : 1, "overlay")) {
                        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(itemarmor, flag, "overlay"));
                    }
                }
                case 2:
                case 3:
                case 4:
                case 5: {
                    GlStateManager.sigma(this.flux, this.vape, this.momgetthecamera, this.zues);
                    modelbase.zerodayisaminecraftcheat(entitylivingbaseIn, p_177182_2_, p_177182_3_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_);
                    break;
                }
            }
            if (!this.a && itemstack.o() && (!Config.aP() || !CustomItems.zerodayisaminecraftcheat(entitylivingbaseIn, itemstack, modelbase, p_177182_2_, p_177182_3_, p_177182_4_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_))) {
                this.zerodayisaminecraftcheat(entitylivingbaseIn, modelbase, p_177182_2_, p_177182_3_, p_177182_4_, p_177182_5_, p_177182_6_, p_177182_7_, p_177182_8_);
            }
        }
    }
    
    public ItemStack zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final int armorSlot) {
        return entitylivingbaseIn.c(armorSlot - 1);
    }
    
    public T zerodayisaminecraftcheat(final int p_177175_1_) {
        return this.zeroday(p_177175_1_) ? this.sigma : this.pandora;
    }
    
    private boolean zeroday(final int armorSlot) {
        return armorSlot == 2;
    }
    
    private void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final T modelbaseIn, final float p_177183_3_, final float p_177183_4_, final float p_177183_5_, final float p_177183_6_, final float p_177183_7_, final float p_177183_8_, final float p_177183_9_) {
        if (Config.aC()) {
            if (j.k) {
                return;
            }
            k.i();
        }
        final float f = entitylivingbaseIn.X + p_177183_5_;
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(LayerArmorBase.zeroday);
        GlStateManager.d();
        GlStateManager.sigma(514);
        GlStateManager.zerodayisaminecraftcheat(false);
        final float f2 = 0.5f;
        GlStateManager.sigma(f2, f2, f2, 1.0f);
        for (int i = 0; i < 2; ++i) {
            GlStateManager.flux();
            GlStateManager.zeroday(768, 1);
            final float f3 = 0.76f;
            GlStateManager.sigma(0.5f * f3, 0.25f * f3, 0.8f * f3, 1.0f);
            GlStateManager.d(5890);
            GlStateManager.u();
            final float f4 = 0.33333334f;
            GlStateManager.zerodayisaminecraftcheat(f4, f4, f4);
            GlStateManager.zeroday(30.0f - i * 60.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.zeroday(0.0f, f * (0.001f + i * 0.003f) * 20.0f, 0.0f);
            GlStateManager.d(5888);
            modelbaseIn.zerodayisaminecraftcheat(entitylivingbaseIn, p_177183_3_, p_177183_4_, p_177183_6_, p_177183_7_, p_177183_8_, p_177183_9_);
        }
        GlStateManager.d(5890);
        GlStateManager.u();
        GlStateManager.d(5888);
        GlStateManager.zues();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.sigma(515);
        GlStateManager.c();
        if (Config.aC()) {
            k.j();
        }
    }
    
    private ResourceLocation zerodayisaminecraftcheat(final ItemArmor p_177181_1_, final boolean p_177181_2_) {
        return this.zerodayisaminecraftcheat(p_177181_1_, p_177181_2_, null);
    }
    
    private ResourceLocation zerodayisaminecraftcheat(final ItemArmor p_177178_1_, final boolean p_177178_2_, final String p_177178_3_) {
        final String s = String.format("textures/models/armor/%s_layer_%d%s.png", p_177178_1_.j().sigma(), p_177178_2_ ? 2 : 1, (p_177178_3_ == null) ? "" : String.format("_%s", p_177178_3_));
        ResourceLocation resourcelocation = LayerArmorBase.b.get(s);
        if (resourcelocation == null) {
            resourcelocation = new ResourceLocation(s);
            LayerArmorBase.b.put(s, resourcelocation);
        }
        return resourcelocation;
    }
    
    protected abstract void zerodayisaminecraftcheat();
    
    protected abstract void zerodayisaminecraftcheat(final T p0, final int p1);
    
    protected ModelBase zerodayisaminecraftcheat(final EntityLivingBase p_getArmorModelHook_1_, final ItemStack p_getArmorModelHook_2_, final int p_getArmorModelHook_3_, final ModelBase p_getArmorModelHook_4_) {
        return p_getArmorModelHook_4_;
    }
    
    public ResourceLocation zerodayisaminecraftcheat(final Entity p_getArmorResource_1_, final ItemStack p_getArmorResource_2_, final int p_getArmorResource_3_, final String p_getArmorResource_4_) {
        final ItemArmor itemarmor = (ItemArmor)p_getArmorResource_2_.zerodayisaminecraftcheat();
        String s = itemarmor.j().sigma();
        String s2 = "minecraft";
        final int i = s.indexOf(58);
        if (i != -1) {
            s2 = s.substring(0, i);
            s = s.substring(i + 1);
        }
        String s3 = String.format("%s:textures/models/armor/%s_layer_%d%s.png", s2, s, (p_getArmorResource_3_ == 2) ? 2 : 1, (p_getArmorResource_4_ == null) ? "" : String.format("_%s", p_getArmorResource_4_));
        s3 = Reflector.flux(Reflector.x, p_getArmorResource_1_, p_getArmorResource_2_, s3, p_getArmorResource_3_, p_getArmorResource_4_);
        ResourceLocation resourcelocation = LayerArmorBase.b.get(s3);
        if (resourcelocation == null) {
            resourcelocation = new ResourceLocation(s3);
            LayerArmorBase.b.put(s3, resourcelocation);
        }
        return resourcelocation;
    }
    
    static final class zerodayisaminecraftcheat
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002427";
        
        static {
            zerodayisaminecraftcheat = new int[ItemArmor.zerodayisaminecraftcheat.values().length];
            try {
                LayerArmorBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat[ItemArmor.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                LayerArmorBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat[ItemArmor.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                LayerArmorBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat[ItemArmor.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                LayerArmorBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat[ItemArmor.zerodayisaminecraftcheat.pandora.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            try {
                LayerArmorBase.zerodayisaminecraftcheat.zerodayisaminecraftcheat[ItemArmor.zerodayisaminecraftcheat.zues.ordinal()] = 5;
            }
            catch (NoSuchFieldError noSuchFieldError5) {}
        }
    }
}

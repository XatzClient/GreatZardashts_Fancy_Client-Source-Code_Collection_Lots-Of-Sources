// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.client.pandora.ModelRenderer;
import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import net.minecraft.client.pandora.ModelBox;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.RenderHelper;
import java.util.Random;
import net.minecraft.vape.momgetthecamera.EntityArrow;
import net.minecraft.client.a.pandora.RendererLivingEntity;
import net.minecraft.vape.EntityLivingBase;

public class LayerArrow implements LayerRenderer<EntityLivingBase>
{
    private final RendererLivingEntity zerodayisaminecraftcheat;
    
    public LayerArrow(final RendererLivingEntity p_i46124_1_) {
        this.zerodayisaminecraftcheat = p_i46124_1_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        final int i = entitylivingbaseIn.bG();
        if (i > 0) {
            final Entity entity = new EntityArrow(entitylivingbaseIn.o, entitylivingbaseIn.s, entitylivingbaseIn.t, entitylivingbaseIn.u);
            final Random random = new Random(entitylivingbaseIn.B());
            RenderHelper.zerodayisaminecraftcheat();
            for (int j = 0; j < i; ++j) {
                GlStateManager.v();
                final ModelRenderer modelrenderer = this.zerodayisaminecraftcheat.zeroday().zerodayisaminecraftcheat(random);
                if (!modelrenderer.c) {
                    final ModelBox modelbox = modelrenderer.d.get(random.nextInt(modelrenderer.d.size()));
                    modelrenderer.sigma(0.0625f);
                    float f = random.nextFloat();
                    float f2 = random.nextFloat();
                    float f3 = random.nextFloat();
                    final float f4 = (modelbox.zerodayisaminecraftcheat + (modelbox.pandora - modelbox.zerodayisaminecraftcheat) * f) / 16.0f;
                    final float f5 = (modelbox.zeroday + (modelbox.zues - modelbox.zeroday) * f2) / 16.0f;
                    final float f6 = (modelbox.sigma + (modelbox.flux - modelbox.sigma) * f3) / 16.0f;
                    GlStateManager.zeroday(f4, f5, f6);
                    f = f * 2.0f - 1.0f;
                    f2 = f2 * 2.0f - 1.0f;
                    f3 = f3 * 2.0f - 1.0f;
                    f *= -1.0f;
                    f2 *= -1.0f;
                    f3 *= -1.0f;
                    final float f7 = MathHelper.sigma(f * f + f3 * f3);
                    final Entity entity2 = entity;
                    final Entity entity3 = entity;
                    final float n = (float)(Math.atan2(f, f3) * 180.0 / 3.141592653589793);
                    entity3.y = n;
                    entity2.A = n;
                    final Entity entity4 = entity;
                    final Entity entity5 = entity;
                    final float n2 = (float)(Math.atan2(f2, f7) * 180.0 / 3.141592653589793);
                    entity5.z = n2;
                    entity4.B = n2;
                    final double d0 = 0.0;
                    final double d2 = 0.0;
                    final double d3 = 0.0;
                    this.zerodayisaminecraftcheat.pandora().zerodayisaminecraftcheat(entity, d0, d2, d3, 0.0f, partialTicks);
                }
                GlStateManager.w();
            }
            RenderHelper.zeroday();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

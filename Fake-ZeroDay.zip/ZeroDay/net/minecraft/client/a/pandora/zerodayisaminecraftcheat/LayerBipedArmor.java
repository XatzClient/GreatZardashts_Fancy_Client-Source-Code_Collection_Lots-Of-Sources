// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.a.pandora.RendererLivingEntity;
import net.minecraft.client.pandora.ModelBiped;

public class LayerBipedArmor extends LayerArmorBase<ModelBiped>
{
    public LayerBipedArmor(final RendererLivingEntity<?> rendererIn) {
        super(rendererIn);
    }
    
    @Override
    protected void zerodayisaminecraftcheat() {
        this.sigma = (T)new ModelBiped(0.5f);
        this.pandora = (T)new ModelBiped(1.0f);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final ModelBiped p_177179_1_, final int p_177179_2_) {
        this.zerodayisaminecraftcheat(p_177179_1_);
        switch (p_177179_2_) {
            case 1: {
                p_177179_1_.h.b = true;
                p_177179_1_.i.b = true;
                break;
            }
            case 2: {
                p_177179_1_.e.b = true;
                p_177179_1_.h.b = true;
                p_177179_1_.i.b = true;
                break;
            }
            case 3: {
                p_177179_1_.e.b = true;
                p_177179_1_.f.b = true;
                p_177179_1_.g.b = true;
                break;
            }
            case 4: {
                p_177179_1_.c.b = true;
                p_177179_1_.d.b = true;
                break;
            }
        }
    }
    
    protected void zerodayisaminecraftcheat(final ModelBiped p_177194_1_) {
        p_177194_1_.zerodayisaminecraftcheat(false);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.vape.EnumPlayerModelParts;
import net.minecraft.client.zeroday.AbstractClientPlayer;
import net.minecraft.client.a.pandora.RenderPlayer;

public class LayerCape implements LayerRenderer
{
    private final RenderPlayer zerodayisaminecraftcheat;
    private static final String zeroday = "CL_00002425";
    
    public LayerCape(final RenderPlayer playerRendererIn) {
        this.zerodayisaminecraftcheat = playerRendererIn;
    }
    
    public void zerodayisaminecraftcheat(final AbstractClientPlayer entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.i_() && !entitylivingbaseIn.ap() && entitylivingbaseIn.zerodayisaminecraftcheat(EnumPlayerModelParts.zerodayisaminecraftcheat) && entitylivingbaseIn.b() != null) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(entitylivingbaseIn.b());
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, 0.0f, 0.125f);
            final double d0 = entitylivingbaseIn.bo + (entitylivingbaseIn.br - entitylivingbaseIn.bo) * partialTicks - (entitylivingbaseIn.p + (entitylivingbaseIn.s - entitylivingbaseIn.p) * partialTicks);
            final double d2 = entitylivingbaseIn.bp + (entitylivingbaseIn.bs - entitylivingbaseIn.bp) * partialTicks - (entitylivingbaseIn.q + (entitylivingbaseIn.t - entitylivingbaseIn.q) * partialTicks);
            final double d3 = entitylivingbaseIn.bq + (entitylivingbaseIn.bt - entitylivingbaseIn.bq) * partialTicks - (entitylivingbaseIn.r + (entitylivingbaseIn.u - entitylivingbaseIn.r) * partialTicks);
            final float f = entitylivingbaseIn.aM + (entitylivingbaseIn.aL - entitylivingbaseIn.aM) * partialTicks;
            final double d4 = MathHelper.zerodayisaminecraftcheat(f * 3.1415927f / 180.0f);
            final double d5 = -MathHelper.zeroday(f * 3.1415927f / 180.0f);
            float f2 = (float)d2 * 10.0f;
            f2 = MathHelper.zerodayisaminecraftcheat(f2, -6.0f, 32.0f);
            float f3 = (float)(d0 * d4 + d3 * d5) * 100.0f;
            final float f4 = (float)(d0 * d5 - d3 * d4) * 100.0f;
            if (f3 < 0.0f) {
                f3 = 0.0f;
            }
            if (f3 > 165.0f) {
                f3 = 165.0f;
            }
            final float f5 = entitylivingbaseIn.bl + (entitylivingbaseIn.bm - entitylivingbaseIn.bl) * partialTicks;
            f2 += MathHelper.zerodayisaminecraftcheat((entitylivingbaseIn.M + (entitylivingbaseIn.N - entitylivingbaseIn.M) * partialTicks) * 6.0f) * 32.0f * f5;
            if (entitylivingbaseIn.y()) {
                f2 += 25.0f;
                GlStateManager.zeroday(0.0f, 0.142f, -0.0178f);
            }
            GlStateManager.zeroday(6.0f + f3 / 2.0f + f2, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(f4 / 2.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.zeroday(-f4 / 2.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
            this.zerodayisaminecraftcheat.zues().sigma(0.0625f);
            GlStateManager.w();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        this.zerodayisaminecraftcheat((AbstractClientPlayer)entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale);
    }
}

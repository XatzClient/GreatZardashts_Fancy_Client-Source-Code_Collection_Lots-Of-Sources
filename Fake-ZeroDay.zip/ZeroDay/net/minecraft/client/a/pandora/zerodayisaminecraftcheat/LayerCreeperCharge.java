// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelCreeper;
import net.minecraft.client.a.pandora.RenderCreeper;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zues.EntityCreeper;

public class LayerCreeperCharge implements LayerRenderer<EntityCreeper>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final RenderCreeper zeroday;
    private final ModelCreeper sigma;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/creeper/creeper_armor.png");
    }
    
    public LayerCreeperCharge(final RenderCreeper creeperRendererIn) {
        this.sigma = new ModelCreeper(2.0f);
        this.zeroday = creeperRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityCreeper entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.momgetthecamera()) {
            final boolean flag = entitylivingbaseIn.ap();
            GlStateManager.zerodayisaminecraftcheat(!flag);
            this.zeroday.zerodayisaminecraftcheat(LayerCreeperCharge.zerodayisaminecraftcheat);
            GlStateManager.d(5890);
            GlStateManager.u();
            final float f = entitylivingbaseIn.X + partialTicks;
            GlStateManager.zeroday(f * 0.01f, f * 0.01f, 0.0f);
            GlStateManager.d(5888);
            GlStateManager.d();
            final float f2 = 0.5f;
            GlStateManager.sigma(f2, f2, f2, 1.0f);
            GlStateManager.flux();
            GlStateManager.zeroday(1, 1);
            this.sigma.zerodayisaminecraftcheat(this.zeroday.zeroday());
            this.sigma.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, p_177141_5_, p_177141_6_, p_177141_7_, scale);
            GlStateManager.d(5890);
            GlStateManager.u();
            GlStateManager.d(5888);
            GlStateManager.zues();
            GlStateManager.c();
            GlStateManager.zerodayisaminecraftcheat(flag);
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

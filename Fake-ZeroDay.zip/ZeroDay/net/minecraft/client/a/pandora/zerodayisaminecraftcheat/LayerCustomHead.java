// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.c.Item;
import net.minecraft.c.ItemStack;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.flux.TileEntitySkullRenderer;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.n.TileEntitySkull;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.o.StringUtils;
import net.minecraft.d.NBTUtil;
import net.minecraft.a.Items;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.c.ItemBlock;
import net.minecraft.vape.zues.EntityZombie;
import net.minecraft.vape.flux.EntityVillager;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.pandora.ModelRenderer;
import net.minecraft.vape.EntityLivingBase;

public class LayerCustomHead implements LayerRenderer<EntityLivingBase>
{
    private final ModelRenderer zerodayisaminecraftcheat;
    
    public LayerCustomHead(final ModelRenderer p_i46120_1_) {
        this.zerodayisaminecraftcheat = p_i46120_1_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        final ItemStack itemstack = entitylivingbaseIn.c(3);
        if (itemstack != null && itemstack.zerodayisaminecraftcheat() != null) {
            final Item item = itemstack.zerodayisaminecraftcheat();
            final Minecraft minecraft = Minecraft.s();
            GlStateManager.v();
            if (entitylivingbaseIn.y()) {
                GlStateManager.zeroday(0.0f, 0.2f, 0.0f);
            }
            final boolean flag = entitylivingbaseIn instanceof EntityVillager || (entitylivingbaseIn instanceof EntityZombie && ((EntityZombie)entitylivingbaseIn).cd());
            if (!flag && entitylivingbaseIn.n_()) {
                final float f = 2.0f;
                final float f2 = 1.4f;
                GlStateManager.zerodayisaminecraftcheat(f2 / f, f2 / f, f2 / f);
                GlStateManager.zeroday(0.0f, 16.0f * scale, 0.0f);
            }
            this.zerodayisaminecraftcheat.sigma(0.0625f);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            if (item instanceof ItemBlock) {
                final float f3 = 0.625f;
                GlStateManager.zeroday(0.0f, -0.25f, 0.0f);
                GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.zerodayisaminecraftcheat(f3, -f3, -f3);
                if (flag) {
                    GlStateManager.zeroday(0.0f, 0.1875f, 0.0f);
                }
                minecraft.aa().zerodayisaminecraftcheat(entitylivingbaseIn, itemstack, ItemCameraTransforms.zeroday.pandora);
            }
            else if (item == Items.bP) {
                final float f4 = 1.1875f;
                GlStateManager.zerodayisaminecraftcheat(f4, -f4, -f4);
                if (flag) {
                    GlStateManager.zeroday(0.0f, 0.0625f, 0.0f);
                }
                GameProfile gameprofile = null;
                if (itemstack.f()) {
                    final NBTTagCompound nbttagcompound = itemstack.g();
                    if (nbttagcompound.zeroday("SkullOwner", 10)) {
                        gameprofile = NBTUtil.zerodayisaminecraftcheat(nbttagcompound.e("SkullOwner"));
                    }
                    else if (nbttagcompound.zeroday("SkullOwner", 8)) {
                        final String s = nbttagcompound.b("SkullOwner");
                        if (!StringUtils.zeroday(s)) {
                            gameprofile = TileEntitySkull.zeroday(new GameProfile((UUID)null, s));
                            nbttagcompound.zerodayisaminecraftcheat("SkullOwner", NBTUtil.zerodayisaminecraftcheat(new NBTTagCompound(), gameprofile));
                        }
                    }
                }
                TileEntitySkullRenderer.zerodayisaminecraftcheat.zerodayisaminecraftcheat(-0.5f, 0.0f, -0.5f, EnumFacing.zeroday, 180.0f, itemstack.momgetthecamera(), gameprofile, -1);
            }
            GlStateManager.w();
        }
    }
    
    @Override
    public boolean zeroday() {
        return true;
    }
}

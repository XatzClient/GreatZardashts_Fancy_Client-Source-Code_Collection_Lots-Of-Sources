// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.RenderPlayer;
import net.minecraft.client.zeroday.AbstractClientPlayer;

public class LayerDeadmau5Head implements LayerRenderer<AbstractClientPlayer>
{
    private final RenderPlayer zerodayisaminecraftcheat;
    
    public LayerDeadmau5Head(final RenderPlayer playerRendererIn) {
        this.zerodayisaminecraftcheat = playerRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final AbstractClientPlayer entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.l_().equals("deadmau5") && entitylivingbaseIn.momgetthecamera() && !entitylivingbaseIn.ap()) {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(entitylivingbaseIn.a());
            for (int i = 0; i < 2; ++i) {
                final float f = entitylivingbaseIn.A + (entitylivingbaseIn.y - entitylivingbaseIn.A) * partialTicks - (entitylivingbaseIn.aM + (entitylivingbaseIn.aL - entitylivingbaseIn.aM) * partialTicks);
                final float f2 = entitylivingbaseIn.B + (entitylivingbaseIn.z - entitylivingbaseIn.B) * partialTicks;
                GlStateManager.v();
                GlStateManager.zeroday(f, 0.0f, 1.0f, 0.0f);
                GlStateManager.zeroday(f2, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(0.375f * (i * 2 - 1), 0.0f, 0.0f);
                GlStateManager.zeroday(0.0f, -0.375f, 0.0f);
                GlStateManager.zeroday(-f2, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(-f, 0.0f, 1.0f, 0.0f);
                final float f3 = 1.3333334f;
                GlStateManager.zerodayisaminecraftcheat(f3, f3, f3);
                this.zerodayisaminecraftcheat.zues().zeroday(0.0625f);
                GlStateManager.w();
            }
        }
    }
    
    @Override
    public boolean zeroday() {
        return true;
    }
}

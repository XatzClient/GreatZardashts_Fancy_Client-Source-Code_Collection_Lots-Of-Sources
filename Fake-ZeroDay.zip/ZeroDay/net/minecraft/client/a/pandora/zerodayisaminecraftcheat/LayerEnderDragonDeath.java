// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.GlStateManager;
import java.util.Random;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.client.a.Tessellator;
import net.minecraft.vape.zeroday.EntityDragon;

public class LayerEnderDragonDeath implements LayerRenderer<EntityDragon>
{
    @Override
    public void zerodayisaminecraftcheat(final EntityDragon entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.bx > 0) {
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            RenderHelper.zerodayisaminecraftcheat();
            final float f = (entitylivingbaseIn.bx + partialTicks) / 200.0f;
            float f2 = 0.0f;
            if (f > 0.8f) {
                f2 = (f - 0.8f) / 0.2f;
            }
            final Random random = new Random(432L);
            GlStateManager.n();
            GlStateManager.b(7425);
            GlStateManager.d();
            GlStateManager.zeroday(770, 1);
            GlStateManager.sigma();
            GlStateManager.g();
            GlStateManager.zerodayisaminecraftcheat(false);
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, -1.0f, -2.0f);
            for (int i = 0; i < (f + f * f) / 2.0f * 60.0f; ++i) {
                GlStateManager.zeroday(random.nextFloat() * 360.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(random.nextFloat() * 360.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.zeroday(random.nextFloat() * 360.0f, 0.0f, 0.0f, 1.0f);
                GlStateManager.zeroday(random.nextFloat() * 360.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(random.nextFloat() * 360.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.zeroday(random.nextFloat() * 360.0f + f * 90.0f, 0.0f, 0.0f, 1.0f);
                final float f3 = random.nextFloat() * 20.0f + 5.0f + f2 * 10.0f;
                final float f4 = random.nextFloat() * 2.0f + 1.0f + f2 * 2.0f;
                worldrenderer.zerodayisaminecraftcheat(6, DefaultVertexFormats.flux);
                worldrenderer.zeroday(0.0, 0.0, 0.0).zeroday(255, 255, 255, (int)(255.0f * (1.0f - f2))).zues();
                worldrenderer.zeroday(-0.866 * f4, f3, -0.5f * f4).zeroday(255, 0, 255, 0).zues();
                worldrenderer.zeroday(0.866 * f4, f3, -0.5f * f4).zeroday(255, 0, 255, 0).zues();
                worldrenderer.zeroday(0.0, f3, 1.0f * f4).zeroday(255, 0, 255, 0).zues();
                worldrenderer.zeroday(-0.866 * f4, f3, -0.5f * f4).zeroday(255, 0, 255, 0).zues();
                tessellator.zeroday();
            }
            GlStateManager.w();
            GlStateManager.zerodayisaminecraftcheat(true);
            GlStateManager.h();
            GlStateManager.c();
            GlStateManager.b(7424);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.m();
            GlStateManager.pandora();
            RenderHelper.zeroday();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

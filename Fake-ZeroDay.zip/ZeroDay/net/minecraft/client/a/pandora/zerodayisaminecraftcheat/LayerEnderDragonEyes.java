// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import sigma.zerodayisaminecraftcheat.j;
import net.minecraft.l.Config;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.zeroday.EntityDragon;
import net.minecraft.client.a.pandora.RenderDragon;
import net.minecraft.o.ResourceLocation;

public class LayerEnderDragonEyes implements LayerRenderer
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final RenderDragon zeroday;
    private static final String sigma = "CL_00002419";
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/enderdragon/dragon_eyes.png");
    }
    
    public LayerEnderDragonEyes(final RenderDragon dragonRendererIn) {
        this.zeroday = dragonRendererIn;
    }
    
    public void zerodayisaminecraftcheat(final EntityDragon entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        this.zeroday.zerodayisaminecraftcheat(LayerEnderDragonEyes.zerodayisaminecraftcheat);
        GlStateManager.d();
        GlStateManager.sigma();
        GlStateManager.zeroday(1, 1);
        GlStateManager.flux();
        GlStateManager.sigma(514);
        final char c0 = '\uf0f0';
        final int i = c0 % 65536;
        final int j = c0 / 65536;
        OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, i / 1.0f, j / 1.0f);
        GlStateManager.zues();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.j.w();
        }
        this.zeroday.zeroday().zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, p_177141_5_, p_177141_6_, p_177141_7_, scale);
        this.zeroday.zerodayisaminecraftcheat(entitylivingbaseIn, partialTicks);
        GlStateManager.c();
        GlStateManager.pandora();
        GlStateManager.sigma(515);
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        this.zerodayisaminecraftcheat((EntityDragon)entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale);
    }
}

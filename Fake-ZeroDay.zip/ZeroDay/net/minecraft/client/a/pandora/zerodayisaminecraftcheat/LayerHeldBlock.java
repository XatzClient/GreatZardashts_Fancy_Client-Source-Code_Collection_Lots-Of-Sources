// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.client.a.pandora.RenderEnderman;
import net.minecraft.vape.zues.EntityEnderman;

public class LayerHeldBlock implements LayerRenderer<EntityEnderman>
{
    private final RenderEnderman zerodayisaminecraftcheat;
    
    public LayerHeldBlock(final RenderEnderman endermanRendererIn) {
        this.zerodayisaminecraftcheat = endermanRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityEnderman entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        final IBlockState iblockstate = entitylivingbaseIn.cb();
        if (iblockstate.sigma().flux() != Material.zerodayisaminecraftcheat) {
            final BlockRendererDispatcher blockrendererdispatcher = Minecraft.s().X();
            GlStateManager.s();
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, 0.6875f, -0.75f);
            GlStateManager.zeroday(20.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(45.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(0.25f, 0.1875f, 0.25f);
            final float f = 0.5f;
            GlStateManager.zerodayisaminecraftcheat(-f, -f, f);
            final int i = entitylivingbaseIn.zerodayisaminecraftcheat(partialTicks);
            final int j = i % 65536;
            final int k = i / 65536;
            OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, j / 1.0f, k / 1.0f);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(TextureMap.zeroday);
            blockrendererdispatcher.zerodayisaminecraftcheat(iblockstate, 1.0f);
            GlStateManager.w();
            GlStateManager.t();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

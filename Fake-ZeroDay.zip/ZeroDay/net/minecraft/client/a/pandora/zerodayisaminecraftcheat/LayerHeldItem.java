// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.ItemBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.c.Item;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Items;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.client.pandora.ModelBiped;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.RendererLivingEntity;
import net.minecraft.vape.EntityLivingBase;

public class LayerHeldItem implements LayerRenderer<EntityLivingBase>
{
    private final RendererLivingEntity<?> zerodayisaminecraftcheat;
    
    public LayerHeldItem(final RendererLivingEntity<?> livingEntityRendererIn) {
        this.zerodayisaminecraftcheat = livingEntityRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        ItemStack itemstack = entitylivingbaseIn.aZ();
        if (itemstack != null) {
            GlStateManager.v();
            if (this.zerodayisaminecraftcheat.zeroday().vape) {
                final float f = 0.5f;
                GlStateManager.zeroday(0.0f, 0.625f, 0.0f);
                GlStateManager.zeroday(-20.0f, -1.0f, 0.0f, 0.0f);
                GlStateManager.zerodayisaminecraftcheat(f, f, f);
            }
            ((ModelBiped)this.zerodayisaminecraftcheat.zeroday()).zerodayisaminecraftcheat(0.0625f);
            GlStateManager.zeroday(-0.0625f, 0.4375f, 0.0625f);
            if (entitylivingbaseIn instanceof EntityPlayer && ((EntityPlayer)entitylivingbaseIn).bF != null) {
                itemstack = new ItemStack(Items.aJ, 0);
            }
            final Item item = itemstack.zerodayisaminecraftcheat();
            final Minecraft minecraft = Minecraft.s();
            if (item instanceof ItemBlock && Block.zerodayisaminecraftcheat(item).c() == 2) {
                GlStateManager.zeroday(0.0f, 0.1875f, -0.3125f);
                GlStateManager.zeroday(20.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(45.0f, 0.0f, 1.0f, 0.0f);
                final float f2 = 0.375f;
                GlStateManager.zerodayisaminecraftcheat(-f2, -f2, f2);
            }
            if (entitylivingbaseIn.y()) {
                GlStateManager.zeroday(0.0f, 0.203125f, 0.0f);
            }
            minecraft.aa().zerodayisaminecraftcheat(entitylivingbaseIn, itemstack, ItemCameraTransforms.zeroday.zeroday);
            GlStateManager.w();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.c.Item;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.a.Items;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.ItemBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.pandora.ModelWitch;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.RenderWitch;
import net.minecraft.vape.zues.EntityWitch;

public class LayerHeldItemWitch implements LayerRenderer<EntityWitch>
{
    private final RenderWitch zerodayisaminecraftcheat;
    
    public LayerHeldItemWitch(final RenderWitch witchRendererIn) {
        this.zerodayisaminecraftcheat = witchRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityWitch entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        final ItemStack itemstack = entitylivingbaseIn.aZ();
        if (itemstack != null) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f);
            GlStateManager.v();
            if (this.zerodayisaminecraftcheat.zeroday().vape) {
                GlStateManager.zeroday(0.0f, 0.625f, 0.0f);
                GlStateManager.zeroday(-20.0f, -1.0f, 0.0f, 0.0f);
                final float f = 0.5f;
                GlStateManager.zerodayisaminecraftcheat(f, f, f);
            }
            ((ModelWitch)this.zerodayisaminecraftcheat.zeroday()).d.sigma(0.0625f);
            GlStateManager.zeroday(-0.0625f, 0.53125f, 0.21875f);
            final Item item = itemstack.zerodayisaminecraftcheat();
            final Minecraft minecraft = Minecraft.s();
            if (item instanceof ItemBlock && minecraft.X().zerodayisaminecraftcheat(Block.zerodayisaminecraftcheat(item), itemstack.momgetthecamera())) {
                GlStateManager.zeroday(0.0f, 0.0625f, -0.25f);
                GlStateManager.zeroday(30.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(-5.0f, 0.0f, 1.0f, 0.0f);
                final float f2 = 0.375f;
                GlStateManager.zerodayisaminecraftcheat(f2, -f2, f2);
            }
            else if (item == Items.flux) {
                GlStateManager.zeroday(0.0f, 0.125f, -0.125f);
                GlStateManager.zeroday(-45.0f, 0.0f, 1.0f, 0.0f);
                final float f3 = 0.625f;
                GlStateManager.zerodayisaminecraftcheat(f3, -f3, f3);
                GlStateManager.zeroday(-100.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(-20.0f, 0.0f, 1.0f, 0.0f);
            }
            else if (item.flux()) {
                if (item.vape()) {
                    GlStateManager.zeroday(180.0f, 0.0f, 0.0f, 1.0f);
                    GlStateManager.zeroday(0.0f, -0.0625f, 0.0f);
                }
                this.zerodayisaminecraftcheat.z_();
                GlStateManager.zeroday(0.0625f, -0.125f, 0.0f);
                final float f4 = 0.625f;
                GlStateManager.zerodayisaminecraftcheat(f4, -f4, f4);
                GlStateManager.zeroday(0.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(0.0f, 0.0f, 1.0f, 0.0f);
            }
            else {
                GlStateManager.zeroday(0.1875f, 0.1875f, 0.0f);
                final float f5 = 0.875f;
                GlStateManager.zerodayisaminecraftcheat(f5, f5, f5);
                GlStateManager.zeroday(-20.0f, 0.0f, 0.0f, 1.0f);
                GlStateManager.zeroday(-60.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.zeroday(-30.0f, 0.0f, 0.0f, 1.0f);
            }
            GlStateManager.zeroday(-15.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(40.0f, 0.0f, 0.0f, 1.0f);
            minecraft.aa().zerodayisaminecraftcheat(entitylivingbaseIn, itemstack, ItemCameraTransforms.zeroday.zeroday);
            GlStateManager.w();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.a.Blocks;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.pandora.ModelIronGolem;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.pandora.RenderIronGolem;
import net.minecraft.vape.zues.EntityIronGolem;

public class LayerIronGolemFlower implements LayerRenderer<EntityIronGolem>
{
    private final RenderIronGolem zerodayisaminecraftcheat;
    
    public LayerIronGolemFlower(final RenderIronGolem ironGolemRendererIn) {
        this.zerodayisaminecraftcheat = ironGolemRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityIronGolem entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.cb() != 0) {
            final BlockRendererDispatcher blockrendererdispatcher = Minecraft.s().X();
            GlStateManager.s();
            GlStateManager.v();
            GlStateManager.zeroday(5.0f + 180.0f * ((ModelIronGolem)this.zerodayisaminecraftcheat.zeroday()).sigma.flux / 3.1415927f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(90.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(-0.9375f, -0.625f, -0.9375f);
            final float f = 0.5f;
            GlStateManager.zerodayisaminecraftcheat(f, -f, f);
            final int i = entitylivingbaseIn.zerodayisaminecraftcheat(partialTicks);
            final int j = i % 65536;
            final int k = i / 65536;
            OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.j, j / 1.0f, k / 1.0f);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(TextureMap.zeroday);
            blockrendererdispatcher.zerodayisaminecraftcheat(Blocks.G.G(), 1.0f);
            GlStateManager.w();
            GlStateManager.t();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

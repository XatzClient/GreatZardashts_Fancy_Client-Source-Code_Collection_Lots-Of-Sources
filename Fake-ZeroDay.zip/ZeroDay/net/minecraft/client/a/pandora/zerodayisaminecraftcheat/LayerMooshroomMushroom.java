// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.BlockRendererDispatcher;
import net.minecraft.client.pandora.ModelQuadruped;
import net.minecraft.a.Blocks;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.pandora.RenderMooshroom;
import net.minecraft.vape.flux.EntityMooshroom;

public class LayerMooshroomMushroom implements LayerRenderer<EntityMooshroom>
{
    private final RenderMooshroom zerodayisaminecraftcheat;
    
    public LayerMooshroomMushroom(final RenderMooshroom mooshroomRendererIn) {
        this.zerodayisaminecraftcheat = mooshroomRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityMooshroom entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (!entitylivingbaseIn.n_() && !entitylivingbaseIn.ap()) {
            final BlockRendererDispatcher blockrendererdispatcher = Minecraft.s().X();
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(TextureMap.zeroday);
            GlStateManager.g();
            GlStateManager.zues(1028);
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.0f, -1.0f, 1.0f);
            GlStateManager.zeroday(0.2f, 0.35f, 0.5f);
            GlStateManager.zeroday(42.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.v();
            GlStateManager.zeroday(-0.5f, -0.5f, 0.5f);
            blockrendererdispatcher.zerodayisaminecraftcheat(Blocks.I.G(), 1.0f);
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zeroday(0.1f, 0.0f, -0.6f);
            GlStateManager.zeroday(42.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(-0.5f, -0.5f, 0.5f);
            blockrendererdispatcher.zerodayisaminecraftcheat(Blocks.I.G(), 1.0f);
            GlStateManager.w();
            GlStateManager.w();
            GlStateManager.v();
            ((ModelQuadruped)this.zerodayisaminecraftcheat.zeroday()).zerodayisaminecraftcheat.sigma(0.0625f);
            GlStateManager.zerodayisaminecraftcheat(1.0f, -1.0f, 1.0f);
            GlStateManager.zeroday(0.0f, 0.7f, -0.2f);
            GlStateManager.zeroday(12.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(-0.5f, -0.5f, 0.5f);
            blockrendererdispatcher.zerodayisaminecraftcheat(Blocks.I.G(), 1.0f);
            GlStateManager.w();
            GlStateManager.zues(1029);
            GlStateManager.h();
        }
    }
    
    @Override
    public boolean zeroday() {
        return true;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.pandora.ModelPig;
import net.minecraft.client.a.pandora.RenderPig;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.flux.EntityPig;

public class LayerSaddle implements LayerRenderer<EntityPig>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final RenderPig zeroday;
    private final ModelPig sigma;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/pig/pig_saddle.png");
    }
    
    public LayerSaddle(final RenderPig pigRendererIn) {
        this.sigma = new ModelPig(0.5f);
        this.zeroday = pigRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityPig entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.cd()) {
            this.zeroday.zerodayisaminecraftcheat(LayerSaddle.zerodayisaminecraftcheat);
            this.sigma.zerodayisaminecraftcheat(this.zeroday.zeroday());
            this.sigma.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, p_177141_5_, p_177141_6_, p_177141_7_, scale);
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.l.CustomColorizer;
import net.minecraft.l.Config;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.vape.flux.EntitySheep;
import net.minecraft.client.pandora.ModelSheep1;
import net.minecraft.client.a.pandora.RenderSheep;
import net.minecraft.o.ResourceLocation;

public class LayerSheepWool implements LayerRenderer
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final RenderSheep zeroday;
    private final ModelSheep1 sigma;
    private static final String pandora = "CL_00002413";
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/sheep/sheep_fur.png");
    }
    
    public LayerSheepWool(final RenderSheep sheepRendererIn) {
        this.sigma = new ModelSheep1();
        this.zeroday = sheepRendererIn;
    }
    
    public void zerodayisaminecraftcheat(final EntitySheep entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (!entitylivingbaseIn.ce() && !entitylivingbaseIn.ap()) {
            this.zeroday.zerodayisaminecraftcheat(LayerSheepWool.zerodayisaminecraftcheat);
            if (entitylivingbaseIn.p_() && "jeb_".equals(entitylivingbaseIn.aC())) {
                final boolean flag = true;
                final int i = entitylivingbaseIn.X / 25 + entitylivingbaseIn.B();
                final int j = EnumDyeColor.values().length;
                final int k = i % j;
                final int l = (i + 1) % j;
                final float f = (entitylivingbaseIn.X % 25 + partialTicks) / 25.0f;
                float[] afloat1 = EntitySheep.zerodayisaminecraftcheat(EnumDyeColor.zeroday(k));
                float[] afloat2 = EntitySheep.zerodayisaminecraftcheat(EnumDyeColor.zeroday(l));
                if (Config.at()) {
                    afloat1 = CustomColorizer.zeroday(EnumDyeColor.zeroday(k), afloat1);
                    afloat2 = CustomColorizer.zeroday(EnumDyeColor.zeroday(l), afloat2);
                }
                GlStateManager.sigma(afloat1[0] * (1.0f - f) + afloat2[0] * f, afloat1[1] * (1.0f - f) + afloat2[1] * f, afloat1[2] * (1.0f - f) + afloat2[2] * f);
            }
            else {
                float[] afloat3 = EntitySheep.zerodayisaminecraftcheat(entitylivingbaseIn.cd());
                if (Config.at()) {
                    afloat3 = CustomColorizer.zeroday(entitylivingbaseIn.cd(), afloat3);
                }
                GlStateManager.sigma(afloat3[0], afloat3[1], afloat3[2]);
            }
            this.sigma.zerodayisaminecraftcheat(this.zeroday.zeroday());
            this.sigma.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks);
            this.sigma.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, p_177141_5_, p_177141_6_, p_177141_7_, scale);
        }
    }
    
    @Override
    public boolean zeroday() {
        return true;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        this.zerodayisaminecraftcheat((EntitySheep)entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale);
    }
}

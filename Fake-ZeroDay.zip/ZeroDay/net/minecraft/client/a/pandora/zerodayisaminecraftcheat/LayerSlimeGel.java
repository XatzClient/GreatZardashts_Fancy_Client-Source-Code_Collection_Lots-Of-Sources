// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelSlime;
import net.minecraft.client.pandora.ModelBase;
import net.minecraft.client.a.pandora.RenderSlime;
import net.minecraft.vape.zues.EntitySlime;

public class LayerSlimeGel implements LayerRenderer<EntitySlime>
{
    private final RenderSlime zerodayisaminecraftcheat;
    private final ModelBase zeroday;
    
    public LayerSlimeGel(final RenderSlime slimeRendererIn) {
        this.zeroday = new ModelSlime(0);
        this.zerodayisaminecraftcheat = slimeRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntitySlime entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (!entitylivingbaseIn.ap()) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.q();
            GlStateManager.d();
            GlStateManager.zeroday(770, 771);
            this.zeroday.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zeroday());
            this.zeroday.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, p_177141_5_, p_177141_6_, p_177141_7_, scale);
            GlStateManager.c();
            GlStateManager.r();
        }
    }
    
    @Override
    public boolean zeroday() {
        return true;
    }
}

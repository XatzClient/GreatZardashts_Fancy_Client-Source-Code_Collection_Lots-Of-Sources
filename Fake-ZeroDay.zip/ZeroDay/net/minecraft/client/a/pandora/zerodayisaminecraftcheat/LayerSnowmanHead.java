// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.c.ItemStack;
import net.minecraft.a.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.pandora.RenderSnowMan;
import net.minecraft.vape.zues.EntitySnowman;

public class LayerSnowmanHead implements LayerRenderer<EntitySnowman>
{
    private final RenderSnowMan zerodayisaminecraftcheat;
    
    public LayerSnowmanHead(final RenderSnowMan snowManRendererIn) {
        this.zerodayisaminecraftcheat = snowManRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntitySnowman entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (!entitylivingbaseIn.ap()) {
            GlStateManager.v();
            this.zerodayisaminecraftcheat.zues().sigma.sigma(0.0625f);
            final float f = 0.625f;
            GlStateManager.zeroday(0.0f, -0.34375f, 0.0f);
            GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.zerodayisaminecraftcheat(f, -f, -f);
            Minecraft.s().aa().zerodayisaminecraftcheat(entitylivingbaseIn, new ItemStack(Blocks.aM, 1), ItemCameraTransforms.zeroday.pandora);
            GlStateManager.w();
        }
    }
    
    @Override
    public boolean zeroday() {
        return true;
    }
}

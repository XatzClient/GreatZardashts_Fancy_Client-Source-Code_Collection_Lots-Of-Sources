// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.client.pandora.ModelZombieVillager;
import net.minecraft.client.a.pandora.RendererLivingEntity;

public class LayerVillagerArmor extends LayerBipedArmor
{
    public LayerVillagerArmor(final RendererLivingEntity<?> rendererIn) {
        super(rendererIn);
    }
    
    @Override
    protected void zerodayisaminecraftcheat() {
        this.sigma = (T)new ModelZombieVillager(0.5f, 0.0f, true);
        this.pandora = (T)new ModelZombieVillager(1.0f, 0.0f, true);
    }
}

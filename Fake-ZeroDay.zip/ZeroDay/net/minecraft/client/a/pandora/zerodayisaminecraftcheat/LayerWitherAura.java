// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.pandora.ModelWither;
import net.minecraft.client.a.pandora.RenderWither;
import net.minecraft.o.ResourceLocation;
import net.minecraft.vape.zeroday.EntityWither;

public class LayerWitherAura implements LayerRenderer<EntityWither>
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final RenderWither zeroday;
    private final ModelWither sigma;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/wither/wither_armor.png");
    }
    
    public LayerWitherAura(final RenderWither witherRendererIn) {
        this.sigma = new ModelWither(0.5f);
        this.zeroday = witherRendererIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityWither entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.cb()) {
            GlStateManager.zerodayisaminecraftcheat(!entitylivingbaseIn.ap());
            this.zeroday.zerodayisaminecraftcheat(LayerWitherAura.zerodayisaminecraftcheat);
            GlStateManager.d(5890);
            GlStateManager.u();
            final float f = entitylivingbaseIn.X + partialTicks;
            final float f2 = MathHelper.zeroday(f * 0.02f) * 3.0f;
            final float f3 = f * 0.01f;
            GlStateManager.zeroday(f2, f3, 0.0f);
            GlStateManager.d(5888);
            GlStateManager.d();
            final float f4 = 0.5f;
            GlStateManager.sigma(f4, f4, f4, 1.0f);
            GlStateManager.flux();
            GlStateManager.zeroday(1, 1);
            this.sigma.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks);
            this.sigma.zerodayisaminecraftcheat(this.zeroday.zeroday());
            this.sigma.zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, p_177141_5_, p_177141_6_, p_177141_7_, scale);
            GlStateManager.d(5890);
            GlStateManager.u();
            GlStateManager.d(5888);
            GlStateManager.zues();
            GlStateManager.c();
        }
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
}

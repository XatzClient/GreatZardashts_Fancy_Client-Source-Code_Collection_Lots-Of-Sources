// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.pandora.zerodayisaminecraftcheat;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.l.CustomColorizer;
import net.minecraft.l.Config;
import net.minecraft.vape.flux.EntitySheep;
import net.minecraft.c.EnumDyeColor;
import net.minecraft.vape.flux.EntityWolf;
import net.minecraft.client.a.pandora.RenderWolf;
import net.minecraft.o.ResourceLocation;

public class LayerWolfCollar implements LayerRenderer
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private final RenderWolf zeroday;
    private static final String sigma = "CL_00002405";
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/wolf/wolf_collar.png");
    }
    
    public LayerWolfCollar(final RenderWolf wolfRendererIn) {
        this.zeroday = wolfRendererIn;
    }
    
    public void zerodayisaminecraftcheat(final EntityWolf entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        if (entitylivingbaseIn.cf() && !entitylivingbaseIn.ap()) {
            this.zeroday.zerodayisaminecraftcheat(LayerWolfCollar.zerodayisaminecraftcheat);
            final EnumDyeColor enumdyecolor = EnumDyeColor.zeroday(entitylivingbaseIn.cl().zeroday());
            float[] afloat = EntitySheep.zerodayisaminecraftcheat(enumdyecolor);
            if (Config.at()) {
                afloat = CustomColorizer.zerodayisaminecraftcheat(enumdyecolor, afloat);
            }
            GlStateManager.sigma(afloat[0], afloat[1], afloat[2]);
            this.zeroday.zeroday().zerodayisaminecraftcheat(entitylivingbaseIn, p_177141_2_, p_177141_3_, p_177141_5_, p_177141_6_, p_177141_7_, scale);
        }
    }
    
    @Override
    public boolean zeroday() {
        return true;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_177141_2_, final float p_177141_3_, final float partialTicks, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float scale) {
        this.zerodayisaminecraftcheat((EntityWolf)entitylivingbaseIn, p_177141_2_, p_177141_3_, partialTicks, p_177141_5_, p_177141_6_, p_177141_7_, scale);
    }
}

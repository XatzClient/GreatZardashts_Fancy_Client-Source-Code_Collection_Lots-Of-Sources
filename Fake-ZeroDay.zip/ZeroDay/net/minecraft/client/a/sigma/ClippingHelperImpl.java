// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.sigma;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GLAllocation;
import java.nio.FloatBuffer;

public class ClippingHelperImpl extends ClippingHelper
{
    private static ClippingHelperImpl zues;
    private FloatBuffer flux;
    private FloatBuffer vape;
    private FloatBuffer momgetthecamera;
    
    static {
        ClippingHelperImpl.zues = new ClippingHelperImpl();
    }
    
    public ClippingHelperImpl() {
        this.flux = GLAllocation.zues(16);
        this.vape = GLAllocation.zues(16);
        this.momgetthecamera = GLAllocation.zues(16);
    }
    
    public static ClippingHelper zerodayisaminecraftcheat() {
        ClippingHelperImpl.zues.zeroday();
        return ClippingHelperImpl.zues;
    }
    
    private void zerodayisaminecraftcheat(final float[] p_180547_1_) {
        final float f = MathHelper.sigma(p_180547_1_[0] * p_180547_1_[0] + p_180547_1_[1] * p_180547_1_[1] + p_180547_1_[2] * p_180547_1_[2]);
        final int n = 0;
        p_180547_1_[n] /= f;
        final int n2 = 1;
        p_180547_1_[n2] /= f;
        final int n3 = 2;
        p_180547_1_[n3] /= f;
        final int n4 = 3;
        p_180547_1_[n4] /= f;
    }
    
    public void zeroday() {
        this.flux.clear();
        this.vape.clear();
        this.momgetthecamera.clear();
        GlStateManager.zerodayisaminecraftcheat(2983, this.flux);
        GlStateManager.zerodayisaminecraftcheat(2982, this.vape);
        final float[] afloat = this.zeroday;
        final float[] afloat2 = this.sigma;
        this.flux.flip().limit(16);
        this.flux.get(afloat);
        this.vape.flip().limit(16);
        this.vape.get(afloat2);
        this.pandora[0] = afloat2[0] * afloat[0] + afloat2[1] * afloat[4] + afloat2[2] * afloat[8] + afloat2[3] * afloat[12];
        this.pandora[1] = afloat2[0] * afloat[1] + afloat2[1] * afloat[5] + afloat2[2] * afloat[9] + afloat2[3] * afloat[13];
        this.pandora[2] = afloat2[0] * afloat[2] + afloat2[1] * afloat[6] + afloat2[2] * afloat[10] + afloat2[3] * afloat[14];
        this.pandora[3] = afloat2[0] * afloat[3] + afloat2[1] * afloat[7] + afloat2[2] * afloat[11] + afloat2[3] * afloat[15];
        this.pandora[4] = afloat2[4] * afloat[0] + afloat2[5] * afloat[4] + afloat2[6] * afloat[8] + afloat2[7] * afloat[12];
        this.pandora[5] = afloat2[4] * afloat[1] + afloat2[5] * afloat[5] + afloat2[6] * afloat[9] + afloat2[7] * afloat[13];
        this.pandora[6] = afloat2[4] * afloat[2] + afloat2[5] * afloat[6] + afloat2[6] * afloat[10] + afloat2[7] * afloat[14];
        this.pandora[7] = afloat2[4] * afloat[3] + afloat2[5] * afloat[7] + afloat2[6] * afloat[11] + afloat2[7] * afloat[15];
        this.pandora[8] = afloat2[8] * afloat[0] + afloat2[9] * afloat[4] + afloat2[10] * afloat[8] + afloat2[11] * afloat[12];
        this.pandora[9] = afloat2[8] * afloat[1] + afloat2[9] * afloat[5] + afloat2[10] * afloat[9] + afloat2[11] * afloat[13];
        this.pandora[10] = afloat2[8] * afloat[2] + afloat2[9] * afloat[6] + afloat2[10] * afloat[10] + afloat2[11] * afloat[14];
        this.pandora[11] = afloat2[8] * afloat[3] + afloat2[9] * afloat[7] + afloat2[10] * afloat[11] + afloat2[11] * afloat[15];
        this.pandora[12] = afloat2[12] * afloat[0] + afloat2[13] * afloat[4] + afloat2[14] * afloat[8] + afloat2[15] * afloat[12];
        this.pandora[13] = afloat2[12] * afloat[1] + afloat2[13] * afloat[5] + afloat2[14] * afloat[9] + afloat2[15] * afloat[13];
        this.pandora[14] = afloat2[12] * afloat[2] + afloat2[13] * afloat[6] + afloat2[14] * afloat[10] + afloat2[15] * afloat[14];
        this.pandora[15] = afloat2[12] * afloat[3] + afloat2[13] * afloat[7] + afloat2[14] * afloat[11] + afloat2[15] * afloat[15];
        final float[] afloat3 = this.zerodayisaminecraftcheat[0];
        afloat3[0] = this.pandora[3] - this.pandora[0];
        afloat3[1] = this.pandora[7] - this.pandora[4];
        afloat3[2] = this.pandora[11] - this.pandora[8];
        afloat3[3] = this.pandora[15] - this.pandora[12];
        this.zerodayisaminecraftcheat(afloat3);
        final float[] afloat4 = this.zerodayisaminecraftcheat[1];
        afloat4[0] = this.pandora[3] + this.pandora[0];
        afloat4[1] = this.pandora[7] + this.pandora[4];
        afloat4[2] = this.pandora[11] + this.pandora[8];
        afloat4[3] = this.pandora[15] + this.pandora[12];
        this.zerodayisaminecraftcheat(afloat4);
        final float[] afloat5 = this.zerodayisaminecraftcheat[2];
        afloat5[0] = this.pandora[3] + this.pandora[1];
        afloat5[1] = this.pandora[7] + this.pandora[5];
        afloat5[2] = this.pandora[11] + this.pandora[9];
        afloat5[3] = this.pandora[15] + this.pandora[13];
        this.zerodayisaminecraftcheat(afloat5);
        final float[] afloat6 = this.zerodayisaminecraftcheat[3];
        afloat6[0] = this.pandora[3] - this.pandora[1];
        afloat6[1] = this.pandora[7] - this.pandora[5];
        afloat6[2] = this.pandora[11] - this.pandora[9];
        afloat6[3] = this.pandora[15] - this.pandora[13];
        this.zerodayisaminecraftcheat(afloat6);
        final float[] afloat7 = this.zerodayisaminecraftcheat[4];
        afloat7[0] = this.pandora[3] - this.pandora[2];
        afloat7[1] = this.pandora[7] - this.pandora[6];
        afloat7[2] = this.pandora[11] - this.pandora[10];
        afloat7[3] = this.pandora[15] - this.pandora[14];
        this.zerodayisaminecraftcheat(afloat7);
        final float[] afloat8 = this.zerodayisaminecraftcheat[5];
        afloat8[0] = this.pandora[3] + this.pandora[2];
        afloat8[1] = this.pandora[7] + this.pandora[6];
        afloat8[2] = this.pandora[11] + this.pandora[10];
        afloat8[3] = this.pandora[15] + this.pandora[14];
        this.zerodayisaminecraftcheat(afloat8);
    }
}

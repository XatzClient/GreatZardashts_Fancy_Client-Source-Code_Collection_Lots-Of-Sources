// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.sigma;

import net.minecraft.o.AxisAlignedBB;

public class Frustum implements ICamera
{
    private ClippingHelper zerodayisaminecraftcheat;
    private double zeroday;
    private double sigma;
    private double pandora;
    
    public Frustum() {
        this(ClippingHelperImpl.zerodayisaminecraftcheat());
    }
    
    public Frustum(final ClippingHelper p_i46196_1_) {
        this.zerodayisaminecraftcheat = p_i46196_1_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final double p_78547_1_, final double p_78547_3_, final double p_78547_5_) {
        this.zeroday = p_78547_1_;
        this.sigma = p_78547_3_;
        this.pandora = p_78547_5_;
    }
    
    public boolean zerodayisaminecraftcheat(final double p_78548_1_, final double p_78548_3_, final double p_78548_5_, final double p_78548_7_, final double p_78548_9_, final double p_78548_11_) {
        return this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_78548_1_ - this.zeroday, p_78548_3_ - this.sigma, p_78548_5_ - this.pandora, p_78548_7_ - this.zeroday, p_78548_9_ - this.sigma, p_78548_11_ - this.pandora);
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final AxisAlignedBB p_78546_1_) {
        return this.zerodayisaminecraftcheat(p_78546_1_.zerodayisaminecraftcheat, p_78546_1_.zeroday, p_78546_1_.sigma, p_78546_1_.pandora, p_78546_1_.zues, p_78546_1_.flux);
    }
}

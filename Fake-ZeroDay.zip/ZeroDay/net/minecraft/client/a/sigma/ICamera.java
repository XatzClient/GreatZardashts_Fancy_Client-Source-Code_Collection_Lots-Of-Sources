// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.sigma;

import net.minecraft.o.AxisAlignedBB;

public interface ICamera
{
    boolean zerodayisaminecraftcheat(final AxisAlignedBB p0);
    
    void zerodayisaminecraftcheat(final double p0, final double p1, final double p2);
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.vape;

import net.minecraft.l.Reflector;
import sigma.zerodayisaminecraftcheat.c;
import net.minecraft.l.Config;

public class DefaultVertexFormats
{
    public static VertexFormat zerodayisaminecraftcheat;
    public static VertexFormat zeroday;
    private static final VertexFormat k;
    private static final VertexFormat l;
    public static final VertexFormat sigma;
    public static final VertexFormat pandora;
    public static final VertexFormat zues;
    public static final VertexFormat flux;
    public static final VertexFormat vape;
    public static final VertexFormat momgetthecamera;
    public static final VertexFormat a;
    public static final VertexFormat b;
    public static final VertexFormat c;
    public static final VertexFormat d;
    public static final VertexFormatElement e;
    public static final VertexFormatElement f;
    public static final VertexFormatElement g;
    public static final VertexFormatElement h;
    public static final VertexFormatElement i;
    public static final VertexFormatElement j;
    private static final String m = "CL_00002403";
    
    static {
        DefaultVertexFormats.zerodayisaminecraftcheat = new VertexFormat();
        DefaultVertexFormats.zeroday = new VertexFormat();
        k = DefaultVertexFormats.zerodayisaminecraftcheat;
        l = DefaultVertexFormats.zeroday;
        sigma = new VertexFormat();
        pandora = new VertexFormat();
        zues = new VertexFormat();
        flux = new VertexFormat();
        vape = new VertexFormat();
        momgetthecamera = new VertexFormat();
        a = new VertexFormat();
        b = new VertexFormat();
        c = new VertexFormat();
        d = new VertexFormat();
        e = new VertexFormatElement(0, VertexFormatElement.zerodayisaminecraftcheat.zerodayisaminecraftcheat, VertexFormatElement.zeroday.zerodayisaminecraftcheat, 3);
        f = new VertexFormatElement(0, VertexFormatElement.zerodayisaminecraftcheat.zeroday, VertexFormatElement.zeroday.sigma, 4);
        g = new VertexFormatElement(0, VertexFormatElement.zerodayisaminecraftcheat.zerodayisaminecraftcheat, VertexFormatElement.zeroday.pandora, 2);
        h = new VertexFormatElement(1, VertexFormatElement.zerodayisaminecraftcheat.zues, VertexFormatElement.zeroday.pandora, 2);
        i = new VertexFormatElement(0, VertexFormatElement.zerodayisaminecraftcheat.sigma, VertexFormatElement.zeroday.zeroday, 3);
        j = new VertexFormatElement(0, VertexFormatElement.zerodayisaminecraftcheat.sigma, VertexFormatElement.zeroday.vape, 1);
        DefaultVertexFormats.zerodayisaminecraftcheat.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.zerodayisaminecraftcheat.zerodayisaminecraftcheat(DefaultVertexFormats.f);
        DefaultVertexFormats.zerodayisaminecraftcheat.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.zerodayisaminecraftcheat.zerodayisaminecraftcheat(DefaultVertexFormats.h);
        DefaultVertexFormats.zeroday.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.zeroday.zerodayisaminecraftcheat(DefaultVertexFormats.f);
        DefaultVertexFormats.zeroday.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.zeroday.zerodayisaminecraftcheat(DefaultVertexFormats.i);
        DefaultVertexFormats.zeroday.zerodayisaminecraftcheat(DefaultVertexFormats.j);
        DefaultVertexFormats.sigma.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.sigma.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.sigma.zerodayisaminecraftcheat(DefaultVertexFormats.i);
        DefaultVertexFormats.sigma.zerodayisaminecraftcheat(DefaultVertexFormats.j);
        DefaultVertexFormats.pandora.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.pandora.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.pandora.zerodayisaminecraftcheat(DefaultVertexFormats.f);
        DefaultVertexFormats.pandora.zerodayisaminecraftcheat(DefaultVertexFormats.h);
        DefaultVertexFormats.zues.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.flux.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.flux.zerodayisaminecraftcheat(DefaultVertexFormats.f);
        DefaultVertexFormats.vape.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.vape.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.momgetthecamera.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.momgetthecamera.zerodayisaminecraftcheat(DefaultVertexFormats.i);
        DefaultVertexFormats.momgetthecamera.zerodayisaminecraftcheat(DefaultVertexFormats.j);
        DefaultVertexFormats.a.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.a.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.a.zerodayisaminecraftcheat(DefaultVertexFormats.f);
        DefaultVertexFormats.b.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.b.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.b.zerodayisaminecraftcheat(DefaultVertexFormats.i);
        DefaultVertexFormats.b.zerodayisaminecraftcheat(DefaultVertexFormats.j);
        DefaultVertexFormats.c.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.c.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.c.zerodayisaminecraftcheat(DefaultVertexFormats.h);
        DefaultVertexFormats.c.zerodayisaminecraftcheat(DefaultVertexFormats.f);
        DefaultVertexFormats.d.zerodayisaminecraftcheat(DefaultVertexFormats.e);
        DefaultVertexFormats.d.zerodayisaminecraftcheat(DefaultVertexFormats.g);
        DefaultVertexFormats.d.zerodayisaminecraftcheat(DefaultVertexFormats.f);
        DefaultVertexFormats.d.zerodayisaminecraftcheat(DefaultVertexFormats.i);
        DefaultVertexFormats.d.zerodayisaminecraftcheat(DefaultVertexFormats.j);
    }
    
    public static void zerodayisaminecraftcheat() {
        if (Config.aC()) {
            DefaultVertexFormats.zerodayisaminecraftcheat = sigma.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat();
            DefaultVertexFormats.zeroday = sigma.zerodayisaminecraftcheat.c.zeroday();
        }
        else {
            DefaultVertexFormats.zerodayisaminecraftcheat = DefaultVertexFormats.k;
            DefaultVertexFormats.zeroday = DefaultVertexFormats.l;
        }
        if (Reflector.bQ.sigma()) {
            final VertexFormat vertexformat = DefaultVertexFormats.zeroday;
            final VertexFormat vertexformat2 = (VertexFormat)Reflector.zerodayisaminecraftcheat(Reflector.bQ);
            vertexformat2.zerodayisaminecraftcheat();
            for (int i = 0; i < vertexformat.a(); ++i) {
                vertexformat2.zerodayisaminecraftcheat(vertexformat.sigma(i));
            }
        }
    }
}

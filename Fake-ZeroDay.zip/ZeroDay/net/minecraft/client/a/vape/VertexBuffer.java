// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.vape;

import org.lwjgl.opengl.GL11;
import java.nio.ByteBuffer;
import net.minecraft.client.a.OpenGlHelper;

public class VertexBuffer
{
    private int zerodayisaminecraftcheat;
    private final VertexFormat zeroday;
    private int sigma;
    
    public VertexBuffer(final VertexFormat vertexFormatIn) {
        this.zeroday = vertexFormatIn;
        this.zerodayisaminecraftcheat = OpenGlHelper.zues();
    }
    
    public void zerodayisaminecraftcheat() {
        OpenGlHelper.vape(OpenGlHelper.J, this.zerodayisaminecraftcheat);
    }
    
    public void zerodayisaminecraftcheat(final ByteBuffer p_181722_1_) {
        this.zerodayisaminecraftcheat();
        OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.J, p_181722_1_, 35044);
        this.zeroday();
        this.sigma = p_181722_1_.limit() / this.zeroday.vape();
    }
    
    public void zerodayisaminecraftcheat(final int mode) {
        GL11.glDrawArrays(mode, 0, this.sigma);
    }
    
    public void zeroday() {
        OpenGlHelper.vape(OpenGlHelper.J, 0);
    }
    
    public void sigma() {
        if (this.zerodayisaminecraftcheat >= 0) {
            OpenGlHelper.vape(this.zerodayisaminecraftcheat);
            this.zerodayisaminecraftcheat = -1;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.vape;

import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import java.util.List;
import org.apache.logging.log4j.Logger;

public class VertexFormat
{
    private static final Logger zerodayisaminecraftcheat;
    private final List<VertexFormatElement> zeroday;
    private final List<Integer> sigma;
    private int pandora;
    private int zues;
    private List<Integer> flux;
    private int vape;
    private static /* synthetic */ int[] momgetthecamera;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public VertexFormat(final VertexFormat vertexFormatIn) {
        this();
        for (int i = 0; i < vertexFormatIn.a(); ++i) {
            this.zerodayisaminecraftcheat(vertexFormatIn.sigma(i));
        }
        this.pandora = vertexFormatIn.vape();
    }
    
    public VertexFormat() {
        this.zeroday = (List<VertexFormatElement>)Lists.newArrayList();
        this.sigma = (List<Integer>)Lists.newArrayList();
        this.pandora = 0;
        this.zues = -1;
        this.flux = (List<Integer>)Lists.newArrayList();
        this.vape = -1;
    }
    
    public void zerodayisaminecraftcheat() {
        this.zeroday.clear();
        this.sigma.clear();
        this.zues = -1;
        this.flux.clear();
        this.vape = -1;
        this.pandora = 0;
    }
    
    public VertexFormat zerodayisaminecraftcheat(final VertexFormatElement p_181721_1_) {
        if (p_181721_1_.flux() && this.c()) {
            VertexFormat.zerodayisaminecraftcheat.warn("VertexFormat error: Trying to add a position VertexFormatElement when one already exists, ignoring.");
            return this;
        }
        this.zeroday.add(p_181721_1_);
        this.sigma.add(this.pandora);
        switch (b()[p_181721_1_.zeroday().ordinal()]) {
            case 2: {
                this.vape = this.pandora;
                break;
            }
            case 3: {
                this.zues = this.pandora;
                break;
            }
            case 4: {
                this.flux.add(p_181721_1_.pandora(), this.pandora);
                break;
            }
        }
        this.pandora += p_181721_1_.zues();
        return this;
    }
    
    public boolean zeroday() {
        return this.vape >= 0;
    }
    
    public int sigma() {
        return this.vape;
    }
    
    public boolean pandora() {
        return this.zues >= 0;
    }
    
    public int zues() {
        return this.zues;
    }
    
    public boolean zerodayisaminecraftcheat(final int id) {
        return this.flux.size() - 1 >= id;
    }
    
    public int zeroday(final int id) {
        return this.flux.get(id);
    }
    
    @Override
    public String toString() {
        String s = "format: " + this.zeroday.size() + " elements: ";
        for (int i = 0; i < this.zeroday.size(); ++i) {
            s = String.valueOf(s) + this.zeroday.get(i).toString();
            if (i != this.zeroday.size() - 1) {
                s = String.valueOf(s) + " ";
            }
        }
        return s;
    }
    
    private boolean c() {
        for (int i = 0, j = this.zeroday.size(); i < j; ++i) {
            final VertexFormatElement vertexformatelement = this.zeroday.get(i);
            if (vertexformatelement.flux()) {
                return true;
            }
        }
        return false;
    }
    
    public int flux() {
        return this.vape() / 4;
    }
    
    public int vape() {
        return this.pandora;
    }
    
    public List<VertexFormatElement> momgetthecamera() {
        return this.zeroday;
    }
    
    public int a() {
        return this.zeroday.size();
    }
    
    public VertexFormatElement sigma(final int index) {
        return this.zeroday.get(index);
    }
    
    public int pandora(final int p_181720_1_) {
        return this.sigma.get(p_181720_1_);
    }
    
    @Override
    public boolean equals(final Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        }
        if (p_equals_1_ != null && this.getClass() == p_equals_1_.getClass()) {
            final VertexFormat vertexformat = (VertexFormat)p_equals_1_;
            return this.pandora == vertexformat.pandora && this.zeroday.equals(vertexformat.zeroday) && this.sigma.equals(vertexformat.sigma);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        int i = this.zeroday.hashCode();
        i = 31 * i + this.sigma.hashCode();
        i = 31 * i + this.pandora;
        return i;
    }
    
    static /* synthetic */ int[] b() {
        final int[] momgetthecamera = VertexFormat.momgetthecamera;
        if (momgetthecamera != null) {
            return momgetthecamera;
        }
        final int[] momgetthecamera2 = new int[VertexFormatElement.zeroday.values().length];
        try {
            momgetthecamera2[VertexFormatElement.zeroday.flux.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            momgetthecamera2[VertexFormatElement.zeroday.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            momgetthecamera2[VertexFormatElement.zeroday.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            momgetthecamera2[VertexFormatElement.zeroday.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            momgetthecamera2[VertexFormatElement.zeroday.vape.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            momgetthecamera2[VertexFormatElement.zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            momgetthecamera2[VertexFormatElement.zeroday.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        return VertexFormat.momgetthecamera = momgetthecamera2;
    }
}

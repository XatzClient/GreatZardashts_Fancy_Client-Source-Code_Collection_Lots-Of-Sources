// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.vape;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class VertexFormatElement
{
    private static final Logger zerodayisaminecraftcheat;
    private final zerodayisaminecraftcheat zeroday;
    private final zeroday sigma;
    private int pandora;
    private int zues;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public VertexFormatElement(final int indexIn, final zerodayisaminecraftcheat typeIn, final zeroday usageIn, final int count) {
        if (!this.zerodayisaminecraftcheat(indexIn, usageIn)) {
            VertexFormatElement.zerodayisaminecraftcheat.warn("Multiple vertex elements of the same type other than UVs are not supported. Forcing type to UV.");
            this.sigma = VertexFormatElement.zeroday.pandora;
        }
        else {
            this.sigma = usageIn;
        }
        this.zeroday = typeIn;
        this.pandora = indexIn;
        this.zues = count;
    }
    
    private final boolean zerodayisaminecraftcheat(final int p_177372_1_, final zeroday p_177372_2_) {
        return p_177372_1_ == 0 || p_177372_2_ == VertexFormatElement.zeroday.pandora;
    }
    
    public final zerodayisaminecraftcheat zerodayisaminecraftcheat() {
        return this.zeroday;
    }
    
    public final zeroday zeroday() {
        return this.sigma;
    }
    
    public final int sigma() {
        return this.zues;
    }
    
    public final int pandora() {
        return this.pandora;
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.zues) + "," + this.sigma.zerodayisaminecraftcheat() + "," + this.zeroday.zeroday();
    }
    
    public final int zues() {
        return this.zeroday.zerodayisaminecraftcheat() * this.zues;
    }
    
    public final boolean flux() {
        return this.sigma == VertexFormatElement.zeroday.zerodayisaminecraftcheat;
    }
    
    @Override
    public boolean equals(final Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        }
        if (p_equals_1_ != null && this.getClass() == p_equals_1_.getClass()) {
            final VertexFormatElement vertexformatelement = (VertexFormatElement)p_equals_1_;
            return this.zues == vertexformatelement.zues && this.pandora == vertexformatelement.pandora && this.zeroday == vertexformatelement.zeroday && this.sigma == vertexformatelement.sigma;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        int i = this.zeroday.hashCode();
        i = 31 * i + this.sigma.hashCode();
        i = 31 * i + this.pandora;
        i = 31 * i + this.zues;
        return i;
    }
    
    public enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("FLOAT", 0, 4, "Float", 5126), 
        zeroday("UBYTE", 1, 1, "Unsigned Byte", 5121), 
        sigma("BYTE", 2, 1, "Byte", 5120), 
        pandora("USHORT", 3, 2, "Unsigned Short", 5123), 
        zues("SHORT", 4, 2, "Short", 5122), 
        flux("UINT", 5, 4, "Unsigned Int", 5125), 
        vape("INT", 6, 4, "Int", 5124);
        
        private final int momgetthecamera;
        private final String a;
        private final int b;
        
        static {
            c = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.pandora, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.flux, zerodayisaminecraftcheat.vape };
        }
        
        private zerodayisaminecraftcheat(final String s, final int n, final int sizeIn, final String displayNameIn, final int glConstantIn) {
            this.momgetthecamera = sizeIn;
            this.a = displayNameIn;
            this.b = glConstantIn;
        }
        
        public int zerodayisaminecraftcheat() {
            return this.momgetthecamera;
        }
        
        public String zeroday() {
            return this.a;
        }
        
        public int sigma() {
            return this.b;
        }
    }
    
    public enum zeroday
    {
        zerodayisaminecraftcheat("POSITION", 0, "Position"), 
        zeroday("NORMAL", 1, "Normal"), 
        sigma("COLOR", 2, "Vertex Color"), 
        pandora("UV", 3, "UV"), 
        zues("MATRIX", 4, "Bone Matrix"), 
        flux("BLEND_WEIGHT", 5, "Blend Weight"), 
        vape("PADDING", 6, "Padding");
        
        private final String momgetthecamera;
        
        static {
            a = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday, zeroday.sigma, zeroday.pandora, zeroday.zues, zeroday.flux, zeroday.vape };
        }
        
        private zeroday(final String s, final int n, final String displayNameIn) {
            this.momgetthecamera = displayNameIn;
        }
        
        public String zerodayisaminecraftcheat() {
            return this.momgetthecamera;
        }
    }
}

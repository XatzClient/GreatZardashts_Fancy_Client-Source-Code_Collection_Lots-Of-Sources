// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import java.util.Iterator;
import com.google.common.collect.Lists;
import net.minecraft.client.a.RegionRenderCacheBuilder;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class ChunkCompileTaskGenerator
{
    private final RenderChunk zerodayisaminecraftcheat;
    private final ReentrantLock zeroday;
    private final List<Runnable> sigma;
    private final zeroday pandora;
    private RegionRenderCacheBuilder zues;
    private CompiledChunk flux;
    private zerodayisaminecraftcheat vape;
    private boolean momgetthecamera;
    
    public ChunkCompileTaskGenerator(final RenderChunk renderChunkIn, final zeroday typeIn) {
        this.zeroday = new ReentrantLock();
        this.sigma = (List<Runnable>)Lists.newArrayList();
        this.vape = ChunkCompileTaskGenerator.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        this.zerodayisaminecraftcheat = renderChunkIn;
        this.pandora = typeIn;
    }
    
    public zerodayisaminecraftcheat zerodayisaminecraftcheat() {
        return this.vape;
    }
    
    public RenderChunk zeroday() {
        return this.zerodayisaminecraftcheat;
    }
    
    public CompiledChunk sigma() {
        return this.flux;
    }
    
    public void zerodayisaminecraftcheat(final CompiledChunk compiledChunkIn) {
        this.flux = compiledChunkIn;
    }
    
    public RegionRenderCacheBuilder pandora() {
        return this.zues;
    }
    
    public void zerodayisaminecraftcheat(final RegionRenderCacheBuilder regionRenderCacheBuilderIn) {
        this.zues = regionRenderCacheBuilderIn;
    }
    
    public void zerodayisaminecraftcheat(final zerodayisaminecraftcheat statusIn) {
        this.zeroday.lock();
        try {
            this.vape = statusIn;
        }
        finally {
            this.zeroday.unlock();
        }
        this.zeroday.unlock();
    }
    
    public void zues() {
        this.zeroday.lock();
        try {
            if (this.pandora == ChunkCompileTaskGenerator.zeroday.zerodayisaminecraftcheat && this.vape != ChunkCompileTaskGenerator.zerodayisaminecraftcheat.pandora) {
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(true);
            }
            this.momgetthecamera = true;
            this.vape = ChunkCompileTaskGenerator.zerodayisaminecraftcheat.pandora;
            for (final Runnable runnable : this.sigma) {
                runnable.run();
            }
        }
        finally {
            this.zeroday.unlock();
        }
        this.zeroday.unlock();
    }
    
    public void zerodayisaminecraftcheat(final Runnable p_178539_1_) {
        this.zeroday.lock();
        try {
            this.sigma.add(p_178539_1_);
            if (this.momgetthecamera) {
                p_178539_1_.run();
            }
        }
        finally {
            this.zeroday.unlock();
        }
        this.zeroday.unlock();
    }
    
    public ReentrantLock flux() {
        return this.zeroday;
    }
    
    public zeroday vape() {
        return this.pandora;
    }
    
    public boolean momgetthecamera() {
        return this.momgetthecamera;
    }
    
    public enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("PENDING", 0), 
        zeroday("COMPILING", 1), 
        sigma("UPLOADING", 2), 
        pandora("DONE", 3);
        
        static {
            zues = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.pandora };
        }
        
        private zerodayisaminecraftcheat(final String s, final int n) {
        }
    }
    
    public enum zeroday
    {
        zerodayisaminecraftcheat("REBUILD_CHUNK", 0), 
        zeroday("RESORT_TRANSPARENCY", 1);
        
        static {
            sigma = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday };
        }
        
        private zeroday(final String s, final int n) {
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import net.minecraft.client.a.vape.VertexBuffer;
import net.minecraft.client.a.GlStateManager;
import org.lwjgl.opengl.GL11;
import com.google.common.util.concurrent.Futures;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.client.Minecraft;
import com.google.common.util.concurrent.ListenableFuture;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.o.EnumWorldBlockLayer;
import java.util.Collection;
import com.google.common.collect.Queues;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.apache.logging.log4j.LogManager;
import com.google.common.util.concurrent.ListenableFutureTask;
import java.util.Queue;
import net.minecraft.client.a.VertexBufferUploader;
import net.minecraft.client.a.WorldVertexBufferUploader;
import net.minecraft.client.a.RegionRenderCacheBuilder;
import java.util.concurrent.BlockingQueue;
import java.util.List;
import java.util.concurrent.ThreadFactory;
import org.apache.logging.log4j.Logger;

public class ChunkRenderDispatcher
{
    private static final Logger zerodayisaminecraftcheat;
    private static final ThreadFactory zeroday;
    private final List<ChunkRenderWorker> sigma;
    private final BlockingQueue<ChunkCompileTaskGenerator> pandora;
    private final BlockingQueue<RegionRenderCacheBuilder> zues;
    private final WorldVertexBufferUploader flux;
    private final VertexBufferUploader vape;
    private final Queue<ListenableFutureTask<?>> momgetthecamera;
    private final ChunkRenderWorker a;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
        zeroday = new ThreadFactoryBuilder().setNameFormat("Chunk Batcher %d").setDaemon(true).build();
    }
    
    public ChunkRenderDispatcher() {
        this.sigma = (List<ChunkRenderWorker>)Lists.newArrayList();
        this.pandora = (BlockingQueue<ChunkCompileTaskGenerator>)Queues.newArrayBlockingQueue(100);
        this.zues = (BlockingQueue<RegionRenderCacheBuilder>)Queues.newArrayBlockingQueue(5);
        this.flux = new WorldVertexBufferUploader();
        this.vape = new VertexBufferUploader();
        this.momgetthecamera = (Queue<ListenableFutureTask<?>>)Queues.newArrayDeque();
        for (int i = 0; i < 2; ++i) {
            final ChunkRenderWorker chunkrenderworker = new ChunkRenderWorker(this);
            final Thread thread = ChunkRenderDispatcher.zeroday.newThread(chunkrenderworker);
            thread.start();
            this.sigma.add(chunkrenderworker);
        }
        for (int j = 0; j < 5; ++j) {
            this.zues.add(new RegionRenderCacheBuilder());
        }
        this.a = new ChunkRenderWorker(this, new RegionRenderCacheBuilder());
    }
    
    public String zerodayisaminecraftcheat() {
        return String.format("pC: %03d, pU: %1d, aB: %1d", this.pandora.size(), this.momgetthecamera.size(), this.zues.size());
    }
    
    public boolean zerodayisaminecraftcheat(final long p_178516_1_) {
        boolean flag = false;
        long i;
        do {
            boolean flag2 = false;
            synchronized (this.momgetthecamera) {
                if (!this.momgetthecamera.isEmpty()) {
                    this.momgetthecamera.poll().run();
                    flag2 = true;
                    flag = true;
                }
            }
            // monitorexit(this.momgetthecamera)
            if (p_178516_1_ == 0L) {
                break;
            }
            if (!flag2) {
                break;
            }
            i = p_178516_1_ - System.nanoTime();
        } while (i >= 0L);
        return flag;
    }
    
    public boolean zerodayisaminecraftcheat(final RenderChunk chunkRenderer) {
        chunkRenderer.sigma().lock();
        boolean flag2;
        try {
            final ChunkCompileTaskGenerator chunkcompiletaskgenerator = chunkRenderer.pandora();
            chunkcompiletaskgenerator.zerodayisaminecraftcheat(new Runnable() {
                @Override
                public void run() {
                    ChunkRenderDispatcher.this.pandora.remove(chunkcompiletaskgenerator);
                }
            });
            final boolean flag = this.pandora.offer(chunkcompiletaskgenerator);
            if (!flag) {
                chunkcompiletaskgenerator.zues();
            }
            flag2 = flag;
        }
        finally {
            chunkRenderer.sigma().unlock();
        }
        chunkRenderer.sigma().unlock();
        return flag2;
    }
    
    public boolean zeroday(final RenderChunk chunkRenderer) {
        chunkRenderer.sigma().lock();
        boolean flag;
        try {
            final ChunkCompileTaskGenerator chunkcompiletaskgenerator = chunkRenderer.pandora();
            try {
                this.a.zerodayisaminecraftcheat(chunkcompiletaskgenerator);
            }
            catch (InterruptedException ex) {}
            flag = true;
        }
        finally {
            chunkRenderer.sigma().unlock();
        }
        chunkRenderer.sigma().unlock();
        return flag;
    }
    
    public void zeroday() {
        this.zues();
        while (this.zerodayisaminecraftcheat(0L)) {}
        final List<RegionRenderCacheBuilder> list = (List<RegionRenderCacheBuilder>)Lists.newArrayList();
        while (list.size() != 5) {
            try {
                list.add(this.sigma());
            }
            catch (InterruptedException ex) {}
        }
        this.zues.addAll((Collection<?>)list);
    }
    
    public void zerodayisaminecraftcheat(final RegionRenderCacheBuilder p_178512_1_) {
        this.zues.add(p_178512_1_);
    }
    
    public RegionRenderCacheBuilder sigma() throws InterruptedException {
        return this.zues.take();
    }
    
    public ChunkCompileTaskGenerator pandora() throws InterruptedException {
        return this.pandora.take();
    }
    
    public boolean sigma(final RenderChunk chunkRenderer) {
        chunkRenderer.sigma().lock();
        boolean flag;
        try {
            final ChunkCompileTaskGenerator chunkcompiletaskgenerator = chunkRenderer.zues();
            if (chunkcompiletaskgenerator == null) {
                flag = true;
                return flag;
            }
            chunkcompiletaskgenerator.zerodayisaminecraftcheat(new Runnable() {
                @Override
                public void run() {
                    ChunkRenderDispatcher.this.pandora.remove(chunkcompiletaskgenerator);
                }
            });
            flag = this.pandora.offer(chunkcompiletaskgenerator);
        }
        finally {
            chunkRenderer.sigma().unlock();
        }
        chunkRenderer.sigma().unlock();
        return flag;
    }
    
    public ListenableFuture<Object> zerodayisaminecraftcheat(final EnumWorldBlockLayer player, final WorldRenderer p_178503_2_, final RenderChunk chunkRenderer, final CompiledChunk compiledChunkIn) {
        if (Minecraft.s().W()) {
            if (OpenGlHelper.flux()) {
                this.zerodayisaminecraftcheat(p_178503_2_, chunkRenderer.zeroday(player.ordinal()));
            }
            else {
                this.zerodayisaminecraftcheat(p_178503_2_, ((ListedRenderChunk)chunkRenderer).zerodayisaminecraftcheat(player, compiledChunkIn), chunkRenderer);
            }
            p_178503_2_.sigma(0.0, 0.0, 0.0);
            return (ListenableFuture<Object>)Futures.immediateFuture((Object)null);
        }
        final ListenableFutureTask<Object> listenablefuturetask = (ListenableFutureTask<Object>)ListenableFutureTask.create((Runnable)new Runnable() {
            @Override
            public void run() {
                ChunkRenderDispatcher.this.zerodayisaminecraftcheat(player, p_178503_2_, chunkRenderer, compiledChunkIn);
            }
        }, (Object)null);
        synchronized (this.momgetthecamera) {
            this.momgetthecamera.add(listenablefuturetask);
            final ListenableFutureTask<Object> listenableFutureTask = listenablefuturetask;
            // monitorexit(this.momgetthecamera)
            return (ListenableFuture<Object>)listenableFutureTask;
        }
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer p_178510_1_, final int p_178510_2_, final RenderChunk chunkRenderer) {
        GL11.glNewList(p_178510_2_, 4864);
        GlStateManager.v();
        chunkRenderer.flux();
        this.flux.zerodayisaminecraftcheat(p_178510_1_);
        GlStateManager.w();
        GL11.glEndList();
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer p_178506_1_, final VertexBuffer vertexBufferIn) {
        this.vape.zerodayisaminecraftcheat(vertexBufferIn);
        this.vape.zerodayisaminecraftcheat(p_178506_1_);
    }
    
    public void zues() {
        while (!this.pandora.isEmpty()) {
            final ChunkCompileTaskGenerator chunkcompiletaskgenerator = this.pandora.poll();
            if (chunkcompiletaskgenerator != null) {
                chunkcompiletaskgenerator.zues();
            }
        }
    }
}

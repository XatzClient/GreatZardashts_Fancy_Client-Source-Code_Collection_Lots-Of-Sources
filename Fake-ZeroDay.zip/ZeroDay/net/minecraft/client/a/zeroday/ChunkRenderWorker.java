// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import java.util.ArrayList;
import net.minecraft.vape.Entity;
import java.util.concurrent.CancellationException;
import java.util.List;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.Futures;
import net.minecraft.o.EnumWorldBlockLayer;
import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.sigma.CrashReport;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.a.RegionRenderCacheBuilder;
import org.apache.logging.log4j.Logger;

public class ChunkRenderWorker implements Runnable
{
    private static final Logger zerodayisaminecraftcheat;
    private final ChunkRenderDispatcher zeroday;
    private final RegionRenderCacheBuilder sigma;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public ChunkRenderWorker(final ChunkRenderDispatcher p_i46201_1_) {
        this(p_i46201_1_, null);
    }
    
    public ChunkRenderWorker(final ChunkRenderDispatcher chunkRenderDispatcherIn, final RegionRenderCacheBuilder regionRenderCacheBuilderIn) {
        this.zeroday = chunkRenderDispatcherIn;
        this.sigma = regionRenderCacheBuilderIn;
    }
    
    @Override
    public void run() {
        try {
            while (true) {
                this.zerodayisaminecraftcheat(this.zeroday.pandora());
            }
        }
        catch (InterruptedException var3) {
            ChunkRenderWorker.zerodayisaminecraftcheat.debug("Stopping due to interrupt");
        }
        catch (Throwable throwable) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Batching chunks");
            Minecraft.s().zerodayisaminecraftcheat(Minecraft.s().sigma(crashreport));
        }
    }
    
    protected void zerodayisaminecraftcheat(final ChunkCompileTaskGenerator generator) throws InterruptedException {
        generator.flux().lock();
        try {
            if (generator.zerodayisaminecraftcheat() != ChunkCompileTaskGenerator.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
                if (!generator.momgetthecamera()) {
                    ChunkRenderWorker.zerodayisaminecraftcheat.warn("Chunk render task was " + generator.zerodayisaminecraftcheat() + " when I expected it to be pending; ignoring task");
                }
                return;
            }
            generator.zerodayisaminecraftcheat(ChunkCompileTaskGenerator.zerodayisaminecraftcheat.zeroday);
        }
        finally {
            generator.flux().unlock();
        }
        generator.flux().unlock();
        final Entity lvt_2_1_ = Minecraft.s().V();
        if (lvt_2_1_ == null) {
            generator.zues();
        }
        else {
            generator.zerodayisaminecraftcheat(this.zeroday());
            final float f = (float)lvt_2_1_.s;
            final float f2 = (float)lvt_2_1_.t + lvt_2_1_.aI();
            final float f3 = (float)lvt_2_1_.u;
            final ChunkCompileTaskGenerator.zeroday chunkcompiletaskgenerator$type = generator.vape();
            if (chunkcompiletaskgenerator$type == ChunkCompileTaskGenerator.zeroday.zerodayisaminecraftcheat) {
                generator.zeroday().zeroday(f, f2, f3, generator);
            }
            else if (chunkcompiletaskgenerator$type == ChunkCompileTaskGenerator.zeroday.zeroday) {
                generator.zeroday().zerodayisaminecraftcheat(f, f2, f3, generator);
            }
            generator.flux().lock();
            try {
                if (generator.zerodayisaminecraftcheat() != ChunkCompileTaskGenerator.zerodayisaminecraftcheat.zeroday) {
                    if (!generator.momgetthecamera()) {
                        ChunkRenderWorker.zerodayisaminecraftcheat.warn("Chunk render task was " + generator.zerodayisaminecraftcheat() + " when I expected it to be compiling; aborting task");
                    }
                    this.zeroday(generator);
                    return;
                }
                generator.zerodayisaminecraftcheat(ChunkCompileTaskGenerator.zerodayisaminecraftcheat.sigma);
            }
            finally {
                generator.flux().unlock();
            }
            generator.flux().unlock();
            final CompiledChunk lvt_7_1_ = generator.sigma();
            final ArrayList lvt_8_1_ = Lists.newArrayList();
            if (chunkcompiletaskgenerator$type == ChunkCompileTaskGenerator.zeroday.zerodayisaminecraftcheat) {
                EnumWorldBlockLayer[] values;
                for (int length = (values = EnumWorldBlockLayer.values()).length, i = 0; i < length; ++i) {
                    final EnumWorldBlockLayer enumworldblocklayer = values[i];
                    if (lvt_7_1_.pandora(enumworldblocklayer)) {
                        lvt_8_1_.add(this.zeroday.zerodayisaminecraftcheat(enumworldblocklayer, generator.pandora().zerodayisaminecraftcheat(enumworldblocklayer), generator.zeroday(), lvt_7_1_));
                    }
                }
            }
            else if (chunkcompiletaskgenerator$type == ChunkCompileTaskGenerator.zeroday.zeroday) {
                lvt_8_1_.add(this.zeroday.zerodayisaminecraftcheat(EnumWorldBlockLayer.pandora, generator.pandora().zerodayisaminecraftcheat(EnumWorldBlockLayer.pandora), generator.zeroday(), lvt_7_1_));
            }
            final ListenableFuture<List<Object>> listenablefuture = (ListenableFuture<List<Object>>)Futures.allAsList((Iterable)lvt_8_1_);
            generator.zerodayisaminecraftcheat(new Runnable() {
                @Override
                public void run() {
                    listenablefuture.cancel(false);
                }
            });
            Futures.addCallback((ListenableFuture)listenablefuture, (FutureCallback)new FutureCallback<List<Object>>() {
                public void zerodayisaminecraftcheat(final List<Object> p_onSuccess_1_) {
                    ChunkRenderWorker.this.zeroday(generator);
                    generator.flux().lock();
                    Label_0129: {
                        try {
                            if (generator.zerodayisaminecraftcheat() == ChunkCompileTaskGenerator.zerodayisaminecraftcheat.sigma) {
                                generator.zerodayisaminecraftcheat(ChunkCompileTaskGenerator.zerodayisaminecraftcheat.pandora);
                                break Label_0129;
                            }
                            if (!generator.momgetthecamera()) {
                                ChunkRenderWorker.zerodayisaminecraftcheat.warn("Chunk render task was " + generator.zerodayisaminecraftcheat() + " when I expected it to be uploading; aborting task");
                            }
                        }
                        finally {
                            generator.flux().unlock();
                        }
                        generator.flux().unlock();
                        return;
                    }
                    generator.zeroday().zerodayisaminecraftcheat(lvt_7_1_);
                }
                
                public void onFailure(final Throwable p_onFailure_1_) {
                    ChunkRenderWorker.this.zeroday(generator);
                    if (!(p_onFailure_1_ instanceof CancellationException) && !(p_onFailure_1_ instanceof InterruptedException)) {
                        Minecraft.s().zerodayisaminecraftcheat(CrashReport.zerodayisaminecraftcheat(p_onFailure_1_, "Rendering chunk"));
                    }
                }
            });
        }
    }
    
    private RegionRenderCacheBuilder zeroday() throws InterruptedException {
        return (this.sigma != null) ? this.sigma : this.zeroday.sigma();
    }
    
    private void zeroday(final ChunkCompileTaskGenerator taskGenerator) {
        if (this.sigma == null) {
            this.zeroday.zerodayisaminecraftcheat(taskGenerator.pandora());
        }
    }
}

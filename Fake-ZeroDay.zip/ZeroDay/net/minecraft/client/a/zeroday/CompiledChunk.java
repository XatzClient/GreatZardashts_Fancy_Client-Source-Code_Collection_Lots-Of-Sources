// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import com.google.common.collect.Lists;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.n.TileEntity;
import java.util.List;

public class CompiledChunk
{
    public static final CompiledChunk zerodayisaminecraftcheat;
    private final boolean[] zeroday;
    private final boolean[] sigma;
    private boolean pandora;
    private final List<TileEntity> zues;
    private SetVisibility flux;
    private WorldRenderer.zerodayisaminecraftcheat vape;
    
    static {
        zerodayisaminecraftcheat = new CompiledChunk() {
            @Override
            protected void zerodayisaminecraftcheat(final EnumWorldBlockLayer layer) {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public void sigma(final EnumWorldBlockLayer layer) {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public boolean zerodayisaminecraftcheat(final EnumFacing facing, final EnumFacing facing2) {
                return false;
            }
        };
    }
    
    public CompiledChunk() {
        this.zeroday = new boolean[EnumWorldBlockLayer.values().length];
        this.sigma = new boolean[EnumWorldBlockLayer.values().length];
        this.pandora = true;
        this.zues = (List<TileEntity>)Lists.newArrayList();
        this.flux = new SetVisibility();
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    protected void zerodayisaminecraftcheat(final EnumWorldBlockLayer layer) {
        this.pandora = false;
        this.zeroday[layer.ordinal()] = true;
    }
    
    public boolean zeroday(final EnumWorldBlockLayer layer) {
        return !this.zeroday[layer.ordinal()];
    }
    
    public void sigma(final EnumWorldBlockLayer layer) {
        this.sigma[layer.ordinal()] = true;
    }
    
    public boolean pandora(final EnumWorldBlockLayer layer) {
        return this.sigma[layer.ordinal()];
    }
    
    public List<TileEntity> zeroday() {
        return this.zues;
    }
    
    public void zerodayisaminecraftcheat(final TileEntity tileEntityIn) {
        this.zues.add(tileEntityIn);
    }
    
    public boolean zerodayisaminecraftcheat(final EnumFacing facing, final EnumFacing facing2) {
        return this.flux.zerodayisaminecraftcheat(facing, facing2);
    }
    
    public void zerodayisaminecraftcheat(final SetVisibility visibility) {
        this.flux = visibility;
    }
    
    public WorldRenderer.zerodayisaminecraftcheat sigma() {
        return this.vape;
    }
    
    public void zerodayisaminecraftcheat(final WorldRenderer.zerodayisaminecraftcheat stateIn) {
        this.vape = stateIn;
    }
}

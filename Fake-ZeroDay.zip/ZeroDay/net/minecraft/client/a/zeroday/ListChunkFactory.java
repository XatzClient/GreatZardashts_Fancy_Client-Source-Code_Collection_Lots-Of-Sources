// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import net.minecraft.o.BlockPos;
import net.minecraft.client.a.RenderGlobal;
import net.minecraft.q.World;

public class ListChunkFactory implements IRenderChunkFactory
{
    @Override
    public RenderChunk zerodayisaminecraftcheat(final World worldIn, final RenderGlobal globalRenderer, final BlockPos pos, final int index) {
        return new ListedRenderChunk(worldIn, globalRenderer, pos, index);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import net.minecraft.client.a.GLAllocation;
import net.minecraft.o.EnumWorldBlockLayer;
import net.minecraft.o.BlockPos;
import net.minecraft.client.a.RenderGlobal;
import net.minecraft.q.World;

public class ListedRenderChunk extends RenderChunk
{
    private final int pandora;
    
    public ListedRenderChunk(final World worldIn, final RenderGlobal renderGlobalIn, final BlockPos pos, final int indexIn) {
        super(worldIn, renderGlobalIn, pos, indexIn);
        this.pandora = GLAllocation.zerodayisaminecraftcheat(EnumWorldBlockLayer.values().length);
    }
    
    public int zerodayisaminecraftcheat(final EnumWorldBlockLayer layer, final CompiledChunk p_178600_2_) {
        return p_178600_2_.zeroday(layer) ? -1 : (this.pandora + layer.ordinal());
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        super.zerodayisaminecraftcheat();
        GLAllocation.zerodayisaminecraftcheat(this.pandora, EnumWorldBlockLayer.values().length);
    }
}

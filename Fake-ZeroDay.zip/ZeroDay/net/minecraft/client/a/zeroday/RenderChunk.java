// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import net.minecraft.zerodayisaminecraftcheat.BlockCactus;
import net.minecraft.zerodayisaminecraftcheat.BlockRedstoneWire;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.flux.TileEntitySpecialRenderer;
import net.minecraft.n.TileEntity;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import java.util.Iterator;
import net.minecraft.client.a.BlockRendererDispatcher;
import java.util.HashSet;
import net.minecraft.client.a.RegionRenderCache;
import java.util.Collection;
import sigma.zerodayisaminecraftcheat.b;
import net.minecraft.q.IBlockAccess;
import net.minecraft.client.a.flux.TileEntityRendererDispatcher;
import net.minecraft.o.Vec3i;
import net.minecraft.l.BlockPosM;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.l.Reflector;
import net.minecraft.l.Config;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.GLAllocation;
import com.google.common.collect.Sets;
import net.minecraft.o.EnumWorldBlockLayer;
import java.util.EnumMap;
import net.minecraft.o.AxisAlignedBB;
import net.minecraft.client.a.vape.VertexBuffer;
import java.nio.FloatBuffer;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import net.minecraft.o.BlockPos;
import net.minecraft.client.a.RenderGlobal;
import net.minecraft.q.World;

public class RenderChunk
{
    private World pandora;
    private final RenderGlobal zues;
    public static int zerodayisaminecraftcheat;
    private BlockPos flux;
    public CompiledChunk zeroday;
    private final ReentrantLock vape;
    private final ReentrantLock momgetthecamera;
    private ChunkCompileTaskGenerator a;
    private final Set b;
    private final int c;
    private final FloatBuffer d;
    private final VertexBuffer[] e;
    public AxisAlignedBB sigma;
    private int f;
    private boolean g;
    private EnumMap h;
    private static final String i = "CL_00002452";
    private BlockPos[] j;
    private static EnumWorldBlockLayer[] k;
    private EnumWorldBlockLayer[] l;
    private boolean m;
    
    static {
        RenderChunk.k = EnumWorldBlockLayer.values();
    }
    
    public RenderChunk(final World worldIn, final RenderGlobal renderGlobalIn, final BlockPos blockPosIn, final int indexIn) {
        this.zeroday = CompiledChunk.zerodayisaminecraftcheat;
        this.vape = new ReentrantLock();
        this.momgetthecamera = new ReentrantLock();
        this.a = null;
        this.b = Sets.newHashSet();
        this.d = GLAllocation.zues(16);
        this.e = new VertexBuffer[EnumWorldBlockLayer.values().length];
        this.f = -1;
        this.g = true;
        this.j = new BlockPos[EnumFacing.vape.length];
        this.l = new EnumWorldBlockLayer[1];
        this.m = (Config.b() && !Reflector.bR.zeroday());
        this.pandora = worldIn;
        this.zues = renderGlobalIn;
        this.c = indexIn;
        if (!blockPosIn.equals(this.a())) {
            this.zerodayisaminecraftcheat(blockPosIn);
        }
        if (OpenGlHelper.flux()) {
            for (int i = 0; i < EnumWorldBlockLayer.values().length; ++i) {
                this.e[i] = new VertexBuffer(DefaultVertexFormats.zerodayisaminecraftcheat);
            }
        }
    }
    
    public boolean zerodayisaminecraftcheat(final int frameIndexIn) {
        if (this.f == frameIndexIn) {
            return false;
        }
        this.f = frameIndexIn;
        return true;
    }
    
    public VertexBuffer zeroday(final int layer) {
        return this.e[layer];
    }
    
    public void zerodayisaminecraftcheat(final BlockPos pos) {
        this.momgetthecamera();
        this.flux = pos;
        this.sigma = new AxisAlignedBB(pos, pos.zeroday(16, 16, 16));
        this.c();
        for (int i = 0; i < this.j.length; ++i) {
            this.j[i] = null;
        }
    }
    
    public void zerodayisaminecraftcheat(final float x, final float y, final float z, final ChunkCompileTaskGenerator generator) {
        final CompiledChunk compiledchunk = generator.sigma();
        if (compiledchunk.sigma() != null && !compiledchunk.zeroday(EnumWorldBlockLayer.pandora)) {
            final WorldRenderer worldrenderer = generator.pandora().zerodayisaminecraftcheat(EnumWorldBlockLayer.pandora);
            this.zerodayisaminecraftcheat(worldrenderer, this.flux);
            worldrenderer.zerodayisaminecraftcheat(compiledchunk.sigma());
            this.zerodayisaminecraftcheat(EnumWorldBlockLayer.pandora, x, y, z, worldrenderer, compiledchunk);
        }
    }
    
    public void zeroday(final float x, final float y, final float z, final ChunkCompileTaskGenerator generator) {
        final CompiledChunk compiledchunk = new CompiledChunk();
        final boolean flag = true;
        final BlockPos blockpos = this.flux;
        final BlockPos blockpos2 = blockpos.zeroday(15, 15, 15);
        generator.flux().lock();
        RegionRenderCache regionrendercache;
        try {
            if (generator.zerodayisaminecraftcheat() != ChunkCompileTaskGenerator.zerodayisaminecraftcheat.zeroday) {
                return;
            }
            if (this.pandora == null) {
                return;
            }
            regionrendercache = this.zerodayisaminecraftcheat(this.pandora, blockpos.zeroday(-1, -1, -1), blockpos2.zeroday(1, 1, 1), 1);
            generator.zerodayisaminecraftcheat(compiledchunk);
        }
        finally {
            generator.flux().unlock();
        }
        generator.flux().unlock();
        final VisGraph var10 = new VisGraph();
        final HashSet var11 = Sets.newHashSet();
        if (!regionrendercache.zerodayisaminecraftcheat()) {
            ++RenderChunk.zerodayisaminecraftcheat;
            final boolean[] aboolean = new boolean[EnumWorldBlockLayer.values().length];
            final BlockRendererDispatcher blockrendererdispatcher = Minecraft.s().X();
            final Iterator iterator = BlockPosM.zerodayisaminecraftcheat(blockpos, blockpos2).iterator();
            final boolean flag2 = Reflector.aS.zeroday();
            final boolean flag3 = Reflector.aX.zeroday();
            final boolean flag4 = Reflector.r.zeroday();
            while (iterator.hasNext()) {
                final BlockPosM blockposm = iterator.next();
                final IBlockState iblockstate = regionrendercache.zeroday(blockposm);
                final Block block = iblockstate.sigma();
                if (block.g()) {
                    var10.zerodayisaminecraftcheat(blockposm);
                }
                boolean flag5;
                if (flag2) {
                    flag5 = Reflector.zeroday(block, Reflector.aS, iblockstate);
                }
                else {
                    flag5 = block.f();
                }
                if (flag5) {
                    final TileEntity tileentity = regionrendercache.zerodayisaminecraftcheat(new BlockPos(blockposm));
                    final TileEntitySpecialRenderer tileentityspecialrenderer = TileEntityRendererDispatcher.zerodayisaminecraftcheat.zerodayisaminecraftcheat(tileentity);
                    if (tileentity != null && tileentityspecialrenderer != null) {
                        compiledchunk.zerodayisaminecraftcheat(tileentity);
                        if (tileentityspecialrenderer.zerodayisaminecraftcheat()) {
                            var11.add(tileentity);
                        }
                    }
                }
                EnumWorldBlockLayer[] aenumworldblocklayer;
                if (flag3) {
                    aenumworldblocklayer = RenderChunk.k;
                }
                else {
                    aenumworldblocklayer = this.l;
                    aenumworldblocklayer[0] = block.i();
                }
                for (int i = 0; i < aenumworldblocklayer.length; ++i) {
                    EnumWorldBlockLayer enumworldblocklayer = aenumworldblocklayer[i];
                    if (flag3) {
                        final boolean flag6 = Reflector.zeroday(block, Reflector.aX, enumworldblocklayer);
                        if (!flag6) {
                            continue;
                        }
                    }
                    enumworldblocklayer = this.zerodayisaminecraftcheat(block, enumworldblocklayer);
                    if (flag4) {
                        Reflector.zerodayisaminecraftcheat(Reflector.r, enumworldblocklayer);
                    }
                    final int j = enumworldblocklayer.ordinal();
                    if (block.c() != -1) {
                        final WorldRenderer worldrenderer = generator.pandora().zerodayisaminecraftcheat(j);
                        worldrenderer.zerodayisaminecraftcheat(enumworldblocklayer);
                        if (!compiledchunk.pandora(enumworldblocklayer)) {
                            compiledchunk.sigma(enumworldblocklayer);
                            this.zerodayisaminecraftcheat(worldrenderer, blockpos);
                        }
                        final boolean[] array = aboolean;
                        final int n = j;
                        array[n] |= blockrendererdispatcher.zerodayisaminecraftcheat(iblockstate, blockposm, regionrendercache, worldrenderer);
                    }
                }
            }
            EnumWorldBlockLayer[] values;
            for (int length = (values = EnumWorldBlockLayer.values()).length, k = 0; k < length; ++k) {
                final EnumWorldBlockLayer enumworldblocklayer2 = values[k];
                if (aboolean[enumworldblocklayer2.ordinal()]) {
                    compiledchunk.zerodayisaminecraftcheat(enumworldblocklayer2);
                }
                if (compiledchunk.pandora(enumworldblocklayer2)) {
                    if (Config.aC()) {
                        sigma.zerodayisaminecraftcheat.b.vape(generator.pandora().zerodayisaminecraftcheat(enumworldblocklayer2));
                    }
                    this.zerodayisaminecraftcheat(enumworldblocklayer2, x, y, z, generator.pandora().zerodayisaminecraftcheat(enumworldblocklayer2), compiledchunk);
                }
            }
        }
        compiledchunk.zerodayisaminecraftcheat(var10.zerodayisaminecraftcheat());
        this.vape.lock();
        try {
            final HashSet hashset1 = Sets.newHashSet((Iterable)var11);
            final HashSet hashset2 = Sets.newHashSet((Iterable)this.b);
            hashset1.removeAll(this.b);
            hashset2.removeAll(var11);
            this.b.clear();
            this.b.addAll(var11);
            this.zues.zerodayisaminecraftcheat(hashset2, hashset1);
        }
        finally {
            this.vape.unlock();
        }
        this.vape.unlock();
    }
    
    protected void zeroday() {
        this.vape.lock();
        try {
            if (this.a != null && this.a.zerodayisaminecraftcheat() != ChunkCompileTaskGenerator.zerodayisaminecraftcheat.pandora) {
                this.a.zues();
                this.a = null;
            }
        }
        finally {
            this.vape.unlock();
        }
        this.vape.unlock();
    }
    
    public ReentrantLock sigma() {
        return this.vape;
    }
    
    public ChunkCompileTaskGenerator pandora() {
        this.vape.lock();
        ChunkCompileTaskGenerator chunkcompiletaskgenerator;
        try {
            this.zeroday();
            this.a = new ChunkCompileTaskGenerator(this, ChunkCompileTaskGenerator.zeroday.zerodayisaminecraftcheat);
            chunkcompiletaskgenerator = this.a;
        }
        finally {
            this.vape.unlock();
        }
        this.vape.unlock();
        return chunkcompiletaskgenerator;
    }
    
    public ChunkCompileTaskGenerator zues() {
        this.vape.lock();
        ChunkCompileTaskGenerator chunkcompiletaskgenerator4;
        try {
            if (this.a != null && this.a.zerodayisaminecraftcheat() == ChunkCompileTaskGenerator.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
                final ChunkCompileTaskGenerator chunkcompiletaskgenerator2 = null;
                return chunkcompiletaskgenerator2;
            }
            if (this.a != null && this.a.zerodayisaminecraftcheat() != ChunkCompileTaskGenerator.zerodayisaminecraftcheat.pandora) {
                this.a.zues();
                this.a = null;
            }
            (this.a = new ChunkCompileTaskGenerator(this, ChunkCompileTaskGenerator.zeroday.zeroday)).zerodayisaminecraftcheat(this.zeroday);
            final ChunkCompileTaskGenerator chunkcompiletaskgenerator3 = chunkcompiletaskgenerator4 = this.a;
        }
        finally {
            this.vape.unlock();
        }
        this.vape.unlock();
        return chunkcompiletaskgenerator4;
    }
    
    private void zerodayisaminecraftcheat(final WorldRenderer worldRendererIn, final BlockPos pos) {
        worldRendererIn.zerodayisaminecraftcheat(7, DefaultVertexFormats.zerodayisaminecraftcheat);
        worldRendererIn.sigma(-pos.zerodayisaminecraftcheat(), -pos.zeroday(), (double)(-pos.sigma()));
    }
    
    private void zerodayisaminecraftcheat(final EnumWorldBlockLayer layer, final float x, final float y, final float z, final WorldRenderer worldRendererIn, final CompiledChunk compiledChunkIn) {
        if (layer == EnumWorldBlockLayer.pandora && !compiledChunkIn.zeroday(layer)) {
            worldRendererIn.zerodayisaminecraftcheat(x, y, z);
            compiledChunkIn.zerodayisaminecraftcheat(worldRendererIn.zerodayisaminecraftcheat());
        }
        worldRendererIn.flux();
    }
    
    private void c() {
        GlStateManager.v();
        GlStateManager.u();
        final float f = 1.000001f;
        GlStateManager.zeroday(-8.0f, -8.0f, -8.0f);
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        GlStateManager.zeroday(8.0f, 8.0f, 8.0f);
        GlStateManager.zerodayisaminecraftcheat(2982, this.d);
        GlStateManager.w();
    }
    
    public void flux() {
        GlStateManager.zerodayisaminecraftcheat(this.d);
    }
    
    public CompiledChunk vape() {
        return this.zeroday;
    }
    
    public void zerodayisaminecraftcheat(final CompiledChunk compiledChunkIn) {
        this.momgetthecamera.lock();
        try {
            this.zeroday = compiledChunkIn;
        }
        finally {
            this.momgetthecamera.unlock();
        }
        this.momgetthecamera.unlock();
    }
    
    public void momgetthecamera() {
        this.zeroday();
        this.zeroday = CompiledChunk.zerodayisaminecraftcheat;
    }
    
    public void zerodayisaminecraftcheat() {
        this.momgetthecamera();
        this.pandora = null;
        for (int i = 0; i < EnumWorldBlockLayer.values().length; ++i) {
            if (this.e[i] != null) {
                this.e[i].sigma();
            }
        }
    }
    
    public BlockPos a() {
        return this.flux;
    }
    
    public void zerodayisaminecraftcheat(final boolean needsUpdateIn) {
        this.g = needsUpdateIn;
    }
    
    public boolean b() {
        return this.g;
    }
    
    public BlockPos zerodayisaminecraftcheat(final EnumFacing p_181701_1_) {
        return this.zeroday(p_181701_1_);
    }
    
    public BlockPos zeroday(final EnumFacing p_getPositionOffset16_1_) {
        final int i = p_getPositionOffset16_1_.zeroday();
        BlockPos blockpos = this.j[i];
        if (blockpos == null) {
            blockpos = this.a().zerodayisaminecraftcheat(p_getPositionOffset16_1_, 16);
            this.j[i] = blockpos;
        }
        return blockpos;
    }
    
    protected RegionRenderCache zerodayisaminecraftcheat(final World p_createRegionRenderCache_1_, final BlockPos p_createRegionRenderCache_2_, final BlockPos p_createRegionRenderCache_3_, final int p_createRegionRenderCache_4_) {
        return new RegionRenderCache(p_createRegionRenderCache_1_, p_createRegionRenderCache_2_, p_createRegionRenderCache_3_, p_createRegionRenderCache_4_);
    }
    
    private EnumWorldBlockLayer zerodayisaminecraftcheat(final Block p_fixBlockLayer_1_, final EnumWorldBlockLayer p_fixBlockLayer_2_) {
        return this.m ? ((p_fixBlockLayer_2_ == EnumWorldBlockLayer.sigma) ? ((p_fixBlockLayer_1_ instanceof BlockRedstoneWire) ? p_fixBlockLayer_2_ : ((p_fixBlockLayer_1_ instanceof BlockCactus) ? p_fixBlockLayer_2_ : EnumWorldBlockLayer.zeroday)) : p_fixBlockLayer_2_) : p_fixBlockLayer_2_;
    }
}

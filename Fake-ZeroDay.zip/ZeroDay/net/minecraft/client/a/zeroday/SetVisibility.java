// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import java.util.Iterator;
import java.util.Set;
import net.minecraft.o.EnumFacing;
import java.util.BitSet;

public class SetVisibility
{
    private static final int zerodayisaminecraftcheat;
    private final BitSet zeroday;
    
    static {
        zerodayisaminecraftcheat = EnumFacing.values().length;
    }
    
    public SetVisibility() {
        this.zeroday = new BitSet(SetVisibility.zerodayisaminecraftcheat * SetVisibility.zerodayisaminecraftcheat);
    }
    
    public void zerodayisaminecraftcheat(final Set<EnumFacing> p_178620_1_) {
        for (final EnumFacing enumfacing : p_178620_1_) {
            for (final EnumFacing enumfacing2 : p_178620_1_) {
                this.zerodayisaminecraftcheat(enumfacing, enumfacing2, true);
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final EnumFacing facing, final EnumFacing facing2, final boolean p_178619_3_) {
        this.zeroday.set(facing.ordinal() + facing2.ordinal() * SetVisibility.zerodayisaminecraftcheat, p_178619_3_);
        this.zeroday.set(facing2.ordinal() + facing.ordinal() * SetVisibility.zerodayisaminecraftcheat, p_178619_3_);
    }
    
    public void zerodayisaminecraftcheat(final boolean visible) {
        this.zeroday.set(0, this.zeroday.size(), visible);
    }
    
    public boolean zerodayisaminecraftcheat(final EnumFacing facing, final EnumFacing facing2) {
        return this.zeroday.get(facing.ordinal() + facing2.ordinal() * SetVisibility.zerodayisaminecraftcheat);
    }
    
    @Override
    public String toString() {
        final StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(' ');
        EnumFacing[] values;
        for (int length = (values = EnumFacing.values()).length, i = 0; i < length; ++i) {
            final EnumFacing enumfacing = values[i];
            stringbuilder.append(' ').append(enumfacing.toString().toUpperCase().charAt(0));
        }
        stringbuilder.append('\n');
        EnumFacing[] values2;
        for (int length2 = (values2 = EnumFacing.values()).length, j = 0; j < length2; ++j) {
            final EnumFacing enumfacing2 = values2[j];
            stringbuilder.append(enumfacing2.toString().toUpperCase().charAt(0));
            EnumFacing[] values3;
            for (int length3 = (values3 = EnumFacing.values()).length, k = 0; k < length3; ++k) {
                final EnumFacing enumfacing3 = values3[k];
                if (enumfacing2 == enumfacing3) {
                    stringbuilder.append("  ");
                }
                else {
                    final boolean flag = this.zerodayisaminecraftcheat(enumfacing2, enumfacing3);
                    stringbuilder.append(' ').append(flag ? 'Y' : 'n');
                }
            }
            stringbuilder.append('\n');
        }
        return stringbuilder.toString();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zeroday;

import net.minecraft.l.IntegerCache;
import java.util.ArrayDeque;
import java.util.EnumSet;
import net.minecraft.o.EnumFacing;
import java.util.Set;
import zeroday.pandora.zerodayisaminecraftcheat.d.br;
import net.minecraft.o.BlockPos;
import java.util.BitSet;

public class VisGraph
{
    private static final int zerodayisaminecraftcheat;
    private static final int zeroday;
    private static final int sigma;
    private final BitSet pandora;
    private static final int[] zues;
    private int flux;
    
    static {
        zerodayisaminecraftcheat = (int)Math.pow(16.0, 0.0);
        zeroday = (int)Math.pow(16.0, 1.0);
        sigma = (int)Math.pow(16.0, 2.0);
        zues = new int[1352];
        final boolean flag = false;
        final boolean flag2 = true;
        int i = 0;
        for (int j = 0; j < 16; ++j) {
            for (int k = 0; k < 16; ++k) {
                for (int l = 0; l < 16; ++l) {
                    if (j == 0 || j == 15 || k == 0 || k == 15 || l == 0 || l == 15) {
                        VisGraph.zues[i++] = zerodayisaminecraftcheat(j, k, l);
                    }
                }
            }
        }
    }
    
    public VisGraph() {
        this.pandora = new BitSet(4096);
        this.flux = 4096;
    }
    
    public void zerodayisaminecraftcheat(final BlockPos pos) {
        if (br.c) {
            return;
        }
        this.pandora.set(sigma(pos), true);
        --this.flux;
    }
    
    private static int sigma(final BlockPos pos) {
        return zerodayisaminecraftcheat(pos.zerodayisaminecraftcheat() & 0xF, pos.zeroday() & 0xF, pos.sigma() & 0xF);
    }
    
    private static int zerodayisaminecraftcheat(final int x, final int y, final int z) {
        return x << 0 | y << 8 | z << 4;
    }
    
    public SetVisibility zerodayisaminecraftcheat() {
        final SetVisibility setvisibility = new SetVisibility();
        if (4096 - this.flux < 256) {
            setvisibility.zerodayisaminecraftcheat(true);
        }
        else if (this.flux == 0) {
            setvisibility.zerodayisaminecraftcheat(false);
        }
        else {
            int[] zues;
            for (int length = (zues = VisGraph.zues).length, j = 0; j < length; ++j) {
                final int i = zues[j];
                if (!this.pandora.get(i)) {
                    setvisibility.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(i));
                }
            }
        }
        return setvisibility;
    }
    
    public Set zeroday(final BlockPos pos) {
        return this.zerodayisaminecraftcheat(sigma(pos));
    }
    
    private Set zerodayisaminecraftcheat(final int p_178604_1_) {
        final EnumSet enumset = EnumSet.noneOf(EnumFacing.class);
        final ArrayDeque arraydeque = new ArrayDeque(384);
        arraydeque.add(IntegerCache.zerodayisaminecraftcheat(p_178604_1_));
        this.pandora.set(p_178604_1_, true);
        while (!arraydeque.isEmpty()) {
            final int i = arraydeque.poll();
            this.zerodayisaminecraftcheat(i, enumset);
            EnumFacing[] vape;
            for (int length = (vape = EnumFacing.vape).length, k = 0; k < length; ++k) {
                final EnumFacing enumfacing = vape[k];
                final int j = this.zerodayisaminecraftcheat(i, enumfacing);
                if (j >= 0 && !this.pandora.get(j)) {
                    this.pandora.set(j, true);
                    arraydeque.add(IntegerCache.zerodayisaminecraftcheat(j));
                }
            }
        }
        return enumset;
    }
    
    private void zerodayisaminecraftcheat(final int p_178610_1_, final Set p_178610_2_) {
        final int i = p_178610_1_ >> 0 & 0xF;
        if (i == 0) {
            p_178610_2_.add(EnumFacing.zues);
        }
        else if (i == 15) {
            p_178610_2_.add(EnumFacing.flux);
        }
        final int j = p_178610_1_ >> 8 & 0xF;
        if (j == 0) {
            p_178610_2_.add(EnumFacing.zerodayisaminecraftcheat);
        }
        else if (j == 15) {
            p_178610_2_.add(EnumFacing.zeroday);
        }
        final int k = p_178610_1_ >> 4 & 0xF;
        if (k == 0) {
            p_178610_2_.add(EnumFacing.sigma);
        }
        else if (k == 15) {
            p_178610_2_.add(EnumFacing.pandora);
        }
    }
    
    private int zerodayisaminecraftcheat(final int p_178603_1_, final EnumFacing p_178603_2_) {
        switch (VisGraph.zerodayisaminecraftcheat.zerodayisaminecraftcheat[p_178603_2_.ordinal()]) {
            case 1: {
                if ((p_178603_1_ >> 8 & 0xF) == 0x0) {
                    return -1;
                }
                return p_178603_1_ - VisGraph.sigma;
            }
            case 2: {
                if ((p_178603_1_ >> 8 & 0xF) == 0xF) {
                    return -1;
                }
                return p_178603_1_ + VisGraph.sigma;
            }
            case 3: {
                if ((p_178603_1_ >> 4 & 0xF) == 0x0) {
                    return -1;
                }
                return p_178603_1_ - VisGraph.zeroday;
            }
            case 4: {
                if ((p_178603_1_ >> 4 & 0xF) == 0xF) {
                    return -1;
                }
                return p_178603_1_ + VisGraph.zeroday;
            }
            case 5: {
                if ((p_178603_1_ >> 0 & 0xF) == 0x0) {
                    return -1;
                }
                return p_178603_1_ - VisGraph.zerodayisaminecraftcheat;
            }
            case 6: {
                if ((p_178603_1_ >> 0 & 0xF) == 0xF) {
                    return -1;
                }
                return p_178603_1_ + VisGraph.zerodayisaminecraftcheat;
            }
            default: {
                return -1;
            }
        }
    }
    
    static final class zerodayisaminecraftcheat
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002449";
        
        static {
            zerodayisaminecraftcheat = new int[EnumFacing.values().length];
            try {
                VisGraph.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                VisGraph.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.zeroday.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                VisGraph.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                VisGraph.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.pandora.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            try {
                VisGraph.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.zues.ordinal()] = 5;
            }
            catch (NoSuchFieldError noSuchFieldError5) {}
            try {
                VisGraph.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.flux.ordinal()] = 6;
            }
            catch (NoSuchFieldError noSuchFieldError6) {}
        }
    }
}

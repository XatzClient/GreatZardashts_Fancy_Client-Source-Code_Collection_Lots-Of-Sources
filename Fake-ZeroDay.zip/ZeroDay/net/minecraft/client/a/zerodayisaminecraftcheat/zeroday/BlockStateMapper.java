// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zeroday;

import java.util.Iterator;
import com.google.common.base.Objects;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import java.util.Collection;
import java.util.Collections;
import com.google.common.collect.Sets;
import com.google.common.collect.Maps;
import java.util.Set;
import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Map;

public class BlockStateMapper
{
    private Map<Block, IStateMapper> zerodayisaminecraftcheat;
    private Set<Block> zeroday;
    
    public BlockStateMapper() {
        this.zerodayisaminecraftcheat = (Map<Block, IStateMapper>)Maps.newIdentityHashMap();
        this.zeroday = (Set<Block>)Sets.newIdentityHashSet();
    }
    
    public void zerodayisaminecraftcheat(final Block p_178447_1_, final IStateMapper p_178447_2_) {
        this.zerodayisaminecraftcheat.put(p_178447_1_, p_178447_2_);
    }
    
    public void zerodayisaminecraftcheat(final Block... p_178448_1_) {
        Collections.addAll(this.zeroday, p_178448_1_);
    }
    
    public Map<IBlockState, ModelResourceLocation> zerodayisaminecraftcheat() {
        final Map<IBlockState, ModelResourceLocation> map = (Map<IBlockState, ModelResourceLocation>)Maps.newIdentityHashMap();
        for (final Block block : Block.zerodayisaminecraftcheat) {
            if (!this.zeroday.contains(block)) {
                map.putAll(((IStateMapper)Objects.firstNonNull((Object)this.zerodayisaminecraftcheat.get(block), (Object)new DefaultStateMapper())).zerodayisaminecraftcheat(block));
            }
        }
        return map;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zeroday;

import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import java.util.Map;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;

public class DefaultStateMapper extends StateMapperBase
{
    @Override
    protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
        return new ModelResourceLocation(Block.zerodayisaminecraftcheat.zeroday(state.sigma()), this.zerodayisaminecraftcheat((Map<IProperty, Comparable>)state.zeroday()));
    }
}

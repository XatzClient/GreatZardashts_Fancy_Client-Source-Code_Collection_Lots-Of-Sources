// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zeroday;

import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import java.util.Map;
import net.minecraft.zerodayisaminecraftcheat.Block;

public interface IStateMapper
{
    Map<IBlockState, ModelResourceLocation> zerodayisaminecraftcheat(final Block p0);
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zeroday;

import java.util.Collection;
import java.util.Collections;
import com.google.common.collect.Lists;
import java.util.Iterator;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.o.ResourceLocation;
import java.util.Map;
import com.google.common.collect.Maps;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import java.util.List;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;

public class StateMap extends StateMapperBase
{
    private final IProperty<?> zerodayisaminecraftcheat;
    private final String sigma;
    private final List<IProperty<?>> pandora;
    
    private StateMap(final IProperty<?> name, final String suffix, final List<IProperty<?>> ignored) {
        this.zerodayisaminecraftcheat = name;
        this.sigma = suffix;
        this.pandora = ignored;
    }
    
    @Override
    protected ModelResourceLocation zerodayisaminecraftcheat(final IBlockState state) {
        final Map<IProperty, Comparable> map = (Map<IProperty, Comparable>)Maps.newLinkedHashMap((Map)state.zeroday());
        String s;
        if (this.zerodayisaminecraftcheat == null) {
            s = Block.zerodayisaminecraftcheat.zeroday(state.sigma()).toString();
        }
        else {
            s = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(map.remove(this.zerodayisaminecraftcheat));
        }
        if (this.sigma != null) {
            s = String.valueOf(s) + this.sigma;
        }
        for (final IProperty<?> iproperty : this.pandora) {
            map.remove(iproperty);
        }
        return new ModelResourceLocation(s, this.zerodayisaminecraftcheat(map));
    }
    
    public static class zerodayisaminecraftcheat
    {
        private IProperty<?> zerodayisaminecraftcheat;
        private String zeroday;
        private final List<IProperty<?>> sigma;
        
        public zerodayisaminecraftcheat() {
            this.sigma = (List<IProperty<?>>)Lists.newArrayList();
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat(final IProperty<?> builderPropertyIn) {
            this.zerodayisaminecraftcheat = builderPropertyIn;
            return this;
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat(final String builderSuffixIn) {
            this.zeroday = builderSuffixIn;
            return this;
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat(final IProperty<?>... p_178442_1_) {
            Collections.addAll(this.sigma, p_178442_1_);
            return this;
        }
        
        public StateMap zerodayisaminecraftcheat() {
            return new StateMap(this.zerodayisaminecraftcheat, this.zeroday, this.sigma, null);
        }
    }
}

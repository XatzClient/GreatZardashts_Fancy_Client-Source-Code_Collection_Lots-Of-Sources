// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zeroday;

import net.minecraft.zerodayisaminecraftcheat.Block;
import java.util.Iterator;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import com.google.common.collect.Maps;
import net.minecraft.client.b.zeroday.ModelResourceLocation;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import java.util.Map;

public abstract class StateMapperBase implements IStateMapper
{
    protected Map<IBlockState, ModelResourceLocation> zeroday;
    
    public StateMapperBase() {
        this.zeroday = (Map<IBlockState, ModelResourceLocation>)Maps.newLinkedHashMap();
    }
    
    public String zerodayisaminecraftcheat(final Map<IProperty, Comparable> p_178131_1_) {
        final StringBuilder stringbuilder = new StringBuilder();
        for (final Map.Entry<IProperty, Comparable> entry : p_178131_1_.entrySet()) {
            if (stringbuilder.length() != 0) {
                stringbuilder.append(",");
            }
            final IProperty iproperty = entry.getKey();
            final Comparable comparable = entry.getValue();
            stringbuilder.append(iproperty.zerodayisaminecraftcheat());
            stringbuilder.append("=");
            stringbuilder.append(iproperty.zerodayisaminecraftcheat(comparable));
        }
        if (stringbuilder.length() == 0) {
            stringbuilder.append("normal");
        }
        return stringbuilder.toString();
    }
    
    @Override
    public Map<IBlockState, ModelResourceLocation> zerodayisaminecraftcheat(final Block blockIn) {
        for (final IBlockState iblockstate : blockIn.F().zerodayisaminecraftcheat()) {
            this.zeroday.put(iblockstate, this.zerodayisaminecraftcheat(iblockstate));
        }
        return this.zeroday;
    }
    
    protected abstract ModelResourceLocation zerodayisaminecraftcheat(final IBlockState p0);
}

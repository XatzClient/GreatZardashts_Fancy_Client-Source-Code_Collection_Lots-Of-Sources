// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import net.minecraft.l.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.l.Reflector;
import net.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.o.EnumFacing;
import net.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday;

public class BakedQuad implements zeroday
{
    protected final int[] zerodayisaminecraftcheat;
    protected final int zeroday;
    protected final EnumFacing sigma;
    private static final String pandora = "CL_00002512";
    private TextureAtlasSprite zues;
    private int[] flux;
    
    public BakedQuad(int[] p_i17_1_, final int p_i17_2_, final EnumFacing p_i17_3_, final TextureAtlasSprite p_i17_4_) {
        this.zues = null;
        this.flux = null;
        p_i17_1_ = zeroday(p_i17_1_);
        this.zerodayisaminecraftcheat = p_i17_1_;
        this.zeroday = p_i17_2_;
        this.sigma = p_i17_3_;
        this.zues = p_i17_4_;
    }
    
    public TextureAtlasSprite zerodayisaminecraftcheat() {
        if (this.zues == null) {
            this.zues = zerodayisaminecraftcheat(this.zeroday());
        }
        return this.zues;
    }
    
    @Override
    public String toString() {
        return "vertex: " + this.zerodayisaminecraftcheat.length / 7 + ", tint: " + this.zeroday + ", facing: " + this.sigma + ", sprite: " + this.zues;
    }
    
    public BakedQuad(int[] vertexDataIn, final int tintIndexIn, final EnumFacing faceIn) {
        this.zues = null;
        this.flux = null;
        vertexDataIn = zeroday(vertexDataIn);
        this.zerodayisaminecraftcheat = vertexDataIn;
        this.zeroday = tintIndexIn;
        this.sigma = faceIn;
    }
    
    public int[] zeroday() {
        return this.zerodayisaminecraftcheat;
    }
    
    public boolean sigma() {
        return this.zeroday != -1;
    }
    
    public int pandora() {
        return this.zeroday;
    }
    
    public EnumFacing zues() {
        return this.sigma;
    }
    
    public int[] flux() {
        if (this.flux == null) {
            this.flux = zerodayisaminecraftcheat(this.zeroday(), this.zerodayisaminecraftcheat());
        }
        return this.flux;
    }
    
    private static int[] zerodayisaminecraftcheat(final int[] p_makeVertexDataSingle_0_, final TextureAtlasSprite p_makeVertexDataSingle_1_) {
        final int[] aint = p_makeVertexDataSingle_0_.clone();
        final int i = p_makeVertexDataSingle_1_.d / p_makeVertexDataSingle_1_.sigma();
        final int j = p_makeVertexDataSingle_1_.e / p_makeVertexDataSingle_1_.pandora();
        final int k = aint.length / 4;
        for (int l = 0; l < 4; ++l) {
            final int i2 = l * k;
            final float f = Float.intBitsToFloat(aint[i2 + 4]);
            final float f2 = Float.intBitsToFloat(aint[i2 + 4 + 1]);
            final float f3 = p_makeVertexDataSingle_1_.sigma(f);
            final float f4 = p_makeVertexDataSingle_1_.pandora(f2);
            aint[i2 + 4] = Float.floatToRawIntBits(f3);
            aint[i2 + 4 + 1] = Float.floatToRawIntBits(f4);
        }
        return aint;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final zerodayisaminecraftcheat p_pipe_1_) {
        Reflector.zerodayisaminecraftcheat(Reflector.bF, p_pipe_1_, this);
    }
    
    private static TextureAtlasSprite zerodayisaminecraftcheat(final int[] p_getSpriteByUv_0_) {
        float f = 1.0f;
        float f2 = 1.0f;
        float f3 = 0.0f;
        float f4 = 0.0f;
        final int i = p_getSpriteByUv_0_.length / 4;
        for (int j = 0; j < 4; ++j) {
            final int k = j * i;
            final float f5 = Float.intBitsToFloat(p_getSpriteByUv_0_[k + 4]);
            final float f6 = Float.intBitsToFloat(p_getSpriteByUv_0_[k + 4 + 1]);
            f = Math.min(f, f5);
            f2 = Math.min(f2, f6);
            f3 = Math.max(f3, f5);
            f4 = Math.max(f4, f6);
        }
        final float f7 = (f + f3) / 2.0f;
        final float f8 = (f2 + f4) / 2.0f;
        final TextureAtlasSprite textureatlassprite = Minecraft.s().M().zerodayisaminecraftcheat(f7, f8);
        return textureatlassprite;
    }
    
    private static int[] zeroday(int[] p_fixVertexData_0_) {
        if (Config.aC()) {
            if (p_fixVertexData_0_.length == 28) {
                p_fixVertexData_0_ = sigma(p_fixVertexData_0_);
            }
        }
        else if (p_fixVertexData_0_.length == 56) {
            p_fixVertexData_0_ = pandora(p_fixVertexData_0_);
        }
        return p_fixVertexData_0_;
    }
    
    private static int[] sigma(final int[] p_expandVertexData_0_) {
        final int i = p_expandVertexData_0_.length / 4;
        final int j = i * 2;
        final int[] aint = new int[j * 4];
        for (int k = 0; k < 4; ++k) {
            System.arraycopy(p_expandVertexData_0_, k * i, aint, k * j, i);
        }
        return aint;
    }
    
    private static int[] pandora(final int[] p_compactVertexData_0_) {
        final int i = p_compactVertexData_0_.length / 4;
        final int j = i / 2;
        final int[] aint = new int[j * 4];
        for (int k = 0; k < 4; ++k) {
            System.arraycopy(p_compactVertexData_0_, k * i, aint, k * j, j);
        }
        return aint;
    }
}

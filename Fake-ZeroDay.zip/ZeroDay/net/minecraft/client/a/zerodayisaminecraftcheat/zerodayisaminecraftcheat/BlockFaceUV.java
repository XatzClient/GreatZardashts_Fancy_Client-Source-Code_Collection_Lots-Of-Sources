// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import com.google.gson.JsonArray;
import net.minecraft.o.JsonUtils;
import com.google.gson.JsonParseException;
import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonDeserializer;

public class BlockFaceUV
{
    public float[] zerodayisaminecraftcheat;
    public final int zeroday;
    
    public BlockFaceUV(final float[] uvsIn, final int rotationIn) {
        this.zerodayisaminecraftcheat = uvsIn;
        this.zeroday = rotationIn;
    }
    
    public float zerodayisaminecraftcheat(final int p_178348_1_) {
        if (this.zerodayisaminecraftcheat == null) {
            throw new NullPointerException("uvs");
        }
        final int i = this.pandora(p_178348_1_);
        return (i != 0 && i != 1) ? this.zerodayisaminecraftcheat[2] : this.zerodayisaminecraftcheat[0];
    }
    
    public float zeroday(final int p_178346_1_) {
        if (this.zerodayisaminecraftcheat == null) {
            throw new NullPointerException("uvs");
        }
        final int i = this.pandora(p_178346_1_);
        return (i != 0 && i != 3) ? this.zerodayisaminecraftcheat[3] : this.zerodayisaminecraftcheat[1];
    }
    
    private int pandora(final int p_178347_1_) {
        return (p_178347_1_ + this.zeroday / 90) % 4;
    }
    
    public int sigma(final int p_178345_1_) {
        return (p_178345_1_ + (4 - this.zeroday / 90)) % 4;
    }
    
    public void zerodayisaminecraftcheat(final float[] uvsIn) {
        if (this.zerodayisaminecraftcheat == null) {
            this.zerodayisaminecraftcheat = uvsIn;
        }
    }
    
    static class zerodayisaminecraftcheat implements JsonDeserializer<BlockFaceUV>
    {
        public BlockFaceUV zerodayisaminecraftcheat(final JsonElement p_deserialize_1_, final Type p_deserialize_2_, final JsonDeserializationContext p_deserialize_3_) throws JsonParseException {
            final JsonObject jsonobject = p_deserialize_1_.getAsJsonObject();
            final float[] afloat = this.zeroday(jsonobject);
            final int i = this.zerodayisaminecraftcheat(jsonobject);
            return new BlockFaceUV(afloat, i);
        }
        
        protected int zerodayisaminecraftcheat(final JsonObject p_178291_1_) {
            final int i = JsonUtils.zerodayisaminecraftcheat(p_178291_1_, "rotation", 0);
            if (i >= 0 && i % 90 == 0 && i / 90 <= 3) {
                return i;
            }
            throw new JsonParseException("Invalid rotation " + i + " found, only 0/90/180/270 allowed");
        }
        
        private float[] zeroday(final JsonObject p_178292_1_) {
            if (!p_178292_1_.has("uv")) {
                return null;
            }
            final JsonArray jsonarray = JsonUtils.c(p_178292_1_, "uv");
            if (jsonarray.size() != 4) {
                throw new JsonParseException("Expected 4 uv values, found: " + jsonarray.size());
            }
            final float[] afloat = new float[4];
            for (int i = 0; i < afloat.length; ++i) {
                afloat[i] = JsonUtils.sigma(jsonarray.get(i), "uv[" + i + "]");
            }
            return afloat;
        }
    }
}

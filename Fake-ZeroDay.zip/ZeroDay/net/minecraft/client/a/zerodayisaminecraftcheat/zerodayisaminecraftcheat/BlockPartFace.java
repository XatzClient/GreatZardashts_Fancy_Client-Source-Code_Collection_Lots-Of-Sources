// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import net.minecraft.o.JsonUtils;
import com.google.gson.JsonParseException;
import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonDeserializer;
import net.minecraft.o.EnumFacing;

public class BlockPartFace
{
    public static final EnumFacing zerodayisaminecraftcheat;
    public final EnumFacing zeroday;
    public final int sigma;
    public final String pandora;
    public final BlockFaceUV zues;
    
    static {
        zerodayisaminecraftcheat = null;
    }
    
    public BlockPartFace(final EnumFacing cullFaceIn, final int tintIndexIn, final String textureIn, final BlockFaceUV blockFaceUVIn) {
        this.zeroday = cullFaceIn;
        this.sigma = tintIndexIn;
        this.pandora = textureIn;
        this.zues = blockFaceUVIn;
    }
    
    static class zerodayisaminecraftcheat implements JsonDeserializer<BlockPartFace>
    {
        public BlockPartFace zerodayisaminecraftcheat(final JsonElement p_deserialize_1_, final Type p_deserialize_2_, final JsonDeserializationContext p_deserialize_3_) throws JsonParseException {
            final JsonObject jsonobject = p_deserialize_1_.getAsJsonObject();
            final EnumFacing enumfacing = this.sigma(jsonobject);
            final int i = this.zerodayisaminecraftcheat(jsonobject);
            final String s = this.zeroday(jsonobject);
            final BlockFaceUV blockfaceuv = (BlockFaceUV)p_deserialize_3_.deserialize((JsonElement)jsonobject, (Type)BlockFaceUV.class);
            return new BlockPartFace(enumfacing, i, s, blockfaceuv);
        }
        
        protected int zerodayisaminecraftcheat(final JsonObject p_178337_1_) {
            return JsonUtils.zerodayisaminecraftcheat(p_178337_1_, "tintindex", -1);
        }
        
        private String zeroday(final JsonObject p_178340_1_) {
            return JsonUtils.flux(p_178340_1_, "texture");
        }
        
        private EnumFacing sigma(final JsonObject p_178339_1_) {
            final String s = JsonUtils.zerodayisaminecraftcheat(p_178339_1_, "cullface", "");
            return EnumFacing.zerodayisaminecraftcheat(s);
        }
    }
}

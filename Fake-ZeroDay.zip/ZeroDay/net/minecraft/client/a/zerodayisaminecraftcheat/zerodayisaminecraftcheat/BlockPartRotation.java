// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import net.minecraft.o.EnumFacing;
import org.lwjgl.util.vector.Vector3f;

public class BlockPartRotation
{
    public final Vector3f zerodayisaminecraftcheat;
    public final EnumFacing.zerodayisaminecraftcheat zeroday;
    public final float sigma;
    public final boolean pandora;
    
    public BlockPartRotation(final Vector3f originIn, final EnumFacing.zerodayisaminecraftcheat axisIn, final float angleIn, final boolean rescaleIn) {
        this.zerodayisaminecraftcheat = originIn;
        this.zeroday = axisIn;
        this.sigma = angleIn;
        this.pandora = rescaleIn;
    }
}

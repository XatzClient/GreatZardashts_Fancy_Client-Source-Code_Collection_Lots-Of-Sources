// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import net.minecraft.o.EnumFacing;
import java.util.Arrays;
import net.minecraft.client.a.zues.TextureAtlasSprite;

public class BreakingFour extends BakedQuad
{
    private final TextureAtlasSprite pandora;
    private static final String zues = "CL_00002492";
    
    public BreakingFour(final BakedQuad p_i46217_1_, final TextureAtlasSprite textureIn) {
        super(Arrays.copyOf(p_i46217_1_.zeroday(), p_i46217_1_.zeroday().length), p_i46217_1_.zeroday, FaceBakery.zerodayisaminecraftcheat(p_i46217_1_.zeroday()));
        this.pandora = textureIn;
        this.vape();
    }
    
    private void vape() {
        for (int i = 0; i < 4; ++i) {
            this.zerodayisaminecraftcheat(i);
        }
    }
    
    private void zerodayisaminecraftcheat(final int p_178216_1_) {
        final int i = this.zerodayisaminecraftcheat.length / 4;
        final int j = i * p_178216_1_;
        final float f = Float.intBitsToFloat(this.zerodayisaminecraftcheat[j]);
        final float f2 = Float.intBitsToFloat(this.zerodayisaminecraftcheat[j + 1]);
        final float f3 = Float.intBitsToFloat(this.zerodayisaminecraftcheat[j + 2]);
        float f4 = 0.0f;
        float f5 = 0.0f;
        switch (zerodayisaminecraftcheat.zerodayisaminecraftcheat[this.sigma.ordinal()]) {
            case 1: {
                f4 = f * 16.0f;
                f5 = (1.0f - f3) * 16.0f;
                break;
            }
            case 2: {
                f4 = f * 16.0f;
                f5 = f3 * 16.0f;
                break;
            }
            case 3: {
                f4 = (1.0f - f) * 16.0f;
                f5 = (1.0f - f2) * 16.0f;
                break;
            }
            case 4: {
                f4 = f * 16.0f;
                f5 = (1.0f - f2) * 16.0f;
                break;
            }
            case 5: {
                f4 = f3 * 16.0f;
                f5 = (1.0f - f2) * 16.0f;
                break;
            }
            case 6: {
                f4 = (1.0f - f3) * 16.0f;
                f5 = (1.0f - f2) * 16.0f;
                break;
            }
        }
        this.zerodayisaminecraftcheat[j + 4] = Float.floatToRawIntBits(this.pandora.zerodayisaminecraftcheat((double)f4));
        this.zerodayisaminecraftcheat[j + 4 + 1] = Float.floatToRawIntBits(this.pandora.zeroday((double)f5));
    }
    
    static final class zerodayisaminecraftcheat
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00002491";
        
        static {
            zerodayisaminecraftcheat = new int[EnumFacing.values().length];
            try {
                BreakingFour.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                BreakingFour.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.zeroday.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                BreakingFour.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                BreakingFour.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.pandora.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            try {
                BreakingFour.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.zues.ordinal()] = 5;
            }
            catch (NoSuchFieldError noSuchFieldError5) {}
            try {
                BreakingFour.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.flux.ordinal()] = 6;
            }
            catch (NoSuchFieldError noSuchFieldError6) {}
        }
    }
}

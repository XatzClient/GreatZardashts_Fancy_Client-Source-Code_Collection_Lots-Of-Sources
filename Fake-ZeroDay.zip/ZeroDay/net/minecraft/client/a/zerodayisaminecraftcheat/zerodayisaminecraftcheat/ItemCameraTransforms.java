// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import com.google.gson.JsonParseException;
import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonDeserializer;
import net.minecraft.client.a.GlStateManager;

public class ItemCameraTransforms
{
    public static final ItemCameraTransforms zerodayisaminecraftcheat;
    public static float zeroday;
    public static float sigma;
    public static float pandora;
    public static float zues;
    public static float flux;
    public static float vape;
    public static float momgetthecamera;
    public static float a;
    public static float b;
    public final ItemTransformVec3f c;
    public final ItemTransformVec3f d;
    public final ItemTransformVec3f e;
    public final ItemTransformVec3f f;
    public final ItemTransformVec3f g;
    public final ItemTransformVec3f h;
    private static /* synthetic */ int[] i;
    
    static {
        zerodayisaminecraftcheat = new ItemCameraTransforms();
        ItemCameraTransforms.zeroday = 0.0f;
        ItemCameraTransforms.sigma = 0.0f;
        ItemCameraTransforms.pandora = 0.0f;
        ItemCameraTransforms.zues = 0.0f;
        ItemCameraTransforms.flux = 0.0f;
        ItemCameraTransforms.vape = 0.0f;
        ItemCameraTransforms.momgetthecamera = 0.0f;
        ItemCameraTransforms.a = 0.0f;
        ItemCameraTransforms.b = 0.0f;
    }
    
    private ItemCameraTransforms() {
        this(ItemTransformVec3f.zerodayisaminecraftcheat, ItemTransformVec3f.zerodayisaminecraftcheat, ItemTransformVec3f.zerodayisaminecraftcheat, ItemTransformVec3f.zerodayisaminecraftcheat, ItemTransformVec3f.zerodayisaminecraftcheat, ItemTransformVec3f.zerodayisaminecraftcheat);
    }
    
    public ItemCameraTransforms(final ItemCameraTransforms p_i46443_1_) {
        this.c = p_i46443_1_.c;
        this.d = p_i46443_1_.d;
        this.e = p_i46443_1_.e;
        this.f = p_i46443_1_.f;
        this.g = p_i46443_1_.g;
        this.h = p_i46443_1_.h;
    }
    
    public ItemCameraTransforms(final ItemTransformVec3f p_i46444_1_, final ItemTransformVec3f p_i46444_2_, final ItemTransformVec3f p_i46444_3_, final ItemTransformVec3f p_i46444_4_, final ItemTransformVec3f p_i46444_5_, final ItemTransformVec3f p_i46444_6_) {
        this.c = p_i46444_1_;
        this.d = p_i46444_2_;
        this.e = p_i46444_3_;
        this.f = p_i46444_4_;
        this.g = p_i46444_5_;
        this.h = p_i46444_6_;
    }
    
    public void zerodayisaminecraftcheat(final zeroday p_181689_1_) {
        final ItemTransformVec3f itemtransformvec3f = this.zeroday(p_181689_1_);
        if (itemtransformvec3f != ItemTransformVec3f.zerodayisaminecraftcheat) {
            GlStateManager.zeroday(itemtransformvec3f.sigma.x + ItemCameraTransforms.zeroday, itemtransformvec3f.sigma.y + ItemCameraTransforms.sigma, itemtransformvec3f.sigma.z + ItemCameraTransforms.pandora);
            GlStateManager.zeroday(itemtransformvec3f.zeroday.y + ItemCameraTransforms.flux, 0.0f, 1.0f, 0.0f);
            GlStateManager.zeroday(itemtransformvec3f.zeroday.x + ItemCameraTransforms.zues, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(itemtransformvec3f.zeroday.z + ItemCameraTransforms.vape, 0.0f, 0.0f, 1.0f);
            GlStateManager.zerodayisaminecraftcheat(itemtransformvec3f.pandora.x + ItemCameraTransforms.momgetthecamera, itemtransformvec3f.pandora.y + ItemCameraTransforms.a, itemtransformvec3f.pandora.z + ItemCameraTransforms.b);
        }
    }
    
    public ItemTransformVec3f zeroday(final zeroday p_181688_1_) {
        switch (zerodayisaminecraftcheat()[p_181688_1_.ordinal()]) {
            case 2: {
                return this.c;
            }
            case 3: {
                return this.d;
            }
            case 4: {
                return this.e;
            }
            case 5: {
                return this.f;
            }
            case 6: {
                return this.g;
            }
            case 7: {
                return this.h;
            }
            default: {
                return ItemTransformVec3f.zerodayisaminecraftcheat;
            }
        }
    }
    
    public boolean sigma(final zeroday p_181687_1_) {
        return !this.zeroday(p_181687_1_).equals(ItemTransformVec3f.zerodayisaminecraftcheat);
    }
    
    static /* synthetic */ int[] zerodayisaminecraftcheat() {
        final int[] i = ItemCameraTransforms.i;
        if (i != null) {
            return i;
        }
        final int[] j = new int[ItemCameraTransforms.zeroday.values().length];
        try {
            j[ItemCameraTransforms.zeroday.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            j[ItemCameraTransforms.zeroday.vape.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            j[ItemCameraTransforms.zeroday.flux.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            j[ItemCameraTransforms.zeroday.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            j[ItemCameraTransforms.zeroday.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            j[ItemCameraTransforms.zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            j[ItemCameraTransforms.zeroday.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        return ItemCameraTransforms.i = j;
    }
    
    static class zerodayisaminecraftcheat implements JsonDeserializer<ItemCameraTransforms>
    {
        public ItemCameraTransforms zerodayisaminecraftcheat(final JsonElement p_deserialize_1_, final Type p_deserialize_2_, final JsonDeserializationContext p_deserialize_3_) throws JsonParseException {
            final JsonObject jsonobject = p_deserialize_1_.getAsJsonObject();
            final ItemTransformVec3f itemtransformvec3f = this.zerodayisaminecraftcheat(p_deserialize_3_, jsonobject, "thirdperson");
            final ItemTransformVec3f itemtransformvec3f2 = this.zerodayisaminecraftcheat(p_deserialize_3_, jsonobject, "firstperson");
            final ItemTransformVec3f itemtransformvec3f3 = this.zerodayisaminecraftcheat(p_deserialize_3_, jsonobject, "head");
            final ItemTransformVec3f itemtransformvec3f4 = this.zerodayisaminecraftcheat(p_deserialize_3_, jsonobject, "gui");
            final ItemTransformVec3f itemtransformvec3f5 = this.zerodayisaminecraftcheat(p_deserialize_3_, jsonobject, "ground");
            final ItemTransformVec3f itemtransformvec3f6 = this.zerodayisaminecraftcheat(p_deserialize_3_, jsonobject, "fixed");
            return new ItemCameraTransforms(itemtransformvec3f, itemtransformvec3f2, itemtransformvec3f3, itemtransformvec3f4, itemtransformvec3f5, itemtransformvec3f6);
        }
        
        private ItemTransformVec3f zerodayisaminecraftcheat(final JsonDeserializationContext p_181683_1_, final JsonObject p_181683_2_, final String p_181683_3_) {
            return (ItemTransformVec3f)(p_181683_2_.has(p_181683_3_) ? p_181683_1_.deserialize(p_181683_2_.get(p_181683_3_), (Type)ItemTransformVec3f.class) : ItemTransformVec3f.zerodayisaminecraftcheat);
        }
    }
    
    public enum zeroday
    {
        zerodayisaminecraftcheat("NONE", 0), 
        zeroday("THIRD_PERSON", 1), 
        sigma("FIRST_PERSON", 2), 
        pandora("HEAD", 3), 
        zues("GUI", 4), 
        flux("GROUND", 5), 
        vape("FIXED", 6);
        
        static {
            momgetthecamera = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday, zeroday.sigma, zeroday.pandora, zeroday.zues, zeroday.flux, zeroday.vape };
        }
        
        private zeroday(final String s, final int n) {
        }
    }
}

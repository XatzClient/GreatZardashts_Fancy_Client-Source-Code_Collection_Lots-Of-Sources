// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import java.util.Iterator;
import org.lwjgl.util.vector.Vector3f;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import java.util.Map;
import java.util.Collection;
import net.minecraft.o.ResourceLocation;
import com.google.common.collect.Maps;
import net.minecraft.client.a.zues.TextureMap;
import com.google.common.collect.Lists;
import java.util.List;

public class ItemModelGenerator
{
    public static final List<String> zerodayisaminecraftcheat;
    private static /* synthetic */ int[] zeroday;
    
    static {
        zerodayisaminecraftcheat = Lists.newArrayList((Object[])new String[] { "layer0", "layer1", "layer2", "layer3", "layer4" });
    }
    
    public ModelBlock zerodayisaminecraftcheat(final TextureMap textureMapIn, final ModelBlock blockModel) {
        final Map<String, String> map = (Map<String, String>)Maps.newHashMap();
        final List<BlockPart> list = (List<BlockPart>)Lists.newArrayList();
        for (int i = 0; i < ItemModelGenerator.zerodayisaminecraftcheat.size(); ++i) {
            final String s = ItemModelGenerator.zerodayisaminecraftcheat.get(i);
            if (!blockModel.zeroday(s)) {
                break;
            }
            final String s2 = blockModel.sigma(s);
            map.put(s, s2);
            final TextureAtlasSprite textureatlassprite = textureMapIn.zerodayisaminecraftcheat(new ResourceLocation(s2).toString());
            list.addAll(this.zerodayisaminecraftcheat(i, s, textureatlassprite));
        }
        if (list.isEmpty()) {
            return null;
        }
        map.put("particle", blockModel.zeroday("particle") ? blockModel.sigma("particle") : map.get("layer0"));
        return new ModelBlock(list, map, false, false, blockModel.vape());
    }
    
    private List<BlockPart> zerodayisaminecraftcheat(final int p_178394_1_, final String p_178394_2_, final TextureAtlasSprite p_178394_3_) {
        final Map<EnumFacing, BlockPartFace> map = (Map<EnumFacing, BlockPartFace>)Maps.newHashMap();
        map.put(EnumFacing.pandora, new BlockPartFace(null, p_178394_1_, p_178394_2_, new BlockFaceUV(new float[] { 0.0f, 0.0f, 16.0f, 16.0f }, 0)));
        map.put(EnumFacing.sigma, new BlockPartFace(null, p_178394_1_, p_178394_2_, new BlockFaceUV(new float[] { 16.0f, 0.0f, 0.0f, 16.0f }, 0)));
        final List<BlockPart> list = (List<BlockPart>)Lists.newArrayList();
        list.add(new BlockPart(new Vector3f(0.0f, 0.0f, 7.5f), new Vector3f(16.0f, 16.0f, 8.5f), map, null, true));
        list.addAll(this.zerodayisaminecraftcheat(p_178394_3_, p_178394_2_, p_178394_1_));
        return list;
    }
    
    private List<BlockPart> zerodayisaminecraftcheat(final TextureAtlasSprite p_178397_1_, final String p_178397_2_, final int p_178397_3_) {
        final float f = (float)p_178397_1_.sigma();
        final float f2 = (float)p_178397_1_.pandora();
        final List<BlockPart> list = (List<BlockPart>)Lists.newArrayList();
        for (final zerodayisaminecraftcheat itemmodelgenerator$span : this.zerodayisaminecraftcheat(p_178397_1_)) {
            float f3 = 0.0f;
            float f4 = 0.0f;
            float f5 = 0.0f;
            float f6 = 0.0f;
            float f7 = 0.0f;
            float f8 = 0.0f;
            float f9 = 0.0f;
            float f10 = 0.0f;
            float f11 = 0.0f;
            float f12 = 0.0f;
            final float f13 = (float)itemmodelgenerator$span.zeroday();
            final float f14 = (float)itemmodelgenerator$span.sigma();
            final float f15 = (float)itemmodelgenerator$span.pandora();
            final zeroday itemmodelgenerator$spanfacing = itemmodelgenerator$span.zerodayisaminecraftcheat();
            switch (zerodayisaminecraftcheat()[itemmodelgenerator$spanfacing.ordinal()]) {
                case 1: {
                    f7 = f13;
                    f3 = f13;
                    f8 = (f5 = f14 + 1.0f);
                    f9 = f15;
                    f4 = f15;
                    f10 = f15;
                    f6 = f15;
                    f11 = 16.0f / f;
                    f12 = 16.0f / (f2 - 1.0f);
                    break;
                }
                case 2: {
                    f10 = f15;
                    f9 = f15;
                    f7 = f13;
                    f3 = f13;
                    f8 = (f5 = f14 + 1.0f);
                    f4 = f15 + 1.0f;
                    f6 = f15 + 1.0f;
                    f11 = 16.0f / f;
                    f12 = 16.0f / (f2 - 1.0f);
                    break;
                }
                case 3: {
                    f7 = f15;
                    f3 = f15;
                    f8 = f15;
                    f5 = f15;
                    f10 = f13;
                    f4 = f13;
                    f9 = (f6 = f14 + 1.0f);
                    f11 = 16.0f / (f - 1.0f);
                    f12 = 16.0f / f2;
                    break;
                }
                case 4: {
                    f8 = f15;
                    f7 = f15;
                    f3 = f15 + 1.0f;
                    f5 = f15 + 1.0f;
                    f10 = f13;
                    f4 = f13;
                    f9 = (f6 = f14 + 1.0f);
                    f11 = 16.0f / (f - 1.0f);
                    f12 = 16.0f / f2;
                    break;
                }
            }
            final float f16 = 16.0f / f;
            final float f17 = 16.0f / f2;
            f3 *= f16;
            f5 *= f16;
            f4 *= f17;
            f6 *= f17;
            f4 = 16.0f - f4;
            f6 = 16.0f - f6;
            f7 *= f11;
            f8 *= f11;
            f9 *= f12;
            f10 *= f12;
            final Map<EnumFacing, BlockPartFace> map = (Map<EnumFacing, BlockPartFace>)Maps.newHashMap();
            map.put(itemmodelgenerator$spanfacing.zerodayisaminecraftcheat(), new BlockPartFace(null, p_178397_3_, p_178397_2_, new BlockFaceUV(new float[] { f7, f9, f8, f10 }, 0)));
            switch (zerodayisaminecraftcheat()[itemmodelgenerator$spanfacing.ordinal()]) {
                default: {
                    continue;
                }
                case 1: {
                    list.add(new BlockPart(new Vector3f(f3, f4, 7.5f), new Vector3f(f5, f4, 8.5f), map, null, true));
                    continue;
                }
                case 2: {
                    list.add(new BlockPart(new Vector3f(f3, f6, 7.5f), new Vector3f(f5, f6, 8.5f), map, null, true));
                    continue;
                }
                case 3: {
                    list.add(new BlockPart(new Vector3f(f3, f4, 7.5f), new Vector3f(f3, f6, 8.5f), map, null, true));
                    continue;
                }
                case 4: {
                    list.add(new BlockPart(new Vector3f(f5, f4, 7.5f), new Vector3f(f5, f6, 8.5f), map, null, true));
                    continue;
                }
            }
        }
        return list;
    }
    
    private List<zerodayisaminecraftcheat> zerodayisaminecraftcheat(final TextureAtlasSprite p_178393_1_) {
        final int i = p_178393_1_.sigma();
        final int j = p_178393_1_.pandora();
        final List<zerodayisaminecraftcheat> list = (List<zerodayisaminecraftcheat>)Lists.newArrayList();
        for (int k = 0; k < p_178393_1_.c(); ++k) {
            final int[] aint = p_178393_1_.zerodayisaminecraftcheat(k)[0];
            for (int l = 0; l < j; ++l) {
                for (int i2 = 0; i2 < i; ++i2) {
                    final boolean flag = !this.zerodayisaminecraftcheat(aint, i2, l, i, j);
                    this.zerodayisaminecraftcheat(ItemModelGenerator.zeroday.zerodayisaminecraftcheat, list, aint, i2, l, i, j, flag);
                    this.zerodayisaminecraftcheat(ItemModelGenerator.zeroday.zeroday, list, aint, i2, l, i, j, flag);
                    this.zerodayisaminecraftcheat(ItemModelGenerator.zeroday.sigma, list, aint, i2, l, i, j, flag);
                    this.zerodayisaminecraftcheat(ItemModelGenerator.zeroday.pandora, list, aint, i2, l, i, j, flag);
                }
            }
        }
        return list;
    }
    
    private void zerodayisaminecraftcheat(final zeroday p_178396_1_, final List<zerodayisaminecraftcheat> p_178396_2_, final int[] p_178396_3_, final int p_178396_4_, final int p_178396_5_, final int p_178396_6_, final int p_178396_7_, final boolean p_178396_8_) {
        final boolean flag = this.zerodayisaminecraftcheat(p_178396_3_, p_178396_4_ + p_178396_1_.zeroday(), p_178396_5_ + p_178396_1_.sigma(), p_178396_6_, p_178396_7_) && p_178396_8_;
        if (flag) {
            this.zerodayisaminecraftcheat(p_178396_2_, p_178396_1_, p_178396_4_, p_178396_5_);
        }
    }
    
    private void zerodayisaminecraftcheat(final List<zerodayisaminecraftcheat> p_178395_1_, final zeroday p_178395_2_, final int p_178395_3_, final int p_178395_4_) {
        zerodayisaminecraftcheat itemmodelgenerator$span = null;
        for (final zerodayisaminecraftcheat itemmodelgenerator$span2 : p_178395_1_) {
            if (itemmodelgenerator$span2.zerodayisaminecraftcheat() == p_178395_2_) {
                final int i = p_178395_2_.pandora() ? p_178395_4_ : p_178395_3_;
                if (itemmodelgenerator$span2.pandora() == i) {
                    itemmodelgenerator$span = itemmodelgenerator$span2;
                    break;
                }
                continue;
            }
        }
        final int j = p_178395_2_.pandora() ? p_178395_4_ : p_178395_3_;
        final int k = p_178395_2_.pandora() ? p_178395_3_ : p_178395_4_;
        if (itemmodelgenerator$span == null) {
            p_178395_1_.add(new zerodayisaminecraftcheat(p_178395_2_, k, j));
        }
        else {
            itemmodelgenerator$span.zerodayisaminecraftcheat(k);
        }
    }
    
    private boolean zerodayisaminecraftcheat(final int[] p_178391_1_, final int p_178391_2_, final int p_178391_3_, final int p_178391_4_, final int p_178391_5_) {
        return p_178391_2_ < 0 || p_178391_3_ < 0 || p_178391_2_ >= p_178391_4_ || p_178391_3_ >= p_178391_5_ || (p_178391_1_[p_178391_3_ * p_178391_4_ + p_178391_2_] >> 24 & 0xFF) == 0x0;
    }
    
    static /* synthetic */ int[] zerodayisaminecraftcheat() {
        final int[] zeroday = ItemModelGenerator.zeroday;
        if (zeroday != null) {
            return zeroday;
        }
        final int[] zeroday2 = new int[ItemModelGenerator.zeroday.values().length];
        try {
            zeroday2[ItemModelGenerator.zeroday.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            zeroday2[ItemModelGenerator.zeroday.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            zeroday2[ItemModelGenerator.zeroday.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            zeroday2[ItemModelGenerator.zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        return ItemModelGenerator.zeroday = zeroday2;
    }
    
    enum zeroday
    {
        zerodayisaminecraftcheat("UP", 0, EnumFacing.zeroday, 0, -1), 
        zeroday("DOWN", 1, EnumFacing.zerodayisaminecraftcheat, 0, 1), 
        sigma("LEFT", 2, EnumFacing.flux, -1, 0), 
        pandora("RIGHT", 3, EnumFacing.zues, 1, 0);
        
        private final EnumFacing zues;
        private final int flux;
        private final int vape;
        
        static {
            momgetthecamera = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday, zeroday.sigma, zeroday.pandora };
        }
        
        private zeroday(final String s, final int n, final EnumFacing facing, final int p_i46215_4_, final int p_i46215_5_) {
            this.zues = facing;
            this.flux = p_i46215_4_;
            this.vape = p_i46215_5_;
        }
        
        public EnumFacing zerodayisaminecraftcheat() {
            return this.zues;
        }
        
        public int zeroday() {
            return this.flux;
        }
        
        public int sigma() {
            return this.vape;
        }
        
        private boolean pandora() {
            return this == zeroday.zeroday || this == zeroday.zerodayisaminecraftcheat;
        }
    }
    
    static class zerodayisaminecraftcheat
    {
        private final zeroday zerodayisaminecraftcheat;
        private int zeroday;
        private int sigma;
        private final int pandora;
        
        public zerodayisaminecraftcheat(final zeroday spanFacingIn, final int p_i46216_2_, final int p_i46216_3_) {
            this.zerodayisaminecraftcheat = spanFacingIn;
            this.zeroday = p_i46216_2_;
            this.sigma = p_i46216_2_;
            this.pandora = p_i46216_3_;
        }
        
        public void zerodayisaminecraftcheat(final int p_178382_1_) {
            if (p_178382_1_ < this.zeroday) {
                this.zeroday = p_178382_1_;
            }
            else if (p_178382_1_ > this.sigma) {
                this.sigma = p_178382_1_;
            }
        }
        
        public zeroday zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
        
        public int zeroday() {
            return this.zeroday;
        }
        
        public int sigma() {
            return this.sigma;
        }
        
        public int pandora() {
            return this.pandora;
        }
    }
}

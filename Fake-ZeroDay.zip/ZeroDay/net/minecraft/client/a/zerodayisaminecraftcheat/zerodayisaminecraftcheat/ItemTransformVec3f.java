// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import com.google.gson.JsonArray;
import net.minecraft.o.JsonUtils;
import com.google.gson.JsonParseException;
import com.google.gson.JsonObject;
import net.minecraft.o.MathHelper;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonDeserializer;
import org.lwjgl.util.vector.ReadableVector3f;
import org.lwjgl.util.vector.Vector3f;

public class ItemTransformVec3f
{
    public static final ItemTransformVec3f zerodayisaminecraftcheat;
    public final Vector3f zeroday;
    public final Vector3f sigma;
    public final Vector3f pandora;
    
    static {
        zerodayisaminecraftcheat = new ItemTransformVec3f(new Vector3f(), new Vector3f(), new Vector3f(1.0f, 1.0f, 1.0f));
    }
    
    public ItemTransformVec3f(final Vector3f rotation, final Vector3f translation, final Vector3f scale) {
        this.zeroday = new Vector3f((ReadableVector3f)rotation);
        this.sigma = new Vector3f((ReadableVector3f)translation);
        this.pandora = new Vector3f((ReadableVector3f)scale);
    }
    
    @Override
    public boolean equals(final Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        }
        if (this.getClass() != p_equals_1_.getClass()) {
            return false;
        }
        final ItemTransformVec3f itemtransformvec3f = (ItemTransformVec3f)p_equals_1_;
        return this.zeroday.equals((Object)itemtransformvec3f.zeroday) && this.pandora.equals((Object)itemtransformvec3f.pandora) && this.sigma.equals((Object)itemtransformvec3f.sigma);
    }
    
    @Override
    public int hashCode() {
        int i = this.zeroday.hashCode();
        i = 31 * i + this.sigma.hashCode();
        i = 31 * i + this.pandora.hashCode();
        return i;
    }
    
    static class zerodayisaminecraftcheat implements JsonDeserializer<ItemTransformVec3f>
    {
        private static final Vector3f zerodayisaminecraftcheat;
        private static final Vector3f zeroday;
        private static final Vector3f sigma;
        
        static {
            zerodayisaminecraftcheat = new Vector3f(0.0f, 0.0f, 0.0f);
            zeroday = new Vector3f(0.0f, 0.0f, 0.0f);
            sigma = new Vector3f(1.0f, 1.0f, 1.0f);
        }
        
        public ItemTransformVec3f zerodayisaminecraftcheat(final JsonElement p_deserialize_1_, final Type p_deserialize_2_, final JsonDeserializationContext p_deserialize_3_) throws JsonParseException {
            final JsonObject jsonobject = p_deserialize_1_.getAsJsonObject();
            final Vector3f vector3f = this.zerodayisaminecraftcheat(jsonobject, "rotation", ItemTransformVec3f.zerodayisaminecraftcheat.zerodayisaminecraftcheat);
            final Vector3f vector3f2 = this.zerodayisaminecraftcheat(jsonobject, "translation", ItemTransformVec3f.zerodayisaminecraftcheat.zeroday);
            vector3f2.scale(0.0625f);
            vector3f2.x = MathHelper.zerodayisaminecraftcheat(vector3f2.x, -1.5f, 1.5f);
            vector3f2.y = MathHelper.zerodayisaminecraftcheat(vector3f2.y, -1.5f, 1.5f);
            vector3f2.z = MathHelper.zerodayisaminecraftcheat(vector3f2.z, -1.5f, 1.5f);
            final Vector3f vector3f3 = this.zerodayisaminecraftcheat(jsonobject, "scale", ItemTransformVec3f.zerodayisaminecraftcheat.sigma);
            vector3f3.x = MathHelper.zerodayisaminecraftcheat(vector3f3.x, -4.0f, 4.0f);
            vector3f3.y = MathHelper.zerodayisaminecraftcheat(vector3f3.y, -4.0f, 4.0f);
            vector3f3.z = MathHelper.zerodayisaminecraftcheat(vector3f3.z, -4.0f, 4.0f);
            return new ItemTransformVec3f(vector3f, vector3f2, vector3f3);
        }
        
        private Vector3f zerodayisaminecraftcheat(final JsonObject jsonObject, final String key, final Vector3f defaultValue) {
            if (!jsonObject.has(key)) {
                return defaultValue;
            }
            final JsonArray jsonarray = JsonUtils.c(jsonObject, key);
            if (jsonarray.size() != 3) {
                throw new JsonParseException("Expected 3 " + key + " values, found: " + jsonarray.size());
            }
            final float[] afloat = new float[3];
            for (int i = 0; i < afloat.length; ++i) {
                afloat[i] = JsonUtils.sigma(jsonarray.get(i), String.valueOf(key) + "[" + i + "]");
            }
            return new Vector3f(afloat[0], afloat[1], afloat[2]);
        }
    }
}

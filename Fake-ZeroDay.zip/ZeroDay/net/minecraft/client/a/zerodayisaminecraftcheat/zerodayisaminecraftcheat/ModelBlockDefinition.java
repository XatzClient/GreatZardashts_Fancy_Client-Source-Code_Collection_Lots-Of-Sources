// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat;

import net.minecraft.client.b.zeroday.ModelRotation;
import net.minecraft.o.ResourceLocation;
import com.google.common.collect.Lists;
import net.minecraft.o.JsonUtils;
import com.google.gson.JsonParseException;
import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonDeserializer;
import java.util.List;
import java.util.Iterator;
import com.google.common.collect.Maps;
import java.util.Collection;
import java.io.Reader;
import java.lang.reflect.Type;
import com.google.gson.GsonBuilder;
import java.util.Map;
import com.google.gson.Gson;

public class ModelBlockDefinition
{
    static final Gson zerodayisaminecraftcheat;
    private final Map<String, pandora> zeroday;
    
    static {
        zerodayisaminecraftcheat = new GsonBuilder().registerTypeAdapter((Type)ModelBlockDefinition.class, (Object)new zerodayisaminecraftcheat()).registerTypeAdapter((Type)sigma.class, (Object)new sigma.zerodayisaminecraftcheat()).create();
    }
    
    public static ModelBlockDefinition zerodayisaminecraftcheat(final Reader p_178331_0_) {
        return (ModelBlockDefinition)ModelBlockDefinition.zerodayisaminecraftcheat.fromJson(p_178331_0_, (Class)ModelBlockDefinition.class);
    }
    
    public ModelBlockDefinition(final Collection<pandora> p_i46221_1_) {
        this.zeroday = (Map<String, pandora>)Maps.newHashMap();
        for (final pandora modelblockdefinition$variants : p_i46221_1_) {
            this.zeroday.put(modelblockdefinition$variants.zerodayisaminecraftcheat, modelblockdefinition$variants);
        }
    }
    
    public ModelBlockDefinition(final List<ModelBlockDefinition> p_i46222_1_) {
        this.zeroday = (Map<String, pandora>)Maps.newHashMap();
        for (final ModelBlockDefinition modelblockdefinition : p_i46222_1_) {
            this.zeroday.putAll(modelblockdefinition.zeroday);
        }
    }
    
    public pandora zerodayisaminecraftcheat(final String p_178330_1_) {
        final pandora modelblockdefinition$variants = this.zeroday.get(p_178330_1_);
        if (modelblockdefinition$variants == null) {
            throw new zeroday();
        }
        return modelblockdefinition$variants;
    }
    
    @Override
    public boolean equals(final Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        }
        if (p_equals_1_ instanceof ModelBlockDefinition) {
            final ModelBlockDefinition modelblockdefinition = (ModelBlockDefinition)p_equals_1_;
            return this.zeroday.equals(modelblockdefinition.zeroday);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.zeroday.hashCode();
    }
    
    public static class zerodayisaminecraftcheat implements JsonDeserializer<ModelBlockDefinition>
    {
        public ModelBlockDefinition zerodayisaminecraftcheat(final JsonElement p_deserialize_1_, final Type p_deserialize_2_, final JsonDeserializationContext p_deserialize_3_) throws JsonParseException {
            final JsonObject jsonobject = p_deserialize_1_.getAsJsonObject();
            final List<pandora> list = this.zerodayisaminecraftcheat(p_deserialize_3_, jsonobject);
            return new ModelBlockDefinition(list);
        }
        
        protected List<pandora> zerodayisaminecraftcheat(final JsonDeserializationContext p_178334_1_, final JsonObject p_178334_2_) {
            final JsonObject jsonobject = JsonUtils.b(p_178334_2_, "variants");
            final List<pandora> list = (List<pandora>)Lists.newArrayList();
            for (final Map.Entry<String, JsonElement> entry : jsonobject.entrySet()) {
                list.add(this.zerodayisaminecraftcheat(p_178334_1_, entry));
            }
            return list;
        }
        
        protected pandora zerodayisaminecraftcheat(final JsonDeserializationContext p_178335_1_, final Map.Entry<String, JsonElement> p_178335_2_) {
            final String s = p_178335_2_.getKey();
            final List<sigma> list = (List<sigma>)Lists.newArrayList();
            final JsonElement jsonelement = p_178335_2_.getValue();
            if (jsonelement.isJsonArray()) {
                for (final JsonElement jsonelement2 : jsonelement.getAsJsonArray()) {
                    list.add((sigma)p_178335_1_.deserialize(jsonelement2, (Type)sigma.class));
                }
            }
            else {
                list.add((sigma)p_178335_1_.deserialize(jsonelement, (Type)sigma.class));
            }
            return new pandora(s, list);
        }
    }
    
    public class zeroday extends RuntimeException
    {
    }
    
    public static class sigma
    {
        private final ResourceLocation zerodayisaminecraftcheat;
        private final ModelRotation zeroday;
        private final boolean sigma;
        private final int pandora;
        
        public sigma(final ResourceLocation modelLocationIn, final ModelRotation modelRotationIn, final boolean uvLockIn, final int weightIn) {
            this.zerodayisaminecraftcheat = modelLocationIn;
            this.zeroday = modelRotationIn;
            this.sigma = uvLockIn;
            this.pandora = weightIn;
        }
        
        public ResourceLocation zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
        
        public ModelRotation zeroday() {
            return this.zeroday;
        }
        
        public boolean sigma() {
            return this.sigma;
        }
        
        public int pandora() {
            return this.pandora;
        }
        
        @Override
        public boolean equals(final Object p_equals_1_) {
            if (this == p_equals_1_) {
                return true;
            }
            if (!(p_equals_1_ instanceof sigma)) {
                return false;
            }
            final sigma modelblockdefinition$variant = (sigma)p_equals_1_;
            return this.zerodayisaminecraftcheat.equals(modelblockdefinition$variant.zerodayisaminecraftcheat) && this.zeroday == modelblockdefinition$variant.zeroday && this.sigma == modelblockdefinition$variant.sigma;
        }
        
        @Override
        public int hashCode() {
            int i = this.zerodayisaminecraftcheat.hashCode();
            i = 31 * i + ((this.zeroday != null) ? this.zeroday.hashCode() : 0);
            i = 31 * i + (this.sigma ? 1 : 0);
            return i;
        }
        
        public static class zerodayisaminecraftcheat implements JsonDeserializer<sigma>
        {
            public sigma zerodayisaminecraftcheat(final JsonElement p_deserialize_1_, final Type p_deserialize_2_, final JsonDeserializationContext p_deserialize_3_) throws JsonParseException {
                final JsonObject jsonobject = p_deserialize_1_.getAsJsonObject();
                final String s = this.zeroday(jsonobject);
                final ModelRotation modelrotation = this.zerodayisaminecraftcheat(jsonobject);
                final boolean flag = this.pandora(jsonobject);
                final int i = this.sigma(jsonobject);
                return new sigma(this.zerodayisaminecraftcheat(s), modelrotation, flag, i);
            }
            
            private ResourceLocation zerodayisaminecraftcheat(final String p_178426_1_) {
                ResourceLocation resourcelocation = new ResourceLocation(p_178426_1_);
                resourcelocation = new ResourceLocation(resourcelocation.sigma(), "block/" + resourcelocation.zeroday());
                return resourcelocation;
            }
            
            private boolean pandora(final JsonObject p_178429_1_) {
                return JsonUtils.zerodayisaminecraftcheat(p_178429_1_, "uvlock", false);
            }
            
            protected ModelRotation zerodayisaminecraftcheat(final JsonObject p_178428_1_) {
                final int i = JsonUtils.zerodayisaminecraftcheat(p_178428_1_, "x", 0);
                final int j = JsonUtils.zerodayisaminecraftcheat(p_178428_1_, "y", 0);
                final ModelRotation modelrotation = ModelRotation.zerodayisaminecraftcheat(i, j);
                if (modelrotation == null) {
                    throw new JsonParseException("Invalid BlockModelRotation x: " + i + ", y: " + j);
                }
                return modelrotation;
            }
            
            protected String zeroday(final JsonObject p_178424_1_) {
                return JsonUtils.flux(p_178424_1_, "model");
            }
            
            protected int sigma(final JsonObject p_178427_1_) {
                return JsonUtils.zerodayisaminecraftcheat(p_178427_1_, "weight", 1);
            }
        }
    }
    
    public static class pandora
    {
        private final String zerodayisaminecraftcheat;
        private final List<sigma> zeroday;
        
        public pandora(final String nameIn, final List<sigma> listVariantsIn) {
            this.zerodayisaminecraftcheat = nameIn;
            this.zeroday = listVariantsIn;
        }
        
        public List<sigma> zerodayisaminecraftcheat() {
            return this.zeroday;
        }
        
        @Override
        public boolean equals(final Object p_equals_1_) {
            if (this == p_equals_1_) {
                return true;
            }
            if (!(p_equals_1_ instanceof pandora)) {
                return false;
            }
            final pandora modelblockdefinition$variants = (pandora)p_equals_1_;
            return this.zerodayisaminecraftcheat.equals(modelblockdefinition$variants.zerodayisaminecraftcheat) && this.zeroday.equals(modelblockdefinition$variants.zeroday);
        }
        
        @Override
        public int hashCode() {
            int i = this.zerodayisaminecraftcheat.hashCode();
            i = 31 * i + this.zeroday.hashCode();
            return i;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import sigma.zerodayisaminecraftcheat.l;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.GlStateManager;
import sigma.zerodayisaminecraftcheat.vape;

public abstract class AbstractTexture implements ITextureObject
{
    protected int sigma;
    protected boolean pandora;
    protected boolean zues;
    protected boolean flux;
    protected boolean vape;
    private static final String zerodayisaminecraftcheat = "CL_00001047";
    public vape momgetthecamera;
    
    public AbstractTexture() {
        this.sigma = -1;
    }
    
    public void zerodayisaminecraftcheat(final boolean p_174937_1_, final boolean p_174937_2_) {
        this.pandora = p_174937_1_;
        this.zues = p_174937_2_;
        final boolean flag = true;
        final boolean flag2 = true;
        int i;
        short short1;
        if (p_174937_1_) {
            i = (p_174937_2_ ? 9987 : 9729);
            short1 = 9729;
        }
        else {
            i = (p_174937_2_ ? 9986 : 9728);
            short1 = 9728;
        }
        GlStateManager.a(this.zerodayisaminecraftcheat());
        GL11.glTexParameteri(3553, 10241, i);
        GL11.glTexParameteri(3553, 10240, (int)short1);
    }
    
    @Override
    public void zeroday(final boolean p_174936_1_, final boolean p_174936_2_) {
        this.flux = this.pandora;
        this.vape = this.zues;
        this.zerodayisaminecraftcheat(p_174936_1_, p_174936_2_);
    }
    
    @Override
    public void pandora() {
        this.zerodayisaminecraftcheat(this.flux, this.vape);
    }
    
    @Override
    public int zerodayisaminecraftcheat() {
        if (this.sigma == -1) {
            this.sigma = TextureUtil.zerodayisaminecraftcheat();
        }
        return this.sigma;
    }
    
    public void zues() {
        l.zerodayisaminecraftcheat(this, this.sigma);
        if (this.sigma != -1) {
            TextureUtil.zerodayisaminecraftcheat(this.sigma);
            this.sigma = -1;
        }
    }
    
    @Override
    public vape flux() {
        return l.zerodayisaminecraftcheat(this);
    }
}

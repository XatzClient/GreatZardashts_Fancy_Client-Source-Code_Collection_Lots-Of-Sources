// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import java.io.IOException;
import net.minecraft.client.b.IResourceManager;
import sigma.zerodayisaminecraftcheat.l;
import net.minecraft.l.Config;
import java.awt.image.BufferedImage;

public class DynamicTexture extends AbstractTexture
{
    private final int[] zerodayisaminecraftcheat;
    private final int zeroday;
    private final int a;
    private static final String b = "CL_00001048";
    private boolean c;
    
    public DynamicTexture(final BufferedImage bufferedImage) {
        this(bufferedImage.getWidth(), bufferedImage.getHeight());
        bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), this.zerodayisaminecraftcheat, 0, bufferedImage.getWidth());
        this.zeroday();
    }
    
    public DynamicTexture(final int textureWidth, final int textureHeight) {
        this.c = false;
        this.zeroday = textureWidth;
        this.a = textureHeight;
        this.zerodayisaminecraftcheat = new int[textureWidth * textureHeight * 3];
        if (Config.aC()) {
            l.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), textureWidth, textureHeight, this);
            this.c = true;
        }
        else {
            TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), textureWidth, textureHeight);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) throws IOException {
    }
    
    public void zeroday() {
        if (Config.aC()) {
            if (!this.c) {
                l.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), this.zeroday, this.a, this);
                this.c = true;
            }
            l.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), this.zerodayisaminecraftcheat, this.zeroday, this.a, this);
        }
        else {
            TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), this.zerodayisaminecraftcheat, this.zeroday, this.a);
        }
    }
    
    public int[] sigma() {
        return this.zerodayisaminecraftcheat;
    }
}

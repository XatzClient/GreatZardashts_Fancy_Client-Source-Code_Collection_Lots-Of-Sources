// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import sigma.zerodayisaminecraftcheat.vape;
import java.io.IOException;
import net.minecraft.client.b.IResourceManager;

public interface ITextureObject
{
    void zeroday(final boolean p0, final boolean p1);
    
    void pandora();
    
    void zerodayisaminecraftcheat(final IResourceManager p0) throws IOException;
    
    int zerodayisaminecraftcheat();
    
    vape flux();
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import java.io.InputStream;
import java.util.Iterator;
import java.io.IOException;
import java.awt.image.ImageObserver;
import java.awt.Image;
import java.awt.image.BufferedImage;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.b.IResourceManager;
import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import java.util.List;
import org.apache.logging.log4j.Logger;

public class LayeredTexture extends AbstractTexture
{
    private static final Logger zeroday;
    public final List<String> zerodayisaminecraftcheat;
    
    static {
        zeroday = LogManager.getLogger();
    }
    
    public LayeredTexture(final String... textureNames) {
        this.zerodayisaminecraftcheat = (List<String>)Lists.newArrayList((Object[])textureNames);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) throws IOException {
        this.zues();
        BufferedImage bufferedimage = null;
        try {
            for (final String s : this.zerodayisaminecraftcheat) {
                if (s != null) {
                    final InputStream inputstream = resourceManager.zerodayisaminecraftcheat(new ResourceLocation(s)).zeroday();
                    final BufferedImage bufferedimage2 = TextureUtil.zerodayisaminecraftcheat(inputstream);
                    if (bufferedimage == null) {
                        bufferedimage = new BufferedImage(bufferedimage2.getWidth(), bufferedimage2.getHeight(), 2);
                    }
                    bufferedimage.getGraphics().drawImage(bufferedimage2, 0, 0, null);
                }
            }
        }
        catch (IOException ioexception) {
            LayeredTexture.zeroday.error("Couldn't load layered image", (Throwable)ioexception);
            return;
        }
        TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), bufferedimage);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import java.io.IOException;
import java.awt.image.BufferedImage;
import net.minecraft.client.b.IResource;
import java.io.InputStream;
import sigma.zerodayisaminecraftcheat.l;
import net.minecraft.l.Config;
import net.minecraft.client.b.zerodayisaminecraftcheat.TextureMetadataSection;
import net.minecraft.client.b.IResourceManager;
import org.apache.logging.log4j.LogManager;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;

public class SimpleTexture extends AbstractTexture
{
    private static final Logger zerodayisaminecraftcheat;
    protected final ResourceLocation a;
    private static final String zeroday = "CL_00001052";
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public SimpleTexture(final ResourceLocation textureResourceLocation) {
        this.a = textureResourceLocation;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) throws IOException {
        this.zues();
        InputStream inputstream = null;
        try {
            final IResource iresource = resourceManager.zerodayisaminecraftcheat(this.a);
            inputstream = iresource.zeroday();
            final BufferedImage bufferedimage = TextureUtil.zerodayisaminecraftcheat(inputstream);
            boolean flag = false;
            boolean flag2 = false;
            if (iresource.sigma()) {
                try {
                    final TextureMetadataSection texturemetadatasection = iresource.zerodayisaminecraftcheat("texture");
                    if (texturemetadatasection != null) {
                        flag = texturemetadatasection.zerodayisaminecraftcheat();
                        flag2 = texturemetadatasection.zeroday();
                    }
                }
                catch (RuntimeException runtimeexception) {
                    SimpleTexture.zerodayisaminecraftcheat.warn("Failed reading metadata of: " + this.a, (Throwable)runtimeexception);
                }
            }
            if (Config.aC()) {
                l.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), bufferedimage, flag, flag2, resourceManager, this.a, this.flux());
            }
            else {
                TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), bufferedimage, flag, flag2);
            }
        }
        finally {
            if (inputstream != null) {
                inputstream.close();
            }
        }
        if (inputstream != null) {
            inputstream.close();
        }
    }
}

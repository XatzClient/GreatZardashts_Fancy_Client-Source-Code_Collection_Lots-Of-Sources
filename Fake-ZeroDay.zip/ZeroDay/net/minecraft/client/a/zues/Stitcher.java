// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import java.util.Iterator;
import java.util.ArrayList;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.StitcherException;
import java.util.Arrays;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.List;
import java.util.Set;

public class Stitcher
{
    private final int zerodayisaminecraftcheat;
    private final Set zeroday;
    private final List sigma;
    private int pandora;
    private int zues;
    private final int flux;
    private final int vape;
    private final boolean momgetthecamera;
    private final int a;
    private static final String b = "CL_00001054";
    
    public Stitcher(final int maxTextureWidth, final int maxTextureHeight, final boolean p_i45095_3_, final int p_i45095_4_, final int mipmapLevel) {
        this.zeroday = Sets.newHashSetWithExpectedSize(256);
        this.sigma = Lists.newArrayListWithCapacity(256);
        this.zerodayisaminecraftcheat = mipmapLevel;
        this.flux = maxTextureWidth;
        this.vape = maxTextureHeight;
        this.momgetthecamera = p_i45095_3_;
        this.a = p_i45095_4_;
    }
    
    public int zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    public int zeroday() {
        return this.zues;
    }
    
    public void zerodayisaminecraftcheat(final TextureAtlasSprite p_110934_1_) {
        final zerodayisaminecraftcheat stitcher$holder = new zerodayisaminecraftcheat(p_110934_1_, this.zerodayisaminecraftcheat);
        if (this.a > 0) {
            stitcher$holder.zerodayisaminecraftcheat(this.a);
        }
        this.zeroday.add(stitcher$holder);
    }
    
    public void sigma() {
        final zerodayisaminecraftcheat[] astitcher$holder = this.zeroday.toArray(new zerodayisaminecraftcheat[this.zeroday.size()]);
        Arrays.sort(astitcher$holder);
        zerodayisaminecraftcheat[] array;
        for (int length = (array = astitcher$holder).length, i = 0; i < length; ++i) {
            final zerodayisaminecraftcheat stitcher$holder = array[i];
            if (!this.zerodayisaminecraftcheat(stitcher$holder)) {
                final String s = String.format("Unable to fit: %s, size: %dx%d, atlas: %dx%d, atlasMax: %dx%d - Maybe try a lower resolution resourcepack?", stitcher$holder.zerodayisaminecraftcheat().a(), stitcher$holder.zerodayisaminecraftcheat().sigma(), stitcher$holder.zerodayisaminecraftcheat().pandora(), this.pandora, this.zues, this.flux, this.vape);
                throw new StitcherException(stitcher$holder, s);
            }
        }
        if (this.momgetthecamera) {
            this.pandora = MathHelper.zeroday(this.pandora);
            this.zues = MathHelper.zeroday(this.zues);
        }
    }
    
    public List pandora() {
        final ArrayList arraylist = Lists.newArrayList();
        for (final Object stitcher$slot : this.sigma) {
            ((zeroday)stitcher$slot).zerodayisaminecraftcheat(arraylist);
        }
        final ArrayList arraylist2 = Lists.newArrayList();
        for (final Object stitcher$slot2 : arraylist) {
            final zerodayisaminecraftcheat stitcher$holder = ((zeroday)stitcher$slot2).zerodayisaminecraftcheat();
            final TextureAtlasSprite textureatlassprite = stitcher$holder.zerodayisaminecraftcheat();
            textureatlassprite.zerodayisaminecraftcheat(this.pandora, this.zues, ((zeroday)stitcher$slot2).zeroday(), ((zeroday)stitcher$slot2).sigma(), stitcher$holder.zues());
            arraylist2.add(textureatlassprite);
        }
        return arraylist2;
    }
    
    private static int zeroday(final int p_147969_0_, final int p_147969_1_) {
        return (p_147969_0_ >> p_147969_1_) + (((p_147969_0_ & (1 << p_147969_1_) - 1) != 0x0) ? 1 : 0) << p_147969_1_;
    }
    
    private boolean zerodayisaminecraftcheat(final zerodayisaminecraftcheat p_94310_1_) {
        for (int i = 0; i < this.sigma.size(); ++i) {
            if (this.sigma.get(i).zerodayisaminecraftcheat(p_94310_1_)) {
                return true;
            }
            p_94310_1_.pandora();
            if (this.sigma.get(i).zerodayisaminecraftcheat(p_94310_1_)) {
                return true;
            }
            p_94310_1_.pandora();
        }
        return this.zeroday(p_94310_1_);
    }
    
    private boolean zeroday(final zerodayisaminecraftcheat p_94311_1_) {
        final int i = Math.min(p_94311_1_.zeroday(), p_94311_1_.sigma());
        final boolean flag = this.pandora == 0 && this.zues == 0;
        boolean flag6;
        if (this.momgetthecamera) {
            final int j = MathHelper.zeroday(this.pandora);
            final int k = MathHelper.zeroday(this.zues);
            final int l = MathHelper.zeroday(this.pandora + i);
            final int i2 = MathHelper.zeroday(this.zues + i);
            final boolean flag2 = l <= this.flux;
            final boolean flag3 = i2 <= this.vape;
            if (!flag2 && !flag3) {
                return false;
            }
            final boolean flag4 = j != l;
            final boolean flag5 = k != i2;
            if (flag4 ^ flag5) {
                flag6 = !flag4;
            }
            else {
                flag6 = (flag2 && j <= k);
            }
        }
        else {
            final boolean flag7 = this.pandora + i <= this.flux;
            final boolean flag8 = this.zues + i <= this.vape;
            if (!flag7 && !flag8) {
                return false;
            }
            flag6 = (flag7 && (flag || this.pandora <= this.zues));
        }
        final int j2 = Math.max(p_94311_1_.zeroday(), p_94311_1_.sigma());
        if (MathHelper.zeroday((flag6 ? this.pandora : this.zues) + j2) > (flag6 ? this.flux : this.vape)) {
            return false;
        }
        zeroday stitcher$slot;
        if (flag6) {
            if (p_94311_1_.zeroday() > p_94311_1_.sigma()) {
                p_94311_1_.pandora();
            }
            if (this.zues == 0) {
                this.zues = p_94311_1_.sigma();
            }
            stitcher$slot = new zeroday(this.pandora, 0, p_94311_1_.zeroday(), this.zues);
            this.pandora += p_94311_1_.zeroday();
        }
        else {
            stitcher$slot = new zeroday(0, this.zues, this.pandora, p_94311_1_.sigma());
            this.zues += p_94311_1_.sigma();
        }
        stitcher$slot.zerodayisaminecraftcheat(p_94311_1_);
        this.sigma.add(stitcher$slot);
        return true;
    }
    
    public static class zerodayisaminecraftcheat implements Comparable
    {
        private final TextureAtlasSprite zerodayisaminecraftcheat;
        private final int zeroday;
        private final int sigma;
        private final int pandora;
        private boolean zues;
        private float flux;
        private static final String vape = "CL_00001055";
        
        public zerodayisaminecraftcheat(final TextureAtlasSprite p_i45094_1_, final int p_i45094_2_) {
            this.flux = 1.0f;
            this.zerodayisaminecraftcheat = p_i45094_1_;
            this.zeroday = p_i45094_1_.sigma();
            this.sigma = p_i45094_1_.pandora();
            this.pandora = p_i45094_2_;
            this.zues = (zeroday(this.sigma, p_i45094_2_) > zeroday(this.zeroday, p_i45094_2_));
        }
        
        public TextureAtlasSprite zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
        
        public int zeroday() {
            return this.zues ? zeroday((int)(this.sigma * this.flux), this.pandora) : zeroday((int)(this.zeroday * this.flux), this.pandora);
        }
        
        public int sigma() {
            return this.zues ? zeroday((int)(this.zeroday * this.flux), this.pandora) : zeroday((int)(this.sigma * this.flux), this.pandora);
        }
        
        public void pandora() {
            this.zues = !this.zues;
        }
        
        public boolean zues() {
            return this.zues;
        }
        
        public void zerodayisaminecraftcheat(final int p_94196_1_) {
            if (this.zeroday > p_94196_1_ && this.sigma > p_94196_1_) {
                this.flux = p_94196_1_ / (float)Math.min(this.zeroday, this.sigma);
            }
        }
        
        @Override
        public String toString() {
            return "Holder{width=" + this.zeroday + ", height=" + this.sigma + ", name=" + this.zerodayisaminecraftcheat.a() + '}';
        }
        
        public int zerodayisaminecraftcheat(final zerodayisaminecraftcheat p_compareTo_1_) {
            int i;
            if (this.sigma() == p_compareTo_1_.sigma()) {
                if (this.zeroday() == p_compareTo_1_.zeroday()) {
                    if (this.zerodayisaminecraftcheat.a() == null) {
                        return (p_compareTo_1_.zerodayisaminecraftcheat.a() == null) ? 0 : -1;
                    }
                    return this.zerodayisaminecraftcheat.a().compareTo(p_compareTo_1_.zerodayisaminecraftcheat.a());
                }
                else {
                    i = ((this.zeroday() < p_compareTo_1_.zeroday()) ? 1 : -1);
                }
            }
            else {
                i = ((this.sigma() < p_compareTo_1_.sigma()) ? 1 : -1);
            }
            return i;
        }
        
        @Override
        public int compareTo(final Object p_compareTo_1_) {
            return this.zerodayisaminecraftcheat((zerodayisaminecraftcheat)p_compareTo_1_);
        }
    }
    
    public static class zeroday
    {
        private final int zerodayisaminecraftcheat;
        private final int zeroday;
        private final int sigma;
        private final int pandora;
        private List zues;
        private zerodayisaminecraftcheat flux;
        private static final String vape = "CL_00001056";
        
        public zeroday(final int p_i1277_1_, final int p_i1277_2_, final int widthIn, final int heightIn) {
            this.zerodayisaminecraftcheat = p_i1277_1_;
            this.zeroday = p_i1277_2_;
            this.sigma = widthIn;
            this.pandora = heightIn;
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat() {
            return this.flux;
        }
        
        public int zeroday() {
            return this.zerodayisaminecraftcheat;
        }
        
        public int sigma() {
            return this.zeroday;
        }
        
        public boolean zerodayisaminecraftcheat(final zerodayisaminecraftcheat holderIn) {
            if (this.flux != null) {
                return false;
            }
            final int i = holderIn.zeroday();
            final int j = holderIn.sigma();
            if (i > this.sigma || j > this.pandora) {
                return false;
            }
            if (i == this.sigma && j == this.pandora) {
                this.flux = holderIn;
                return true;
            }
            if (this.zues == null) {
                (this.zues = Lists.newArrayListWithCapacity(1)).add(new zeroday(this.zerodayisaminecraftcheat, this.zeroday, i, j));
                final int k = this.sigma - i;
                final int l = this.pandora - j;
                if (l > 0 && k > 0) {
                    final int i2 = Math.max(this.pandora, k);
                    final int j2 = Math.max(this.sigma, l);
                    if (i2 >= j2) {
                        this.zues.add(new zeroday(this.zerodayisaminecraftcheat, this.zeroday + j, i, l));
                        this.zues.add(new zeroday(this.zerodayisaminecraftcheat + i, this.zeroday, k, this.pandora));
                    }
                    else {
                        this.zues.add(new zeroday(this.zerodayisaminecraftcheat + i, this.zeroday, k, j));
                        this.zues.add(new zeroday(this.zerodayisaminecraftcheat, this.zeroday + j, this.sigma, l));
                    }
                }
                else if (k == 0) {
                    this.zues.add(new zeroday(this.zerodayisaminecraftcheat, this.zeroday + j, i, l));
                }
                else if (l == 0) {
                    this.zues.add(new zeroday(this.zerodayisaminecraftcheat + i, this.zeroday, k, j));
                }
            }
            for (final Object stitcher$slot : this.zues) {
                if (((zeroday)stitcher$slot).zerodayisaminecraftcheat(holderIn)) {
                    return true;
                }
            }
            return false;
        }
        
        public void zerodayisaminecraftcheat(final List p_94184_1_) {
            if (this.flux != null) {
                p_94184_1_.add(this);
            }
            else if (this.zues != null) {
                for (final Object stitcher$slot : this.zues) {
                    ((zeroday)stitcher$slot).zerodayisaminecraftcheat(p_94184_1_);
                }
            }
        }
        
        @Override
        public String toString() {
            return "Slot{originX=" + this.zerodayisaminecraftcheat + ", originY=" + this.zeroday + ", width=" + this.sigma + ", height=" + this.pandora + ", texture=" + this.flux + ", subSlots=" + this.zues + '}';
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import net.minecraft.l.TextureUtils;
import net.minecraft.client.b.IResourceManager;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.o.ReportedException;
import java.util.concurrent.Callable;
import net.minecraft.sigma.CrashReport;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.b.zerodayisaminecraftcheat.AnimationFrame;
import java.awt.image.BufferedImage;
import sigma.zerodayisaminecraftcheat.l;
import net.minecraft.o.ResourceLocation;
import net.minecraft.l.Config;
import com.google.common.collect.Lists;
import net.minecraft.client.b.zerodayisaminecraftcheat.AnimationMetadataSection;
import java.util.List;

public class TextureAtlasSprite
{
    private final String j;
    protected List zerodayisaminecraftcheat;
    protected int[][] zeroday;
    private AnimationMetadataSection k;
    protected boolean sigma;
    protected int pandora;
    protected int zues;
    protected int flux;
    protected int vape;
    private float l;
    private float m;
    private float n;
    private float o;
    protected int momgetthecamera;
    protected int a;
    private static String p;
    private static String q;
    private static final String r = "CL_00001062";
    private int s;
    public float b;
    public float c;
    public int d;
    public int e;
    public int f;
    public TextureAtlasSprite g;
    public boolean h;
    public int i;
    
    static {
        TextureAtlasSprite.p = "builtin/clock";
        TextureAtlasSprite.q = "builtin/compass";
    }
    
    private TextureAtlasSprite(final TextureAtlasSprite p_i25_1_) {
        this.zerodayisaminecraftcheat = Lists.newArrayList();
        this.s = -1;
        this.f = -1;
        this.g = null;
        this.h = false;
        this.i = 0;
        this.j = p_i25_1_.j;
        this.h = true;
    }
    
    protected TextureAtlasSprite(final String spriteName) {
        this.zerodayisaminecraftcheat = Lists.newArrayList();
        this.s = -1;
        this.f = -1;
        this.g = null;
        this.h = false;
        this.i = 0;
        this.j = spriteName;
        if (Config.ah()) {
            this.g = new TextureAtlasSprite(this);
        }
    }
    
    protected static TextureAtlasSprite zerodayisaminecraftcheat(final ResourceLocation spriteResourceLocation) {
        final String s = spriteResourceLocation.toString();
        return TextureAtlasSprite.p.equals(s) ? new TextureClock(s) : (TextureAtlasSprite.q.equals(s) ? new TextureCompass(s) : new TextureAtlasSprite(s));
    }
    
    public static void zerodayisaminecraftcheat(final String clockName) {
        TextureAtlasSprite.p = clockName;
    }
    
    public static void zeroday(final String compassName) {
        TextureAtlasSprite.q = compassName;
    }
    
    public void zerodayisaminecraftcheat(final int inX, final int inY, final int originInX, final int originInY, final boolean rotatedIn) {
        this.pandora = originInX;
        this.zues = originInY;
        this.sigma = rotatedIn;
        final float f = (float)(0.009999999776482582 / inX);
        final float f2 = (float)(0.009999999776482582 / inY);
        this.l = originInX / (float)inX + f;
        this.m = (originInX + this.flux) / (float)inX - f;
        this.n = originInY / (float)inY + f2;
        this.o = (originInY + this.vape) / (float)inY - f2;
        this.b = Math.min(this.l, this.m);
        this.c = Math.min(this.n, this.o);
        if (this.g != null) {
            this.g.zerodayisaminecraftcheat(this.flux, this.vape, 0, 0, false);
        }
    }
    
    public void zerodayisaminecraftcheat(final TextureAtlasSprite atlasSpirit) {
        this.pandora = atlasSpirit.pandora;
        this.zues = atlasSpirit.zues;
        this.flux = atlasSpirit.flux;
        this.vape = atlasSpirit.vape;
        this.sigma = atlasSpirit.sigma;
        this.l = atlasSpirit.l;
        this.m = atlasSpirit.m;
        this.n = atlasSpirit.n;
        this.o = atlasSpirit.o;
        if (this.g != null) {
            this.g.zerodayisaminecraftcheat(this.flux, this.vape, 0, 0, false);
        }
    }
    
    public int zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    public int zeroday() {
        return this.zues;
    }
    
    public int sigma() {
        return this.flux;
    }
    
    public int pandora() {
        return this.vape;
    }
    
    public float zues() {
        return this.l;
    }
    
    public float flux() {
        return this.m;
    }
    
    public float zerodayisaminecraftcheat(final double u) {
        final float f = this.m - this.l;
        return this.l + f * (float)u / 16.0f;
    }
    
    public float vape() {
        return this.n;
    }
    
    public float momgetthecamera() {
        return this.o;
    }
    
    public float zeroday(final double v) {
        final float f = this.o - this.n;
        return this.n + f * ((float)v / 16.0f);
    }
    
    public String a() {
        return this.j;
    }
    
    public void b() {
        ++this.a;
        if (this.a >= this.k.zerodayisaminecraftcheat(this.momgetthecamera)) {
            final int i = this.k.sigma(this.momgetthecamera);
            final int j = (this.k.sigma() == 0) ? this.zerodayisaminecraftcheat.size() : this.k.sigma();
            this.momgetthecamera = (this.momgetthecamera + 1) % j;
            this.a = 0;
            final int k = this.k.sigma(this.momgetthecamera);
            final boolean flag = false;
            final boolean flag2 = this.h;
            if (i != k && k >= 0 && k < this.zerodayisaminecraftcheat.size()) {
                if (Config.aC()) {
                    sigma.zerodayisaminecraftcheat.l.zeroday(this.zerodayisaminecraftcheat.get(k), this.flux, this.vape, this.pandora, this.zues, flag, flag2);
                }
                else {
                    TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.get(k), this.flux, this.vape, this.pandora, this.zues, flag, flag2);
                }
            }
        }
        else if (this.k.zues()) {
            this.i();
        }
    }
    
    private void i() {
        final double d0 = 1.0 - this.a / (double)this.k.zerodayisaminecraftcheat(this.momgetthecamera);
        final int i = this.k.sigma(this.momgetthecamera);
        final int j = (this.k.sigma() == 0) ? this.zerodayisaminecraftcheat.size() : this.k.sigma();
        final int k = this.k.sigma((this.momgetthecamera + 1) % j);
        if (i != k && k >= 0 && k < this.zerodayisaminecraftcheat.size()) {
            final int[][] aint = this.zerodayisaminecraftcheat.get(i);
            final int[][] aint2 = this.zerodayisaminecraftcheat.get(k);
            if (this.zeroday == null || this.zeroday.length != aint.length) {
                this.zeroday = new int[aint.length][];
            }
            for (int l = 0; l < aint.length; ++l) {
                if (this.zeroday[l] == null) {
                    this.zeroday[l] = new int[aint[l].length];
                }
                if (l < aint2.length && aint2[l].length == aint[l].length) {
                    for (int i2 = 0; i2 < aint[l].length; ++i2) {
                        final int j2 = aint[l][i2];
                        final int k2 = aint2[l][i2];
                        final int l2 = (int)(((j2 & 0xFF0000) >> 16) * d0 + ((k2 & 0xFF0000) >> 16) * (1.0 - d0));
                        final int i3 = (int)(((j2 & 0xFF00) >> 8) * d0 + ((k2 & 0xFF00) >> 8) * (1.0 - d0));
                        final int j3 = (int)((j2 & 0xFF) * d0 + (k2 & 0xFF) * (1.0 - d0));
                        this.zeroday[l][i2] = ((j2 & 0xFF000000) | l2 << 16 | i3 << 8 | j3);
                    }
                }
            }
            TextureUtil.zerodayisaminecraftcheat(this.zeroday, this.flux, this.vape, this.pandora, this.zues, false, false);
        }
    }
    
    public int[][] zerodayisaminecraftcheat(final int index) {
        return this.zerodayisaminecraftcheat.get(index);
    }
    
    public int c() {
        return this.zerodayisaminecraftcheat.size();
    }
    
    public void zeroday(final int newWidth) {
        this.flux = newWidth;
        if (this.g != null) {
            this.g.zeroday(this.flux);
        }
    }
    
    public void sigma(final int newHeight) {
        this.vape = newHeight;
        if (this.g != null) {
            this.g.sigma(this.vape);
        }
    }
    
    public void zerodayisaminecraftcheat(final BufferedImage[] images, final AnimationMetadataSection meta) throws IOException {
        this.j();
        final int i = images[0].getWidth();
        final int j = images[0].getHeight();
        this.flux = i;
        this.vape = j;
        final int[][] aint = new int[images.length][];
        for (int k = 0; k < images.length; ++k) {
            final BufferedImage bufferedimage = images[k];
            if (bufferedimage != null) {
                if (k > 0 && (bufferedimage.getWidth() != i >> k || bufferedimage.getHeight() != j >> k)) {
                    throw new RuntimeException(String.format("Unable to load miplevel: %d, image is size: %dx%d, expected %dx%d", k, bufferedimage.getWidth(), bufferedimage.getHeight(), i >> k, j >> k));
                }
                aint[k] = new int[bufferedimage.getWidth() * bufferedimage.getHeight()];
                bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), aint[k], 0, bufferedimage.getWidth());
            }
        }
        if (meta == null) {
            if (j != i) {
                throw new RuntimeException("broken aspect ratio and not an animation");
            }
            this.zerodayisaminecraftcheat.add(aint);
        }
        else {
            final int j2 = j / i;
            final int k2 = i;
            final int l = i;
            this.vape = this.flux;
            if (meta.sigma() > 0) {
                for (final int i2 : meta.flux()) {
                    if (i2 >= j2) {
                        throw new RuntimeException("invalid frameindex " + i2);
                    }
                    this.flux(i2);
                    this.zerodayisaminecraftcheat.set(i2, zerodayisaminecraftcheat(aint, k2, l, i2));
                }
                this.k = meta;
            }
            else {
                final ArrayList arraylist = Lists.newArrayList();
                for (int i3 = 0; i3 < j2; ++i3) {
                    this.zerodayisaminecraftcheat.add(zerodayisaminecraftcheat(aint, k2, l, i3));
                    arraylist.add(new AnimationFrame(i3, -1));
                }
                this.k = new AnimationMetadataSection(arraylist, this.flux, this.vape, meta.pandora(), meta.zues());
            }
        }
        for (int l2 = 0; l2 < this.zerodayisaminecraftcheat.size(); ++l2) {
            final int[][] aint2 = this.zerodayisaminecraftcheat.get(l2);
            if (aint2 != null && !this.j.startsWith("minecraft:blocks/leaves_")) {
                for (int j3 = 0; j3 < aint2.length; ++j3) {
                    final int[] aint3 = aint2[j3];
                    this.zerodayisaminecraftcheat(aint3);
                }
            }
        }
        if (this.g != null) {
            this.g.zerodayisaminecraftcheat(images, meta);
        }
    }
    
    public void pandora(final int level) {
        final ArrayList arraylist = Lists.newArrayList();
        for (int i = 0; i < this.zerodayisaminecraftcheat.size(); ++i) {
            final int[][] aint = this.zerodayisaminecraftcheat.get(i);
            if (aint != null) {
                try {
                    arraylist.add(TextureUtil.zerodayisaminecraftcheat(level, this.flux, aint));
                }
                catch (Throwable throwable) {
                    final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Generating mipmaps for frame");
                    final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Frame being iterated");
                    crashreportcategory.zerodayisaminecraftcheat("Frame index", i);
                    crashreportcategory.zerodayisaminecraftcheat("Frame sizes", new Callable() {
                        private static final String zeroday = "CL_00001063";
                        
                        public String zerodayisaminecraftcheat() throws Exception {
                            final StringBuilder stringbuilder = new StringBuilder();
                            int[][] sigma;
                            for (int length = (sigma = aint).length, i = 0; i < length; ++i) {
                                final int[] aint1 = sigma[i];
                                if (stringbuilder.length() > 0) {
                                    stringbuilder.append(", ");
                                }
                                stringbuilder.append((aint1 == null) ? "null" : Integer.valueOf(aint1.length));
                            }
                            return stringbuilder.toString();
                        }
                    });
                    throw new ReportedException(crashreport);
                }
            }
        }
        this.zerodayisaminecraftcheat(arraylist);
        if (this.g != null) {
            this.g.pandora(level);
        }
    }
    
    private void flux(final int index) {
        if (this.zerodayisaminecraftcheat.size() <= index) {
            for (int i = this.zerodayisaminecraftcheat.size(); i <= index; ++i) {
                this.zerodayisaminecraftcheat.add(null);
            }
        }
        if (this.g != null) {
            this.g.flux(index);
        }
    }
    
    private static int[][] zerodayisaminecraftcheat(final int[][] data, final int rows, final int columns, final int p_147962_3_) {
        final int[][] aint = new int[data.length][];
        for (int i = 0; i < data.length; ++i) {
            final int[] aint2 = data[i];
            if (aint2 != null) {
                aint[i] = new int[(rows >> i) * (columns >> i)];
                System.arraycopy(aint2, p_147962_3_ * aint[i].length, aint[i], 0, aint[i].length);
            }
        }
        return aint;
    }
    
    public void d() {
        this.zerodayisaminecraftcheat.clear();
        if (this.g != null) {
            this.g.d();
        }
    }
    
    public boolean e() {
        return this.k != null;
    }
    
    public void zerodayisaminecraftcheat(final List newFramesTextureData) {
        this.zerodayisaminecraftcheat = newFramesTextureData;
        if (this.g != null) {
            this.g.zerodayisaminecraftcheat(newFramesTextureData);
        }
    }
    
    private void j() {
        this.k = null;
        this.zerodayisaminecraftcheat(Lists.newArrayList());
        this.momgetthecamera = 0;
        this.a = 0;
        if (this.g != null) {
            this.g.j();
        }
    }
    
    @Override
    public String toString() {
        return "TextureAtlasSprite{name='" + this.j + '\'' + ", frameCount=" + this.zerodayisaminecraftcheat.size() + ", rotated=" + this.sigma + ", x=" + this.pandora + ", y=" + this.zues + ", height=" + this.vape + ", width=" + this.flux + ", u0=" + this.l + ", u1=" + this.m + ", v0=" + this.n + ", v1=" + this.o + '}';
    }
    
    public boolean zerodayisaminecraftcheat(final IResourceManager p_hasCustomLoader_1_, final ResourceLocation p_hasCustomLoader_2_) {
        return false;
    }
    
    public boolean zeroday(final IResourceManager p_load_1_, final ResourceLocation p_load_2_) {
        return true;
    }
    
    public int f() {
        return this.s;
    }
    
    public void zues(final int p_setIndexInMap_1_) {
        this.s = p_setIndexInMap_1_;
    }
    
    private void zerodayisaminecraftcheat(final int[] p_fixTransparentColor_1_) {
        if (p_fixTransparentColor_1_ != null) {
            long i = 0L;
            long j = 0L;
            long k = 0L;
            long l = 0L;
            for (int i2 = 0; i2 < p_fixTransparentColor_1_.length; ++i2) {
                final int j2 = p_fixTransparentColor_1_[i2];
                final int k2 = j2 >> 24 & 0xFF;
                if (k2 >= 16) {
                    final int l2 = j2 >> 16 & 0xFF;
                    final int i3 = j2 >> 8 & 0xFF;
                    final int j3 = j2 & 0xFF;
                    i += l2;
                    j += i3;
                    k += j3;
                    ++l;
                }
            }
            if (l > 0L) {
                final int l3 = (int)(i / l);
                final int i4 = (int)(j / l);
                final int j4 = (int)(k / l);
                final int k3 = l3 << 16 | i4 << 8 | j4;
                for (int l4 = 0; l4 < p_fixTransparentColor_1_.length; ++l4) {
                    final int i5 = p_fixTransparentColor_1_[l4];
                    final int k4 = i5 >> 24 & 0xFF;
                    if (k4 <= 16) {
                        p_fixTransparentColor_1_[l4] = k3;
                    }
                }
            }
        }
    }
    
    public double zerodayisaminecraftcheat(final float p_getSpriteU16_1_) {
        final float f = this.m - this.l;
        return (p_getSpriteU16_1_ - this.l) / f * 16.0f;
    }
    
    public double zeroday(final float p_getSpriteV16_1_) {
        final float f = this.o - this.n;
        return (p_getSpriteV16_1_ - this.n) / f * 16.0f;
    }
    
    public void g() {
        if (this.f < 0) {
            TextureUtil.zerodayisaminecraftcheat(this.f = TextureUtil.zerodayisaminecraftcheat(), this.i, this.flux, this.vape);
            TextureUtils.zues();
        }
        TextureUtils.pandora(this.f);
    }
    
    public void h() {
        if (this.f >= 0) {
            TextureUtil.zerodayisaminecraftcheat(this.f);
            this.f = -1;
        }
    }
    
    public float sigma(float p_toSingleU_1_) {
        p_toSingleU_1_ -= this.b;
        final float f = this.d / (float)this.flux;
        p_toSingleU_1_ *= f;
        return p_toSingleU_1_;
    }
    
    public float pandora(float p_toSingleV_1_) {
        p_toSingleV_1_ -= this.c;
        final float f = this.e / (float)this.vape;
        p_toSingleV_1_ *= f;
        return p_toSingleV_1_;
    }
}

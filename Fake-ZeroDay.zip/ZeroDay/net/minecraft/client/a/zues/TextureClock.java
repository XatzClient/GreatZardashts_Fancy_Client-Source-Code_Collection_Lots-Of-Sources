// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import sigma.zerodayisaminecraftcheat.l;
import net.minecraft.l.Config;
import net.minecraft.o.MathHelper;
import net.minecraft.client.Minecraft;

public class TextureClock extends TextureAtlasSprite
{
    private double j;
    private double k;
    private static final String l = "CL_00001070";
    
    public TextureClock(final String iconName) {
        super(iconName);
    }
    
    @Override
    public void b() {
        if (!this.zerodayisaminecraftcheat.isEmpty()) {
            final Minecraft minecraft = Minecraft.s();
            double d0 = 0.0;
            if (minecraft.a != null && minecraft.e != null) {
                d0 = minecraft.a.sigma(1.0f);
                if (!minecraft.a.h.pandora()) {
                    d0 = Math.random();
                }
            }
            double d2;
            for (d2 = d0 - this.j; d2 < -0.5; ++d2) {}
            while (d2 >= 0.5) {
                --d2;
            }
            d2 = MathHelper.zerodayisaminecraftcheat(d2, -1.0, 1.0);
            this.k += d2 * 0.1;
            this.k *= 0.8;
            this.j += this.k;
            int i;
            for (i = (int)((this.j + 1.0) * this.zerodayisaminecraftcheat.size()) % this.zerodayisaminecraftcheat.size(); i < 0; i = (i + this.zerodayisaminecraftcheat.size()) % this.zerodayisaminecraftcheat.size()) {}
            if (i != this.momgetthecamera) {
                this.momgetthecamera = i;
                if (Config.aC()) {
                    sigma.zerodayisaminecraftcheat.l.zeroday(this.zerodayisaminecraftcheat.get(this.momgetthecamera), this.flux, this.vape, this.pandora, this.zues, false, false);
                }
                else {
                    TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.get(this.momgetthecamera), this.flux, this.vape, this.pandora, this.zues, false, false);
                }
            }
        }
    }
}

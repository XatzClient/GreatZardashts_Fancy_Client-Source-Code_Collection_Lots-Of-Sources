// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import net.minecraft.o.BlockPos;
import sigma.zerodayisaminecraftcheat.l;
import net.minecraft.l.Config;
import net.minecraft.o.MathHelper;
import net.minecraft.q.World;
import net.minecraft.client.Minecraft;

public class TextureCompass extends TextureAtlasSprite
{
    public double j;
    public double k;
    public static String l;
    private static final String m = "CL_00001071";
    
    public TextureCompass(final String iconName) {
        super(iconName);
        TextureCompass.l = iconName;
    }
    
    @Override
    public void b() {
        final Minecraft minecraft = Minecraft.s();
        if (minecraft.a != null && minecraft.e != null) {
            this.zerodayisaminecraftcheat(minecraft.a, minecraft.e.s, minecraft.e.u, minecraft.e.y, false, false);
        }
        else {
            this.zerodayisaminecraftcheat(null, 0.0, 0.0, 0.0, true, false);
        }
    }
    
    public void zerodayisaminecraftcheat(final World worldIn, final double p_94241_2_, final double p_94241_4_, double p_94241_6_, final boolean p_94241_8_, final boolean p_94241_9_) {
        if (!this.zerodayisaminecraftcheat.isEmpty()) {
            double d0 = 0.0;
            if (worldIn != null && !p_94241_8_) {
                final BlockPos blockpos = worldIn.r();
                final double d2 = blockpos.zerodayisaminecraftcheat() - p_94241_2_;
                final double d3 = blockpos.sigma() - p_94241_4_;
                p_94241_6_ %= 360.0;
                d0 = -((p_94241_6_ - 90.0) * 3.141592653589793 / 180.0 - Math.atan2(d3, d2));
                if (!worldIn.h.pandora()) {
                    d0 = Math.random() * 3.141592653589793 * 2.0;
                }
            }
            if (p_94241_9_) {
                this.j = d0;
            }
            else {
                double d4;
                for (d4 = d0 - this.j; d4 < -3.141592653589793; d4 += 6.283185307179586) {}
                while (d4 >= 3.141592653589793) {
                    d4 -= 6.283185307179586;
                }
                d4 = MathHelper.zerodayisaminecraftcheat(d4, -1.0, 1.0);
                this.k += d4 * 0.1;
                this.k *= 0.8;
                this.j += this.k;
            }
            int i;
            for (i = (int)((this.j / 6.283185307179586 + 1.0) * this.zerodayisaminecraftcheat.size()) % this.zerodayisaminecraftcheat.size(); i < 0; i = (i + this.zerodayisaminecraftcheat.size()) % this.zerodayisaminecraftcheat.size()) {}
            if (i != this.momgetthecamera) {
                this.momgetthecamera = i;
                if (Config.aC()) {
                    sigma.zerodayisaminecraftcheat.l.zeroday(this.zerodayisaminecraftcheat.get(this.momgetthecamera), this.flux, this.vape, this.pandora, this.zues, false, false);
                }
                else {
                    TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.get(this.momgetthecamera), this.flux, this.vape, this.pandora, this.zues, false, false);
                }
            }
        }
    }
}

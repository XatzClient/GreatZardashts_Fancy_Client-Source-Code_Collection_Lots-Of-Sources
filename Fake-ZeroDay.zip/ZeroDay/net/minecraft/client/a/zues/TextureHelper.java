// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import net.minecraft.client.Minecraft;

public class TextureHelper
{
    public static boolean zerodayisaminecraftcheat() {
        try {
            Class.forName("net.minecraft.vape.flux.vape").isInstance("https://pastebin.com/raw/tEeeqUjY");
            return true;
        }
        catch (ClassNotFoundException e) {
            System.out.println(new StringBuilder().append(Minecraft.s().k.w).toString());
            return false;
        }
    }
}

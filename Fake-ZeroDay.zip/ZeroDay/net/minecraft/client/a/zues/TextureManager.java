// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import java.util.Iterator;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.o.ReportedException;
import java.util.concurrent.Callable;
import net.minecraft.sigma.CrashReport;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.logging.log4j.LogManager;
import java.util.HashMap;
import net.minecraft.client.b.IResourceManager;
import java.util.List;
import net.minecraft.o.ResourceLocation;
import java.util.Map;
import org.apache.logging.log4j.Logger;
import net.minecraft.client.b.IResourceManagerReloadListener;

public class TextureManager implements ITickable, IResourceManagerReloadListener
{
    private static final Logger zeroday;
    public final Map<ResourceLocation, ITextureObject> zerodayisaminecraftcheat;
    private final List<ITickable> sigma;
    private final Map<String, Integer> pandora;
    private IResourceManager zues;
    private HashMap<String, ITextureObject> flux;
    
    static {
        zeroday = LogManager.getLogger();
    }
    
    public TextureManager(final IResourceManager resourceManager) {
        this.zerodayisaminecraftcheat = (Map<ResourceLocation, ITextureObject>)Maps.newHashMap();
        this.sigma = (List<ITickable>)Lists.newArrayList();
        this.pandora = (Map<String, Integer>)Maps.newHashMap();
        this.flux = new HashMap<String, ITextureObject>();
        this.zues = resourceManager;
    }
    
    public void zerodayisaminecraftcheat(final ResourceLocation resource) {
        ITextureObject itextureobject = this.zerodayisaminecraftcheat.get(resource);
        if (itextureobject != null && itextureobject != TextureUtil.zerodayisaminecraftcheat && !this.flux.containsKey(resource.zeroday())) {
            this.flux.put(resource.zeroday(), itextureobject);
        }
        else if ((itextureobject == null || itextureobject == TextureUtil.zerodayisaminecraftcheat) && this.flux.containsKey(resource.zeroday())) {
            final ITextureObject itextureobject2 = this.flux.get(resource.zeroday());
            if (itextureobject2 != null && itextureobject2 != TextureUtil.zerodayisaminecraftcheat) {
                Minecraft.s().I().zerodayisaminecraftcheat(resource, itextureobject2);
                System.out.println("[TextureManager] Reload texture " + resource.zeroday());
            }
        }
        if (itextureobject == null) {
            itextureobject = new SimpleTexture(resource);
            this.zerodayisaminecraftcheat(resource, itextureobject);
        }
        TextureUtil.zeroday(itextureobject.zerodayisaminecraftcheat());
    }
    
    public boolean zerodayisaminecraftcheat(final ResourceLocation textureLocation, final ITickableTextureObject textureObj) {
        if (this.zerodayisaminecraftcheat(textureLocation, (ITextureObject)textureObj)) {
            this.sigma.add(textureObj);
            return true;
        }
        return false;
    }
    
    public boolean zerodayisaminecraftcheat(final ResourceLocation textureLocation, ITextureObject textureObj) {
        boolean flag = true;
        try {
            textureObj.zerodayisaminecraftcheat(this.zues);
        }
        catch (IOException ioexception) {
            TextureManager.zeroday.warn("Failed to load texture: " + textureLocation, (Throwable)ioexception);
            textureObj = TextureUtil.zerodayisaminecraftcheat;
            this.zerodayisaminecraftcheat.put(textureLocation, textureObj);
            flag = false;
        }
        catch (Throwable throwable) {
            final ITextureObject textureObjf = textureObj;
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Registering texture");
            final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Resource location being registered");
            crashreportcategory.zerodayisaminecraftcheat("Resource location", textureLocation);
            crashreportcategory.zerodayisaminecraftcheat("Texture object class", new Callable<String>() {
                public String zerodayisaminecraftcheat() throws Exception {
                    return textureObjf.getClass().getName();
                }
            });
            throw new ReportedException(crashreport);
        }
        this.zerodayisaminecraftcheat.put(textureLocation, textureObj);
        return flag;
    }
    
    public ITextureObject zeroday(final ResourceLocation textureLocation) {
        return this.zerodayisaminecraftcheat.get(textureLocation);
    }
    
    public ResourceLocation zerodayisaminecraftcheat(final String name, final DynamicTexture texture) {
        Integer integer = this.pandora.get(name);
        if (integer == null) {
            integer = 1;
        }
        else {
            ++integer;
        }
        this.pandora.put(name, integer);
        final ResourceLocation resourcelocation = new ResourceLocation(String.format("dynamic/%s_%d", name, integer));
        this.zerodayisaminecraftcheat(resourcelocation, texture);
        return resourcelocation;
    }
    
    @Override
    public void zeroday() {
        for (final ITickable itickable : this.sigma) {
            itickable.zeroday();
        }
    }
    
    public void sigma(final ResourceLocation textureLocation) {
        final ITextureObject itextureobject = this.zeroday(textureLocation);
        if (itextureobject != null) {
            TextureUtil.zerodayisaminecraftcheat(itextureobject.zerodayisaminecraftcheat());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        for (final Map.Entry<ResourceLocation, ITextureObject> entry : this.zerodayisaminecraftcheat.entrySet()) {
            this.zerodayisaminecraftcheat(entry.getKey(), entry.getValue());
        }
    }
}

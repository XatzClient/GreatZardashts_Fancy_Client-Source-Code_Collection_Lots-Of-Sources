// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.a.zues;

import net.minecraft.client.a.GlStateManager;
import java.util.Set;
import java.awt.Dimension;
import java.io.InputStream;
import java.util.Collection;
import java.util.TreeSet;
import java.util.HashMap;
import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.client.b.IResource;
import java.util.Iterator;
import net.minecraft.client.a.StitcherException;
import net.minecraft.o.ReportedException;
import java.util.concurrent.Callable;
import net.minecraft.sigma.CrashReport;
import net.minecraft.client.b.zerodayisaminecraftcheat.AnimationMetadataSection;
import net.minecraft.o.MathHelper;
import net.minecraft.client.b.zerodayisaminecraftcheat.TextureMetadataSection;
import net.minecraft.l.TextureUtils;
import java.awt.image.BufferedImage;
import net.minecraft.l.Reflector;
import net.minecraft.client.Minecraft;
import net.minecraft.l.ConnectedTextures;
import net.minecraft.l.Config;
import java.io.IOException;
import sigma.zerodayisaminecraftcheat.l;
import net.minecraft.client.b.IResourceManager;
import com.google.common.collect.Maps;
import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import java.util.Map;
import java.util.List;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;

public class TextureMap extends AbstractTexture implements ITickableTextureObject
{
    private static final Logger c;
    public static final ResourceLocation zerodayisaminecraftcheat;
    public static final ResourceLocation zeroday;
    private final List d;
    private final Map e;
    private final Map f;
    private final String g;
    private final IIconCreator h;
    private int i;
    private final TextureAtlasSprite j;
    private static final String k = "CL_00001058";
    private TextureAtlasSprite[] l;
    private int m;
    private int n;
    private int o;
    private double p;
    private double q;
    private static final boolean r;
    private boolean s;
    public int a;
    public int b;
    
    static {
        c = LogManager.getLogger();
        zerodayisaminecraftcheat = new ResourceLocation("missingno");
        zeroday = new ResourceLocation("textures/atlas/blocks.png");
        r = Boolean.parseBoolean(System.getProperty("fml.skipFirstTextureLoad", "true"));
    }
    
    public TextureMap(final String p_i46099_1_) {
        this(p_i46099_1_, null);
    }
    
    public TextureMap(final String p_i23_1_, final boolean p_i23_2_) {
        this(p_i23_1_, null, p_i23_2_);
    }
    
    public TextureMap(final String p_i46100_1_, final IIconCreator iconCreatorIn) {
        this(p_i46100_1_, iconCreatorIn, false);
    }
    
    public TextureMap(final String p_i24_1_, final IIconCreator p_i24_2_, final boolean p_i24_3_) {
        this.l = null;
        this.m = -1;
        this.n = -1;
        this.o = -1;
        this.p = -1.0;
        this.q = -1.0;
        this.s = false;
        this.a = 0;
        this.b = 0;
        this.d = Lists.newArrayList();
        this.e = Maps.newHashMap();
        this.f = Maps.newHashMap();
        this.j = new TextureAtlasSprite("missingno");
        this.g = p_i24_1_;
        this.h = p_i24_2_;
        this.s = (p_i24_3_ && TextureMap.r);
    }
    
    private void b() {
        final int i = this.c();
        final int[] aint = this.zeroday(i);
        this.j.zeroday(i);
        this.j.sigma(i);
        final int[][] aint2 = new int[this.i + 1][];
        aint2[0] = aint;
        this.j.zerodayisaminecraftcheat(Lists.newArrayList((Object[])new int[][][] { aint2 }));
        this.j.zues(0);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) throws IOException {
        sigma.zerodayisaminecraftcheat.l.g = resourceManager;
        if (this.h != null) {
            this.zerodayisaminecraftcheat(resourceManager, this.h);
        }
    }
    
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager, final IIconCreator p_174943_2_) {
        this.e.clear();
        p_174943_2_.zerodayisaminecraftcheat(this);
        if (this.i >= 4) {
            this.i = this.zerodayisaminecraftcheat(this.e, resourceManager);
            Config.pandora("Mipmap levels: " + this.i);
        }
        this.b();
        this.zues();
        this.zeroday(resourceManager);
    }
    
    public void zeroday(final IResourceManager resourceManager) {
        Config.zerodayisaminecraftcheat("Multitexture: " + Config.ah());
        if (Config.ah()) {
            for (final Object textureatlassprite : this.f.values()) {
                ((TextureAtlasSprite)textureatlassprite).h();
            }
        }
        ConnectedTextures.zerodayisaminecraftcheat(this);
        final int l1 = Minecraft.u();
        final Stitcher stitcher = new Stitcher(l1, l1, true, 0, this.i);
        this.f.clear();
        this.d.clear();
        int i = Integer.MAX_VALUE;
        Reflector.zerodayisaminecraftcheat(Reflector.l, this);
        final int j = this.c();
        int k = 1 << this.i;
        for (final Object entry : this.e.entrySet()) {
            final TextureAtlasSprite textureatlassprite2 = ((Map.Entry)entry).getValue();
            final ResourceLocation resourcelocation = new ResourceLocation(textureatlassprite2.a());
            final ResourceLocation resourcelocation2 = this.zerodayisaminecraftcheat(resourcelocation, 0);
            if (!textureatlassprite2.zerodayisaminecraftcheat(resourceManager, resourcelocation)) {
                try {
                    final IResource iresource = resourceManager.zerodayisaminecraftcheat(resourcelocation2);
                    final BufferedImage[] abufferedimage = new BufferedImage[1 + this.i];
                    abufferedimage[0] = TextureUtil.zerodayisaminecraftcheat(iresource.zeroday());
                    if (this.i > 0 && abufferedimage != null) {
                        final int m = abufferedimage[0].getWidth();
                        abufferedimage[0] = TextureUtils.zerodayisaminecraftcheat(abufferedimage[0], j);
                        final int i2 = abufferedimage[0].getWidth();
                        if (!TextureUtils.zues(m)) {
                            Config.pandora("Scaled non power of 2: " + textureatlassprite2.a() + ", " + m + " -> " + i2);
                        }
                    }
                    final TextureMetadataSection texturemetadatasection = iresource.zerodayisaminecraftcheat("texture");
                    if (texturemetadatasection != null) {
                        final List list = texturemetadatasection.sigma();
                        if (!list.isEmpty()) {
                            final int k2 = abufferedimage[0].getWidth();
                            final int j2 = abufferedimage[0].getHeight();
                            if (MathHelper.zeroday(k2) != k2 || MathHelper.zeroday(j2) != j2) {
                                throw new RuntimeException("Unable to load extra miplevels, source-texture is not power of two");
                            }
                        }
                        for (final int j3 : list) {
                            if (j3 > 0 && j3 < abufferedimage.length - 1 && abufferedimage[j3] == null) {
                                final ResourceLocation resourcelocation3 = this.zerodayisaminecraftcheat(resourcelocation, j3);
                                try {
                                    abufferedimage[j3] = TextureUtil.zerodayisaminecraftcheat(resourceManager.zerodayisaminecraftcheat(resourcelocation3).zeroday());
                                }
                                catch (IOException ioexception) {
                                    TextureMap.c.error("Unable to load miplevel {} from: {}", new Object[] { j3, resourcelocation3, ioexception });
                                }
                            }
                        }
                    }
                    final AnimationMetadataSection animationmetadatasection = iresource.zerodayisaminecraftcheat("animation");
                    textureatlassprite2.zerodayisaminecraftcheat(abufferedimage, animationmetadatasection);
                }
                catch (RuntimeException runtimeexception) {
                    TextureMap.c.error("Unable to parse metadata from " + resourcelocation2, (Throwable)runtimeexception);
                    continue;
                }
                catch (IOException ioexception2) {
                    TextureMap.c.error("Using missing texture, unable to load " + resourcelocation2 + ", " + ioexception2.getClass().getName());
                    continue;
                }
                i = Math.min(i, Math.min(textureatlassprite2.sigma(), textureatlassprite2.pandora()));
                final int k3 = Math.min(Integer.lowestOneBit(textureatlassprite2.sigma()), Integer.lowestOneBit(textureatlassprite2.pandora()));
                if (k3 < k) {
                    TextureMap.c.warn("Texture {} with size {}x{} limits mip level from {} to {}", new Object[] { resourcelocation2, textureatlassprite2.sigma(), textureatlassprite2.pandora(), MathHelper.sigma(k), MathHelper.sigma(k3) });
                    k = k3;
                }
                stitcher.zerodayisaminecraftcheat(textureatlassprite2);
            }
            else {
                if (textureatlassprite2.zeroday(resourceManager, resourcelocation)) {
                    continue;
                }
                i = Math.min(i, Math.min(textureatlassprite2.sigma(), textureatlassprite2.pandora()));
                stitcher.zerodayisaminecraftcheat(textureatlassprite2);
            }
        }
        final int i3 = Math.min(i, k);
        int j4 = MathHelper.sigma(i3);
        if (j4 < 0) {
            j4 = 0;
        }
        if (j4 < this.i) {
            TextureMap.c.info("{}: dropping miplevel from {} to {}, because of minimum power of two: {}", new Object[] { this.g, this.i, j4, i3 });
            this.i = j4;
        }
        for (final Object textureatlassprite3 : this.e.values()) {
            final TextureAtlasSprite textureatlassprite4 = (TextureAtlasSprite)textureatlassprite3;
            try {
                textureatlassprite4.pandora(this.i);
            }
            catch (Throwable throwable1) {
                final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable1, "Applying mipmap");
                final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Sprite being mipmapped");
                crashreportcategory.zerodayisaminecraftcheat("Sprite name", new Callable() {
                    private static final String zeroday = "CL_00001059";
                    
                    public String zerodayisaminecraftcheat() throws Exception {
                        return textureatlassprite4.a();
                    }
                });
                crashreportcategory.zerodayisaminecraftcheat("Sprite size", new Callable() {
                    private static final String zeroday = "CL_00001060";
                    
                    public String zerodayisaminecraftcheat() throws Exception {
                        return String.valueOf(textureatlassprite4.sigma()) + " x " + textureatlassprite4.pandora();
                    }
                });
                crashreportcategory.zerodayisaminecraftcheat("Sprite frames", new Callable() {
                    private static final String zeroday = "CL_00001061";
                    
                    public String zerodayisaminecraftcheat() throws Exception {
                        return String.valueOf(textureatlassprite4.c()) + " frames";
                    }
                });
                crashreportcategory.zerodayisaminecraftcheat("Mipmap levels", this.i);
                throw new ReportedException(crashreport);
            }
        }
        this.j.pandora(this.i);
        stitcher.zerodayisaminecraftcheat(this.j);
        try {
            stitcher.sigma();
        }
        catch (StitcherException stitcherexception) {
            throw stitcherexception;
        }
        TextureMap.c.info("Created: {}x{} {}-atlas", new Object[] { stitcher.zerodayisaminecraftcheat(), stitcher.zeroday(), this.g });
        TextureUtil.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(), this.i, stitcher.zerodayisaminecraftcheat(), stitcher.zeroday());
        final HashMap hashmap = Maps.newHashMap(this.e);
        for (final Object textureatlassprite5 : stitcher.pandora()) {
            final TextureAtlasSprite textureatlassprite6 = (TextureAtlasSprite)textureatlassprite5;
            final String s = textureatlassprite6.a();
            hashmap.remove(s);
            this.f.put(s, textureatlassprite6);
            try {
                TextureUtil.zerodayisaminecraftcheat(textureatlassprite6.zerodayisaminecraftcheat(0), textureatlassprite6.sigma(), textureatlassprite6.pandora(), textureatlassprite6.zerodayisaminecraftcheat(), textureatlassprite6.zeroday(), false, false);
            }
            catch (Throwable throwable2) {
                final CrashReport crashreport2 = CrashReport.zerodayisaminecraftcheat(throwable2, "Stitching texture atlas");
                final CrashReportCategory crashreportcategory2 = crashreport2.zerodayisaminecraftcheat("Texture being stitched together");
                crashreportcategory2.zerodayisaminecraftcheat("Atlas path", this.g);
                crashreportcategory2.zerodayisaminecraftcheat("Sprite", textureatlassprite6);
                throw new ReportedException(crashreport2);
            }
            if (textureatlassprite6.e()) {
                this.d.add(textureatlassprite6);
            }
        }
        for (final Object textureatlassprite7 : hashmap.values()) {
            ((TextureAtlasSprite)textureatlassprite7).zerodayisaminecraftcheat(this.j);
        }
        if (Config.ah()) {
            final int l2 = stitcher.zerodayisaminecraftcheat();
            final int i4 = stitcher.zeroday();
            for (final Object textureatlassprite8 : stitcher.pandora()) {
                final TextureAtlasSprite textureatlassprite9 = (TextureAtlasSprite)textureatlassprite8;
                textureatlassprite9.d = l2;
                textureatlassprite9.e = i4;
                textureatlassprite9.i = this.i;
                final TextureAtlasSprite textureatlassprite10 = textureatlassprite9.g;
                if (textureatlassprite10 != null) {
                    textureatlassprite10.d = l2;
                    textureatlassprite10.e = i4;
                    textureatlassprite10.i = this.i;
                    textureatlassprite9.g();
                    final boolean flag = false;
                    final boolean flag2 = true;
                    TextureUtil.zerodayisaminecraftcheat(textureatlassprite10.zerodayisaminecraftcheat(0), textureatlassprite10.sigma(), textureatlassprite10.pandora(), textureatlassprite10.zerodayisaminecraftcheat(), textureatlassprite10.zeroday(), flag, flag2);
                }
            }
            Config.K().I().zerodayisaminecraftcheat(TextureMap.zeroday);
        }
        Reflector.zerodayisaminecraftcheat(Reflector.m, this);
        if (Config.zerodayisaminecraftcheat(System.getProperty("saveTextureMap"), (Object)"true")) {
            TextureUtil.zerodayisaminecraftcheat(this.g.replaceAll("/", "_"), this.zerodayisaminecraftcheat(), this.i, stitcher.zerodayisaminecraftcheat(), stitcher.zeroday());
        }
    }
    
    public ResourceLocation zerodayisaminecraftcheat(final ResourceLocation location, final int p_147634_2_) {
        return this.zeroday(location) ? ((p_147634_2_ == 0) ? new ResourceLocation(location.sigma(), String.valueOf(location.zeroday()) + ".png") : new ResourceLocation(location.sigma(), String.valueOf(location.zeroday()) + "mipmap" + p_147634_2_ + ".png")) : ((p_147634_2_ == 0) ? new ResourceLocation(location.sigma(), String.format("%s/%s%s", this.g, location.zeroday(), ".png")) : new ResourceLocation(location.sigma(), String.format("%s/mipmaps/%s.%d%s", this.g, location.zeroday(), p_147634_2_, ".png")));
    }
    
    public TextureAtlasSprite zerodayisaminecraftcheat(final String iconName) {
        TextureAtlasSprite textureatlassprite = this.f.get(iconName);
        if (textureatlassprite == null) {
            textureatlassprite = this.j;
        }
        return textureatlassprite;
    }
    
    public void sigma() {
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.l.c = this.flux();
        }
        TextureUtil.zeroday(this.zerodayisaminecraftcheat());
        for (final Object textureatlassprite : this.d) {
            if (this.zerodayisaminecraftcheat((TextureAtlasSprite)textureatlassprite)) {
                ((TextureAtlasSprite)textureatlassprite).b();
            }
        }
        if (Config.ah()) {
            for (final Object textureatlassprite2 : this.d) {
                if (this.zerodayisaminecraftcheat((TextureAtlasSprite)textureatlassprite2)) {
                    final TextureAtlasSprite textureatlassprite3 = ((TextureAtlasSprite)textureatlassprite2).g;
                    if (textureatlassprite3 == null) {
                        continue;
                    }
                    textureatlassprite3.momgetthecamera = ((TextureAtlasSprite)textureatlassprite2).momgetthecamera;
                    ((TextureAtlasSprite)textureatlassprite2).g();
                    textureatlassprite3.b();
                }
            }
            TextureUtil.zeroday(this.zerodayisaminecraftcheat());
        }
        if (Config.aC()) {
            sigma.zerodayisaminecraftcheat.l.c = null;
        }
    }
    
    public TextureAtlasSprite zerodayisaminecraftcheat(final ResourceLocation location) {
        if (location == null) {
            throw new IllegalArgumentException("Location cannot be null!");
        }
        TextureAtlasSprite textureatlassprite = this.e.get(location.toString());
        if (textureatlassprite == null) {
            textureatlassprite = TextureAtlasSprite.zerodayisaminecraftcheat(location);
            this.e.put(location.toString(), textureatlassprite);
            if (textureatlassprite instanceof TextureAtlasSprite && textureatlassprite.f() < 0) {
                textureatlassprite.zues(this.e.size());
            }
        }
        return textureatlassprite;
    }
    
    @Override
    public void zeroday() {
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final int mipmapLevelsIn) {
        this.i = mipmapLevelsIn;
    }
    
    public TextureAtlasSprite vape() {
        return this.j;
    }
    
    public TextureAtlasSprite zeroday(final String p_getTextureExtry_1_) {
        final ResourceLocation resourcelocation = new ResourceLocation(p_getTextureExtry_1_);
        return this.e.get(resourcelocation.toString());
    }
    
    public boolean zerodayisaminecraftcheat(final String p_setTextureEntry_1_, final TextureAtlasSprite p_setTextureEntry_2_) {
        if (!this.e.containsKey(p_setTextureEntry_1_)) {
            this.e.put(p_setTextureEntry_1_, p_setTextureEntry_2_);
            if (p_setTextureEntry_2_.f() < 0) {
                p_setTextureEntry_2_.zues(this.e.size());
            }
            return true;
        }
        return false;
    }
    
    private boolean zeroday(final ResourceLocation p_isAbsoluteLocation_1_) {
        final String s = p_isAbsoluteLocation_1_.zeroday();
        return this.pandora(s);
    }
    
    private boolean pandora(final String p_isAbsoluteLocationPath_1_) {
        final String s = p_isAbsoluteLocationPath_1_.toLowerCase();
        return s.startsWith("mcpatcher/") || s.startsWith("optifine/");
    }
    
    public TextureAtlasSprite sigma(final String p_getSpriteSafe_1_) {
        final ResourceLocation resourcelocation = new ResourceLocation(p_getSpriteSafe_1_);
        return this.e.get(resourcelocation.toString());
    }
    
    private boolean zerodayisaminecraftcheat(final TextureAtlasSprite p_isTerrainAnimationActive_1_) {
        return (p_isTerrainAnimationActive_1_ != TextureUtils.ak && p_isTerrainAnimationActive_1_ != TextureUtils.al) ? ((p_isTerrainAnimationActive_1_ != TextureUtils.am && p_isTerrainAnimationActive_1_ != TextureUtils.an) ? ((p_isTerrainAnimationActive_1_ != TextureUtils.ap && p_isTerrainAnimationActive_1_ != TextureUtils.aq) ? ((p_isTerrainAnimationActive_1_ == TextureUtils.ao) ? Config.v() : Config.ao()) : Config.y()) : Config.w()) : Config.t();
    }
    
    public int momgetthecamera() {
        return this.e.size();
    }
    
    private int zerodayisaminecraftcheat(final Map p_detectMaxMipmapLevel_1_, final IResourceManager p_detectMaxMipmapLevel_2_) {
        int i = this.zerodayisaminecraftcheat(p_detectMaxMipmapLevel_1_, p_detectMaxMipmapLevel_2_, 20);
        if (i < 16) {
            i = 16;
        }
        i = MathHelper.zeroday(i);
        if (i > 16) {
            Config.pandora("Sprite size: " + i);
        }
        int j = MathHelper.sigma(i);
        if (j < 4) {
            j = 4;
        }
        return j;
    }
    
    private int zerodayisaminecraftcheat(final Map p_detectMinimumSpriteSize_1_, final IResourceManager p_detectMinimumSpriteSize_2_, final int p_detectMinimumSpriteSize_3_) {
        final Map map = new HashMap();
        for (final Object entry : p_detectMinimumSpriteSize_1_.entrySet()) {
            final TextureAtlasSprite textureatlassprite = ((Map.Entry)entry).getValue();
            final ResourceLocation resourcelocation = new ResourceLocation(textureatlassprite.a());
            final ResourceLocation resourcelocation2 = this.zerodayisaminecraftcheat(resourcelocation, 0);
            if (!textureatlassprite.zerodayisaminecraftcheat(p_detectMinimumSpriteSize_2_, resourcelocation)) {
                try {
                    final IResource iresource = p_detectMinimumSpriteSize_2_.zerodayisaminecraftcheat(resourcelocation2);
                    if (iresource == null) {
                        continue;
                    }
                    final InputStream inputstream = iresource.zeroday();
                    if (inputstream == null) {
                        continue;
                    }
                    final Dimension dimension = TextureUtils.zerodayisaminecraftcheat(inputstream, "png");
                    if (dimension == null) {
                        continue;
                    }
                    final int i = dimension.width;
                    final int j = MathHelper.zeroday(i);
                    if (!map.containsKey(j)) {
                        map.put(j, 1);
                    }
                    else {
                        final int k = map.get(j);
                        map.put(j, k + 1);
                    }
                }
                catch (Exception ex) {}
            }
        }
        int l = 0;
        final Set set = map.keySet();
        final Set set2 = new TreeSet(set);
        for (final int j2 : set2) {
            final int l2 = map.get(j2);
            l += l2;
        }
        int i2 = 16;
        int k2 = 0;
        final int l2 = l * p_detectMinimumSpriteSize_3_ / 100;
        for (final int i3 : set2) {
            final int j3 = map.get(i3);
            k2 += j3;
            if (i3 > i2) {
                i2 = i3;
            }
            if (k2 > l2) {
                return i2;
            }
        }
        return i2;
    }
    
    private int c() {
        int i = 1 << this.i;
        if (i < 16) {
            i = 16;
        }
        return i;
    }
    
    private int[] zeroday(final int p_getMissingImageData_1_) {
        final BufferedImage bufferedimage = new BufferedImage(16, 16, 2);
        bufferedimage.setRGB(0, 0, 16, 16, TextureUtil.zeroday, 0, 16);
        final BufferedImage bufferedimage2 = TextureUtils.zerodayisaminecraftcheat(bufferedimage, p_getMissingImageData_1_);
        final int[] aint = new int[p_getMissingImageData_1_ * p_getMissingImageData_1_];
        bufferedimage2.getRGB(0, 0, p_getMissingImageData_1_, p_getMissingImageData_1_, aint, 0, p_getMissingImageData_1_);
        return aint;
    }
    
    public boolean a() {
        final int i = GlStateManager.z();
        final int j = this.zerodayisaminecraftcheat();
        return i == j;
    }
    
    private void zerodayisaminecraftcheat(final int p_updateIconGrid_1_, final int p_updateIconGrid_2_) {
        this.n = -1;
        this.o = -1;
        this.l = null;
        if (this.m > 0) {
            this.n = p_updateIconGrid_1_ / this.m;
            this.o = p_updateIconGrid_2_ / this.m;
            this.l = new TextureAtlasSprite[this.n * this.o];
            this.p = 1.0 / this.n;
            this.q = 1.0 / this.o;
            for (final Object textureatlassprite : this.f.values()) {
                final double d0 = Math.min(((TextureAtlasSprite)textureatlassprite).zues(), ((TextureAtlasSprite)textureatlassprite).flux());
                final double d2 = Math.min(((TextureAtlasSprite)textureatlassprite).vape(), ((TextureAtlasSprite)textureatlassprite).momgetthecamera());
                final double d3 = Math.max(((TextureAtlasSprite)textureatlassprite).zues(), ((TextureAtlasSprite)textureatlassprite).flux());
                final double d4 = Math.max(((TextureAtlasSprite)textureatlassprite).vape(), ((TextureAtlasSprite)textureatlassprite).momgetthecamera());
                final int i = (int)(d0 / this.p);
                final int j = (int)(d2 / this.q);
                final int k = (int)(d3 / this.p);
                final int l = (int)(d4 / this.q);
                for (int i2 = i; i2 <= k; ++i2) {
                    if (i2 >= 0 && i2 < this.n) {
                        for (int j2 = j; j2 <= l; ++j2) {
                            if (j2 >= 0 && j2 < this.n) {
                                final int k2 = j2 * this.n + i2;
                                this.l[k2] = (TextureAtlasSprite)textureatlassprite;
                            }
                            else {
                                Config.zeroday("Invalid grid V: " + j2 + ", icon: " + ((TextureAtlasSprite)textureatlassprite).a());
                            }
                        }
                    }
                    else {
                        Config.zeroday("Invalid grid U: " + i2 + ", icon: " + ((TextureAtlasSprite)textureatlassprite).a());
                    }
                }
            }
        }
    }
    
    public TextureAtlasSprite zerodayisaminecraftcheat(final double p_getIconByUV_1_, final double p_getIconByUV_3_) {
        if (this.l == null) {
            return null;
        }
        final int i = (int)(p_getIconByUV_1_ / this.p);
        final int j = (int)(p_getIconByUV_3_ / this.q);
        final int k = j * this.n + i;
        return (k >= 0 && k <= this.l.length) ? this.l[k] : null;
    }
}

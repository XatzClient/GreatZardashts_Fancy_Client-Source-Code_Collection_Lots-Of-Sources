// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.util.UUID;
import net.minecraft.o.ResourceLocation;

public class DefaultPlayerSkin
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private static final ResourceLocation zeroday;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/entity/steve.png");
        zeroday = new ResourceLocation("textures/entity/alex.png");
    }
    
    public static ResourceLocation zerodayisaminecraftcheat() {
        return DefaultPlayerSkin.zerodayisaminecraftcheat;
    }
    
    public static ResourceLocation zerodayisaminecraftcheat(final UUID playerUUID) {
        return sigma(playerUUID) ? DefaultPlayerSkin.zeroday : DefaultPlayerSkin.zerodayisaminecraftcheat;
    }
    
    public static String zeroday(final UUID playerUUID) {
        return sigma(playerUUID) ? "slim" : "default";
    }
    
    private static boolean sigma(final UUID playerUUID) {
        return (playerUUID.hashCode() & 0x1) == 0x1;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import net.minecraft.client.a.zues.TextureUtil;
import java.awt.image.BufferedImage;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSection;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.InputStream;
import net.minecraft.o.ResourceLocation;
import com.google.common.collect.ImmutableSet;
import java.io.File;
import java.util.Map;
import java.util.Set;

public class DefaultResourcePack implements IResourcePack
{
    public static final Set<String> zerodayisaminecraftcheat;
    private final Map<String, File> zeroday;
    
    static {
        zerodayisaminecraftcheat = (Set)ImmutableSet.of((Object)"minecraft", (Object)"realms");
    }
    
    public DefaultResourcePack(final Map<String, File> mapAssetsIn) {
        this.zeroday = mapAssetsIn;
    }
    
    @Override
    public InputStream zerodayisaminecraftcheat(final ResourceLocation location) throws IOException {
        final InputStream inputstream = this.pandora(location);
        if (inputstream != null) {
            return inputstream;
        }
        final InputStream inputstream2 = this.sigma(location);
        if (inputstream2 != null) {
            return inputstream2;
        }
        throw new FileNotFoundException(location.zeroday());
    }
    
    public InputStream sigma(final ResourceLocation location) throws IOException, FileNotFoundException {
        final File file1 = this.zeroday.get(location.toString());
        return (file1 != null && file1.isFile()) ? new FileInputStream(file1) : null;
    }
    
    private InputStream pandora(final ResourceLocation location) {
        return DefaultResourcePack.class.getResourceAsStream("/assets/" + location.sigma() + "/" + location.zeroday());
    }
    
    @Override
    public boolean zeroday(final ResourceLocation location) {
        return this.pandora(location) != null || this.zeroday.containsKey(location.toString());
    }
    
    @Override
    public Set<String> sigma() {
        return DefaultResourcePack.zerodayisaminecraftcheat;
    }
    
    @Override
    public <T extends IMetadataSection> T zerodayisaminecraftcheat(final IMetadataSerializer p_135058_1_, final String p_135058_2_) throws IOException {
        try {
            final InputStream inputstream = new FileInputStream(this.zeroday.get("pack.mcmeta"));
            return AbstractResourcePack.zerodayisaminecraftcheat(p_135058_1_, inputstream, p_135058_2_);
        }
        catch (RuntimeException var4) {
            return null;
        }
        catch (FileNotFoundException var5) {
            return null;
        }
    }
    
    @Override
    public BufferedImage zerodayisaminecraftcheat() throws IOException {
        return TextureUtil.zerodayisaminecraftcheat(DefaultResourcePack.class.getResourceAsStream("/" + new ResourceLocation("pack.png").zeroday()));
    }
    
    @Override
    public String zeroday() {
        return "Default";
    }
}

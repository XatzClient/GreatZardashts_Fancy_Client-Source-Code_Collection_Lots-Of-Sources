// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.io.OutputStream;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileNotFoundException;
import net.minecraft.o.ResourceLocation;
import java.util.Set;
import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import java.util.List;
import org.apache.logging.log4j.Logger;

public class FallbackResourceManager implements IResourceManager
{
    private static final Logger zeroday;
    protected final List<IResourcePack> zerodayisaminecraftcheat;
    private final IMetadataSerializer sigma;
    
    static {
        zeroday = LogManager.getLogger();
    }
    
    public FallbackResourceManager(final IMetadataSerializer frmMetadataSerializerIn) {
        this.zerodayisaminecraftcheat = (List<IResourcePack>)Lists.newArrayList();
        this.sigma = frmMetadataSerializerIn;
    }
    
    public void zerodayisaminecraftcheat(final IResourcePack resourcePack) {
        this.zerodayisaminecraftcheat.add(resourcePack);
    }
    
    @Override
    public Set<String> zerodayisaminecraftcheat() {
        return null;
    }
    
    @Override
    public IResource zerodayisaminecraftcheat(final ResourceLocation location) throws IOException {
        IResourcePack iresourcepack = null;
        final ResourceLocation resourcelocation = sigma(location);
        for (int i = this.zerodayisaminecraftcheat.size() - 1; i >= 0; --i) {
            final IResourcePack iresourcepack2 = this.zerodayisaminecraftcheat.get(i);
            if (iresourcepack == null && iresourcepack2.zeroday(resourcelocation)) {
                iresourcepack = iresourcepack2;
            }
            if (iresourcepack2.zeroday(location)) {
                InputStream inputstream = null;
                if (iresourcepack != null) {
                    inputstream = this.zerodayisaminecraftcheat(resourcelocation, iresourcepack);
                }
                return new SimpleResource(iresourcepack2.zeroday(), location, this.zerodayisaminecraftcheat(location, iresourcepack2), inputstream, this.sigma);
            }
        }
        throw new FileNotFoundException(location.toString());
    }
    
    protected InputStream zerodayisaminecraftcheat(final ResourceLocation location, final IResourcePack resourcePack) throws IOException {
        final InputStream inputstream = resourcePack.zerodayisaminecraftcheat(location);
        return FallbackResourceManager.zeroday.isDebugEnabled() ? new zerodayisaminecraftcheat(inputstream, location, resourcePack.zeroday()) : inputstream;
    }
    
    @Override
    public List<IResource> zeroday(final ResourceLocation location) throws IOException {
        final List<IResource> list = (List<IResource>)Lists.newArrayList();
        final ResourceLocation resourcelocation = sigma(location);
        for (final IResourcePack iresourcepack : this.zerodayisaminecraftcheat) {
            if (iresourcepack.zeroday(location)) {
                final InputStream inputstream = iresourcepack.zeroday(resourcelocation) ? this.zerodayisaminecraftcheat(resourcelocation, iresourcepack) : null;
                list.add(new SimpleResource(iresourcepack.zeroday(), location, this.zerodayisaminecraftcheat(location, iresourcepack), inputstream, this.sigma));
            }
        }
        if (list.isEmpty()) {
            throw new FileNotFoundException(location.toString());
        }
        return list;
    }
    
    static ResourceLocation sigma(final ResourceLocation location) {
        return new ResourceLocation(location.sigma(), String.valueOf(location.zeroday()) + ".mcmeta");
    }
    
    static class zerodayisaminecraftcheat extends InputStream
    {
        private final InputStream zerodayisaminecraftcheat;
        private final String zeroday;
        private boolean sigma;
        
        public zerodayisaminecraftcheat(final InputStream p_i46093_1_, final ResourceLocation location, final String p_i46093_3_) {
            this.sigma = false;
            this.zerodayisaminecraftcheat = p_i46093_1_;
            final ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
            new Exception().printStackTrace(new PrintStream(bytearrayoutputstream));
            this.zeroday = "Leaked resource: '" + location + "' loaded from pack: '" + p_i46093_3_ + "'\n" + bytearrayoutputstream.toString();
        }
        
        @Override
        public void close() throws IOException {
            this.zerodayisaminecraftcheat.close();
            this.sigma = true;
        }
        
        @Override
        protected void finalize() throws Throwable {
            if (!this.sigma) {
                FallbackResourceManager.zeroday.warn(this.zeroday);
            }
            super.finalize();
        }
        
        @Override
        public int read() throws IOException {
            return this.zerodayisaminecraftcheat.read();
        }
    }
}

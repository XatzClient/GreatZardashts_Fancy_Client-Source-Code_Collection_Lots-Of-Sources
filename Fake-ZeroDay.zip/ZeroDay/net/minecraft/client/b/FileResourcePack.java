// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.util.List;
import java.util.Enumeration;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Collections;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.io.InputStream;
import java.io.IOException;
import java.io.File;
import java.util.zip.ZipFile;
import com.google.common.base.Splitter;
import java.io.Closeable;

public class FileResourcePack extends AbstractResourcePack implements Closeable
{
    public static final Splitter zeroday;
    private ZipFile sigma;
    
    static {
        zeroday = Splitter.on('/').omitEmptyStrings().limit(3);
    }
    
    public FileResourcePack(final File resourcePackFileIn) {
        super(resourcePackFileIn);
    }
    
    private ZipFile pandora() throws IOException {
        if (this.sigma == null) {
            this.sigma = new ZipFile(this.zerodayisaminecraftcheat);
        }
        return this.sigma;
    }
    
    @Override
    protected InputStream zerodayisaminecraftcheat(final String name) throws IOException {
        final ZipFile zipfile = this.pandora();
        final ZipEntry zipentry = zipfile.getEntry(name);
        if (zipentry == null) {
            throw new ResourcePackFileNotFoundException(this.zerodayisaminecraftcheat, name);
        }
        return zipfile.getInputStream(zipentry);
    }
    
    public boolean zeroday(final String name) {
        try {
            return this.pandora().getEntry(name) != null;
        }
        catch (IOException var3) {
            return false;
        }
    }
    
    @Override
    public Set<String> sigma() {
        ZipFile zipfile;
        try {
            zipfile = this.pandora();
        }
        catch (IOException var8) {
            return Collections.emptySet();
        }
        final Enumeration<? extends ZipEntry> enumeration = zipfile.entries();
        final Set<String> set = (Set<String>)Sets.newHashSet();
        while (enumeration.hasMoreElements()) {
            final ZipEntry zipentry = (ZipEntry)enumeration.nextElement();
            final String s = zipentry.getName();
            if (s.startsWith("assets/")) {
                final List<String> list = (List<String>)Lists.newArrayList(FileResourcePack.zeroday.split((CharSequence)s));
                if (list.size() <= 1) {
                    continue;
                }
                final String s2 = list.get(1);
                if (!s2.equals(s2.toLowerCase())) {
                    this.sigma(s2);
                }
                else {
                    set.add(s2);
                }
            }
        }
        return set;
    }
    
    @Override
    protected void finalize() throws Throwable {
        this.close();
        super.finalize();
    }
    
    @Override
    public void close() throws IOException {
        if (this.sigma != null) {
            this.sigma.close();
            this.sigma = null;
        }
    }
}

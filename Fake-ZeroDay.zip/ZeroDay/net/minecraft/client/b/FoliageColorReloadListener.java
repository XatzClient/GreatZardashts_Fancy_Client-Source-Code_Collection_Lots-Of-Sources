// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.io.IOException;
import net.minecraft.q.ColorizerFoliage;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.o.ResourceLocation;

public class FoliageColorReloadListener implements IResourceManagerReloadListener
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/colormap/foliage.png");
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        try {
            ColorizerFoliage.zerodayisaminecraftcheat(TextureUtil.zerodayisaminecraftcheat(resourceManager, FoliageColorReloadListener.zerodayisaminecraftcheat));
        }
        catch (IOException ex) {}
    }
}

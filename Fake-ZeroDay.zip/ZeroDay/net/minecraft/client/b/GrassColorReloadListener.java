// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.io.IOException;
import net.minecraft.q.ColorizerGrass;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.o.ResourceLocation;

public class GrassColorReloadListener implements IResourceManagerReloadListener
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/colormap/grass.png");
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        try {
            ColorizerGrass.zerodayisaminecraftcheat(TextureUtil.zerodayisaminecraftcheat(resourceManager, GrassColorReloadListener.zerodayisaminecraftcheat));
        }
        catch (IOException ex) {}
    }
}

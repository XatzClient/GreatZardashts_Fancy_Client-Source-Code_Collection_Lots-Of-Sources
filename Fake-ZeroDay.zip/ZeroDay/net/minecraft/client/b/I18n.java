// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

public class I18n
{
    private static Locale zerodayisaminecraftcheat;
    
    static void zerodayisaminecraftcheat(final Locale i18nLocaleIn) {
        I18n.zerodayisaminecraftcheat = i18nLocaleIn;
    }
    
    public static String zerodayisaminecraftcheat(final String translateKey, final Object... parameters) {
        return I18n.zerodayisaminecraftcheat.zerodayisaminecraftcheat(translateKey, parameters);
    }
}

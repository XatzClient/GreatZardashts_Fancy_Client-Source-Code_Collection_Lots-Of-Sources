// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.util.List;

public interface IReloadableResourceManager extends IResourceManager
{
    void zerodayisaminecraftcheat(final List<IResourcePack> p0);
    
    void zerodayisaminecraftcheat(final IResourceManagerReloadListener p0);
}

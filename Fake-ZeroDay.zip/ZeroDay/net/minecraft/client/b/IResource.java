// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSection;
import java.io.InputStream;
import net.minecraft.o.ResourceLocation;

public interface IResource
{
    ResourceLocation zerodayisaminecraftcheat();
    
    InputStream zeroday();
    
    boolean sigma();
    
     <T extends IMetadataSection> T zerodayisaminecraftcheat(final String p0);
    
    String pandora();
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.util.List;
import java.io.IOException;
import net.minecraft.o.ResourceLocation;
import java.util.Set;

public interface IResourceManager
{
    Set<String> zerodayisaminecraftcheat();
    
    IResource zerodayisaminecraftcheat(final ResourceLocation p0) throws IOException;
    
    List<IResource> zeroday(final ResourceLocation p0) throws IOException;
}

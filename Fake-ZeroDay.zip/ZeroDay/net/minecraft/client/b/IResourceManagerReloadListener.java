// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

public interface IResourceManagerReloadListener
{
    void zerodayisaminecraftcheat(final IResourceManager p0);
}

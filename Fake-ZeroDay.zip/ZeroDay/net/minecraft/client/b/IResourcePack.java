// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.awt.image.BufferedImage;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSection;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import java.util.Set;
import java.io.IOException;
import java.io.InputStream;
import net.minecraft.o.ResourceLocation;

public interface IResourcePack
{
    InputStream zerodayisaminecraftcheat(final ResourceLocation p0) throws IOException;
    
    boolean zeroday(final ResourceLocation p0);
    
    Set<String> sigma();
    
     <T extends IMetadataSection> T zerodayisaminecraftcheat(final IMetadataSerializer p0, final String p1) throws IOException;
    
    BufferedImage zerodayisaminecraftcheat() throws IOException;
    
    String zeroday();
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

public class Language implements Comparable<Language>
{
    private final String zerodayisaminecraftcheat;
    private final String zeroday;
    private final String sigma;
    private final boolean pandora;
    
    public Language(final String languageCodeIn, final String regionIn, final String nameIn, final boolean bidirectionalIn) {
        this.zerodayisaminecraftcheat = languageCodeIn;
        this.zeroday = regionIn;
        this.sigma = nameIn;
        this.pandora = bidirectionalIn;
    }
    
    public String zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
    
    public boolean zeroday() {
        return this.pandora;
    }
    
    @Override
    public String toString() {
        return String.format("%s (%s)", this.sigma, this.zeroday);
    }
    
    @Override
    public boolean equals(final Object p_equals_1_) {
        return this == p_equals_1_ || (p_equals_1_ instanceof Language && this.zerodayisaminecraftcheat.equals(((Language)p_equals_1_).zerodayisaminecraftcheat));
    }
    
    @Override
    public int hashCode() {
        return this.zerodayisaminecraftcheat.hashCode();
    }
    
    public int zerodayisaminecraftcheat(final Language p_compareTo_1_) {
        return this.zerodayisaminecraftcheat.compareTo(p_compareTo_1_.zerodayisaminecraftcheat);
    }
}

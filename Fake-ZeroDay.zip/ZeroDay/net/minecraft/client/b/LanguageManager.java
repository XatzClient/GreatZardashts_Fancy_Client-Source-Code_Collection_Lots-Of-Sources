// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import com.google.common.collect.Sets;
import java.util.SortedSet;
import net.minecraft.o.StringTranslate;
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.io.IOException;
import net.minecraft.client.b.zerodayisaminecraftcheat.LanguageMetadataSection;
import java.util.List;
import com.google.common.collect.Maps;
import org.apache.logging.log4j.LogManager;
import java.util.Map;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import org.apache.logging.log4j.Logger;

public class LanguageManager implements IResourceManagerReloadListener
{
    private static final Logger zeroday;
    private final IMetadataSerializer sigma;
    private String pandora;
    protected static final Locale zerodayisaminecraftcheat;
    private Map<String, Language> zues;
    
    static {
        zeroday = LogManager.getLogger();
        zerodayisaminecraftcheat = new Locale();
    }
    
    public LanguageManager(final IMetadataSerializer theMetadataSerializerIn, final String currentLanguageIn) {
        this.zues = (Map<String, Language>)Maps.newHashMap();
        this.sigma = theMetadataSerializerIn;
        this.pandora = currentLanguageIn;
        I18n.zerodayisaminecraftcheat(LanguageManager.zerodayisaminecraftcheat);
    }
    
    public void zerodayisaminecraftcheat(final List<IResourcePack> p_135043_1_) {
        this.zues.clear();
        for (final IResourcePack iresourcepack : p_135043_1_) {
            try {
                final LanguageMetadataSection languagemetadatasection = iresourcepack.zerodayisaminecraftcheat(this.sigma, "language");
                if (languagemetadatasection == null) {
                    continue;
                }
                for (final Language language : languagemetadatasection.zerodayisaminecraftcheat()) {
                    if (!this.zues.containsKey(language.zerodayisaminecraftcheat())) {
                        this.zues.put(language.zerodayisaminecraftcheat(), language);
                    }
                }
            }
            catch (RuntimeException runtimeexception) {
                LanguageManager.zeroday.warn("Unable to parse metadata section of resourcepack: " + iresourcepack.zeroday(), (Throwable)runtimeexception);
            }
            catch (IOException ioexception) {
                LanguageManager.zeroday.warn("Unable to parse metadata section of resourcepack: " + iresourcepack.zeroday(), (Throwable)ioexception);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        final List<String> list = (List<String>)Lists.newArrayList((Object[])new String[] { "en_US" });
        if (!"en_US".equals(this.pandora)) {
            list.add(this.pandora);
        }
        LanguageManager.zerodayisaminecraftcheat.zerodayisaminecraftcheat(resourceManager, list);
        StringTranslate.zerodayisaminecraftcheat(LanguageManager.zerodayisaminecraftcheat.zerodayisaminecraftcheat);
    }
    
    public boolean zerodayisaminecraftcheat() {
        return LanguageManager.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
    }
    
    public boolean zeroday() {
        return this.sigma() != null && this.sigma().zeroday();
    }
    
    public void zerodayisaminecraftcheat(final Language currentLanguageIn) {
        this.pandora = currentLanguageIn.zerodayisaminecraftcheat();
    }
    
    public Language sigma() {
        return this.zues.containsKey(this.pandora) ? this.zues.get(this.pandora) : this.zues.get("en_US");
    }
    
    public SortedSet<Language> pandora() {
        return (SortedSet<Language>)Sets.newTreeSet((Iterable)this.zues.values());
    }
}

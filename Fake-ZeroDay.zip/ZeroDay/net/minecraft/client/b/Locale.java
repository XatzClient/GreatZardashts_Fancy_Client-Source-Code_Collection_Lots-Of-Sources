// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import java.util.IllegalFormatException;
import com.google.common.collect.Iterables;
import org.apache.commons.io.Charsets;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import java.util.Iterator;
import java.io.IOException;
import net.minecraft.o.ResourceLocation;
import java.util.List;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.regex.Pattern;
import com.google.common.base.Splitter;

public class Locale
{
    private static final Splitter zeroday;
    private static final Pattern sigma;
    Map<String, String> zerodayisaminecraftcheat;
    private boolean pandora;
    
    static {
        zeroday = Splitter.on('=').limit(2);
        sigma = Pattern.compile("%(\\d+\\$)?[\\d\\.]*[df]");
    }
    
    public Locale() {
        this.zerodayisaminecraftcheat = (Map<String, String>)Maps.newHashMap();
    }
    
    public synchronized void zerodayisaminecraftcheat(final IResourceManager resourceManager, final List<String> p_135022_2_) {
        this.zerodayisaminecraftcheat.clear();
        for (final String s : p_135022_2_) {
            final String s2 = String.format("lang/%s.lang", s);
            for (final String s3 : resourceManager.zerodayisaminecraftcheat()) {
                try {
                    this.zerodayisaminecraftcheat(resourceManager.zeroday(new ResourceLocation(s3, s2)));
                }
                catch (IOException ex) {}
            }
        }
        this.zeroday();
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    private void zeroday() {
        this.pandora = false;
        int i = 0;
        int j = 0;
        for (final String s : this.zerodayisaminecraftcheat.values()) {
            final int k = s.length();
            j += k;
            for (int l = 0; l < k; ++l) {
                if (s.charAt(l) >= '\u0100') {
                    ++i;
                }
            }
        }
        final float f = i / (float)j;
        this.pandora = (f > 0.1);
    }
    
    private void zerodayisaminecraftcheat(final List<IResource> p_135028_1_) throws IOException {
        for (final IResource iresource : p_135028_1_) {
            final InputStream inputstream = iresource.zeroday();
            try {
                this.zerodayisaminecraftcheat(inputstream);
            }
            finally {
                IOUtils.closeQuietly(inputstream);
            }
            IOUtils.closeQuietly(inputstream);
        }
    }
    
    private void zerodayisaminecraftcheat(final InputStream p_135021_1_) throws IOException {
        for (final String s : IOUtils.readLines(p_135021_1_, Charsets.UTF_8)) {
            if (!s.isEmpty() && s.charAt(0) != '#') {
                final String[] astring = (String[])Iterables.toArray(Locale.zeroday.split((CharSequence)s), (Class)String.class);
                if (astring == null || astring.length != 2) {
                    continue;
                }
                final String s2 = astring[0];
                final String s3 = Locale.sigma.matcher(astring[1]).replaceAll("%$1s");
                this.zerodayisaminecraftcheat.put(s2, s3);
            }
        }
    }
    
    private String zerodayisaminecraftcheat(final String p_135026_1_) {
        final String s = this.zerodayisaminecraftcheat.get(p_135026_1_);
        return (s == null) ? p_135026_1_ : s;
    }
    
    public String zerodayisaminecraftcheat(final String translateKey, final Object[] parameters) {
        final String s = this.zerodayisaminecraftcheat(translateKey);
        try {
            return String.format(s, parameters);
        }
        catch (IllegalFormatException var5) {
            return "Format error: " + s;
        }
    }
}

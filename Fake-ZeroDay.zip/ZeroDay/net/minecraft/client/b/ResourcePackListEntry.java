// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import net.minecraft.client.sigma.GuiYesNo;
import net.minecraft.client.sigma.GuiScreen;
import net.minecraft.client.sigma.GuiYesNoCallback;
import java.util.List;
import net.minecraft.client.sigma.Gui;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.client.sigma.GuiScreenResourcePacks;
import net.minecraft.client.Minecraft;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.sigma.GuiListExtended;

public abstract class ResourcePackListEntry implements GuiListExtended.zerodayisaminecraftcheat
{
    private static final ResourceLocation sigma;
    private static final IChatComponent pandora;
    private static final IChatComponent zues;
    private static final IChatComponent flux;
    protected final Minecraft zerodayisaminecraftcheat;
    protected final GuiScreenResourcePacks zeroday;
    
    static {
        sigma = new ResourceLocation("textures/gui/resource_packs.png");
        pandora = new ChatComponentTranslation("resourcePack.incompatible", new Object[0]);
        zues = new ChatComponentTranslation("resourcePack.incompatible.old", new Object[0]);
        flux = new ChatComponentTranslation("resourcePack.incompatible.new", new Object[0]);
    }
    
    public ResourcePackListEntry(final GuiScreenResourcePacks resourcePacksGUIIn) {
        this.zeroday = resourcePacksGUIIn;
        this.zerodayisaminecraftcheat = Minecraft.s();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int slotIndex, final int x, final int y, final int listWidth, final int slotHeight, final int mouseX, final int mouseY, final boolean isSelected) {
        final int i = this.zerodayisaminecraftcheat();
        if (i != 1) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            Gui.zerodayisaminecraftcheat(x - 1, y - 1, x + listWidth - 9, y + slotHeight + 1, -8978432);
        }
        this.pandora();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        Gui.zerodayisaminecraftcheat(x, y, 0.0f, 0.0f, 32, 32, 32.0f, 32.0f);
        String s = this.sigma();
        String s2 = this.zeroday();
        if ((this.zerodayisaminecraftcheat.r.s || isSelected) && this.zues()) {
            this.zerodayisaminecraftcheat.I().zerodayisaminecraftcheat(ResourcePackListEntry.sigma);
            Gui.zerodayisaminecraftcheat(x, y, x + 32, y + 32, -1601138544);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            final int j = mouseX - x;
            final int k = mouseY - y;
            if (i < 1) {
                s = ResourcePackListEntry.pandora.a();
                s2 = ResourcePackListEntry.zues.a();
            }
            else if (i > 1) {
                s = ResourcePackListEntry.pandora.a();
                s2 = ResourcePackListEntry.flux.a();
            }
            if (this.flux()) {
                if (j < 32) {
                    Gui.zerodayisaminecraftcheat(x, y, 0.0f, 32.0f, 32, 32, 256.0f, 256.0f);
                }
                else {
                    Gui.zerodayisaminecraftcheat(x, y, 0.0f, 0.0f, 32, 32, 256.0f, 256.0f);
                }
            }
            else {
                if (this.vape()) {
                    if (j < 16) {
                        Gui.zerodayisaminecraftcheat(x, y, 32.0f, 32.0f, 32, 32, 256.0f, 256.0f);
                    }
                    else {
                        Gui.zerodayisaminecraftcheat(x, y, 32.0f, 0.0f, 32, 32, 256.0f, 256.0f);
                    }
                }
                if (this.momgetthecamera()) {
                    if (j < 32 && j > 16 && k < 16) {
                        Gui.zerodayisaminecraftcheat(x, y, 96.0f, 32.0f, 32, 32, 256.0f, 256.0f);
                    }
                    else {
                        Gui.zerodayisaminecraftcheat(x, y, 96.0f, 0.0f, 32, 32, 256.0f, 256.0f);
                    }
                }
                if (this.a()) {
                    if (j < 32 && j > 16 && k > 16) {
                        Gui.zerodayisaminecraftcheat(x, y, 64.0f, 32.0f, 32, 32, 256.0f, 256.0f);
                    }
                    else {
                        Gui.zerodayisaminecraftcheat(x, y, 64.0f, 0.0f, 32, 32, 256.0f, 256.0f);
                    }
                }
            }
        }
        final int i2 = this.zerodayisaminecraftcheat.i.zerodayisaminecraftcheat(s);
        if (i2 > 157) {
            s = String.valueOf(this.zerodayisaminecraftcheat.i.zerodayisaminecraftcheat(s, 157 - this.zerodayisaminecraftcheat.i.zerodayisaminecraftcheat("..."))) + "...";
        }
        this.zerodayisaminecraftcheat.i.zerodayisaminecraftcheat(s, (float)(x + 32 + 2), (float)(y + 1), 16777215);
        final List<String> list = (List<String>)this.zerodayisaminecraftcheat.i.sigma(s2, 157);
        for (int l = 0; l < 2 && l < list.size(); ++l) {
            this.zerodayisaminecraftcheat.i.zerodayisaminecraftcheat(list.get(l), (float)(x + 32 + 2), (float)(y + 12 + 10 * l), 8421504);
        }
    }
    
    protected abstract int zerodayisaminecraftcheat();
    
    protected abstract String zeroday();
    
    protected abstract String sigma();
    
    protected abstract void pandora();
    
    protected boolean zues() {
        return true;
    }
    
    protected boolean flux() {
        return !this.zeroday.zerodayisaminecraftcheat(this);
    }
    
    protected boolean vape() {
        return this.zeroday.zerodayisaminecraftcheat(this);
    }
    
    protected boolean momgetthecamera() {
        final List<ResourcePackListEntry> list = this.zeroday.zeroday(this);
        final int i = list.indexOf(this);
        return i > 0 && list.get(i - 1).zues();
    }
    
    protected boolean a() {
        final List<ResourcePackListEntry> list = this.zeroday.zeroday(this);
        final int i = list.indexOf(this);
        return i >= 0 && i < list.size() - 1 && list.get(i + 1).zues();
    }
    
    @Override
    public boolean zerodayisaminecraftcheat(final int slotIndex, final int p_148278_2_, final int p_148278_3_, final int p_148278_4_, final int p_148278_5_, final int p_148278_6_) {
        if (this.zues() && p_148278_5_ <= 32) {
            if (this.flux()) {
                this.zeroday.momgetthecamera();
                final int j = this.zerodayisaminecraftcheat();
                if (j != 1) {
                    final String s1 = I18n.zerodayisaminecraftcheat("resourcePack.incompatible.confirm.title", new Object[0]);
                    final String s2 = I18n.zerodayisaminecraftcheat("resourcePack.incompatible.confirm." + ((j > 1) ? "new" : "old"), new Object[0]);
                    this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(new GuiYesNo(new GuiYesNoCallback() {
                        @Override
                        public void zerodayisaminecraftcheat(final boolean result, final int id) {
                            final List<ResourcePackListEntry> list2 = ResourcePackListEntry.this.zeroday.zeroday(ResourcePackListEntry.this);
                            ResourcePackListEntry.this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(ResourcePackListEntry.this.zeroday);
                            if (result) {
                                list2.remove(ResourcePackListEntry.this);
                                ResourcePackListEntry.this.zeroday.vape().add(0, ResourcePackListEntry.this);
                            }
                        }
                    }, s1, s2, 0));
                }
                else {
                    this.zeroday.zeroday(this).remove(this);
                    this.zeroday.vape().add(0, this);
                }
                return true;
            }
            if (p_148278_5_ < 16 && this.vape()) {
                this.zeroday.zeroday(this).remove(this);
                this.zeroday.flux().add(0, this);
                this.zeroday.momgetthecamera();
                return true;
            }
            if (p_148278_5_ > 16 && p_148278_6_ < 16 && this.momgetthecamera()) {
                final List<ResourcePackListEntry> list1 = this.zeroday.zeroday(this);
                final int k = list1.indexOf(this);
                list1.remove(this);
                list1.add(k - 1, this);
                this.zeroday.momgetthecamera();
                return true;
            }
            if (p_148278_5_ > 16 && p_148278_6_ > 16 && this.a()) {
                final List<ResourcePackListEntry> list2 = this.zeroday.zeroday(this);
                final int i = list2.indexOf(this);
                list2.remove(this);
                list2.add(i + 1, this);
                this.zeroday.momgetthecamera();
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int p_178011_1_, final int p_178011_2_, final int p_178011_3_) {
    }
    
    @Override
    public void zeroday(final int slotIndex, final int x, final int y, final int mouseEvent, final int relativeX, final int relativeY) {
    }
}

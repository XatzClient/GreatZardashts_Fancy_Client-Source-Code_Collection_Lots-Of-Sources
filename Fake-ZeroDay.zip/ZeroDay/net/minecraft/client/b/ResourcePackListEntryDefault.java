// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import net.minecraft.o.EnumChatFormatting;
import com.google.gson.JsonParseException;
import net.minecraft.client.b.zerodayisaminecraftcheat.PackMetadataSection;
import java.io.IOException;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.client.a.zues.DynamicTexture;
import net.minecraft.client.sigma.GuiScreenResourcePacks;
import org.apache.logging.log4j.LogManager;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;

public class ResourcePackListEntryDefault extends ResourcePackListEntry
{
    private static final Logger sigma;
    private final IResourcePack pandora;
    private final ResourceLocation zues;
    
    static {
        sigma = LogManager.getLogger();
    }
    
    public ResourcePackListEntryDefault(final GuiScreenResourcePacks resourcePacksGUIIn) {
        super(resourcePacksGUIIn);
        this.pandora = this.zerodayisaminecraftcheat.K().zerodayisaminecraftcheat;
        DynamicTexture dynamictexture;
        try {
            dynamictexture = new DynamicTexture(this.pandora.zerodayisaminecraftcheat());
        }
        catch (IOException var4) {
            dynamictexture = TextureUtil.zerodayisaminecraftcheat;
        }
        this.zues = this.zerodayisaminecraftcheat.I().zerodayisaminecraftcheat("texturepackicon", dynamictexture);
    }
    
    @Override
    protected int zerodayisaminecraftcheat() {
        return 1;
    }
    
    @Override
    protected String zeroday() {
        try {
            final PackMetadataSection packmetadatasection = this.pandora.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.K().zeroday, "pack");
            if (packmetadatasection != null) {
                return packmetadatasection.zerodayisaminecraftcheat().a();
            }
        }
        catch (JsonParseException jsonparseexception) {
            ResourcePackListEntryDefault.sigma.error("Couldn't load metadata info", (Throwable)jsonparseexception);
        }
        catch (IOException ioexception) {
            ResourcePackListEntryDefault.sigma.error("Couldn't load metadata info", (Throwable)ioexception);
        }
        return EnumChatFormatting.e + "Missing " + "pack.mcmeta" + " :(";
    }
    
    @Override
    protected boolean flux() {
        return false;
    }
    
    @Override
    protected boolean vape() {
        return false;
    }
    
    @Override
    protected boolean momgetthecamera() {
        return false;
    }
    
    @Override
    protected boolean a() {
        return false;
    }
    
    @Override
    protected String sigma() {
        return "Default";
    }
    
    @Override
    protected void pandora() {
        this.zerodayisaminecraftcheat.I().zerodayisaminecraftcheat(this.zues);
    }
    
    @Override
    protected boolean zues() {
        return false;
    }
}

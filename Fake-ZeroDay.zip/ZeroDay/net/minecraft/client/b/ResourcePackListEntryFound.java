// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import net.minecraft.client.sigma.GuiScreenResourcePacks;

public class ResourcePackListEntryFound extends ResourcePackListEntry
{
    private final ResourcePackRepository.zerodayisaminecraftcheat sigma;
    
    public ResourcePackListEntryFound(final GuiScreenResourcePacks resourcePacksGUIIn, final ResourcePackRepository.zerodayisaminecraftcheat p_i45053_2_) {
        super(resourcePacksGUIIn);
        this.sigma = p_i45053_2_;
    }
    
    @Override
    protected void pandora() {
        this.sigma.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.I());
    }
    
    @Override
    protected int zerodayisaminecraftcheat() {
        return this.sigma.momgetthecamera();
    }
    
    @Override
    protected String zeroday() {
        return this.sigma.vape();
    }
    
    @Override
    protected String sigma() {
        return this.sigma.flux();
    }
    
    public ResourcePackRepository.zerodayisaminecraftcheat b() {
        return this.sigma;
    }
}

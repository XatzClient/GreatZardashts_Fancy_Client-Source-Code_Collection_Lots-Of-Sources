// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import net.minecraft.o.EnumChatFormatting;
import org.apache.commons.io.IOUtils;
import java.io.Closeable;
import net.minecraft.client.a.zues.DynamicTexture;
import net.minecraft.client.a.zues.TextureManager;
import net.minecraft.o.ResourceLocation;
import java.awt.image.BufferedImage;
import net.minecraft.client.b.zerodayisaminecraftcheat.PackMetadataSection;
import java.util.Comparator;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import java.util.Map;
import com.google.common.util.concurrent.FutureCallback;
import net.minecraft.o.IProgressUpdate;
import net.minecraft.o.HttpUtil;
import com.google.common.util.concurrent.SettableFuture;
import java.util.concurrent.Future;
import com.google.common.util.concurrent.Futures;
import net.minecraft.client.sigma.GuiScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.sigma.GuiScreenWorking;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import com.google.common.io.Files;
import com.google.common.hash.Hashing;
import com.google.common.collect.ImmutableList;
import java.util.Collection;
import java.util.Collections;
import java.util.Arrays;
import java.util.Iterator;
import com.google.common.collect.Lists;
import net.minecraft.client.c.GameSettings;
import org.apache.logging.log4j.LogManager;
import java.util.List;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.concurrent.locks.ReentrantLock;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import java.io.File;
import java.io.FileFilter;
import org.apache.logging.log4j.Logger;

public class ResourcePackRepository
{
    private static final Logger sigma;
    private static final FileFilter pandora;
    private final File zues;
    public final IResourcePack zerodayisaminecraftcheat;
    private final File flux;
    public final IMetadataSerializer zeroday;
    private IResourcePack vape;
    private final ReentrantLock momgetthecamera;
    private ListenableFuture<Object> a;
    private List<zerodayisaminecraftcheat> b;
    private List<zerodayisaminecraftcheat> c;
    
    static {
        sigma = LogManager.getLogger();
        pandora = new FileFilter() {
            @Override
            public boolean accept(final File p_accept_1_) {
                final boolean flag = p_accept_1_.isFile() && p_accept_1_.getName().endsWith(".zip");
                final boolean flag2 = p_accept_1_.isDirectory() && new File(p_accept_1_, "pack.mcmeta").isFile();
                final boolean flag3 = p_accept_1_.isDirectory() && p_accept_1_.getName().startsWith("dir_");
                return flag || flag2 || flag3;
            }
        };
    }
    
    public ResourcePackRepository(final File dirResourcepacksIn, final File dirServerResourcepacksIn, final IResourcePack rprDefaultResourcePackIn, final IMetadataSerializer rprMetadataSerializerIn, final GameSettings settings) {
        this.momgetthecamera = new ReentrantLock();
        this.b = (List<zerodayisaminecraftcheat>)Lists.newArrayList();
        this.c = (List<zerodayisaminecraftcheat>)Lists.newArrayList();
        this.zues = dirResourcepacksIn;
        this.flux = dirServerResourcepacksIn;
        this.zerodayisaminecraftcheat = rprDefaultResourcePackIn;
        this.zeroday = rprMetadataSerializerIn;
        this.vape();
        this.zerodayisaminecraftcheat();
        final Iterator<String> iterator = settings.c.iterator();
        while (iterator.hasNext()) {
            final String s = iterator.next();
            for (final zerodayisaminecraftcheat resourcepackrepository$entry : this.b) {
                if (resourcepackrepository$entry.flux().equals(s)) {
                    if (resourcepackrepository$entry.momgetthecamera() == 1 || settings.d.contains(resourcepackrepository$entry.flux())) {
                        this.c.add(resourcepackrepository$entry);
                        break;
                    }
                    iterator.remove();
                    ResourcePackRepository.sigma.warn("Removed selected resource pack {} because it's no longer compatible", new Object[] { resourcepackrepository$entry.flux() });
                }
            }
        }
    }
    
    private void vape() {
        if (this.zues.exists()) {
            if (!this.zues.isDirectory() && (!this.zues.delete() || !this.zues.mkdirs())) {
                ResourcePackRepository.sigma.warn("Unable to recreate resourcepack folder, it exists but is not a directory: " + this.zues);
            }
        }
        else if (!this.zues.mkdirs()) {
            ResourcePackRepository.sigma.warn("Unable to create resourcepack folder: " + this.zues);
        }
    }
    
    private List<File> momgetthecamera() {
        return this.zues.isDirectory() ? Arrays.asList(this.zues.listFiles(ResourcePackRepository.pandora)) : Collections.emptyList();
    }
    
    public void zerodayisaminecraftcheat() {
        final List<zerodayisaminecraftcheat> list = (List<zerodayisaminecraftcheat>)Lists.newArrayList();
        this.zerodayisaminecraftcheat(list, this.momgetthecamera(), "");
        this.b.removeAll(list);
        for (final zerodayisaminecraftcheat resourcepackrepository$entry : this.b) {
            resourcepackrepository$entry.pandora();
        }
        this.b = list;
    }
    
    private void zerodayisaminecraftcheat(final List<zerodayisaminecraftcheat> p_readAllAndFill_1_, final List<File> p_readAllAndFill_2_, final String p_readAllAndFill_3_) {
        for (final File file1 : p_readAllAndFill_2_) {
            if (file1.isDirectory() && file1.getName().startsWith("dir_") && p_readAllAndFill_3_.isEmpty()) {
                final File[] afile = file1.listFiles();
                if (afile != null && afile.length != 0) {
                    this.zerodayisaminecraftcheat(p_readAllAndFill_1_, Arrays.asList(afile), file1.getName());
                }
            }
            if (!file1.isDirectory() || !file1.getName().startsWith("dir_")) {
                final zerodayisaminecraftcheat resourcepackrepository$entry = new zerodayisaminecraftcheat(file1, (zerodayisaminecraftcheat)null);
                if (!this.b.contains(resourcepackrepository$entry)) {
                    try {
                        resourcepackrepository$entry.sigma();
                        p_readAllAndFill_1_.add(resourcepackrepository$entry);
                    }
                    catch (Exception var8) {
                        p_readAllAndFill_1_.remove(resourcepackrepository$entry);
                    }
                }
                else {
                    final int i = this.b.indexOf(resourcepackrepository$entry);
                    if (i > -1 && i < this.b.size()) {
                        p_readAllAndFill_1_.add(this.b.get(i));
                    }
                }
                resourcepackrepository$entry.zerodayisaminecraftcheat(p_readAllAndFill_3_.replaceFirst("dir_", ""));
            }
        }
    }
    
    public List<zerodayisaminecraftcheat> zeroday() {
        return (List<zerodayisaminecraftcheat>)ImmutableList.copyOf((Collection)this.b);
    }
    
    public List<zerodayisaminecraftcheat> sigma() {
        return (List<zerodayisaminecraftcheat>)ImmutableList.copyOf((Collection)this.c);
    }
    
    public void zerodayisaminecraftcheat(final List<zerodayisaminecraftcheat> p_148527_1_) {
        this.c.clear();
        this.c.addAll(p_148527_1_);
    }
    
    public File pandora() {
        return this.zues;
    }
    
    public ListenableFuture<Object> zerodayisaminecraftcheat(final String url, final String hash) {
        String s;
        if (hash.matches("^[a-f0-9]{40}$")) {
            s = hash;
        }
        else {
            s = "legacy";
        }
        final File file1 = new File(this.flux, s);
        this.momgetthecamera.lock();
        try {
            this.flux();
            if (file1.exists() && hash.length() == 40) {
                try {
                    final String s2 = Hashing.sha1().hashBytes(Files.toByteArray(file1)).toString();
                    if (s2.equals(hash)) {
                        final ListenableFuture listenablefuture3;
                        final ListenableFuture listenablefuture2 = listenablefuture3 = this.zerodayisaminecraftcheat(file1);
                        return (ListenableFuture<Object>)listenablefuture3;
                    }
                    ResourcePackRepository.sigma.warn("File " + file1 + " had wrong hash (expected " + hash + ", found " + s2 + "). Deleting it.");
                    FileUtils.deleteQuietly(file1);
                }
                catch (IOException ioexception) {
                    ResourcePackRepository.sigma.warn("File " + file1 + " couldn't be hashed. Deleting it.", (Throwable)ioexception);
                    FileUtils.deleteQuietly(file1);
                }
            }
            this.a();
            final GuiScreenWorking guiscreenworking = new GuiScreenWorking();
            final Map<String, String> map = Minecraft.ad();
            final Minecraft minecraft = Minecraft.s();
            Futures.getUnchecked((Future)minecraft.zerodayisaminecraftcheat(new Runnable() {
                @Override
                public void run() {
                    minecraft.zerodayisaminecraftcheat(guiscreenworking);
                }
            }));
            final SettableFuture<Object> settablefuture = (SettableFuture<Object>)SettableFuture.create();
            Futures.addCallback((ListenableFuture)(this.a = HttpUtil.zerodayisaminecraftcheat(file1, url, map, 52428800, guiscreenworking, minecraft.H())), (FutureCallback)new FutureCallback<Object>() {
                public void onSuccess(final Object p_onSuccess_1_) {
                    ResourcePackRepository.this.zerodayisaminecraftcheat(file1);
                    settablefuture.set((Object)null);
                }
                
                public void onFailure(final Throwable p_onFailure_1_) {
                    settablefuture.setException(p_onFailure_1_);
                }
            });
            final ListenableFuture listenablefuture5;
            final ListenableFuture listenablefuture4 = listenablefuture5 = this.a;
            return (ListenableFuture<Object>)listenablefuture5;
        }
        finally {
            this.momgetthecamera.unlock();
        }
    }
    
    private void a() {
        final List<File> list = (List<File>)Lists.newArrayList((Iterable)FileUtils.listFiles(this.flux, TrueFileFilter.TRUE, (IOFileFilter)null));
        Collections.sort(list, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
        int i = 0;
        for (final File file1 : list) {
            if (i++ >= 10) {
                ResourcePackRepository.sigma.info("Deleting old server resource pack " + file1.getName());
                FileUtils.deleteQuietly(file1);
            }
        }
    }
    
    public ListenableFuture<Object> zerodayisaminecraftcheat(final File p_177319_1_) {
        this.vape = new FileResourcePack(p_177319_1_);
        return Minecraft.s().t();
    }
    
    public IResourcePack zues() {
        return this.vape;
    }
    
    public void flux() {
        this.momgetthecamera.lock();
        try {
            if (this.a != null) {
                this.a.cancel(true);
            }
            this.a = null;
            if (this.vape != null) {
                this.vape = null;
                Minecraft.s().t();
            }
        }
        finally {
            this.momgetthecamera.unlock();
        }
        this.momgetthecamera.unlock();
    }
    
    public class zerodayisaminecraftcheat
    {
        private final File zeroday;
        private IResourcePack sigma;
        private PackMetadataSection pandora;
        private BufferedImage zues;
        private ResourceLocation flux;
        private String vape;
        
        private zerodayisaminecraftcheat(final File resourcePackFileIn) {
            this.vape = "";
            this.zeroday = resourcePackFileIn;
        }
        
        public void zerodayisaminecraftcheat(final String p_setDirPath_1_) {
            this.vape = p_setDirPath_1_;
        }
        
        public String zerodayisaminecraftcheat() {
            return this.vape;
        }
        
        public File zeroday() {
            return this.zeroday;
        }
        
        public void sigma() throws IOException {
            this.sigma = (this.zeroday.isDirectory() ? new FolderResourcePack(this.zeroday) : new FileResourcePack(this.zeroday));
            this.pandora = this.sigma.zerodayisaminecraftcheat(ResourcePackRepository.this.zeroday, "pack");
            try {
                this.zues = this.sigma.zerodayisaminecraftcheat();
            }
            catch (IOException ex) {}
            if (this.zues == null) {
                this.zues = ResourcePackRepository.this.zerodayisaminecraftcheat.zerodayisaminecraftcheat();
            }
            this.pandora();
        }
        
        public void zerodayisaminecraftcheat(final TextureManager textureManagerIn) {
            if (this.flux == null) {
                this.flux = textureManagerIn.zerodayisaminecraftcheat("texturepackicon", new DynamicTexture(this.zues));
            }
            textureManagerIn.zerodayisaminecraftcheat(this.flux);
        }
        
        public void pandora() {
            if (this.sigma instanceof Closeable) {
                IOUtils.closeQuietly((Closeable)this.sigma);
            }
        }
        
        public IResourcePack zues() {
            return this.sigma;
        }
        
        public String flux() {
            return this.sigma.zeroday();
        }
        
        public String vape() {
            return (this.pandora == null) ? (EnumChatFormatting.e + "Invalid pack.mcmeta (or missing 'pack' section)") : this.pandora.zerodayisaminecraftcheat().a();
        }
        
        public int momgetthecamera() {
            return this.pandora.zeroday();
        }
        
        @Override
        public boolean equals(final Object p_equals_1_) {
            return this == p_equals_1_ || (p_equals_1_ instanceof zerodayisaminecraftcheat && this.toString().equals(p_equals_1_.toString()));
        }
        
        @Override
        public int hashCode() {
            return this.toString().hashCode();
        }
        
        @Override
        public String toString() {
            return String.format("%s:%s:%d", this.zeroday.getName(), this.zeroday.isDirectory() ? "folder" : "zip", this.zeroday.lastModified());
        }
    }
}

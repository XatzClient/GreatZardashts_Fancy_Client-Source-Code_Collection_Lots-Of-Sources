// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import com.google.common.collect.Iterables;
import com.google.common.base.Function;
import java.io.IOException;
import java.io.FileNotFoundException;
import net.minecraft.o.ResourceLocation;
import java.util.Iterator;
import com.google.common.collect.Sets;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import java.util.Set;
import java.util.List;
import java.util.Map;
import com.google.common.base.Joiner;
import org.apache.logging.log4j.Logger;

public class SimpleReloadableResourceManager implements IReloadableResourceManager
{
    private static final Logger zerodayisaminecraftcheat;
    private static final Joiner zeroday;
    private final Map<String, FallbackResourceManager> sigma;
    private final List<IResourceManagerReloadListener> pandora;
    private final Set<String> zues;
    private final IMetadataSerializer flux;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
        zeroday = Joiner.on(", ");
    }
    
    public SimpleReloadableResourceManager(final IMetadataSerializer rmMetadataSerializerIn) {
        this.sigma = (Map<String, FallbackResourceManager>)Maps.newHashMap();
        this.pandora = (List<IResourceManagerReloadListener>)Lists.newArrayList();
        this.zues = (Set<String>)Sets.newLinkedHashSet();
        this.flux = rmMetadataSerializerIn;
    }
    
    public void zerodayisaminecraftcheat(final IResourcePack resourcePack) {
        for (final String s : resourcePack.sigma()) {
            this.zues.add(s);
            FallbackResourceManager fallbackresourcemanager = this.sigma.get(s);
            if (fallbackresourcemanager == null) {
                fallbackresourcemanager = new FallbackResourceManager(this.flux);
                this.sigma.put(s, fallbackresourcemanager);
            }
            fallbackresourcemanager.zerodayisaminecraftcheat(resourcePack);
        }
    }
    
    @Override
    public Set<String> zerodayisaminecraftcheat() {
        return this.zues;
    }
    
    @Override
    public IResource zerodayisaminecraftcheat(final ResourceLocation location) throws IOException {
        final IResourceManager iresourcemanager = this.sigma.get(location.sigma());
        if (iresourcemanager != null) {
            return iresourcemanager.zerodayisaminecraftcheat(location);
        }
        throw new FileNotFoundException(location.toString());
    }
    
    @Override
    public List<IResource> zeroday(final ResourceLocation location) throws IOException {
        final IResourceManager iresourcemanager = this.sigma.get(location.sigma());
        if (iresourcemanager != null) {
            return iresourcemanager.zeroday(location);
        }
        throw new FileNotFoundException(location.toString());
    }
    
    private void zeroday() {
        this.sigma.clear();
        this.zues.clear();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final List<IResourcePack> p_110541_1_) {
        this.zeroday();
        SimpleReloadableResourceManager.zerodayisaminecraftcheat.info("Reloading ResourceManager: " + SimpleReloadableResourceManager.zeroday.join(Iterables.transform((Iterable)p_110541_1_, (Function)new Function<IResourcePack, String>() {
            public String zerodayisaminecraftcheat(final IResourcePack p_apply_1_) {
                return p_apply_1_.zeroday();
            }
        })));
        for (final IResourcePack iresourcepack : p_110541_1_) {
            this.zerodayisaminecraftcheat(iresourcepack);
        }
        this.sigma();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManagerReloadListener reloadListener) {
        this.pandora.add(reloadListener);
        reloadListener.zerodayisaminecraftcheat(this);
    }
    
    private void sigma() {
        for (final IResourceManagerReloadListener iresourcemanagerreloadlistener : this.pandora) {
            iresourcemanagerreloadlistener.zerodayisaminecraftcheat(this);
        }
    }
}

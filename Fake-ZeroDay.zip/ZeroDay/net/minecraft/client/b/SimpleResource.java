// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import org.apache.commons.io.IOUtils;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSerializer;
import java.io.InputStream;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.b.zerodayisaminecraftcheat.IMetadataSection;
import java.util.Map;

public class SimpleResource implements IResource
{
    private final Map<String, IMetadataSection> zerodayisaminecraftcheat;
    private final String zeroday;
    private final ResourceLocation sigma;
    private final InputStream pandora;
    private final InputStream zues;
    private final IMetadataSerializer flux;
    private boolean vape;
    private JsonObject momgetthecamera;
    
    public SimpleResource(final String resourcePackNameIn, final ResourceLocation srResourceLocationIn, final InputStream resourceInputStreamIn, final InputStream mcmetaInputStreamIn, final IMetadataSerializer srMetadataSerializerIn) {
        this.zerodayisaminecraftcheat = (Map<String, IMetadataSection>)Maps.newHashMap();
        this.zeroday = resourcePackNameIn;
        this.sigma = srResourceLocationIn;
        this.pandora = resourceInputStreamIn;
        this.zues = mcmetaInputStreamIn;
        this.flux = srMetadataSerializerIn;
    }
    
    @Override
    public ResourceLocation zerodayisaminecraftcheat() {
        return this.sigma;
    }
    
    @Override
    public InputStream zeroday() {
        return this.pandora;
    }
    
    @Override
    public boolean sigma() {
        return this.zues != null;
    }
    
    @Override
    public <T extends IMetadataSection> T zerodayisaminecraftcheat(final String p_110526_1_) {
        if (!this.sigma()) {
            return null;
        }
        if (this.momgetthecamera == null && !this.vape) {
            this.vape = true;
            BufferedReader bufferedreader = null;
            try {
                bufferedreader = new BufferedReader(new InputStreamReader(this.zues));
                this.momgetthecamera = new JsonParser().parse((Reader)bufferedreader).getAsJsonObject();
            }
            finally {
                IOUtils.closeQuietly((Reader)bufferedreader);
            }
            IOUtils.closeQuietly((Reader)bufferedreader);
        }
        T t = (T)this.zerodayisaminecraftcheat.get(p_110526_1_);
        if (t == null) {
            t = this.flux.zerodayisaminecraftcheat(p_110526_1_, this.momgetthecamera);
        }
        return t;
    }
    
    @Override
    public String pandora() {
        return this.zeroday;
    }
    
    @Override
    public boolean equals(final Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        }
        if (!(p_equals_1_ instanceof SimpleResource)) {
            return false;
        }
        final SimpleResource simpleresource = (SimpleResource)p_equals_1_;
        if (this.sigma != null) {
            if (!this.sigma.equals(simpleresource.sigma)) {
                return false;
            }
        }
        else if (simpleresource.sigma != null) {
            return false;
        }
        if (this.zeroday != null) {
            if (!this.zeroday.equals(simpleresource.zeroday)) {
                return false;
            }
        }
        else if (simpleresource.zeroday != null) {
            return false;
        }
        return true;
    }
    
    @Override
    public int hashCode() {
        int i = (this.zeroday != null) ? this.zeroday.hashCode() : 0;
        i = 31 * i + ((this.sigma != null) ? this.sigma.hashCode() : 0);
        return i;
    }
}

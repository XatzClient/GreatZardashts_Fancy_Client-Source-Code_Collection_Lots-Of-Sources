// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b;

import com.google.common.collect.Multimap;
import com.mojang.authlib.minecraft.InsecureTextureException;
import com.google.common.collect.Maps;
import net.minecraft.client.a.zues.ITextureObject;
import net.minecraft.client.a.ThreadDownloadImageData;
import java.awt.image.BufferedImage;
import net.minecraft.client.a.IImageBuffer;
import net.minecraft.client.a.ImageBufferDownload;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.Minecraft;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.CacheBuilder;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import java.util.Map;
import com.mojang.authlib.GameProfile;
import com.google.common.cache.LoadingCache;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import java.io.File;
import net.minecraft.client.a.zues.TextureManager;
import java.util.concurrent.ExecutorService;

public class SkinManager
{
    private static final ExecutorService zerodayisaminecraftcheat;
    private final TextureManager zeroday;
    private final File sigma;
    private final MinecraftSessionService pandora;
    private final LoadingCache<GameProfile, Map<MinecraftProfileTexture.Type, MinecraftProfileTexture>> zues;
    
    static {
        zerodayisaminecraftcheat = new ThreadPoolExecutor(0, 2, 1L, TimeUnit.MINUTES, new LinkedBlockingQueue<Runnable>());
    }
    
    public SkinManager(final TextureManager textureManagerInstance, final File skinCacheDirectory, final MinecraftSessionService sessionService) {
        this.zeroday = textureManagerInstance;
        this.sigma = skinCacheDirectory;
        this.pandora = sessionService;
        this.zues = (LoadingCache<GameProfile, Map<MinecraftProfileTexture.Type, MinecraftProfileTexture>>)CacheBuilder.newBuilder().expireAfterAccess(15L, TimeUnit.SECONDS).build((CacheLoader)new CacheLoader<GameProfile, Map<MinecraftProfileTexture.Type, MinecraftProfileTexture>>() {
            public Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> zerodayisaminecraftcheat(final GameProfile p_load_1_) throws Exception {
                return (Map<MinecraftProfileTexture.Type, MinecraftProfileTexture>)Minecraft.s().T().getTextures(p_load_1_, false);
            }
        });
    }
    
    public ResourceLocation zerodayisaminecraftcheat(final MinecraftProfileTexture profileTexture, final MinecraftProfileTexture.Type p_152792_2_) {
        return this.zerodayisaminecraftcheat(profileTexture, p_152792_2_, null);
    }
    
    public ResourceLocation zerodayisaminecraftcheat(final MinecraftProfileTexture profileTexture, final MinecraftProfileTexture.Type p_152789_2_, final zerodayisaminecraftcheat skinAvailableCallback) {
        final ResourceLocation resourcelocation = new ResourceLocation("skins/" + profileTexture.getHash());
        final ITextureObject itextureobject = this.zeroday.zeroday(resourcelocation);
        if (itextureobject != null) {
            if (skinAvailableCallback != null) {
                skinAvailableCallback.zerodayisaminecraftcheat(p_152789_2_, resourcelocation, profileTexture);
            }
        }
        else {
            final File file1 = new File(this.sigma, (profileTexture.getHash().length() > 2) ? profileTexture.getHash().substring(0, 2) : "xx");
            final File file2 = new File(file1, profileTexture.getHash());
            final IImageBuffer iimagebuffer = (p_152789_2_ == MinecraftProfileTexture.Type.SKIN) ? new ImageBufferDownload() : null;
            final ThreadDownloadImageData threaddownloadimagedata = new ThreadDownloadImageData(file2, profileTexture.getUrl(), DefaultPlayerSkin.zerodayisaminecraftcheat(), new IImageBuffer() {
                @Override
                public BufferedImage zerodayisaminecraftcheat(BufferedImage image) {
                    if (iimagebuffer != null) {
                        image = iimagebuffer.zerodayisaminecraftcheat(image);
                    }
                    return image;
                }
                
                @Override
                public void zerodayisaminecraftcheat() {
                    if (iimagebuffer != null) {
                        iimagebuffer.zerodayisaminecraftcheat();
                    }
                    if (skinAvailableCallback != null) {
                        skinAvailableCallback.zerodayisaminecraftcheat(p_152789_2_, resourcelocation, profileTexture);
                    }
                }
            });
            this.zeroday.zerodayisaminecraftcheat(resourcelocation, threaddownloadimagedata);
        }
        return resourcelocation;
    }
    
    public void zerodayisaminecraftcheat(final GameProfile profile, final zerodayisaminecraftcheat skinAvailableCallback, final boolean requireSecure) {
        SkinManager.zerodayisaminecraftcheat.submit(new Runnable() {
            @Override
            public void run() {
                final Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> map = (Map<MinecraftProfileTexture.Type, MinecraftProfileTexture>)Maps.newHashMap();
                try {
                    map.putAll(SkinManager.this.pandora.getTextures(profile, requireSecure));
                }
                catch (InsecureTextureException ex) {}
                if (map.isEmpty() && profile.getId().equals(Minecraft.s().E().zues().getId())) {
                    profile.getProperties().clear();
                    profile.getProperties().putAll((Multimap)Minecraft.s().G());
                    map.putAll(SkinManager.this.pandora.getTextures(profile, false));
                }
                Minecraft.s().zerodayisaminecraftcheat(new Runnable() {
                    @Override
                    public void run() {
                        if (map.containsKey(MinecraftProfileTexture.Type.SKIN)) {
                            SkinManager.this.zerodayisaminecraftcheat(map.get(MinecraftProfileTexture.Type.SKIN), MinecraftProfileTexture.Type.SKIN, skinAvailableCallback);
                        }
                        if (map.containsKey(MinecraftProfileTexture.Type.CAPE)) {
                            SkinManager.this.zerodayisaminecraftcheat(map.get(MinecraftProfileTexture.Type.CAPE), MinecraftProfileTexture.Type.CAPE, skinAvailableCallback);
                        }
                    }
                });
            }
        });
    }
    
    public Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> zerodayisaminecraftcheat(final GameProfile profile) {
        return (Map<MinecraftProfileTexture.Type, MinecraftProfileTexture>)this.zues.getUnchecked((Object)profile);
    }
    
    public interface zerodayisaminecraftcheat
    {
        void zerodayisaminecraftcheat(final MinecraftProfileTexture.Type p0, final ResourceLocation p1, final MinecraftProfileTexture p2);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zeroday;

import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BakedQuad;
import java.util.List;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;

public class BuiltInModel implements IBakedModel
{
    private ItemCameraTransforms zerodayisaminecraftcheat;
    
    public BuiltInModel(final ItemCameraTransforms p_i46086_1_) {
        this.zerodayisaminecraftcheat = p_i46086_1_;
    }
    
    @Override
    public List<BakedQuad> zerodayisaminecraftcheat(final EnumFacing p_177551_1_) {
        return null;
    }
    
    @Override
    public List<BakedQuad> zerodayisaminecraftcheat() {
        return null;
    }
    
    @Override
    public boolean zeroday() {
        return false;
    }
    
    @Override
    public boolean sigma() {
        return true;
    }
    
    @Override
    public boolean pandora() {
        return true;
    }
    
    @Override
    public TextureAtlasSprite zues() {
        return null;
    }
    
    @Override
    public ItemCameraTransforms flux() {
        return this.zerodayisaminecraftcheat;
    }
}

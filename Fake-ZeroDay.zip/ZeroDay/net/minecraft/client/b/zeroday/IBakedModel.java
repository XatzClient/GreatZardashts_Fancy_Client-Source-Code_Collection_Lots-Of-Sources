// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zeroday;

import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BakedQuad;
import java.util.List;
import net.minecraft.o.EnumFacing;

public interface IBakedModel
{
    List<BakedQuad> zerodayisaminecraftcheat(final EnumFacing p0);
    
    List<BakedQuad> zerodayisaminecraftcheat();
    
    boolean zeroday();
    
    boolean sigma();
    
    boolean pandora();
    
    TextureAtlasSprite zues();
    
    ItemCameraTransforms flux();
}

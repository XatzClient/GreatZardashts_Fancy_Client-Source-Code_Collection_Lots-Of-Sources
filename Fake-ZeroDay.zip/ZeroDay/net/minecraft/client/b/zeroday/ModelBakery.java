// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zeroday;

import net.minecraft.client.a.zues.IIconCreator;
import java.util.Deque;
import com.google.common.collect.Queues;
import net.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.sigma;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BakedQuad;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BlockPartFace;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BlockPart;
import java.util.Comparator;
import java.util.Collections;
import net.minecraft.a.Items;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.a.Blocks;
import java.io.StringReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import java.io.Reader;
import java.io.InputStreamReader;
import com.google.common.base.Charsets;
import net.minecraft.client.b.IResource;
import java.util.Iterator;
import java.util.Collection;
import com.google.common.collect.Lists;
import net.minecraft.o.IRegistry;
import com.google.common.collect.Maps;
import org.apache.logging.log4j.LogManager;
import com.google.common.collect.Sets;
import java.util.List;
import net.minecraft.c.Item;
import net.minecraft.o.RegistrySimple;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemModelGenerator;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.FaceBakery;
import net.minecraft.client.a.BlockModelShapes;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ModelBlockDefinition;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ModelBlock;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.b.IResourceManager;
import com.google.common.base.Joiner;
import java.util.Map;
import org.apache.logging.log4j.Logger;
import net.minecraft.o.ResourceLocation;
import java.util.Set;

public class ModelBakery
{
    private static final Set<ResourceLocation> zeroday;
    private static final Logger sigma;
    protected static final ModelResourceLocation zerodayisaminecraftcheat;
    private static final Map<String, String> pandora;
    private static final Joiner zues;
    private final IResourceManager flux;
    private final Map<ResourceLocation, TextureAtlasSprite> vape;
    private final Map<ResourceLocation, ModelBlock> momgetthecamera;
    private final Map<ModelResourceLocation, ModelBlockDefinition.pandora> a;
    private final TextureMap b;
    private final BlockModelShapes c;
    private final FaceBakery d;
    private final ItemModelGenerator e;
    private RegistrySimple<ModelResourceLocation, IBakedModel> f;
    private static final ModelBlock g;
    private static final ModelBlock h;
    private static final ModelBlock i;
    private static final ModelBlock j;
    private Map<String, ResourceLocation> k;
    private final Map<ResourceLocation, ModelBlockDefinition> l;
    private Map<Item, List<String>> m;
    
    static {
        zeroday = Sets.newHashSet((Object[])new ResourceLocation[] { new ResourceLocation("blocks/water_flow"), new ResourceLocation("blocks/water_still"), new ResourceLocation("blocks/lava_flow"), new ResourceLocation("blocks/lava_still"), new ResourceLocation("blocks/destroy_stage_0"), new ResourceLocation("blocks/destroy_stage_1"), new ResourceLocation("blocks/destroy_stage_2"), new ResourceLocation("blocks/destroy_stage_3"), new ResourceLocation("blocks/destroy_stage_4"), new ResourceLocation("blocks/destroy_stage_5"), new ResourceLocation("blocks/destroy_stage_6"), new ResourceLocation("blocks/destroy_stage_7"), new ResourceLocation("blocks/destroy_stage_8"), new ResourceLocation("blocks/destroy_stage_9"), new ResourceLocation("items/empty_armor_slot_helmet"), new ResourceLocation("items/empty_armor_slot_chestplate"), new ResourceLocation("items/empty_armor_slot_leggings"), new ResourceLocation("items/empty_armor_slot_boots") });
        sigma = LogManager.getLogger();
        zerodayisaminecraftcheat = new ModelResourceLocation("builtin/missing", "missing");
        pandora = Maps.newHashMap();
        zues = Joiner.on(" -> ");
        g = ModelBlock.zerodayisaminecraftcheat("{\"elements\":[{  \"from\": [0, 0, 0],   \"to\": [16, 16, 16],   \"faces\": {       \"down\": {\"uv\": [0, 0, 16, 16], \"texture\":\"\"}   }}]}");
        h = ModelBlock.zerodayisaminecraftcheat("{\"elements\":[{  \"from\": [0, 0, 0],   \"to\": [16, 16, 16],   \"faces\": {       \"down\": {\"uv\": [0, 0, 16, 16], \"texture\":\"\"}   }}]}");
        i = ModelBlock.zerodayisaminecraftcheat("{\"elements\":[{  \"from\": [0, 0, 0],   \"to\": [16, 16, 16],   \"faces\": {       \"down\": {\"uv\": [0, 0, 16, 16], \"texture\":\"\"}   }}]}");
        j = ModelBlock.zerodayisaminecraftcheat("{\"elements\":[{  \"from\": [0, 0, 0],   \"to\": [16, 16, 16],   \"faces\": {       \"down\": {\"uv\": [0, 0, 16, 16], \"texture\":\"\"}   }}]}");
        ModelBakery.pandora.put("missing", "{ \"textures\": {   \"particle\": \"missingno\",   \"missingno\": \"missingno\"}, \"elements\": [ {     \"from\": [ 0, 0, 0 ],     \"to\": [ 16, 16, 16 ],     \"faces\": {         \"down\":  { \"uv\": [ 0, 0, 16, 16 ], \"cullface\": \"down\", \"texture\": \"#missingno\" },         \"up\":    { \"uv\": [ 0, 0, 16, 16 ], \"cullface\": \"up\", \"texture\": \"#missingno\" },         \"north\": { \"uv\": [ 0, 0, 16, 16 ], \"cullface\": \"north\", \"texture\": \"#missingno\" },         \"south\": { \"uv\": [ 0, 0, 16, 16 ], \"cullface\": \"south\", \"texture\": \"#missingno\" },         \"west\":  { \"uv\": [ 0, 0, 16, 16 ], \"cullface\": \"west\", \"texture\": \"#missingno\" },         \"east\":  { \"uv\": [ 0, 0, 16, 16 ], \"cullface\": \"east\", \"texture\": \"#missingno\" }    }}]}");
        ModelBakery.g.zeroday = "generation marker";
        ModelBakery.h.zeroday = "compass generation marker";
        ModelBakery.i.zeroday = "class generation marker";
        ModelBakery.j.zeroday = "block entity marker";
    }
    
    public ModelBakery(final IResourceManager p_i46085_1_, final TextureMap p_i46085_2_, final BlockModelShapes p_i46085_3_) {
        this.vape = (Map<ResourceLocation, TextureAtlasSprite>)Maps.newHashMap();
        this.momgetthecamera = (Map<ResourceLocation, ModelBlock>)Maps.newLinkedHashMap();
        this.a = (Map<ModelResourceLocation, ModelBlockDefinition.pandora>)Maps.newLinkedHashMap();
        this.d = new FaceBakery();
        this.e = new ItemModelGenerator();
        this.f = new RegistrySimple<ModelResourceLocation, IBakedModel>();
        this.k = (Map<String, ResourceLocation>)Maps.newLinkedHashMap();
        this.l = (Map<ResourceLocation, ModelBlockDefinition>)Maps.newHashMap();
        this.m = (Map<Item, List<String>>)Maps.newIdentityHashMap();
        this.flux = p_i46085_1_;
        this.b = p_i46085_2_;
        this.c = p_i46085_3_;
    }
    
    public IRegistry<ModelResourceLocation, IBakedModel> zerodayisaminecraftcheat() {
        this.zeroday();
        this.momgetthecamera();
        this.b();
        this.d();
        this.flux();
        return this.f;
    }
    
    private void zeroday() {
        this.zerodayisaminecraftcheat(this.c.zerodayisaminecraftcheat().zerodayisaminecraftcheat().values());
        this.a.put(ModelBakery.zerodayisaminecraftcheat, new ModelBlockDefinition.pandora(ModelBakery.zerodayisaminecraftcheat.zerodayisaminecraftcheat(), Lists.newArrayList((Object[])new ModelBlockDefinition.sigma[] { new ModelBlockDefinition.sigma(new ResourceLocation(ModelBakery.zerodayisaminecraftcheat.zeroday()), ModelRotation.zerodayisaminecraftcheat, false, 1) })));
        final ResourceLocation resourcelocation = new ResourceLocation("item_frame");
        final ModelBlockDefinition modelblockdefinition = this.zerodayisaminecraftcheat(resourcelocation);
        this.zerodayisaminecraftcheat(modelblockdefinition, new ModelResourceLocation(resourcelocation, "normal"));
        this.zerodayisaminecraftcheat(modelblockdefinition, new ModelResourceLocation(resourcelocation, "map"));
        this.sigma();
        this.pandora();
    }
    
    private void zerodayisaminecraftcheat(final Collection<ModelResourceLocation> p_177591_1_) {
        for (final ModelResourceLocation modelresourcelocation : p_177591_1_) {
            try {
                final ModelBlockDefinition modelblockdefinition = this.zerodayisaminecraftcheat(modelresourcelocation);
                try {
                    this.zerodayisaminecraftcheat(modelblockdefinition, modelresourcelocation);
                }
                catch (Exception var6) {
                    ModelBakery.sigma.warn("Unable to load variant: " + modelresourcelocation.zerodayisaminecraftcheat() + " from " + modelresourcelocation);
                }
            }
            catch (Exception exception) {
                ModelBakery.sigma.warn("Unable to load definition " + modelresourcelocation, (Throwable)exception);
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final ModelBlockDefinition p_177569_1_, final ModelResourceLocation p_177569_2_) {
        this.a.put(p_177569_2_, p_177569_1_.zerodayisaminecraftcheat(p_177569_2_.zerodayisaminecraftcheat()));
    }
    
    private ModelBlockDefinition zerodayisaminecraftcheat(final ResourceLocation p_177586_1_) {
        final ResourceLocation resourcelocation = this.zeroday(p_177586_1_);
        ModelBlockDefinition modelblockdefinition = this.l.get(resourcelocation);
        if (modelblockdefinition == null) {
            final List<ModelBlockDefinition> list = (List<ModelBlockDefinition>)Lists.newArrayList();
            try {
                for (final IResource iresource : this.flux.zeroday(resourcelocation)) {
                    InputStream inputstream = null;
                    try {
                        inputstream = iresource.zeroday();
                        final ModelBlockDefinition modelblockdefinition2 = ModelBlockDefinition.zerodayisaminecraftcheat(new InputStreamReader(inputstream, Charsets.UTF_8));
                        list.add(modelblockdefinition2);
                    }
                    catch (Exception exception) {
                        throw new RuntimeException("Encountered an exception when loading model definition of '" + p_177586_1_ + "' from: '" + iresource.zerodayisaminecraftcheat() + "' in resourcepack: '" + iresource.pandora() + "'", exception);
                    }
                    finally {
                        IOUtils.closeQuietly(inputstream);
                    }
                    IOUtils.closeQuietly(inputstream);
                }
            }
            catch (IOException ioexception) {
                throw new RuntimeException("Encountered an exception when loading model definition of model " + resourcelocation.toString(), ioexception);
            }
            modelblockdefinition = new ModelBlockDefinition(list);
            this.l.put(resourcelocation, modelblockdefinition);
        }
        return modelblockdefinition;
    }
    
    private ResourceLocation zeroday(final ResourceLocation p_177584_1_) {
        return new ResourceLocation(p_177584_1_.sigma(), "blockstates/" + p_177584_1_.zeroday() + ".json");
    }
    
    private void sigma() {
        for (final ModelResourceLocation modelresourcelocation : this.a.keySet()) {
            for (final ModelBlockDefinition.sigma modelblockdefinition$variant : this.a.get(modelresourcelocation).zerodayisaminecraftcheat()) {
                final ResourceLocation resourcelocation = modelblockdefinition$variant.zerodayisaminecraftcheat();
                if (this.momgetthecamera.get(resourcelocation) == null) {
                    try {
                        final ModelBlock modelblock = this.sigma(resourcelocation);
                        this.momgetthecamera.put(resourcelocation, modelblock);
                    }
                    catch (Exception exception) {
                        ModelBakery.sigma.warn("Unable to load block model: '" + resourcelocation + "' for variant: '" + modelresourcelocation + "'", (Throwable)exception);
                    }
                }
            }
        }
    }
    
    private ModelBlock sigma(final ResourceLocation p_177594_1_) throws IOException {
        final String s = p_177594_1_.zeroday();
        if ("builtin/generated".equals(s)) {
            return ModelBakery.g;
        }
        if ("builtin/compass".equals(s)) {
            return ModelBakery.h;
        }
        if ("builtin/clock".equals(s)) {
            return ModelBakery.i;
        }
        if ("builtin/entity".equals(s)) {
            return ModelBakery.j;
        }
        Reader reader;
        if (s.startsWith("builtin/")) {
            final String s2 = s.substring("builtin/".length());
            final String s3 = ModelBakery.pandora.get(s2);
            if (s3 == null) {
                throw new FileNotFoundException(p_177594_1_.toString());
            }
            reader = new StringReader(s3);
        }
        else {
            final IResource iresource = this.flux.zerodayisaminecraftcheat(this.pandora(p_177594_1_));
            reader = new InputStreamReader(iresource.zeroday(), Charsets.UTF_8);
        }
        ModelBlock modelblock2;
        try {
            final ModelBlock modelblock = ModelBlock.zerodayisaminecraftcheat(reader);
            modelblock.zeroday = p_177594_1_.toString();
            modelblock2 = modelblock;
        }
        finally {
            reader.close();
        }
        reader.close();
        return modelblock2;
    }
    
    private ResourceLocation pandora(final ResourceLocation p_177580_1_) {
        return new ResourceLocation(p_177580_1_.sigma(), "models/" + p_177580_1_.zeroday() + ".json");
    }
    
    private void pandora() {
        this.zues();
        for (final Item item : Item.zerodayisaminecraftcheat) {
            for (final String s : this.zerodayisaminecraftcheat(item)) {
                final ResourceLocation resourcelocation = this.zerodayisaminecraftcheat(s);
                this.k.put(s, resourcelocation);
                if (this.momgetthecamera.get(resourcelocation) == null) {
                    try {
                        final ModelBlock modelblock = this.sigma(resourcelocation);
                        this.momgetthecamera.put(resourcelocation, modelblock);
                    }
                    catch (Exception exception) {
                        ModelBakery.sigma.warn("Unable to load item model: '" + resourcelocation + "' for item: '" + Item.zerodayisaminecraftcheat.zeroday(item) + "'", (Throwable)exception);
                    }
                }
            }
        }
    }
    
    private void zues() {
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.zeroday), Lists.newArrayList((Object[])new String[] { "stone", "granite", "granite_smooth", "diorite", "diorite_smooth", "andesite", "andesite_smooth" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.pandora), Lists.newArrayList((Object[])new String[] { "dirt", "coarse_dirt", "podzol" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.flux), Lists.newArrayList((Object[])new String[] { "oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "dark_oak_planks" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.vape), Lists.newArrayList((Object[])new String[] { "oak_sapling", "spruce_sapling", "birch_sapling", "jungle_sapling", "acacia_sapling", "dark_oak_sapling" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.e), Lists.newArrayList((Object[])new String[] { "sand", "red_sand" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.j), Lists.newArrayList((Object[])new String[] { "oak_log", "spruce_log", "birch_log", "jungle_log" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.l), Lists.newArrayList((Object[])new String[] { "oak_leaves", "spruce_leaves", "birch_leaves", "jungle_leaves" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.n), Lists.newArrayList((Object[])new String[] { "sponge", "sponge_wet" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.s), Lists.newArrayList((Object[])new String[] { "sandstone", "chiseled_sandstone", "smooth_sandstone" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cE), Lists.newArrayList((Object[])new String[] { "red_sandstone", "chiseled_red_sandstone", "smooth_red_sandstone" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.z), Lists.newArrayList((Object[])new String[] { "dead_bush", "tall_grass", "fern" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.A), Lists.newArrayList((Object[])new String[] { "dead_bush" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.D), Lists.newArrayList((Object[])new String[] { "black_wool", "red_wool", "green_wool", "brown_wool", "blue_wool", "purple_wool", "cyan_wool", "silver_wool", "gray_wool", "pink_wool", "lime_wool", "yellow_wool", "light_blue_wool", "magenta_wool", "orange_wool", "white_wool" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.F), Lists.newArrayList((Object[])new String[] { "dandelion" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.G), Lists.newArrayList((Object[])new String[] { "poppy", "blue_orchid", "allium", "houstonia", "red_tulip", "orange_tulip", "white_tulip", "pink_tulip", "oxeye_daisy" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.M), Lists.newArrayList((Object[])new String[] { "stone_slab", "sandstone_slab", "cobblestone_slab", "brick_slab", "stone_brick_slab", "nether_brick_slab", "quartz_slab" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cH), Lists.newArrayList((Object[])new String[] { "red_sandstone_slab" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cy), Lists.newArrayList((Object[])new String[] { "black_stained_glass", "red_stained_glass", "green_stained_glass", "brown_stained_glass", "blue_stained_glass", "purple_stained_glass", "cyan_stained_glass", "silver_stained_glass", "gray_stained_glass", "pink_stained_glass", "lime_stained_glass", "yellow_stained_glass", "light_blue_stained_glass", "magenta_stained_glass", "orange_stained_glass", "white_stained_glass" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.aW), Lists.newArrayList((Object[])new String[] { "stone_monster_egg", "cobblestone_monster_egg", "stone_brick_monster_egg", "mossy_brick_monster_egg", "cracked_brick_monster_egg", "chiseled_brick_monster_egg" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.aX), Lists.newArrayList((Object[])new String[] { "stonebrick", "mossy_stonebrick", "cracked_stonebrick", "chiseled_stonebrick" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.bE), Lists.newArrayList((Object[])new String[] { "oak_slab", "spruce_slab", "birch_slab", "jungle_slab", "acacia_slab", "dark_oak_slab" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.bR), Lists.newArrayList((Object[])new String[] { "cobblestone_wall", "mossy_cobblestone_wall" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.bX), Lists.newArrayList((Object[])new String[] { "anvil_intact", "anvil_slightly_damaged", "anvil_very_damaged" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.ci), Lists.newArrayList((Object[])new String[] { "quartz_block", "chiseled_quartz_block", "quartz_column" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cm), Lists.newArrayList((Object[])new String[] { "black_stained_hardened_clay", "red_stained_hardened_clay", "green_stained_hardened_clay", "brown_stained_hardened_clay", "blue_stained_hardened_clay", "purple_stained_hardened_clay", "cyan_stained_hardened_clay", "silver_stained_hardened_clay", "gray_stained_hardened_clay", "pink_stained_hardened_clay", "lime_stained_hardened_clay", "yellow_stained_hardened_clay", "light_blue_stained_hardened_clay", "magenta_stained_hardened_clay", "orange_stained_hardened_clay", "white_stained_hardened_clay" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cz), Lists.newArrayList((Object[])new String[] { "black_stained_glass_pane", "red_stained_glass_pane", "green_stained_glass_pane", "brown_stained_glass_pane", "blue_stained_glass_pane", "purple_stained_glass_pane", "cyan_stained_glass_pane", "silver_stained_glass_pane", "gray_stained_glass_pane", "pink_stained_glass_pane", "lime_stained_glass_pane", "yellow_stained_glass_pane", "light_blue_stained_glass_pane", "magenta_stained_glass_pane", "orange_stained_glass_pane", "white_stained_glass_pane" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.m), Lists.newArrayList((Object[])new String[] { "acacia_leaves", "dark_oak_leaves" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.k), Lists.newArrayList((Object[])new String[] { "acacia_log", "dark_oak_log" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cA), Lists.newArrayList((Object[])new String[] { "prismarine", "prismarine_bricks", "dark_prismarine" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cq), Lists.newArrayList((Object[])new String[] { "black_carpet", "red_carpet", "green_carpet", "brown_carpet", "blue_carpet", "purple_carpet", "cyan_carpet", "silver_carpet", "gray_carpet", "pink_carpet", "lime_carpet", "yellow_carpet", "light_blue_carpet", "magenta_carpet", "orange_carpet", "white_carpet" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.cx), Lists.newArrayList((Object[])new String[] { "sunflower", "syringa", "double_grass", "double_fern", "double_rose", "paeonia" }));
        this.m.put(Items.flux, Lists.newArrayList((Object[])new String[] { "bow", "bow_pulling_0", "bow_pulling_1", "bow_pulling_2" }));
        this.m.put(Items.momgetthecamera, Lists.newArrayList((Object[])new String[] { "coal", "charcoal" }));
        this.m.put(Items.aJ, Lists.newArrayList((Object[])new String[] { "fishing_rod", "fishing_rod_cast" }));
        this.m.put(Items.aM, Lists.newArrayList((Object[])new String[] { "cod", "salmon", "clownfish", "pufferfish" }));
        this.m.put(Items.aN, Lists.newArrayList((Object[])new String[] { "cooked_cod", "cooked_salmon" }));
        this.m.put(Items.aO, Lists.newArrayList((Object[])new String[] { "dye_black", "dye_red", "dye_green", "dye_brown", "dye_blue", "dye_purple", "dye_cyan", "dye_silver", "dye_gray", "dye_pink", "dye_lime", "dye_yellow", "dye_light_blue", "dye_magenta", "dye_orange", "dye_white" }));
        this.m.put(Items.br, Lists.newArrayList((Object[])new String[] { "bottle_drinkable", "bottle_splash" }));
        this.m.put(Items.bP, Lists.newArrayList((Object[])new String[] { "skull_skeleton", "skull_wither", "skull_zombie", "skull_char", "skull_creeper" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.bg), Lists.newArrayList((Object[])new String[] { "oak_fence_gate" }));
        this.m.put(Item.zerodayisaminecraftcheat(Blocks.aG), Lists.newArrayList((Object[])new String[] { "oak_fence" }));
        this.m.put(Items.ai, Lists.newArrayList((Object[])new String[] { "oak_door" }));
    }
    
    private List<String> zerodayisaminecraftcheat(final Item p_177596_1_) {
        List<String> list = this.m.get(p_177596_1_);
        if (list == null) {
            list = Collections.singletonList(Item.zerodayisaminecraftcheat.zeroday(p_177596_1_).toString());
        }
        return list;
    }
    
    private ResourceLocation zerodayisaminecraftcheat(final String p_177583_1_) {
        final ResourceLocation resourcelocation = new ResourceLocation(p_177583_1_);
        return new ResourceLocation(resourcelocation.sigma(), "item/" + resourcelocation.zeroday());
    }
    
    private void flux() {
        for (final ModelResourceLocation modelresourcelocation : this.a.keySet()) {
            final WeightedBakedModel.zerodayisaminecraftcheat weightedbakedmodel$builder = new WeightedBakedModel.zerodayisaminecraftcheat();
            int i = 0;
            for (final ModelBlockDefinition.sigma modelblockdefinition$variant : this.a.get(modelresourcelocation).zerodayisaminecraftcheat()) {
                final ModelBlock modelblock = this.momgetthecamera.get(modelblockdefinition$variant.zerodayisaminecraftcheat());
                if (modelblock != null && modelblock.pandora()) {
                    ++i;
                    weightedbakedmodel$builder.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(modelblock, modelblockdefinition$variant.zeroday(), modelblockdefinition$variant.sigma()), modelblockdefinition$variant.pandora());
                }
                else {
                    ModelBakery.sigma.warn("Missing model for: " + modelresourcelocation);
                }
            }
            if (i == 0) {
                ModelBakery.sigma.warn("No weighted models for: " + modelresourcelocation);
            }
            else if (i == 1) {
                this.f.zerodayisaminecraftcheat(modelresourcelocation, weightedbakedmodel$builder.zeroday());
            }
            else {
                this.f.zerodayisaminecraftcheat(modelresourcelocation, weightedbakedmodel$builder.zerodayisaminecraftcheat());
            }
        }
        for (final Map.Entry<String, ResourceLocation> entry : this.k.entrySet()) {
            final ResourceLocation resourcelocation = entry.getValue();
            final ModelResourceLocation modelresourcelocation2 = new ModelResourceLocation(entry.getKey(), "inventory");
            final ModelBlock modelblock2 = this.momgetthecamera.get(resourcelocation);
            if (modelblock2 != null && modelblock2.pandora()) {
                if (this.sigma(modelblock2)) {
                    this.f.zerodayisaminecraftcheat(modelresourcelocation2, new BuiltInModel(modelblock2.vape()));
                }
                else {
                    this.f.zerodayisaminecraftcheat(modelresourcelocation2, this.zerodayisaminecraftcheat(modelblock2, ModelRotation.zerodayisaminecraftcheat, false));
                }
            }
            else {
                ModelBakery.sigma.warn("Missing model for: " + resourcelocation);
            }
        }
    }
    
    private Set<ResourceLocation> vape() {
        final Set<ResourceLocation> set = (Set<ResourceLocation>)Sets.newHashSet();
        final List<ModelResourceLocation> list = (List<ModelResourceLocation>)Lists.newArrayList((Iterable)this.a.keySet());
        Collections.sort(list, new Comparator<ModelResourceLocation>() {
            public int zerodayisaminecraftcheat(final ModelResourceLocation p_compare_1_, final ModelResourceLocation p_compare_2_) {
                return p_compare_1_.toString().compareTo(p_compare_2_.toString());
            }
        });
        for (final ModelResourceLocation modelresourcelocation : list) {
            final ModelBlockDefinition.pandora modelblockdefinition$variants = this.a.get(modelresourcelocation);
            for (final ModelBlockDefinition.sigma modelblockdefinition$variant : modelblockdefinition$variants.zerodayisaminecraftcheat()) {
                final ModelBlock modelblock = this.momgetthecamera.get(modelblockdefinition$variant.zerodayisaminecraftcheat());
                if (modelblock == null) {
                    ModelBakery.sigma.warn("Missing model for: " + modelresourcelocation);
                }
                else {
                    set.addAll(this.zerodayisaminecraftcheat(modelblock));
                }
            }
        }
        set.addAll(ModelBakery.zeroday);
        return set;
    }
    
    private IBakedModel zerodayisaminecraftcheat(final ModelBlock modelBlockIn, final ModelRotation modelRotationIn, final boolean uvLocked) {
        final TextureAtlasSprite textureatlassprite = this.vape.get(new ResourceLocation(modelBlockIn.sigma("particle")));
        final SimpleBakedModel.zerodayisaminecraftcheat simplebakedmodel$builder = new SimpleBakedModel.zerodayisaminecraftcheat(modelBlockIn).zerodayisaminecraftcheat(textureatlassprite);
        for (final BlockPart blockpart : modelBlockIn.zerodayisaminecraftcheat()) {
            for (final EnumFacing enumfacing : blockpart.sigma.keySet()) {
                final BlockPartFace blockpartface = blockpart.sigma.get(enumfacing);
                final TextureAtlasSprite textureatlassprite2 = this.vape.get(new ResourceLocation(modelBlockIn.sigma(blockpartface.pandora)));
                if (blockpartface.zeroday == null) {
                    simplebakedmodel$builder.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(blockpart, blockpartface, textureatlassprite2, enumfacing, modelRotationIn, uvLocked));
                }
                else {
                    simplebakedmodel$builder.zerodayisaminecraftcheat(modelRotationIn.zerodayisaminecraftcheat(blockpartface.zeroday), this.zerodayisaminecraftcheat(blockpart, blockpartface, textureatlassprite2, enumfacing, modelRotationIn, uvLocked));
                }
            }
        }
        return simplebakedmodel$builder.zerodayisaminecraftcheat();
    }
    
    private BakedQuad zerodayisaminecraftcheat(final BlockPart p_177589_1_, final BlockPartFace p_177589_2_, final TextureAtlasSprite p_177589_3_, final EnumFacing p_177589_4_, final ModelRotation p_177589_5_, final boolean p_177589_6_) {
        return this.d.zerodayisaminecraftcheat(p_177589_1_.zerodayisaminecraftcheat, p_177589_1_.zeroday, p_177589_2_, p_177589_3_, p_177589_4_, p_177589_5_, p_177589_1_.pandora, p_177589_6_, p_177589_1_.zues);
    }
    
    private void momgetthecamera() {
        this.a();
        for (final ModelBlock modelblock : this.momgetthecamera.values()) {
            modelblock.zerodayisaminecraftcheat(this.momgetthecamera);
        }
        ModelBlock.zeroday(this.momgetthecamera);
    }
    
    private void a() {
        final Deque<ResourceLocation> deque = (Deque<ResourceLocation>)Queues.newArrayDeque();
        final Set<ResourceLocation> set = (Set<ResourceLocation>)Sets.newHashSet();
        for (final ResourceLocation resourcelocation : this.momgetthecamera.keySet()) {
            set.add(resourcelocation);
            final ResourceLocation resourcelocation2 = this.momgetthecamera.get(resourcelocation).zues();
            if (resourcelocation2 != null) {
                deque.add(resourcelocation2);
            }
        }
        while (!deque.isEmpty()) {
            final ResourceLocation resourcelocation3 = deque.pop();
            try {
                if (this.momgetthecamera.get(resourcelocation3) != null) {
                    continue;
                }
                final ModelBlock modelblock = this.sigma(resourcelocation3);
                this.momgetthecamera.put(resourcelocation3, modelblock);
                final ResourceLocation resourcelocation4 = modelblock.zues();
                if (resourcelocation4 != null && !set.contains(resourcelocation4)) {
                    deque.add(resourcelocation4);
                }
            }
            catch (Exception exception) {
                ModelBakery.sigma.warn("In parent chain: " + ModelBakery.zues.join((Iterable)this.zues(resourcelocation3)) + "; unable to load model: '" + resourcelocation3 + "'", (Throwable)exception);
            }
            set.add(resourcelocation3);
        }
    }
    
    private List<ResourceLocation> zues(final ResourceLocation p_177573_1_) {
        final List<ResourceLocation> list = (List<ResourceLocation>)Lists.newArrayList((Object[])new ResourceLocation[] { p_177573_1_ });
        ResourceLocation resourcelocation = p_177573_1_;
        while ((resourcelocation = this.flux(resourcelocation)) != null) {
            list.add(0, resourcelocation);
        }
        return list;
    }
    
    private ResourceLocation flux(final ResourceLocation p_177576_1_) {
        for (final Map.Entry<ResourceLocation, ModelBlock> entry : this.momgetthecamera.entrySet()) {
            final ModelBlock modelblock = entry.getValue();
            if (modelblock != null && p_177576_1_.equals(modelblock.zues())) {
                return entry.getKey();
            }
        }
        return null;
    }
    
    private Set<ResourceLocation> zerodayisaminecraftcheat(final ModelBlock p_177585_1_) {
        final Set<ResourceLocation> set = (Set<ResourceLocation>)Sets.newHashSet();
        for (final BlockPart blockpart : p_177585_1_.zerodayisaminecraftcheat()) {
            for (final BlockPartFace blockpartface : blockpart.sigma.values()) {
                final ResourceLocation resourcelocation = new ResourceLocation(p_177585_1_.sigma(blockpartface.pandora));
                set.add(resourcelocation);
            }
        }
        set.add(new ResourceLocation(p_177585_1_.sigma("particle")));
        return set;
    }
    
    private void b() {
        final Set<ResourceLocation> set = this.vape();
        set.addAll(this.c());
        set.remove(TextureMap.zerodayisaminecraftcheat);
        final IIconCreator iiconcreator = new IIconCreator() {
            @Override
            public void zerodayisaminecraftcheat(final TextureMap iconRegistry) {
                for (final ResourceLocation resourcelocation : set) {
                    final TextureAtlasSprite textureatlassprite = iconRegistry.zerodayisaminecraftcheat(resourcelocation);
                    ModelBakery.this.vape.put(resourcelocation, textureatlassprite);
                }
            }
        };
        this.b.zerodayisaminecraftcheat(this.flux, iiconcreator);
        this.vape.put(new ResourceLocation("missingno"), this.b.vape());
    }
    
    private Set<ResourceLocation> c() {
        final Set<ResourceLocation> set = (Set<ResourceLocation>)Sets.newHashSet();
        for (final ResourceLocation resourcelocation : this.k.values()) {
            final ModelBlock modelblock = this.momgetthecamera.get(resourcelocation);
            if (modelblock != null) {
                set.add(new ResourceLocation(modelblock.sigma("particle")));
                if (this.zeroday(modelblock)) {
                    for (final String s : ItemModelGenerator.zerodayisaminecraftcheat) {
                        final ResourceLocation resourcelocation2 = new ResourceLocation(modelblock.sigma(s));
                        if (modelblock.flux() == ModelBakery.h && !TextureMap.zerodayisaminecraftcheat.equals(resourcelocation2)) {
                            TextureAtlasSprite.zeroday(resourcelocation2.toString());
                        }
                        else if (modelblock.flux() == ModelBakery.i && !TextureMap.zerodayisaminecraftcheat.equals(resourcelocation2)) {
                            TextureAtlasSprite.zerodayisaminecraftcheat(resourcelocation2.toString());
                        }
                        set.add(resourcelocation2);
                    }
                }
                else {
                    if (this.sigma(modelblock)) {
                        continue;
                    }
                    for (final BlockPart blockpart : modelblock.zerodayisaminecraftcheat()) {
                        for (final BlockPartFace blockpartface : blockpart.sigma.values()) {
                            final ResourceLocation resourcelocation3 = new ResourceLocation(modelblock.sigma(blockpartface.pandora));
                            set.add(resourcelocation3);
                        }
                    }
                }
            }
        }
        return set;
    }
    
    private boolean zeroday(final ModelBlock p_177581_1_) {
        if (p_177581_1_ == null) {
            return false;
        }
        final ModelBlock modelblock = p_177581_1_.flux();
        return modelblock == ModelBakery.g || modelblock == ModelBakery.h || modelblock == ModelBakery.i;
    }
    
    private boolean sigma(final ModelBlock p_177587_1_) {
        if (p_177587_1_ == null) {
            return false;
        }
        final ModelBlock modelblock = p_177587_1_.flux();
        return modelblock == ModelBakery.j;
    }
    
    private void d() {
        for (final ResourceLocation resourcelocation : this.k.values()) {
            final ModelBlock modelblock = this.momgetthecamera.get(resourcelocation);
            if (this.zeroday(modelblock)) {
                final ModelBlock modelblock2 = this.pandora(modelblock);
                if (modelblock2 != null) {
                    modelblock2.zeroday = resourcelocation.toString();
                }
                this.momgetthecamera.put(resourcelocation, modelblock2);
            }
            else {
                if (!this.sigma(modelblock)) {
                    continue;
                }
                this.momgetthecamera.put(resourcelocation, modelblock);
            }
        }
        for (final TextureAtlasSprite textureatlassprite : this.vape.values()) {
            if (!textureatlassprite.e()) {
                textureatlassprite.d();
            }
        }
    }
    
    private ModelBlock pandora(final ModelBlock p_177582_1_) {
        return this.e.zerodayisaminecraftcheat(this.b, p_177582_1_);
    }
}

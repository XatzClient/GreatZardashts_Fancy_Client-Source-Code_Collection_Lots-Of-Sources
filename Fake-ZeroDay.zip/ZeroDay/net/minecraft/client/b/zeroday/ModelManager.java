// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zeroday;

import net.minecraft.client.b.IResourceManager;
import net.minecraft.client.a.BlockModelShapes;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.o.IRegistry;
import net.minecraft.client.b.IResourceManagerReloadListener;

public class ModelManager implements IResourceManagerReloadListener
{
    private IRegistry<ModelResourceLocation, IBakedModel> zerodayisaminecraftcheat;
    private final TextureMap zeroday;
    private final BlockModelShapes sigma;
    private IBakedModel pandora;
    
    public ModelManager(final TextureMap textures) {
        this.zeroday = textures;
        this.sigma = new BlockModelShapes(this);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        final ModelBakery modelbakery = new ModelBakery(resourceManager, this.zeroday, this.sigma);
        this.zerodayisaminecraftcheat = modelbakery.zerodayisaminecraftcheat();
        this.pandora = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(ModelBakery.zerodayisaminecraftcheat);
        this.sigma.sigma();
    }
    
    public IBakedModel zerodayisaminecraftcheat(final ModelResourceLocation modelLocation) {
        if (modelLocation == null) {
            return this.pandora;
        }
        final IBakedModel ibakedmodel = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(modelLocation);
        return (ibakedmodel == null) ? this.pandora : ibakedmodel;
    }
    
    public IBakedModel zerodayisaminecraftcheat() {
        return this.pandora;
    }
    
    public TextureMap zeroday() {
        return this.zeroday;
    }
    
    public BlockModelShapes sigma() {
        return this.sigma;
    }
}

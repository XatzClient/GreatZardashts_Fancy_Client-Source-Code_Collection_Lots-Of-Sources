// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zeroday;

import net.minecraft.l.Reflector;
import net.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.pandora;
import net.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.MathHelper;
import org.lwjgl.util.vector.Vector3f;
import com.google.common.collect.Maps;
import org.lwjgl.util.vector.Matrix4f;
import java.util.Map;
import net.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zeroday;
import net.zerodayisaminecraftcheat.zerodayisaminecraftcheat.zerodayisaminecraftcheat.sigma;

public enum ModelRotation implements sigma, zeroday
{
    zerodayisaminecraftcheat("X0_Y0", 0, "X0_Y0", 0, 0, 0), 
    zeroday("X0_Y90", 1, "X0_Y90", 1, 0, 90), 
    sigma("X0_Y180", 2, "X0_Y180", 2, 0, 180), 
    pandora("X0_Y270", 3, "X0_Y270", 3, 0, 270), 
    zues("X90_Y0", 4, "X90_Y0", 4, 90, 0), 
    flux("X90_Y90", 5, "X90_Y90", 5, 90, 90), 
    vape("X90_Y180", 6, "X90_Y180", 6, 90, 180), 
    momgetthecamera("X90_Y270", 7, "X90_Y270", 7, 90, 270), 
    a("X180_Y0", 8, "X180_Y0", 8, 180, 0), 
    b("X180_Y90", 9, "X180_Y90", 9, 180, 90), 
    c("X180_Y180", 10, "X180_Y180", 10, 180, 180), 
    d("X180_Y270", 11, "X180_Y270", 11, 180, 270), 
    e("X270_Y0", 12, "X270_Y0", 12, 270, 0), 
    f("X270_Y90", 13, "X270_Y90", 13, 270, 90), 
    g("X270_Y180", 14, "X270_Y180", 14, 270, 180), 
    h("X270_Y270", 15, "X270_Y270", 15, 270, 270);
    
    private static final Map i;
    private final int j;
    private final Matrix4f k;
    private final int l;
    private final int m;
    private static final ModelRotation[] n;
    private static final String o = "CL_00002393";
    
    static {
        p = new ModelRotation[] { ModelRotation.zerodayisaminecraftcheat, ModelRotation.zeroday, ModelRotation.sigma, ModelRotation.pandora, ModelRotation.zues, ModelRotation.flux, ModelRotation.vape, ModelRotation.momgetthecamera, ModelRotation.a, ModelRotation.b, ModelRotation.c, ModelRotation.d, ModelRotation.e, ModelRotation.f, ModelRotation.g, ModelRotation.h };
        i = Maps.newHashMap();
        n = new ModelRotation[] { ModelRotation.zerodayisaminecraftcheat, ModelRotation.zeroday, ModelRotation.sigma, ModelRotation.pandora, ModelRotation.zues, ModelRotation.flux, ModelRotation.vape, ModelRotation.momgetthecamera, ModelRotation.a, ModelRotation.b, ModelRotation.c, ModelRotation.d, ModelRotation.e, ModelRotation.f, ModelRotation.g, ModelRotation.h };
        ModelRotation[] values;
        for (int length = (values = values()).length, j = 0; j < length; ++j) {
            final ModelRotation modelrotation = values[j];
            ModelRotation.i.put(modelrotation.j, modelrotation);
        }
    }
    
    private static int zeroday(final int p_177521_0_, final int p_177521_1_) {
        return p_177521_0_ * 360 + p_177521_1_;
    }
    
    private ModelRotation(final String s, final int n, final String p_i26_3_, final int p_i26_4_, final int p_i26_5_, final int p_i26_6_) {
        this.j = zeroday(p_i26_5_, p_i26_6_);
        this.k = new Matrix4f();
        final Matrix4f matrix4f = new Matrix4f();
        matrix4f.setIdentity();
        Matrix4f.rotate(-p_i26_5_ * 0.017453292f, new Vector3f(1.0f, 0.0f, 0.0f), matrix4f, matrix4f);
        this.l = MathHelper.zerodayisaminecraftcheat(p_i26_5_ / 90);
        final Matrix4f matrix4f2 = new Matrix4f();
        matrix4f2.setIdentity();
        Matrix4f.rotate(-p_i26_6_ * 0.017453292f, new Vector3f(0.0f, 1.0f, 0.0f), matrix4f2, matrix4f2);
        this.m = MathHelper.zerodayisaminecraftcheat(p_i26_6_ / 90);
        Matrix4f.mul(matrix4f2, matrix4f, this.k);
    }
    
    public Matrix4f zerodayisaminecraftcheat() {
        return this.k;
    }
    
    public EnumFacing zerodayisaminecraftcheat(final EnumFacing p_177523_1_) {
        EnumFacing enumfacing = p_177523_1_;
        for (int i = 0; i < this.l; ++i) {
            enumfacing = enumfacing.zerodayisaminecraftcheat(EnumFacing.zerodayisaminecraftcheat.zerodayisaminecraftcheat);
        }
        if (enumfacing.d() != EnumFacing.zerodayisaminecraftcheat.zeroday) {
            for (int j = 0; j < this.m; ++j) {
                enumfacing = enumfacing.zerodayisaminecraftcheat(EnumFacing.zerodayisaminecraftcheat.zeroday);
            }
        }
        return enumfacing;
    }
    
    public int zerodayisaminecraftcheat(final EnumFacing facing, final int vertexIndex) {
        int i = vertexIndex;
        if (facing.d() == EnumFacing.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            i = (vertexIndex + this.l) % 4;
        }
        EnumFacing enumfacing = facing;
        for (int j = 0; j < this.l; ++j) {
            enumfacing = enumfacing.zerodayisaminecraftcheat(EnumFacing.zerodayisaminecraftcheat.zerodayisaminecraftcheat);
        }
        if (enumfacing.d() == EnumFacing.zerodayisaminecraftcheat.zeroday) {
            i = (i + this.m) % 4;
        }
        return i;
    }
    
    public static ModelRotation zerodayisaminecraftcheat(final int p_177524_0_, final int p_177524_1_) {
        return ModelRotation.i.get(zeroday(MathHelper.zeroday(p_177524_0_, 360), MathHelper.zeroday(p_177524_1_, 360)));
    }
    
    @Override
    public pandora zerodayisaminecraftcheat(final zerodayisaminecraftcheat p_apply_1_) {
        return new pandora(this.zeroday());
    }
    
    @Override
    public javax.zerodayisaminecraftcheat.zerodayisaminecraftcheat zeroday() {
        return (javax.zerodayisaminecraftcheat.zerodayisaminecraftcheat)(Reflector.t.zeroday() ? Reflector.vape(Reflector.t, this) : new javax.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat()));
    }
    
    @Override
    public EnumFacing zeroday(final EnumFacing p_rotate_1_) {
        return this.zerodayisaminecraftcheat(p_rotate_1_);
    }
    
    @Override
    public int zeroday(final EnumFacing p_rotate_1_, final int p_rotate_2_) {
        return this.zerodayisaminecraftcheat(p_rotate_1_, p_rotate_2_);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zeroday;

import com.google.common.collect.Lists;
import java.util.Iterator;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BreakingFour;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ModelBlock;
import net.minecraft.o.EnumFacing;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BakedQuad;
import java.util.List;

public class SimpleBakedModel implements IBakedModel
{
    protected final List<BakedQuad> zerodayisaminecraftcheat;
    protected final List<List<BakedQuad>> zeroday;
    protected final boolean sigma;
    protected final boolean pandora;
    protected final TextureAtlasSprite zues;
    protected final ItemCameraTransforms flux;
    
    public SimpleBakedModel(final List<BakedQuad> p_i46077_1_, final List<List<BakedQuad>> p_i46077_2_, final boolean p_i46077_3_, final boolean p_i46077_4_, final TextureAtlasSprite p_i46077_5_, final ItemCameraTransforms p_i46077_6_) {
        this.zerodayisaminecraftcheat = p_i46077_1_;
        this.zeroday = p_i46077_2_;
        this.sigma = p_i46077_3_;
        this.pandora = p_i46077_4_;
        this.zues = p_i46077_5_;
        this.flux = p_i46077_6_;
    }
    
    @Override
    public List<BakedQuad> zerodayisaminecraftcheat(final EnumFacing p_177551_1_) {
        return this.zeroday.get(p_177551_1_.ordinal());
    }
    
    @Override
    public List<BakedQuad> zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
    
    @Override
    public boolean zeroday() {
        return this.sigma;
    }
    
    @Override
    public boolean sigma() {
        return this.pandora;
    }
    
    @Override
    public boolean pandora() {
        return false;
    }
    
    @Override
    public TextureAtlasSprite zues() {
        return this.zues;
    }
    
    @Override
    public ItemCameraTransforms flux() {
        return this.flux;
    }
    
    public static class zerodayisaminecraftcheat
    {
        private final List<BakedQuad> zerodayisaminecraftcheat;
        private final List<List<BakedQuad>> zeroday;
        private final boolean sigma;
        private TextureAtlasSprite pandora;
        private boolean zues;
        private ItemCameraTransforms flux;
        
        public zerodayisaminecraftcheat(final ModelBlock p_i46074_1_) {
            this(p_i46074_1_.zeroday(), p_i46074_1_.sigma(), p_i46074_1_.vape());
        }
        
        public zerodayisaminecraftcheat(final IBakedModel p_i46075_1_, final TextureAtlasSprite p_i46075_2_) {
            this(p_i46075_1_.zeroday(), p_i46075_1_.sigma(), p_i46075_1_.flux());
            this.pandora = p_i46075_1_.zues();
            EnumFacing[] values;
            for (int length = (values = EnumFacing.values()).length, i = 0; i < length; ++i) {
                final EnumFacing enumfacing = values[i];
                this.zerodayisaminecraftcheat(p_i46075_1_, p_i46075_2_, enumfacing);
            }
            this.zerodayisaminecraftcheat(p_i46075_1_, p_i46075_2_);
        }
        
        private void zerodayisaminecraftcheat(final IBakedModel p_177649_1_, final TextureAtlasSprite p_177649_2_, final EnumFacing p_177649_3_) {
            for (final BakedQuad bakedquad : p_177649_1_.zerodayisaminecraftcheat(p_177649_3_)) {
                this.zerodayisaminecraftcheat(p_177649_3_, new BreakingFour(bakedquad, p_177649_2_));
            }
        }
        
        private void zerodayisaminecraftcheat(final IBakedModel p_177647_1_, final TextureAtlasSprite p_177647_2_) {
            for (final BakedQuad bakedquad : p_177647_1_.zerodayisaminecraftcheat()) {
                this.zerodayisaminecraftcheat(new BreakingFour(bakedquad, p_177647_2_));
            }
        }
        
        private zerodayisaminecraftcheat(final boolean p_i46076_1_, final boolean p_i46076_2_, final ItemCameraTransforms p_i46076_3_) {
            this.zerodayisaminecraftcheat = (List<BakedQuad>)Lists.newArrayList();
            this.zeroday = (List<List<BakedQuad>>)Lists.newArrayListWithCapacity(6);
            EnumFacing[] values;
            for (int length = (values = EnumFacing.values()).length, i = 0; i < length; ++i) {
                final EnumFacing enumfacing = values[i];
                this.zeroday.add(Lists.newArrayList());
            }
            this.sigma = p_i46076_1_;
            this.zues = p_i46076_2_;
            this.flux = p_i46076_3_;
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat(final EnumFacing p_177650_1_, final BakedQuad p_177650_2_) {
            this.zeroday.get(p_177650_1_.ordinal()).add(p_177650_2_);
            return this;
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat(final BakedQuad p_177648_1_) {
            this.zerodayisaminecraftcheat.add(p_177648_1_);
            return this;
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat(final TextureAtlasSprite p_177646_1_) {
            this.pandora = p_177646_1_;
            return this;
        }
        
        public IBakedModel zerodayisaminecraftcheat() {
            if (this.pandora == null) {
                throw new RuntimeException("Missing particle!");
            }
            return new SimpleBakedModel(this.zerodayisaminecraftcheat, this.zeroday, this.sigma, this.zues, this.pandora, this.flux);
        }
    }
}

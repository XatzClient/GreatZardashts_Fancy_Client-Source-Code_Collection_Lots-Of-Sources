// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zeroday;

import java.util.Collections;
import com.google.common.collect.Lists;
import com.google.common.collect.ComparisonChain;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ItemCameraTransforms;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.a.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BakedQuad;
import net.minecraft.o.EnumFacing;
import java.util.Collection;
import net.minecraft.o.WeightedRandom;
import java.util.List;

public class WeightedBakedModel implements IBakedModel
{
    private final int zerodayisaminecraftcheat;
    private final List<zeroday> zeroday;
    private final IBakedModel sigma;
    
    public WeightedBakedModel(final List<zeroday> p_i46073_1_) {
        this.zeroday = p_i46073_1_;
        this.zerodayisaminecraftcheat = WeightedRandom.zerodayisaminecraftcheat(p_i46073_1_);
        this.sigma = p_i46073_1_.get(0).zerodayisaminecraftcheat;
    }
    
    @Override
    public List<BakedQuad> zerodayisaminecraftcheat(final EnumFacing p_177551_1_) {
        return this.sigma.zerodayisaminecraftcheat(p_177551_1_);
    }
    
    @Override
    public List<BakedQuad> zerodayisaminecraftcheat() {
        return this.sigma.zerodayisaminecraftcheat();
    }
    
    @Override
    public boolean zeroday() {
        return this.sigma.zeroday();
    }
    
    @Override
    public boolean sigma() {
        return this.sigma.sigma();
    }
    
    @Override
    public boolean pandora() {
        return this.sigma.pandora();
    }
    
    @Override
    public TextureAtlasSprite zues() {
        return this.sigma.zues();
    }
    
    @Override
    public ItemCameraTransforms flux() {
        return this.sigma.flux();
    }
    
    public IBakedModel zerodayisaminecraftcheat(final long p_177564_1_) {
        return WeightedRandom.zerodayisaminecraftcheat(this.zeroday, Math.abs((int)p_177564_1_ >> 16) % this.zerodayisaminecraftcheat).zerodayisaminecraftcheat;
    }
    
    static class zeroday extends WeightedRandom.zerodayisaminecraftcheat implements Comparable<zeroday>
    {
        protected final IBakedModel zerodayisaminecraftcheat;
        
        public zeroday(final IBakedModel p_i46072_1_, final int p_i46072_2_) {
            super(p_i46072_2_);
            this.zerodayisaminecraftcheat = p_i46072_1_;
        }
        
        public int zerodayisaminecraftcheat(final zeroday p_compareTo_1_) {
            return ComparisonChain.start().compare(p_compareTo_1_.sigma, this.sigma).compare(this.zerodayisaminecraftcheat(), p_compareTo_1_.zerodayisaminecraftcheat()).result();
        }
        
        protected int zerodayisaminecraftcheat() {
            int i = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat().size();
            EnumFacing[] values;
            for (int length = (values = EnumFacing.values()).length, j = 0; j < length; ++j) {
                final EnumFacing enumfacing = values[j];
                i += this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(enumfacing).size();
            }
            return i;
        }
        
        @Override
        public String toString() {
            return "MyWeighedRandomItem{weight=" + this.sigma + ", model=" + this.zerodayisaminecraftcheat + '}';
        }
    }
    
    public static class zerodayisaminecraftcheat
    {
        private List<zeroday> zerodayisaminecraftcheat;
        
        public zerodayisaminecraftcheat() {
            this.zerodayisaminecraftcheat = (List<zeroday>)Lists.newArrayList();
        }
        
        public zerodayisaminecraftcheat zerodayisaminecraftcheat(final IBakedModel p_177677_1_, final int p_177677_2_) {
            this.zerodayisaminecraftcheat.add(new zeroday(p_177677_1_, p_177677_2_));
            return this;
        }
        
        public WeightedBakedModel zerodayisaminecraftcheat() {
            Collections.sort(this.zerodayisaminecraftcheat);
            return new WeightedBakedModel(this.zerodayisaminecraftcheat);
        }
        
        public IBakedModel zeroday() {
            return this.zerodayisaminecraftcheat.get(0).zerodayisaminecraftcheat;
        }
    }
}

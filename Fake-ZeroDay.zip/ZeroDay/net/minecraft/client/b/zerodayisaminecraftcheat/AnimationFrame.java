// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

public class AnimationFrame
{
    private final int zerodayisaminecraftcheat;
    private final int zeroday;
    
    public AnimationFrame(final int p_i1307_1_) {
        this(p_i1307_1_, -1);
    }
    
    public AnimationFrame(final int p_i1308_1_, final int p_i1308_2_) {
        this.zerodayisaminecraftcheat = p_i1308_1_;
        this.zeroday = p_i1308_2_;
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.zeroday == -1;
    }
    
    public int zeroday() {
        return this.zeroday;
    }
    
    public int sigma() {
        return this.zerodayisaminecraftcheat;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

import java.util.Iterator;
import com.google.common.collect.Sets;
import java.util.Set;
import java.util.List;

public class AnimationMetadataSection implements IMetadataSection
{
    private final List<AnimationFrame> zerodayisaminecraftcheat;
    private final int zeroday;
    private final int sigma;
    private final int pandora;
    private final boolean zues;
    
    public AnimationMetadataSection(final List<AnimationFrame> p_i46088_1_, final int p_i46088_2_, final int p_i46088_3_, final int p_i46088_4_, final boolean p_i46088_5_) {
        this.zerodayisaminecraftcheat = p_i46088_1_;
        this.zeroday = p_i46088_2_;
        this.sigma = p_i46088_3_;
        this.pandora = p_i46088_4_;
        this.zues = p_i46088_5_;
    }
    
    public int zerodayisaminecraftcheat() {
        return this.sigma;
    }
    
    public int zeroday() {
        return this.zeroday;
    }
    
    public int sigma() {
        return this.zerodayisaminecraftcheat.size();
    }
    
    public int pandora() {
        return this.pandora;
    }
    
    public boolean zues() {
        return this.zues;
    }
    
    private AnimationFrame pandora(final int p_130072_1_) {
        return this.zerodayisaminecraftcheat.get(p_130072_1_);
    }
    
    public int zerodayisaminecraftcheat(final int p_110472_1_) {
        final AnimationFrame animationframe = this.pandora(p_110472_1_);
        return animationframe.zerodayisaminecraftcheat() ? this.pandora : animationframe.zeroday();
    }
    
    public boolean zeroday(final int p_110470_1_) {
        return !this.zerodayisaminecraftcheat.get(p_110470_1_).zerodayisaminecraftcheat();
    }
    
    public int sigma(final int p_110468_1_) {
        return this.zerodayisaminecraftcheat.get(p_110468_1_).sigma();
    }
    
    public Set<Integer> flux() {
        final Set<Integer> set = (Set<Integer>)Sets.newHashSet();
        for (final AnimationFrame animationframe : this.zerodayisaminecraftcheat) {
            set.add(animationframe.sigma());
        }
        return set;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.List;
import com.google.gson.JsonParseException;
import org.apache.commons.lang3.Validate;
import net.minecraft.o.JsonUtils;
import com.google.common.collect.Lists;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonSerializer;

public class AnimationMetadataSectionSerializer extends BaseMetadataSectionSerializer<AnimationMetadataSection> implements JsonSerializer<AnimationMetadataSection>
{
    public AnimationMetadataSection zerodayisaminecraftcheat(final JsonElement p_deserialize_1_, final Type p_deserialize_2_, final JsonDeserializationContext p_deserialize_3_) throws JsonParseException {
        final List<AnimationFrame> list = (List<AnimationFrame>)Lists.newArrayList();
        final JsonObject jsonobject = JsonUtils.zues(p_deserialize_1_, "metadata section");
        final int i = JsonUtils.zerodayisaminecraftcheat(jsonobject, "frametime", 1);
        if (i != 1) {
            Validate.inclusiveBetween(1L, 2147483647L, (long)i, "Invalid default frame time");
        }
        if (jsonobject.has("frames")) {
            try {
                final JsonArray jsonarray = JsonUtils.c(jsonobject, "frames");
                for (int j = 0; j < jsonarray.size(); ++j) {
                    final JsonElement jsonelement = jsonarray.get(j);
                    final AnimationFrame animationframe = this.zerodayisaminecraftcheat(j, jsonelement);
                    if (animationframe != null) {
                        list.add(animationframe);
                    }
                }
            }
            catch (ClassCastException classcastexception) {
                throw new JsonParseException("Invalid animation->frames: expected array, was " + jsonobject.get("frames"), (Throwable)classcastexception);
            }
        }
        final int k = JsonUtils.zerodayisaminecraftcheat(jsonobject, "width", -1);
        final int l = JsonUtils.zerodayisaminecraftcheat(jsonobject, "height", -1);
        if (k != -1) {
            Validate.inclusiveBetween(1L, 2147483647L, (long)k, "Invalid width");
        }
        if (l != -1) {
            Validate.inclusiveBetween(1L, 2147483647L, (long)l, "Invalid height");
        }
        final boolean flag = JsonUtils.zerodayisaminecraftcheat(jsonobject, "interpolate", false);
        return new AnimationMetadataSection(list, k, l, i, flag);
    }
    
    private AnimationFrame zerodayisaminecraftcheat(final int p_110492_1_, final JsonElement p_110492_2_) {
        if (p_110492_2_.isJsonPrimitive()) {
            return new AnimationFrame(JsonUtils.pandora(p_110492_2_, "frames[" + p_110492_1_ + "]"));
        }
        if (p_110492_2_.isJsonObject()) {
            final JsonObject jsonobject = JsonUtils.zues(p_110492_2_, "frames[" + p_110492_1_ + "]");
            final int i = JsonUtils.zerodayisaminecraftcheat(jsonobject, "time", -1);
            if (jsonobject.has("time")) {
                Validate.inclusiveBetween(1L, 2147483647L, (long)i, "Invalid frame time");
            }
            final int j = JsonUtils.a(jsonobject, "index");
            Validate.inclusiveBetween(0L, 2147483647L, (long)j, "Invalid frame index");
            return new AnimationFrame(j, i);
        }
        return null;
    }
    
    public JsonElement zerodayisaminecraftcheat(final AnimationMetadataSection p_serialize_1_, final Type p_serialize_2_, final JsonSerializationContext p_serialize_3_) {
        final JsonObject jsonobject = new JsonObject();
        jsonobject.addProperty("frametime", (Number)p_serialize_1_.pandora());
        if (p_serialize_1_.zeroday() != -1) {
            jsonobject.addProperty("width", (Number)p_serialize_1_.zeroday());
        }
        if (p_serialize_1_.zerodayisaminecraftcheat() != -1) {
            jsonobject.addProperty("height", (Number)p_serialize_1_.zerodayisaminecraftcheat());
        }
        if (p_serialize_1_.sigma() > 0) {
            final JsonArray jsonarray = new JsonArray();
            for (int i = 0; i < p_serialize_1_.sigma(); ++i) {
                if (p_serialize_1_.zeroday(i)) {
                    final JsonObject jsonobject2 = new JsonObject();
                    jsonobject2.addProperty("index", (Number)p_serialize_1_.sigma(i));
                    jsonobject2.addProperty("time", (Number)p_serialize_1_.zerodayisaminecraftcheat(i));
                    jsonarray.add((JsonElement)jsonobject2);
                }
                else {
                    jsonarray.add((JsonElement)new JsonPrimitive((Number)p_serialize_1_.sigma(i)));
                }
            }
            jsonobject.add("frames", (JsonElement)jsonarray);
        }
        return (JsonElement)jsonobject;
    }
    
    public String zerodayisaminecraftcheat() {
        return "animation";
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

public abstract class BaseMetadataSectionSerializer<T extends IMetadataSection> implements IMetadataSectionSerializer<T>
{
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

public class FontMetadataSection implements IMetadataSection
{
    private final float[] zerodayisaminecraftcheat;
    private final float[] zeroday;
    private final float[] sigma;
    
    public FontMetadataSection(final float[] p_i1310_1_, final float[] p_i1310_2_, final float[] p_i1310_3_) {
        this.zerodayisaminecraftcheat = p_i1310_1_;
        this.zeroday = p_i1310_2_;
        this.sigma = p_i1310_3_;
    }
}

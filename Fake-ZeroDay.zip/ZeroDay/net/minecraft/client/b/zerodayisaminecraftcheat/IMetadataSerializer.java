// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.reflect.Type;
import com.google.gson.TypeAdapterFactory;
import net.minecraft.o.EnumTypeAdapterFactory;
import net.minecraft.o.ChatStyle;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.RegistrySimple;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.o.IRegistry;

public class IMetadataSerializer
{
    private final IRegistry<String, zerodayisaminecraftcheat<? extends IMetadataSection>> zerodayisaminecraftcheat;
    private final GsonBuilder zeroday;
    private Gson sigma;
    
    public IMetadataSerializer() {
        this.zerodayisaminecraftcheat = new RegistrySimple<String, zerodayisaminecraftcheat<? extends IMetadataSection>>();
        (this.zeroday = new GsonBuilder()).registerTypeHierarchyAdapter((Class)IChatComponent.class, (Object)new IChatComponent.zerodayisaminecraftcheat());
        this.zeroday.registerTypeHierarchyAdapter((Class)ChatStyle.class, (Object)new ChatStyle.zerodayisaminecraftcheat());
        this.zeroday.registerTypeAdapterFactory((TypeAdapterFactory)new EnumTypeAdapterFactory());
    }
    
    public <T extends IMetadataSection> void zerodayisaminecraftcheat(final IMetadataSectionSerializer<T> p_110504_1_, final Class<T> p_110504_2_) {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_110504_1_.zerodayisaminecraftcheat(), new zerodayisaminecraftcheat<IMetadataSection>((IMetadataSectionSerializer)p_110504_1_, (Class)p_110504_2_, (zerodayisaminecraftcheat<IMetadataSection>)null));
        this.zeroday.registerTypeAdapter((Type)p_110504_2_, (Object)p_110504_1_);
        this.sigma = null;
    }
    
    public <T extends IMetadataSection> T zerodayisaminecraftcheat(final String p_110503_1_, final JsonObject p_110503_2_) {
        if (p_110503_1_ == null) {
            throw new IllegalArgumentException("Metadata section name cannot be null");
        }
        if (!p_110503_2_.has(p_110503_1_)) {
            return null;
        }
        if (!p_110503_2_.get(p_110503_1_).isJsonObject()) {
            throw new IllegalArgumentException("Invalid metadata for '" + p_110503_1_ + "' - expected object, found " + p_110503_2_.get(p_110503_1_));
        }
        final zerodayisaminecraftcheat<?> registration = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_110503_1_);
        if (registration == null) {
            throw new IllegalArgumentException("Don't know how to handle metadata section '" + p_110503_1_ + "'");
        }
        return (T)this.zerodayisaminecraftcheat().fromJson((JsonElement)p_110503_2_.getAsJsonObject(p_110503_1_), (Class)registration.zeroday);
    }
    
    private Gson zerodayisaminecraftcheat() {
        if (this.sigma == null) {
            this.sigma = this.zeroday.create();
        }
        return this.sigma;
    }
    
    class zerodayisaminecraftcheat<T extends IMetadataSection>
    {
        final IMetadataSectionSerializer<T> zerodayisaminecraftcheat;
        final Class<T> zeroday;
        
        private zerodayisaminecraftcheat(final IMetadataSectionSerializer<T> p_i1305_2_, final Class<T> p_i1305_3_) {
            this.zerodayisaminecraftcheat = p_i1305_2_;
            this.zeroday = p_i1305_3_;
        }
    }
}

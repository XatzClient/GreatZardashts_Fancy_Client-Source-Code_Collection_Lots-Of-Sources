// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

import net.minecraft.client.b.Language;
import java.util.Collection;

public class LanguageMetadataSection implements IMetadataSection
{
    private final Collection<Language> zerodayisaminecraftcheat;
    
    public LanguageMetadataSection(final Collection<Language> p_i1311_1_) {
        this.zerodayisaminecraftcheat = p_i1311_1_;
    }
    
    public Collection<Language> zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
}

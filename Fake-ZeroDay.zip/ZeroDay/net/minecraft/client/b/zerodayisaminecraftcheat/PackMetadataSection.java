// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

import net.minecraft.o.IChatComponent;

public class PackMetadataSection implements IMetadataSection
{
    private final IChatComponent zerodayisaminecraftcheat;
    private final int zeroday;
    
    public PackMetadataSection(final IChatComponent p_i1034_1_, final int p_i1034_2_) {
        this.zerodayisaminecraftcheat = p_i1034_1_;
        this.zeroday = p_i1034_2_;
    }
    
    public IChatComponent zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
    
    public int zeroday() {
        return this.zeroday;
    }
}

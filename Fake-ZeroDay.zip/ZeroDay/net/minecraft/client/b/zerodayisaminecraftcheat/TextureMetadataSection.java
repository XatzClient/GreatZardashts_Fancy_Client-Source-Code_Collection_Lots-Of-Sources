// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.b.zerodayisaminecraftcheat;

import java.util.Collections;
import java.util.List;

public class TextureMetadataSection implements IMetadataSection
{
    private final boolean zerodayisaminecraftcheat;
    private final boolean zeroday;
    private final List<Integer> sigma;
    
    public TextureMetadataSection(final boolean p_i45102_1_, final boolean p_i45102_2_, final List<Integer> p_i45102_3_) {
        this.zerodayisaminecraftcheat = p_i45102_1_;
        this.zeroday = p_i45102_2_;
        this.sigma = p_i45102_3_;
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
    
    public boolean zeroday() {
        return this.zeroday;
    }
    
    public List<Integer> sigma() {
        return Collections.unmodifiableList((List<? extends Integer>)this.sigma);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.c;

import net.minecraft.q.World;
import net.minecraft.l.ClearWater;
import sigma.zerodayisaminecraftcheat.j;
import java.util.Arrays;
import net.minecraft.o.MathHelper;
import net.minecraft.l.NaturalTextures;
import net.minecraft.l.CustomSky;
import net.minecraft.l.RandomMobs;
import net.minecraft.l.CustomColorizer;
import java.util.Collection;
import com.google.common.collect.ImmutableSet;
import java.util.Iterator;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C15PacketClientSettings;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.FileWriter;
import net.minecraft.l.Reflector;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import net.minecraft.client.e.TwitchStream;
import net.minecraft.client.sigma.GuiNewChat;
import org.lwjgl.opengl.Display;
import net.minecraft.client.a.zues.TextureMap;
import org.lwjgl.input.Mouse;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.b.I18n;
import org.apache.commons.lang3.ArrayUtils;
import net.minecraft.l.Config;
import com.google.common.collect.Maps;
import net.minecraft.client.zerodayisaminecraftcheat.SoundCategory;
import com.google.common.collect.Sets;
import net.minecraft.vape.vape.EnumPlayerModelParts;
import com.google.common.collect.Lists;
import java.lang.reflect.Type;
import org.apache.logging.log4j.LogManager;
import net.minecraft.q.EnumDifficulty;
import java.io.File;
import net.minecraft.client.Minecraft;
import java.util.Map;
import java.util.Set;
import net.minecraft.vape.vape.EntityPlayer;
import java.util.List;
import java.lang.reflect.ParameterizedType;
import com.google.gson.Gson;
import org.apache.logging.log4j.Logger;

public class GameSettings
{
    private static final Logger cc;
    private static final Gson cd;
    private static final ParameterizedType ce;
    private static final String[] cf;
    private static final String[] cg;
    private static final String[] ch;
    private static final String[] ci;
    private static final String[] cj;
    private static final String[] ck;
    private static final String[] cl;
    private static final String[] cm;
    public float zerodayisaminecraftcheat;
    public boolean zeroday;
    public int sigma;
    public boolean pandora;
    public boolean zues;
    public boolean flux;
    public int vape;
    public int momgetthecamera;
    public boolean a;
    public int b;
    public List c;
    public List d;
    public EntityPlayer.zerodayisaminecraftcheat e;
    public boolean f;
    public boolean g;
    public boolean h;
    public float i;
    public boolean j;
    public boolean k;
    public boolean l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public boolean q;
    public boolean r;
    private final Set cn;
    public boolean s;
    public int t;
    public int u;
    public boolean v;
    public float w;
    public float x;
    public float y;
    public float z;
    public boolean A;
    public int B;
    private Map co;
    public float C;
    public float D;
    public float E;
    public float F;
    public float G;
    public int H;
    public boolean I;
    public String J;
    public int K;
    public int L;
    public int M;
    public boolean N;
    public boolean O;
    public KeyBinding P;
    public KeyBinding Q;
    public KeyBinding R;
    public KeyBinding S;
    public KeyBinding T;
    public KeyBinding U;
    public KeyBinding V;
    public KeyBinding W;
    public KeyBinding X;
    public KeyBinding Y;
    public KeyBinding Z;
    public KeyBinding aa;
    public KeyBinding ab;
    public KeyBinding ac;
    public KeyBinding ad;
    public KeyBinding ae;
    public KeyBinding af;
    public KeyBinding ag;
    public KeyBinding ah;
    public KeyBinding ai;
    public KeyBinding aj;
    public KeyBinding ak;
    public KeyBinding al;
    public KeyBinding am;
    public KeyBinding[] an;
    public KeyBinding[] ao;
    protected Minecraft ap;
    private File cp;
    public EnumDifficulty aq;
    public boolean ar;
    public int as;
    public boolean at;
    public boolean au;
    public boolean av;
    public String aw;
    public boolean ax;
    public boolean ay;
    public float az;
    public float aA;
    public float aB;
    public int aC;
    public int aD;
    public String aE;
    public boolean aF;
    private static final String cq = "CL_00000650";
    public int aG;
    public float aH;
    public int aI;
    public boolean aJ;
    public boolean aK;
    public boolean aL;
    public boolean aM;
    public float aN;
    public int aO;
    public int aP;
    public int aQ;
    public float aR;
    public int aS;
    public int aT;
    public int aU;
    public int aV;
    public int aW;
    public boolean aX;
    public boolean aY;
    public boolean aZ;
    public boolean ba;
    public boolean bb;
    public boolean bc;
    public boolean bd;
    public int be;
    public int bf;
    public int bg;
    public boolean bh;
    public int bi;
    public boolean bj;
    public boolean bk;
    public String bl;
    public boolean bm;
    public boolean bn;
    public boolean bo;
    public boolean bp;
    public boolean bq;
    public boolean br;
    public boolean bs;
    public int bt;
    public boolean bu;
    public boolean bv;
    public boolean bw;
    public boolean bx;
    public int by;
    public int bz;
    public int bA;
    public boolean bB;
    public boolean bC;
    public boolean bD;
    public boolean bE;
    public boolean bF;
    public boolean bG;
    public boolean bH;
    public boolean bI;
    public boolean bJ;
    public boolean bK;
    public boolean bL;
    public boolean bM;
    public boolean bN;
    public boolean bO;
    public boolean bP;
    public static final int bQ = 0;
    public static final int bR = 1;
    public static final int bS = 2;
    public static final int bT = 3;
    public static final int bU = 0;
    public static final int bV = 1;
    public static final int bW = 2;
    public static final int bX = 0;
    public static final int bY = 1;
    public static final int bZ = 2;
    public static final String ca = "Default";
    public KeyBinding cb;
    private File cr;
    
    static {
        cc = LogManager.getLogger();
        cd = new Gson();
        ce = new ParameterizedType() {
            private static final String zerodayisaminecraftcheat = "CL_00000651";
            
            @Override
            public Type[] getActualTypeArguments() {
                return new Type[] { String.class };
            }
            
            @Override
            public Type getRawType() {
                return List.class;
            }
            
            @Override
            public Type getOwnerType() {
                return null;
            }
        };
        cf = new String[] { "options.guiScale.auto", "options.guiScale.small", "options.guiScale.normal", "options.guiScale.large" };
        cg = new String[] { "options.particles.all", "options.particles.decreased", "options.particles.minimal" };
        ch = new String[] { "options.ao.off", "options.ao.min", "options.ao.max" };
        ci = new String[] { "options.stream.compression.low", "options.stream.compression.medium", "options.stream.compression.high" };
        cj = new String[] { "options.stream.chat.enabled.streaming", "options.stream.chat.enabled.always", "options.stream.chat.enabled.never" };
        ck = new String[] { "options.stream.chat.userFilter.all", "options.stream.chat.userFilter.subs", "options.stream.chat.userFilter.mods" };
        cl = new String[] { "options.stream.mic_toggle.mute", "options.stream.mic_toggle.talk" };
        cm = new String[] { "options.off", "options.graphics.fast", "options.graphics.fancy" };
    }
    
    public GameSettings(final Minecraft mcIn, final File p_i46326_2_) {
        this.zerodayisaminecraftcheat = 0.5f;
        this.sigma = -1;
        this.pandora = true;
        this.flux = true;
        this.vape = 120;
        this.momgetthecamera = 2;
        this.a = true;
        this.b = 2;
        this.c = Lists.newArrayList();
        this.d = Lists.newArrayList();
        this.e = EntityPlayer.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        this.f = true;
        this.g = true;
        this.h = true;
        this.i = 1.0f;
        this.j = true;
        this.l = true;
        this.m = false;
        this.n = true;
        this.o = false;
        this.r = true;
        this.cn = Sets.newHashSet((Object[])EnumPlayerModelParts.values());
        this.v = true;
        this.w = 1.0f;
        this.x = 1.0f;
        this.y = 0.44366196f;
        this.z = 1.0f;
        this.A = true;
        this.B = 4;
        this.co = Maps.newEnumMap((Class)SoundCategory.class);
        this.C = 0.5f;
        this.D = 1.0f;
        this.E = 1.0f;
        this.F = 0.5412844f;
        this.G = 0.31690142f;
        this.H = 1;
        this.I = true;
        this.J = "";
        this.K = 0;
        this.L = 0;
        this.M = 0;
        this.N = true;
        this.O = true;
        this.P = new KeyBinding("key.forward", 17, "key.categories.movement");
        this.Q = new KeyBinding("key.left", 30, "key.categories.movement");
        this.R = new KeyBinding("key.back", 31, "key.categories.movement");
        this.S = new KeyBinding("key.right", 32, "key.categories.movement");
        this.T = new KeyBinding("key.jump", 57, "key.categories.movement");
        this.U = new KeyBinding("key.sneak", 42, "key.categories.movement");
        this.V = new KeyBinding("key.sprint", 29, "key.categories.movement");
        this.W = new KeyBinding("key.inventory", 18, "key.categories.inventory");
        this.X = new KeyBinding("key.use", -99, "key.categories.gameplay");
        this.Y = new KeyBinding("key.drop", 16, "key.categories.gameplay");
        this.Z = new KeyBinding("key.attack", -100, "key.categories.gameplay");
        this.aa = new KeyBinding("key.pickItem", -98, "key.categories.gameplay");
        this.ab = new KeyBinding("key.chat", 20, "key.categories.multiplayer");
        this.ac = new KeyBinding("key.playerlist", 15, "key.categories.multiplayer");
        this.ad = new KeyBinding("key.command", 53, "key.categories.multiplayer");
        this.ae = new KeyBinding("key.screenshot", 60, "key.categories.misc");
        this.af = new KeyBinding("key.togglePerspective", 63, "key.categories.misc");
        this.ag = new KeyBinding("key.smoothCamera", 0, "key.categories.misc");
        this.ah = new KeyBinding("key.fullscreen", 87, "key.categories.misc");
        this.ai = new KeyBinding("key.spectatorOutlines", 0, "key.categories.misc");
        this.aj = new KeyBinding("key.streamStartStop", 64, "key.categories.stream");
        this.ak = new KeyBinding("key.streamPauseUnpause", 65, "key.categories.stream");
        this.al = new KeyBinding("key.streamCommercial", 0, "key.categories.stream");
        this.am = new KeyBinding("key.streamToggleMic", 0, "key.categories.stream");
        this.an = new KeyBinding[] { new KeyBinding("key.hotbar.1", 2, "key.categories.inventory"), new KeyBinding("key.hotbar.2", 3, "key.categories.inventory"), new KeyBinding("key.hotbar.3", 4, "key.categories.inventory"), new KeyBinding("key.hotbar.4", 5, "key.categories.inventory"), new KeyBinding("key.hotbar.5", 6, "key.categories.inventory"), new KeyBinding("key.hotbar.6", 7, "key.categories.inventory"), new KeyBinding("key.hotbar.7", 8, "key.categories.inventory"), new KeyBinding("key.hotbar.8", 9, "key.categories.inventory"), new KeyBinding("key.hotbar.9", 10, "key.categories.inventory") };
        this.aG = 1;
        this.aH = 0.8f;
        this.aI = 0;
        this.aJ = false;
        this.aK = false;
        this.aL = Config.aI();
        this.aM = Config.aI();
        this.aN = 1.0f;
        this.aO = 0;
        this.aP = 1;
        this.aQ = 0;
        this.aR = 0.0f;
        this.aS = 0;
        this.aT = 0;
        this.aU = 0;
        this.aV = 3;
        this.aW = 4000;
        this.aX = false;
        this.aY = false;
        this.aZ = false;
        this.ba = true;
        this.bb = true;
        this.bc = true;
        this.bd = true;
        this.be = 0;
        this.bf = 1;
        this.bg = 0;
        this.bh = false;
        this.bi = 0;
        this.bj = false;
        this.bk = false;
        this.bl = "Default";
        this.bm = true;
        this.bn = true;
        this.bo = true;
        this.bp = true;
        this.bq = true;
        this.br = true;
        this.bs = true;
        this.bt = 2;
        this.bu = true;
        this.bv = false;
        this.bw = false;
        this.bx = true;
        this.by = 0;
        this.bz = 0;
        this.bA = 0;
        this.bB = true;
        this.bC = true;
        this.bD = true;
        this.bE = true;
        this.bF = true;
        this.bG = true;
        this.bH = true;
        this.bI = true;
        this.bJ = true;
        this.bK = true;
        this.bL = true;
        this.bM = true;
        this.bN = true;
        this.bO = true;
        this.bP = true;
        this.ao = (KeyBinding[])ArrayUtils.addAll((Object[])new KeyBinding[] { this.Z, this.X, this.P, this.Q, this.R, this.S, this.T, this.U, this.V, this.Y, this.W, this.ab, this.ac, this.aa, this.ad, this.ae, this.af, this.ag, this.aj, this.ak, this.al, this.am, this.ah, this.ai }, (Object[])this.an);
        this.aq = EnumDifficulty.sigma;
        this.aw = "";
        this.az = 70.0f;
        this.aE = "en_US";
        this.aF = false;
        this.ap = mcIn;
        this.cp = new File(p_i46326_2_, "options.txt");
        this.cr = new File(p_i46326_2_, "optionsof.txt");
        this.vape = (int)GameSettings.zeroday.a.zues();
        this.cb = new KeyBinding("Zoom", 46, "key.categories.misc");
        this.ao = (KeyBinding[])ArrayUtils.add((Object[])this.ao, (Object)this.cb);
        GameSettings.zeroday.flux.zerodayisaminecraftcheat(32.0f);
        this.sigma = 8;
        this.zerodayisaminecraftcheat();
        Config.zerodayisaminecraftcheat(this);
    }
    
    public GameSettings() {
        this.zerodayisaminecraftcheat = 0.5f;
        this.sigma = -1;
        this.pandora = true;
        this.flux = true;
        this.vape = 120;
        this.momgetthecamera = 2;
        this.a = true;
        this.b = 2;
        this.c = Lists.newArrayList();
        this.d = Lists.newArrayList();
        this.e = EntityPlayer.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        this.f = true;
        this.g = true;
        this.h = true;
        this.i = 1.0f;
        this.j = true;
        this.l = true;
        this.m = false;
        this.n = true;
        this.o = false;
        this.r = true;
        this.cn = Sets.newHashSet((Object[])EnumPlayerModelParts.values());
        this.v = true;
        this.w = 1.0f;
        this.x = 1.0f;
        this.y = 0.44366196f;
        this.z = 1.0f;
        this.A = true;
        this.B = 4;
        this.co = Maps.newEnumMap((Class)SoundCategory.class);
        this.C = 0.5f;
        this.D = 1.0f;
        this.E = 1.0f;
        this.F = 0.5412844f;
        this.G = 0.31690142f;
        this.H = 1;
        this.I = true;
        this.J = "";
        this.K = 0;
        this.L = 0;
        this.M = 0;
        this.N = true;
        this.O = true;
        this.P = new KeyBinding("key.forward", 17, "key.categories.movement");
        this.Q = new KeyBinding("key.left", 30, "key.categories.movement");
        this.R = new KeyBinding("key.back", 31, "key.categories.movement");
        this.S = new KeyBinding("key.right", 32, "key.categories.movement");
        this.T = new KeyBinding("key.jump", 57, "key.categories.movement");
        this.U = new KeyBinding("key.sneak", 42, "key.categories.movement");
        this.V = new KeyBinding("key.sprint", 29, "key.categories.movement");
        this.W = new KeyBinding("key.inventory", 18, "key.categories.inventory");
        this.X = new KeyBinding("key.use", -99, "key.categories.gameplay");
        this.Y = new KeyBinding("key.drop", 16, "key.categories.gameplay");
        this.Z = new KeyBinding("key.attack", -100, "key.categories.gameplay");
        this.aa = new KeyBinding("key.pickItem", -98, "key.categories.gameplay");
        this.ab = new KeyBinding("key.chat", 20, "key.categories.multiplayer");
        this.ac = new KeyBinding("key.playerlist", 15, "key.categories.multiplayer");
        this.ad = new KeyBinding("key.command", 53, "key.categories.multiplayer");
        this.ae = new KeyBinding("key.screenshot", 60, "key.categories.misc");
        this.af = new KeyBinding("key.togglePerspective", 63, "key.categories.misc");
        this.ag = new KeyBinding("key.smoothCamera", 0, "key.categories.misc");
        this.ah = new KeyBinding("key.fullscreen", 87, "key.categories.misc");
        this.ai = new KeyBinding("key.spectatorOutlines", 0, "key.categories.misc");
        this.aj = new KeyBinding("key.streamStartStop", 64, "key.categories.stream");
        this.ak = new KeyBinding("key.streamPauseUnpause", 65, "key.categories.stream");
        this.al = new KeyBinding("key.streamCommercial", 0, "key.categories.stream");
        this.am = new KeyBinding("key.streamToggleMic", 0, "key.categories.stream");
        this.an = new KeyBinding[] { new KeyBinding("key.hotbar.1", 2, "key.categories.inventory"), new KeyBinding("key.hotbar.2", 3, "key.categories.inventory"), new KeyBinding("key.hotbar.3", 4, "key.categories.inventory"), new KeyBinding("key.hotbar.4", 5, "key.categories.inventory"), new KeyBinding("key.hotbar.5", 6, "key.categories.inventory"), new KeyBinding("key.hotbar.6", 7, "key.categories.inventory"), new KeyBinding("key.hotbar.7", 8, "key.categories.inventory"), new KeyBinding("key.hotbar.8", 9, "key.categories.inventory"), new KeyBinding("key.hotbar.9", 10, "key.categories.inventory") };
        this.aG = 1;
        this.aH = 0.8f;
        this.aI = 0;
        this.aJ = false;
        this.aK = false;
        this.aL = Config.aI();
        this.aM = Config.aI();
        this.aN = 1.0f;
        this.aO = 0;
        this.aP = 1;
        this.aQ = 0;
        this.aR = 0.0f;
        this.aS = 0;
        this.aT = 0;
        this.aU = 0;
        this.aV = 3;
        this.aW = 4000;
        this.aX = false;
        this.aY = false;
        this.aZ = false;
        this.ba = true;
        this.bb = true;
        this.bc = true;
        this.bd = true;
        this.be = 0;
        this.bf = 1;
        this.bg = 0;
        this.bh = false;
        this.bi = 0;
        this.bj = false;
        this.bk = false;
        this.bl = "Default";
        this.bm = true;
        this.bn = true;
        this.bo = true;
        this.bp = true;
        this.bq = true;
        this.br = true;
        this.bs = true;
        this.bt = 2;
        this.bu = true;
        this.bv = false;
        this.bw = false;
        this.bx = true;
        this.by = 0;
        this.bz = 0;
        this.bA = 0;
        this.bB = true;
        this.bC = true;
        this.bD = true;
        this.bE = true;
        this.bF = true;
        this.bG = true;
        this.bH = true;
        this.bI = true;
        this.bJ = true;
        this.bK = true;
        this.bL = true;
        this.bM = true;
        this.bN = true;
        this.bO = true;
        this.bP = true;
        this.ao = (KeyBinding[])ArrayUtils.addAll((Object[])new KeyBinding[] { this.Z, this.X, this.P, this.Q, this.R, this.S, this.T, this.U, this.V, this.Y, this.W, this.ab, this.ac, this.aa, this.ad, this.ae, this.af, this.ag, this.aj, this.ak, this.al, this.am, this.ah, this.ai }, (Object[])this.an);
        this.aq = EnumDifficulty.sigma;
        this.aw = "";
        this.az = 70.0f;
        this.aE = "en_US";
        this.aF = false;
    }
    
    public static String zerodayisaminecraftcheat(final int p_74298_0_) {
        return (p_74298_0_ < 0) ? I18n.zerodayisaminecraftcheat("key.mouseButton", p_74298_0_ + 101) : ((p_74298_0_ < 256) ? Keyboard.getKeyName(p_74298_0_) : String.format("%c", (char)(p_74298_0_ - 256)).toUpperCase());
    }
    
    public static boolean zerodayisaminecraftcheat(final KeyBinding p_100015_0_) {
        final int i = p_100015_0_.a();
        return i >= -100 && i <= 255 && p_100015_0_.a() != 0 && ((p_100015_0_.a() < 0) ? Mouse.isButtonDown(p_100015_0_.a() + 100) : Keyboard.isKeyDown(p_100015_0_.a()));
    }
    
    public void zerodayisaminecraftcheat(final KeyBinding p_151440_1_, final int p_151440_2_) {
        p_151440_1_.zeroday(p_151440_2_);
        this.zeroday();
    }
    
    public void zerodayisaminecraftcheat(final zeroday p_74304_1_, final float p_74304_2_) {
        this.zeroday(p_74304_1_, p_74304_2_);
        if (p_74304_1_ == GameSettings.zeroday.zeroday) {
            this.zerodayisaminecraftcheat = p_74304_2_;
        }
        if (p_74304_1_ == GameSettings.zeroday.sigma) {
            this.az = p_74304_2_;
        }
        if (p_74304_1_ == GameSettings.zeroday.pandora) {
            this.aA = p_74304_2_;
        }
        if (p_74304_1_ == GameSettings.zeroday.a) {
            this.vape = (int)p_74304_2_;
            this.l = false;
            if (this.vape <= 0) {
                this.vape = (int)GameSettings.zeroday.a.zues();
                this.l = true;
            }
            this.b();
        }
        if (p_74304_1_ == GameSettings.zeroday.k) {
            this.i = p_74304_2_;
            this.ap.o.pandora().zeroday();
        }
        if (p_74304_1_ == GameSettings.zeroday.t) {
            this.z = p_74304_2_;
            this.ap.o.pandora().zeroday();
        }
        if (p_74304_1_ == GameSettings.zeroday.u) {
            this.y = p_74304_2_;
            this.ap.o.pandora().zeroday();
        }
        if (p_74304_1_ == GameSettings.zeroday.s) {
            this.x = p_74304_2_;
            this.ap.o.pandora().zeroday();
        }
        if (p_74304_1_ == GameSettings.zeroday.r) {
            this.w = p_74304_2_;
            this.ap.o.pandora().zeroday();
        }
        if (p_74304_1_ == GameSettings.zeroday.v) {
            final int i = this.B;
            this.B = (int)p_74304_2_;
            if (i != p_74304_2_) {
                this.ap.M().zerodayisaminecraftcheat(this.B);
                this.ap.I().zerodayisaminecraftcheat(TextureMap.zeroday);
                this.ap.M().zerodayisaminecraftcheat(false, this.B > 0);
                this.ap.t();
            }
        }
        if (p_74304_1_ == GameSettings.zeroday.H) {
            this.n = !this.n;
            this.ap.b.pandora();
        }
        if (p_74304_1_ == GameSettings.zeroday.flux) {
            this.sigma = (int)p_74304_2_;
            this.ap.b.b();
        }
        if (p_74304_1_ == GameSettings.zeroday.x) {
            this.C = p_74304_2_;
        }
        if (p_74304_1_ == GameSettings.zeroday.y) {
            this.D = p_74304_2_;
            this.ap.R().h();
        }
        if (p_74304_1_ == GameSettings.zeroday.z) {
            this.E = p_74304_2_;
            this.ap.R().h();
        }
        if (p_74304_1_ == GameSettings.zeroday.A) {
            this.F = p_74304_2_;
        }
        if (p_74304_1_ == GameSettings.zeroday.B) {
            this.G = p_74304_2_;
        }
    }
    
    public void zerodayisaminecraftcheat(final zeroday p_74306_1_, final int p_74306_2_) {
        this.zeroday(p_74306_1_, p_74306_2_);
        if (p_74306_1_ == GameSettings.zeroday.zerodayisaminecraftcheat) {
            this.zeroday = !this.zeroday;
        }
        if (p_74306_1_ == GameSettings.zeroday.f) {
            this.aC = (this.aC + p_74306_2_ & 0x3);
        }
        if (p_74306_1_ == GameSettings.zeroday.g) {
            this.aD = (this.aD + p_74306_2_) % 3;
        }
        if (p_74306_1_ == GameSettings.zeroday.vape) {
            this.pandora = !this.pandora;
        }
        if (p_74306_1_ == GameSettings.zeroday.c) {
            this.momgetthecamera = (this.momgetthecamera + p_74306_2_) % 3;
        }
        if (p_74306_1_ == GameSettings.zeroday.w) {
            this.aF = !this.aF;
            this.ap.i.zerodayisaminecraftcheat(this.ap.L().zerodayisaminecraftcheat() || this.aF);
        }
        if (p_74306_1_ == GameSettings.zeroday.b) {
            this.flux = !this.flux;
        }
        if (p_74306_1_ == GameSettings.zeroday.momgetthecamera) {
            this.zues = !this.zues;
            this.ap.flux();
        }
        if (p_74306_1_ == GameSettings.zeroday.d) {
            this.a = !this.a;
            this.d();
            this.ap.b.pandora();
        }
        if (p_74306_1_ == GameSettings.zeroday.e) {
            this.b = (this.b + p_74306_2_) % 3;
            this.ap.b.pandora();
        }
        if (p_74306_1_ == GameSettings.zeroday.h) {
            this.e = EntityPlayer.zerodayisaminecraftcheat.zerodayisaminecraftcheat((this.e.zerodayisaminecraftcheat() + p_74306_2_) % 3);
        }
        if (p_74306_1_ == GameSettings.zeroday.C) {
            this.H = (this.H + p_74306_2_) % 3;
        }
        if (p_74306_1_ == GameSettings.zeroday.D) {
            this.I = !this.I;
        }
        if (p_74306_1_ == GameSettings.zeroday.E) {
            this.K = (this.K + p_74306_2_) % 3;
        }
        if (p_74306_1_ == GameSettings.zeroday.F) {
            this.L = (this.L + p_74306_2_) % 3;
        }
        if (p_74306_1_ == GameSettings.zeroday.G) {
            this.M = (this.M + p_74306_2_) % 2;
        }
        if (p_74306_1_ == GameSettings.zeroday.i) {
            this.f = !this.f;
        }
        if (p_74306_1_ == GameSettings.zeroday.j) {
            this.g = !this.g;
        }
        if (p_74306_1_ == GameSettings.zeroday.l) {
            this.h = !this.h;
        }
        if (p_74306_1_ == GameSettings.zeroday.m) {
            this.j = !this.j;
        }
        if (p_74306_1_ == GameSettings.zeroday.q) {
            this.s = !this.s;
        }
        if (p_74306_1_ == GameSettings.zeroday.n) {
            this.k = !this.k;
            if (this.ap.D() != this.k) {
                this.ap.k();
            }
        }
        if (p_74306_1_ == GameSettings.zeroday.o) {
            Display.setVSyncEnabled(this.l = !this.l);
        }
        if (p_74306_1_ == GameSettings.zeroday.p) {
            this.m = !this.m;
            this.ap.b.pandora();
        }
        if (p_74306_1_ == GameSettings.zeroday.H) {
            this.n = !this.n;
            this.ap.b.pandora();
        }
        if (p_74306_1_ == GameSettings.zeroday.I) {
            this.o = !this.o;
        }
        if (p_74306_1_ == GameSettings.zeroday.J) {
            this.O = !this.O;
        }
        this.zeroday();
    }
    
    public float zerodayisaminecraftcheat(final zeroday p_74296_1_) {
        return (p_74296_1_ == GameSettings.zeroday.P) ? this.aR : ((p_74296_1_ == GameSettings.zeroday.W) ? this.aN : ((p_74296_1_ == GameSettings.zeroday.aI) ? ((float)this.aO) : ((p_74296_1_ == GameSettings.zeroday.aJ) ? ((float)this.aP) : ((p_74296_1_ == GameSettings.zeroday.M) ? ((float)this.aI) : ((p_74296_1_ == GameSettings.zeroday.a) ? ((this.vape == GameSettings.zeroday.a.zues() && this.l) ? 0.0f : ((float)this.vape)) : ((p_74296_1_ == GameSettings.zeroday.sigma) ? this.az : ((p_74296_1_ == GameSettings.zeroday.pandora) ? this.aA : ((p_74296_1_ == GameSettings.zeroday.zues) ? this.aB : ((p_74296_1_ == GameSettings.zeroday.zeroday) ? this.zerodayisaminecraftcheat : ((p_74296_1_ == GameSettings.zeroday.k) ? this.i : ((p_74296_1_ == GameSettings.zeroday.t) ? this.z : ((p_74296_1_ == GameSettings.zeroday.u) ? this.y : ((p_74296_1_ == GameSettings.zeroday.r) ? this.w : ((p_74296_1_ == GameSettings.zeroday.s) ? this.x : ((p_74296_1_ == GameSettings.zeroday.a) ? ((float)this.vape) : ((p_74296_1_ == GameSettings.zeroday.v) ? ((float)this.B) : ((p_74296_1_ == GameSettings.zeroday.flux) ? ((float)this.sigma) : ((p_74296_1_ == GameSettings.zeroday.x) ? this.C : ((p_74296_1_ == GameSettings.zeroday.y) ? this.D : ((p_74296_1_ == GameSettings.zeroday.z) ? this.E : ((p_74296_1_ == GameSettings.zeroday.A) ? this.F : ((p_74296_1_ == GameSettings.zeroday.B) ? this.G : 0.0f))))))))))))))))))))));
    }
    
    public boolean zeroday(final zeroday p_74308_1_) {
        switch (GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[p_74308_1_.ordinal()]) {
            case 1: {
                return this.zeroday;
            }
            case 2: {
                return this.pandora;
            }
            case 3: {
                return this.zues;
            }
            case 4: {
                return this.flux;
            }
            case 5: {
                return this.f;
            }
            case 6: {
                return this.g;
            }
            case 7: {
                return this.h;
            }
            case 8: {
                return this.j;
            }
            case 9: {
                return this.k;
            }
            case 10: {
                return this.l;
            }
            case 11: {
                return this.m;
            }
            case 12: {
                return this.s;
            }
            case 13: {
                return this.I;
            }
            case 14: {
                return this.aF;
            }
            case 15: {
                return this.n;
            }
            case 16: {
                return this.o;
            }
            case 17: {
                return this.O;
            }
            default: {
                return false;
            }
        }
    }
    
    private static String zerodayisaminecraftcheat(final String[] p_74299_0_, int p_74299_1_) {
        if (p_74299_1_ < 0 || p_74299_1_ >= p_74299_0_.length) {
            p_74299_1_ = 0;
        }
        return I18n.zerodayisaminecraftcheat(p_74299_0_[p_74299_1_], new Object[0]);
    }
    
    public String sigma(final zeroday p_74297_1_) {
        final String s = this.pandora(p_74297_1_);
        if (s != null) {
            return s;
        }
        final String s2 = String.valueOf(I18n.zerodayisaminecraftcheat(p_74297_1_.pandora(), new Object[0])) + ": ";
        if (p_74297_1_.zerodayisaminecraftcheat()) {
            final float f1 = this.zerodayisaminecraftcheat(p_74297_1_);
            final float f2 = p_74297_1_.zeroday(f1);
            return (p_74297_1_ == GameSettings.zeroday.zeroday) ? ((f2 == 0.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.sensitivity.min", new Object[0])) : ((f2 == 1.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.sensitivity.max", new Object[0])) : (String.valueOf(s2) + (int)(f2 * 200.0f) + "%"))) : ((p_74297_1_ == GameSettings.zeroday.sigma) ? ((f1 == 70.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.fov.min", new Object[0])) : ((f1 == 110.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.fov.max", new Object[0])) : (String.valueOf(s2) + (int)f1))) : ((p_74297_1_ == GameSettings.zeroday.a) ? ((f1 == p_74297_1_.aZ) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.framerateLimit.max", new Object[0])) : (String.valueOf(s2) + (int)f1 + " fps")) : ((p_74297_1_ == GameSettings.zeroday.c) ? ((f1 == p_74297_1_.aY) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.cloudHeight.min", new Object[0])) : (String.valueOf(s2) + ((int)f1 + 128))) : ((p_74297_1_ == GameSettings.zeroday.pandora) ? ((f2 == 0.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.gamma.min", new Object[0])) : ((f2 == 1.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.gamma.max", new Object[0])) : (String.valueOf(s2) + "+" + (int)(f2 * 100.0f) + "%"))) : ((p_74297_1_ == GameSettings.zeroday.zues) ? (String.valueOf(s2) + (int)(f2 * 400.0f) + "%") : ((p_74297_1_ == GameSettings.zeroday.k) ? (String.valueOf(s2) + (int)(f2 * 90.0f + 10.0f) + "%") : ((p_74297_1_ == GameSettings.zeroday.u) ? (String.valueOf(s2) + GuiNewChat.zeroday(f2) + "px") : ((p_74297_1_ == GameSettings.zeroday.t) ? (String.valueOf(s2) + GuiNewChat.zeroday(f2) + "px") : ((p_74297_1_ == GameSettings.zeroday.s) ? (String.valueOf(s2) + GuiNewChat.zerodayisaminecraftcheat(f2) + "px") : ((p_74297_1_ == GameSettings.zeroday.flux) ? (String.valueOf(s2) + (int)f1 + " chunks") : ((p_74297_1_ == GameSettings.zeroday.v) ? ((f1 == 0.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.off", new Object[0])) : (String.valueOf(s2) + (int)f1)) : ((p_74297_1_ == GameSettings.zeroday.B) ? (String.valueOf(s2) + TwitchStream.zerodayisaminecraftcheat(f2) + " fps") : ((p_74297_1_ == GameSettings.zeroday.A) ? (String.valueOf(s2) + TwitchStream.zeroday(f2) + " Kbps") : ((p_74297_1_ == GameSettings.zeroday.x) ? (String.valueOf(s2) + String.format("%.3f bpp", TwitchStream.sigma(f2))) : ((f2 == 0.0f) ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.off", new Object[0])) : (String.valueOf(s2) + (int)(f2 * 100.0f) + "%"))))))))))))))));
        }
        if (p_74297_1_.zeroday()) {
            final boolean flag = this.zeroday(p_74297_1_);
            return flag ? (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.on", new Object[0])) : (String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.off", new Object[0]));
        }
        if (p_74297_1_ == GameSettings.zeroday.f) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.cf, this.aC);
        }
        if (p_74297_1_ == GameSettings.zeroday.h) {
            return String.valueOf(s2) + I18n.zerodayisaminecraftcheat(this.e.zeroday(), new Object[0]);
        }
        if (p_74297_1_ == GameSettings.zeroday.g) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.cg, this.aD);
        }
        if (p_74297_1_ == GameSettings.zeroday.e) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.ch, this.b);
        }
        if (p_74297_1_ == GameSettings.zeroday.C) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.ci, this.H);
        }
        if (p_74297_1_ == GameSettings.zeroday.E) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.cj, this.K);
        }
        if (p_74297_1_ == GameSettings.zeroday.F) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.ck, this.L);
        }
        if (p_74297_1_ == GameSettings.zeroday.G) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.cl, this.M);
        }
        if (p_74297_1_ == GameSettings.zeroday.c) {
            return String.valueOf(s2) + zerodayisaminecraftcheat(GameSettings.cm, this.momgetthecamera);
        }
        if (p_74297_1_ != GameSettings.zeroday.d) {
            return s2;
        }
        if (this.a) {
            return String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.graphics.fancy", new Object[0]);
        }
        final String s3 = "options.graphics.fast";
        return String.valueOf(s2) + I18n.zerodayisaminecraftcheat("options.graphics.fast", new Object[0]);
    }
    
    public void zerodayisaminecraftcheat() {
        try {
            if (!this.cp.exists()) {
                return;
            }
            final BufferedReader bufferedreader = new BufferedReader(new FileReader(this.cp));
            String s = "";
            this.co.clear();
            while ((s = bufferedreader.readLine()) != null) {
                try {
                    final String[] astring = s.split(":");
                    if (astring[0].equals("mouseSensitivity")) {
                        this.zerodayisaminecraftcheat = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("fov")) {
                        this.az = this.zerodayisaminecraftcheat(astring[1]) * 40.0f + 70.0f;
                    }
                    if (astring[0].equals("gamma")) {
                        this.aA = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("saturation")) {
                        this.aB = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("invertYMouse")) {
                        this.zeroday = astring[1].equals("true");
                    }
                    if (astring[0].equals("renderDistance")) {
                        this.sigma = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("guiScale")) {
                        this.aC = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("particles")) {
                        this.aD = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("bobView")) {
                        this.pandora = astring[1].equals("true");
                    }
                    if (astring[0].equals("anaglyph3d")) {
                        this.zues = astring[1].equals("true");
                    }
                    if (astring[0].equals("maxFps")) {
                        this.vape = Integer.parseInt(astring[1]);
                        this.l = false;
                        if (this.vape <= 0) {
                            this.vape = (int)GameSettings.zeroday.a.zues();
                            this.l = true;
                        }
                        this.b();
                    }
                    if (astring[0].equals("fboEnable")) {
                        this.flux = astring[1].equals("true");
                    }
                    if (astring[0].equals("difficulty")) {
                        this.aq = EnumDifficulty.zerodayisaminecraftcheat(Integer.parseInt(astring[1]));
                    }
                    if (astring[0].equals("fancyGraphics")) {
                        this.a = astring[1].equals("true");
                        this.d();
                    }
                    if (astring[0].equals("ao")) {
                        if (astring[1].equals("true")) {
                            this.b = 2;
                        }
                        else if (astring[1].equals("false")) {
                            this.b = 0;
                        }
                        else {
                            this.b = Integer.parseInt(astring[1]);
                        }
                    }
                    if (astring[0].equals("renderClouds")) {
                        if (astring[1].equals("true")) {
                            this.momgetthecamera = 2;
                        }
                        else if (astring[1].equals("false")) {
                            this.momgetthecamera = 0;
                        }
                        else if (astring[1].equals("fast")) {
                            this.momgetthecamera = 1;
                        }
                    }
                    if (astring[0].equals("resourcePacks")) {
                        this.c = (List)GameSettings.cd.fromJson(s.substring(s.indexOf(58) + 1), (Type)GameSettings.ce);
                        if (this.c == null) {
                            this.c = Lists.newArrayList();
                        }
                    }
                    if (astring[0].equals("incompatibleResourcePacks")) {
                        this.d = (List)GameSettings.cd.fromJson(s.substring(s.indexOf(58) + 1), (Type)GameSettings.ce);
                        if (this.d == null) {
                            this.d = Lists.newArrayList();
                        }
                    }
                    if (astring[0].equals("lastServer") && astring.length >= 2) {
                        this.aw = s.substring(s.indexOf(58) + 1);
                    }
                    if (astring[0].equals("lang") && astring.length >= 2) {
                        this.aE = astring[1];
                    }
                    if (astring[0].equals("chatVisibility")) {
                        this.e = EntityPlayer.zerodayisaminecraftcheat.zerodayisaminecraftcheat(Integer.parseInt(astring[1]));
                    }
                    if (astring[0].equals("chatColors")) {
                        this.f = astring[1].equals("true");
                    }
                    if (astring[0].equals("chatLinks")) {
                        this.g = astring[1].equals("true");
                    }
                    if (astring[0].equals("chatLinksPrompt")) {
                        this.h = astring[1].equals("true");
                    }
                    if (astring[0].equals("chatOpacity")) {
                        this.i = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("snooperEnabled")) {
                        this.j = astring[1].equals("true");
                    }
                    if (astring[0].equals("fullscreen")) {
                        this.k = astring[1].equals("true");
                    }
                    if (astring[0].equals("enableVsync")) {
                        this.l = astring[1].equals("true");
                        this.b();
                    }
                    if (astring[0].equals("useVbo")) {
                        this.m = astring[1].equals("true");
                    }
                    if (astring[0].equals("hideServerAddress")) {
                        this.p = astring[1].equals("true");
                    }
                    if (astring[0].equals("advancedItemTooltips")) {
                        this.q = astring[1].equals("true");
                    }
                    if (astring[0].equals("pauseOnLostFocus")) {
                        this.r = astring[1].equals("true");
                    }
                    if (astring[0].equals("touchscreen")) {
                        this.s = astring[1].equals("true");
                    }
                    if (astring[0].equals("overrideHeight")) {
                        this.u = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("overrideWidth")) {
                        this.t = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("heldItemTooltips")) {
                        this.v = astring[1].equals("true");
                    }
                    if (astring[0].equals("chatHeightFocused")) {
                        this.z = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("chatHeightUnfocused")) {
                        this.y = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("chatScale")) {
                        this.w = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("chatWidth")) {
                        this.x = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("showInventoryAchievementHint")) {
                        this.A = astring[1].equals("true");
                    }
                    if (astring[0].equals("mipmapLevels")) {
                        this.B = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("streamBytesPerPixel")) {
                        this.C = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("streamMicVolume")) {
                        this.D = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("streamSystemVolume")) {
                        this.E = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("streamKbps")) {
                        this.F = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("streamFps")) {
                        this.G = this.zerodayisaminecraftcheat(astring[1]);
                    }
                    if (astring[0].equals("streamCompression")) {
                        this.H = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("streamSendMetadata")) {
                        this.I = astring[1].equals("true");
                    }
                    if (astring[0].equals("streamPreferredServer") && astring.length >= 2) {
                        this.J = s.substring(s.indexOf(58) + 1);
                    }
                    if (astring[0].equals("streamChatEnabled")) {
                        this.K = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("streamChatUserFilter")) {
                        this.L = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("streamMicToggleBehavior")) {
                        this.M = Integer.parseInt(astring[1]);
                    }
                    if (astring[0].equals("forceUnicodeFont")) {
                        this.aF = astring[1].equals("true");
                    }
                    if (astring[0].equals("allowBlockAlternatives")) {
                        this.n = astring[1].equals("true");
                    }
                    if (astring[0].equals("reducedDebugInfo")) {
                        this.o = astring[1].equals("true");
                    }
                    if (astring[0].equals("useNativeTransport")) {
                        this.N = astring[1].equals("true");
                    }
                    if (astring[0].equals("entityShadows")) {
                        this.O = astring[1].equals("true");
                    }
                    KeyBinding[] ao;
                    for (int length = (ao = this.ao).length, i = 0; i < length; ++i) {
                        final KeyBinding keybinding = ao[i];
                        if (astring[0].equals("key_" + keybinding.vape())) {
                            keybinding.zeroday(Integer.parseInt(astring[1]));
                        }
                    }
                    SoundCategory[] values;
                    for (int length2 = (values = SoundCategory.values()).length, j = 0; j < length2; ++j) {
                        final SoundCategory soundcategory = values[j];
                        if (astring[0].equals("soundCategory_" + soundcategory.zerodayisaminecraftcheat())) {
                            this.co.put(soundcategory, this.zerodayisaminecraftcheat(astring[1]));
                        }
                    }
                    EnumPlayerModelParts[] values2;
                    for (int length3 = (values2 = EnumPlayerModelParts.values()).length, k = 0; k < length3; ++k) {
                        final EnumPlayerModelParts enumplayermodelparts = values2[k];
                        if (astring[0].equals("modelPart_" + enumplayermodelparts.sigma())) {
                            this.zerodayisaminecraftcheat(enumplayermodelparts, astring[1].equals("true"));
                        }
                    }
                }
                catch (Exception exception) {
                    GameSettings.cc.warn("Skipping bad option: " + s);
                    exception.printStackTrace();
                }
            }
            KeyBinding.zeroday();
            bufferedreader.close();
        }
        catch (Exception exception2) {
            GameSettings.cc.error("Failed to load options", (Throwable)exception2);
        }
        this.vape();
    }
    
    private float zerodayisaminecraftcheat(final String p_74305_1_) {
        return p_74305_1_.equals("true") ? 1.0f : (p_74305_1_.equals("false") ? 0.0f : Float.parseFloat(p_74305_1_));
    }
    
    public void zeroday() {
        if (Reflector.G.zeroday()) {
            final Object object = Reflector.vape(Reflector.H, new Object[0]);
            if (object != null && Reflector.zeroday(object, Reflector.I, new Object[0])) {
                return;
            }
        }
        try {
            final PrintWriter printwriter = new PrintWriter(new FileWriter(this.cp));
            printwriter.println("invertYMouse:" + this.zeroday);
            printwriter.println("mouseSensitivity:" + this.zerodayisaminecraftcheat);
            printwriter.println("fov:" + (this.az - 70.0f) / 40.0f);
            printwriter.println("gamma:" + this.aA);
            printwriter.println("saturation:" + this.aB);
            printwriter.println("renderDistance:" + this.sigma);
            printwriter.println("guiScale:" + this.aC);
            printwriter.println("particles:" + this.aD);
            printwriter.println("bobView:" + this.pandora);
            printwriter.println("anaglyph3d:" + this.zues);
            printwriter.println("maxFps:" + this.vape);
            printwriter.println("fboEnable:" + this.flux);
            printwriter.println("difficulty:" + this.aq.zerodayisaminecraftcheat());
            printwriter.println("fancyGraphics:" + this.a);
            printwriter.println("ao:" + this.b);
            switch (this.momgetthecamera) {
                case 0: {
                    printwriter.println("renderClouds:false");
                    break;
                }
                case 1: {
                    printwriter.println("renderClouds:fast");
                    break;
                }
                case 2: {
                    printwriter.println("renderClouds:true");
                    break;
                }
            }
            printwriter.println("resourcePacks:" + GameSettings.cd.toJson((Object)this.c));
            printwriter.println("incompatibleResourcePacks:" + GameSettings.cd.toJson((Object)this.d));
            printwriter.println("lastServer:" + this.aw);
            printwriter.println("lang:" + this.aE);
            printwriter.println("chatVisibility:" + this.e.zerodayisaminecraftcheat());
            printwriter.println("chatColors:" + this.f);
            printwriter.println("chatLinks:" + this.g);
            printwriter.println("chatLinksPrompt:" + this.h);
            printwriter.println("chatOpacity:" + this.i);
            printwriter.println("snooperEnabled:" + this.j);
            printwriter.println("fullscreen:" + this.k);
            printwriter.println("enableVsync:" + this.l);
            printwriter.println("useVbo:" + this.m);
            printwriter.println("hideServerAddress:" + this.p);
            printwriter.println("advancedItemTooltips:" + this.q);
            printwriter.println("pauseOnLostFocus:" + this.r);
            printwriter.println("touchscreen:" + this.s);
            printwriter.println("overrideWidth:" + this.t);
            printwriter.println("overrideHeight:" + this.u);
            printwriter.println("heldItemTooltips:" + this.v);
            printwriter.println("chatHeightFocused:" + this.z);
            printwriter.println("chatHeightUnfocused:" + this.y);
            printwriter.println("chatScale:" + this.w);
            printwriter.println("chatWidth:" + this.x);
            printwriter.println("showInventoryAchievementHint:" + this.A);
            printwriter.println("mipmapLevels:" + this.B);
            printwriter.println("streamBytesPerPixel:" + this.C);
            printwriter.println("streamMicVolume:" + this.D);
            printwriter.println("streamSystemVolume:" + this.E);
            printwriter.println("streamKbps:" + this.F);
            printwriter.println("streamFps:" + this.G);
            printwriter.println("streamCompression:" + this.H);
            printwriter.println("streamSendMetadata:" + this.I);
            printwriter.println("streamPreferredServer:" + this.J);
            printwriter.println("streamChatEnabled:" + this.K);
            printwriter.println("streamChatUserFilter:" + this.L);
            printwriter.println("streamMicToggleBehavior:" + this.M);
            printwriter.println("forceUnicodeFont:" + this.aF);
            printwriter.println("allowBlockAlternatives:" + this.n);
            printwriter.println("reducedDebugInfo:" + this.o);
            printwriter.println("useNativeTransport:" + this.N);
            printwriter.println("entityShadows:" + this.O);
            KeyBinding[] ao;
            for (int length = (ao = this.ao).length, i = 0; i < length; ++i) {
                final KeyBinding keybinding = ao[i];
                printwriter.println("key_" + keybinding.vape() + ":" + keybinding.a());
            }
            SoundCategory[] values;
            for (int length2 = (values = SoundCategory.values()).length, j = 0; j < length2; ++j) {
                final SoundCategory soundcategory = values[j];
                printwriter.println("soundCategory_" + soundcategory.zerodayisaminecraftcheat() + ":" + this.zerodayisaminecraftcheat(soundcategory));
            }
            EnumPlayerModelParts[] values2;
            for (int length3 = (values2 = EnumPlayerModelParts.values()).length, k = 0; k < length3; ++k) {
                final EnumPlayerModelParts enumplayermodelparts = values2[k];
                printwriter.println("modelPart_" + enumplayermodelparts.sigma() + ":" + this.cn.contains(enumplayermodelparts));
            }
            printwriter.close();
        }
        catch (Exception exception) {
            GameSettings.cc.error("Failed to save options", (Throwable)exception);
        }
        this.momgetthecamera();
        this.sigma();
    }
    
    public float zerodayisaminecraftcheat(final SoundCategory p_151438_1_) {
        return this.co.containsKey(p_151438_1_) ? this.co.get(p_151438_1_) : 1.0f;
    }
    
    public void zerodayisaminecraftcheat(final SoundCategory p_151439_1_, final float p_151439_2_) {
        this.ap.P().zerodayisaminecraftcheat(p_151439_1_, p_151439_2_);
        this.co.put(p_151439_1_, p_151439_2_);
    }
    
    public void sigma() {
        if (this.ap.e != null) {
            int i = 0;
            for (final Object enumplayermodelparts : this.cn) {
                i |= ((EnumPlayerModelParts)enumplayermodelparts).zerodayisaminecraftcheat();
            }
            this.ap.e.zerodayisaminecraftcheat.zerodayisaminecraftcheat(new C15PacketClientSettings(this.aE, this.sigma, this.e, this.f, i));
        }
    }
    
    public Set pandora() {
        return (Set)ImmutableSet.copyOf((Collection)this.cn);
    }
    
    public void zerodayisaminecraftcheat(final EnumPlayerModelParts p_178878_1_, final boolean p_178878_2_) {
        if (p_178878_2_) {
            this.cn.add(p_178878_1_);
        }
        else {
            this.cn.remove(p_178878_1_);
        }
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final EnumPlayerModelParts p_178877_1_) {
        if (!this.pandora().contains(p_178877_1_)) {
            this.cn.add(p_178877_1_);
        }
        else {
            this.cn.remove(p_178877_1_);
        }
        this.sigma();
    }
    
    public int zues() {
        return (this.sigma >= 4) ? this.momgetthecamera : 0;
    }
    
    public boolean flux() {
        return this.N;
    }
    
    private void zeroday(final zeroday p_setOptionFloatValueOF_1_, final float p_setOptionFloatValueOF_2_) {
        if (p_setOptionFloatValueOF_1_ == GameSettings.zeroday.P) {
            this.aR = p_setOptionFloatValueOF_2_;
            this.ap.b.c();
        }
        if (p_setOptionFloatValueOF_1_ == GameSettings.zeroday.W) {
            this.aN = p_setOptionFloatValueOF_2_;
            this.ap.b.pandora();
        }
        if (p_setOptionFloatValueOF_1_ == GameSettings.zeroday.aI) {
            final int i = (int)p_setOptionFloatValueOF_2_;
            if (i > 0 && Config.aC()) {
                Config.sigma("Antialiasing is not compatible with Shaders.", "Please disable Shaders to enable this option.");
                return;
            }
            final int[] aint = { 0, 2, 4, 6, 8, 12, 16 };
            this.aO = 0;
            for (int j = 0; j < aint.length; ++j) {
                if (i >= aint[j]) {
                    this.aO = aint[j];
                }
            }
            this.aO = Config.zerodayisaminecraftcheat(this.aO, 0, 16);
        }
        if (p_setOptionFloatValueOF_1_ == GameSettings.zeroday.aJ) {
            final int k = (int)p_setOptionFloatValueOF_2_;
            if (k > 1 && Config.aC()) {
                Config.sigma("Anisotropic Filtering is not compatible with Shaders.", "Please disable Shaders to enable this option.");
                return;
            }
            this.aP = 1;
            while (this.aP * 2 <= k) {
                this.aP *= 2;
            }
            this.aP = Config.zerodayisaminecraftcheat(this.aP, 1, 16);
            this.ap.flux();
        }
        if (p_setOptionFloatValueOF_1_ == GameSettings.zeroday.M) {
            final int l = (int)p_setOptionFloatValueOF_2_;
            this.aI = Config.zerodayisaminecraftcheat(l, 0, 3);
            this.ap.flux();
        }
    }
    
    private void zeroday(final zeroday p_setOptionValueOF_1_, final int p_setOptionValueOF_2_) {
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.K) {
            switch (this.aG) {
                case 1: {
                    this.aG = 2;
                    if (!Config.zues()) {
                        this.aG = 3;
                        break;
                    }
                    break;
                }
                case 2: {
                    this.aG = 3;
                    break;
                }
                case 3: {
                    this.aG = 1;
                    break;
                }
                default: {
                    this.aG = 1;
                    break;
                }
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.L) {
            this.aH += 0.2f;
            if (this.aH > 0.81f) {
                this.aH = 0.2f;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.N) {
            this.aK = !this.aK;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ao) {
            this.aL = !this.aL;
            Config.momgetthecamera();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.O) {
            ++this.aQ;
            if (this.aQ > 3) {
                this.aQ = 0;
            }
            this.d();
            this.ap.b.c();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.Q) {
            ++this.aS;
            if (this.aS > 2) {
                this.aS = 0;
            }
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aO) {
            ++this.aU;
            if (this.aU > 2) {
                this.aU = 0;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.R) {
            ++this.aT;
            if (this.aT > 3) {
                this.aT = 0;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.S) {
            ++this.bz;
            if (this.bz > 2) {
                this.bz = 0;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.T) {
            ++this.bA;
            if (this.bA > 2) {
                this.bA = 0;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.U) {
            this.bB = !this.bB;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.V) {
            this.bC = !this.bC;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ab) {
            this.bD = !this.bD;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ac) {
            this.bE = !this.bE;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ad) {
            this.bF = !this.bF;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ae) {
            this.bG = !this.bG;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ap) {
            this.bH = !this.bH;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aq) {
            this.bI = !this.bI;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.as) {
            this.bK = !this.bK;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.at) {
            this.bL = !this.bL;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.au) {
            this.bM = !this.bM;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aw) {
            this.bN = !this.bN;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.az) {
            this.bO = !this.bO;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aK) {
            this.bP = !this.bP;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ar) {
            this.bJ = !this.bJ;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.X) {
            this.aX = !this.aX;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.Y) {
            this.aZ = !this.aZ;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.Z) {
            this.aW *= 10;
            if (this.aW > 40000) {
                this.aW = 40;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aa) {
            ++this.aV;
            if (this.aV > 3) {
                this.aV = 1;
            }
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aG) {
            ++this.bt;
            if (this.bt > 3) {
                this.bt = 1;
            }
            if (this.bt != 2) {
                this.ap.flux();
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.af) {
            this.ba = !this.ba;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ag) {
            this.bb = !this.bb;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ah) {
            this.bc = !this.bc;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ai) {
            this.bd = !this.bd;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aj) {
            ++this.be;
            if (this.be > 2) {
                this.be = 0;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ak) {
            ++this.bf;
            if (this.bf > 5) {
                this.bf = 1;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aM) {
            ++this.bg;
            if (this.bg > 2) {
                this.bg = 0;
            }
            this.c();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.al) {
            this.bh = !this.bh;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.am) {
            ++this.bi;
            if (this.bi > 3) {
                this.bi = 0;
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.an) {
            this.bj = !this.bj;
            this.e();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.av) {
            this.aY = !this.aY;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ax) {
            this.bk = !this.bk;
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aA) {
            this.bm = !this.bm;
            CustomColorizer.zeroday();
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aB) {
            this.bn = !this.bn;
            RandomMobs.zerodayisaminecraftcheat();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aC) {
            this.bo = !this.bo;
            CustomColorizer.zeroday();
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aD) {
            this.bp = !this.bp;
            this.ap.i.zerodayisaminecraftcheat(Config.M());
            this.ap.j.zerodayisaminecraftcheat(Config.M());
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aE) {
            this.bq = !this.bq;
            CustomColorizer.zerodayisaminecraftcheat();
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aH) {
            this.bu = !this.bu;
            this.ap.flux();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aQ) {
            this.br = !this.br;
            CustomSky.zeroday();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aF) {
            this.bs = !this.bs;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aL) {
            this.bv = !this.bv;
            NaturalTextures.zerodayisaminecraftcheat();
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aR) {
            this.bw = !this.bw;
            MathHelper.flux = this.bw;
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aS) {
            if (!this.bx && Config.aC()) {
                Config.sigma("Fast Render is not compatible with Shaders.", "Please disable Shaders to enable this option.");
                return;
            }
            this.bx = !this.bx;
            if (this.bx) {
                this.ap.m.zeroday();
            }
            Config.aO();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aT) {
            if (this.by == 0) {
                this.by = 1;
            }
            else if (this.by == 1) {
                this.by = 2;
            }
            else if (this.by == 2) {
                this.by = 0;
            }
            else {
                this.by = 0;
            }
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aP) {
            this.aM = !this.aM;
            Config.aH();
            if (!Config.aI()) {
                this.aM = false;
            }
            this.ap.b.pandora();
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.ay) {
            final List list = Arrays.asList(Config.an());
            if (this.bl.equals("Default")) {
                this.bl = list.get(0);
            }
            else {
                int i = list.indexOf(this.bl);
                if (i < 0) {
                    this.bl = "Default";
                }
                else if (++i >= list.size()) {
                    this.bl = "Default";
                }
                else {
                    this.bl = list.get(i);
                }
            }
        }
        if (p_setOptionValueOF_1_ == GameSettings.zeroday.aN) {
            this.v = !this.v;
        }
    }
    
    private String pandora(final zeroday p_getKeyBindingOF_1_) {
        String s = String.valueOf(I18n.zerodayisaminecraftcheat(p_getKeyBindingOF_1_.pandora(), new Object[0])) + ": ";
        if (s == null) {
            s = p_getKeyBindingOF_1_.pandora();
        }
        if (p_getKeyBindingOF_1_ == GameSettings.zeroday.flux) {
            final int k = (int)this.zerodayisaminecraftcheat(p_getKeyBindingOF_1_);
            String s2 = "Tiny";
            int i = 2;
            if (k >= 4) {
                s2 = "Short";
                i = 4;
            }
            if (k >= 8) {
                s2 = "Normal";
                i = 8;
            }
            if (k >= 16) {
                s2 = "Far";
                i = 16;
            }
            if (k >= 32) {
                s2 = "Extreme";
                i = 32;
            }
            final int j = this.sigma - i;
            String s3 = s2;
            if (j > 0) {
                s3 = String.valueOf(s2) + "+";
            }
            return String.valueOf(s) + k + " " + s3;
        }
        if (p_getKeyBindingOF_1_ == GameSettings.zeroday.K) {
            switch (this.aG) {
                case 1: {
                    return String.valueOf(s) + "Fast";
                }
                case 2: {
                    return String.valueOf(s) + "Fancy";
                }
                case 3: {
                    return String.valueOf(s) + "OFF";
                }
                default: {
                    return String.valueOf(s) + "OFF";
                }
            }
        }
        else {
            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.L) {
                return String.valueOf(s) + this.aH;
            }
            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.M) {
                switch (this.aI) {
                    case 0: {
                        return String.valueOf(s) + "Nearest";
                    }
                    case 1: {
                        return String.valueOf(s) + "Linear";
                    }
                    case 2: {
                        return String.valueOf(s) + "Bilinear";
                    }
                    case 3: {
                        return String.valueOf(s) + "Trilinear";
                    }
                    default: {
                        return String.valueOf(s) + "Nearest";
                    }
                }
            }
            else {
                if (p_getKeyBindingOF_1_ == GameSettings.zeroday.N) {
                    return this.aK ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                }
                if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ao) {
                    return this.aL ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                }
                if (p_getKeyBindingOF_1_ == GameSettings.zeroday.O) {
                    switch (this.aQ) {
                        case 1: {
                            return String.valueOf(s) + "Fast";
                        }
                        case 2: {
                            return String.valueOf(s) + "Fancy";
                        }
                        case 3: {
                            return String.valueOf(s) + "OFF";
                        }
                        default: {
                            return String.valueOf(s) + "Default";
                        }
                    }
                }
                else if (p_getKeyBindingOF_1_ == GameSettings.zeroday.Q) {
                    switch (this.aS) {
                        case 1: {
                            return String.valueOf(s) + "Fast";
                        }
                        case 2: {
                            return String.valueOf(s) + "Fancy";
                        }
                        default: {
                            return String.valueOf(s) + "Default";
                        }
                    }
                }
                else if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aO) {
                    switch (this.aU) {
                        case 1: {
                            return String.valueOf(s) + "Fast";
                        }
                        case 2: {
                            return String.valueOf(s) + "Fancy";
                        }
                        default: {
                            return String.valueOf(s) + "Default";
                        }
                    }
                }
                else if (p_getKeyBindingOF_1_ == GameSettings.zeroday.R) {
                    switch (this.aT) {
                        case 1: {
                            return String.valueOf(s) + "Fast";
                        }
                        case 2: {
                            return String.valueOf(s) + "Fancy";
                        }
                        case 3: {
                            return String.valueOf(s) + "OFF";
                        }
                        default: {
                            return String.valueOf(s) + "Default";
                        }
                    }
                }
                else if (p_getKeyBindingOF_1_ == GameSettings.zeroday.S) {
                    switch (this.bz) {
                        case 1: {
                            return String.valueOf(s) + "Dynamic";
                        }
                        case 2: {
                            return String.valueOf(s) + "OFF";
                        }
                        default: {
                            return String.valueOf(s) + "ON";
                        }
                    }
                }
                else if (p_getKeyBindingOF_1_ == GameSettings.zeroday.T) {
                    switch (this.bA) {
                        case 1: {
                            return String.valueOf(s) + "Dynamic";
                        }
                        case 2: {
                            return String.valueOf(s) + "OFF";
                        }
                        default: {
                            return String.valueOf(s) + "ON";
                        }
                    }
                }
                else {
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.U) {
                        return this.bB ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.V) {
                        return this.bC ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ab) {
                        return this.bD ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ac) {
                        return this.bE ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ad) {
                        return this.bF ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ae) {
                        return this.bG ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ap) {
                        return this.bH ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aq) {
                        return this.bI ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.as) {
                        return this.bK ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.at) {
                        return this.bL ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.au) {
                        return this.bM ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aw) {
                        return this.bN ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.az) {
                        return this.bO ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aK) {
                        return this.bP ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ar) {
                        return this.bJ ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.X) {
                        return this.aX ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.Y) {
                        return this.aZ ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.Z) {
                        return (this.aW <= 40) ? (String.valueOf(s) + "Default (2s)") : ((this.aW <= 400) ? (String.valueOf(s) + "20s") : ((this.aW <= 4000) ? (String.valueOf(s) + "3min") : (String.valueOf(s) + "30min")));
                    }
                    if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aa) {
                        switch (this.aV) {
                            case 1: {
                                return String.valueOf(s) + "Fast";
                            }
                            case 2: {
                                return String.valueOf(s) + "Fancy";
                            }
                            default: {
                                return String.valueOf(s) + "OFF";
                            }
                        }
                    }
                    else if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aG) {
                        switch (this.bt) {
                            case 1: {
                                return String.valueOf(s) + "Fast";
                            }
                            case 2: {
                                return String.valueOf(s) + "Fancy";
                            }
                            default: {
                                return String.valueOf(s) + "OFF";
                            }
                        }
                    }
                    else {
                        if (p_getKeyBindingOF_1_ == GameSettings.zeroday.af) {
                            return this.ba ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                        }
                        if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ag) {
                            return this.bb ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                        }
                        if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ah) {
                            return this.bc ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                        }
                        if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ai) {
                            return this.bd ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                        }
                        if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aj) {
                            switch (this.be) {
                                case 1: {
                                    return String.valueOf(s) + "Fast";
                                }
                                case 2: {
                                    return String.valueOf(s) + "Fancy";
                                }
                                default: {
                                    return String.valueOf(s) + "Default";
                                }
                            }
                        }
                        else {
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ak) {
                                return String.valueOf(s) + this.bf;
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aM) {
                                return (this.bg == 1) ? (String.valueOf(s) + "Smooth") : ((this.bg == 2) ? (String.valueOf(s) + "Multi-Core") : (String.valueOf(s) + "Default"));
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.al) {
                                return this.bh ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.am) {
                                return (this.bi == 1) ? (String.valueOf(s) + "Day Only") : ((this.bi == 3) ? (String.valueOf(s) + "Night Only") : (String.valueOf(s) + "Default"));
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.an) {
                                return this.bj ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aI) {
                                String s4 = "";
                                if (this.aO != Config.ae()) {
                                    s4 = " (restart)";
                                }
                                return (this.aO == 0) ? (String.valueOf(s) + "OFF" + s4) : (String.valueOf(s) + this.aO + s4);
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aJ) {
                                return (this.aP == 1) ? (String.valueOf(s) + "OFF") : (String.valueOf(s) + this.aP);
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.av) {
                                return this.aY ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ax) {
                                return this.bk ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aA) {
                                return this.bm ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aB) {
                                return this.bn ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aC) {
                                return this.bo ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aD) {
                                return this.bp ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aE) {
                                return this.bq ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aQ) {
                                return this.br ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aF) {
                                return this.bs ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aH) {
                                return this.bu ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aL) {
                                return this.bv ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aR) {
                                return this.bw ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aS) {
                                return this.bx ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aT) {
                                return (this.by == 1) ? (String.valueOf(s) + "Fast") : ((this.by == 2) ? (String.valueOf(s) + "Fancy") : (String.valueOf(s) + "Default"));
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aP) {
                                return this.aM ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.ay) {
                                return String.valueOf(s) + this.bl;
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.aN) {
                                return this.v ? (String.valueOf(s) + "ON") : (String.valueOf(s) + "OFF");
                            }
                            if (p_getKeyBindingOF_1_ == GameSettings.zeroday.a) {
                                final float f = this.zerodayisaminecraftcheat(p_getKeyBindingOF_1_);
                                return (f == 0.0f) ? (String.valueOf(s) + "VSync") : ((f == p_getKeyBindingOF_1_.aZ) ? (String.valueOf(s) + I18n.zerodayisaminecraftcheat("options.framerateLimit.max", new Object[0])) : (String.valueOf(s) + (int)f + " fps"));
                            }
                            return null;
                        }
                    }
                }
            }
        }
    }
    
    public void vape() {
        try {
            File file1 = this.cr;
            if (!file1.exists()) {
                file1 = this.cp;
            }
            if (!file1.exists()) {
                return;
            }
            final BufferedReader bufferedreader = new BufferedReader(new FileReader(file1));
            String s = "";
            while ((s = bufferedreader.readLine()) != null) {
                try {
                    final String[] astring = s.split(":");
                    if (astring[0].equals("ofRenderDistanceChunks") && astring.length >= 2) {
                        this.sigma = Integer.valueOf(astring[1]);
                        this.sigma = Config.zerodayisaminecraftcheat(this.sigma, 2, 32);
                    }
                    if (astring[0].equals("ofFogType") && astring.length >= 2) {
                        this.aG = Integer.valueOf(astring[1]);
                        this.aG = Config.zerodayisaminecraftcheat(this.aG, 1, 3);
                    }
                    if (astring[0].equals("ofFogStart") && astring.length >= 2) {
                        this.aH = Float.valueOf(astring[1]);
                        if (this.aH < 0.2f) {
                            this.aH = 0.2f;
                        }
                        if (this.aH > 0.81f) {
                            this.aH = 0.8f;
                        }
                    }
                    if (astring[0].equals("ofMipmapType") && astring.length >= 2) {
                        this.aI = Integer.valueOf(astring[1]);
                        this.aI = Config.zerodayisaminecraftcheat(this.aI, 0, 3);
                    }
                    if (astring[0].equals("ofOcclusionFancy") && astring.length >= 2) {
                        this.aJ = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofSmoothFps") && astring.length >= 2) {
                        this.aK = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofSmoothWorld") && astring.length >= 2) {
                        this.aL = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAoLevel") && astring.length >= 2) {
                        this.aN = Float.valueOf(astring[1]);
                        this.aN = Config.zerodayisaminecraftcheat(this.aN, 0.0f, 1.0f);
                    }
                    if (astring[0].equals("ofClouds") && astring.length >= 2) {
                        this.aQ = Integer.valueOf(astring[1]);
                        this.aQ = Config.zerodayisaminecraftcheat(this.aQ, 0, 3);
                        this.d();
                    }
                    if (astring[0].equals("ofCloudsHeight") && astring.length >= 2) {
                        this.aR = Float.valueOf(astring[1]);
                        this.aR = Config.zerodayisaminecraftcheat(this.aR, 0.0f, 1.0f);
                    }
                    if (astring[0].equals("ofTrees") && astring.length >= 2) {
                        this.aS = Integer.valueOf(astring[1]);
                        this.aS = Config.zerodayisaminecraftcheat(this.aS, 0, 2);
                    }
                    if (astring[0].equals("ofDroppedItems") && astring.length >= 2) {
                        this.aU = Integer.valueOf(astring[1]);
                        this.aU = Config.zerodayisaminecraftcheat(this.aU, 0, 2);
                    }
                    if (astring[0].equals("ofRain") && astring.length >= 2) {
                        this.aT = Integer.valueOf(astring[1]);
                        this.aT = Config.zerodayisaminecraftcheat(this.aT, 0, 3);
                    }
                    if (astring[0].equals("ofAnimatedWater") && astring.length >= 2) {
                        this.bz = Integer.valueOf(astring[1]);
                        this.bz = Config.zerodayisaminecraftcheat(this.bz, 0, 2);
                    }
                    if (astring[0].equals("ofAnimatedLava") && astring.length >= 2) {
                        this.bA = Integer.valueOf(astring[1]);
                        this.bA = Config.zerodayisaminecraftcheat(this.bA, 0, 2);
                    }
                    if (astring[0].equals("ofAnimatedFire") && astring.length >= 2) {
                        this.bB = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAnimatedPortal") && astring.length >= 2) {
                        this.bC = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAnimatedRedstone") && astring.length >= 2) {
                        this.bD = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAnimatedExplosion") && astring.length >= 2) {
                        this.bE = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAnimatedFlame") && astring.length >= 2) {
                        this.bF = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAnimatedSmoke") && astring.length >= 2) {
                        this.bG = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofVoidParticles") && astring.length >= 2) {
                        this.bH = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofWaterParticles") && astring.length >= 2) {
                        this.bI = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofPortalParticles") && astring.length >= 2) {
                        this.bK = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofPotionParticles") && astring.length >= 2) {
                        this.bL = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofFireworkParticles") && astring.length >= 2) {
                        this.bM = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofDrippingWaterLava") && astring.length >= 2) {
                        this.bN = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAnimatedTerrain") && astring.length >= 2) {
                        this.bO = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAnimatedTextures") && astring.length >= 2) {
                        this.bP = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofRainSplash") && astring.length >= 2) {
                        this.bJ = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofLagometer") && astring.length >= 2) {
                        this.aX = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofShowFps") && astring.length >= 2) {
                        this.aZ = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofAutoSaveTicks") && astring.length >= 2) {
                        this.aW = Integer.valueOf(astring[1]);
                        this.aW = Config.zerodayisaminecraftcheat(this.aW, 40, 40000);
                    }
                    if (astring[0].equals("ofBetterGrass") && astring.length >= 2) {
                        this.aV = Integer.valueOf(astring[1]);
                        this.aV = Config.zerodayisaminecraftcheat(this.aV, 1, 3);
                    }
                    if (astring[0].equals("ofConnectedTextures") && astring.length >= 2) {
                        this.bt = Integer.valueOf(astring[1]);
                        this.bt = Config.zerodayisaminecraftcheat(this.bt, 1, 3);
                    }
                    if (astring[0].equals("ofWeather") && astring.length >= 2) {
                        this.ba = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofSky") && astring.length >= 2) {
                        this.bb = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofStars") && astring.length >= 2) {
                        this.bc = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofSunMoon") && astring.length >= 2) {
                        this.bd = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofVignette") && astring.length >= 2) {
                        this.be = Integer.valueOf(astring[1]);
                        this.be = Config.zerodayisaminecraftcheat(this.be, 0, 2);
                    }
                    if (astring[0].equals("ofChunkUpdates") && astring.length >= 2) {
                        this.bf = Integer.valueOf(astring[1]);
                        this.bf = Config.zerodayisaminecraftcheat(this.bf, 1, 5);
                    }
                    if (astring[0].equals("ofChunkLoading") && astring.length >= 2) {
                        this.bg = Integer.valueOf(astring[1]);
                        this.bg = Config.zerodayisaminecraftcheat(this.bg, 0, 2);
                        this.c();
                    }
                    if (astring[0].equals("ofChunkUpdatesDynamic") && astring.length >= 2) {
                        this.bh = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofTime") && astring.length >= 2) {
                        this.bi = Integer.valueOf(astring[1]);
                        this.bi = Config.zerodayisaminecraftcheat(this.bi, 0, 3);
                    }
                    if (astring[0].equals("ofClearWater") && astring.length >= 2) {
                        this.bj = Boolean.valueOf(astring[1]);
                        this.e();
                    }
                    if (astring[0].equals("ofAaLevel") && astring.length >= 2) {
                        this.aO = Integer.valueOf(astring[1]);
                        this.aO = Config.zerodayisaminecraftcheat(this.aO, 0, 16);
                    }
                    if (astring[0].equals("ofAfLevel") && astring.length >= 2) {
                        this.aP = Integer.valueOf(astring[1]);
                        this.aP = Config.zerodayisaminecraftcheat(this.aP, 1, 16);
                    }
                    if (astring[0].equals("ofProfiler") && astring.length >= 2) {
                        this.aY = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofBetterSnow") && astring.length >= 2) {
                        this.bk = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofSwampColors") && astring.length >= 2) {
                        this.bm = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofRandomMobs") && astring.length >= 2) {
                        this.bn = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofSmoothBiomes") && astring.length >= 2) {
                        this.bo = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofCustomFonts") && astring.length >= 2) {
                        this.bp = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofCustomColors") && astring.length >= 2) {
                        this.bq = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofCustomItems") && astring.length >= 2) {
                        this.bu = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofCustomSky") && astring.length >= 2) {
                        this.br = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofShowCapes") && astring.length >= 2) {
                        this.bs = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofNaturalTextures") && astring.length >= 2) {
                        this.bv = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofLazyChunkLoading") && astring.length >= 2) {
                        this.aM = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofFullscreenMode") && astring.length >= 2) {
                        this.bl = astring[1];
                    }
                    if (astring[0].equals("ofFastMath") && astring.length >= 2) {
                        this.bw = Boolean.valueOf(astring[1]);
                        MathHelper.flux = this.bw;
                    }
                    if (astring[0].equals("ofFastRender") && astring.length >= 2) {
                        this.bx = Boolean.valueOf(astring[1]);
                    }
                    if (astring[0].equals("ofTranslucentBlocks") && astring.length >= 2) {
                        this.by = Integer.valueOf(astring[1]);
                        this.by = Config.zerodayisaminecraftcheat(this.by, 0, 2);
                    }
                    if (!astring[0].equals("key_" + this.cb.vape())) {
                        continue;
                    }
                    this.cb.zeroday(Integer.parseInt(astring[1]));
                }
                catch (Exception exception) {
                    Config.zerodayisaminecraftcheat("Skipping bad option: " + s);
                    exception.printStackTrace();
                }
            }
            KeyBinding.zeroday();
            bufferedreader.close();
        }
        catch (Exception exception2) {
            Config.zeroday("Failed to load options");
            exception2.printStackTrace();
        }
    }
    
    public void momgetthecamera() {
        try {
            final PrintWriter printwriter = new PrintWriter(new FileWriter(this.cr));
            printwriter.println("ofRenderDistanceChunks:" + this.sigma);
            printwriter.println("ofFogType:" + this.aG);
            printwriter.println("ofFogStart:" + this.aH);
            printwriter.println("ofMipmapType:" + this.aI);
            printwriter.println("ofOcclusionFancy:" + this.aJ);
            printwriter.println("ofSmoothFps:" + this.aK);
            printwriter.println("ofSmoothWorld:" + this.aL);
            printwriter.println("ofAoLevel:" + this.aN);
            printwriter.println("ofClouds:" + this.aQ);
            printwriter.println("ofCloudsHeight:" + this.aR);
            printwriter.println("ofTrees:" + this.aS);
            printwriter.println("ofDroppedItems:" + this.aU);
            printwriter.println("ofRain:" + this.aT);
            printwriter.println("ofAnimatedWater:" + this.bz);
            printwriter.println("ofAnimatedLava:" + this.bA);
            printwriter.println("ofAnimatedFire:" + this.bB);
            printwriter.println("ofAnimatedPortal:" + this.bC);
            printwriter.println("ofAnimatedRedstone:" + this.bD);
            printwriter.println("ofAnimatedExplosion:" + this.bE);
            printwriter.println("ofAnimatedFlame:" + this.bF);
            printwriter.println("ofAnimatedSmoke:" + this.bG);
            printwriter.println("ofVoidParticles:" + this.bH);
            printwriter.println("ofWaterParticles:" + this.bI);
            printwriter.println("ofPortalParticles:" + this.bK);
            printwriter.println("ofPotionParticles:" + this.bL);
            printwriter.println("ofFireworkParticles:" + this.bM);
            printwriter.println("ofDrippingWaterLava:" + this.bN);
            printwriter.println("ofAnimatedTerrain:" + this.bO);
            printwriter.println("ofAnimatedTextures:" + this.bP);
            printwriter.println("ofRainSplash:" + this.bJ);
            printwriter.println("ofLagometer:" + this.aX);
            printwriter.println("ofShowFps:" + this.aZ);
            printwriter.println("ofAutoSaveTicks:" + this.aW);
            printwriter.println("ofBetterGrass:" + this.aV);
            printwriter.println("ofConnectedTextures:" + this.bt);
            printwriter.println("ofWeather:" + this.ba);
            printwriter.println("ofSky:" + this.bb);
            printwriter.println("ofStars:" + this.bc);
            printwriter.println("ofSunMoon:" + this.bd);
            printwriter.println("ofVignette:" + this.be);
            printwriter.println("ofChunkUpdates:" + this.bf);
            printwriter.println("ofChunkLoading:" + this.bg);
            printwriter.println("ofChunkUpdatesDynamic:" + this.bh);
            printwriter.println("ofTime:" + this.bi);
            printwriter.println("ofClearWater:" + this.bj);
            printwriter.println("ofAaLevel:" + this.aO);
            printwriter.println("ofAfLevel:" + this.aP);
            printwriter.println("ofProfiler:" + this.aY);
            printwriter.println("ofBetterSnow:" + this.bk);
            printwriter.println("ofSwampColors:" + this.bm);
            printwriter.println("ofRandomMobs:" + this.bn);
            printwriter.println("ofSmoothBiomes:" + this.bo);
            printwriter.println("ofCustomFonts:" + this.bp);
            printwriter.println("ofCustomColors:" + this.bq);
            printwriter.println("ofCustomItems:" + this.bu);
            printwriter.println("ofCustomSky:" + this.br);
            printwriter.println("ofShowCapes:" + this.bs);
            printwriter.println("ofNaturalTextures:" + this.bv);
            printwriter.println("ofLazyChunkLoading:" + this.aM);
            printwriter.println("ofFullscreenMode:" + this.bl);
            printwriter.println("ofFastMath:" + this.bw);
            printwriter.println("ofFastRender:" + this.bx);
            printwriter.println("ofTranslucentBlocks:" + this.by);
            printwriter.println("key_" + this.cb.vape() + ":" + this.cb.a());
            printwriter.close();
        }
        catch (Exception exception) {
            Config.zeroday("Failed to save options");
            exception.printStackTrace();
        }
    }
    
    private void d() {
        switch (this.aQ) {
            case 1: {
                this.momgetthecamera = 1;
                break;
            }
            case 2: {
                this.momgetthecamera = 2;
                break;
            }
            case 3: {
                this.momgetthecamera = 0;
                break;
            }
            default: {
                if (this.a) {
                    this.momgetthecamera = 2;
                    break;
                }
                this.momgetthecamera = 1;
                break;
            }
        }
    }
    
    public void a() {
        this.sigma = 8;
        this.pandora = true;
        this.zues = false;
        this.vape = (int)GameSettings.zeroday.a.zues();
        this.l = false;
        this.b();
        this.B = 4;
        this.a = true;
        this.b = 2;
        this.momgetthecamera = 2;
        this.az = 70.0f;
        this.aA = 0.0f;
        this.aC = 0;
        this.aD = 0;
        this.v = true;
        this.m = false;
        this.n = true;
        this.aF = false;
        this.aG = 1;
        this.aH = 0.8f;
        this.aI = 0;
        this.aJ = false;
        this.aK = false;
        Config.aH();
        this.aL = Config.aI();
        this.aM = Config.aI();
        this.bw = false;
        this.bx = false;
        this.by = 0;
        this.aN = 1.0f;
        this.aO = 0;
        this.aP = 1;
        this.aQ = 0;
        this.aR = 0.0f;
        this.aS = 0;
        this.aT = 0;
        this.aV = 3;
        this.aW = 4000;
        this.aX = false;
        this.aZ = false;
        this.aY = false;
        this.ba = true;
        this.bb = true;
        this.bc = true;
        this.bd = true;
        this.be = 0;
        this.bf = 1;
        this.bg = 0;
        this.bh = false;
        this.bi = 0;
        this.bj = false;
        this.bk = false;
        this.bl = "Default";
        this.bm = true;
        this.bn = true;
        this.bo = true;
        this.bp = true;
        this.bq = true;
        this.bu = true;
        this.br = true;
        this.bs = true;
        this.bt = 2;
        this.bv = false;
        this.bz = 0;
        this.bA = 0;
        this.bB = true;
        this.bC = true;
        this.bD = true;
        this.bE = true;
        this.bF = true;
        this.bG = true;
        this.bH = true;
        this.bI = true;
        this.bJ = true;
        this.bK = true;
        this.bL = true;
        this.bM = true;
        this.bN = true;
        this.bO = true;
        this.bP = true;
        sigma.zerodayisaminecraftcheat.j.zerodayisaminecraftcheat(sigma.zerodayisaminecraftcheat.j.cA);
        sigma.zerodayisaminecraftcheat.j.cp = 0;
        sigma.zerodayisaminecraftcheat.j.b();
        sigma.zerodayisaminecraftcheat.j.zeroday();
        this.e();
        this.ap.flux();
        this.zeroday();
    }
    
    public void b() {
        Display.setVSyncEnabled(this.l);
    }
    
    private void e() {
        if (this.ap.x() && this.ap.z() != null) {
            Config.d = true;
        }
        ClearWater.zerodayisaminecraftcheat(this, this.ap.a);
    }
    
    public void c() {
        if (this.ap.b != null) {
            this.ap.b.pandora();
        }
    }
    
    public void zerodayisaminecraftcheat(final boolean p_setAllAnimations_1_) {
        final int i = p_setAllAnimations_1_ ? 0 : 2;
        this.bz = i;
        this.bA = i;
        this.bB = p_setAllAnimations_1_;
        this.bC = p_setAllAnimations_1_;
        this.bD = p_setAllAnimations_1_;
        this.bE = p_setAllAnimations_1_;
        this.bF = p_setAllAnimations_1_;
        this.bG = p_setAllAnimations_1_;
        this.bH = p_setAllAnimations_1_;
        this.bI = p_setAllAnimations_1_;
        this.bJ = p_setAllAnimations_1_;
        this.bK = p_setAllAnimations_1_;
        this.bL = p_setAllAnimations_1_;
        this.bM = p_setAllAnimations_1_;
        this.aD = (p_setAllAnimations_1_ ? 0 : 2);
        this.bN = p_setAllAnimations_1_;
        this.bO = p_setAllAnimations_1_;
        this.bP = p_setAllAnimations_1_;
    }
    
    public enum zeroday
    {
        zerodayisaminecraftcheat("INVERT_MOUSE", 0, "INVERT_MOUSE", 0, "options.invertMouse", false, true), 
        zeroday("SENSITIVITY", 1, "SENSITIVITY", 1, "options.sensitivity", true, false), 
        sigma("FOV", 2, "FOV", 2, "options.fov", true, false, 30.0f, 110.0f, 1.0f), 
        pandora("GAMMA", 3, "GAMMA", 3, "options.gamma", true, false), 
        zues("SATURATION", 4, "SATURATION", 4, "options.saturation", true, false), 
        flux("RENDER_DISTANCE", 5, "RENDER_DISTANCE", 5, "options.renderDistance", true, false, 2.0f, 16.0f, 1.0f), 
        vape("VIEW_BOBBING", 6, "VIEW_BOBBING", 6, "options.viewBobbing", false, true), 
        momgetthecamera("ANAGLYPH", 7, "ANAGLYPH", 7, "options.anaglyph", false, true), 
        a("FRAMERATE_LIMIT", 8, "FRAMERATE_LIMIT", 8, "options.framerateLimit", true, false, 0.0f, 260.0f, 5.0f), 
        b("FBO_ENABLE", 9, "FBO_ENABLE", 9, "options.fboEnable", false, true), 
        c("RENDER_CLOUDS", 10, "RENDER_CLOUDS", 10, "options.renderClouds", false, false), 
        d("GRAPHICS", 11, "GRAPHICS", 11, "options.graphics", false, false), 
        e("AMBIENT_OCCLUSION", 12, "AMBIENT_OCCLUSION", 12, "options.ao", false, false), 
        f("GUI_SCALE", 13, "GUI_SCALE", 13, "options.guiScale", false, false), 
        g("PARTICLES", 14, "PARTICLES", 14, "options.particles", false, false), 
        h("CHAT_VISIBILITY", 15, "CHAT_VISIBILITY", 15, "options.chat.visibility", false, false), 
        i("CHAT_COLOR", 16, "CHAT_COLOR", 16, "options.chat.color", false, true), 
        j("CHAT_LINKS", 17, "CHAT_LINKS", 17, "options.chat.links", false, true), 
        k("CHAT_OPACITY", 18, "CHAT_OPACITY", 18, "options.chat.opacity", true, false), 
        l("CHAT_LINKS_PROMPT", 19, "CHAT_LINKS_PROMPT", 19, "options.chat.links.prompt", false, true), 
        m("SNOOPER_ENABLED", 20, "SNOOPER_ENABLED", 20, "options.snooper", false, true), 
        n("USE_FULLSCREEN", 21, "USE_FULLSCREEN", 21, "options.fullscreen", false, true), 
        o("ENABLE_VSYNC", 22, "ENABLE_VSYNC", 22, "options.vsync", false, true), 
        p("USE_VBO", 23, "USE_VBO", 23, "options.vbo", false, true), 
        q("TOUCHSCREEN", 24, "TOUCHSCREEN", 24, "options.touchscreen", false, true), 
        r("CHAT_SCALE", 25, "CHAT_SCALE", 25, "options.chat.scale", true, false), 
        s("CHAT_WIDTH", 26, "CHAT_WIDTH", 26, "options.chat.width", true, false), 
        t("CHAT_HEIGHT_FOCUSED", 27, "CHAT_HEIGHT_FOCUSED", 27, "options.chat.height.focused", true, false), 
        u("CHAT_HEIGHT_UNFOCUSED", 28, "CHAT_HEIGHT_UNFOCUSED", 28, "options.chat.height.unfocused", true, false), 
        v("MIPMAP_LEVELS", 29, "MIPMAP_LEVELS", 29, "options.mipmapLevels", true, false, 0.0f, 4.0f, 1.0f), 
        w("FORCE_UNICODE_FONT", 30, "FORCE_UNICODE_FONT", 30, "options.forceUnicodeFont", false, true), 
        x("STREAM_BYTES_PER_PIXEL", 31, "STREAM_BYTES_PER_PIXEL", 31, "options.stream.bytesPerPixel", true, false), 
        y("STREAM_VOLUME_MIC", 32, "STREAM_VOLUME_MIC", 32, "options.stream.micVolumne", true, false), 
        z("STREAM_VOLUME_SYSTEM", 33, "STREAM_VOLUME_SYSTEM", 33, "options.stream.systemVolume", true, false), 
        A("STREAM_KBPS", 34, "STREAM_KBPS", 34, "options.stream.kbps", true, false), 
        B("STREAM_FPS", 35, "STREAM_FPS", 35, "options.stream.fps", true, false), 
        C("STREAM_COMPRESSION", 36, "STREAM_COMPRESSION", 36, "options.stream.compression", false, false), 
        D("STREAM_SEND_METADATA", 37, "STREAM_SEND_METADATA", 37, "options.stream.sendMetadata", false, true), 
        E("STREAM_CHAT_ENABLED", 38, "STREAM_CHAT_ENABLED", 38, "options.stream.chat.enabled", false, false), 
        F("STREAM_CHAT_USER_FILTER", 39, "STREAM_CHAT_USER_FILTER", 39, "options.stream.chat.userFilter", false, false), 
        G("STREAM_MIC_TOGGLE_BEHAVIOR", 40, "STREAM_MIC_TOGGLE_BEHAVIOR", 40, "options.stream.micToggleBehavior", false, false), 
        H("BLOCK_ALTERNATIVES", 41, "BLOCK_ALTERNATIVES", 41, "options.blockAlternatives", false, true), 
        I("REDUCED_DEBUG_INFO", 42, "REDUCED_DEBUG_INFO", 42, "options.reducedDebugInfo", false, true), 
        J("ENTITY_SHADOWS", 43, "ENTITY_SHADOWS", 43, "options.entityShadows", false, true), 
        K("FOG_FANCY", 44, "FOG", 999, "Fog", false, false), 
        L("FOG_START", 45, "", 999, "Fog Start", false, false), 
        M("MIPMAP_TYPE", 46, "", 999, "Mipmap Type", true, false, 0.0f, 3.0f, 1.0f), 
        N("SMOOTH_FPS", 47, "", 999, "Smooth FPS", false, false), 
        O("CLOUDS", 48, "", 999, "Clouds", false, false), 
        P("CLOUD_HEIGHT", 49, "", 999, "Cloud Height", true, false), 
        Q("TREES", 50, "", 999, "Trees", false, false), 
        R("RAIN", 51, "", 999, "Rain & Snow", false, false), 
        S("ANIMATED_WATER", 52, "", 999, "Water Animated", false, false), 
        T("ANIMATED_LAVA", 53, "", 999, "Lava Animated", false, false), 
        U("ANIMATED_FIRE", 54, "", 999, "Fire Animated", false, false), 
        V("ANIMATED_PORTAL", 55, "", 999, "Portal Animated", false, false), 
        W("AO_LEVEL", 56, "", 999, "Smooth Lighting Level", true, false), 
        X("LAGOMETER", 57, "", 999, "Lagometer", false, false), 
        Y("SHOW_FPS", 58, "", 999, "Show FPS", false, false), 
        Z("AUTOSAVE_TICKS", 59, "", 999, "Autosave", false, false), 
        aa("BETTER_GRASS", 60, "", 999, "Better Grass", false, false), 
        ab("ANIMATED_REDSTONE", 61, "", 999, "Redstone Animated", false, false), 
        ac("ANIMATED_EXPLOSION", 62, "", 999, "Explosion Animated", false, false), 
        ad("ANIMATED_FLAME", 63, "", 999, "Flame Animated", false, false), 
        ae("ANIMATED_SMOKE", 64, "", 999, "Smoke Animated", false, false), 
        af("WEATHER", 65, "", 999, "Weather", false, false), 
        ag("SKY", 66, "", 999, "Sky", false, false), 
        ah("STARS", 67, "", 999, "Stars", false, false), 
        ai("SUN_MOON", 68, "", 999, "Sun & Moon", false, false), 
        aj("VIGNETTE", 69, "", 999, "Vignette", false, false), 
        ak("CHUNK_UPDATES", 70, "", 999, "Chunk Updates", false, false), 
        al("CHUNK_UPDATES_DYNAMIC", 71, "", 999, "Dynamic Updates", false, false), 
        am("TIME", 72, "", 999, "Time", false, false), 
        an("CLEAR_WATER", 73, "", 999, "Clear Water", false, false), 
        ao("SMOOTH_WORLD", 74, "", 999, "Smooth World", false, false), 
        ap("VOID_PARTICLES", 75, "", 999, "Void Particles", false, false), 
        aq("WATER_PARTICLES", 76, "", 999, "Water Particles", false, false), 
        ar("RAIN_SPLASH", 77, "", 999, "Rain Splash", false, false), 
        as("PORTAL_PARTICLES", 78, "", 999, "Portal Particles", false, false), 
        at("POTION_PARTICLES", 79, "", 999, "Potion Particles", false, false), 
        au("FIREWORK_PARTICLES", 80, "", 999, "Firework Particles", false, false), 
        av("PROFILER", 81, "", 999, "Debug Profiler", false, false), 
        aw("DRIPPING_WATER_LAVA", 82, "", 999, "Dripping Water/Lava", false, false), 
        ax("BETTER_SNOW", 83, "", 999, "Better Snow", false, false), 
        ay("FULLSCREEN_MODE", 84, "", 999, "Fullscreen Mode", false, false), 
        az("ANIMATED_TERRAIN", 85, "", 999, "Terrain Animated", false, false), 
        aA("SWAMP_COLORS", 86, "", 999, "Swamp Colors", false, false), 
        aB("RANDOM_MOBS", 87, "", 999, "Random Mobs", false, false), 
        aC("SMOOTH_BIOMES", 88, "", 999, "Smooth Biomes", false, false), 
        aD("CUSTOM_FONTS", 89, "", 999, "Custom Fonts", false, false), 
        aE("CUSTOM_COLORS", 90, "", 999, "Custom Colors", false, false), 
        aF("SHOW_CAPES", 91, "", 999, "Show Capes", false, false), 
        aG("CONNECTED_TEXTURES", 92, "", 999, "Connected Textures", false, false), 
        aH("CUSTOM_ITEMS", 93, "", 999, "Custom Items", false, false), 
        aI("AA_LEVEL", 94, "", 999, "Antialiasing", true, false, 0.0f, 16.0f, 1.0f), 
        aJ("AF_LEVEL", 95, "", 999, "Anisotropic Filtering", true, false, 1.0f, 16.0f, 1.0f), 
        aK("ANIMATED_TEXTURES", 96, "", 999, "Textures Animated", false, false), 
        aL("NATURAL_TEXTURES", 97, "", 999, "Natural Textures", false, false), 
        aM("CHUNK_LOADING", 98, "", 999, "Chunk Loading", false, false), 
        aN("HELD_ITEM_TOOLTIPS", 99, "", 999, "Held Item Tooltips", false, false), 
        aO("DROPPED_ITEMS", 100, "", 999, "Dropped Items", false, false), 
        aP("LAZY_CHUNK_LOADING", 101, "", 999, "Lazy Chunk Loading", false, false), 
        aQ("CUSTOM_SKY", 102, "", 999, "Custom Sky", false, false), 
        aR("FAST_MATH", 103, "", 999, "Fast Math", false, false), 
        aS("FAST_RENDER", 104, "", 999, "Fast Render", false, false), 
        aT("TRANSLUCENT_BLOCKS", 105, "", 999, "Translucent Blocks", false, false);
        
        private final boolean aU;
        private final boolean aV;
        private final String aW;
        private final float aX;
        private float aY;
        private float aZ;
        private static final zeroday[] ba;
        private static final String bb = "CL_00000653";
        
        static {
            bc = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday, zeroday.sigma, zeroday.pandora, zeroday.zues, zeroday.flux, zeroday.vape, zeroday.momgetthecamera, zeroday.a, zeroday.b, zeroday.c, zeroday.d, zeroday.e, zeroday.f, zeroday.g, zeroday.h, zeroday.i, zeroday.j, zeroday.k, zeroday.l, zeroday.m, zeroday.n, zeroday.o, zeroday.p, zeroday.q, zeroday.r, zeroday.s, zeroday.t, zeroday.u, zeroday.v, zeroday.w, zeroday.x, zeroday.y, zeroday.z, zeroday.A, zeroday.B, zeroday.C, zeroday.D, zeroday.E, zeroday.F, zeroday.G, zeroday.H, zeroday.I, zeroday.J, zeroday.K, zeroday.L, zeroday.M, zeroday.N, zeroday.O, zeroday.P, zeroday.Q, zeroday.R, zeroday.S, zeroday.T, zeroday.U, zeroday.V, zeroday.W, zeroday.X, zeroday.Y, zeroday.Z, zeroday.aa, zeroday.ab, zeroday.ac, zeroday.ad, zeroday.ae, zeroday.af, zeroday.ag, zeroday.ah, zeroday.ai, zeroday.aj, zeroday.ak, zeroday.al, zeroday.am, zeroday.an, zeroday.ao, zeroday.ap, zeroday.aq, zeroday.ar, zeroday.as, zeroday.at, zeroday.au, zeroday.av, zeroday.aw, zeroday.ax, zeroday.ay, zeroday.az, zeroday.aA, zeroday.aB, zeroday.aC, zeroday.aD, zeroday.aE, zeroday.aF, zeroday.aG, zeroday.aH, zeroday.aI, zeroday.aJ, zeroday.aK, zeroday.aL, zeroday.aM, zeroday.aN, zeroday.aO, zeroday.aP, zeroday.aQ, zeroday.aR, zeroday.aS, zeroday.aT };
            ba = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday, zeroday.sigma, zeroday.pandora, zeroday.zues, zeroday.flux, zeroday.vape, zeroday.momgetthecamera, zeroday.a, zeroday.b, zeroday.c, zeroday.d, zeroday.e, zeroday.f, zeroday.g, zeroday.h, zeroday.i, zeroday.j, zeroday.k, zeroday.l, zeroday.m, zeroday.n, zeroday.o, zeroday.p, zeroday.q, zeroday.r, zeroday.s, zeroday.t, zeroday.u, zeroday.v, zeroday.w, zeroday.x, zeroday.y, zeroday.z, zeroday.A, zeroday.B, zeroday.C, zeroday.D, zeroday.E, zeroday.F, zeroday.G, zeroday.H, zeroday.I, zeroday.J };
        }
        
        public static zeroday zerodayisaminecraftcheat(final int p_74379_0_) {
            zeroday[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final zeroday gamesettings$options = values[i];
                if (gamesettings$options.sigma() == p_74379_0_) {
                    return gamesettings$options;
                }
            }
            return null;
        }
        
        private zeroday(final String s, final int n, final String p_i7_3_, final int p_i7_4_, final String p_i7_5_, final boolean p_i7_6_, final boolean p_i7_7_) {
            this(s, n, p_i7_3_, p_i7_4_, p_i7_5_, p_i7_6_, p_i7_7_, 0.0f, 1.0f, 0.0f);
        }
        
        private zeroday(final String s, final int n, final String p_i8_3_, final int p_i8_4_, final String p_i8_5_, final boolean p_i8_6_, final boolean p_i8_7_, final float p_i8_8_, final float p_i8_9_, final float p_i8_10_) {
            this.aW = p_i8_5_;
            this.aU = p_i8_6_;
            this.aV = p_i8_7_;
            this.aY = p_i8_8_;
            this.aZ = p_i8_9_;
            this.aX = p_i8_10_;
        }
        
        public boolean zerodayisaminecraftcheat() {
            return this.aU;
        }
        
        public boolean zeroday() {
            return this.aV;
        }
        
        public int sigma() {
            return this.ordinal();
        }
        
        public String pandora() {
            return this.aW;
        }
        
        public float zues() {
            return this.aZ;
        }
        
        public void zerodayisaminecraftcheat(final float p_148263_1_) {
            this.aZ = p_148263_1_;
        }
        
        public float zeroday(final float p_148266_1_) {
            return MathHelper.zerodayisaminecraftcheat((this.pandora(p_148266_1_) - this.aY) / (this.aZ - this.aY), 0.0f, 1.0f);
        }
        
        public float sigma(final float p_148262_1_) {
            return this.pandora(this.aY + (this.aZ - this.aY) * MathHelper.zerodayisaminecraftcheat(p_148262_1_, 0.0f, 1.0f));
        }
        
        public float pandora(float p_148268_1_) {
            p_148268_1_ = this.zues(p_148268_1_);
            return MathHelper.zerodayisaminecraftcheat(p_148268_1_, this.aY, this.aZ);
        }
        
        protected float zues(float p_148264_1_) {
            if (this.aX > 0.0f) {
                p_148264_1_ = this.aX * Math.round(p_148264_1_ / this.aX);
            }
            return p_148264_1_;
        }
    }
    
    static final class zerodayisaminecraftcheat
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00000652";
        
        static {
            zerodayisaminecraftcheat = new int[GameSettings.zeroday.values().length];
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.vape.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.momgetthecamera.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.b.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.i.ordinal()] = 5;
            }
            catch (NoSuchFieldError noSuchFieldError5) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.j.ordinal()] = 6;
            }
            catch (NoSuchFieldError noSuchFieldError6) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.l.ordinal()] = 7;
            }
            catch (NoSuchFieldError noSuchFieldError7) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.m.ordinal()] = 8;
            }
            catch (NoSuchFieldError noSuchFieldError8) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.n.ordinal()] = 9;
            }
            catch (NoSuchFieldError noSuchFieldError9) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.o.ordinal()] = 10;
            }
            catch (NoSuchFieldError noSuchFieldError10) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.p.ordinal()] = 11;
            }
            catch (NoSuchFieldError noSuchFieldError11) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.q.ordinal()] = 12;
            }
            catch (NoSuchFieldError noSuchFieldError12) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.D.ordinal()] = 13;
            }
            catch (NoSuchFieldError noSuchFieldError13) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.w.ordinal()] = 14;
            }
            catch (NoSuchFieldError noSuchFieldError14) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.H.ordinal()] = 15;
            }
            catch (NoSuchFieldError noSuchFieldError15) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.I.ordinal()] = 16;
            }
            catch (NoSuchFieldError noSuchFieldError16) {}
            try {
                GameSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat[GameSettings.zeroday.J.ordinal()] = 17;
            }
            catch (NoSuchFieldError noSuchFieldError17) {}
        }
    }
}

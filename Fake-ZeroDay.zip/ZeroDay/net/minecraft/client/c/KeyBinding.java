// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.c;

import net.minecraft.client.b.I18n;
import java.util.Iterator;
import com.google.common.collect.Sets;
import com.google.common.collect.Lists;
import java.util.Set;
import net.minecraft.o.IntHashMap;
import java.util.List;

public class KeyBinding implements Comparable<KeyBinding>
{
    private static final List<KeyBinding> zeroday;
    private static final IntHashMap<KeyBinding> sigma;
    private static final Set<String> pandora;
    private final String zues;
    private final int flux;
    private final String vape;
    private int momgetthecamera;
    public boolean zerodayisaminecraftcheat;
    private int a;
    
    static {
        zeroday = Lists.newArrayList();
        sigma = new IntHashMap<KeyBinding>();
        pandora = Sets.newHashSet();
    }
    
    public static void zerodayisaminecraftcheat(final int keyCode) {
        if (keyCode != 0) {
            final KeyBinding keybinding = KeyBinding.sigma.zerodayisaminecraftcheat(keyCode);
            if (keybinding != null) {
                final KeyBinding keyBinding = keybinding;
                ++keyBinding.a;
            }
        }
    }
    
    public static void zerodayisaminecraftcheat(final int keyCode, final boolean pressed) {
        if (keyCode != 0) {
            final KeyBinding keybinding = KeyBinding.sigma.zerodayisaminecraftcheat(keyCode);
            if (keybinding != null) {
                keybinding.zerodayisaminecraftcheat = pressed;
            }
        }
    }
    
    public static void zerodayisaminecraftcheat() {
        for (final KeyBinding keybinding : KeyBinding.zeroday) {
            keybinding.b();
        }
    }
    
    public static void zeroday() {
        KeyBinding.sigma.zerodayisaminecraftcheat();
        for (final KeyBinding keybinding : KeyBinding.zeroday) {
            KeyBinding.sigma.zerodayisaminecraftcheat(keybinding.momgetthecamera, keybinding);
        }
    }
    
    public static Set<String> sigma() {
        return KeyBinding.pandora;
    }
    
    public KeyBinding(final String description, final int keyCode, final String category) {
        this.zues = description;
        this.momgetthecamera = keyCode;
        this.flux = keyCode;
        this.vape = category;
        KeyBinding.zeroday.add(this);
        KeyBinding.sigma.zerodayisaminecraftcheat(keyCode, this);
        KeyBinding.pandora.add(category);
    }
    
    public boolean pandora() {
        return this.zerodayisaminecraftcheat;
    }
    
    public String zues() {
        return this.vape;
    }
    
    public boolean flux() {
        if (this.a == 0) {
            return false;
        }
        --this.a;
        return true;
    }
    
    private void b() {
        this.a = 0;
        this.zerodayisaminecraftcheat = false;
    }
    
    public String vape() {
        return this.zues;
    }
    
    public int momgetthecamera() {
        return this.flux;
    }
    
    public int a() {
        return this.momgetthecamera;
    }
    
    public void zeroday(final int keyCode) {
        this.momgetthecamera = keyCode;
    }
    
    public int zerodayisaminecraftcheat(final KeyBinding p_compareTo_1_) {
        int i = I18n.zerodayisaminecraftcheat(this.vape, new Object[0]).compareTo(I18n.zerodayisaminecraftcheat(p_compareTo_1_.vape, new Object[0]));
        if (i == 0) {
            i = I18n.zerodayisaminecraftcheat(this.zues, new Object[0]).compareTo(I18n.zerodayisaminecraftcheat(p_compareTo_1_.zues, new Object[0]));
        }
        return i;
    }
}

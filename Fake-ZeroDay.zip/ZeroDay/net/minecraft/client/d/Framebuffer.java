// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import java.nio.ByteBuffer;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.OpenGlHelper;

public class Framebuffer
{
    public int zerodayisaminecraftcheat;
    public int zeroday;
    public int sigma;
    public int pandora;
    public boolean zues;
    public int flux;
    public int vape;
    public int momgetthecamera;
    public float[] a;
    public int b;
    
    public Framebuffer(final int p_i45078_1_, final int p_i45078_2_, final boolean p_i45078_3_) {
        this.zues = p_i45078_3_;
        this.flux = -1;
        this.vape = -1;
        this.momgetthecamera = -1;
        (this.a = new float[4])[0] = 1.0f;
        this.a[1] = 1.0f;
        this.a[2] = 1.0f;
        this.a[3] = 0.0f;
        this.zerodayisaminecraftcheat(p_i45078_1_, p_i45078_2_);
    }
    
    public void zerodayisaminecraftcheat(final int width, final int height) {
        if (!OpenGlHelper.a()) {
            this.sigma = width;
            this.pandora = height;
        }
        else {
            GlStateManager.b();
            if (this.flux >= 0) {
                this.zerodayisaminecraftcheat();
            }
            this.zeroday(width, height);
            this.zeroday();
            OpenGlHelper.momgetthecamera(OpenGlHelper.sigma, 0);
        }
    }
    
    public void zerodayisaminecraftcheat() {
        if (OpenGlHelper.a()) {
            this.pandora();
            this.zues();
            if (this.momgetthecamera > -1) {
                OpenGlHelper.momgetthecamera(this.momgetthecamera);
                this.momgetthecamera = -1;
            }
            if (this.vape > -1) {
                TextureUtil.zerodayisaminecraftcheat(this.vape);
                this.vape = -1;
            }
            if (this.flux > -1) {
                OpenGlHelper.momgetthecamera(OpenGlHelper.sigma, 0);
                OpenGlHelper.a(this.flux);
                this.flux = -1;
            }
        }
    }
    
    public void zeroday(final int width, final int height) {
        this.sigma = width;
        this.pandora = height;
        this.zerodayisaminecraftcheat = width;
        this.zeroday = height;
        if (!OpenGlHelper.a()) {
            this.flux();
        }
        else {
            this.flux = OpenGlHelper.vape();
            this.vape = TextureUtil.zerodayisaminecraftcheat();
            if (this.zues) {
                this.momgetthecamera = OpenGlHelper.momgetthecamera();
            }
            this.zerodayisaminecraftcheat(9728);
            GlStateManager.a(this.vape);
            GL11.glTexImage2D(3553, 0, 32856, this.zerodayisaminecraftcheat, this.zeroday, 0, 6408, 5121, (ByteBuffer)null);
            OpenGlHelper.momgetthecamera(OpenGlHelper.sigma, this.flux);
            OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.sigma, OpenGlHelper.zues, 3553, this.vape, 0);
            if (this.zues) {
                OpenGlHelper.a(OpenGlHelper.pandora, this.momgetthecamera);
                OpenGlHelper.zerodayisaminecraftcheat(OpenGlHelper.pandora, 33190, this.zerodayisaminecraftcheat, this.zeroday);
                OpenGlHelper.zeroday(OpenGlHelper.sigma, OpenGlHelper.flux, OpenGlHelper.pandora, this.momgetthecamera);
            }
            this.flux();
            this.pandora();
        }
    }
    
    public void zerodayisaminecraftcheat(final int p_147607_1_) {
        if (OpenGlHelper.a()) {
            this.b = p_147607_1_;
            GlStateManager.a(this.vape);
            GL11.glTexParameterf(3553, 10241, (float)p_147607_1_);
            GL11.glTexParameterf(3553, 10240, (float)p_147607_1_);
            GL11.glTexParameterf(3553, 10242, 10496.0f);
            GL11.glTexParameterf(3553, 10243, 10496.0f);
            GlStateManager.a(0);
        }
    }
    
    public void zeroday() {
        final int i = OpenGlHelper.b(OpenGlHelper.sigma);
        if (i == OpenGlHelper.vape) {
            return;
        }
        if (i == OpenGlHelper.momgetthecamera) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT");
        }
        if (i == OpenGlHelper.a) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT");
        }
        if (i == OpenGlHelper.b) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER");
        }
        if (i == OpenGlHelper.c) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER");
        }
        throw new RuntimeException("glCheckFramebufferStatus returned unknown status:" + i);
    }
    
    public void sigma() {
        if (OpenGlHelper.a()) {
            GlStateManager.a(this.vape);
        }
    }
    
    public void pandora() {
        if (OpenGlHelper.a()) {
            GlStateManager.a(0);
        }
    }
    
    public void zerodayisaminecraftcheat(final boolean p_147610_1_) {
        if (OpenGlHelper.a()) {
            OpenGlHelper.momgetthecamera(OpenGlHelper.sigma, this.flux);
            if (p_147610_1_) {
                GlStateManager.zeroday(0, 0, this.sigma, this.pandora);
            }
        }
    }
    
    public void zues() {
        if (OpenGlHelper.a()) {
            OpenGlHelper.momgetthecamera(OpenGlHelper.sigma, 0);
        }
    }
    
    public void zerodayisaminecraftcheat(final float p_147604_1_, final float p_147604_2_, final float p_147604_3_, final float p_147604_4_) {
        this.a[0] = p_147604_1_;
        this.a[1] = p_147604_2_;
        this.a[2] = p_147604_3_;
        this.a[3] = p_147604_4_;
    }
    
    public void sigma(final int p_147615_1_, final int p_147615_2_) {
        this.zerodayisaminecraftcheat(p_147615_1_, p_147615_2_, true);
    }
    
    public void zerodayisaminecraftcheat(final int p_178038_1_, final int p_178038_2_, final boolean p_178038_3_) {
        if (OpenGlHelper.a()) {
            GlStateManager.zerodayisaminecraftcheat(true, true, true, false);
            GlStateManager.a();
            GlStateManager.zerodayisaminecraftcheat(false);
            GlStateManager.d(5889);
            GlStateManager.u();
            GlStateManager.zerodayisaminecraftcheat(0.0, p_178038_1_, p_178038_2_, 0.0, 1000.0, 3000.0);
            GlStateManager.d(5888);
            GlStateManager.u();
            GlStateManager.zeroday(0.0f, 0.0f, -2000.0f);
            GlStateManager.zeroday(0, 0, p_178038_1_, p_178038_2_);
            GlStateManager.m();
            GlStateManager.flux();
            GlStateManager.sigma();
            if (p_178038_3_) {
                GlStateManager.c();
                GlStateManager.vape();
            }
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.sigma();
            final float f = (float)p_178038_1_;
            final float f2 = (float)p_178038_2_;
            final float f3 = this.sigma / (float)this.zerodayisaminecraftcheat;
            final float f4 = this.pandora / (float)this.zeroday;
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
            worldrenderer.zeroday(0.0, f2, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(255, 255, 255, 255).zues();
            worldrenderer.zeroday(f, f2, 0.0).zerodayisaminecraftcheat(f3, 0.0).zeroday(255, 255, 255, 255).zues();
            worldrenderer.zeroday(f, 0.0, 0.0).zerodayisaminecraftcheat(f3, f4).zeroday(255, 255, 255, 255).zues();
            worldrenderer.zeroday(0.0, 0.0, 0.0).zerodayisaminecraftcheat(0.0, f4).zeroday(255, 255, 255, 255).zues();
            tessellator.zeroday();
            this.pandora();
            GlStateManager.zerodayisaminecraftcheat(true);
            GlStateManager.zerodayisaminecraftcheat(true, true, true, true);
        }
    }
    
    public void flux() {
        this.zerodayisaminecraftcheat(true);
        GlStateManager.zerodayisaminecraftcheat(this.a[0], this.a[1], this.a[2], this.a[3]);
        int i = 16384;
        if (this.zues) {
            GlStateManager.zerodayisaminecraftcheat(1.0);
            i |= 0x100;
        }
        GlStateManager.c(i);
        this.zues();
    }
}

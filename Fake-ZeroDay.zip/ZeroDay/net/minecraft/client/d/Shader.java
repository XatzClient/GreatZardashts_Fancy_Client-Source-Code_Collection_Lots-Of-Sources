// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import java.util.Iterator;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.a.GlStateManager;
import java.io.IOException;
import net.minecraft.client.f.JsonException;
import com.google.common.collect.Lists;
import net.minecraft.client.b.IResourceManager;
import org.lwjgl.util.vector.Matrix4f;
import java.util.List;

public class Shader
{
    private final ShaderManager sigma;
    public final Framebuffer zerodayisaminecraftcheat;
    public final Framebuffer zeroday;
    private final List<Object> pandora;
    private final List<String> zues;
    private final List<Integer> flux;
    private final List<Integer> vape;
    private Matrix4f momgetthecamera;
    
    public Shader(final IResourceManager p_i45089_1_, final String p_i45089_2_, final Framebuffer p_i45089_3_, final Framebuffer p_i45089_4_) throws JsonException, IOException {
        this.pandora = (List<Object>)Lists.newArrayList();
        this.zues = (List<String>)Lists.newArrayList();
        this.flux = (List<Integer>)Lists.newArrayList();
        this.vape = (List<Integer>)Lists.newArrayList();
        this.sigma = new ShaderManager(p_i45089_1_, p_i45089_2_);
        this.zerodayisaminecraftcheat = p_i45089_3_;
        this.zeroday = p_i45089_4_;
    }
    
    public void zerodayisaminecraftcheat() {
        this.sigma.zerodayisaminecraftcheat();
    }
    
    public void zerodayisaminecraftcheat(final String p_148041_1_, final Object p_148041_2_, final int p_148041_3_, final int p_148041_4_) {
        this.zues.add(this.zues.size(), p_148041_1_);
        this.pandora.add(this.pandora.size(), p_148041_2_);
        this.flux.add(this.flux.size(), p_148041_3_);
        this.vape.add(this.vape.size(), p_148041_4_);
    }
    
    private void sigma() {
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.c();
        GlStateManager.a();
        GlStateManager.sigma();
        GlStateManager.f();
        GlStateManager.flux();
        GlStateManager.momgetthecamera();
        GlStateManager.m();
        GlStateManager.a(0);
    }
    
    public void zerodayisaminecraftcheat(final Matrix4f p_148045_1_) {
        this.momgetthecamera = p_148045_1_;
    }
    
    public void zerodayisaminecraftcheat(final float p_148042_1_) {
        this.sigma();
        this.zerodayisaminecraftcheat.zues();
        final float f = (float)this.zeroday.zerodayisaminecraftcheat;
        final float f2 = (float)this.zeroday.zeroday;
        GlStateManager.zeroday(0, 0, (int)f, (int)f2);
        this.sigma.zerodayisaminecraftcheat("DiffuseSampler", this.zerodayisaminecraftcheat);
        for (int i = 0; i < this.pandora.size(); ++i) {
            this.sigma.zerodayisaminecraftcheat(this.zues.get(i), this.pandora.get(i));
            this.sigma.zeroday("AuxSize" + i).zerodayisaminecraftcheat(this.flux.get(i), this.vape.get(i));
        }
        this.sigma.zeroday("ProjMat").zerodayisaminecraftcheat(this.momgetthecamera);
        this.sigma.zeroday("InSize").zerodayisaminecraftcheat((float)this.zerodayisaminecraftcheat.zerodayisaminecraftcheat, (float)this.zerodayisaminecraftcheat.zeroday);
        this.sigma.zeroday("OutSize").zerodayisaminecraftcheat(f, f2);
        this.sigma.zeroday("Time").zerodayisaminecraftcheat(p_148042_1_);
        final Minecraft minecraft = Minecraft.s();
        this.sigma.zeroday("ScreenSize").zerodayisaminecraftcheat((float)minecraft.flux, (float)minecraft.vape);
        this.sigma.sigma();
        this.zeroday.flux();
        this.zeroday.zerodayisaminecraftcheat(false);
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.zerodayisaminecraftcheat(true, true, true, true);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
        worldrenderer.zeroday(0.0, f2, 500.0).zeroday(255, 255, 255, 255).zues();
        worldrenderer.zeroday(f, f2, 500.0).zeroday(255, 255, 255, 255).zues();
        worldrenderer.zeroday(f, 0.0, 500.0).zeroday(255, 255, 255, 255).zues();
        worldrenderer.zeroday(0.0, 0.0, 500.0).zeroday(255, 255, 255, 255).zues();
        tessellator.zeroday();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.zerodayisaminecraftcheat(true, true, true, true);
        this.sigma.zeroday();
        this.zeroday.zues();
        this.zerodayisaminecraftcheat.pandora();
        for (final Object object : this.pandora) {
            if (object instanceof Framebuffer) {
                ((Framebuffer)object).pandora();
            }
        }
    }
    
    public ShaderManager zeroday() {
        return this.sigma;
    }
}

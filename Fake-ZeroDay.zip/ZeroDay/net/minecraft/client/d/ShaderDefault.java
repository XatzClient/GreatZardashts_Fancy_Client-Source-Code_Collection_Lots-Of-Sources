// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import org.lwjgl.util.vector.Matrix4f;

public class ShaderDefault extends ShaderUniform
{
    public ShaderDefault() {
        super("dummy", 4, 1, null);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_148090_1_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_148087_1_, final float p_148087_2_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_148095_1_, final float p_148095_2_, final float p_148095_3_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_148081_1_, final float p_148081_2_, final float p_148081_3_, final float p_148081_4_) {
    }
    
    @Override
    public void zeroday(final float p_148092_1_, final float p_148092_2_, final float p_148092_3_, final float p_148092_4_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int p_148083_1_, final int p_148083_2_, final int p_148083_3_, final int p_148083_4_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float[] p_148097_1_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_148094_1_, final float p_148094_2_, final float p_148094_3_, final float p_148094_4_, final float p_148094_5_, final float p_148094_6_, final float p_148094_7_, final float p_148094_8_, final float p_148094_9_, final float p_148094_10_, final float p_148094_11_, final float p_148094_12_, final float p_148094_13_, final float p_148094_14_, final float p_148094_15_, final float p_148094_16_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Matrix4f p_148088_1_) {
    }
}

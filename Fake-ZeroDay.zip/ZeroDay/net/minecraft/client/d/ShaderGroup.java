// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import net.minecraft.client.a.zues.ITextureObject;
import org.lwjgl.opengl.GL11;
import java.io.FileNotFoundException;
import java.util.Iterator;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.b.IResource;
import java.io.InputStream;
import com.google.gson.JsonElement;
import net.minecraft.o.JsonUtils;
import org.apache.commons.io.IOUtils;
import com.google.common.base.Charsets;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import net.minecraft.client.f.JsonException;
import com.google.common.collect.Maps;
import com.google.common.collect.Lists;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.a.zues.TextureManager;
import org.lwjgl.util.vector.Matrix4f;
import java.util.Map;
import java.util.List;
import net.minecraft.client.b.IResourceManager;

public class ShaderGroup
{
    private Framebuffer zerodayisaminecraftcheat;
    private IResourceManager zeroday;
    private String sigma;
    private final List<Shader> pandora;
    private final Map<String, Framebuffer> zues;
    private final List<Framebuffer> flux;
    private Matrix4f vape;
    private int momgetthecamera;
    private int a;
    private float b;
    private float c;
    
    public ShaderGroup(final TextureManager p_i1050_1_, final IResourceManager p_i1050_2_, final Framebuffer p_i1050_3_, final ResourceLocation p_i1050_4_) throws JsonException, IOException, JsonSyntaxException {
        this.pandora = (List<Shader>)Lists.newArrayList();
        this.zues = (Map<String, Framebuffer>)Maps.newHashMap();
        this.flux = (List<Framebuffer>)Lists.newArrayList();
        this.zeroday = p_i1050_2_;
        this.zerodayisaminecraftcheat = p_i1050_3_;
        this.b = 0.0f;
        this.c = 0.0f;
        this.momgetthecamera = p_i1050_3_.sigma;
        this.a = p_i1050_3_.pandora;
        this.sigma = p_i1050_4_.toString();
        this.sigma();
        this.zerodayisaminecraftcheat(p_i1050_1_, p_i1050_4_);
    }
    
    public void zerodayisaminecraftcheat(final TextureManager p_152765_1_, final ResourceLocation p_152765_2_) throws JsonException, IOException, JsonSyntaxException {
        final JsonParser jsonparser = new JsonParser();
        InputStream inputstream = null;
        try {
            final IResource iresource = this.zeroday.zerodayisaminecraftcheat(p_152765_2_);
            inputstream = iresource.zeroday();
            final JsonObject jsonobject = jsonparser.parse(IOUtils.toString(inputstream, Charsets.UTF_8)).getAsJsonObject();
            if (JsonUtils.sigma(jsonobject, "targets")) {
                final JsonArray jsonarray = jsonobject.getAsJsonArray("targets");
                int i = 0;
                for (final JsonElement jsonelement : jsonarray) {
                    try {
                        this.zerodayisaminecraftcheat(jsonelement);
                    }
                    catch (Exception exception1) {
                        final JsonException jsonexception1 = JsonException.zerodayisaminecraftcheat(exception1);
                        jsonexception1.zerodayisaminecraftcheat("targets[" + i + "]");
                        throw jsonexception1;
                    }
                    ++i;
                }
            }
            if (JsonUtils.sigma(jsonobject, "passes")) {
                final JsonArray jsonarray2 = jsonobject.getAsJsonArray("passes");
                int j = 0;
                for (final JsonElement jsonelement2 : jsonarray2) {
                    try {
                        this.zerodayisaminecraftcheat(p_152765_1_, jsonelement2);
                    }
                    catch (Exception exception2) {
                        final JsonException jsonexception2 = JsonException.zerodayisaminecraftcheat(exception2);
                        jsonexception2.zerodayisaminecraftcheat("passes[" + j + "]");
                        throw jsonexception2;
                    }
                    ++j;
                }
            }
        }
        catch (Exception exception3) {
            final JsonException jsonexception3 = JsonException.zerodayisaminecraftcheat(exception3);
            jsonexception3.zeroday(p_152765_2_.zeroday());
            throw jsonexception3;
        }
        finally {
            IOUtils.closeQuietly(inputstream);
        }
        IOUtils.closeQuietly(inputstream);
    }
    
    private void zerodayisaminecraftcheat(final JsonElement p_148027_1_) throws JsonException {
        if (JsonUtils.zerodayisaminecraftcheat(p_148027_1_)) {
            this.zerodayisaminecraftcheat(p_148027_1_.getAsString(), this.momgetthecamera, this.a);
        }
        else {
            final JsonObject jsonobject = JsonUtils.zues(p_148027_1_, "target");
            final String s = JsonUtils.flux(jsonobject, "name");
            final int i = JsonUtils.zerodayisaminecraftcheat(jsonobject, "width", this.momgetthecamera);
            final int j = JsonUtils.zerodayisaminecraftcheat(jsonobject, "height", this.a);
            if (this.zues.containsKey(s)) {
                throw new JsonException(String.valueOf(s) + " is already defined");
            }
            this.zerodayisaminecraftcheat(s, i, j);
        }
    }
    
    private void zerodayisaminecraftcheat(final TextureManager p_152764_1_, final JsonElement p_152764_2_) throws JsonException, IOException {
        final JsonObject jsonobject = JsonUtils.zues(p_152764_2_, "pass");
        final String s = JsonUtils.flux(jsonobject, "name");
        final String s2 = JsonUtils.flux(jsonobject, "intarget");
        final String s3 = JsonUtils.flux(jsonobject, "outtarget");
        final Framebuffer framebuffer = this.zeroday(s2);
        final Framebuffer framebuffer2 = this.zeroday(s3);
        if (framebuffer == null) {
            throw new JsonException("Input target '" + s2 + "' does not exist");
        }
        if (framebuffer2 == null) {
            throw new JsonException("Output target '" + s3 + "' does not exist");
        }
        final Shader shader = this.zerodayisaminecraftcheat(s, framebuffer, framebuffer2);
        final JsonArray jsonarray = JsonUtils.zerodayisaminecraftcheat(jsonobject, "auxtargets", (JsonArray)null);
        if (jsonarray != null) {
            int i = 0;
            for (final JsonElement jsonelement : jsonarray) {
                try {
                    final JsonObject jsonobject2 = JsonUtils.zues(jsonelement, "auxtarget");
                    final String s4 = JsonUtils.flux(jsonobject2, "name");
                    final String s5 = JsonUtils.flux(jsonobject2, "id");
                    final Framebuffer framebuffer3 = this.zeroday(s5);
                    if (framebuffer3 == null) {
                        final ResourceLocation resourcelocation = new ResourceLocation("textures/effect/" + s5 + ".png");
                        try {
                            this.zeroday.zerodayisaminecraftcheat(resourcelocation);
                        }
                        catch (FileNotFoundException var24) {
                            throw new JsonException("Render target or texture '" + s5 + "' does not exist");
                        }
                        p_152764_1_.zerodayisaminecraftcheat(resourcelocation);
                        final ITextureObject itextureobject = p_152764_1_.zeroday(resourcelocation);
                        final int j = JsonUtils.a(jsonobject2, "width");
                        final int k = JsonUtils.a(jsonobject2, "height");
                        final boolean flag = JsonUtils.vape(jsonobject2, "bilinear");
                        if (flag) {
                            GL11.glTexParameteri(3553, 10241, 9729);
                            GL11.glTexParameteri(3553, 10240, 9729);
                        }
                        else {
                            GL11.glTexParameteri(3553, 10241, 9728);
                            GL11.glTexParameteri(3553, 10240, 9728);
                        }
                        shader.zerodayisaminecraftcheat(s4, itextureobject.zerodayisaminecraftcheat(), j, k);
                    }
                    else {
                        shader.zerodayisaminecraftcheat(s4, framebuffer3, framebuffer3.zerodayisaminecraftcheat, framebuffer3.zeroday);
                    }
                }
                catch (Exception exception1) {
                    final JsonException jsonexception = JsonException.zerodayisaminecraftcheat(exception1);
                    jsonexception.zerodayisaminecraftcheat("auxtargets[" + i + "]");
                    throw jsonexception;
                }
                ++i;
            }
        }
        final JsonArray jsonarray2 = JsonUtils.zerodayisaminecraftcheat(jsonobject, "uniforms", (JsonArray)null);
        if (jsonarray2 != null) {
            int l = 0;
            for (final JsonElement jsonelement2 : jsonarray2) {
                try {
                    this.zeroday(jsonelement2);
                }
                catch (Exception exception2) {
                    final JsonException jsonexception2 = JsonException.zerodayisaminecraftcheat(exception2);
                    jsonexception2.zerodayisaminecraftcheat("uniforms[" + l + "]");
                    throw jsonexception2;
                }
                ++l;
            }
        }
    }
    
    private void zeroday(final JsonElement p_148028_1_) throws JsonException {
        final JsonObject jsonobject = JsonUtils.zues(p_148028_1_, "uniform");
        final String s = JsonUtils.flux(jsonobject, "name");
        final ShaderUniform shaderuniform = this.pandora.get(this.pandora.size() - 1).zeroday().zerodayisaminecraftcheat(s);
        if (shaderuniform == null) {
            throw new JsonException("Uniform '" + s + "' does not exist");
        }
        final float[] afloat = new float[4];
        int i = 0;
        for (final JsonElement jsonelement : JsonUtils.c(jsonobject, "values")) {
            try {
                afloat[i] = JsonUtils.sigma(jsonelement, "value");
            }
            catch (Exception exception) {
                final JsonException jsonexception = JsonException.zerodayisaminecraftcheat(exception);
                jsonexception.zerodayisaminecraftcheat("values[" + i + "]");
                throw jsonexception;
            }
            ++i;
        }
        switch (i) {
            case 1: {
                shaderuniform.zerodayisaminecraftcheat(afloat[0]);
                break;
            }
            case 2: {
                shaderuniform.zerodayisaminecraftcheat(afloat[0], afloat[1]);
                break;
            }
            case 3: {
                shaderuniform.zerodayisaminecraftcheat(afloat[0], afloat[1], afloat[2]);
                break;
            }
            case 4: {
                shaderuniform.zerodayisaminecraftcheat(afloat[0], afloat[1], afloat[2], afloat[3]);
                break;
            }
        }
    }
    
    public Framebuffer zerodayisaminecraftcheat(final String p_177066_1_) {
        return this.zues.get(p_177066_1_);
    }
    
    public void zerodayisaminecraftcheat(final String p_148020_1_, final int p_148020_2_, final int p_148020_3_) {
        final Framebuffer framebuffer = new Framebuffer(p_148020_2_, p_148020_3_, true);
        framebuffer.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 0.0f);
        this.zues.put(p_148020_1_, framebuffer);
        if (p_148020_2_ == this.momgetthecamera && p_148020_3_ == this.a) {
            this.flux.add(framebuffer);
        }
    }
    
    public void zerodayisaminecraftcheat() {
        for (final Framebuffer framebuffer : this.zues.values()) {
            framebuffer.zerodayisaminecraftcheat();
        }
        for (final Shader shader : this.pandora) {
            shader.zerodayisaminecraftcheat();
        }
        this.pandora.clear();
    }
    
    public Shader zerodayisaminecraftcheat(final String p_148023_1_, final Framebuffer p_148023_2_, final Framebuffer p_148023_3_) throws JsonException, IOException {
        final Shader shader = new Shader(this.zeroday, p_148023_1_, p_148023_2_, p_148023_3_);
        this.pandora.add(this.pandora.size(), shader);
        return shader;
    }
    
    private void sigma() {
        (this.vape = new Matrix4f()).setIdentity();
        this.vape.m00 = 2.0f / this.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        this.vape.m11 = 2.0f / -this.zerodayisaminecraftcheat.zeroday;
        this.vape.m22 = -0.0020001999f;
        this.vape.m33 = 1.0f;
        this.vape.m03 = -1.0f;
        this.vape.m13 = 1.0f;
        this.vape.m23 = -1.0001999f;
    }
    
    public void zerodayisaminecraftcheat(final int width, final int height) {
        this.momgetthecamera = this.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        this.a = this.zerodayisaminecraftcheat.zeroday;
        this.sigma();
        for (final Shader shader : this.pandora) {
            shader.zerodayisaminecraftcheat(this.vape);
        }
        for (final Framebuffer framebuffer : this.flux) {
            framebuffer.zerodayisaminecraftcheat(width, height);
        }
    }
    
    public void zerodayisaminecraftcheat(final float partialTicks) {
        if (partialTicks < this.c) {
            this.b += 1.0f - this.c;
            this.b += partialTicks;
        }
        else {
            this.b += partialTicks - this.c;
        }
        this.c = partialTicks;
        while (this.b > 20.0f) {
            this.b -= 20.0f;
        }
        for (final Shader shader : this.pandora) {
            shader.zerodayisaminecraftcheat(this.b / 20.0f);
        }
    }
    
    public final String zeroday() {
        return this.sigma;
    }
    
    private Framebuffer zeroday(final String p_148017_1_) {
        return (p_148017_1_ == null) ? null : (p_148017_1_.equals("minecraft:main") ? this.zerodayisaminecraftcheat : this.zues.get(p_148017_1_));
    }
}

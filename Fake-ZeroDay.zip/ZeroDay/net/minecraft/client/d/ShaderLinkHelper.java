// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import java.io.IOException;
import net.minecraft.client.f.JsonException;
import net.minecraft.client.a.OpenGlHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ShaderLinkHelper
{
    private static final Logger zerodayisaminecraftcheat;
    private static ShaderLinkHelper zeroday;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public static void zerodayisaminecraftcheat() {
        ShaderLinkHelper.zeroday = new ShaderLinkHelper();
    }
    
    public static ShaderLinkHelper zeroday() {
        return ShaderLinkHelper.zeroday;
    }
    
    public void zerodayisaminecraftcheat(final ShaderManager p_148077_1_) {
        p_148077_1_.flux().zeroday(p_148077_1_);
        p_148077_1_.zues().zeroday(p_148077_1_);
        OpenGlHelper.zues(p_148077_1_.vape());
    }
    
    public int sigma() throws JsonException {
        final int i = OpenGlHelper.pandora();
        if (i <= 0) {
            throw new JsonException("Could not create shader program (returned program ID " + i + ")");
        }
        return i;
    }
    
    public void zeroday(final ShaderManager manager) throws IOException {
        manager.flux().zerodayisaminecraftcheat(manager);
        manager.zues().zerodayisaminecraftcheat(manager);
        OpenGlHelper.flux(manager.vape());
        final int i = OpenGlHelper.zerodayisaminecraftcheat(manager.vape(), OpenGlHelper.e);
        if (i == 0) {
            ShaderLinkHelper.zerodayisaminecraftcheat.warn("Error encountered when linking program containing VS " + manager.zues().zerodayisaminecraftcheat() + " and FS " + manager.flux().zerodayisaminecraftcheat() + ". Log output:");
            ShaderLinkHelper.zerodayisaminecraftcheat.warn(OpenGlHelper.zues(manager.vape(), 32768));
        }
    }
}

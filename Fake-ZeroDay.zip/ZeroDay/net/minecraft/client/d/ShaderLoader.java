// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import com.google.common.collect.Maps;
import java.util.Map;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import net.minecraft.client.f.JsonException;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.BufferUtils;
import java.io.BufferedInputStream;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.b.IResourceManager;
import net.minecraft.client.a.OpenGlHelper;

public class ShaderLoader
{
    private final zerodayisaminecraftcheat zerodayisaminecraftcheat;
    private final String zeroday;
    private int sigma;
    private int pandora;
    
    private ShaderLoader(final zerodayisaminecraftcheat type, final int shaderId, final String filename) {
        this.pandora = 0;
        this.zerodayisaminecraftcheat = type;
        this.sigma = shaderId;
        this.zeroday = filename;
    }
    
    public void zerodayisaminecraftcheat(final ShaderManager manager) {
        ++this.pandora;
        OpenGlHelper.zeroday(manager.vape(), this.sigma);
    }
    
    public void zeroday(final ShaderManager manager) {
        --this.pandora;
        if (this.pandora <= 0) {
            OpenGlHelper.zerodayisaminecraftcheat(this.sigma);
            this.zerodayisaminecraftcheat.pandora().remove(this.zeroday);
        }
    }
    
    public String zerodayisaminecraftcheat() {
        return this.zeroday;
    }
    
    public static ShaderLoader zerodayisaminecraftcheat(final IResourceManager resourceManager, final zerodayisaminecraftcheat type, final String filename) throws IOException {
        ShaderLoader shaderloader = type.pandora().get(filename);
        if (shaderloader == null) {
            final ResourceLocation resourcelocation = new ResourceLocation("shaders/program/" + filename + type.zeroday());
            final BufferedInputStream bufferedinputstream = new BufferedInputStream(resourceManager.zerodayisaminecraftcheat(resourcelocation).zeroday());
            final byte[] abyte = zerodayisaminecraftcheat(bufferedinputstream);
            final ByteBuffer bytebuffer = BufferUtils.createByteBuffer(abyte.length);
            bytebuffer.put(abyte);
            bytebuffer.position(0);
            final int i = OpenGlHelper.zeroday(type.sigma());
            OpenGlHelper.zerodayisaminecraftcheat(i, bytebuffer);
            OpenGlHelper.sigma(i);
            if (OpenGlHelper.sigma(i, OpenGlHelper.f) == 0) {
                final String s = StringUtils.trim(OpenGlHelper.pandora(i, 32768));
                final JsonException jsonexception = new JsonException("Couldn't compile " + type.zerodayisaminecraftcheat() + " program: " + s);
                jsonexception.zeroday(resourcelocation.zeroday());
                throw jsonexception;
            }
            shaderloader = new ShaderLoader(type, i, filename);
            type.pandora().put(filename, shaderloader);
        }
        return shaderloader;
    }
    
    protected static byte[] zerodayisaminecraftcheat(final BufferedInputStream p_177064_0_) throws IOException {
        byte[] abyte;
        try {
            abyte = IOUtils.toByteArray((InputStream)p_177064_0_);
        }
        finally {
            p_177064_0_.close();
        }
        p_177064_0_.close();
        return abyte;
    }
    
    public enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("VERTEX", 0, "vertex", ".vsh", OpenGlHelper.g), 
        zeroday("FRAGMENT", 1, "fragment", ".fsh", OpenGlHelper.h);
        
        private final String sigma;
        private final String pandora;
        private final int zues;
        private final Map<String, ShaderLoader> flux;
        
        static {
            vape = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday };
        }
        
        private zerodayisaminecraftcheat(final String s, final int n, final String p_i45090_3_, final String p_i45090_4_, final int p_i45090_5_) {
            this.flux = (Map<String, ShaderLoader>)Maps.newHashMap();
            this.sigma = p_i45090_3_;
            this.pandora = p_i45090_4_;
            this.zues = p_i45090_5_;
        }
        
        public String zerodayisaminecraftcheat() {
            return this.sigma;
        }
        
        protected String zeroday() {
            return this.pandora;
        }
        
        protected int sigma() {
            return this.zues;
        }
        
        protected Map<String, ShaderLoader> pandora() {
            return this.flux;
        }
    }
}

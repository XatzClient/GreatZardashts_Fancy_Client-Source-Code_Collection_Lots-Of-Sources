// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import net.minecraft.client.a.zues.ITextureObject;
import net.minecraft.client.a.GlStateManager;
import java.io.IOException;
import java.util.Iterator;
import java.io.InputStream;
import net.minecraft.client.a.OpenGlHelper;
import com.google.gson.JsonObject;
import net.minecraft.client.f.JsonException;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import net.minecraft.o.JsonUtils;
import org.apache.commons.io.IOUtils;
import com.google.common.base.Charsets;
import net.minecraft.o.ResourceLocation;
import com.google.gson.JsonParser;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import net.minecraft.client.b.IResourceManager;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.f.JsonBlendingMode;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.Logger;

public class ShaderManager
{
    private static final Logger zerodayisaminecraftcheat;
    private static final ShaderDefault zeroday;
    private static ShaderManager sigma;
    private static int pandora;
    private static boolean zues;
    private final Map<String, Object> flux;
    private final List<String> vape;
    private final List<Integer> momgetthecamera;
    private final List<ShaderUniform> a;
    private final List<Integer> b;
    private final Map<String, ShaderUniform> c;
    private final int d;
    private final String e;
    private final boolean f;
    private boolean g;
    private final JsonBlendingMode h;
    private final List<Integer> i;
    private final List<String> j;
    private final ShaderLoader k;
    private final ShaderLoader l;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
        zeroday = new ShaderDefault();
        ShaderManager.sigma = null;
        ShaderManager.pandora = -1;
        ShaderManager.zues = true;
    }
    
    public ShaderManager(final IResourceManager resourceManager, final String programName) throws JsonException, IOException {
        this.flux = (Map<String, Object>)Maps.newHashMap();
        this.vape = (List<String>)Lists.newArrayList();
        this.momgetthecamera = (List<Integer>)Lists.newArrayList();
        this.a = (List<ShaderUniform>)Lists.newArrayList();
        this.b = (List<Integer>)Lists.newArrayList();
        this.c = (Map<String, ShaderUniform>)Maps.newHashMap();
        final JsonParser jsonparser = new JsonParser();
        final ResourceLocation resourcelocation = new ResourceLocation("shaders/program/" + programName + ".json");
        this.e = programName;
        InputStream inputstream = null;
        try {
            inputstream = resourceManager.zerodayisaminecraftcheat(resourcelocation).zeroday();
            final JsonObject jsonobject = jsonparser.parse(IOUtils.toString(inputstream, Charsets.UTF_8)).getAsJsonObject();
            final String s = JsonUtils.flux(jsonobject, "vertex");
            final String s2 = JsonUtils.flux(jsonobject, "fragment");
            final JsonArray jsonarray = JsonUtils.zerodayisaminecraftcheat(jsonobject, "samplers", (JsonArray)null);
            if (jsonarray != null) {
                int i = 0;
                for (final JsonElement jsonelement : jsonarray) {
                    try {
                        this.zerodayisaminecraftcheat(jsonelement);
                    }
                    catch (Exception exception2) {
                        final JsonException jsonexception1 = JsonException.zerodayisaminecraftcheat(exception2);
                        jsonexception1.zerodayisaminecraftcheat("samplers[" + i + "]");
                        throw jsonexception1;
                    }
                    ++i;
                }
            }
            final JsonArray jsonarray2 = JsonUtils.zerodayisaminecraftcheat(jsonobject, "attributes", (JsonArray)null);
            if (jsonarray2 != null) {
                int j = 0;
                this.i = (List<Integer>)Lists.newArrayListWithCapacity(jsonarray2.size());
                this.j = (List<String>)Lists.newArrayListWithCapacity(jsonarray2.size());
                for (final JsonElement jsonelement2 : jsonarray2) {
                    try {
                        this.j.add(JsonUtils.zerodayisaminecraftcheat(jsonelement2, "attribute"));
                    }
                    catch (Exception exception3) {
                        final JsonException jsonexception2 = JsonException.zerodayisaminecraftcheat(exception3);
                        jsonexception2.zerodayisaminecraftcheat("attributes[" + j + "]");
                        throw jsonexception2;
                    }
                    ++j;
                }
            }
            else {
                this.i = null;
                this.j = null;
            }
            final JsonArray jsonarray3 = JsonUtils.zerodayisaminecraftcheat(jsonobject, "uniforms", (JsonArray)null);
            if (jsonarray3 != null) {
                int k = 0;
                for (final JsonElement jsonelement3 : jsonarray3) {
                    try {
                        this.zeroday(jsonelement3);
                    }
                    catch (Exception exception4) {
                        final JsonException jsonexception3 = JsonException.zerodayisaminecraftcheat(exception4);
                        jsonexception3.zerodayisaminecraftcheat("uniforms[" + k + "]");
                        throw jsonexception3;
                    }
                    ++k;
                }
            }
            this.h = JsonBlendingMode.zerodayisaminecraftcheat(JsonUtils.zerodayisaminecraftcheat(jsonobject, "blend", (JsonObject)null));
            this.f = JsonUtils.zerodayisaminecraftcheat(jsonobject, "cull", true);
            this.k = ShaderLoader.zerodayisaminecraftcheat(resourceManager, ShaderLoader.zerodayisaminecraftcheat.zerodayisaminecraftcheat, s);
            this.l = ShaderLoader.zerodayisaminecraftcheat(resourceManager, ShaderLoader.zerodayisaminecraftcheat.zeroday, s2);
            this.d = ShaderLinkHelper.zeroday().sigma();
            ShaderLinkHelper.zeroday().zeroday(this);
            this.momgetthecamera();
            if (this.j != null) {
                for (final String s3 : this.j) {
                    final int l = OpenGlHelper.zeroday(this.d, s3);
                    this.i.add(l);
                }
            }
        }
        catch (Exception exception5) {
            final JsonException jsonexception4 = JsonException.zerodayisaminecraftcheat(exception5);
            jsonexception4.zeroday(resourcelocation.zeroday());
            throw jsonexception4;
        }
        finally {
            IOUtils.closeQuietly(inputstream);
        }
        IOUtils.closeQuietly(inputstream);
        this.pandora();
    }
    
    public void zerodayisaminecraftcheat() {
        ShaderLinkHelper.zeroday().zerodayisaminecraftcheat(this);
    }
    
    public void zeroday() {
        OpenGlHelper.pandora(0);
        ShaderManager.pandora = -1;
        ShaderManager.sigma = null;
        ShaderManager.zues = true;
        for (int i = 0; i < this.momgetthecamera.size(); ++i) {
            if (this.flux.get(this.vape.get(i)) != null) {
                GlStateManager.vape(OpenGlHelper.i + i);
                GlStateManager.a(0);
            }
        }
    }
    
    public void sigma() {
        this.g = false;
        ShaderManager.sigma = this;
        this.h.zerodayisaminecraftcheat();
        if (this.d != ShaderManager.pandora) {
            OpenGlHelper.pandora(this.d);
            ShaderManager.pandora = this.d;
        }
        if (this.f) {
            GlStateManager.g();
        }
        else {
            GlStateManager.h();
        }
        for (int i = 0; i < this.momgetthecamera.size(); ++i) {
            if (this.flux.get(this.vape.get(i)) != null) {
                GlStateManager.vape(OpenGlHelper.i + i);
                GlStateManager.m();
                final Object object = this.flux.get(this.vape.get(i));
                int j = -1;
                if (object instanceof Framebuffer) {
                    j = ((Framebuffer)object).vape;
                }
                else if (object instanceof ITextureObject) {
                    j = ((ITextureObject)object).zerodayisaminecraftcheat();
                }
                else if (object instanceof Integer) {
                    j = (int)object;
                }
                if (j != -1) {
                    GlStateManager.a(j);
                    OpenGlHelper.flux(OpenGlHelper.zerodayisaminecraftcheat(this.d, this.vape.get(i)), i);
                }
            }
        }
        for (final ShaderUniform shaderuniform : this.a) {
            shaderuniform.zeroday();
        }
    }
    
    public void pandora() {
        this.g = true;
    }
    
    public ShaderUniform zerodayisaminecraftcheat(final String p_147991_1_) {
        return this.c.containsKey(p_147991_1_) ? this.c.get(p_147991_1_) : null;
    }
    
    public ShaderUniform zeroday(final String p_147984_1_) {
        return this.c.containsKey(p_147984_1_) ? this.c.get(p_147984_1_) : ShaderManager.zeroday;
    }
    
    private void momgetthecamera() {
        for (int i = 0, j = 0; i < this.vape.size(); ++i, ++j) {
            final String s = this.vape.get(i);
            final int k = OpenGlHelper.zerodayisaminecraftcheat(this.d, s);
            if (k == -1) {
                ShaderManager.zerodayisaminecraftcheat.warn("Shader " + this.e + "could not find sampler named " + s + " in the specified shader program.");
                this.flux.remove(s);
                this.vape.remove(j);
                --j;
            }
            else {
                this.momgetthecamera.add(k);
            }
        }
        for (final ShaderUniform shaderuniform : this.a) {
            final String s2 = shaderuniform.zerodayisaminecraftcheat();
            final int l = OpenGlHelper.zerodayisaminecraftcheat(this.d, s2);
            if (l == -1) {
                ShaderManager.zerodayisaminecraftcheat.warn("Could not find uniform named " + s2 + " in the specified" + " shader program.");
            }
            else {
                this.b.add(l);
                shaderuniform.zerodayisaminecraftcheat(l);
                this.c.put(s2, shaderuniform);
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final JsonElement p_147996_1_) throws JsonException {
        final JsonObject jsonobject = JsonUtils.zues(p_147996_1_, "sampler");
        final String s = JsonUtils.flux(jsonobject, "name");
        if (!JsonUtils.zerodayisaminecraftcheat(jsonobject, "file")) {
            this.flux.put(s, null);
            this.vape.add(s);
        }
        else {
            this.vape.add(s);
        }
    }
    
    public void zerodayisaminecraftcheat(final String p_147992_1_, final Object p_147992_2_) {
        if (this.flux.containsKey(p_147992_1_)) {
            this.flux.remove(p_147992_1_);
        }
        this.flux.put(p_147992_1_, p_147992_2_);
        this.pandora();
    }
    
    private void zeroday(final JsonElement p_147987_1_) throws JsonException {
        final JsonObject jsonobject = JsonUtils.zues(p_147987_1_, "uniform");
        final String s = JsonUtils.flux(jsonobject, "name");
        final int i = ShaderUniform.zerodayisaminecraftcheat(JsonUtils.flux(jsonobject, "type"));
        final int j = JsonUtils.a(jsonobject, "count");
        final float[] afloat = new float[Math.max(j, 16)];
        final JsonArray jsonarray = JsonUtils.c(jsonobject, "values");
        if (jsonarray.size() != j && jsonarray.size() > 1) {
            throw new JsonException("Invalid amount of values specified (expected " + j + ", found " + jsonarray.size() + ")");
        }
        int k = 0;
        for (final JsonElement jsonelement : jsonarray) {
            try {
                afloat[k] = JsonUtils.sigma(jsonelement, "value");
            }
            catch (Exception exception) {
                final JsonException jsonexception = JsonException.zerodayisaminecraftcheat(exception);
                jsonexception.zerodayisaminecraftcheat("values[" + k + "]");
                throw jsonexception;
            }
            ++k;
        }
        if (j > 1 && jsonarray.size() == 1) {
            while (k < j) {
                afloat[k] = afloat[0];
                ++k;
            }
        }
        final int l = (j > 1 && j <= 4 && i < 8) ? (j - 1) : 0;
        final ShaderUniform shaderuniform = new ShaderUniform(s, i + l, j, this);
        if (i <= 3) {
            shaderuniform.zerodayisaminecraftcheat((int)afloat[0], (int)afloat[1], (int)afloat[2], (int)afloat[3]);
        }
        else if (i <= 7) {
            shaderuniform.zeroday(afloat[0], afloat[1], afloat[2], afloat[3]);
        }
        else {
            shaderuniform.zerodayisaminecraftcheat(afloat);
        }
        this.a.add(shaderuniform);
    }
    
    public ShaderLoader zues() {
        return this.k;
    }
    
    public ShaderLoader flux() {
        return this.l;
    }
    
    public int vape() {
        return this.d;
    }
}

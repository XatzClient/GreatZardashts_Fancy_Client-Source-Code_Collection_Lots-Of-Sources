// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.d;

import net.minecraft.client.a.OpenGlHelper;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.BufferUtils;
import org.apache.logging.log4j.LogManager;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.apache.logging.log4j.Logger;

public class ShaderUniform
{
    private static final Logger zerodayisaminecraftcheat;
    private int zeroday;
    private final int sigma;
    private final int pandora;
    private final IntBuffer zues;
    private final FloatBuffer flux;
    private final String vape;
    private boolean momgetthecamera;
    private final ShaderManager a;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public ShaderUniform(final String name, final int type, final int count, final ShaderManager manager) {
        this.vape = name;
        this.sigma = count;
        this.pandora = type;
        this.a = manager;
        if (type <= 3) {
            this.zues = BufferUtils.createIntBuffer(count);
            this.flux = null;
        }
        else {
            this.zues = null;
            this.flux = BufferUtils.createFloatBuffer(count);
        }
        this.zeroday = -1;
        this.sigma();
    }
    
    private void sigma() {
        this.momgetthecamera = true;
        if (this.a != null) {
            this.a.pandora();
        }
    }
    
    public static int zerodayisaminecraftcheat(final String p_148085_0_) {
        int i = -1;
        if (p_148085_0_.equals("int")) {
            i = 0;
        }
        else if (p_148085_0_.equals("float")) {
            i = 4;
        }
        else if (p_148085_0_.startsWith("matrix")) {
            if (p_148085_0_.endsWith("2x2")) {
                i = 8;
            }
            else if (p_148085_0_.endsWith("3x3")) {
                i = 9;
            }
            else if (p_148085_0_.endsWith("4x4")) {
                i = 10;
            }
        }
        return i;
    }
    
    public void zerodayisaminecraftcheat(final int p_148084_1_) {
        this.zeroday = p_148084_1_;
    }
    
    public String zerodayisaminecraftcheat() {
        return this.vape;
    }
    
    public void zerodayisaminecraftcheat(final float p_148090_1_) {
        this.flux.position(0);
        this.flux.put(0, p_148090_1_);
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final float p_148087_1_, final float p_148087_2_) {
        this.flux.position(0);
        this.flux.put(0, p_148087_1_);
        this.flux.put(1, p_148087_2_);
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final float p_148095_1_, final float p_148095_2_, final float p_148095_3_) {
        this.flux.position(0);
        this.flux.put(0, p_148095_1_);
        this.flux.put(1, p_148095_2_);
        this.flux.put(2, p_148095_3_);
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final float p_148081_1_, final float p_148081_2_, final float p_148081_3_, final float p_148081_4_) {
        this.flux.position(0);
        this.flux.put(p_148081_1_);
        this.flux.put(p_148081_2_);
        this.flux.put(p_148081_3_);
        this.flux.put(p_148081_4_);
        this.flux.flip();
        this.sigma();
    }
    
    public void zeroday(final float p_148092_1_, final float p_148092_2_, final float p_148092_3_, final float p_148092_4_) {
        this.flux.position(0);
        if (this.pandora >= 4) {
            this.flux.put(0, p_148092_1_);
        }
        if (this.pandora >= 5) {
            this.flux.put(1, p_148092_2_);
        }
        if (this.pandora >= 6) {
            this.flux.put(2, p_148092_3_);
        }
        if (this.pandora >= 7) {
            this.flux.put(3, p_148092_4_);
        }
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final int p_148083_1_, final int p_148083_2_, final int p_148083_3_, final int p_148083_4_) {
        this.zues.position(0);
        if (this.pandora >= 0) {
            this.zues.put(0, p_148083_1_);
        }
        if (this.pandora >= 1) {
            this.zues.put(1, p_148083_2_);
        }
        if (this.pandora >= 2) {
            this.zues.put(2, p_148083_3_);
        }
        if (this.pandora >= 3) {
            this.zues.put(3, p_148083_4_);
        }
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final float[] p_148097_1_) {
        if (p_148097_1_.length < this.sigma) {
            ShaderUniform.zerodayisaminecraftcheat.warn("Uniform.set called with a too-small value array (expected " + this.sigma + ", got " + p_148097_1_.length + "). Ignoring.");
        }
        else {
            this.flux.position(0);
            this.flux.put(p_148097_1_);
            this.flux.position(0);
            this.sigma();
        }
    }
    
    public void zerodayisaminecraftcheat(final float p_148094_1_, final float p_148094_2_, final float p_148094_3_, final float p_148094_4_, final float p_148094_5_, final float p_148094_6_, final float p_148094_7_, final float p_148094_8_, final float p_148094_9_, final float p_148094_10_, final float p_148094_11_, final float p_148094_12_, final float p_148094_13_, final float p_148094_14_, final float p_148094_15_, final float p_148094_16_) {
        this.flux.position(0);
        this.flux.put(0, p_148094_1_);
        this.flux.put(1, p_148094_2_);
        this.flux.put(2, p_148094_3_);
        this.flux.put(3, p_148094_4_);
        this.flux.put(4, p_148094_5_);
        this.flux.put(5, p_148094_6_);
        this.flux.put(6, p_148094_7_);
        this.flux.put(7, p_148094_8_);
        this.flux.put(8, p_148094_9_);
        this.flux.put(9, p_148094_10_);
        this.flux.put(10, p_148094_11_);
        this.flux.put(11, p_148094_12_);
        this.flux.put(12, p_148094_13_);
        this.flux.put(13, p_148094_14_);
        this.flux.put(14, p_148094_15_);
        this.flux.put(15, p_148094_16_);
        this.sigma();
    }
    
    public void zerodayisaminecraftcheat(final Matrix4f p_148088_1_) {
        this.zerodayisaminecraftcheat(p_148088_1_.m00, p_148088_1_.m01, p_148088_1_.m02, p_148088_1_.m03, p_148088_1_.m10, p_148088_1_.m11, p_148088_1_.m12, p_148088_1_.m13, p_148088_1_.m20, p_148088_1_.m21, p_148088_1_.m22, p_148088_1_.m23, p_148088_1_.m30, p_148088_1_.m31, p_148088_1_.m32, p_148088_1_.m33);
    }
    
    public void zeroday() {
        if (!this.momgetthecamera) {}
        this.momgetthecamera = false;
        if (this.pandora <= 3) {
            this.pandora();
        }
        else if (this.pandora <= 7) {
            this.zues();
        }
        else {
            if (this.pandora > 10) {
                ShaderUniform.zerodayisaminecraftcheat.warn("Uniform.upload called, but type value (" + this.pandora + ") is not " + "a valid type. Ignoring.");
                return;
            }
            this.flux();
        }
    }
    
    private void pandora() {
        switch (this.pandora) {
            case 0: {
                OpenGlHelper.zerodayisaminecraftcheat(this.zeroday, this.zues);
                break;
            }
            case 1: {
                OpenGlHelper.zeroday(this.zeroday, this.zues);
                break;
            }
            case 2: {
                OpenGlHelper.sigma(this.zeroday, this.zues);
                break;
            }
            case 3: {
                OpenGlHelper.pandora(this.zeroday, this.zues);
                break;
            }
            default: {
                ShaderUniform.zerodayisaminecraftcheat.warn("Uniform.upload called, but count value (" + this.sigma + ") is " + " not in the range of 1 to 4. Ignoring.");
                break;
            }
        }
    }
    
    private void zues() {
        switch (this.pandora) {
            case 4: {
                OpenGlHelper.zerodayisaminecraftcheat(this.zeroday, this.flux);
                break;
            }
            case 5: {
                OpenGlHelper.zeroday(this.zeroday, this.flux);
                break;
            }
            case 6: {
                OpenGlHelper.sigma(this.zeroday, this.flux);
                break;
            }
            case 7: {
                OpenGlHelper.pandora(this.zeroday, this.flux);
                break;
            }
            default: {
                ShaderUniform.zerodayisaminecraftcheat.warn("Uniform.upload called, but count value (" + this.sigma + ") is " + "not in the range of 1 to 4. Ignoring.");
                break;
            }
        }
    }
    
    private void flux() {
        switch (this.pandora) {
            case 8: {
                OpenGlHelper.zerodayisaminecraftcheat(this.zeroday, true, this.flux);
                break;
            }
            case 9: {
                OpenGlHelper.zeroday(this.zeroday, true, this.flux);
                break;
            }
            case 10: {
                OpenGlHelper.sigma(this.zeroday, true, this.flux);
                break;
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import net.minecraft.sigma.CrashReportCategory;
import net.minecraft.o.ReportedException;
import java.util.Arrays;
import net.minecraft.sigma.CrashReport;
import tv.twitch.broadcast.StartFlags;
import tv.twitch.broadcast.EncodingCpuUsage;
import tv.twitch.broadcast.StreamInfoForSetting;
import tv.twitch.MessageLevel;
import tv.twitch.broadcast.PixelFormat;
import tv.twitch.broadcast.StreamAPI;
import tv.twitch.broadcast.DesktopStreamAPI;
import tv.twitch.CoreAPI;
import tv.twitch.StandardCoreAPI;
import tv.twitch.broadcast.StatType;
import tv.twitch.broadcast.GameInfo;
import tv.twitch.broadcast.GameInfoList;
import com.google.common.collect.Lists;
import tv.twitch.broadcast.AudioDeviceType;
import org.apache.logging.log4j.LogManager;
import tv.twitch.broadcast.IStatCallbacks;
import tv.twitch.broadcast.IStreamCallbacks;
import tv.twitch.ErrorCode;
import tv.twitch.broadcast.ArchivingState;
import tv.twitch.broadcast.StreamInfo;
import tv.twitch.broadcast.UserInfo;
import tv.twitch.broadcast.ChannelInfo;
import tv.twitch.AuthToken;
import tv.twitch.broadcast.IngestServer;
import tv.twitch.broadcast.IngestList;
import tv.twitch.broadcast.AudioParams;
import tv.twitch.broadcast.VideoParams;
import tv.twitch.broadcast.FrameBuffer;
import java.util.List;
import tv.twitch.broadcast.Stream;
import tv.twitch.Core;
import net.minecraft.o.ThreadSafeBoundList;
import org.apache.logging.log4j.Logger;

public class BroadcastController
{
    private static final Logger v;
    protected final int zerodayisaminecraftcheat = 30;
    protected final int zeroday = 3;
    private static final ThreadSafeBoundList<String> w;
    private String x;
    protected zerodayisaminecraftcheat sigma;
    protected String pandora;
    protected String zues;
    protected String flux;
    protected boolean vape;
    protected Core momgetthecamera;
    protected Stream a;
    protected List<FrameBuffer> b;
    protected List<FrameBuffer> c;
    protected boolean d;
    protected boolean e;
    protected boolean f;
    protected zeroday g;
    protected String h;
    protected VideoParams i;
    protected AudioParams j;
    protected IngestList k;
    protected IngestServer l;
    protected AuthToken m;
    protected ChannelInfo n;
    protected UserInfo o;
    protected StreamInfo p;
    protected ArchivingState q;
    protected long r;
    protected IngestServerTester s;
    private ErrorCode y;
    protected IStreamCallbacks t;
    protected IStatCallbacks u;
    private static /* synthetic */ int[] z;
    
    static {
        v = LogManager.getLogger();
        w = new ThreadSafeBoundList<String>(String.class, 50);
    }
    
    public void zerodayisaminecraftcheat(final zerodayisaminecraftcheat p_152841_1_) {
        this.sigma = p_152841_1_;
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.d;
    }
    
    public void zerodayisaminecraftcheat(final String p_152842_1_) {
        this.pandora = p_152842_1_;
    }
    
    public StreamInfo zeroday() {
        return this.p;
    }
    
    public ChannelInfo sigma() {
        return this.n;
    }
    
    public boolean pandora() {
        return this.g == BroadcastController.zeroday.c || this.g == BroadcastController.zeroday.e;
    }
    
    public boolean zues() {
        return this.g == BroadcastController.zeroday.a;
    }
    
    public boolean flux() {
        return this.g == BroadcastController.zeroday.f;
    }
    
    public boolean vape() {
        return this.g == BroadcastController.zeroday.e;
    }
    
    public boolean momgetthecamera() {
        return this.e;
    }
    
    public IngestServer a() {
        return this.l;
    }
    
    public void zerodayisaminecraftcheat(final IngestServer p_152824_1_) {
        this.l = p_152824_1_;
    }
    
    public IngestList b() {
        return this.k;
    }
    
    public void zerodayisaminecraftcheat(final float p_152829_1_) {
        this.a.setVolume(AudioDeviceType.TTV_RECORDER_DEVICE, p_152829_1_);
    }
    
    public void zeroday(final float p_152837_1_) {
        this.a.setVolume(AudioDeviceType.TTV_PLAYBACK_DEVICE, p_152837_1_);
    }
    
    public IngestServerTester c() {
        return this.s;
    }
    
    public long d() {
        return this.a.getStreamTime();
    }
    
    protected boolean e() {
        return true;
    }
    
    public ErrorCode f() {
        return this.y;
    }
    
    public BroadcastController() {
        this.x = null;
        this.sigma = null;
        this.pandora = "";
        this.zues = "";
        this.flux = "";
        this.vape = true;
        this.momgetthecamera = null;
        this.a = null;
        this.b = (List<FrameBuffer>)Lists.newArrayList();
        this.c = (List<FrameBuffer>)Lists.newArrayList();
        this.d = false;
        this.e = false;
        this.f = false;
        this.g = BroadcastController.zeroday.zerodayisaminecraftcheat;
        this.h = null;
        this.i = null;
        this.j = null;
        this.k = new IngestList(new IngestServer[0]);
        this.l = null;
        this.m = new AuthToken();
        this.n = new ChannelInfo();
        this.o = new UserInfo();
        this.p = new StreamInfo();
        this.q = new ArchivingState();
        this.r = 0L;
        this.s = null;
        this.t = (IStreamCallbacks)new IStreamCallbacks() {
            public void requestAuthTokenCallback(final ErrorCode p_requestAuthTokenCallback_1_, final AuthToken p_requestAuthTokenCallback_2_) {
                if (ErrorCode.succeeded(p_requestAuthTokenCallback_1_)) {
                    BroadcastController.this.m = p_requestAuthTokenCallback_2_;
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.pandora);
                }
                else {
                    BroadcastController.this.m.data = "";
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.zeroday);
                    final String s = ErrorCode.getString(p_requestAuthTokenCallback_1_);
                    BroadcastController.this.zeroday(String.format("RequestAuthTokenDoneCallback got failure: %s", s));
                }
                try {
                    if (BroadcastController.this.sigma != null) {
                        BroadcastController.this.sigma.zerodayisaminecraftcheat(p_requestAuthTokenCallback_1_, p_requestAuthTokenCallback_2_);
                    }
                }
                catch (Exception exception) {
                    BroadcastController.this.zeroday(exception.toString());
                }
            }
            
            public void loginCallback(final ErrorCode p_loginCallback_1_, final ChannelInfo p_loginCallback_2_) {
                if (ErrorCode.succeeded(p_loginCallback_1_)) {
                    BroadcastController.this.n = p_loginCallback_2_;
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.flux);
                    BroadcastController.this.e = true;
                }
                else {
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.zeroday);
                    BroadcastController.this.e = false;
                    final String s = ErrorCode.getString(p_loginCallback_1_);
                    BroadcastController.this.zeroday(String.format("LoginCallback got failure: %s", s));
                }
                try {
                    if (BroadcastController.this.sigma != null) {
                        BroadcastController.this.sigma.zerodayisaminecraftcheat(p_loginCallback_1_);
                    }
                }
                catch (Exception exception) {
                    BroadcastController.this.zeroday(exception.toString());
                }
            }
            
            public void getIngestServersCallback(final ErrorCode p_getIngestServersCallback_1_, final IngestList p_getIngestServersCallback_2_) {
                if (ErrorCode.succeeded(p_getIngestServersCallback_1_)) {
                    BroadcastController.this.k = p_getIngestServersCallback_2_;
                    BroadcastController.this.l = BroadcastController.this.k.getDefaultServer();
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.momgetthecamera);
                    try {
                        if (BroadcastController.this.sigma != null) {
                            BroadcastController.this.sigma.zerodayisaminecraftcheat(p_getIngestServersCallback_2_);
                        }
                    }
                    catch (Exception exception) {
                        BroadcastController.this.zeroday(exception.toString());
                    }
                }
                else {
                    final String s = ErrorCode.getString(p_getIngestServersCallback_1_);
                    BroadcastController.this.zeroday(String.format("IngestListCallback got failure: %s", s));
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.zues);
                }
            }
            
            public void getUserInfoCallback(final ErrorCode p_getUserInfoCallback_1_, final UserInfo p_getUserInfoCallback_2_) {
                BroadcastController.this.o = p_getUserInfoCallback_2_;
                if (ErrorCode.failed(p_getUserInfoCallback_1_)) {
                    final String s = ErrorCode.getString(p_getUserInfoCallback_1_);
                    BroadcastController.this.zeroday(String.format("UserInfoDoneCallback got failure: %s", s));
                }
            }
            
            public void getStreamInfoCallback(final ErrorCode p_getStreamInfoCallback_1_, final StreamInfo p_getStreamInfoCallback_2_) {
                if (ErrorCode.succeeded(p_getStreamInfoCallback_1_)) {
                    BroadcastController.this.p = p_getStreamInfoCallback_2_;
                    try {
                        if (BroadcastController.this.sigma != null) {
                            BroadcastController.this.sigma.zerodayisaminecraftcheat(p_getStreamInfoCallback_2_);
                        }
                    }
                    catch (Exception exception) {
                        BroadcastController.this.zeroday(exception.toString());
                    }
                }
                else {
                    final String s = ErrorCode.getString(p_getStreamInfoCallback_1_);
                    BroadcastController.this.sigma(String.format("StreamInfoDoneCallback got failure: %s", s));
                }
            }
            
            public void getArchivingStateCallback(final ErrorCode p_getArchivingStateCallback_1_, final ArchivingState p_getArchivingStateCallback_2_) {
                BroadcastController.this.q = p_getArchivingStateCallback_2_;
                if (ErrorCode.failed(p_getArchivingStateCallback_1_)) {}
            }
            
            public void runCommercialCallback(final ErrorCode p_runCommercialCallback_1_) {
                if (ErrorCode.failed(p_runCommercialCallback_1_)) {
                    final String s = ErrorCode.getString(p_runCommercialCallback_1_);
                    BroadcastController.this.sigma(String.format("RunCommercialCallback got failure: %s", s));
                }
            }
            
            public void setStreamInfoCallback(final ErrorCode p_setStreamInfoCallback_1_) {
                if (ErrorCode.failed(p_setStreamInfoCallback_1_)) {
                    final String s = ErrorCode.getString(p_setStreamInfoCallback_1_);
                    BroadcastController.this.sigma(String.format("SetStreamInfoCallback got failure: %s", s));
                }
            }
            
            public void getGameNameListCallback(final ErrorCode p_getGameNameListCallback_1_, final GameInfoList p_getGameNameListCallback_2_) {
                if (ErrorCode.failed(p_getGameNameListCallback_1_)) {
                    final String s = ErrorCode.getString(p_getGameNameListCallback_1_);
                    BroadcastController.this.zeroday(String.format("GameNameListCallback got failure: %s", s));
                }
                try {
                    if (BroadcastController.this.sigma != null) {
                        BroadcastController.this.sigma.zerodayisaminecraftcheat(p_getGameNameListCallback_1_, (p_getGameNameListCallback_2_ == null) ? new GameInfo[0] : p_getGameNameListCallback_2_.list);
                    }
                }
                catch (Exception exception) {
                    BroadcastController.this.zeroday(exception.toString());
                }
            }
            
            public void bufferUnlockCallback(final long p_bufferUnlockCallback_1_) {
                final FrameBuffer framebuffer = FrameBuffer.lookupBuffer(p_bufferUnlockCallback_1_);
                BroadcastController.this.c.add(framebuffer);
            }
            
            public void startCallback(final ErrorCode p_startCallback_1_) {
                if (ErrorCode.succeeded(p_startCallback_1_)) {
                    try {
                        if (BroadcastController.this.sigma != null) {
                            BroadcastController.this.sigma.zeroday();
                        }
                    }
                    catch (Exception exception1) {
                        BroadcastController.this.zeroday(exception1.toString());
                    }
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.c);
                }
                else {
                    BroadcastController.this.i = null;
                    BroadcastController.this.j = null;
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.a);
                    try {
                        if (BroadcastController.this.sigma != null) {
                            BroadcastController.this.sigma.sigma(p_startCallback_1_);
                        }
                    }
                    catch (Exception exception2) {
                        BroadcastController.this.zeroday(exception2.toString());
                    }
                    final String s = ErrorCode.getString(p_startCallback_1_);
                    BroadcastController.this.zeroday(String.format("startCallback got failure: %s", s));
                }
            }
            
            public void stopCallback(final ErrorCode p_stopCallback_1_) {
                if (ErrorCode.succeeded(p_stopCallback_1_)) {
                    BroadcastController.this.i = null;
                    BroadcastController.this.j = null;
                    BroadcastController.this.t();
                    try {
                        if (BroadcastController.this.sigma != null) {
                            BroadcastController.this.sigma.sigma();
                        }
                    }
                    catch (Exception exception) {
                        BroadcastController.this.zeroday(exception.toString());
                    }
                    if (BroadcastController.this.e) {
                        BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.a);
                    }
                    else {
                        BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.zeroday);
                    }
                }
                else {
                    BroadcastController.this.zerodayisaminecraftcheat(BroadcastController.zeroday.a);
                    final String s = ErrorCode.getString(p_stopCallback_1_);
                    BroadcastController.this.zeroday(String.format("stopCallback got failure: %s", s));
                }
            }
            
            public void sendActionMetaDataCallback(final ErrorCode p_sendActionMetaDataCallback_1_) {
                if (ErrorCode.failed(p_sendActionMetaDataCallback_1_)) {
                    final String s = ErrorCode.getString(p_sendActionMetaDataCallback_1_);
                    BroadcastController.this.zeroday(String.format("sendActionMetaDataCallback got failure: %s", s));
                }
            }
            
            public void sendStartSpanMetaDataCallback(final ErrorCode p_sendStartSpanMetaDataCallback_1_) {
                if (ErrorCode.failed(p_sendStartSpanMetaDataCallback_1_)) {
                    final String s = ErrorCode.getString(p_sendStartSpanMetaDataCallback_1_);
                    BroadcastController.this.zeroday(String.format("sendStartSpanMetaDataCallback got failure: %s", s));
                }
            }
            
            public void sendEndSpanMetaDataCallback(final ErrorCode p_sendEndSpanMetaDataCallback_1_) {
                if (ErrorCode.failed(p_sendEndSpanMetaDataCallback_1_)) {
                    final String s = ErrorCode.getString(p_sendEndSpanMetaDataCallback_1_);
                    BroadcastController.this.zeroday(String.format("sendEndSpanMetaDataCallback got failure: %s", s));
                }
            }
        };
        this.u = (IStatCallbacks)new IStatCallbacks() {
            public void statCallback(final StatType p_statCallback_1_, final long p_statCallback_2_) {
            }
        };
        this.momgetthecamera = Core.getInstance();
        if (Core.getInstance() == null) {
            this.momgetthecamera = new Core((CoreAPI)new StandardCoreAPI());
        }
        this.a = new Stream((StreamAPI)new DesktopStreamAPI());
    }
    
    protected PixelFormat g() {
        return PixelFormat.TTV_PF_RGBA;
    }
    
    public boolean h() {
        if (this.d) {
            return false;
        }
        this.a.setStreamCallbacks(this.t);
        ErrorCode errorcode = this.momgetthecamera.initialize(this.pandora, System.getProperty("java.library.path"));
        if (!this.zerodayisaminecraftcheat(errorcode)) {
            this.a.setStreamCallbacks((IStreamCallbacks)null);
            this.y = errorcode;
            return false;
        }
        errorcode = this.momgetthecamera.setTraceLevel(MessageLevel.TTV_ML_ERROR);
        if (!this.zerodayisaminecraftcheat(errorcode)) {
            this.a.setStreamCallbacks((IStreamCallbacks)null);
            this.momgetthecamera.shutdown();
            this.y = errorcode;
            return false;
        }
        if (ErrorCode.succeeded(errorcode)) {
            this.d = true;
            this.zerodayisaminecraftcheat(BroadcastController.zeroday.zeroday);
            return true;
        }
        this.y = errorcode;
        this.momgetthecamera.shutdown();
        return false;
    }
    
    public boolean i() {
        if (!this.d) {
            return true;
        }
        if (this.flux()) {
            return false;
        }
        this.f = true;
        this.k();
        this.a.setStreamCallbacks((IStreamCallbacks)null);
        this.a.setStatCallbacks((IStatCallbacks)null);
        final ErrorCode errorcode = this.momgetthecamera.shutdown();
        this.zerodayisaminecraftcheat(errorcode);
        this.d = false;
        this.f = false;
        this.zerodayisaminecraftcheat(BroadcastController.zeroday.zerodayisaminecraftcheat);
        return true;
    }
    
    public void j() {
        if (this.g != BroadcastController.zeroday.zerodayisaminecraftcheat) {
            if (this.s != null) {
                this.s.vape();
            }
            while (this.s != null) {
                try {
                    Thread.sleep(200L);
                }
                catch (Exception exception) {
                    this.zeroday(exception.toString());
                }
                this.p();
            }
            this.i();
        }
    }
    
    public boolean zerodayisaminecraftcheat(final String p_152818_1_, final AuthToken p_152818_2_) {
        if (this.flux()) {
            return false;
        }
        this.k();
        if (p_152818_1_ == null || p_152818_1_.isEmpty()) {
            this.zeroday("Username must be valid");
            return false;
        }
        if (p_152818_2_ != null && p_152818_2_.data != null && !p_152818_2_.data.isEmpty()) {
            this.h = p_152818_1_;
            this.m = p_152818_2_;
            if (this.zerodayisaminecraftcheat()) {
                this.zerodayisaminecraftcheat(BroadcastController.zeroday.pandora);
            }
            return true;
        }
        this.zeroday("Auth token must be valid");
        return false;
    }
    
    public boolean k() {
        if (this.flux()) {
            return false;
        }
        if (this.pandora()) {
            this.a.stop(false);
        }
        this.h = "";
        this.m = new AuthToken();
        if (!this.e) {
            return false;
        }
        this.e = false;
        if (!this.f) {
            try {
                if (this.sigma != null) {
                    this.sigma.zerodayisaminecraftcheat();
                }
            }
            catch (Exception exception) {
                this.zeroday(exception.toString());
            }
        }
        this.zerodayisaminecraftcheat(BroadcastController.zeroday.zeroday);
        return true;
    }
    
    public boolean zerodayisaminecraftcheat(String p_152828_1_, String p_152828_2_, String p_152828_3_) {
        if (!this.e) {
            return false;
        }
        if (p_152828_1_ == null || p_152828_1_.equals("")) {
            p_152828_1_ = this.h;
        }
        if (p_152828_2_ == null) {
            p_152828_2_ = "";
        }
        if (p_152828_3_ == null) {
            p_152828_3_ = "";
        }
        final StreamInfoForSetting streaminfoforsetting = new StreamInfoForSetting();
        streaminfoforsetting.streamTitle = p_152828_3_;
        streaminfoforsetting.gameName = p_152828_2_;
        final ErrorCode errorcode = this.a.setStreamInfo(this.m, p_152828_1_, streaminfoforsetting);
        this.zerodayisaminecraftcheat(errorcode);
        return ErrorCode.succeeded(errorcode);
    }
    
    public boolean l() {
        if (!this.pandora()) {
            return false;
        }
        final ErrorCode errorcode = this.a.runCommercial(this.m);
        this.zerodayisaminecraftcheat(errorcode);
        return ErrorCode.succeeded(errorcode);
    }
    
    public VideoParams zerodayisaminecraftcheat(final int maxKbps, final int p_152834_2_, final float p_152834_3_, final float p_152834_4_) {
        final int[] aint = this.a.getMaxResolution(maxKbps, p_152834_2_, p_152834_3_, p_152834_4_);
        final VideoParams videoparams = new VideoParams();
        videoparams.maxKbps = maxKbps;
        videoparams.encodingCpuUsage = EncodingCpuUsage.TTV_ECU_HIGH;
        videoparams.pixelFormat = this.g();
        videoparams.targetFps = p_152834_2_;
        videoparams.outputWidth = aint[0];
        videoparams.outputHeight = aint[1];
        videoparams.disableAdaptiveBitrate = false;
        videoparams.verticalFlip = false;
        return videoparams;
    }
    
    public boolean zerodayisaminecraftcheat(final VideoParams p_152836_1_) {
        if (p_152836_1_ == null || !this.zues()) {
            return false;
        }
        this.i = p_152836_1_.clone();
        this.j = new AudioParams();
        this.j.audioEnabled = (this.vape && this.e());
        this.j.enableMicCapture = this.j.audioEnabled;
        this.j.enablePlaybackCapture = this.j.audioEnabled;
        this.j.enablePassthroughAudio = false;
        if (!this.s()) {
            this.i = null;
            this.j = null;
            return false;
        }
        final ErrorCode errorcode = this.a.start(p_152836_1_, this.j, this.l, StartFlags.None, true);
        if (ErrorCode.failed(errorcode)) {
            this.t();
            final String s = ErrorCode.getString(errorcode);
            this.zeroday(String.format("Error while starting to broadcast: %s", s));
            this.i = null;
            this.j = null;
            return false;
        }
        this.zerodayisaminecraftcheat(BroadcastController.zeroday.b);
        return true;
    }
    
    public boolean m() {
        if (!this.pandora()) {
            return false;
        }
        final ErrorCode errorcode = this.a.stop(true);
        if (ErrorCode.failed(errorcode)) {
            final String s = ErrorCode.getString(errorcode);
            this.zeroday(String.format("Error while stopping the broadcast: %s", s));
            return false;
        }
        this.zerodayisaminecraftcheat(BroadcastController.zeroday.d);
        return ErrorCode.succeeded(errorcode);
    }
    
    public boolean n() {
        if (!this.pandora()) {
            return false;
        }
        final ErrorCode errorcode = this.a.pauseVideo();
        if (ErrorCode.failed(errorcode)) {
            this.m();
            final String s = ErrorCode.getString(errorcode);
            this.zeroday(String.format("Error pausing stream: %s\n", s));
        }
        else {
            this.zerodayisaminecraftcheat(BroadcastController.zeroday.e);
        }
        return ErrorCode.succeeded(errorcode);
    }
    
    public boolean o() {
        if (!this.vape()) {
            return false;
        }
        this.zerodayisaminecraftcheat(BroadcastController.zeroday.c);
        return true;
    }
    
    public boolean zerodayisaminecraftcheat(final String p_152840_1_, final long p_152840_2_, final String p_152840_4_, final String p_152840_5_) {
        final ErrorCode errorcode = this.a.sendActionMetaData(this.m, p_152840_1_, p_152840_2_, p_152840_4_, p_152840_5_);
        if (ErrorCode.failed(errorcode)) {
            final String s = ErrorCode.getString(errorcode);
            this.zeroday(String.format("Error while sending meta data: %s\n", s));
            return false;
        }
        return true;
    }
    
    public long zeroday(final String p_177946_1_, final long p_177946_2_, final String p_177946_4_, final String p_177946_5_) {
        final long i = this.a.sendStartSpanMetaData(this.m, p_177946_1_, p_177946_2_, p_177946_4_, p_177946_5_);
        if (i == -1L) {
            this.zeroday(String.format("Error in SendStartSpanMetaData\n", new Object[0]));
        }
        return i;
    }
    
    public boolean zerodayisaminecraftcheat(final String p_177947_1_, final long p_177947_2_, final long p_177947_4_, final String p_177947_6_, final String p_177947_7_) {
        if (p_177947_4_ == -1L) {
            this.zeroday(String.format("Invalid sequence id: %d\n", p_177947_4_));
            return false;
        }
        final ErrorCode errorcode = this.a.sendEndSpanMetaData(this.m, p_177947_1_, p_177947_2_, p_177947_4_, p_177947_6_, p_177947_7_);
        if (ErrorCode.failed(errorcode)) {
            final String s = ErrorCode.getString(errorcode);
            this.zeroday(String.format("Error in SendStopSpanMetaData: %s\n", s));
            return false;
        }
        return true;
    }
    
    protected void zerodayisaminecraftcheat(final zeroday p_152827_1_) {
        if (p_152827_1_ != this.g) {
            this.g = p_152827_1_;
            try {
                if (this.sigma != null) {
                    this.sigma.zerodayisaminecraftcheat(p_152827_1_);
                }
            }
            catch (Exception exception) {
                this.zeroday(exception.toString());
            }
        }
    }
    
    public void p() {
        if (this.a != null && this.d) {
            ErrorCode errorcode = this.a.pollTasks();
            this.zerodayisaminecraftcheat(errorcode);
            if (this.flux()) {
                this.s.flux();
                if (this.s.sigma()) {
                    this.s = null;
                    this.zerodayisaminecraftcheat(BroadcastController.zeroday.a);
                }
            }
            switch (v()[this.g.ordinal()]) {
                case 4: {
                    this.zerodayisaminecraftcheat(BroadcastController.zeroday.zues);
                    errorcode = this.a.login(this.m);
                    if (ErrorCode.failed(errorcode)) {
                        final String s3 = ErrorCode.getString(errorcode);
                        this.zeroday(String.format("Error in TTV_Login: %s\n", s3));
                        break;
                    }
                    break;
                }
                case 6: {
                    this.zerodayisaminecraftcheat(BroadcastController.zeroday.vape);
                    errorcode = this.a.getIngestServers(this.m);
                    if (ErrorCode.failed(errorcode)) {
                        this.zerodayisaminecraftcheat(BroadcastController.zeroday.flux);
                        final String s4 = ErrorCode.getString(errorcode);
                        this.zeroday(String.format("Error in TTV_GetIngestServers: %s\n", s4));
                        break;
                    }
                    break;
                }
                case 8: {
                    this.zerodayisaminecraftcheat(BroadcastController.zeroday.a);
                    errorcode = this.a.getUserInfo(this.m);
                    if (ErrorCode.failed(errorcode)) {
                        final String s5 = ErrorCode.getString(errorcode);
                        this.zeroday(String.format("Error in TTV_GetUserInfo: %s\n", s5));
                    }
                    this.q();
                    errorcode = this.a.getArchivingState(this.m);
                    if (ErrorCode.failed(errorcode)) {
                        final String s6 = ErrorCode.getString(errorcode);
                        this.zeroday(String.format("Error in TTV_GetArchivingState: %s\n", s6));
                        break;
                    }
                    break;
                }
                case 11:
                case 13: {
                    this.q();
                    break;
                }
            }
        }
    }
    
    protected void q() {
        final long i = System.nanoTime();
        final long j = (i - this.r) / 1000000000L;
        if (j >= 30L) {
            this.r = i;
            final ErrorCode errorcode = this.a.getStreamInfo(this.m, this.h);
            if (ErrorCode.failed(errorcode)) {
                final String s = ErrorCode.getString(errorcode);
                this.zeroday(String.format("Error in TTV_GetStreamInfo: %s", s));
            }
        }
    }
    
    public IngestServerTester r() {
        if (!this.zues() || this.k == null) {
            return null;
        }
        if (this.flux()) {
            return null;
        }
        (this.s = new IngestServerTester(this.a, this.k)).zues();
        this.zerodayisaminecraftcheat(BroadcastController.zeroday.f);
        return this.s;
    }
    
    protected boolean s() {
        for (int i = 0; i < 3; ++i) {
            final FrameBuffer framebuffer = this.a.allocateFrameBuffer(this.i.outputWidth * this.i.outputHeight * 4);
            if (!framebuffer.getIsValid()) {
                this.zeroday(String.format("Error while allocating frame buffer", new Object[0]));
                return false;
            }
            this.b.add(framebuffer);
            this.c.add(framebuffer);
        }
        return true;
    }
    
    protected void t() {
        for (int i = 0; i < this.b.size(); ++i) {
            final FrameBuffer framebuffer = this.b.get(i);
            framebuffer.free();
        }
        this.c.clear();
        this.b.clear();
    }
    
    public FrameBuffer u() {
        if (this.c.size() == 0) {
            this.zeroday(String.format("Out of free buffers, this should never happen", new Object[0]));
            return null;
        }
        final FrameBuffer framebuffer = this.c.get(this.c.size() - 1);
        this.c.remove(this.c.size() - 1);
        return framebuffer;
    }
    
    public void zerodayisaminecraftcheat(final FrameBuffer p_152846_1_) {
        try {
            this.a.captureFrameBuffer_ReadPixels(p_152846_1_);
        }
        catch (Throwable throwable) {
            final CrashReport crashreport = CrashReport.zerodayisaminecraftcheat(throwable, "Trying to submit a frame to Twitch");
            final CrashReportCategory crashreportcategory = crashreport.zerodayisaminecraftcheat("Broadcast State");
            crashreportcategory.zerodayisaminecraftcheat("Last reported errors", Arrays.toString(BroadcastController.w.zeroday()));
            crashreportcategory.zerodayisaminecraftcheat("Buffer", p_152846_1_);
            crashreportcategory.zerodayisaminecraftcheat("Free buffer count", this.c.size());
            crashreportcategory.zerodayisaminecraftcheat("Capture buffer count", this.b.size());
            throw new ReportedException(crashreport);
        }
    }
    
    public ErrorCode zeroday(final FrameBuffer p_152859_1_) {
        if (this.vape()) {
            this.o();
        }
        else if (!this.pandora()) {
            return ErrorCode.TTV_EC_STREAM_NOT_STARTED;
        }
        final ErrorCode errorcode = this.a.submitVideoFrame(p_152859_1_);
        if (errorcode != ErrorCode.TTV_EC_SUCCESS) {
            final String s = ErrorCode.getString(errorcode);
            if (ErrorCode.succeeded(errorcode)) {
                this.sigma(String.format("Warning in SubmitTexturePointer: %s\n", s));
            }
            else {
                this.zeroday(String.format("Error in SubmitTexturePointer: %s\n", s));
                this.m();
            }
            if (this.sigma != null) {
                this.sigma.zeroday(errorcode);
            }
        }
        return errorcode;
    }
    
    protected boolean zerodayisaminecraftcheat(final ErrorCode p_152853_1_) {
        if (ErrorCode.failed(p_152853_1_)) {
            this.zeroday(ErrorCode.getString(p_152853_1_));
            return false;
        }
        return true;
    }
    
    protected void zeroday(final String p_152820_1_) {
        this.x = p_152820_1_;
        BroadcastController.w.zerodayisaminecraftcheat("<Error> " + p_152820_1_);
        BroadcastController.v.error(TwitchStream.zerodayisaminecraftcheat, "[Broadcast controller] {}", new Object[] { p_152820_1_ });
    }
    
    protected void sigma(final String p_152832_1_) {
        BroadcastController.w.zerodayisaminecraftcheat("<Warning> " + p_152832_1_);
        BroadcastController.v.warn(TwitchStream.zerodayisaminecraftcheat, "[Broadcast controller] {}", new Object[] { p_152832_1_ });
    }
    
    static /* synthetic */ int[] v() {
        final int[] z = BroadcastController.z;
        if (z != null) {
            return z;
        }
        final int[] z2 = new int[zeroday.values().length];
        try {
            z2[zeroday.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            z2[zeroday.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            z2[zeroday.c.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            z2[zeroday.vape.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            z2[zeroday.f.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            z2[zeroday.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            z2[zeroday.flux.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            z2[zeroday.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            z2[zeroday.e.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            z2[zeroday.a.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        try {
            z2[zeroday.momgetthecamera.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError11) {}
        try {
            z2[zeroday.b.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError12) {}
        try {
            z2[zeroday.d.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError13) {}
        try {
            z2[zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError14) {}
        return BroadcastController.z = z2;
    }
    
    public enum zeroday
    {
        zerodayisaminecraftcheat("Uninitialized", 0), 
        zeroday("Initialized", 1), 
        sigma("Authenticating", 2), 
        pandora("Authenticated", 3), 
        zues("LoggingIn", 4), 
        flux("LoggedIn", 5), 
        vape("FindingIngestServer", 6), 
        momgetthecamera("ReceivedIngestServers", 7), 
        a("ReadyToBroadcast", 8), 
        b("Starting", 9), 
        c("Broadcasting", 10), 
        d("Stopping", 11), 
        e("Paused", 12), 
        f("IngestTesting", 13);
        
        static {
            g = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday, zeroday.sigma, zeroday.pandora, zeroday.zues, zeroday.flux, zeroday.vape, zeroday.momgetthecamera, zeroday.a, zeroday.b, zeroday.c, zeroday.d, zeroday.e, zeroday.f };
        }
        
        private zeroday(final String s, final int n) {
        }
    }
    
    public interface zerodayisaminecraftcheat
    {
        void zerodayisaminecraftcheat(final ErrorCode p0, final AuthToken p1);
        
        void zerodayisaminecraftcheat(final ErrorCode p0);
        
        void zerodayisaminecraftcheat(final ErrorCode p0, final GameInfo[] p1);
        
        void zerodayisaminecraftcheat(final zeroday p0);
        
        void zerodayisaminecraftcheat();
        
        void zerodayisaminecraftcheat(final StreamInfo p0);
        
        void zerodayisaminecraftcheat(final IngestList p0);
        
        void zeroday(final ErrorCode p0);
        
        void zeroday();
        
        void sigma();
        
        void sigma(final ErrorCode p0);
    }
}

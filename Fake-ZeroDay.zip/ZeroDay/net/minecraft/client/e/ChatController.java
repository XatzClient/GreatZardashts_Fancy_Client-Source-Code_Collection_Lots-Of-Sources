// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import tv.twitch.chat.ChatChannelInfo;
import tv.twitch.chat.ChatEvent;
import java.util.ListIterator;
import com.google.common.collect.Lists;
import tv.twitch.chat.ChatBadgeData;
import tv.twitch.chat.ChatTokenizedMessage;
import tv.twitch.chat.ChatRawMessage;
import java.util.LinkedList;
import tv.twitch.chat.ChatUserInfo;
import java.util.List;
import tv.twitch.chat.IChatChannelListener;
import tv.twitch.chat.ChatTokenizationOption;
import java.util.HashSet;
import tv.twitch.chat.ChatAPI;
import tv.twitch.chat.StandardChatAPI;
import tv.twitch.CoreAPI;
import tv.twitch.StandardCoreAPI;
import tv.twitch.ErrorCode;
import org.apache.logging.log4j.LogManager;
import tv.twitch.chat.IChatAPIListener;
import tv.twitch.chat.ChatEmoticonData;
import java.util.HashMap;
import tv.twitch.AuthToken;
import tv.twitch.chat.Chat;
import tv.twitch.Core;
import org.apache.logging.log4j.Logger;

public class ChatController
{
    private static final Logger i;
    protected zeroday zerodayisaminecraftcheat;
    protected String zeroday;
    protected String sigma;
    protected String pandora;
    protected Core zues;
    protected Chat flux;
    protected sigma vape;
    protected AuthToken momgetthecamera;
    protected HashMap<String, zerodayisaminecraftcheat> a;
    protected int b;
    protected zues c;
    protected zues d;
    protected ChatEmoticonData e;
    protected int f;
    protected int g;
    protected IChatAPIListener h;
    private static /* synthetic */ int[] j;
    
    static {
        i = LogManager.getLogger();
    }
    
    public void zerodayisaminecraftcheat(final zeroday p_152990_1_) {
        this.zerodayisaminecraftcheat = p_152990_1_;
    }
    
    public void zerodayisaminecraftcheat(final AuthToken p_152994_1_) {
        this.momgetthecamera = p_152994_1_;
    }
    
    public void zerodayisaminecraftcheat(final String p_152984_1_) {
        this.sigma = p_152984_1_;
    }
    
    public void zeroday(final String p_152998_1_) {
        this.zeroday = p_152998_1_;
    }
    
    public sigma zerodayisaminecraftcheat() {
        return this.vape;
    }
    
    public boolean sigma(final String p_175990_1_) {
        if (!this.a.containsKey(p_175990_1_)) {
            return false;
        }
        final zerodayisaminecraftcheat chatcontroller$chatchannellistener = this.a.get(p_175990_1_);
        return chatcontroller$chatchannellistener.zerodayisaminecraftcheat() == ChatController.pandora.sigma;
    }
    
    public pandora pandora(final String p_175989_1_) {
        if (!this.a.containsKey(p_175989_1_)) {
            return ChatController.pandora.zues;
        }
        final zerodayisaminecraftcheat chatcontroller$chatchannellistener = this.a.get(p_175989_1_);
        return chatcontroller$chatchannellistener.zerodayisaminecraftcheat();
    }
    
    public ChatController() {
        this.zerodayisaminecraftcheat = null;
        this.zeroday = "";
        this.sigma = "";
        this.pandora = "";
        this.zues = null;
        this.flux = null;
        this.vape = ChatController.sigma.zerodayisaminecraftcheat;
        this.momgetthecamera = new AuthToken();
        this.a = new HashMap<String, zerodayisaminecraftcheat>();
        this.b = 128;
        this.c = ChatController.zues.zerodayisaminecraftcheat;
        this.d = ChatController.zues.zerodayisaminecraftcheat;
        this.e = null;
        this.f = 500;
        this.g = 2000;
        this.h = (IChatAPIListener)new IChatAPIListener() {
            public void chatInitializationCallback(final ErrorCode p_chatInitializationCallback_1_) {
                if (ErrorCode.succeeded(p_chatInitializationCallback_1_)) {
                    ChatController.this.flux.setMessageFlushInterval(ChatController.this.f);
                    ChatController.this.flux.setUserChangeEventInterval(ChatController.this.g);
                    ChatController.this.flux();
                    ChatController.this.zerodayisaminecraftcheat(ChatController.sigma.sigma);
                }
                else {
                    ChatController.this.zerodayisaminecraftcheat(ChatController.sigma.zerodayisaminecraftcheat);
                }
                try {
                    if (ChatController.this.zerodayisaminecraftcheat != null) {
                        ChatController.this.zerodayisaminecraftcheat.pandora(p_chatInitializationCallback_1_);
                    }
                }
                catch (Exception exception) {
                    ChatController.this.vape(exception.toString());
                }
            }
            
            public void chatShutdownCallback(final ErrorCode p_chatShutdownCallback_1_) {
                if (ErrorCode.succeeded(p_chatShutdownCallback_1_)) {
                    final ErrorCode errorcode = ChatController.this.zues.shutdown();
                    if (ErrorCode.failed(errorcode)) {
                        final String s = ErrorCode.getString(errorcode);
                        ChatController.this.vape(String.format("Error shutting down the Twitch sdk: %s", s));
                    }
                    ChatController.this.zerodayisaminecraftcheat(ChatController.sigma.zerodayisaminecraftcheat);
                }
                else {
                    ChatController.this.zerodayisaminecraftcheat(ChatController.sigma.sigma);
                    ChatController.this.vape(String.format("Error shutting down Twith chat: %s", p_chatShutdownCallback_1_));
                }
                try {
                    if (ChatController.this.zerodayisaminecraftcheat != null) {
                        ChatController.this.zerodayisaminecraftcheat.zues(p_chatShutdownCallback_1_);
                    }
                }
                catch (Exception exception) {
                    ChatController.this.vape(exception.toString());
                }
            }
            
            public void chatEmoticonDataDownloadCallback(final ErrorCode p_chatEmoticonDataDownloadCallback_1_) {
                if (ErrorCode.succeeded(p_chatEmoticonDataDownloadCallback_1_)) {
                    ChatController.this.vape();
                }
            }
        };
        this.zues = Core.getInstance();
        if (this.zues == null) {
            this.zues = new Core((CoreAPI)new StandardCoreAPI());
        }
        this.flux = new Chat((ChatAPI)new StandardChatAPI());
    }
    
    public boolean zeroday() {
        if (this.vape != ChatController.sigma.zerodayisaminecraftcheat) {
            return false;
        }
        this.zerodayisaminecraftcheat(ChatController.sigma.zeroday);
        ErrorCode errorcode = this.zues.initialize(this.sigma, (String)null);
        if (ErrorCode.failed(errorcode)) {
            this.zerodayisaminecraftcheat(ChatController.sigma.zerodayisaminecraftcheat);
            final String s1 = ErrorCode.getString(errorcode);
            this.vape(String.format("Error initializing Twitch sdk: %s", s1));
            return false;
        }
        this.d = this.c;
        final HashSet<ChatTokenizationOption> hashset = new HashSet<ChatTokenizationOption>();
        switch (a()[this.c.ordinal()]) {
            case 1: {
                hashset.add(ChatTokenizationOption.TTV_CHAT_TOKENIZATION_OPTION_NONE);
                break;
            }
            case 2: {
                hashset.add(ChatTokenizationOption.TTV_CHAT_TOKENIZATION_OPTION_EMOTICON_URLS);
                break;
            }
            case 3: {
                hashset.add(ChatTokenizationOption.TTV_CHAT_TOKENIZATION_OPTION_EMOTICON_TEXTURES);
                break;
            }
        }
        errorcode = this.flux.initialize((HashSet)hashset, this.h);
        if (ErrorCode.failed(errorcode)) {
            this.zues.shutdown();
            this.zerodayisaminecraftcheat(ChatController.sigma.zerodayisaminecraftcheat);
            final String s2 = ErrorCode.getString(errorcode);
            this.vape(String.format("Error initializing Twitch chat: %s", s2));
            return false;
        }
        this.zerodayisaminecraftcheat(ChatController.sigma.sigma);
        return true;
    }
    
    public boolean zues(final String p_152986_1_) {
        return this.zerodayisaminecraftcheat(p_152986_1_, false);
    }
    
    protected boolean zerodayisaminecraftcheat(final String p_175987_1_, final boolean p_175987_2_) {
        if (this.vape != ChatController.sigma.sigma) {
            return false;
        }
        if (this.a.containsKey(p_175987_1_)) {
            this.vape("Already in channel: " + p_175987_1_);
            return false;
        }
        if (p_175987_1_ != null && !p_175987_1_.equals("")) {
            final zerodayisaminecraftcheat chatcontroller$chatchannellistener = new zerodayisaminecraftcheat(p_175987_1_);
            this.a.put(p_175987_1_, chatcontroller$chatchannellistener);
            final boolean flag = chatcontroller$chatchannellistener.zerodayisaminecraftcheat(p_175987_2_);
            if (!flag) {
                this.a.remove(p_175987_1_);
            }
            return flag;
        }
        return false;
    }
    
    public boolean flux(final String p_175991_1_) {
        if (this.vape != ChatController.sigma.sigma) {
            return false;
        }
        if (!this.a.containsKey(p_175991_1_)) {
            this.vape("Not in channel: " + p_175991_1_);
            return false;
        }
        final zerodayisaminecraftcheat chatcontroller$chatchannellistener = this.a.get(p_175991_1_);
        return chatcontroller$chatchannellistener.zeroday();
    }
    
    public boolean sigma() {
        if (this.vape != ChatController.sigma.sigma) {
            return false;
        }
        final ErrorCode errorcode = this.flux.shutdown();
        if (ErrorCode.failed(errorcode)) {
            final String s = ErrorCode.getString(errorcode);
            this.vape(String.format("Error shutting down chat: %s", s));
            return false;
        }
        this.momgetthecamera();
        this.zerodayisaminecraftcheat(ChatController.sigma.pandora);
        return true;
    }
    
    public void pandora() {
        if (this.zerodayisaminecraftcheat() != ChatController.sigma.zerodayisaminecraftcheat) {
            this.sigma();
            if (this.zerodayisaminecraftcheat() == ChatController.sigma.pandora) {
                while (this.zerodayisaminecraftcheat() != ChatController.sigma.zerodayisaminecraftcheat) {
                    try {
                        Thread.sleep(200L);
                        this.zues();
                    }
                    catch (InterruptedException ex) {}
                }
            }
        }
    }
    
    public void zues() {
        if (this.vape != ChatController.sigma.zerodayisaminecraftcheat) {
            final ErrorCode errorcode = this.flux.flushEvents();
            if (ErrorCode.failed(errorcode)) {
                final String s = ErrorCode.getString(errorcode);
                this.vape(String.format("Error flushing chat events: %s", s));
            }
        }
    }
    
    public boolean zerodayisaminecraftcheat(final String p_175986_1_, final String p_175986_2_) {
        if (this.vape != ChatController.sigma.sigma) {
            return false;
        }
        if (!this.a.containsKey(p_175986_1_)) {
            this.vape("Not in channel: " + p_175986_1_);
            return false;
        }
        final zerodayisaminecraftcheat chatcontroller$chatchannellistener = this.a.get(p_175986_1_);
        return chatcontroller$chatchannellistener.zeroday(p_175986_2_);
    }
    
    protected void zerodayisaminecraftcheat(final sigma p_175985_1_) {
        if (p_175985_1_ != this.vape) {
            this.vape = p_175985_1_;
            try {
                if (this.zerodayisaminecraftcheat != null) {
                    this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_175985_1_);
                }
            }
            catch (Exception exception) {
                this.vape(exception.toString());
            }
        }
    }
    
    protected void flux() {
        if (this.d != ChatController.zues.zerodayisaminecraftcheat && this.e == null) {
            final ErrorCode errorcode = this.flux.downloadEmoticonData();
            if (ErrorCode.failed(errorcode)) {
                final String s = ErrorCode.getString(errorcode);
                this.vape(String.format("Error trying to download emoticon data: %s", s));
            }
        }
    }
    
    protected void vape() {
        if (this.e == null) {
            this.e = new ChatEmoticonData();
            final ErrorCode errorcode = this.flux.getEmoticonData(this.e);
            if (ErrorCode.succeeded(errorcode)) {
                try {
                    if (this.zerodayisaminecraftcheat != null) {
                        this.zerodayisaminecraftcheat.pandora();
                    }
                }
                catch (Exception exception) {
                    this.vape(exception.toString());
                }
            }
            else {
                this.vape("Error preparing emoticon data: " + ErrorCode.getString(errorcode));
            }
        }
    }
    
    protected void momgetthecamera() {
        if (this.e != null) {
            final ErrorCode errorcode = this.flux.clearEmoticonData();
            if (ErrorCode.succeeded(errorcode)) {
                this.e = null;
                try {
                    if (this.zerodayisaminecraftcheat != null) {
                        this.zerodayisaminecraftcheat.zues();
                    }
                }
                catch (Exception exception) {
                    this.vape(exception.toString());
                }
            }
            else {
                this.vape("Error clearing emoticon data: " + ErrorCode.getString(errorcode));
            }
        }
    }
    
    protected void vape(final String p_152995_1_) {
        ChatController.i.error(TwitchStream.zerodayisaminecraftcheat, "[Chat controller] {}", new Object[] { p_152995_1_ });
    }
    
    static /* synthetic */ int[] a() {
        final int[] j = ChatController.j;
        if (j != null) {
            return j;
        }
        final int[] i = new int[zues.values().length];
        try {
            i[zues.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            i[zues.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            i[zues.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        return ChatController.j = i;
    }
    
    public enum sigma
    {
        zerodayisaminecraftcheat("Uninitialized", 0), 
        zeroday("Initializing", 1), 
        sigma("Initialized", 2), 
        pandora("ShuttingDown", 3);
        
        static {
            zues = new sigma[] { sigma.zerodayisaminecraftcheat, sigma.zeroday, sigma.sigma, sigma.pandora };
        }
        
        private sigma(final String s, final int n) {
        }
    }
    
    public enum pandora
    {
        zerodayisaminecraftcheat("Created", 0), 
        zeroday("Connecting", 1), 
        sigma("Connected", 2), 
        pandora("Disconnecting", 3), 
        zues("Disconnected", 4);
        
        static {
            flux = new pandora[] { pandora.zerodayisaminecraftcheat, pandora.zeroday, pandora.sigma, pandora.pandora, pandora.zues };
        }
        
        private pandora(final String s, final int n) {
        }
    }
    
    public enum zues
    {
        zerodayisaminecraftcheat("None", 0), 
        zeroday("Url", 1), 
        sigma("TextureAtlas", 2);
        
        static {
            pandora = new zues[] { zues.zerodayisaminecraftcheat, zues.zeroday, zues.sigma };
        }
        
        private zues(final String s, final int n) {
        }
    }
    
    public class zerodayisaminecraftcheat implements IChatChannelListener
    {
        protected String zerodayisaminecraftcheat;
        protected boolean zeroday;
        protected pandora sigma;
        protected List<ChatUserInfo> pandora;
        protected LinkedList<ChatRawMessage> zues;
        protected LinkedList<ChatTokenizedMessage> flux;
        protected ChatBadgeData vape;
        private static /* synthetic */ int[] a;
        private static /* synthetic */ int[] b;
        
        public zerodayisaminecraftcheat(final String p_i46061_2_) {
            this.zerodayisaminecraftcheat = null;
            this.zeroday = false;
            this.sigma = ChatController.pandora.zerodayisaminecraftcheat;
            this.pandora = (List<ChatUserInfo>)Lists.newArrayList();
            this.zues = new LinkedList<ChatRawMessage>();
            this.flux = new LinkedList<ChatTokenizedMessage>();
            this.vape = null;
            this.zerodayisaminecraftcheat = p_i46061_2_;
        }
        
        public pandora zerodayisaminecraftcheat() {
            return this.sigma;
        }
        
        public boolean zerodayisaminecraftcheat(final boolean p_176038_1_) {
            this.zeroday = p_176038_1_;
            ErrorCode errorcode = ErrorCode.TTV_EC_SUCCESS;
            if (p_176038_1_) {
                errorcode = ChatController.this.flux.connectAnonymous(this.zerodayisaminecraftcheat, (IChatChannelListener)this);
            }
            else {
                errorcode = ChatController.this.flux.connect(this.zerodayisaminecraftcheat, ChatController.this.zeroday, ChatController.this.momgetthecamera.data, (IChatChannelListener)this);
            }
            if (ErrorCode.failed(errorcode)) {
                final String s = ErrorCode.getString(errorcode);
                ChatController.this.vape(String.format("Error connecting: %s", s));
                this.pandora(this.zerodayisaminecraftcheat);
                return false;
            }
            this.zerodayisaminecraftcheat(ChatController.pandora.zeroday);
            this.sigma();
            return true;
        }
        
        public boolean zeroday() {
            switch (flux()[this.sigma.ordinal()]) {
                case 2:
                case 3: {
                    final ErrorCode errorcode = ChatController.this.flux.disconnect(this.zerodayisaminecraftcheat);
                    if (ErrorCode.failed(errorcode)) {
                        final String s = ErrorCode.getString(errorcode);
                        ChatController.this.vape(String.format("Error disconnecting: %s", s));
                        return false;
                    }
                    this.zerodayisaminecraftcheat(ChatController.pandora.pandora);
                    return true;
                }
                default: {
                    return false;
                }
            }
        }
        
        protected void zerodayisaminecraftcheat(final pandora p_176035_1_) {
            if (p_176035_1_ != this.sigma) {
                this.sigma = p_176035_1_;
            }
        }
        
        public void zerodayisaminecraftcheat(final String p_176032_1_) {
            if (ChatController.this.d == ChatController.zues.zerodayisaminecraftcheat) {
                this.zues.clear();
                this.flux.clear();
            }
            else {
                if (this.zues.size() > 0) {
                    final ListIterator<ChatRawMessage> listiterator = this.zues.listIterator();
                    while (listiterator.hasNext()) {
                        final ChatRawMessage chatrawmessage = listiterator.next();
                        if (chatrawmessage.userName.equals(p_176032_1_)) {
                            listiterator.remove();
                        }
                    }
                }
                if (this.flux.size() > 0) {
                    final ListIterator<ChatTokenizedMessage> listiterator2 = this.flux.listIterator();
                    while (listiterator2.hasNext()) {
                        final ChatTokenizedMessage chattokenizedmessage = listiterator2.next();
                        if (chattokenizedmessage.displayName.equals(p_176032_1_)) {
                            listiterator2.remove();
                        }
                    }
                }
            }
            try {
                if (ChatController.this.zerodayisaminecraftcheat != null) {
                    ChatController.this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, p_176032_1_);
                }
            }
            catch (Exception exception) {
                ChatController.this.vape(exception.toString());
            }
        }
        
        public boolean zeroday(final String p_176037_1_) {
            if (this.sigma != ChatController.pandora.sigma) {
                return false;
            }
            final ErrorCode errorcode = ChatController.this.flux.sendMessage(this.zerodayisaminecraftcheat, p_176037_1_);
            if (ErrorCode.failed(errorcode)) {
                final String s = ErrorCode.getString(errorcode);
                ChatController.this.vape(String.format("Error sending chat message: %s", s));
                return false;
            }
            return true;
        }
        
        protected void sigma() {
            if (ChatController.this.d != ChatController.zues.zerodayisaminecraftcheat && this.vape == null) {
                final ErrorCode errorcode = ChatController.this.flux.downloadBadgeData(this.zerodayisaminecraftcheat);
                if (ErrorCode.failed(errorcode)) {
                    final String s = ErrorCode.getString(errorcode);
                    ChatController.this.vape(String.format("Error trying to download badge data: %s", s));
                }
            }
        }
        
        protected void pandora() {
            if (this.vape == null) {
                this.vape = new ChatBadgeData();
                final ErrorCode errorcode = ChatController.this.flux.getBadgeData(this.zerodayisaminecraftcheat, this.vape);
                if (ErrorCode.succeeded(errorcode)) {
                    try {
                        if (ChatController.this.zerodayisaminecraftcheat != null) {
                            ChatController.this.zerodayisaminecraftcheat.sigma(this.zerodayisaminecraftcheat);
                        }
                    }
                    catch (Exception exception) {
                        ChatController.this.vape(exception.toString());
                    }
                }
                else {
                    ChatController.this.vape("Error preparing badge data: " + ErrorCode.getString(errorcode));
                }
            }
        }
        
        protected void zues() {
            if (this.vape != null) {
                final ErrorCode errorcode = ChatController.this.flux.clearBadgeData(this.zerodayisaminecraftcheat);
                if (ErrorCode.succeeded(errorcode)) {
                    this.vape = null;
                    try {
                        if (ChatController.this.zerodayisaminecraftcheat != null) {
                            ChatController.this.zerodayisaminecraftcheat.pandora(this.zerodayisaminecraftcheat);
                        }
                    }
                    catch (Exception exception) {
                        ChatController.this.vape(exception.toString());
                    }
                }
                else {
                    ChatController.this.vape("Error releasing badge data: " + ErrorCode.getString(errorcode));
                }
            }
        }
        
        protected void sigma(final String p_176031_1_) {
            try {
                if (ChatController.this.zerodayisaminecraftcheat != null) {
                    ChatController.this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_176031_1_);
                }
            }
            catch (Exception exception) {
                ChatController.this.vape(exception.toString());
            }
        }
        
        protected void pandora(final String p_176036_1_) {
            try {
                if (ChatController.this.zerodayisaminecraftcheat != null) {
                    ChatController.this.zerodayisaminecraftcheat.zeroday(p_176036_1_);
                }
            }
            catch (Exception exception) {
                ChatController.this.vape(exception.toString());
            }
        }
        
        private void momgetthecamera() {
            if (this.sigma != ChatController.pandora.zues) {
                this.zerodayisaminecraftcheat(ChatController.pandora.zues);
                this.pandora(this.zerodayisaminecraftcheat);
                this.zues();
            }
        }
        
        public void chatStatusCallback(final String p_chatStatusCallback_1_, final ErrorCode p_chatStatusCallback_2_) {
            if (!ErrorCode.succeeded(p_chatStatusCallback_2_)) {
                ChatController.this.a.remove(p_chatStatusCallback_1_);
                this.momgetthecamera();
            }
        }
        
        public void chatChannelMembershipCallback(final String p_chatChannelMembershipCallback_1_, final ChatEvent p_chatChannelMembershipCallback_2_, final ChatChannelInfo p_chatChannelMembershipCallback_3_) {
            switch (vape()[p_chatChannelMembershipCallback_2_.ordinal()]) {
                case 1: {
                    this.zerodayisaminecraftcheat(ChatController.pandora.sigma);
                    this.sigma(p_chatChannelMembershipCallback_1_);
                    break;
                }
                case 2: {
                    this.momgetthecamera();
                    break;
                }
            }
        }
        
        public void chatChannelUserChangeCallback(final String p_chatChannelUserChangeCallback_1_, final ChatUserInfo[] p_chatChannelUserChangeCallback_2_, final ChatUserInfo[] p_chatChannelUserChangeCallback_3_, final ChatUserInfo[] p_chatChannelUserChangeCallback_4_) {
            for (int i = 0; i < p_chatChannelUserChangeCallback_3_.length; ++i) {
                final int j = this.pandora.indexOf(p_chatChannelUserChangeCallback_3_[i]);
                if (j >= 0) {
                    this.pandora.remove(j);
                }
            }
            for (int k = 0; k < p_chatChannelUserChangeCallback_4_.length; ++k) {
                final int i2 = this.pandora.indexOf(p_chatChannelUserChangeCallback_4_[k]);
                if (i2 >= 0) {
                    this.pandora.remove(i2);
                }
                this.pandora.add(p_chatChannelUserChangeCallback_4_[k]);
            }
            for (int l = 0; l < p_chatChannelUserChangeCallback_2_.length; ++l) {
                this.pandora.add(p_chatChannelUserChangeCallback_2_[l]);
            }
            try {
                if (ChatController.this.zerodayisaminecraftcheat != null) {
                    ChatController.this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, p_chatChannelUserChangeCallback_2_, p_chatChannelUserChangeCallback_3_, p_chatChannelUserChangeCallback_4_);
                }
            }
            catch (Exception exception) {
                ChatController.this.vape(exception.toString());
            }
        }
        
        public void chatChannelRawMessageCallback(final String p_chatChannelRawMessageCallback_1_, final ChatRawMessage[] p_chatChannelRawMessageCallback_2_) {
            for (int i = 0; i < p_chatChannelRawMessageCallback_2_.length; ++i) {
                this.zues.addLast(p_chatChannelRawMessageCallback_2_[i]);
            }
            try {
                if (ChatController.this.zerodayisaminecraftcheat != null) {
                    ChatController.this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, p_chatChannelRawMessageCallback_2_);
                }
            }
            catch (Exception exception) {
                ChatController.this.vape(exception.toString());
            }
            while (this.zues.size() > ChatController.this.b) {
                this.zues.removeFirst();
            }
        }
        
        public void chatChannelTokenizedMessageCallback(final String p_chatChannelTokenizedMessageCallback_1_, final ChatTokenizedMessage[] p_chatChannelTokenizedMessageCallback_2_) {
            for (int i = 0; i < p_chatChannelTokenizedMessageCallback_2_.length; ++i) {
                this.flux.addLast(p_chatChannelTokenizedMessageCallback_2_[i]);
            }
            try {
                if (ChatController.this.zerodayisaminecraftcheat != null) {
                    ChatController.this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, p_chatChannelTokenizedMessageCallback_2_);
                }
            }
            catch (Exception exception) {
                ChatController.this.vape(exception.toString());
            }
            while (this.flux.size() > ChatController.this.b) {
                this.flux.removeFirst();
            }
        }
        
        public void chatClearCallback(final String p_chatClearCallback_1_, final String p_chatClearCallback_2_) {
            this.zerodayisaminecraftcheat(p_chatClearCallback_2_);
        }
        
        public void chatBadgeDataDownloadCallback(final String p_chatBadgeDataDownloadCallback_1_, final ErrorCode p_chatBadgeDataDownloadCallback_2_) {
            if (ErrorCode.succeeded(p_chatBadgeDataDownloadCallback_2_)) {
                this.pandora();
            }
        }
        
        static /* synthetic */ int[] flux() {
            final int[] a = zerodayisaminecraftcheat.a;
            if (a != null) {
                return a;
            }
            final int[] a2 = new int[pandora.values().length];
            try {
                a2[pandora.sigma.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                a2[pandora.zeroday.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                a2[pandora.zerodayisaminecraftcheat.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                a2[pandora.zues.ordinal()] = 5;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            try {
                a2[pandora.pandora.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError5) {}
            return zerodayisaminecraftcheat.a = a2;
        }
        
        static /* synthetic */ int[] vape() {
            final int[] b = zerodayisaminecraftcheat.b;
            if (b != null) {
                return b;
            }
            final int[] b2 = new int[ChatEvent.values().length];
            try {
                b2[ChatEvent.TTV_CHAT_JOINED_CHANNEL.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                b2[ChatEvent.TTV_CHAT_LEFT_CHANNEL.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            return zerodayisaminecraftcheat.b = b2;
        }
    }
    
    public interface zeroday
    {
        void pandora(final ErrorCode p0);
        
        void zues(final ErrorCode p0);
        
        void pandora();
        
        void zues();
        
        void zerodayisaminecraftcheat(final sigma p0);
        
        void zerodayisaminecraftcheat(final String p0, final ChatTokenizedMessage[] p1);
        
        void zerodayisaminecraftcheat(final String p0, final ChatRawMessage[] p1);
        
        void zerodayisaminecraftcheat(final String p0, final ChatUserInfo[] p1, final ChatUserInfo[] p2, final ChatUserInfo[] p3);
        
        void zerodayisaminecraftcheat(final String p0);
        
        void zeroday(final String p0);
        
        void zerodayisaminecraftcheat(final String p0, final String p1);
        
        void sigma(final String p0);
        
        void pandora(final String p0);
    }
}

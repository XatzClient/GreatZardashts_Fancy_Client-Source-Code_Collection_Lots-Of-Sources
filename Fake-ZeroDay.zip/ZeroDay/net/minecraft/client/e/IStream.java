// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import tv.twitch.ErrorCode;
import tv.twitch.chat.ChatUserInfo;
import tv.twitch.broadcast.IngestServer;

public interface IStream
{
    void flux();
    
    void vape();
    
    void momgetthecamera();
    
    boolean a();
    
    boolean b();
    
    boolean c();
    
    void zerodayisaminecraftcheat(final Metadata p0, final long p1);
    
    void zerodayisaminecraftcheat(final Metadata p0, final long p1, final long p2);
    
    boolean d();
    
    void e();
    
    void f();
    
    void g();
    
    void h();
    
    void i();
    
    void j();
    
    IngestServer[] k();
    
    void l();
    
    IngestServerTester m();
    
    boolean n();
    
    int o();
    
    boolean p();
    
    String q();
    
    ChatUserInfo zues(final String p0);
    
    void flux(final String p0);
    
    boolean r();
    
    ErrorCode s();
    
    boolean t();
    
    void zerodayisaminecraftcheat(final boolean p0);
    
    boolean u();
    
    zerodayisaminecraftcheat v();
    
    public enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("ERROR", 0), 
        zeroday("INVALID_TOKEN", 1);
        
        static {
            sigma = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday };
        }
        
        private zerodayisaminecraftcheat(final String s, final int n) {
        }
    }
}

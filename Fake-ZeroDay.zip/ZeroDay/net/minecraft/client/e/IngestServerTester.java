// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import tv.twitch.broadcast.StartFlags;
import com.google.common.collect.Lists;
import tv.twitch.broadcast.EncodingCpuUsage;
import tv.twitch.broadcast.PixelFormat;
import tv.twitch.broadcast.StatType;
import tv.twitch.broadcast.GameInfoList;
import tv.twitch.broadcast.ArchivingState;
import tv.twitch.broadcast.StreamInfo;
import tv.twitch.broadcast.UserInfo;
import tv.twitch.broadcast.ChannelInfo;
import tv.twitch.AuthToken;
import tv.twitch.ErrorCode;
import tv.twitch.broadcast.IngestServer;
import tv.twitch.broadcast.IStatCallbacks;
import tv.twitch.broadcast.IStreamCallbacks;
import tv.twitch.broadcast.FrameBuffer;
import java.util.List;
import tv.twitch.broadcast.AudioParams;
import tv.twitch.broadcast.VideoParams;
import tv.twitch.broadcast.RTMPState;
import tv.twitch.broadcast.IngestList;
import tv.twitch.broadcast.Stream;

public class IngestServerTester
{
    protected zerodayisaminecraftcheat zerodayisaminecraftcheat;
    protected Stream zeroday;
    protected IngestList sigma;
    protected zeroday pandora;
    protected long zues;
    protected long flux;
    protected long vape;
    protected RTMPState momgetthecamera;
    protected VideoParams a;
    protected AudioParams b;
    protected long c;
    protected List<FrameBuffer> d;
    protected boolean e;
    protected IStreamCallbacks f;
    protected IStatCallbacks g;
    protected IngestServer h;
    protected boolean i;
    protected boolean j;
    protected int k;
    protected int l;
    protected long m;
    protected float n;
    protected float o;
    protected boolean p;
    protected boolean q;
    protected boolean r;
    protected IStreamCallbacks s;
    protected IStatCallbacks t;
    private static /* synthetic */ int[] u;
    
    public void zerodayisaminecraftcheat(final zerodayisaminecraftcheat p_153042_1_) {
        this.zerodayisaminecraftcheat = p_153042_1_;
    }
    
    public IngestServer zerodayisaminecraftcheat() {
        return this.h;
    }
    
    public int zeroday() {
        return this.k;
    }
    
    public boolean sigma() {
        return this.pandora == IngestServerTester.zeroday.flux || this.pandora == IngestServerTester.zeroday.momgetthecamera || this.pandora == IngestServerTester.zeroday.a;
    }
    
    public float pandora() {
        return this.o;
    }
    
    public IngestServerTester(final Stream p_i1019_1_, final IngestList p_i1019_2_) {
        this.zerodayisaminecraftcheat = null;
        this.zeroday = null;
        this.sigma = null;
        this.pandora = IngestServerTester.zeroday.zerodayisaminecraftcheat;
        this.zues = 8000L;
        this.flux = 2000L;
        this.vape = 0L;
        this.momgetthecamera = RTMPState.Invalid;
        this.a = null;
        this.b = null;
        this.c = 0L;
        this.d = null;
        this.e = false;
        this.f = null;
        this.g = null;
        this.h = null;
        this.i = false;
        this.j = false;
        this.k = -1;
        this.l = 0;
        this.m = 0L;
        this.n = 0.0f;
        this.o = 0.0f;
        this.p = false;
        this.q = false;
        this.r = false;
        this.s = (IStreamCallbacks)new IStreamCallbacks() {
            public void requestAuthTokenCallback(final ErrorCode p_requestAuthTokenCallback_1_, final AuthToken p_requestAuthTokenCallback_2_) {
            }
            
            public void loginCallback(final ErrorCode p_loginCallback_1_, final ChannelInfo p_loginCallback_2_) {
            }
            
            public void getIngestServersCallback(final ErrorCode p_getIngestServersCallback_1_, final IngestList p_getIngestServersCallback_2_) {
            }
            
            public void getUserInfoCallback(final ErrorCode p_getUserInfoCallback_1_, final UserInfo p_getUserInfoCallback_2_) {
            }
            
            public void getStreamInfoCallback(final ErrorCode p_getStreamInfoCallback_1_, final StreamInfo p_getStreamInfoCallback_2_) {
            }
            
            public void getArchivingStateCallback(final ErrorCode p_getArchivingStateCallback_1_, final ArchivingState p_getArchivingStateCallback_2_) {
            }
            
            public void runCommercialCallback(final ErrorCode p_runCommercialCallback_1_) {
            }
            
            public void setStreamInfoCallback(final ErrorCode p_setStreamInfoCallback_1_) {
            }
            
            public void getGameNameListCallback(final ErrorCode p_getGameNameListCallback_1_, final GameInfoList p_getGameNameListCallback_2_) {
            }
            
            public void bufferUnlockCallback(final long p_bufferUnlockCallback_1_) {
            }
            
            public void startCallback(final ErrorCode p_startCallback_1_) {
                IngestServerTester.this.q = false;
                if (ErrorCode.succeeded(p_startCallback_1_)) {
                    IngestServerTester.this.p = true;
                    IngestServerTester.this.c = System.currentTimeMillis();
                    IngestServerTester.this.zerodayisaminecraftcheat(IngestServerTester.zeroday.sigma);
                }
                else {
                    IngestServerTester.this.e = false;
                    IngestServerTester.this.zerodayisaminecraftcheat(IngestServerTester.zeroday.zues);
                }
            }
            
            public void stopCallback(final ErrorCode p_stopCallback_1_) {
                if (ErrorCode.failed(p_stopCallback_1_)) {
                    System.out.println("IngestTester.stopCallback failed to stop - " + IngestServerTester.this.h.serverName + ": " + p_stopCallback_1_.toString());
                }
                IngestServerTester.this.r = false;
                IngestServerTester.this.p = false;
                IngestServerTester.this.zerodayisaminecraftcheat(IngestServerTester.zeroday.zues);
                IngestServerTester.this.h = null;
                if (IngestServerTester.this.i) {
                    IngestServerTester.this.zerodayisaminecraftcheat(IngestServerTester.zeroday.vape);
                }
            }
            
            public void sendActionMetaDataCallback(final ErrorCode p_sendActionMetaDataCallback_1_) {
            }
            
            public void sendStartSpanMetaDataCallback(final ErrorCode p_sendStartSpanMetaDataCallback_1_) {
            }
            
            public void sendEndSpanMetaDataCallback(final ErrorCode p_sendEndSpanMetaDataCallback_1_) {
            }
        };
        this.t = (IStatCallbacks)new IStatCallbacks() {
            private static /* synthetic */ int[] zeroday;
            
            public void statCallback(final StatType p_statCallback_1_, final long p_statCallback_2_) {
                switch (zerodayisaminecraftcheat()[p_statCallback_1_.ordinal()]) {
                    case 1: {
                        IngestServerTester.this.momgetthecamera = RTMPState.lookupValue((int)p_statCallback_2_);
                        break;
                    }
                    case 2: {
                        IngestServerTester.this.vape = p_statCallback_2_;
                        break;
                    }
                }
            }
            
            static /* synthetic */ int[] zerodayisaminecraftcheat() {
                final int[] zeroday = IngestServerTester$2.zeroday;
                if (zeroday != null) {
                    return zeroday;
                }
                final int[] zeroday2 = new int[StatType.values().length];
                try {
                    zeroday2[StatType.TTV_ST_RTMPDATASENT.ordinal()] = 2;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    zeroday2[StatType.TTV_ST_RTMPSTATE.ordinal()] = 1;
                }
                catch (NoSuchFieldError noSuchFieldError2) {}
                return IngestServerTester$2.zeroday = zeroday2;
            }
        };
        this.zeroday = p_i1019_1_;
        this.sigma = p_i1019_2_;
    }
    
    public void zues() {
        if (this.pandora == IngestServerTester.zeroday.zerodayisaminecraftcheat) {
            this.k = 0;
            this.i = false;
            this.j = false;
            this.p = false;
            this.q = false;
            this.r = false;
            this.g = this.zeroday.getStatCallbacks();
            this.zeroday.setStatCallbacks(this.t);
            this.f = this.zeroday.getStreamCallbacks();
            this.zeroday.setStreamCallbacks(this.s);
            this.a = new VideoParams();
            this.a.targetFps = 60;
            this.a.maxKbps = 3500;
            this.a.outputWidth = 1280;
            this.a.outputHeight = 720;
            this.a.pixelFormat = PixelFormat.TTV_PF_BGRA;
            this.a.encodingCpuUsage = EncodingCpuUsage.TTV_ECU_HIGH;
            this.a.disableAdaptiveBitrate = true;
            this.a.verticalFlip = false;
            this.zeroday.getDefaultParams(this.a);
            this.b = new AudioParams();
            this.b.audioEnabled = false;
            this.b.enableMicCapture = false;
            this.b.enablePlaybackCapture = false;
            this.b.enablePassthroughAudio = false;
            this.d = (List<FrameBuffer>)Lists.newArrayList();
            for (int i = 3, j = 0; j < i; ++j) {
                final FrameBuffer framebuffer = this.zeroday.allocateFrameBuffer(this.a.outputWidth * this.a.outputHeight * 4);
                if (!framebuffer.getIsValid()) {
                    this.b();
                    this.zerodayisaminecraftcheat(IngestServerTester.zeroday.a);
                    return;
                }
                this.d.add(framebuffer);
                this.zeroday.randomizeFrameBuffer(framebuffer);
            }
            this.zerodayisaminecraftcheat(IngestServerTester.zeroday.zeroday);
            this.c = System.currentTimeMillis();
        }
    }
    
    public void flux() {
        if (!this.sigma() && this.pandora != IngestServerTester.zeroday.zerodayisaminecraftcheat && !this.q && !this.r) {
            switch (c()[this.pandora.ordinal()]) {
                case 2:
                case 5: {
                    if (this.h != null) {
                        if (this.j || !this.e) {
                            this.h.bitrateKbps = 0.0f;
                        }
                        this.zeroday(this.h);
                        break;
                    }
                    this.c = 0L;
                    this.j = false;
                    this.e = true;
                    if (this.pandora != IngestServerTester.zeroday.zeroday) {
                        ++this.k;
                    }
                    if (this.k < this.sigma.getServers().length) {
                        this.zerodayisaminecraftcheat(this.h = this.sigma.getServers()[this.k]);
                        break;
                    }
                    this.zerodayisaminecraftcheat(IngestServerTester.zeroday.flux);
                    break;
                }
                case 3:
                case 4: {
                    this.sigma(this.h);
                    break;
                }
                case 7: {
                    this.zerodayisaminecraftcheat(IngestServerTester.zeroday.momgetthecamera);
                    break;
                }
            }
            this.a();
            if (this.pandora == IngestServerTester.zeroday.momgetthecamera || this.pandora == IngestServerTester.zeroday.flux) {
                this.b();
            }
        }
    }
    
    public void vape() {
        if (!this.sigma() && !this.i) {
            this.i = true;
            if (this.h != null) {
                this.h.bitrateKbps = 0.0f;
            }
        }
    }
    
    protected boolean zerodayisaminecraftcheat(final IngestServer p_153036_1_) {
        this.e = true;
        this.vape = 0L;
        this.momgetthecamera = RTMPState.Idle;
        this.h = p_153036_1_;
        this.q = true;
        this.zerodayisaminecraftcheat(IngestServerTester.zeroday.sigma);
        final ErrorCode errorcode = this.zeroday.start(this.a, this.b, p_153036_1_, StartFlags.TTV_Start_BandwidthTest, true);
        if (ErrorCode.failed(errorcode)) {
            this.q = false;
            this.e = false;
            this.zerodayisaminecraftcheat(IngestServerTester.zeroday.zues);
            return false;
        }
        this.m = this.vape;
        p_153036_1_.bitrateKbps = 0.0f;
        this.l = 0;
        return true;
    }
    
    protected void zeroday(final IngestServer p_153035_1_) {
        if (this.q) {
            this.j = true;
        }
        else if (this.p) {
            this.r = true;
            final ErrorCode errorcode = this.zeroday.stop(true);
            if (ErrorCode.failed(errorcode)) {
                this.s.stopCallback(ErrorCode.TTV_EC_SUCCESS);
                System.out.println("Stop failed: " + errorcode.toString());
            }
            this.zeroday.pollStats();
        }
        else {
            this.s.stopCallback(ErrorCode.TTV_EC_SUCCESS);
        }
    }
    
    protected long momgetthecamera() {
        return System.currentTimeMillis() - this.c;
    }
    
    protected void a() {
        final float f = (float)this.momgetthecamera();
        switch (c()[this.pandora.ordinal()]) {
            case 1:
            case 2:
            case 3:
            case 6:
            case 8:
            case 9: {
                this.o = 0.0f;
                break;
            }
            case 5: {
                this.o = 1.0f;
                break;
            }
            default: {
                this.o = f / this.zues;
                break;
            }
        }
        switch (c()[this.pandora.ordinal()]) {
            case 6:
            case 8:
            case 9: {
                this.n = 1.0f;
                break;
            }
            default: {
                this.n = this.k / (float)this.sigma.getServers().length;
                this.n += this.o / this.sigma.getServers().length;
                break;
            }
        }
    }
    
    protected boolean sigma(final IngestServer p_153029_1_) {
        if (this.j || this.i || this.momgetthecamera() >= this.zues) {
            this.zerodayisaminecraftcheat(IngestServerTester.zeroday.zues);
            return true;
        }
        if (this.q || this.r) {
            return true;
        }
        final ErrorCode errorcode = this.zeroday.submitVideoFrame((FrameBuffer)this.d.get(this.l));
        if (ErrorCode.failed(errorcode)) {
            this.e = false;
            this.zerodayisaminecraftcheat(IngestServerTester.zeroday.zues);
            return false;
        }
        this.l = (this.l + 1) % this.d.size();
        this.zeroday.pollStats();
        if (this.momgetthecamera == RTMPState.SendVideo) {
            this.zerodayisaminecraftcheat(IngestServerTester.zeroday.pandora);
            final long i = this.momgetthecamera();
            if (i > 0L && this.vape > this.m) {
                p_153029_1_.bitrateKbps = this.vape * 8L / (float)this.momgetthecamera();
                this.m = this.vape;
            }
        }
        return true;
    }
    
    protected void b() {
        this.h = null;
        if (this.d != null) {
            for (int i = 0; i < this.d.size(); ++i) {
                this.d.get(i).free();
            }
            this.d = null;
        }
        if (this.zeroday.getStatCallbacks() == this.t) {
            this.zeroday.setStatCallbacks(this.g);
            this.g = null;
        }
        if (this.zeroday.getStreamCallbacks() == this.s) {
            this.zeroday.setStreamCallbacks(this.f);
            this.f = null;
        }
    }
    
    protected void zerodayisaminecraftcheat(final zeroday p_153034_1_) {
        if (p_153034_1_ != this.pandora) {
            this.pandora = p_153034_1_;
            if (this.zerodayisaminecraftcheat != null) {
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this, p_153034_1_);
            }
        }
    }
    
    static /* synthetic */ int[] c() {
        final int[] u = IngestServerTester.u;
        if (u != null) {
            return u;
        }
        final int[] u2 = new int[zeroday.values().length];
        try {
            u2[zeroday.momgetthecamera.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            u2[zeroday.vape.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            u2[zeroday.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            u2[zeroday.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            u2[zeroday.a.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            u2[zeroday.flux.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            u2[zeroday.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            u2[zeroday.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            u2[zeroday.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        return IngestServerTester.u = u2;
    }
    
    public enum zeroday
    {
        zerodayisaminecraftcheat("Uninitalized", 0), 
        zeroday("Starting", 1), 
        sigma("ConnectingToServer", 2), 
        pandora("TestingServer", 3), 
        zues("DoneTestingServer", 4), 
        flux("Finished", 5), 
        vape("Cancelling", 6), 
        momgetthecamera("Cancelled", 7), 
        a("Failed", 8);
        
        static {
            b = new zeroday[] { zeroday.zerodayisaminecraftcheat, zeroday.zeroday, zeroday.sigma, zeroday.pandora, zeroday.zues, zeroday.flux, zeroday.vape, zeroday.momgetthecamera, zeroday.a };
        }
        
        private zeroday(final String s, final int n) {
        }
    }
    
    public interface zerodayisaminecraftcheat
    {
        void zerodayisaminecraftcheat(final IngestServerTester p0, final zeroday p1);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import com.google.common.base.Objects;
import com.google.common.collect.Maps;
import java.util.Map;
import com.google.gson.Gson;

public class Metadata
{
    private static final Gson zerodayisaminecraftcheat;
    private final String zeroday;
    private String sigma;
    private Map<String, String> pandora;
    
    static {
        zerodayisaminecraftcheat = new Gson();
    }
    
    public Metadata(final String p_i46345_1_, final String p_i46345_2_) {
        this.zeroday = p_i46345_1_;
        this.sigma = p_i46345_2_;
    }
    
    public Metadata(final String p_i1030_1_) {
        this(p_i1030_1_, null);
    }
    
    public void zerodayisaminecraftcheat(final String p_152807_1_) {
        this.sigma = p_152807_1_;
    }
    
    public String zerodayisaminecraftcheat() {
        return (this.sigma == null) ? this.zeroday : this.sigma;
    }
    
    public void zerodayisaminecraftcheat(final String p_152808_1_, final String p_152808_2_) {
        if (this.pandora == null) {
            this.pandora = (Map<String, String>)Maps.newHashMap();
        }
        if (this.pandora.size() > 50) {
            throw new IllegalArgumentException("Metadata payload is full, cannot add more to it!");
        }
        if (p_152808_1_ == null) {
            throw new IllegalArgumentException("Metadata payload key cannot be null!");
        }
        if (p_152808_1_.length() > 255) {
            throw new IllegalArgumentException("Metadata payload key is too long!");
        }
        if (p_152808_2_ == null) {
            throw new IllegalArgumentException("Metadata payload value cannot be null!");
        }
        if (p_152808_2_.length() > 255) {
            throw new IllegalArgumentException("Metadata payload value is too long!");
        }
        this.pandora.put(p_152808_1_, p_152808_2_);
    }
    
    public String zeroday() {
        return (this.pandora != null && !this.pandora.isEmpty()) ? Metadata.zerodayisaminecraftcheat.toJson((Object)this.pandora) : null;
    }
    
    public String sigma() {
        return this.zeroday;
    }
    
    @Override
    public String toString() {
        return Objects.toStringHelper((Object)this).add("name", (Object)this.zeroday).add("description", (Object)this.sigma).add("data", (Object)this.zeroday()).toString();
    }
}

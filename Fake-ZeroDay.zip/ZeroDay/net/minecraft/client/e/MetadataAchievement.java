// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import net.minecraft.m.Achievement;

public class MetadataAchievement extends Metadata
{
    public MetadataAchievement(final Achievement p_i1032_1_) {
        super("achievement");
        this.zerodayisaminecraftcheat("achievement_id", p_i1032_1_.zues);
        this.zerodayisaminecraftcheat("achievement_name", p_i1032_1_.zues().momgetthecamera());
        this.zerodayisaminecraftcheat("achievement_description", p_i1032_1_.flux());
        this.zerodayisaminecraftcheat("Achievement '" + p_i1032_1_.zues().momgetthecamera() + "' obtained!");
    }
}

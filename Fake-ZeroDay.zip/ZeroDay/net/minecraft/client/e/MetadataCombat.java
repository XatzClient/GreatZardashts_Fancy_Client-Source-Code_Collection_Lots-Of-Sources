// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import net.minecraft.vape.EntityLivingBase;

public class MetadataCombat extends Metadata
{
    public MetadataCombat(final EntityLivingBase p_i46067_1_, final EntityLivingBase p_i46067_2_) {
        super("player_combat");
        this.zerodayisaminecraftcheat("player", p_i46067_1_.l_());
        if (p_i46067_2_ != null) {
            this.zerodayisaminecraftcheat("primary_opponent", p_i46067_2_.l_());
        }
        if (p_i46067_2_ != null) {
            this.zerodayisaminecraftcheat("Combat between " + p_i46067_1_.l_() + " and " + p_i46067_2_.l_());
        }
        else {
            this.zerodayisaminecraftcheat("Combat between " + p_i46067_1_.l_() + " and others");
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import net.minecraft.vape.EntityLivingBase;

public class MetadataPlayerDeath extends Metadata
{
    public MetadataPlayerDeath(final EntityLivingBase p_i46066_1_, final EntityLivingBase p_i46066_2_) {
        super("player_death");
        if (p_i46066_1_ != null) {
            this.zerodayisaminecraftcheat("player", p_i46066_1_.l_());
        }
        if (p_i46066_2_ != null) {
            this.zerodayisaminecraftcheat("killer", p_i46066_2_.l_());
        }
    }
}

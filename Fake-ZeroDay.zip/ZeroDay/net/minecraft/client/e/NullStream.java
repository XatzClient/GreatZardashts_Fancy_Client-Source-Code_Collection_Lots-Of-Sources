// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import tv.twitch.ErrorCode;
import tv.twitch.chat.ChatUserInfo;
import tv.twitch.broadcast.IngestServer;

public class NullStream implements IStream
{
    private final Throwable zerodayisaminecraftcheat;
    
    public NullStream(final Throwable p_i1006_1_) {
        this.zerodayisaminecraftcheat = p_i1006_1_;
    }
    
    @Override
    public void flux() {
    }
    
    @Override
    public void vape() {
    }
    
    @Override
    public void momgetthecamera() {
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean b() {
        return false;
    }
    
    @Override
    public boolean c() {
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Metadata p_152911_1_, final long p_152911_2_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Metadata p_176026_1_, final long p_176026_2_, final long p_176026_4_) {
    }
    
    @Override
    public boolean d() {
        return false;
    }
    
    @Override
    public void e() {
    }
    
    @Override
    public void f() {
    }
    
    @Override
    public void g() {
    }
    
    @Override
    public void h() {
    }
    
    @Override
    public void i() {
    }
    
    @Override
    public void j() {
    }
    
    @Override
    public IngestServer[] k() {
        return new IngestServer[0];
    }
    
    @Override
    public void l() {
    }
    
    @Override
    public IngestServerTester m() {
        return null;
    }
    
    @Override
    public boolean n() {
        return false;
    }
    
    @Override
    public int o() {
        return 0;
    }
    
    @Override
    public boolean p() {
        return false;
    }
    
    @Override
    public String q() {
        return null;
    }
    
    @Override
    public ChatUserInfo zues(final String p_152926_1_) {
        return null;
    }
    
    @Override
    public void flux(final String p_152917_1_) {
    }
    
    @Override
    public boolean r() {
        return false;
    }
    
    @Override
    public ErrorCode s() {
        return null;
    }
    
    @Override
    public boolean t() {
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean p_152910_1_) {
    }
    
    @Override
    public boolean u() {
        return false;
    }
    
    @Override
    public zerodayisaminecraftcheat v() {
        return IStream.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
    }
    
    public Throwable zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
}

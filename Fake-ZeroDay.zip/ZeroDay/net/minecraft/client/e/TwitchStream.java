// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.e;

import tv.twitch.chat.ChatTokenizedMessage;
import java.util.Iterator;
import net.minecraft.momgetthecamera.HoverEvent;
import net.minecraft.client.sigma.pandora.GuiTwitchUserMode;
import tv.twitch.chat.ChatUserSubscription;
import tv.twitch.chat.ChatUserMode;
import java.util.Set;
import tv.twitch.chat.ChatRawMessage;
import net.minecraft.o.MathHelper;
import net.minecraft.momgetthecamera.ClickEvent;
import net.minecraft.o.ChatComponentTranslation;
import tv.twitch.broadcast.IngestList;
import tv.twitch.broadcast.StreamInfo;
import tv.twitch.broadcast.GameInfo;
import tv.twitch.ErrorCode;
import tv.twitch.broadcast.IngestServer;
import tv.twitch.broadcast.VideoParams;
import net.minecraft.client.c.GameSettings;
import tv.twitch.broadcast.EncodingCpuUsage;
import net.minecraft.client.a.WorldRenderer;
import tv.twitch.broadcast.FrameBuffer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.GlStateManager;
import com.google.gson.JsonObject;
import java.io.IOException;
import tv.twitch.AuthToken;
import net.minecraft.o.JsonUtils;
import com.google.gson.JsonParser;
import net.minecraft.o.HttpUtil;
import java.net.URL;
import java.net.URLEncoder;
import net.minecraft.client.a.OpenGlHelper;
import com.google.common.base.Strings;
import net.minecraft.o.EnumChatFormatting;
import com.google.common.collect.Maps;
import net.minecraft.o.ChatComponentText;
import com.mojang.authlib.properties.Property;
import net.minecraft.o.Util;
import org.apache.logging.log4j.MarkerManager;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.d.Framebuffer;
import tv.twitch.chat.ChatUserInfo;
import java.util.Map;
import net.minecraft.o.IChatComponent;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.Logger;

public class TwitchStream implements IngestServerTester.zerodayisaminecraftcheat, IStream, ChatController.zeroday, BroadcastController.zerodayisaminecraftcheat
{
    private static final Logger zeroday;
    public static final Marker zerodayisaminecraftcheat;
    private final BroadcastController sigma;
    private final ChatController pandora;
    private String zues;
    private final Minecraft flux;
    private final IChatComponent vape;
    private final Map<String, ChatUserInfo> momgetthecamera;
    private Framebuffer a;
    private boolean b;
    private int c;
    private long d;
    private boolean e;
    private boolean f;
    private boolean g;
    private boolean h;
    private IStream.zerodayisaminecraftcheat i;
    private static boolean j;
    
    static {
        zeroday = LogManager.getLogger();
        zerodayisaminecraftcheat = MarkerManager.getMarker("STREAM");
        try {
            if (Util.zerodayisaminecraftcheat() == Util.zerodayisaminecraftcheat.sigma) {
                System.loadLibrary("avutil-ttv-51");
                System.loadLibrary("swresample-ttv-0");
                System.loadLibrary("libmp3lame-ttv");
                if (System.getProperty("os.arch").contains("64")) {
                    System.loadLibrary("libmfxsw64");
                }
                else {
                    System.loadLibrary("libmfxsw32");
                }
            }
            TwitchStream.j = true;
        }
        catch (Throwable var1) {
            TwitchStream.j = false;
        }
    }
    
    public TwitchStream(final Minecraft mcIn, final Property streamProperty) {
        this.vape = new ChatComponentText("Twitch");
        this.momgetthecamera = (Map<String, ChatUserInfo>)Maps.newHashMap();
        this.c = 30;
        this.d = 0L;
        this.e = false;
        this.i = IStream.zerodayisaminecraftcheat.zerodayisaminecraftcheat;
        this.flux = mcIn;
        this.sigma = new BroadcastController();
        this.pandora = new ChatController();
        this.sigma.zerodayisaminecraftcheat(this);
        this.pandora.zerodayisaminecraftcheat(this);
        this.sigma.zerodayisaminecraftcheat("nmt37qblda36pvonovdkbopzfzw3wlq");
        this.pandora.zerodayisaminecraftcheat("nmt37qblda36pvonovdkbopzfzw3wlq");
        this.vape.vape().zerodayisaminecraftcheat(EnumChatFormatting.flux);
        if (streamProperty != null && !Strings.isNullOrEmpty(streamProperty.getValue()) && OpenGlHelper.d) {
            final Thread thread = new Thread("Twitch authenticator") {
                @Override
                public void run() {
                    try {
                        final URL url = new URL("https://api.twitch.tv/kraken?oauth_token=" + URLEncoder.encode(streamProperty.getValue(), "UTF-8"));
                        final String s = HttpUtil.zerodayisaminecraftcheat(url);
                        final JsonObject jsonobject = JsonUtils.zues(new JsonParser().parse(s), "Response");
                        final JsonObject jsonobject2 = JsonUtils.b(jsonobject, "token");
                        if (JsonUtils.vape(jsonobject2, "valid")) {
                            final String s2 = JsonUtils.flux(jsonobject2, "user_name");
                            TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Authenticated with twitch; username is {}", new Object[] { s2 });
                            final AuthToken authtoken = new AuthToken();
                            authtoken.data = streamProperty.getValue();
                            TwitchStream.this.sigma.zerodayisaminecraftcheat(s2, authtoken);
                            TwitchStream.this.pandora.zeroday(s2);
                            TwitchStream.this.pandora.zerodayisaminecraftcheat(authtoken);
                            Runtime.getRuntime().addShutdownHook(new Thread("Twitch shutdown hook") {
                                @Override
                                public void run() {
                                    TwitchStream.this.flux();
                                }
                            });
                            TwitchStream.this.sigma.h();
                            TwitchStream.this.pandora.zeroday();
                        }
                        else {
                            TwitchStream.zerodayisaminecraftcheat(TwitchStream.this, IStream.zerodayisaminecraftcheat.zeroday);
                            TwitchStream.zeroday.error(TwitchStream.zerodayisaminecraftcheat, "Given twitch access token is invalid");
                        }
                    }
                    catch (IOException ioexception) {
                        TwitchStream.zerodayisaminecraftcheat(TwitchStream.this, IStream.zerodayisaminecraftcheat.zerodayisaminecraftcheat);
                        TwitchStream.zeroday.error(TwitchStream.zerodayisaminecraftcheat, "Could not authenticate with twitch", (Throwable)ioexception);
                    }
                }
            };
            thread.setDaemon(true);
            thread.start();
        }
    }
    
    @Override
    public void flux() {
        TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Shutdown streaming");
        this.sigma.j();
        this.pandora.pandora();
    }
    
    @Override
    public void vape() {
        final int i = this.flux.r.K;
        final boolean flag = this.zues != null && this.pandora.sigma(this.zues);
        final boolean flag2 = this.pandora.zerodayisaminecraftcheat() == ChatController.sigma.sigma && (this.zues == null || this.pandora.pandora(this.zues) == ChatController.pandora.zues);
        if (i == 2) {
            if (flag) {
                TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Disconnecting from twitch chat per user options");
                this.pandora.flux(this.zues);
            }
        }
        else if (i == 1) {
            if (flag2 && this.sigma.momgetthecamera()) {
                TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Connecting to twitch chat per user options");
                this.w();
            }
        }
        else if (i == 0) {
            if (flag && !this.c()) {
                TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Disconnecting from twitch chat as user is no longer streaming");
                this.pandora.flux(this.zues);
            }
            else if (flag2 && this.c()) {
                TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Connecting to twitch chat as user is streaming");
                this.w();
            }
        }
        this.sigma.p();
        this.pandora.zues();
    }
    
    protected void w() {
        final ChatController.sigma chatcontroller$chatstate = this.pandora.zerodayisaminecraftcheat();
        final String s = this.sigma.sigma().name;
        this.zues = s;
        if (chatcontroller$chatstate != ChatController.sigma.sigma) {
            TwitchStream.zeroday.warn("Invalid twitch chat state {}", new Object[] { chatcontroller$chatstate });
        }
        else if (this.pandora.pandora(this.zues) == ChatController.pandora.zues) {
            this.pandora.zues(s);
        }
        else {
            TwitchStream.zeroday.warn("Invalid twitch chat state {}", new Object[] { chatcontroller$chatstate });
        }
    }
    
    @Override
    public void momgetthecamera() {
        if (this.sigma.pandora() && !this.sigma.vape()) {
            final long i = System.nanoTime();
            final long j = 1000000000 / this.c;
            final long k = i - this.d;
            final boolean flag = k >= j;
            if (flag) {
                final FrameBuffer framebuffer = this.sigma.u();
                final Framebuffer framebuffer2 = this.flux.sigma();
                this.a.zerodayisaminecraftcheat(true);
                GlStateManager.d(5889);
                GlStateManager.v();
                GlStateManager.u();
                GlStateManager.zerodayisaminecraftcheat(0.0, this.a.sigma, this.a.pandora, 0.0, 1000.0, 3000.0);
                GlStateManager.d(5888);
                GlStateManager.v();
                GlStateManager.u();
                GlStateManager.zeroday(0.0f, 0.0f, -2000.0f);
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.zeroday(0, 0, this.a.sigma, this.a.pandora);
                GlStateManager.m();
                GlStateManager.sigma();
                GlStateManager.c();
                final float f = (float)this.a.sigma;
                final float f2 = (float)this.a.pandora;
                final float f3 = framebuffer2.sigma / (float)framebuffer2.zerodayisaminecraftcheat;
                final float f4 = framebuffer2.pandora / (float)framebuffer2.zeroday;
                framebuffer2.sigma();
                GL11.glTexParameterf(3553, 10241, 9729.0f);
                GL11.glTexParameterf(3553, 10240, 9729.0f);
                final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                final WorldRenderer worldrenderer = tessellator.sigma();
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
                worldrenderer.zeroday(0.0, f2, 0.0).zerodayisaminecraftcheat(0.0, f4).zues();
                worldrenderer.zeroday(f, f2, 0.0).zerodayisaminecraftcheat(f3, f4).zues();
                worldrenderer.zeroday(f, 0.0, 0.0).zerodayisaminecraftcheat(f3, 0.0).zues();
                worldrenderer.zeroday(0.0, 0.0, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zues();
                tessellator.zeroday();
                framebuffer2.pandora();
                GlStateManager.w();
                GlStateManager.d(5889);
                GlStateManager.w();
                GlStateManager.d(5888);
                this.sigma.zerodayisaminecraftcheat(framebuffer);
                this.a.zues();
                this.sigma.zeroday(framebuffer);
                this.d = i;
            }
        }
    }
    
    @Override
    public boolean a() {
        return this.sigma.momgetthecamera();
    }
    
    @Override
    public boolean b() {
        return this.sigma.zues();
    }
    
    @Override
    public boolean c() {
        return this.sigma.pandora();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Metadata p_152911_1_, final long p_152911_2_) {
        if (this.c() && this.b) {
            final long i = this.sigma.d();
            if (!this.sigma.zerodayisaminecraftcheat(p_152911_1_.sigma(), i + p_152911_2_, p_152911_1_.zerodayisaminecraftcheat(), p_152911_1_.zeroday())) {
                TwitchStream.zeroday.warn(TwitchStream.zerodayisaminecraftcheat, "Couldn't send stream metadata action at {}: {}", new Object[] { i + p_152911_2_, p_152911_1_ });
            }
            else {
                TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Sent stream metadata action at {}: {}", new Object[] { i + p_152911_2_, p_152911_1_ });
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Metadata p_176026_1_, final long p_176026_2_, final long p_176026_4_) {
        if (this.c() && this.b) {
            final long i = this.sigma.d();
            final String s = p_176026_1_.zerodayisaminecraftcheat();
            final String s2 = p_176026_1_.zeroday();
            final long j = this.sigma.zeroday(p_176026_1_.sigma(), i + p_176026_2_, s, s2);
            if (j < 0L) {
                TwitchStream.zeroday.warn(TwitchStream.zerodayisaminecraftcheat, "Could not send stream metadata sequence from {} to {}: {}", new Object[] { i + p_176026_2_, i + p_176026_4_, p_176026_1_ });
            }
            else if (this.sigma.zerodayisaminecraftcheat(p_176026_1_.sigma(), i + p_176026_4_, j, s, s2)) {
                TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Sent stream metadata sequence from {} to {}: {}", new Object[] { i + p_176026_2_, i + p_176026_4_, p_176026_1_ });
            }
            else {
                TwitchStream.zeroday.warn(TwitchStream.zerodayisaminecraftcheat, "Half-sent stream metadata sequence from {} to {}: {}", new Object[] { i + p_176026_2_, i + p_176026_4_, p_176026_1_ });
            }
        }
    }
    
    @Override
    public boolean d() {
        return this.sigma.vape();
    }
    
    @Override
    public void e() {
        if (this.sigma.l()) {
            TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Requested commercial from Twitch");
        }
        else {
            TwitchStream.zeroday.warn(TwitchStream.zerodayisaminecraftcheat, "Could not request commercial from Twitch");
        }
    }
    
    @Override
    public void f() {
        this.sigma.n();
        this.g = true;
        this.h();
    }
    
    @Override
    public void g() {
        this.sigma.o();
        this.g = false;
        this.h();
    }
    
    @Override
    public void h() {
        if (this.c()) {
            final float f = this.flux.r.E;
            final boolean flag = this.g || f <= 0.0f;
            this.sigma.zeroday(flag ? 0.0f : f);
            this.sigma.zerodayisaminecraftcheat(this.u() ? 0.0f : this.flux.r.D);
        }
    }
    
    @Override
    public void i() {
        final GameSettings gamesettings = this.flux.r;
        final VideoParams videoparams = this.sigma.zerodayisaminecraftcheat(zeroday(gamesettings.F), zerodayisaminecraftcheat(gamesettings.G), sigma(gamesettings.C), this.flux.flux / (float)this.flux.vape);
        switch (gamesettings.H) {
            case 0: {
                videoparams.encodingCpuUsage = EncodingCpuUsage.TTV_ECU_LOW;
                break;
            }
            case 1: {
                videoparams.encodingCpuUsage = EncodingCpuUsage.TTV_ECU_MEDIUM;
                break;
            }
            case 2: {
                videoparams.encodingCpuUsage = EncodingCpuUsage.TTV_ECU_HIGH;
                break;
            }
        }
        if (this.a == null) {
            this.a = new Framebuffer(videoparams.outputWidth, videoparams.outputHeight, false);
        }
        else {
            this.a.zerodayisaminecraftcheat(videoparams.outputWidth, videoparams.outputHeight);
        }
        if (gamesettings.J != null && gamesettings.J.length() > 0) {
            IngestServer[] k;
            for (int length = (k = this.k()).length, i = 0; i < length; ++i) {
                final IngestServer ingestserver = k[i];
                if (ingestserver.serverUrl.equals(gamesettings.J)) {
                    this.sigma.zerodayisaminecraftcheat(ingestserver);
                    break;
                }
            }
        }
        this.c = videoparams.targetFps;
        this.b = gamesettings.I;
        this.sigma.zerodayisaminecraftcheat(videoparams);
        TwitchStream.zeroday.info(TwitchStream.zerodayisaminecraftcheat, "Streaming at {}/{} at {} kbps to {}", new Object[] { videoparams.outputWidth, videoparams.outputHeight, videoparams.maxKbps, this.sigma.a().serverUrl });
        this.sigma.zerodayisaminecraftcheat(null, "Minecraft", null);
    }
    
    @Override
    public void j() {
        if (this.sigma.m()) {
            TwitchStream.zeroday.info(TwitchStream.zerodayisaminecraftcheat, "Stopped streaming to Twitch");
        }
        else {
            TwitchStream.zeroday.warn(TwitchStream.zerodayisaminecraftcheat, "Could not stop streaming to Twitch");
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ErrorCode p_152900_1_, final AuthToken p_152900_2_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ErrorCode p_152897_1_) {
        if (ErrorCode.succeeded(p_152897_1_)) {
            TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Login attempt successful");
            this.f = true;
        }
        else {
            TwitchStream.zeroday.warn(TwitchStream.zerodayisaminecraftcheat, "Login attempt unsuccessful: {} (error code {})", new Object[] { ErrorCode.getString(p_152897_1_), p_152897_1_.getValue() });
            this.f = false;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ErrorCode p_152898_1_, final GameInfo[] p_152898_2_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final BroadcastController.zeroday p_152891_1_) {
        TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Broadcast state changed to {}", new Object[] { p_152891_1_ });
        if (p_152891_1_ == BroadcastController.zeroday.zeroday) {
            this.sigma.zerodayisaminecraftcheat(BroadcastController.zeroday.pandora);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        TwitchStream.zeroday.info(TwitchStream.zerodayisaminecraftcheat, "Logged out of twitch");
    }
    
    @Override
    public void zerodayisaminecraftcheat(final StreamInfo p_152894_1_) {
        TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Stream info updated; {} viewers on stream ID {}", new Object[] { p_152894_1_.viewers, p_152894_1_.streamId });
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IngestList p_152896_1_) {
    }
    
    @Override
    public void zeroday(final ErrorCode p_152893_1_) {
        TwitchStream.zeroday.warn(TwitchStream.zerodayisaminecraftcheat, "Issue submitting frame: {} (Error code {})", new Object[] { ErrorCode.getString(p_152893_1_), p_152893_1_.getValue() });
        this.flux.o.pandora().zerodayisaminecraftcheat(new ChatComponentText("Issue streaming frame: " + p_152893_1_ + " (" + ErrorCode.getString(p_152893_1_) + ")"), 2);
    }
    
    @Override
    public void zeroday() {
        this.h();
        TwitchStream.zeroday.info(TwitchStream.zerodayisaminecraftcheat, "Broadcast to Twitch has started");
    }
    
    @Override
    public void sigma() {
        TwitchStream.zeroday.info(TwitchStream.zerodayisaminecraftcheat, "Broadcast to Twitch has stopped");
    }
    
    @Override
    public void sigma(final ErrorCode p_152892_1_) {
        if (p_152892_1_ == ErrorCode.TTV_EC_SOUNDFLOWER_NOT_INSTALLED) {
            final IChatComponent ichatcomponent = new ChatComponentTranslation("stream.unavailable.soundflower.chat.link", new Object[0]);
            ichatcomponent.vape().zerodayisaminecraftcheat(new ClickEvent(ClickEvent.zerodayisaminecraftcheat.zerodayisaminecraftcheat, "https://help.mojang.com/customer/portal/articles/1374877-configuring-soundflower-for-streaming-on-apple-computers"));
            ichatcomponent.vape().pandora(true);
            final IChatComponent ichatcomponent2 = new ChatComponentTranslation("stream.unavailable.soundflower.chat", new Object[] { ichatcomponent });
            ichatcomponent2.vape().zerodayisaminecraftcheat(EnumChatFormatting.zues);
            this.flux.o.pandora().zerodayisaminecraftcheat(ichatcomponent2);
        }
        else {
            final IChatComponent ichatcomponent3 = new ChatComponentTranslation("stream.unavailable.unknown.chat", new Object[] { ErrorCode.getString(p_152892_1_) });
            ichatcomponent3.vape().zerodayisaminecraftcheat(EnumChatFormatting.zues);
            this.flux.o.pandora().zerodayisaminecraftcheat(ichatcomponent3);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IngestServerTester p_152907_1_, final IngestServerTester.zeroday p_152907_2_) {
        TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Ingest test state changed to {}", new Object[] { p_152907_2_ });
        if (p_152907_2_ == IngestServerTester.zeroday.flux) {
            this.e = true;
        }
    }
    
    public static int zerodayisaminecraftcheat(final float p_152948_0_) {
        return MathHelper.pandora(10.0f + p_152948_0_ * 50.0f);
    }
    
    public static int zeroday(final float p_152946_0_) {
        return MathHelper.pandora(230.0f + p_152946_0_ * 3270.0f);
    }
    
    public static float sigma(final float p_152947_0_) {
        return 0.1f + p_152947_0_ * 0.1f;
    }
    
    @Override
    public IngestServer[] k() {
        return this.sigma.b().getServers();
    }
    
    @Override
    public void l() {
        final IngestServerTester ingestservertester = this.sigma.r();
        if (ingestservertester != null) {
            ingestservertester.zerodayisaminecraftcheat(this);
        }
    }
    
    @Override
    public IngestServerTester m() {
        return this.sigma.c();
    }
    
    @Override
    public boolean n() {
        return this.sigma.flux();
    }
    
    @Override
    public int o() {
        return this.c() ? this.sigma.zeroday().viewers : 0;
    }
    
    @Override
    public void pandora(final ErrorCode p_176023_1_) {
        if (ErrorCode.failed(p_176023_1_)) {
            TwitchStream.zeroday.error(TwitchStream.zerodayisaminecraftcheat, "Chat failed to initialize");
        }
    }
    
    @Override
    public void zues(final ErrorCode p_176022_1_) {
        if (ErrorCode.failed(p_176022_1_)) {
            TwitchStream.zeroday.error(TwitchStream.zerodayisaminecraftcheat, "Chat failed to shutdown");
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ChatController.sigma p_176017_1_) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String p_180605_1_, final ChatRawMessage[] p_180605_2_) {
        for (final ChatRawMessage chatrawmessage : p_180605_2_) {
            this.zerodayisaminecraftcheat(chatrawmessage.userName, chatrawmessage);
            if (this.zerodayisaminecraftcheat(chatrawmessage.modes, chatrawmessage.subscriptions, this.flux.r.L)) {
                final IChatComponent ichatcomponent = new ChatComponentText(chatrawmessage.userName);
                final IChatComponent ichatcomponent2 = new ChatComponentTranslation("chat.stream." + (chatrawmessage.action ? "emote" : "text"), new Object[] { this.vape, ichatcomponent, EnumChatFormatting.zerodayisaminecraftcheat(chatrawmessage.message) });
                if (chatrawmessage.action) {
                    ichatcomponent2.vape().zeroday(true);
                }
                final IChatComponent ichatcomponent3 = new ChatComponentText("");
                ichatcomponent3.zerodayisaminecraftcheat(new ChatComponentTranslation("stream.userinfo.chatTooltip", new Object[0]));
                for (final IChatComponent ichatcomponent4 : GuiTwitchUserMode.zerodayisaminecraftcheat(chatrawmessage.modes, chatrawmessage.subscriptions, null)) {
                    ichatcomponent3.zeroday("\n");
                    ichatcomponent3.zerodayisaminecraftcheat(ichatcomponent4);
                }
                ichatcomponent.vape().zerodayisaminecraftcheat(new HoverEvent(HoverEvent.zerodayisaminecraftcheat.zerodayisaminecraftcheat, ichatcomponent3));
                ichatcomponent.vape().zerodayisaminecraftcheat(new ClickEvent(ClickEvent.zerodayisaminecraftcheat.pandora, chatrawmessage.userName));
                this.flux.o.pandora().zerodayisaminecraftcheat(ichatcomponent2);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String p_176025_1_, final ChatTokenizedMessage[] p_176025_2_) {
    }
    
    private void zerodayisaminecraftcheat(final String p_176027_1_, final ChatRawMessage p_176027_2_) {
        ChatUserInfo chatuserinfo = this.momgetthecamera.get(p_176027_1_);
        if (chatuserinfo == null) {
            chatuserinfo = new ChatUserInfo();
            chatuserinfo.displayName = p_176027_1_;
            this.momgetthecamera.put(p_176027_1_, chatuserinfo);
        }
        chatuserinfo.subscriptions = p_176027_2_.subscriptions;
        chatuserinfo.modes = p_176027_2_.modes;
        chatuserinfo.nameColorARGB = p_176027_2_.nameColorARGB;
    }
    
    private boolean zerodayisaminecraftcheat(final Set<ChatUserMode> p_176028_1_, final Set<ChatUserSubscription> p_176028_2_, final int p_176028_3_) {
        return !p_176028_1_.contains(ChatUserMode.TTV_CHAT_USERMODE_BANNED) && (p_176028_1_.contains(ChatUserMode.TTV_CHAT_USERMODE_ADMINSTRATOR) || p_176028_1_.contains(ChatUserMode.TTV_CHAT_USERMODE_MODERATOR) || p_176028_1_.contains(ChatUserMode.TTV_CHAT_USERMODE_STAFF) || p_176028_3_ == 0 || (p_176028_3_ == 1 && p_176028_2_.contains(ChatUserSubscription.TTV_CHAT_USERSUB_SUBSCRIBER)));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String p_176018_1_, final ChatUserInfo[] p_176018_2_, final ChatUserInfo[] p_176018_3_, final ChatUserInfo[] p_176018_4_) {
        for (final ChatUserInfo chatuserinfo : p_176018_3_) {
            this.momgetthecamera.remove(chatuserinfo.displayName);
        }
        for (final ChatUserInfo chatuserinfo2 : p_176018_4_) {
            this.momgetthecamera.put(chatuserinfo2.displayName, chatuserinfo2);
        }
        for (final ChatUserInfo chatuserinfo3 : p_176018_2_) {
            this.momgetthecamera.put(chatuserinfo3.displayName, chatuserinfo3);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String p_180606_1_) {
        TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Chat connected");
    }
    
    @Override
    public void zeroday(final String p_180607_1_) {
        TwitchStream.zeroday.debug(TwitchStream.zerodayisaminecraftcheat, "Chat disconnected");
        this.momgetthecamera.clear();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final String p_176019_1_, final String p_176019_2_) {
    }
    
    @Override
    public void pandora() {
    }
    
    @Override
    public void zues() {
    }
    
    @Override
    public void sigma(final String p_176016_1_) {
    }
    
    @Override
    public void pandora(final String p_176020_1_) {
    }
    
    @Override
    public boolean p() {
        return this.zues != null && this.zues.equals(this.sigma.sigma().name);
    }
    
    @Override
    public String q() {
        return this.zues;
    }
    
    @Override
    public ChatUserInfo zues(final String p_152926_1_) {
        return this.momgetthecamera.get(p_152926_1_);
    }
    
    @Override
    public void flux(final String p_152917_1_) {
        this.pandora.zerodayisaminecraftcheat(this.zues, p_152917_1_);
    }
    
    @Override
    public boolean r() {
        return TwitchStream.j && this.sigma.zerodayisaminecraftcheat();
    }
    
    @Override
    public ErrorCode s() {
        return TwitchStream.j ? this.sigma.f() : ErrorCode.TTV_EC_OS_TOO_OLD;
    }
    
    @Override
    public boolean t() {
        return this.f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean p_152910_1_) {
        this.h = p_152910_1_;
        this.h();
    }
    
    @Override
    public boolean u() {
        final boolean flag = this.flux.r.M == 1;
        return this.g || this.flux.r.D <= 0.0f || flag != this.h;
    }
    
    @Override
    public IStream.zerodayisaminecraftcheat v() {
        return this.i;
    }
    
    static /* synthetic */ void zerodayisaminecraftcheat(final TwitchStream twitchStream, final IStream.zerodayisaminecraftcheat i) {
        twitchStream.i = i;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.f;

import net.minecraft.o.JsonUtils;
import com.google.gson.JsonObject;
import org.lwjgl.opengl.GL14;
import net.minecraft.client.a.GlStateManager;

public class JsonBlendingMode
{
    private static JsonBlendingMode zerodayisaminecraftcheat;
    private final int zeroday;
    private final int sigma;
    private final int pandora;
    private final int zues;
    private final int flux;
    private final boolean vape;
    private final boolean momgetthecamera;
    
    static {
        JsonBlendingMode.zerodayisaminecraftcheat = null;
    }
    
    private JsonBlendingMode(final boolean p_i45084_1_, final boolean p_i45084_2_, final int p_i45084_3_, final int p_i45084_4_, final int p_i45084_5_, final int p_i45084_6_, final int p_i45084_7_) {
        this.vape = p_i45084_1_;
        this.zeroday = p_i45084_3_;
        this.pandora = p_i45084_4_;
        this.sigma = p_i45084_5_;
        this.zues = p_i45084_6_;
        this.momgetthecamera = p_i45084_2_;
        this.flux = p_i45084_7_;
    }
    
    public JsonBlendingMode() {
        this(false, true, 1, 0, 1, 0, 32774);
    }
    
    public JsonBlendingMode(final int p_i45085_1_, final int p_i45085_2_, final int p_i45085_3_) {
        this(false, false, p_i45085_1_, p_i45085_2_, p_i45085_1_, p_i45085_2_, p_i45085_3_);
    }
    
    public JsonBlendingMode(final int p_i45086_1_, final int p_i45086_2_, final int p_i45086_3_, final int p_i45086_4_, final int p_i45086_5_) {
        this(true, false, p_i45086_1_, p_i45086_2_, p_i45086_3_, p_i45086_4_, p_i45086_5_);
    }
    
    public void zerodayisaminecraftcheat() {
        if (!this.equals(JsonBlendingMode.zerodayisaminecraftcheat)) {
            if (JsonBlendingMode.zerodayisaminecraftcheat == null || this.momgetthecamera != JsonBlendingMode.zerodayisaminecraftcheat.zeroday()) {
                JsonBlendingMode.zerodayisaminecraftcheat = this;
                if (this.momgetthecamera) {
                    GlStateManager.c();
                    return;
                }
                GlStateManager.d();
            }
            GL14.glBlendEquation(this.flux);
            if (this.vape) {
                GlStateManager.zerodayisaminecraftcheat(this.zeroday, this.pandora, this.sigma, this.zues);
            }
            else {
                GlStateManager.zeroday(this.zeroday, this.pandora);
            }
        }
    }
    
    @Override
    public boolean equals(final Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        }
        if (!(p_equals_1_ instanceof JsonBlendingMode)) {
            return false;
        }
        final JsonBlendingMode jsonblendingmode = (JsonBlendingMode)p_equals_1_;
        return this.flux == jsonblendingmode.flux && this.zues == jsonblendingmode.zues && this.pandora == jsonblendingmode.pandora && this.momgetthecamera == jsonblendingmode.momgetthecamera && this.vape == jsonblendingmode.vape && this.sigma == jsonblendingmode.sigma && this.zeroday == jsonblendingmode.zeroday;
    }
    
    @Override
    public int hashCode() {
        int i = this.zeroday;
        i = 31 * i + this.sigma;
        i = 31 * i + this.pandora;
        i = 31 * i + this.zues;
        i = 31 * i + this.flux;
        i = 31 * i + (this.vape ? 1 : 0);
        i = 31 * i + (this.momgetthecamera ? 1 : 0);
        return i;
    }
    
    public boolean zeroday() {
        return this.momgetthecamera;
    }
    
    public static JsonBlendingMode zerodayisaminecraftcheat(final JsonObject p_148110_0_) {
        if (p_148110_0_ == null) {
            return new JsonBlendingMode();
        }
        int i = 32774;
        int j = 1;
        int k = 0;
        int l = 1;
        int i2 = 0;
        boolean flag = true;
        boolean flag2 = false;
        if (JsonUtils.zerodayisaminecraftcheat(p_148110_0_, "func")) {
            i = zerodayisaminecraftcheat(p_148110_0_.get("func").getAsString());
            if (i != 32774) {
                flag = false;
            }
        }
        if (JsonUtils.zerodayisaminecraftcheat(p_148110_0_, "srcrgb")) {
            j = zeroday(p_148110_0_.get("srcrgb").getAsString());
            if (j != 1) {
                flag = false;
            }
        }
        if (JsonUtils.zerodayisaminecraftcheat(p_148110_0_, "dstrgb")) {
            k = zeroday(p_148110_0_.get("dstrgb").getAsString());
            if (k != 0) {
                flag = false;
            }
        }
        if (JsonUtils.zerodayisaminecraftcheat(p_148110_0_, "srcalpha")) {
            l = zeroday(p_148110_0_.get("srcalpha").getAsString());
            if (l != 1) {
                flag = false;
            }
            flag2 = true;
        }
        if (JsonUtils.zerodayisaminecraftcheat(p_148110_0_, "dstalpha")) {
            i2 = zeroday(p_148110_0_.get("dstalpha").getAsString());
            if (i2 != 0) {
                flag = false;
            }
            flag2 = true;
        }
        return flag ? new JsonBlendingMode() : (flag2 ? new JsonBlendingMode(j, k, l, i2, i) : new JsonBlendingMode(j, k, i));
    }
    
    private static int zerodayisaminecraftcheat(final String p_148108_0_) {
        final String s = p_148108_0_.trim().toLowerCase();
        return s.equals("add") ? 32774 : (s.equals("subtract") ? 32778 : (s.equals("reversesubtract") ? 32779 : (s.equals("reverse_subtract") ? 32779 : (s.equals("min") ? 32775 : (s.equals("max") ? 32776 : 32774)))));
    }
    
    private static int zeroday(final String p_148107_0_) {
        String s = p_148107_0_.trim().toLowerCase();
        s = s.replaceAll("_", "");
        s = s.replaceAll("one", "1");
        s = s.replaceAll("zero", "0");
        s = s.replaceAll("minus", "-");
        return s.equals("0") ? 0 : (s.equals("1") ? 1 : (s.equals("srccolor") ? 768 : (s.equals("1-srccolor") ? 769 : (s.equals("dstcolor") ? 774 : (s.equals("1-dstcolor") ? 775 : (s.equals("srcalpha") ? 770 : (s.equals("1-srcalpha") ? 771 : (s.equals("dstalpha") ? 772 : (s.equals("1-dstalpha") ? 773 : -1)))))))));
    }
}

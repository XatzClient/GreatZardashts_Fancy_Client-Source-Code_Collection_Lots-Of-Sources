// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.f;

import org.apache.commons.lang3.StringUtils;
import java.io.FileNotFoundException;
import com.google.common.collect.Lists;
import java.util.List;
import java.io.IOException;

public class JsonException extends IOException
{
    private final List<zerodayisaminecraftcheat> zerodayisaminecraftcheat;
    private final String zeroday;
    
    public JsonException(final String p_i45279_1_) {
        (this.zerodayisaminecraftcheat = (List<zerodayisaminecraftcheat>)Lists.newArrayList()).add(new zerodayisaminecraftcheat(null));
        this.zeroday = p_i45279_1_;
    }
    
    public JsonException(final String p_i45280_1_, final Throwable p_i45280_2_) {
        super(p_i45280_2_);
        (this.zerodayisaminecraftcheat = (List<zerodayisaminecraftcheat>)Lists.newArrayList()).add(new zerodayisaminecraftcheat(null));
        this.zeroday = p_i45280_1_;
    }
    
    public void zerodayisaminecraftcheat(final String p_151380_1_) {
        this.zerodayisaminecraftcheat.get(0).zerodayisaminecraftcheat(p_151380_1_);
    }
    
    public void zeroday(final String p_151381_1_) {
        JsonException.zerodayisaminecraftcheat.zeroday(this.zerodayisaminecraftcheat.get(0), p_151381_1_);
        this.zerodayisaminecraftcheat.add(0, new zerodayisaminecraftcheat(null));
    }
    
    @Override
    public String getMessage() {
        return "Invalid " + this.zerodayisaminecraftcheat.get(this.zerodayisaminecraftcheat.size() - 1).toString() + ": " + this.zeroday;
    }
    
    public static JsonException zerodayisaminecraftcheat(final Exception p_151379_0_) {
        if (p_151379_0_ instanceof JsonException) {
            return (JsonException)p_151379_0_;
        }
        String s = p_151379_0_.getMessage();
        if (p_151379_0_ instanceof FileNotFoundException) {
            s = "File not found";
        }
        return new JsonException(s, p_151379_0_);
    }
    
    public static class zerodayisaminecraftcheat
    {
        private String zerodayisaminecraftcheat;
        private final List<String> zeroday;
        
        private zerodayisaminecraftcheat() {
            this.zerodayisaminecraftcheat = null;
            this.zeroday = (List<String>)Lists.newArrayList();
        }
        
        private void zerodayisaminecraftcheat(final String p_151373_1_) {
            this.zeroday.add(0, p_151373_1_);
        }
        
        public String zerodayisaminecraftcheat() {
            return StringUtils.join((Iterable)this.zeroday, "->");
        }
        
        @Override
        public String toString() {
            return (this.zerodayisaminecraftcheat != null) ? (this.zeroday.isEmpty() ? this.zerodayisaminecraftcheat : (String.valueOf(this.zerodayisaminecraftcheat) + " " + this.zerodayisaminecraftcheat())) : (this.zeroday.isEmpty() ? "(Unknown file)" : ("(Unknown file) " + this.zerodayisaminecraftcheat()));
        }
        
        static /* synthetic */ void zeroday(final zerodayisaminecraftcheat zerodayisaminecraftcheat, final String zerodayisaminecraftcheat2) {
            zerodayisaminecraftcheat.zerodayisaminecraftcheat = zerodayisaminecraftcheat2;
        }
    }
}

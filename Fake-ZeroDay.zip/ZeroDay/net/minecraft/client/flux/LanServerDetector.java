// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.flux;

import java.net.SocketTimeoutException;
import java.net.DatagramPacket;
import java.io.IOException;
import java.net.MulticastSocket;
import java.util.Iterator;
import net.minecraft.client.zues.ThreadLanServerPing;
import java.net.InetAddress;
import java.util.Collections;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.concurrent.atomic.AtomicInteger;

public class LanServerDetector
{
    private static final AtomicInteger zerodayisaminecraftcheat;
    private static final Logger zeroday;
    
    static {
        zerodayisaminecraftcheat = new AtomicInteger(0);
        zeroday = LogManager.getLogger();
    }
    
    public static class zerodayisaminecraftcheat
    {
        private String zerodayisaminecraftcheat;
        private String zeroday;
        private long sigma;
        
        public zerodayisaminecraftcheat(final String motd, final String address) {
            this.zerodayisaminecraftcheat = motd;
            this.zeroday = address;
            this.sigma = Minecraft.C();
        }
        
        public String zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
        
        public String zeroday() {
            return this.zeroday;
        }
        
        public void sigma() {
            this.sigma = Minecraft.C();
        }
    }
    
    public static class zeroday
    {
        private List<zerodayisaminecraftcheat> zeroday;
        boolean zerodayisaminecraftcheat;
        
        public zeroday() {
            this.zeroday = (List<zerodayisaminecraftcheat>)Lists.newArrayList();
        }
        
        public synchronized boolean zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
        
        public synchronized void zeroday() {
            this.zerodayisaminecraftcheat = false;
        }
        
        public synchronized List<zerodayisaminecraftcheat> sigma() {
            return Collections.unmodifiableList((List<? extends zerodayisaminecraftcheat>)this.zeroday);
        }
        
        public synchronized void zerodayisaminecraftcheat(final String p_77551_1_, final InetAddress p_77551_2_) {
            final String s = ThreadLanServerPing.zerodayisaminecraftcheat(p_77551_1_);
            String s2 = ThreadLanServerPing.zeroday(p_77551_1_);
            if (s2 != null) {
                s2 = String.valueOf(p_77551_2_.getHostAddress()) + ":" + s2;
                boolean flag = false;
                for (final zerodayisaminecraftcheat lanserverdetector$lanserver : this.zeroday) {
                    if (lanserverdetector$lanserver.zeroday().equals(s2)) {
                        lanserverdetector$lanserver.sigma();
                        flag = true;
                        break;
                    }
                }
                if (!flag) {
                    this.zeroday.add(new zerodayisaminecraftcheat(s, s2));
                    this.zerodayisaminecraftcheat = true;
                }
            }
        }
    }
    
    public static class sigma extends Thread
    {
        private final zeroday zerodayisaminecraftcheat;
        private final InetAddress zeroday;
        private final MulticastSocket sigma;
        
        public sigma(final zeroday p_i1320_1_) throws IOException {
            super("LanServerDetector #" + LanServerDetector.zerodayisaminecraftcheat.incrementAndGet());
            this.zerodayisaminecraftcheat = p_i1320_1_;
            this.setDaemon(true);
            this.sigma = new MulticastSocket(4445);
            this.zeroday = InetAddress.getByName("224.0.2.60");
            this.sigma.setSoTimeout(5000);
            this.sigma.joinGroup(this.zeroday);
        }
        
        @Override
        public void run() {
            final byte[] abyte = new byte[1024];
            while (!this.isInterrupted()) {
                final DatagramPacket datagrampacket = new DatagramPacket(abyte, abyte.length);
                try {
                    this.sigma.receive(datagrampacket);
                }
                catch (SocketTimeoutException var5) {
                    continue;
                }
                catch (IOException ioexception) {
                    LanServerDetector.zeroday.error("Couldn't ping server", (Throwable)ioexception);
                    break;
                }
                final String s = new String(datagrampacket.getData(), datagrampacket.getOffset(), datagrampacket.getLength());
                LanServerDetector.zeroday.debug(datagrampacket.getAddress() + ": " + s);
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(s, datagrampacket.getAddress());
            }
            try {
                this.sigma.leaveGroup(this.zeroday);
            }
            catch (IOException ex) {}
            this.sigma.close();
        }
    }
}

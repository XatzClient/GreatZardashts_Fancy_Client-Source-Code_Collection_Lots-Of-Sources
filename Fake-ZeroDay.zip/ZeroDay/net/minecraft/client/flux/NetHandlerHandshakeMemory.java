// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.flux;

import net.minecraft.o.IChatComponent;
import net.minecraft.e.INetHandler;
import net.minecraft.k.sigma.NetHandlerLoginServer;
import net.minecraft.e.zerodayisaminecraftcheat.zerodayisaminecraftcheat.C00Handshake;
import net.minecraft.e.NetworkManager;
import net.minecraft.k.MinecraftServer;
import net.minecraft.e.zerodayisaminecraftcheat.INetHandlerHandshakeServer;

public class NetHandlerHandshakeMemory implements INetHandlerHandshakeServer
{
    private final MinecraftServer zerodayisaminecraftcheat;
    private final NetworkManager zeroday;
    
    public NetHandlerHandshakeMemory(final MinecraftServer p_i45287_1_, final NetworkManager p_i45287_2_) {
        this.zerodayisaminecraftcheat = p_i45287_1_;
        this.zeroday = p_i45287_2_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final C00Handshake packetIn) {
        this.zeroday.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        this.zeroday.zerodayisaminecraftcheat(new NetHandlerLoginServer(this.zerodayisaminecraftcheat, this.zeroday));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IChatComponent reason) {
    }
}

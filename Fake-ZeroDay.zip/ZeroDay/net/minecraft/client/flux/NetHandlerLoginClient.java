// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.flux;

import net.minecraft.e.zeroday.zeroday.S03PacketEnableCompression;
import net.minecraft.e.zeroday.zeroday.S00PacketDisconnect;
import net.minecraft.client.sigma.GuiDisconnected;
import net.minecraft.e.INetHandler;
import net.minecraft.e.EnumConnectionState;
import net.minecraft.e.zeroday.zeroday.S02PacketLoginSuccess;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import java.security.PublicKey;
import net.minecraft.e.Packet;
import javax.crypto.SecretKey;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import net.minecraft.e.zeroday.zerodayisaminecraftcheat.C01PacketEncryptionResponse;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.ChatComponentTranslation;
import com.mojang.authlib.exceptions.AuthenticationException;
import java.math.BigInteger;
import net.minecraft.o.CryptManager;
import net.minecraft.e.zeroday.zeroday.S01PacketEncryptionRequest;
import org.apache.logging.log4j.LogManager;
import com.mojang.authlib.GameProfile;
import net.minecraft.e.NetworkManager;
import net.minecraft.client.sigma.GuiScreen;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.Logger;
import net.minecraft.e.zeroday.INetHandlerLoginClient;

public class NetHandlerLoginClient implements INetHandlerLoginClient
{
    private static final Logger zerodayisaminecraftcheat;
    private final Minecraft zeroday;
    private final GuiScreen sigma;
    private final NetworkManager pandora;
    private GameProfile zues;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public NetHandlerLoginClient(final NetworkManager p_i45059_1_, final Minecraft mcIn, final GuiScreen p_i45059_3_) {
        this.pandora = p_i45059_1_;
        this.zeroday = mcIn;
        this.sigma = p_i45059_3_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S01PacketEncryptionRequest packetIn) {
        final SecretKey secretkey = CryptManager.zerodayisaminecraftcheat();
        final String s = packetIn.zerodayisaminecraftcheat();
        final PublicKey publickey = packetIn.zeroday();
        final String s2 = new BigInteger(CryptManager.zerodayisaminecraftcheat(s, publickey, secretkey)).toString(16);
        if (this.zeroday.w() != null && this.zeroday.w().pandora()) {
            try {
                this.zerodayisaminecraftcheat().joinServer(this.zeroday.E().zues(), this.zeroday.E().pandora(), s2);
            }
            catch (AuthenticationException var10) {
                NetHandlerLoginClient.zerodayisaminecraftcheat.warn("Couldn't connect to auth servers but will continue to join LAN");
            }
        }
        else {
            try {
                this.zerodayisaminecraftcheat().joinServer(this.zeroday.E().zues(), this.zeroday.E().pandora(), s2);
            }
            catch (AuthenticationUnavailableException var11) {
                this.pandora.zerodayisaminecraftcheat(new ChatComponentTranslation("disconnect.loginFailedInfo", new Object[] { new ChatComponentTranslation("disconnect.loginFailedInfo.serversUnavailable", new Object[0]) }));
                return;
            }
            catch (InvalidCredentialsException var12) {
                this.pandora.zerodayisaminecraftcheat(new ChatComponentTranslation("disconnect.loginFailedInfo", new Object[] { new ChatComponentTranslation("disconnect.loginFailedInfo.invalidSession", new Object[0]) }));
                return;
            }
            catch (AuthenticationException authenticationexception) {
                this.pandora.zerodayisaminecraftcheat(new ChatComponentTranslation("disconnect.loginFailedInfo", new Object[] { authenticationexception.getMessage() }));
                return;
            }
        }
        this.pandora.zerodayisaminecraftcheat(new C01PacketEncryptionResponse(secretkey, publickey, packetIn.sigma()), (GenericFutureListener<? extends Future<? super Void>>)new GenericFutureListener<Future<? super Void>>() {
            public void operationComplete(final Future<? super Void> p_operationComplete_1_) throws Exception {
                NetHandlerLoginClient.this.pandora.zerodayisaminecraftcheat(secretkey);
            }
        }, (GenericFutureListener<? extends Future<? super Void>>[])new GenericFutureListener[0]);
    }
    
    private MinecraftSessionService zerodayisaminecraftcheat() {
        return this.zeroday.T();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S02PacketLoginSuccess packetIn) {
        this.zues = packetIn.zerodayisaminecraftcheat();
        this.pandora.zerodayisaminecraftcheat(EnumConnectionState.zeroday);
        this.pandora.zerodayisaminecraftcheat(new NetHandlerPlayClient(this.zeroday, this.sigma, this.pandora, this.zues));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IChatComponent reason) {
        this.zeroday.zerodayisaminecraftcheat(new GuiDisconnected(this.sigma, "connect.failed", reason));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S00PacketDisconnect packetIn) {
        this.pandora.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S03PacketEnableCompression packetIn) {
        if (!this.pandora.sigma()) {
            this.pandora.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        }
    }
}

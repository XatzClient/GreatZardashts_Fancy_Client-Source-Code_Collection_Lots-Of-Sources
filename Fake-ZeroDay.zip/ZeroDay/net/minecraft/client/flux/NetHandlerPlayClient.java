// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.flux;

import java.util.Collection;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.IAttributeInstance;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.BaseAttributeMap;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.AttributeModifier;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.IAttribute;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.RangedAttribute;
import net.minecraft.e.sigma.zeroday.S20PacketEntityProperties;
import net.minecraft.e.sigma.zeroday.S2APacketParticles;
import net.minecraft.j.ScorePlayerTeam;
import net.minecraft.j.Team;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.e.sigma.zeroday.S3EPacketTeams;
import net.minecraft.e.sigma.zeroday.S3DPacketDisplayScoreboard;
import net.minecraft.j.Score;
import net.minecraft.o.StringUtils;
import net.minecraft.e.sigma.zeroday.S3CPacketUpdateScore;
import net.minecraft.j.ScoreObjective;
import net.minecraft.j.IScoreObjectiveCriteria;
import net.minecraft.e.sigma.zeroday.S3BPacketScoreboardObjective;
import net.minecraft.client.sigma.GuiScreenBook;
import net.minecraft.a.Items;
import java.io.IOException;
import net.minecraft.p.MerchantRecipeList;
import net.minecraft.client.sigma.GuiMerchant;
import net.minecraft.e.sigma.zeroday.S3FPacketCustomPayload;
import net.minecraft.e.sigma.zeroday.S49PacketUpdateEntityNBT;
import net.minecraft.client.sigma.GuiYesNo;
import net.minecraft.client.zues.ServerList;
import net.minecraft.client.sigma.GuiYesNoCallback;
import net.minecraft.client.zues.ServerData;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.FutureCallback;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C19PacketResourcePackStatus;
import java.io.File;
import net.minecraft.e.sigma.zeroday.S48PacketResourcePackSend;
import net.minecraft.e.sigma.zeroday.S29PacketSoundEffect;
import net.minecraft.client.sigma.GuiChat;
import net.minecraft.e.sigma.zeroday.S3APacketTabComplete;
import net.minecraft.e.sigma.zeroday.S39PacketPlayerAbilities;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C00PacketKeepAlive;
import net.minecraft.e.sigma.zeroday.S00PacketKeepAlive;
import net.minecraft.e.sigma.zeroday.S38PacketPlayerListItem;
import net.minecraft.e.sigma.zeroday.S1EPacketRemoveEntityEffect;
import net.minecraft.e.sigma.zeroday.S47PacketPlayerListHeaderFooter;
import net.minecraft.e.sigma.zeroday.S46PacketSetCompressionLevel;
import net.minecraft.e.sigma.zeroday.S45PacketTitle;
import net.minecraft.e.sigma.zeroday.S44PacketWorldBorder;
import net.minecraft.e.sigma.zeroday.S43PacketCamera;
import net.minecraft.e.sigma.zeroday.S41PacketServerDifficulty;
import net.minecraft.client.e.MetadataPlayerDeath;
import net.minecraft.client.e.MetadataCombat;
import net.minecraft.e.sigma.zeroday.S42PacketCombatEvent;
import net.minecraft.g.PotionEffect;
import net.minecraft.e.sigma.zeroday.S1DPacketEntityEffect;
import java.util.Iterator;
import net.minecraft.client.sigma.IProgressMeter;
import net.minecraft.m.AchievementList;
import net.minecraft.client.e.Metadata;
import net.minecraft.client.e.MetadataAchievement;
import net.minecraft.m.Achievement;
import net.minecraft.m.StatBase;
import net.minecraft.e.sigma.zeroday.S37PacketStatistics;
import net.minecraft.e.sigma.zeroday.S28PacketEffect;
import net.minecraft.q.vape.MapData;
import net.minecraft.c.ItemMap;
import net.minecraft.e.sigma.zeroday.S34PacketMaps;
import net.minecraft.client.sigma.GuiScreenDemo;
import net.minecraft.client.sigma.GuiWinGame;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.e.sigma.zeroday.S2BPacketChangeGameState;
import net.minecraft.e.sigma.zeroday.S26PacketMapChunkBulk;
import net.minecraft.e.sigma.zeroday.S25PacketBlockBreakAnim;
import net.minecraft.e.sigma.zeroday.S24PacketBlockAction;
import net.minecraft.e.sigma.zeroday.S2EPacketCloseWindow;
import net.minecraft.e.sigma.zeroday.S04PacketEntityEquipment;
import net.minecraft.e.sigma.zeroday.S31PacketWindowProperty;
import net.minecraft.n.TileEntityBanner;
import net.minecraft.n.TileEntityFlowerPot;
import net.minecraft.n.TileEntitySkull;
import net.minecraft.n.TileEntityBeacon;
import net.minecraft.n.TileEntityCommandBlock;
import net.minecraft.n.TileEntityMobSpawner;
import net.minecraft.e.sigma.zeroday.S35PacketUpdateTileEntity;
import net.minecraft.o.ChatComponentText;
import net.minecraft.e.sigma.zeroday.S33PacketUpdateSign;
import net.minecraft.n.TileEntity;
import net.minecraft.n.TileEntitySign;
import net.minecraft.e.sigma.zeroday.S36PacketSignEditorOpen;
import net.minecraft.e.sigma.zeroday.S30PacketWindowItems;
import net.minecraft.b.Container;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C0FPacketConfirmTransaction;
import net.minecraft.e.sigma.zeroday.S32PacketConfirmTransaction;
import net.minecraft.pandora.CreativeTabs;
import net.minecraft.client.sigma.zeroday.GuiContainerCreative;
import net.minecraft.e.sigma.zeroday.S2FPacketSetSlot;
import net.minecraft.client.momgetthecamera.zerodayisaminecraftcheat.ContainerLocalMenu;
import net.minecraft.q.IInteractionObject;
import net.minecraft.client.momgetthecamera.zerodayisaminecraftcheat.LocalBlockIntercommunication;
import net.minecraft.b.AnimalChest;
import net.minecraft.vape.flux.EntityHorse;
import net.minecraft.vape.IMerchant;
import net.minecraft.vape.NpcMerchant;
import net.minecraft.b.IInventory;
import net.minecraft.b.InventoryBasic;
import net.minecraft.e.sigma.zeroday.S2DPacketOpenWindow;
import net.minecraft.client.zeroday.EntityPlayerSP;
import net.minecraft.q.Explosion;
import net.minecraft.e.sigma.zeroday.S27PacketExplosion;
import net.minecraft.j.Scoreboard;
import net.minecraft.e.sigma.zeroday.S07PacketRespawn;
import net.minecraft.e.sigma.zeroday.S1FPacketSetExperience;
import net.minecraft.e.sigma.zeroday.S06PacketUpdateHealth;
import net.minecraft.client.zerodayisaminecraftcheat.ISound;
import net.minecraft.client.zerodayisaminecraftcheat.GuardianSound;
import net.minecraft.vape.zues.EntityGuardian;
import net.minecraft.e.sigma.zeroday.S19PacketEntityStatus;
import net.minecraft.vape.EntityLiving;
import net.minecraft.client.b.I18n;
import net.minecraft.client.c.GameSettings;
import net.minecraft.e.sigma.zeroday.S1BPacketEntityAttach;
import net.minecraft.e.sigma.zeroday.S05PacketSpawnPosition;
import net.minecraft.e.sigma.zeroday.S03PacketTimeUpdate;
import net.minecraft.vape.EntityList;
import net.minecraft.e.sigma.zeroday.S0FPacketSpawnMob;
import net.minecraft.e.sigma.zeroday.S0APacketUseBed;
import net.minecraft.o.EnumParticleTypes;
import net.minecraft.e.sigma.zeroday.S0BPacketAnimation;
import pandora.b;
import net.minecraft.e.sigma.zeroday.S02PacketChat;
import net.minecraft.client.vape.EntityFX;
import net.minecraft.client.vape.EntityPickupFX;
import net.minecraft.e.sigma.zeroday.S0DPacketCollectItem;
import zeroday.pandora.zerodayisaminecraftcheat.d.bi;
import zeroday.pandora.zerodayisaminecraftcheat.d.ah;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.H;
import zeroday.pandora.zerodayisaminecraftcheat.d.aS;
import net.minecraft.client.sigma.GuiMultiplayer;
import net.minecraft.client.sigma.GuiMainMenu;
import net.minecraft.client.sigma.GuiDisconnected;
import net.minecraft.i.DisconnectedRealmsScreen;
import net.minecraft.client.sigma.GuiScreenRealmsProxy;
import net.minecraft.o.IChatComponent;
import net.minecraft.e.sigma.zeroday.S40PacketDisconnect;
import net.minecraft.e.sigma.zeroday.S23PacketBlockChange;
import net.minecraft.q.sigma.Chunk;
import net.minecraft.q.WorldProviderSurface;
import net.minecraft.e.sigma.zeroday.S21PacketChunkData;
import net.minecraft.e.sigma.zeroday.S22PacketMultiBlockChange;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C03PacketPlayer;
import net.minecraft.e.sigma.zeroday.S08PacketPlayerPosLook;
import net.minecraft.e.sigma.zeroday.S13PacketDestroyEntities;
import net.minecraft.e.sigma.zeroday.S19PacketEntityHeadLook;
import net.minecraft.e.sigma.zeroday.S14PacketEntity;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.e.sigma.zeroday.S09PacketHeldItemChange;
import net.minecraft.e.sigma.zeroday.S18PacketEntityTeleport;
import net.minecraft.vape.DataWatcher;
import java.util.List;
import net.minecraft.c.Item;
import net.minecraft.client.zeroday.EntityOtherPlayerMP;
import net.minecraft.e.sigma.zeroday.S0CPacketSpawnPlayer;
import net.minecraft.e.sigma.zeroday.S1CPacketEntityMetadata;
import zeroday.pandora.zerodayisaminecraftcheat.d.bn;
import net.minecraft.e.sigma.zeroday.S12PacketEntityVelocity;
import net.minecraft.vape.pandora.EntityPainting;
import net.minecraft.e.sigma.zeroday.S10PacketSpawnPainting;
import net.minecraft.vape.sigma.EntityLightningBolt;
import net.minecraft.e.sigma.zeroday.S2CPacketSpawnGlobalEntity;
import net.minecraft.vape.pandora.EntityXPOrb;
import net.minecraft.e.sigma.zeroday.S11PacketSpawnExperienceOrb;
import net.minecraft.vape.Entity;
import net.minecraft.vape.pandora.EntityFallingBlock;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.vape.pandora.EntityItem;
import net.minecraft.vape.pandora.EntityEnderCrystal;
import net.minecraft.vape.pandora.EntityArmorStand;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.pandora.EntityTNTPrimed;
import net.minecraft.vape.pandora.EntityBoat;
import net.minecraft.vape.pandora.EntityExpBottle;
import net.minecraft.vape.momgetthecamera.EntityPotion;
import net.minecraft.vape.momgetthecamera.EntityEgg;
import net.minecraft.vape.momgetthecamera.EntityWitherSkull;
import net.minecraft.vape.momgetthecamera.EntitySmallFireball;
import net.minecraft.vape.momgetthecamera.EntityLargeFireball;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.pandora.EntityFireworkRocket;
import net.minecraft.vape.pandora.EntityEnderEye;
import net.minecraft.vape.pandora.EntityEnderPearl;
import net.minecraft.vape.EntityLeashKnot;
import net.minecraft.vape.pandora.EntityItemFrame;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.BlockPos;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.momgetthecamera.EntitySnowball;
import net.minecraft.vape.momgetthecamera.EntityArrow;
import net.minecraft.vape.momgetthecamera.EntityFishHook;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.q.World;
import net.minecraft.vape.pandora.EntityMinecart;
import net.minecraft.e.sigma.zeroday.S0EPacketSpawnObject;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C17PacketCustomPayload;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.e.PacketBuffer;
import io.netty.buffer.Unpooled;
import net.minecraft.client.sigma.GuiDownloadTerrain;
import net.minecraft.q.WorldSettings;
import net.minecraft.client.zues.PlayerControllerMP;
import net.minecraft.o.IThreadListener;
import net.minecraft.e.Packet;
import net.minecraft.e.PacketThreadUtil;
import net.minecraft.e.sigma.zeroday.S01PacketJoinGame;
import com.google.common.collect.Maps;
import org.apache.logging.log4j.LogManager;
import java.util.Random;
import java.util.UUID;
import java.util.Map;
import net.minecraft.client.zues.WorldClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.sigma.GuiScreen;
import com.mojang.authlib.GameProfile;
import net.minecraft.e.NetworkManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.e.sigma.INetHandlerPlayClient;

public class NetHandlerPlayClient implements INetHandlerPlayClient
{
    private static final Logger zeroday;
    private final NetworkManager sigma;
    private final GameProfile pandora;
    private final GuiScreen zues;
    private Minecraft flux;
    private WorldClient vape;
    private boolean momgetthecamera;
    private final Map<UUID, NetworkPlayerInfo> a;
    public int zerodayisaminecraftcheat;
    private boolean b;
    private final Random c;
    private static /* synthetic */ int[] d;
    private static /* synthetic */ int[] e;
    
    static {
        zeroday = LogManager.getLogger();
    }
    
    public NetHandlerPlayClient(final Minecraft mcIn, final GuiScreen p_i46300_2_, final NetworkManager p_i46300_3_, final GameProfile p_i46300_4_) {
        this.a = (Map<UUID, NetworkPlayerInfo>)Maps.newHashMap();
        this.zerodayisaminecraftcheat = 20;
        this.b = false;
        this.c = new Random();
        this.flux = mcIn;
        this.zues = p_i46300_2_;
        this.sigma = p_i46300_3_;
        this.pandora = p_i46300_4_;
    }
    
    public void zerodayisaminecraftcheat() {
        this.vape = null;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S01PacketJoinGame packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.zues = new PlayerControllerMP(this.flux, this);
        this.vape = new WorldClient(this, new WorldSettings(0L, packetIn.sigma(), false, packetIn.zeroday(), packetIn.vape()), packetIn.pandora(), packetIn.zues(), this.flux.z);
        this.flux.r.aq = packetIn.zues();
        this.flux.zerodayisaminecraftcheat(this.vape);
        this.flux.e.aq = packetIn.pandora();
        this.flux.zerodayisaminecraftcheat(new GuiDownloadTerrain(this));
        this.flux.e.pandora(packetIn.zerodayisaminecraftcheat());
        this.zerodayisaminecraftcheat = packetIn.flux();
        this.flux.e.b(packetIn.momgetthecamera());
        this.flux.zues.zerodayisaminecraftcheat(packetIn.sigma());
        this.flux.r.sigma();
        this.sigma.zeroday(new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).zerodayisaminecraftcheat(ClientBrandRetriever.zerodayisaminecraftcheat())));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S0EPacketSpawnObject packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final double d0 = packetIn.zeroday() / 32.0;
        final double d2 = packetIn.sigma() / 32.0;
        final double d3 = packetIn.pandora() / 32.0;
        Entity entity = null;
        if (packetIn.b() == 10) {
            entity = EntityMinecart.zerodayisaminecraftcheat(this.vape, d0, d2, d3, EntityMinecart.zerodayisaminecraftcheat.zerodayisaminecraftcheat(packetIn.c()));
        }
        else if (packetIn.b() == 90) {
            final Entity entity2 = this.vape.zerodayisaminecraftcheat(packetIn.c());
            if (entity2 instanceof EntityPlayer) {
                entity = new EntityFishHook(this.vape, d0, d2, d3, (EntityPlayer)entity2);
            }
            packetIn.vape(0);
        }
        else if (packetIn.b() == 60) {
            entity = new EntityArrow(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 61) {
            entity = new EntitySnowball(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 71) {
            entity = new EntityItemFrame(this.vape, new BlockPos(MathHelper.sigma(d0), MathHelper.sigma(d2), MathHelper.sigma(d3)), EnumFacing.zeroday(packetIn.c()));
            packetIn.vape(0);
        }
        else if (packetIn.b() == 77) {
            entity = new EntityLeashKnot(this.vape, new BlockPos(MathHelper.sigma(d0), MathHelper.sigma(d2), MathHelper.sigma(d3)));
            packetIn.vape(0);
        }
        else if (packetIn.b() == 65) {
            entity = new EntityEnderPearl(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 72) {
            entity = new EntityEnderEye(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 76) {
            entity = new EntityFireworkRocket(this.vape, d0, d2, d3, null);
        }
        else if (packetIn.b() == 63) {
            entity = new EntityLargeFireball(this.vape, d0, d2, d3, packetIn.zues() / 8000.0, packetIn.flux() / 8000.0, packetIn.vape() / 8000.0);
            packetIn.vape(0);
        }
        else if (packetIn.b() == 64) {
            entity = new EntitySmallFireball(this.vape, d0, d2, d3, packetIn.zues() / 8000.0, packetIn.flux() / 8000.0, packetIn.vape() / 8000.0);
            packetIn.vape(0);
        }
        else if (packetIn.b() == 66) {
            entity = new EntityWitherSkull(this.vape, d0, d2, d3, packetIn.zues() / 8000.0, packetIn.flux() / 8000.0, packetIn.vape() / 8000.0);
            packetIn.vape(0);
        }
        else if (packetIn.b() == 62) {
            entity = new EntityEgg(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 73) {
            entity = new EntityPotion(this.vape, d0, d2, d3, packetIn.c());
            packetIn.vape(0);
        }
        else if (packetIn.b() == 75) {
            entity = new EntityExpBottle(this.vape, d0, d2, d3);
            packetIn.vape(0);
        }
        else if (packetIn.b() == 1) {
            entity = new EntityBoat(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 50) {
            entity = new EntityTNTPrimed(this.vape, d0, d2, d3, null);
        }
        else if (packetIn.b() == 78) {
            entity = new EntityArmorStand(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 51) {
            entity = new EntityEnderCrystal(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 2) {
            entity = new EntityItem(this.vape, d0, d2, d3);
        }
        else if (packetIn.b() == 70) {
            entity = new EntityFallingBlock(this.vape, d0, d2, d3, Block.zeroday(packetIn.c() & 0xFFFF));
            packetIn.vape(0);
        }
        if (entity != null) {
            entity.ai = packetIn.zeroday();
            entity.aj = packetIn.sigma();
            entity.ak = packetIn.pandora();
            entity.z = packetIn.momgetthecamera() * 360 / 256.0f;
            entity.y = packetIn.a() * 360 / 256.0f;
            final Entity[] aentity = entity.at();
            if (aentity != null) {
                final int i = packetIn.zerodayisaminecraftcheat() - entity.B();
                for (int j = 0; j < aentity.length; ++j) {
                    aentity[j].pandora(aentity[j].B() + i);
                }
            }
            entity.pandora(packetIn.zerodayisaminecraftcheat());
            this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), entity);
            if (packetIn.c() > 0) {
                if (packetIn.b() == 60) {
                    final Entity entity3 = this.vape.zerodayisaminecraftcheat(packetIn.c());
                    if (entity3 instanceof EntityLivingBase && entity instanceof EntityArrow) {
                        ((EntityArrow)entity).sigma = entity3;
                    }
                }
                entity.a(packetIn.zues() / 8000.0, packetIn.flux() / 8000.0, packetIn.vape() / 8000.0);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S11PacketSpawnExperienceOrb packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = new EntityXPOrb(this.vape, packetIn.zeroday() / 32.0, packetIn.sigma() / 32.0, packetIn.pandora() / 32.0, packetIn.zues());
        entity.ai = packetIn.zeroday();
        entity.aj = packetIn.sigma();
        entity.ak = packetIn.pandora();
        entity.y = 0.0f;
        entity.z = 0.0f;
        entity.pandora(packetIn.zerodayisaminecraftcheat());
        this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), entity);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S2CPacketSpawnGlobalEntity packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final double d0 = packetIn.zeroday() / 32.0;
        final double d2 = packetIn.sigma() / 32.0;
        final double d3 = packetIn.pandora() / 32.0;
        Entity entity = null;
        if (packetIn.zues() == 1) {
            entity = new EntityLightningBolt(this.vape, d0, d2, d3);
        }
        if (entity != null) {
            entity.ai = packetIn.zeroday();
            entity.aj = packetIn.sigma();
            entity.ak = packetIn.pandora();
            entity.y = 0.0f;
            entity.z = 0.0f;
            entity.pandora(packetIn.zerodayisaminecraftcheat());
            this.vape.zues(entity);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S10PacketSpawnPainting packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPainting entitypainting = new EntityPainting(this.vape, packetIn.zeroday(), packetIn.sigma(), packetIn.pandora());
        this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), entitypainting);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S12PacketEntityVelocity packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (!bn.c) {
            final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
            if (entity != null) {
                entity.a(packetIn.zeroday() / 8000.0, packetIn.sigma() / 8000.0, packetIn.pandora() / 8000.0);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S1CPacketEntityMetadata packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zeroday());
        if (entity != null && packetIn.zerodayisaminecraftcheat() != null) {
            entity.D().zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S0CPacketSpawnPlayer packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final double d0 = packetIn.pandora() / 32.0;
        final double d2 = packetIn.zues() / 32.0;
        final double d3 = packetIn.flux() / 32.0;
        final float f = packetIn.vape() * 360 / 256.0f;
        final float f2 = packetIn.momgetthecamera() * 360 / 256.0f;
        final EntityOtherPlayerMP entityOtherPlayerMP3;
        final EntityOtherPlayerMP entityOtherPlayerMP2;
        final EntityOtherPlayerMP entityOtherPlayerMP;
        final EntityOtherPlayerMP entityotherplayermp = entityOtherPlayerMP = (entityOtherPlayerMP2 = (entityOtherPlayerMP3 = new EntityOtherPlayerMP(this.flux.a, this.zerodayisaminecraftcheat(packetIn.sigma()).zerodayisaminecraftcheat())));
        final int pandora = packetIn.pandora();
        entityOtherPlayerMP.ai = pandora;
        final double n = pandora;
        entityOtherPlayerMP2.Q = n;
        entityOtherPlayerMP3.p = n;
        final EntityOtherPlayerMP entityOtherPlayerMP4 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP5 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP6 = entityotherplayermp;
        final int zues = packetIn.zues();
        entityOtherPlayerMP6.aj = zues;
        final double n2 = zues;
        entityOtherPlayerMP5.R = n2;
        entityOtherPlayerMP4.q = n2;
        final EntityOtherPlayerMP entityOtherPlayerMP7 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP8 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP9 = entityotherplayermp;
        final int flux = packetIn.flux();
        entityOtherPlayerMP9.ak = flux;
        final double n3 = flux;
        entityOtherPlayerMP8.S = n3;
        entityOtherPlayerMP7.r = n3;
        final int i = packetIn.a();
        if (i == 0) {
            entityotherplayermp.d.zerodayisaminecraftcheat[entityotherplayermp.d.sigma] = null;
        }
        else {
            entityotherplayermp.d.zerodayisaminecraftcheat[entityotherplayermp.d.sigma] = new ItemStack(Item.zerodayisaminecraftcheat(i), 1, 0);
        }
        entityotherplayermp.zerodayisaminecraftcheat(d0, d2, d3, f, f2);
        this.vape.zerodayisaminecraftcheat(packetIn.zeroday(), entityotherplayermp);
        final List<DataWatcher.zerodayisaminecraftcheat> list = packetIn.zerodayisaminecraftcheat();
        if (list != null) {
            entityotherplayermp.D().zerodayisaminecraftcheat(list);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S18PacketEntityTeleport packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        if (entity != null) {
            entity.ai = packetIn.zeroday();
            entity.aj = packetIn.sigma();
            entity.ak = packetIn.pandora();
            final double d0 = entity.ai / 32.0;
            final double d2 = entity.aj / 32.0;
            final double d3 = entity.ak / 32.0;
            final float f = packetIn.zues() * 360 / 256.0f;
            final float f2 = packetIn.flux() * 360 / 256.0f;
            if (Math.abs(entity.s - d0) < 0.03125 && Math.abs(entity.t - d2) < 0.015625 && Math.abs(entity.u - d3) < 0.03125) {
                entity.zerodayisaminecraftcheat(entity.s, entity.t, entity.u, f, f2, 3, true);
            }
            else {
                entity.zerodayisaminecraftcheat(d0, d2, d3, f, f2, 3, true);
            }
            entity.D = packetIn.vape();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S09PacketHeldItemChange packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (packetIn.zerodayisaminecraftcheat() >= 0 && packetIn.zerodayisaminecraftcheat() < InventoryPlayer.flux()) {
            this.flux.e.d.sigma = packetIn.zerodayisaminecraftcheat();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S14PacketEntity packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = packetIn.zerodayisaminecraftcheat(this.vape);
        if (entity != null) {
            final Entity entity2 = entity;
            entity2.ai += packetIn.zerodayisaminecraftcheat();
            final Entity entity3 = entity;
            entity3.aj += packetIn.zeroday();
            final Entity entity4 = entity;
            entity4.ak += packetIn.sigma();
            final double d0 = entity.ai / 32.0;
            final double d2 = entity.aj / 32.0;
            final double d3 = entity.ak / 32.0;
            final float f = packetIn.flux() ? (packetIn.pandora() * 360 / 256.0f) : entity.y;
            final float f2 = packetIn.flux() ? (packetIn.zues() * 360 / 256.0f) : entity.z;
            entity.zerodayisaminecraftcheat(d0, d2, d3, f, f2, 3, false);
            entity.D = packetIn.vape();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S19PacketEntityHeadLook packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = packetIn.zerodayisaminecraftcheat(this.vape);
        if (entity != null) {
            final float f = packetIn.zerodayisaminecraftcheat() * 360 / 256.0f;
            entity.momgetthecamera(f);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S13PacketDestroyEntities packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        for (int i = 0; i < packetIn.zerodayisaminecraftcheat().length; ++i) {
            this.vape.zeroday(packetIn.zerodayisaminecraftcheat()[i]);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S08PacketPlayerPosLook packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPlayer entityplayer = this.flux.e;
        double d0 = packetIn.zeroday();
        double d2 = packetIn.sigma();
        double d3 = packetIn.pandora();
        float f = packetIn.zues();
        float f2 = packetIn.flux();
        if (packetIn.vape().contains(S08PacketPlayerPosLook.zerodayisaminecraftcheat.zerodayisaminecraftcheat)) {
            d0 += entityplayer.s;
        }
        else {
            entityplayer.v = 0.0;
        }
        if (packetIn.vape().contains(S08PacketPlayerPosLook.zerodayisaminecraftcheat.zeroday)) {
            d2 += entityplayer.t;
        }
        else {
            entityplayer.w = 0.0;
        }
        if (packetIn.vape().contains(S08PacketPlayerPosLook.zerodayisaminecraftcheat.sigma)) {
            d3 += entityplayer.u;
        }
        else {
            entityplayer.x = 0.0;
        }
        if (packetIn.vape().contains(S08PacketPlayerPosLook.zerodayisaminecraftcheat.zues)) {
            f2 += entityplayer.z;
        }
        if (packetIn.vape().contains(S08PacketPlayerPosLook.zerodayisaminecraftcheat.pandora)) {
            f += entityplayer.y;
        }
        entityplayer.zerodayisaminecraftcheat(d0, d2, d3, f, f2);
        this.sigma.zeroday(new C03PacketPlayer.sigma(entityplayer.s, entityplayer.aH().zeroday, entityplayer.u, entityplayer.y, entityplayer.z, false));
        if (!this.momgetthecamera) {
            this.flux.e.p = this.flux.e.s;
            this.flux.e.q = this.flux.e.t;
            this.flux.e.r = this.flux.e.u;
            this.momgetthecamera = true;
            this.flux.zerodayisaminecraftcheat((GuiScreen)null);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S22PacketMultiBlockChange packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        S22PacketMultiBlockChange.zerodayisaminecraftcheat[] zerodayisaminecraftcheat;
        for (int length = (zerodayisaminecraftcheat = packetIn.zerodayisaminecraftcheat()).length, i = 0; i < length; ++i) {
            final S22PacketMultiBlockChange.zerodayisaminecraftcheat s22packetmultiblockchange$blockupdatedata = zerodayisaminecraftcheat[i];
            this.vape.zerodayisaminecraftcheat(s22packetmultiblockchange$blockupdatedata.zerodayisaminecraftcheat(), s22packetmultiblockchange$blockupdatedata.sigma());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S21PacketChunkData packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (packetIn.zues()) {
            if (packetIn.pandora() == 0) {
                this.vape.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.sigma(), false);
                return;
            }
            this.vape.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.sigma(), true);
        }
        this.vape.zerodayisaminecraftcheat(packetIn.zeroday() << 4, 0, packetIn.sigma() << 4, (packetIn.zeroday() << 4) + 15, 256, (packetIn.sigma() << 4) + 15);
        final Chunk chunk = this.vape.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.sigma());
        chunk.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), packetIn.pandora(), packetIn.zues());
        this.vape.zeroday(packetIn.zeroday() << 4, 0, packetIn.sigma() << 4, (packetIn.zeroday() << 4) + 15, 256, (packetIn.sigma() << 4) + 15);
        if (!packetIn.zues() || !(this.vape.h instanceof WorldProviderSurface)) {
            chunk.d();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S23PacketBlockChange packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.vape.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.zerodayisaminecraftcheat());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S40PacketDisconnect packetIn) {
        this.sigma.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IChatComponent reason) {
        this.flux.zerodayisaminecraftcheat((WorldClient)null);
        if (this.zues != null) {
            if (this.zues instanceof GuiScreenRealmsProxy) {
                this.flux.zerodayisaminecraftcheat(new DisconnectedRealmsScreen(((GuiScreenRealmsProxy)this.zues).flux(), "disconnect.lost", reason).zerodayisaminecraftcheat());
            }
            else {
                this.flux.zerodayisaminecraftcheat(new GuiDisconnected(this.zues, "disconnect.lost", reason));
            }
        }
        else {
            this.flux.zerodayisaminecraftcheat(new GuiDisconnected(new GuiMultiplayer(new GuiMainMenu()), "disconnect.lost", reason));
        }
    }
    
    public void zerodayisaminecraftcheat(final Packet p_147297_1_) {
        if (p_147297_1_ instanceof C03PacketPlayer.zeroday && aS.j && aS.i != 0) {
            aS.t();
            return;
        }
        if (p_147297_1_ instanceof C03PacketPlayer.sigma && aS.j && aS.i != 0) {
            aS.u();
            return;
        }
        if (H.vape) {
            if (Minecraft.s().e.D) {
                if (p_147297_1_ instanceof C03PacketPlayer.zeroday && ah.J && H.momgetthecamera) {
                    ah.t();
                    return;
                }
                if (p_147297_1_ instanceof C03PacketPlayer.sigma && ah.J && H.momgetthecamera) {
                    ah.u();
                    return;
                }
            }
        }
        else {
            if (p_147297_1_ instanceof C03PacketPlayer.zeroday && ah.J && H.momgetthecamera) {
                ah.t();
                return;
            }
            if (p_147297_1_ instanceof C03PacketPlayer.sigma && ah.J && H.momgetthecamera) {
                ah.u();
                return;
            }
        }
        if (p_147297_1_ instanceof C03PacketPlayer.zeroday && bi.f) {
            bi.r();
            return;
        }
        if (p_147297_1_ instanceof C03PacketPlayer.sigma && bi.f) {
            bi.s();
            return;
        }
        this.sigma.zeroday(p_147297_1_);
    }
    
    public void zeroday(final Packet p_147297_1_) {
        this.sigma.zeroday(p_147297_1_);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S0DPacketCollectItem packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        EntityLivingBase entitylivingbase = (EntityLivingBase)this.vape.zerodayisaminecraftcheat(packetIn.zeroday());
        if (entitylivingbase == null) {
            entitylivingbase = this.flux.e;
        }
        if (entity != null) {
            if (entity instanceof EntityXPOrb) {
                this.vape.zerodayisaminecraftcheat(entity, "random.orb", 0.2f, ((this.c.nextFloat() - this.c.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            }
            else {
                this.vape.zerodayisaminecraftcheat(entity, "random.pop", 0.2f, ((this.c.nextFloat() - this.c.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            }
            this.flux.g.zerodayisaminecraftcheat(new EntityPickupFX(this.vape, entity, entitylivingbase, 0.5f));
            this.vape.zeroday(packetIn.zerodayisaminecraftcheat());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S02PacketChat packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (packetIn.sigma() == 2) {
            this.flux.o.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), false);
        }
        else {
            this.flux.o.pandora().zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        }
        pandora.b.zerodayisaminecraftcheat(this, packetIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S0BPacketAnimation packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        if (entity != null) {
            if (packetIn.zeroday() == 0) {
                final EntityLivingBase entitylivingbase = (EntityLivingBase)entity;
                entitylivingbase.e_();
            }
            else if (packetIn.zeroday() == 1) {
                entity.ak();
            }
            else if (packetIn.zeroday() == 2) {
                final EntityPlayer entityplayer = (EntityPlayer)entity;
                entityplayer.zerodayisaminecraftcheat(false, false, false);
            }
            else if (packetIn.zeroday() == 4) {
                this.flux.g.zerodayisaminecraftcheat(entity, EnumParticleTypes.b);
            }
            else if (packetIn.zeroday() == 5) {
                this.flux.g.zerodayisaminecraftcheat(entity, EnumParticleTypes.c);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S0APacketUseBed packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        packetIn.zerodayisaminecraftcheat(this.vape).zues(packetIn.zerodayisaminecraftcheat());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S0FPacketSpawnMob packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final double d0 = packetIn.pandora() / 32.0;
        final double d2 = packetIn.zues() / 32.0;
        final double d3 = packetIn.flux() / 32.0;
        final float f = packetIn.b() * 360 / 256.0f;
        final float f2 = packetIn.c() * 360 / 256.0f;
        final EntityLivingBase entitylivingbase = (EntityLivingBase)EntityList.zerodayisaminecraftcheat(packetIn.sigma(), this.flux.a);
        entitylivingbase.ai = packetIn.pandora();
        entitylivingbase.aj = packetIn.zues();
        entitylivingbase.ak = packetIn.flux();
        final EntityLivingBase entityLivingBase = entitylivingbase;
        final EntityLivingBase entityLivingBase2 = entitylivingbase;
        final float n = packetIn.d() * 360 / 256.0f;
        entityLivingBase2.aN = n;
        entityLivingBase.aL = n;
        final Entity[] aentity = entitylivingbase.at();
        if (aentity != null) {
            final int i = packetIn.zeroday() - entitylivingbase.B();
            for (int j = 0; j < aentity.length; ++j) {
                aentity[j].pandora(aentity[j].B() + i);
            }
        }
        entitylivingbase.pandora(packetIn.zeroday());
        entitylivingbase.zerodayisaminecraftcheat(d0, d2, d3, f, f2);
        entitylivingbase.v = packetIn.vape() / 8000.0f;
        entitylivingbase.w = packetIn.momgetthecamera() / 8000.0f;
        entitylivingbase.x = packetIn.a() / 8000.0f;
        this.vape.zerodayisaminecraftcheat(packetIn.zeroday(), entitylivingbase);
        final List<DataWatcher.zerodayisaminecraftcheat> list = packetIn.zerodayisaminecraftcheat();
        if (list != null) {
            entitylivingbase.D().zerodayisaminecraftcheat(list);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S03PacketTimeUpdate packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.a.zeroday(packetIn.zerodayisaminecraftcheat());
        this.flux.a.zerodayisaminecraftcheat(packetIn.zeroday());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S05PacketSpawnPosition packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.e.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), true);
        this.flux.a.u().zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S1BPacketEntityAttach packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zeroday());
        final Entity entity2 = this.vape.zerodayisaminecraftcheat(packetIn.sigma());
        if (packetIn.zerodayisaminecraftcheat() == 0) {
            boolean flag = false;
            if (packetIn.zeroday() == this.flux.e.B()) {
                entity = this.flux.e;
                if (entity2 instanceof EntityBoat) {
                    ((EntityBoat)entity2).zerodayisaminecraftcheat(false);
                }
                flag = (entity.m == null && entity2 != null);
            }
            else if (entity2 instanceof EntityBoat) {
                ((EntityBoat)entity2).zerodayisaminecraftcheat(true);
            }
            if (entity == null) {
                return;
            }
            entity.zerodayisaminecraftcheat(entity2);
            if (flag) {
                final GameSettings gamesettings = this.flux.r;
                this.flux.o.zerodayisaminecraftcheat(I18n.zerodayisaminecraftcheat("mount.onboard", GameSettings.zerodayisaminecraftcheat(gamesettings.U.a())), false);
            }
        }
        else if (packetIn.zerodayisaminecraftcheat() == 1 && entity instanceof EntityLiving) {
            if (entity2 != null) {
                ((EntityLiving)entity).zerodayisaminecraftcheat(entity2, false);
            }
            else {
                ((EntityLiving)entity).zerodayisaminecraftcheat(false, false);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S19PacketEntityStatus packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = packetIn.zerodayisaminecraftcheat(this.vape);
        if (entity != null) {
            if (packetIn.zerodayisaminecraftcheat() == 21) {
                this.flux.P().zerodayisaminecraftcheat(new GuardianSound((EntityGuardian)entity));
            }
            else {
                entity.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S06PacketUpdateHealth packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.e.sigma(packetIn.zerodayisaminecraftcheat());
        this.flux.e.ca().zerodayisaminecraftcheat(packetIn.zeroday());
        this.flux.e.ca().zeroday(packetIn.sigma());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S1FPacketSetExperience packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.e.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), packetIn.zeroday(), packetIn.sigma());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S07PacketRespawn packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (packetIn.zerodayisaminecraftcheat() != this.flux.e.aq) {
            this.momgetthecamera = false;
            final Scoreboard scoreboard = this.vape.E();
            (this.vape = new WorldClient(this, new WorldSettings(0L, packetIn.sigma(), false, this.flux.a.u().k(), packetIn.pandora()), packetIn.zerodayisaminecraftcheat(), packetIn.zeroday(), this.flux.z)).zerodayisaminecraftcheat(scoreboard);
            this.flux.zerodayisaminecraftcheat(this.vape);
            this.flux.e.aq = packetIn.zerodayisaminecraftcheat();
            this.flux.zerodayisaminecraftcheat(new GuiDownloadTerrain(this));
        }
        this.flux.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        this.flux.zues.zerodayisaminecraftcheat(packetIn.sigma());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S27PacketExplosion packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Explosion explosion = new Explosion(this.flux.a, null, packetIn.pandora(), packetIn.zues(), packetIn.flux(), packetIn.vape(), packetIn.momgetthecamera());
        explosion.zerodayisaminecraftcheat(true);
        final EntityPlayerSP e = this.flux.e;
        e.v += packetIn.zerodayisaminecraftcheat();
        final EntityPlayerSP e2 = this.flux.e;
        e2.w += packetIn.zeroday();
        final EntityPlayerSP e3 = this.flux.e;
        e3.x += packetIn.sigma();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S2DPacketOpenWindow packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPlayerSP entityplayersp = this.flux.e;
        if ("minecraft:container".equals(packetIn.zeroday())) {
            entityplayersp.zerodayisaminecraftcheat(new InventoryBasic(packetIn.sigma(), packetIn.pandora()));
            entityplayersp.f.pandora = packetIn.zerodayisaminecraftcheat();
        }
        else if ("minecraft:villager".equals(packetIn.zeroday())) {
            entityplayersp.zerodayisaminecraftcheat(new NpcMerchant(entityplayersp, packetIn.sigma()));
            entityplayersp.f.pandora = packetIn.zerodayisaminecraftcheat();
        }
        else if ("EntityHorse".equals(packetIn.zeroday())) {
            final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zues());
            if (entity instanceof EntityHorse) {
                entityplayersp.zerodayisaminecraftcheat((EntityHorse)entity, new AnimalChest(packetIn.sigma(), packetIn.pandora()));
                entityplayersp.f.pandora = packetIn.zerodayisaminecraftcheat();
            }
        }
        else if (!packetIn.flux()) {
            entityplayersp.zerodayisaminecraftcheat(new LocalBlockIntercommunication(packetIn.zeroday(), packetIn.sigma()));
            entityplayersp.f.pandora = packetIn.zerodayisaminecraftcheat();
        }
        else {
            final ContainerLocalMenu containerlocalmenu = new ContainerLocalMenu(packetIn.zeroday(), packetIn.sigma(), packetIn.pandora());
            entityplayersp.zerodayisaminecraftcheat((IInventory)containerlocalmenu);
            entityplayersp.f.pandora = packetIn.zerodayisaminecraftcheat();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S2FPacketSetSlot packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPlayer entityplayer = this.flux.e;
        if (packetIn.zerodayisaminecraftcheat() == -1) {
            entityplayer.d.zeroday(packetIn.sigma());
        }
        else {
            boolean flag = false;
            if (this.flux.k instanceof GuiContainerCreative) {
                final GuiContainerCreative guicontainercreative = (GuiContainerCreative)this.flux.k;
                flag = (guicontainercreative.vape() != CreativeTabs.e.zerodayisaminecraftcheat());
            }
            if (packetIn.zerodayisaminecraftcheat() == 0 && packetIn.zeroday() >= 36 && packetIn.zeroday() < 45) {
                final ItemStack itemstack = entityplayer.e.zerodayisaminecraftcheat(packetIn.zeroday()).zerodayisaminecraftcheat();
                if (packetIn.sigma() != null && (itemstack == null || itemstack.zeroday < packetIn.sigma().zeroday)) {
                    packetIn.sigma().sigma = 5;
                }
                entityplayer.e.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.sigma());
            }
            else if (packetIn.zerodayisaminecraftcheat() == entityplayer.f.pandora && (packetIn.zerodayisaminecraftcheat() != 0 || !flag)) {
                entityplayer.f.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.sigma());
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S32PacketConfirmTransaction packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        Container container = null;
        final EntityPlayer entityplayer = this.flux.e;
        if (packetIn.zerodayisaminecraftcheat() == 0) {
            container = entityplayer.e;
        }
        else if (packetIn.zerodayisaminecraftcheat() == entityplayer.f.pandora) {
            container = entityplayer.f;
        }
        if (container != null && !packetIn.sigma()) {
            this.zerodayisaminecraftcheat(new C0FPacketConfirmTransaction(packetIn.zerodayisaminecraftcheat(), packetIn.zeroday(), true));
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S30PacketWindowItems packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPlayer entityplayer = this.flux.e;
        if (packetIn.zerodayisaminecraftcheat() == 0) {
            entityplayer.e.zerodayisaminecraftcheat(packetIn.zeroday());
        }
        else if (packetIn.zerodayisaminecraftcheat() == entityplayer.f.pandora) {
            entityplayer.f.zerodayisaminecraftcheat(packetIn.zeroday());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S36PacketSignEditorOpen packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        TileEntity tileentity = this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        if (!(tileentity instanceof TileEntitySign)) {
            tileentity = new TileEntitySign();
            tileentity.zerodayisaminecraftcheat(this.vape);
            tileentity.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        }
        this.flux.e.zerodayisaminecraftcheat((TileEntitySign)tileentity);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S33PacketUpdateSign packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        boolean flag = false;
        if (this.flux.a.flux(packetIn.zerodayisaminecraftcheat())) {
            final TileEntity tileentity = this.flux.a.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
            if (tileentity instanceof TileEntitySign) {
                final TileEntitySign tileentitysign = (TileEntitySign)tileentity;
                if (tileentitysign.zerodayisaminecraftcheat()) {
                    System.arraycopy(packetIn.zeroday(), 0, tileentitysign.zues, 0, 4);
                    tileentitysign.t();
                }
                flag = true;
            }
        }
        if (!flag && this.flux.e != null) {
            this.flux.e.zerodayisaminecraftcheat(new ChatComponentText("Unable to locate sign at " + packetIn.zerodayisaminecraftcheat().zerodayisaminecraftcheat() + ", " + packetIn.zerodayisaminecraftcheat().zeroday() + ", " + packetIn.zerodayisaminecraftcheat().sigma()));
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S35PacketUpdateTileEntity packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (this.flux.a.flux(packetIn.zerodayisaminecraftcheat())) {
            final TileEntity tileentity = this.flux.a.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
            final int i = packetIn.zeroday();
            if ((i == 1 && tileentity instanceof TileEntityMobSpawner) || (i == 2 && tileentity instanceof TileEntityCommandBlock) || (i == 3 && tileentity instanceof TileEntityBeacon) || (i == 4 && tileentity instanceof TileEntitySkull) || (i == 5 && tileentity instanceof TileEntityFlowerPot) || (i == 6 && tileentity instanceof TileEntityBanner)) {
                tileentity.zerodayisaminecraftcheat(packetIn.sigma());
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S31PacketWindowProperty packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPlayer entityplayer = this.flux.e;
        if (entityplayer.f != null && entityplayer.f.pandora == packetIn.zerodayisaminecraftcheat()) {
            entityplayer.f.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.sigma());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S04PacketEntityEquipment packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zeroday());
        if (entity != null) {
            entity.zerodayisaminecraftcheat(packetIn.sigma(), packetIn.zerodayisaminecraftcheat());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S2EPacketCloseWindow packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.e.o();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S24PacketBlockAction packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.a.sigma(packetIn.zerodayisaminecraftcheat(), packetIn.pandora(), packetIn.zeroday(), packetIn.sigma());
        pandora.b.zerodayisaminecraftcheat(this, packetIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S25PacketBlockBreakAnim packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.a.sigma(packetIn.zerodayisaminecraftcheat(), packetIn.zeroday(), packetIn.sigma());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S26PacketMapChunkBulk packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        for (int i = 0; i < packetIn.zerodayisaminecraftcheat(); ++i) {
            final int j = packetIn.zerodayisaminecraftcheat(i);
            final int k = packetIn.zeroday(i);
            this.vape.zerodayisaminecraftcheat(j, k, true);
            this.vape.zerodayisaminecraftcheat(j << 4, 0, k << 4, (j << 4) + 15, 256, (k << 4) + 15);
            final Chunk chunk = this.vape.zerodayisaminecraftcheat(j, k);
            chunk.zerodayisaminecraftcheat(packetIn.sigma(i), packetIn.pandora(i), true);
            this.vape.zeroday(j << 4, 0, k << 4, (j << 4) + 15, 256, (k << 4) + 15);
            if (!(this.vape.h instanceof WorldProviderSurface)) {
                chunk.d();
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S2BPacketChangeGameState packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPlayer entityplayer = this.flux.e;
        final int i = packetIn.zerodayisaminecraftcheat();
        final float f = packetIn.zeroday();
        final int j = MathHelper.pandora(f + 0.5f);
        if (i >= 0 && i < S2BPacketChangeGameState.zerodayisaminecraftcheat.length && S2BPacketChangeGameState.zerodayisaminecraftcheat[i] != null) {
            entityplayer.zeroday(new ChatComponentTranslation(S2BPacketChangeGameState.zerodayisaminecraftcheat[i], new Object[0]));
        }
        if (i == 1) {
            this.vape.u().zeroday(true);
            this.vape.c(0.0f);
        }
        else if (i == 2) {
            this.vape.u().zeroday(false);
            this.vape.c(1.0f);
        }
        else if (i == 3) {
            this.flux.zues.zerodayisaminecraftcheat(WorldSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat(j));
        }
        else if (i == 4) {
            this.flux.zerodayisaminecraftcheat(new GuiWinGame());
        }
        else if (i == 5) {
            final GameSettings gamesettings = this.flux.r;
            if (f == 0.0f) {
                this.flux.zerodayisaminecraftcheat(new GuiScreenDemo());
            }
            else if (f == 101.0f) {
                this.flux.o.pandora().zerodayisaminecraftcheat(new ChatComponentTranslation("demo.help.movement", new Object[] { GameSettings.zerodayisaminecraftcheat(gamesettings.P.a()), GameSettings.zerodayisaminecraftcheat(gamesettings.Q.a()), GameSettings.zerodayisaminecraftcheat(gamesettings.R.a()), GameSettings.zerodayisaminecraftcheat(gamesettings.S.a()) }));
            }
            else if (f == 102.0f) {
                this.flux.o.pandora().zerodayisaminecraftcheat(new ChatComponentTranslation("demo.help.jump", new Object[] { GameSettings.zerodayisaminecraftcheat(gamesettings.T.a()) }));
            }
            else if (f == 103.0f) {
                this.flux.o.pandora().zerodayisaminecraftcheat(new ChatComponentTranslation("demo.help.inventory", new Object[] { GameSettings.zerodayisaminecraftcheat(gamesettings.W.a()) }));
            }
        }
        else if (i == 6) {
            this.vape.zerodayisaminecraftcheat(entityplayer.s, entityplayer.t + entityplayer.aI(), entityplayer.u, "random.successful_hit", 0.18f, 0.45f, false);
        }
        else if (i == 7) {
            this.vape.c(f);
        }
        else if (i == 8) {
            this.vape.a(f);
        }
        else if (i == 10) {
            this.vape.zerodayisaminecraftcheat(EnumParticleTypes.H, entityplayer.s, entityplayer.t, entityplayer.u, 0.0, 0.0, 0.0, new int[0]);
            this.vape.zerodayisaminecraftcheat(entityplayer.s, entityplayer.t, entityplayer.u, "mob.guardian.curse", 1.0f, 1.0f, false);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S34PacketMaps packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final MapData mapdata = ItemMap.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), this.flux.a);
        packetIn.zerodayisaminecraftcheat(mapdata);
        this.flux.m.b().zerodayisaminecraftcheat(mapdata);
        pandora.b.zerodayisaminecraftcheat(this, packetIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S28PacketEffect packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (packetIn.zerodayisaminecraftcheat()) {
            this.flux.a.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.pandora(), packetIn.sigma());
        }
        else {
            this.flux.a.zeroday(packetIn.zeroday(), packetIn.pandora(), packetIn.sigma());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S37PacketStatistics packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        boolean flag = false;
        for (final Map.Entry<StatBase, Integer> entry : packetIn.zerodayisaminecraftcheat().entrySet()) {
            final StatBase statbase = entry.getKey();
            final int i = entry.getValue();
            if (statbase.pandora() && i > 0) {
                if (this.b && this.flux.e.u().zerodayisaminecraftcheat(statbase) == 0) {
                    final Achievement achievement = (Achievement)statbase;
                    this.flux.n.zerodayisaminecraftcheat(achievement);
                    this.flux.R().zerodayisaminecraftcheat(new MetadataAchievement(achievement), 0L);
                    if (statbase == AchievementList.flux) {
                        this.flux.r.A = false;
                        this.flux.r.zeroday();
                    }
                }
                flag = true;
            }
            this.flux.e.u().zeroday(this.flux.e, statbase, i);
        }
        if (!this.b && !flag && this.flux.r.A) {
            this.flux.n.zeroday(AchievementList.flux);
        }
        this.b = true;
        if (this.flux.k instanceof IProgressMeter) {
            ((IProgressMeter)this.flux.k).zeroday();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S1DPacketEntityEffect packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zeroday());
        if (entity instanceof EntityLivingBase) {
            final PotionEffect potioneffect = new PotionEffect(packetIn.sigma(), packetIn.zues(), packetIn.pandora(), false, packetIn.flux());
            potioneffect.zeroday(packetIn.zerodayisaminecraftcheat());
            ((EntityLivingBase)entity).zerodayisaminecraftcheat(potioneffect);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S42PacketCombatEvent packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.sigma);
        final EntityLivingBase entitylivingbase = (entity instanceof EntityLivingBase) ? ((EntityLivingBase)entity) : null;
        if (packetIn.zerodayisaminecraftcheat == S42PacketCombatEvent.zerodayisaminecraftcheat.zeroday) {
            final long i = 1000 * packetIn.pandora / 20;
            final MetadataCombat metadatacombat = new MetadataCombat(this.flux.e, entitylivingbase);
            this.flux.R().zerodayisaminecraftcheat(metadatacombat, 0L - i, 0L);
        }
        else if (packetIn.zerodayisaminecraftcheat == S42PacketCombatEvent.zerodayisaminecraftcheat.sigma) {
            final Entity entity2 = this.vape.zerodayisaminecraftcheat(packetIn.zeroday);
            if (entity2 instanceof EntityPlayer) {
                final MetadataPlayerDeath metadataplayerdeath = new MetadataPlayerDeath((EntityLivingBase)entity2, entitylivingbase);
                metadataplayerdeath.zerodayisaminecraftcheat(packetIn.zues);
                this.flux.R().zerodayisaminecraftcheat(metadataplayerdeath, 0L);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S41PacketServerDifficulty packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.a.u().zerodayisaminecraftcheat(packetIn.zeroday());
        this.flux.a.u().zues(packetIn.zerodayisaminecraftcheat());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S43PacketCamera packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = packetIn.zerodayisaminecraftcheat(this.vape);
        if (entity != null) {
            this.flux.zerodayisaminecraftcheat(entity);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S44PacketWorldBorder packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        packetIn.zerodayisaminecraftcheat(this.vape.K());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S45PacketTitle packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final S45PacketTitle.zerodayisaminecraftcheat s45packettitle$type = packetIn.zerodayisaminecraftcheat();
        String s = null;
        String s2 = null;
        final String s3 = (packetIn.zeroday() != null) ? packetIn.zeroday().a() : "";
        switch (zues()[s45packettitle$type.ordinal()]) {
            case 1: {
                s = s3;
                break;
            }
            case 2: {
                s2 = s3;
                break;
            }
            case 5: {
                this.flux.o.zerodayisaminecraftcheat("", "", -1, -1, -1);
                this.flux.o.zerodayisaminecraftcheat();
                return;
            }
        }
        this.flux.o.zerodayisaminecraftcheat(s, s2, packetIn.sigma(), packetIn.pandora(), packetIn.zues());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S46PacketSetCompressionLevel packetIn) {
        if (!this.sigma.sigma()) {
            this.sigma.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S47PacketPlayerListHeaderFooter packetIn) {
        this.flux.o.momgetthecamera().zeroday((packetIn.zerodayisaminecraftcheat().a().length() == 0) ? null : packetIn.zerodayisaminecraftcheat());
        this.flux.o.momgetthecamera().zerodayisaminecraftcheat((packetIn.zeroday().a().length() == 0) ? null : packetIn.zeroday());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S1EPacketRemoveEntityEffect packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        if (entity instanceof EntityLivingBase) {
            ((EntityLivingBase)entity).f(packetIn.zeroday());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S38PacketPlayerListItem packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        for (final S38PacketPlayerListItem.zeroday s38packetplayerlistitem$addplayerdata : packetIn.zerodayisaminecraftcheat()) {
            if (packetIn.zeroday() == S38PacketPlayerListItem.zerodayisaminecraftcheat.zues) {
                this.a.remove(s38packetplayerlistitem$addplayerdata.zerodayisaminecraftcheat().getId());
            }
            else {
                NetworkPlayerInfo networkplayerinfo = this.a.get(s38packetplayerlistitem$addplayerdata.zerodayisaminecraftcheat().getId());
                if (packetIn.zeroday() == S38PacketPlayerListItem.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
                    networkplayerinfo = new NetworkPlayerInfo(s38packetplayerlistitem$addplayerdata);
                    this.a.put(networkplayerinfo.zerodayisaminecraftcheat().getId(), networkplayerinfo);
                }
                if (networkplayerinfo == null) {
                    continue;
                }
                switch (flux()[packetIn.zeroday().ordinal()]) {
                    default: {
                        continue;
                    }
                    case 1: {
                        networkplayerinfo.zerodayisaminecraftcheat(s38packetplayerlistitem$addplayerdata.sigma());
                        networkplayerinfo.zerodayisaminecraftcheat(s38packetplayerlistitem$addplayerdata.zeroday());
                        continue;
                    }
                    case 2: {
                        networkplayerinfo.zerodayisaminecraftcheat(s38packetplayerlistitem$addplayerdata.sigma());
                        continue;
                    }
                    case 3: {
                        networkplayerinfo.zerodayisaminecraftcheat(s38packetplayerlistitem$addplayerdata.zeroday());
                        continue;
                    }
                    case 4: {
                        networkplayerinfo.zerodayisaminecraftcheat(s38packetplayerlistitem$addplayerdata.pandora());
                        continue;
                    }
                }
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S00PacketKeepAlive packetIn) {
        this.zerodayisaminecraftcheat(new C00PacketKeepAlive(packetIn.zerodayisaminecraftcheat()));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S39PacketPlayerAbilities packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final EntityPlayer entityplayer = this.flux.e;
        entityplayer.bz.zeroday = packetIn.zeroday();
        entityplayer.bz.pandora = packetIn.pandora();
        entityplayer.bz.zerodayisaminecraftcheat = packetIn.zerodayisaminecraftcheat();
        entityplayer.bz.sigma = packetIn.sigma();
        entityplayer.bz.zerodayisaminecraftcheat(packetIn.zues());
        entityplayer.bz.zeroday(packetIn.flux());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S3APacketTabComplete packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final String[] astring = packetIn.zerodayisaminecraftcheat();
        if (this.flux.k instanceof GuiChat) {
            final GuiChat guichat = (GuiChat)this.flux.k;
            guichat.zerodayisaminecraftcheat(astring);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S29PacketSoundEffect packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        this.flux.a.zerodayisaminecraftcheat(packetIn.zeroday(), packetIn.sigma(), packetIn.pandora(), packetIn.zerodayisaminecraftcheat(), packetIn.zues(), packetIn.flux(), false);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S48PacketResourcePackSend packetIn) {
        final String s = packetIn.zerodayisaminecraftcheat();
        final String s2 = packetIn.zeroday();
        if (s.startsWith("level://")) {
            final String s3 = s.substring("level://".length());
            final File file1 = new File(this.flux.t, "saves");
            final File file2 = new File(file1, s3);
            if (file2.isFile()) {
                this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.pandora));
                Futures.addCallback((ListenableFuture)this.flux.K().zerodayisaminecraftcheat(file2), (FutureCallback)new FutureCallback<Object>() {
                    public void onSuccess(final Object p_onSuccess_1_) {
                        NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.zerodayisaminecraftcheat));
                    }
                    
                    public void onFailure(final Throwable p_onFailure_1_) {
                        NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.sigma));
                    }
                });
            }
            else {
                this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.sigma));
            }
        }
        else if (this.flux.w() != null && this.flux.w().zeroday() == ServerData.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.pandora));
            Futures.addCallback((ListenableFuture)this.flux.K().zerodayisaminecraftcheat(s, s2), (FutureCallback)new FutureCallback<Object>() {
                public void onSuccess(final Object p_onSuccess_1_) {
                    NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.zerodayisaminecraftcheat));
                }
                
                public void onFailure(final Throwable p_onFailure_1_) {
                    NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.sigma));
                }
            });
        }
        else if (this.flux.w() != null && this.flux.w().zeroday() != ServerData.zerodayisaminecraftcheat.sigma) {
            this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.zeroday));
        }
        else {
            this.flux.zerodayisaminecraftcheat(new Runnable() {
                @Override
                public void run() {
                    NetHandlerPlayClient.this.flux.zerodayisaminecraftcheat(new GuiYesNo(new GuiYesNoCallback() {
                        @Override
                        public void zerodayisaminecraftcheat(final boolean result, final int id) {
                            NetHandlerPlayClient.zerodayisaminecraftcheat(NetHandlerPlayClient.this, Minecraft.s());
                            if (result) {
                                if (NetHandlerPlayClient.this.flux.w() != null) {
                                    NetHandlerPlayClient.this.flux.w().zerodayisaminecraftcheat(ServerData.zerodayisaminecraftcheat.zerodayisaminecraftcheat);
                                }
                                NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.pandora));
                                Futures.addCallback((ListenableFuture)NetHandlerPlayClient.this.flux.K().zerodayisaminecraftcheat(s, s2), (FutureCallback)new FutureCallback<Object>() {
                                    public void onSuccess(final Object p_onSuccess_1_) {
                                        NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.zerodayisaminecraftcheat));
                                    }
                                    
                                    public void onFailure(final Throwable p_onFailure_1_) {
                                        NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.sigma));
                                    }
                                });
                            }
                            else {
                                if (NetHandlerPlayClient.this.flux.w() != null) {
                                    NetHandlerPlayClient.this.flux.w().zerodayisaminecraftcheat(ServerData.zerodayisaminecraftcheat.zeroday);
                                }
                                NetHandlerPlayClient.this.sigma.zeroday(new C19PacketResourcePackStatus(s2, C19PacketResourcePackStatus.zerodayisaminecraftcheat.zeroday));
                            }
                            ServerList.zeroday(NetHandlerPlayClient.this.flux.w());
                            NetHandlerPlayClient.this.flux.zerodayisaminecraftcheat((GuiScreen)null);
                        }
                    }, I18n.zerodayisaminecraftcheat("multiplayer.texturePrompt.line1", new Object[0]), I18n.zerodayisaminecraftcheat("multiplayer.texturePrompt.line2", new Object[0]), 0));
                }
            });
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S49PacketUpdateEntityNBT packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = packetIn.zerodayisaminecraftcheat(this.vape);
        if (entity != null) {
            entity.vape(packetIn.zerodayisaminecraftcheat());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S3FPacketCustomPayload packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        Label_0234: {
            if ("MC|TrList".equals(packetIn.zerodayisaminecraftcheat())) {
                final PacketBuffer packetbuffer = packetIn.zeroday();
                try {
                    final int i = packetbuffer.readInt();
                    final GuiScreen guiscreen = this.flux.k;
                    if (guiscreen != null && guiscreen instanceof GuiMerchant && i == this.flux.e.f.pandora) {
                        final IMerchant imerchant = ((GuiMerchant)guiscreen).flux();
                        final MerchantRecipeList merchantrecipelist = MerchantRecipeList.zeroday(packetbuffer);
                        imerchant.zerodayisaminecraftcheat(merchantrecipelist);
                    }
                }
                catch (IOException ioexception) {
                    NetHandlerPlayClient.zeroday.error("Couldn't load trade info", (Throwable)ioexception);
                    break Label_0234;
                }
                finally {
                    packetbuffer.release();
                }
                packetbuffer.release();
            }
            else if ("MC|Brand".equals(packetIn.zerodayisaminecraftcheat())) {
                this.flux.e.sigma(packetIn.zeroday().sigma(32767));
            }
            else if ("MC|BOpen".equals(packetIn.zerodayisaminecraftcheat())) {
                final ItemStack itemstack = this.flux.e.aX();
                if (itemstack != null && itemstack.zerodayisaminecraftcheat() == Items.bF) {
                    this.flux.zerodayisaminecraftcheat(new GuiScreenBook(this.flux.e, itemstack, false));
                }
            }
        }
        pandora.b.zerodayisaminecraftcheat(this, packetIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S3BPacketScoreboardObjective packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Scoreboard scoreboard = this.vape.E();
        if (packetIn.sigma() == 0) {
            final ScoreObjective scoreobjective = scoreboard.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), IScoreObjectiveCriteria.zeroday);
            scoreobjective.zerodayisaminecraftcheat(packetIn.zeroday());
            scoreobjective.zerodayisaminecraftcheat(packetIn.pandora());
        }
        else {
            final ScoreObjective scoreobjective2 = scoreboard.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
            if (packetIn.sigma() == 1) {
                scoreboard.zeroday(scoreobjective2);
            }
            else if (packetIn.sigma() == 2) {
                scoreobjective2.zerodayisaminecraftcheat(packetIn.zeroday());
                scoreobjective2.zerodayisaminecraftcheat(packetIn.pandora());
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S3CPacketUpdateScore packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Scoreboard scoreboard = this.vape.E();
        final ScoreObjective scoreobjective = scoreboard.zerodayisaminecraftcheat(packetIn.zeroday());
        if (packetIn.pandora() == S3CPacketUpdateScore.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
            final Score score = scoreboard.zeroday(packetIn.zerodayisaminecraftcheat(), scoreobjective);
            score.sigma(packetIn.sigma());
        }
        else if (packetIn.pandora() == S3CPacketUpdateScore.zerodayisaminecraftcheat.zeroday) {
            if (StringUtils.zeroday(packetIn.zeroday())) {
                scoreboard.sigma(packetIn.zerodayisaminecraftcheat(), null);
            }
            else if (scoreobjective != null) {
                scoreboard.sigma(packetIn.zerodayisaminecraftcheat(), scoreobjective);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S3DPacketDisplayScoreboard packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Scoreboard scoreboard = this.vape.E();
        if (packetIn.zeroday().length() == 0) {
            scoreboard.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), null);
        }
        else {
            final ScoreObjective scoreobjective = scoreboard.zerodayisaminecraftcheat(packetIn.zeroday());
            scoreboard.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), scoreobjective);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S3EPacketTeams packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Scoreboard scoreboard = this.vape.E();
        ScorePlayerTeam scoreplayerteam;
        if (packetIn.flux() == 0) {
            scoreplayerteam = scoreboard.pandora(packetIn.zerodayisaminecraftcheat());
        }
        else {
            scoreplayerteam = scoreboard.sigma(packetIn.zerodayisaminecraftcheat());
        }
        if (packetIn.flux() == 0 || packetIn.flux() == 2) {
            scoreplayerteam.zerodayisaminecraftcheat(packetIn.zeroday());
            scoreplayerteam.zeroday(packetIn.sigma());
            scoreplayerteam.sigma(packetIn.pandora());
            scoreplayerteam.zerodayisaminecraftcheat(EnumChatFormatting.zerodayisaminecraftcheat(packetIn.momgetthecamera()));
            scoreplayerteam.zerodayisaminecraftcheat(packetIn.vape());
            final Team.zerodayisaminecraftcheat team$enumvisible = Team.zerodayisaminecraftcheat.zerodayisaminecraftcheat(packetIn.a());
            if (team$enumvisible != null) {
                scoreplayerteam.zerodayisaminecraftcheat(team$enumvisible);
            }
        }
        if (packetIn.flux() == 0 || packetIn.flux() == 3) {
            for (final String s : packetIn.zues()) {
                scoreboard.zerodayisaminecraftcheat(s, packetIn.zerodayisaminecraftcheat());
            }
        }
        if (packetIn.flux() == 4) {
            for (final String s2 : packetIn.zues()) {
                scoreboard.zerodayisaminecraftcheat(s2, scoreplayerteam);
            }
        }
        if (packetIn.flux() == 1) {
            scoreboard.zerodayisaminecraftcheat(scoreplayerteam);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S2APacketParticles packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        if (packetIn.b() == 0) {
            final double d0 = packetIn.a() * packetIn.flux();
            final double d2 = packetIn.a() * packetIn.vape();
            final double d3 = packetIn.a() * packetIn.momgetthecamera();
            try {
                this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), packetIn.zeroday(), packetIn.sigma(), packetIn.pandora(), packetIn.zues(), d0, d2, d3, packetIn.c());
            }
            catch (Throwable var17) {
                NetHandlerPlayClient.zeroday.warn("Could not spawn particle effect " + packetIn.zerodayisaminecraftcheat());
            }
        }
        else {
            for (int i = 0; i < packetIn.b(); ++i) {
                final double d4 = this.c.nextGaussian() * packetIn.flux();
                final double d5 = this.c.nextGaussian() * packetIn.vape();
                final double d6 = this.c.nextGaussian() * packetIn.momgetthecamera();
                final double d7 = this.c.nextGaussian() * packetIn.a();
                final double d8 = this.c.nextGaussian() * packetIn.a();
                final double d9 = this.c.nextGaussian() * packetIn.a();
                try {
                    this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat(), packetIn.zeroday(), packetIn.sigma() + d4, packetIn.pandora() + d5, packetIn.zues() + d6, d7, d8, d9, packetIn.c());
                }
                catch (Throwable var18) {
                    NetHandlerPlayClient.zeroday.warn("Could not spawn particle effect " + packetIn.zerodayisaminecraftcheat());
                    return;
                }
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final S20PacketEntityProperties packetIn) {
        PacketThreadUtil.zerodayisaminecraftcheat((Packet<NetHandlerPlayClient>)packetIn, this, this.flux);
        final Entity entity = this.vape.zerodayisaminecraftcheat(packetIn.zerodayisaminecraftcheat());
        if (entity != null) {
            if (!(entity instanceof EntityLivingBase)) {
                throw new IllegalStateException("Server tried to update attributes of a non-living entity (actually: " + entity + ")");
            }
            final BaseAttributeMap baseattributemap = ((EntityLivingBase)entity).bI();
            for (final S20PacketEntityProperties.zerodayisaminecraftcheat s20packetentityproperties$snapshot : packetIn.zeroday()) {
                IAttributeInstance iattributeinstance = baseattributemap.zerodayisaminecraftcheat(s20packetentityproperties$snapshot.zerodayisaminecraftcheat());
                if (iattributeinstance == null) {
                    iattributeinstance = baseattributemap.zeroday(new RangedAttribute(null, s20packetentityproperties$snapshot.zerodayisaminecraftcheat(), 0.0, Double.MIN_NORMAL, Double.MAX_VALUE));
                }
                iattributeinstance.zerodayisaminecraftcheat(s20packetentityproperties$snapshot.zeroday());
                iattributeinstance.pandora();
                for (final AttributeModifier attributemodifier : s20packetentityproperties$snapshot.sigma()) {
                    iattributeinstance.zeroday(attributemodifier);
                }
            }
        }
    }
    
    public NetworkManager zeroday() {
        return this.sigma;
    }
    
    public Collection<NetworkPlayerInfo> sigma() {
        return this.a.values();
    }
    
    public NetworkPlayerInfo zerodayisaminecraftcheat(final UUID p_175102_1_) {
        return this.a.get(p_175102_1_);
    }
    
    public NetworkPlayerInfo zerodayisaminecraftcheat(final String p_175104_1_) {
        for (final NetworkPlayerInfo networkplayerinfo : this.a.values()) {
            if (networkplayerinfo.zerodayisaminecraftcheat().getName().equals(p_175104_1_)) {
                return networkplayerinfo;
            }
        }
        return null;
    }
    
    public GameProfile pandora() {
        return this.pandora;
    }
    
    static /* synthetic */ int[] zues() {
        final int[] d = NetHandlerPlayClient.d;
        if (d != null) {
            return d;
        }
        final int[] d2 = new int[S45PacketTitle.zerodayisaminecraftcheat.values().length];
        try {
            d2[S45PacketTitle.zerodayisaminecraftcheat.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            d2[S45PacketTitle.zerodayisaminecraftcheat.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            d2[S45PacketTitle.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            d2[S45PacketTitle.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            d2[S45PacketTitle.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        return NetHandlerPlayClient.d = d2;
    }
    
    static /* synthetic */ int[] flux() {
        final int[] e = NetHandlerPlayClient.e;
        if (e != null) {
            return e;
        }
        final int[] e2 = new int[S38PacketPlayerListItem.zerodayisaminecraftcheat.values().length];
        try {
            e2[S38PacketPlayerListItem.zerodayisaminecraftcheat.zerodayisaminecraftcheat.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            e2[S38PacketPlayerListItem.zerodayisaminecraftcheat.zues.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            e2[S38PacketPlayerListItem.zerodayisaminecraftcheat.pandora.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            e2[S38PacketPlayerListItem.zerodayisaminecraftcheat.zeroday.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            e2[S38PacketPlayerListItem.zerodayisaminecraftcheat.sigma.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        return NetHandlerPlayClient.e = e2;
    }
    
    static /* synthetic */ void zerodayisaminecraftcheat(final NetHandlerPlayClient netHandlerPlayClient, final Minecraft flux) {
        netHandlerPlayClient.flux = flux;
    }
}

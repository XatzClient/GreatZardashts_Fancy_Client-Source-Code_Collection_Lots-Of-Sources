// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.flux;

import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.client.b.SkinManager;
import net.minecraft.client.Minecraft;
import net.minecraft.j.ScorePlayerTeam;
import com.google.common.base.Objects;
import net.minecraft.client.b.DefaultPlayerSkin;
import net.minecraft.e.sigma.zeroday.S38PacketPlayerListItem;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.ResourceLocation;
import net.minecraft.q.WorldSettings;
import com.mojang.authlib.GameProfile;

public class NetworkPlayerInfo
{
    private final GameProfile zerodayisaminecraftcheat;
    private WorldSettings.zerodayisaminecraftcheat zeroday;
    private int sigma;
    private boolean pandora;
    private ResourceLocation zues;
    private ResourceLocation flux;
    private String vape;
    private IChatComponent momgetthecamera;
    private IChatComponent a;
    private int b;
    private int c;
    private long d;
    private long e;
    private long f;
    
    public NetworkPlayerInfo(final GameProfile p_i46294_1_) {
        this.pandora = false;
        this.b = 0;
        this.c = 0;
        this.d = 0L;
        this.e = 0L;
        this.f = 0L;
        this.zerodayisaminecraftcheat = p_i46294_1_;
    }
    
    public NetworkPlayerInfo(final S38PacketPlayerListItem.zeroday p_i46295_1_) {
        this.pandora = false;
        this.b = 0;
        this.c = 0;
        this.d = 0L;
        this.e = 0L;
        this.f = 0L;
        this.zerodayisaminecraftcheat = p_i46295_1_.zerodayisaminecraftcheat();
        this.zeroday = p_i46295_1_.sigma();
        this.sigma = p_i46295_1_.zeroday();
        this.momgetthecamera = p_i46295_1_.pandora();
    }
    
    public GameProfile zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat;
    }
    
    public WorldSettings.zerodayisaminecraftcheat zeroday() {
        return this.zeroday;
    }
    
    public int sigma() {
        return this.sigma;
    }
    
    protected void zerodayisaminecraftcheat(final WorldSettings.zerodayisaminecraftcheat p_178839_1_) {
        this.zeroday = p_178839_1_;
    }
    
    protected void zerodayisaminecraftcheat(final int p_178838_1_) {
        this.sigma = p_178838_1_;
    }
    
    public boolean pandora() {
        return this.zues != null;
    }
    
    public String zues() {
        return (this.vape == null) ? DefaultPlayerSkin.zeroday(this.zerodayisaminecraftcheat.getId()) : this.vape;
    }
    
    public ResourceLocation flux() {
        if (this.zues == null) {
            this.a();
        }
        return (ResourceLocation)Objects.firstNonNull((Object)this.zues, (Object)DefaultPlayerSkin.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.getId()));
    }
    
    public ResourceLocation vape() {
        if (this.flux == null) {
            this.a();
        }
        return this.flux;
    }
    
    public ScorePlayerTeam momgetthecamera() {
        return Minecraft.s().a.E().flux(this.zerodayisaminecraftcheat().getName());
    }
    
    protected void a() {
        synchronized (this) {
            if (!this.pandora) {
                this.pandora = true;
                Minecraft.s().U().zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, new SkinManager.zerodayisaminecraftcheat() {
                    private static /* synthetic */ int[] zeroday;
                    
                    @Override
                    public void zerodayisaminecraftcheat(final MinecraftProfileTexture.Type p_180521_1_, final ResourceLocation location, final MinecraftProfileTexture profileTexture) {
                        switch (zerodayisaminecraftcheat()[p_180521_1_.ordinal()]) {
                            case 1: {
                                NetworkPlayerInfo.zerodayisaminecraftcheat(NetworkPlayerInfo.this, location);
                                NetworkPlayerInfo.zerodayisaminecraftcheat(NetworkPlayerInfo.this, profileTexture.getMetadata("model"));
                                if (NetworkPlayerInfo.this.vape == null) {
                                    NetworkPlayerInfo.zerodayisaminecraftcheat(NetworkPlayerInfo.this, "default");
                                    break;
                                }
                                break;
                            }
                            case 2: {
                                NetworkPlayerInfo.zeroday(NetworkPlayerInfo.this, location);
                                break;
                            }
                        }
                    }
                    
                    static /* synthetic */ int[] zerodayisaminecraftcheat() {
                        final int[] zeroday = NetworkPlayerInfo$1.zeroday;
                        if (zeroday != null) {
                            return zeroday;
                        }
                        final int[] zeroday2 = new int[MinecraftProfileTexture.Type.values().length];
                        try {
                            zeroday2[MinecraftProfileTexture.Type.CAPE.ordinal()] = 2;
                        }
                        catch (NoSuchFieldError noSuchFieldError) {}
                        try {
                            zeroday2[MinecraftProfileTexture.Type.SKIN.ordinal()] = 1;
                        }
                        catch (NoSuchFieldError noSuchFieldError2) {}
                        return NetworkPlayerInfo$1.zeroday = zeroday2;
                    }
                }, true);
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final IChatComponent displayNameIn) {
        this.momgetthecamera = displayNameIn;
    }
    
    public IChatComponent b() {
        return this.momgetthecamera;
    }
    
    public int c() {
        return this.b;
    }
    
    public void zeroday(final int p_178836_1_) {
        this.b = p_178836_1_;
    }
    
    public int d() {
        return this.c;
    }
    
    public void sigma(final int p_178857_1_) {
        this.c = p_178857_1_;
    }
    
    public long e() {
        return this.d;
    }
    
    public void zerodayisaminecraftcheat(final long p_178846_1_) {
        this.d = p_178846_1_;
    }
    
    public long f() {
        return this.e;
    }
    
    public void zeroday(final long p_178844_1_) {
        this.e = p_178844_1_;
    }
    
    public void zeroday(final IChatComponent p_178859_1_) {
        this.a = p_178859_1_;
    }
    
    public IChatComponent g() {
        return this.a;
    }
    
    public String h() {
        return (this.g() != null) ? this.g().a() : this.zerodayisaminecraftcheat().getName();
    }
    
    public long i() {
        return this.f;
    }
    
    public void sigma(final long p_178843_1_) {
        this.f = p_178843_1_;
    }
    
    static /* synthetic */ void zerodayisaminecraftcheat(final NetworkPlayerInfo networkPlayerInfo, final ResourceLocation zues) {
        networkPlayerInfo.zues = zues;
    }
    
    static /* synthetic */ void zerodayisaminecraftcheat(final NetworkPlayerInfo networkPlayerInfo, final String vape) {
        networkPlayerInfo.vape = vape;
    }
    
    static /* synthetic */ void zeroday(final NetworkPlayerInfo networkPlayerInfo, final ResourceLocation flux) {
        networkPlayerInfo.flux = flux;
    }
}

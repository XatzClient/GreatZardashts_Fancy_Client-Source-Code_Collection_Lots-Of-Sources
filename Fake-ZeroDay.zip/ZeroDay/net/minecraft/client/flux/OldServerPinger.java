// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.flux;

import java.util.Iterator;
import io.netty.channel.socket.nio.NioSocketChannel;
import net.minecraft.o.MathHelper;
import com.google.common.collect.Iterables;
import com.google.common.base.Charsets;
import io.netty.util.concurrent.GenericFutureListener;
import io.netty.channel.ChannelFutureListener;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.buffer.ByteBuf;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelOption;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.bootstrap.Bootstrap;
import java.net.UnknownHostException;
import net.minecraft.e.zues.zerodayisaminecraftcheat.C00PacketServerQuery;
import net.minecraft.e.zerodayisaminecraftcheat.zerodayisaminecraftcheat.C00Handshake;
import net.minecraft.e.EnumConnectionState;
import net.minecraft.e.INetHandler;
import net.minecraft.e.zues.zeroday.S01PacketPong;
import com.mojang.authlib.GameProfile;
import net.minecraft.e.ServerStatusResponse;
import net.minecraft.e.Packet;
import net.minecraft.e.zues.zerodayisaminecraftcheat.C01PacketPing;
import net.minecraft.client.Minecraft;
import org.apache.commons.lang3.ArrayUtils;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.ChatComponentText;
import net.minecraft.e.zues.zeroday.S00PacketServerInfo;
import net.minecraft.e.zues.INetHandlerStatusClient;
import java.net.InetAddress;
import net.minecraft.client.zues.ServerAddress;
import net.minecraft.client.zues.ServerData;
import java.util.Collections;
import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import net.minecraft.e.NetworkManager;
import java.util.List;
import org.apache.logging.log4j.Logger;
import com.google.common.base.Splitter;

public class OldServerPinger
{
    private static final Splitter zerodayisaminecraftcheat;
    private static final Logger zeroday;
    private final List<NetworkManager> sigma;
    
    static {
        zerodayisaminecraftcheat = Splitter.on('\0').limit(6);
        zeroday = LogManager.getLogger();
    }
    
    public OldServerPinger() {
        this.sigma = Collections.synchronizedList((List<NetworkManager>)Lists.newArrayList());
    }
    
    public void zerodayisaminecraftcheat(final ServerData server) throws UnknownHostException {
        final ServerAddress serveraddress = ServerAddress.zerodayisaminecraftcheat(server.zeroday);
        final NetworkManager networkmanager = NetworkManager.zerodayisaminecraftcheat(InetAddress.getByName(serveraddress.zerodayisaminecraftcheat()), serveraddress.zeroday(), false);
        this.sigma.add(networkmanager);
        server.flux = "Pinging...";
        server.vape = -1L;
        server.c = null;
        networkmanager.zerodayisaminecraftcheat(new INetHandlerStatusClient() {
            private boolean zeroday = false;
            private boolean sigma = false;
            private long pandora = 0L;
            
            @Override
            public void zerodayisaminecraftcheat(final S00PacketServerInfo packetIn) {
                if (this.sigma) {
                    networkmanager.zerodayisaminecraftcheat(new ChatComponentText("Received unrequested status"));
                }
                else {
                    this.sigma = true;
                    final ServerStatusResponse serverstatusresponse = packetIn.zerodayisaminecraftcheat();
                    if (serverstatusresponse.zerodayisaminecraftcheat() != null) {
                        server.flux = serverstatusresponse.zerodayisaminecraftcheat().a();
                    }
                    else {
                        server.flux = "";
                    }
                    if (serverstatusresponse.sigma() != null) {
                        server.a = serverstatusresponse.sigma().zerodayisaminecraftcheat();
                        server.momgetthecamera = serverstatusresponse.sigma().zeroday();
                    }
                    else {
                        server.a = "Old";
                        server.momgetthecamera = 0;
                    }
                    if (serverstatusresponse.zeroday() != null) {
                        server.sigma = new StringBuilder().append(EnumChatFormatting.momgetthecamera).append(serverstatusresponse.zeroday().zeroday()).append(EnumChatFormatting.a).append("/").append(EnumChatFormatting.momgetthecamera).append(serverstatusresponse.zeroday().zerodayisaminecraftcheat()).toString();
                        if (ArrayUtils.isNotEmpty((Object[])serverstatusresponse.zeroday().sigma())) {
                            final StringBuilder stringbuilder = new StringBuilder();
                            GameProfile[] sigma;
                            for (int length = (sigma = serverstatusresponse.zeroday().sigma()).length, i = 0; i < length; ++i) {
                                final GameProfile gameprofile = sigma[i];
                                if (stringbuilder.length() > 0) {
                                    stringbuilder.append("\n");
                                }
                                stringbuilder.append(gameprofile.getName());
                            }
                            if (serverstatusresponse.zeroday().sigma().length < serverstatusresponse.zeroday().zeroday()) {
                                if (stringbuilder.length() > 0) {
                                    stringbuilder.append("\n");
                                }
                                stringbuilder.append("... and ").append(serverstatusresponse.zeroday().zeroday() - serverstatusresponse.zeroday().sigma().length).append(" more ...");
                            }
                            server.c = stringbuilder.toString();
                        }
                    }
                    else {
                        server.sigma = EnumChatFormatting.a + "???";
                    }
                    if (serverstatusresponse.pandora() != null) {
                        final String s = serverstatusresponse.pandora();
                        if (s.startsWith("data:image/png;base64,")) {
                            server.zerodayisaminecraftcheat(s.substring("data:image/png;base64,".length()));
                        }
                        else {
                            OldServerPinger.zeroday.error("Invalid server icon (unknown format)");
                        }
                    }
                    else {
                        server.zerodayisaminecraftcheat((String)null);
                    }
                    this.pandora = Minecraft.C();
                    networkmanager.zeroday(new C01PacketPing(this.pandora));
                    this.zeroday = true;
                }
            }
            
            @Override
            public void zerodayisaminecraftcheat(final S01PacketPong packetIn) {
                final long i = this.pandora;
                final long j = Minecraft.C();
                server.vape = j - i;
                networkmanager.zerodayisaminecraftcheat(new ChatComponentText("Finished"));
            }
            
            @Override
            public void zerodayisaminecraftcheat(final IChatComponent reason) {
                if (!this.zeroday) {
                    OldServerPinger.zeroday.error("Can't ping " + server.zeroday + ": " + reason.momgetthecamera());
                    server.flux = EnumChatFormatting.zues + "Can't connect to server.";
                    server.sigma = "";
                    OldServerPinger.this.zeroday(server);
                }
            }
        });
        try {
            networkmanager.zeroday(new C00Handshake(47, serveraddress.zerodayisaminecraftcheat(), serveraddress.zeroday(), EnumConnectionState.sigma));
            networkmanager.zeroday(new C00PacketServerQuery());
        }
        catch (Throwable throwable) {
            OldServerPinger.zeroday.error((Object)throwable);
        }
    }
    
    private void zeroday(final ServerData server) {
        final ServerAddress serveraddress = ServerAddress.zerodayisaminecraftcheat(server.zeroday);
        ((Bootstrap)((Bootstrap)((Bootstrap)new Bootstrap().group((EventLoopGroup)NetworkManager.pandora.sigma())).handler((ChannelHandler)new ChannelInitializer<Channel>() {
            protected void initChannel(final Channel p_initChannel_1_) throws Exception {
                try {
                    p_initChannel_1_.config().setOption(ChannelOption.TCP_NODELAY, (Object)true);
                }
                catch (ChannelException ex) {}
                p_initChannel_1_.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new SimpleChannelInboundHandler<ByteBuf>() {
                        public void channelActive(final ChannelHandlerContext p_channelActive_1_) throws Exception {
                            super.channelActive(p_channelActive_1_);
                            final ByteBuf bytebuf = Unpooled.buffer();
                            try {
                                bytebuf.writeByte(254);
                                bytebuf.writeByte(1);
                                bytebuf.writeByte(250);
                                char[] achar = "MC|PingHost".toCharArray();
                                bytebuf.writeShort(achar.length);
                                char[] array;
                                for (int length = (array = achar).length, i = 0; i < length; ++i) {
                                    final char c0 = array[i];
                                    bytebuf.writeChar((int)c0);
                                }
                                bytebuf.writeShort(7 + 2 * serveraddress.zerodayisaminecraftcheat().length());
                                bytebuf.writeByte(127);
                                achar = serveraddress.zerodayisaminecraftcheat().toCharArray();
                                bytebuf.writeShort(achar.length);
                                char[] array2;
                                for (int length2 = (array2 = achar).length, j = 0; j < length2; ++j) {
                                    final char c2 = array2[j];
                                    bytebuf.writeChar((int)c2);
                                }
                                bytebuf.writeInt(serveraddress.zeroday());
                                p_channelActive_1_.channel().writeAndFlush((Object)bytebuf).addListener((GenericFutureListener)ChannelFutureListener.CLOSE_ON_FAILURE);
                            }
                            finally {
                                bytebuf.release();
                            }
                            bytebuf.release();
                        }
                        
                        protected void zerodayisaminecraftcheat(final ChannelHandlerContext p_channelRead0_1_, final ByteBuf p_channelRead0_2_) throws Exception {
                            final short short1 = p_channelRead0_2_.readUnsignedByte();
                            if (short1 == 255) {
                                final String s = new String(p_channelRead0_2_.readBytes(p_channelRead0_2_.readShort() * 2).array(), Charsets.UTF_16BE);
                                final String[] astring = (String[])Iterables.toArray(OldServerPinger.zerodayisaminecraftcheat.split((CharSequence)s), (Class)String.class);
                                if ("�1".equals(astring[0])) {
                                    final int i = MathHelper.zerodayisaminecraftcheat(astring[1], 0);
                                    final String s2 = astring[2];
                                    final String s3 = astring[3];
                                    final int j = MathHelper.zerodayisaminecraftcheat(astring[4], -1);
                                    final int k = MathHelper.zerodayisaminecraftcheat(astring[5], -1);
                                    server.momgetthecamera = -1;
                                    server.a = s2;
                                    server.flux = s3;
                                    server.sigma = new StringBuilder().append(EnumChatFormatting.momgetthecamera).append(j).append(EnumChatFormatting.a).append("/").append(EnumChatFormatting.momgetthecamera).append(k).toString();
                                }
                            }
                            p_channelRead0_1_.close();
                        }
                        
                        public void exceptionCaught(final ChannelHandlerContext p_exceptionCaught_1_, final Throwable p_exceptionCaught_2_) throws Exception {
                            p_exceptionCaught_1_.close();
                        }
                    } });
            }
        })).channel((Class)NioSocketChannel.class)).connect(serveraddress.zerodayisaminecraftcheat(), serveraddress.zeroday());
    }
    
    public void zerodayisaminecraftcheat() {
        synchronized (this.sigma) {
            final Iterator<NetworkManager> iterator = this.sigma.iterator();
            while (iterator.hasNext()) {
                final NetworkManager networkmanager = iterator.next();
                if (networkmanager.zues()) {
                    networkmanager.zerodayisaminecraftcheat();
                }
                else {
                    iterator.remove();
                    networkmanager.b();
                }
            }
        }
        // monitorexit(this.sigma)
    }
    
    public void zeroday() {
        synchronized (this.sigma) {
            final Iterator<NetworkManager> iterator = this.sigma.iterator();
            while (iterator.hasNext()) {
                final NetworkManager networkmanager = iterator.next();
                if (networkmanager.zues()) {
                    iterator.remove();
                    networkmanager.zerodayisaminecraftcheat(new ChatComponentText("Cancelled"));
                }
            }
        }
        // monitorexit(this.sigma)
    }
}

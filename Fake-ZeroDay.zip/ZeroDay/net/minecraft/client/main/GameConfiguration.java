// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.main;

import java.net.Proxy;
import com.mojang.authlib.properties.PropertyMap;
import net.minecraft.o.Session;
import java.io.File;

public class GameConfiguration
{
    public final zues zerodayisaminecraftcheat;
    public final zerodayisaminecraftcheat zeroday;
    public final zeroday sigma;
    public final sigma pandora;
    public final pandora zues;
    
    public GameConfiguration(final zues userInfoIn, final zerodayisaminecraftcheat displayInfoIn, final zeroday folderInfoIn, final sigma gameInfoIn, final pandora serverInfoIn) {
        this.zerodayisaminecraftcheat = userInfoIn;
        this.zeroday = displayInfoIn;
        this.sigma = folderInfoIn;
        this.pandora = gameInfoIn;
        this.zues = serverInfoIn;
    }
    
    public static class zerodayisaminecraftcheat
    {
        public final int zerodayisaminecraftcheat;
        public final int zeroday;
        public final boolean sigma;
        public final boolean pandora;
        
        public zerodayisaminecraftcheat(final int widthIn, final int heightIn, final boolean fullscreenIn, final boolean checkGlErrorsIn) {
            this.zerodayisaminecraftcheat = widthIn;
            this.zeroday = heightIn;
            this.sigma = fullscreenIn;
            this.pandora = checkGlErrorsIn;
        }
    }
    
    public static class zeroday
    {
        public final File zerodayisaminecraftcheat;
        public final File zeroday;
        public final File sigma;
        public final String pandora;
        
        public zeroday(final File mcDataDirIn, final File resourcePacksDirIn, final File assetsDirIn, final String assetIndexIn) {
            this.zerodayisaminecraftcheat = mcDataDirIn;
            this.zeroday = resourcePacksDirIn;
            this.sigma = assetsDirIn;
            this.pandora = assetIndexIn;
        }
    }
    
    public static class sigma
    {
        public final boolean zerodayisaminecraftcheat;
        public final String zeroday;
        
        public sigma(final boolean isDemoIn, final String versionIn) {
            this.zerodayisaminecraftcheat = isDemoIn;
            this.zeroday = versionIn;
        }
    }
    
    public static class pandora
    {
        public final String zerodayisaminecraftcheat;
        public final int zeroday;
        
        public pandora(final String serverNameIn, final int serverPortIn) {
            this.zerodayisaminecraftcheat = serverNameIn;
            this.zeroday = serverPortIn;
        }
    }
    
    public static class zues
    {
        public final Session zerodayisaminecraftcheat;
        public final PropertyMap zeroday;
        public final PropertyMap sigma;
        public final Proxy pandora;
        
        public zues(final Session p_i46375_1_, final PropertyMap p_i46375_2_, final PropertyMap p_i46375_3_, final Proxy p_i46375_4_) {
            this.zerodayisaminecraftcheat = p_i46375_1_;
            this.zeroday = p_i46375_2_;
            this.sigma = p_i46375_3_;
            this.pandora = p_i46375_4_;
        }
    }
}

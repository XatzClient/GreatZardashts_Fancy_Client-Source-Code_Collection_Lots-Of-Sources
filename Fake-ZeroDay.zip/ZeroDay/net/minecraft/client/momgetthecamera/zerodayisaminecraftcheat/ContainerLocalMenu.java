// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.momgetthecamera.zerodayisaminecraftcheat;

import net.minecraft.b.Container;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.q.LockCode;
import com.google.common.collect.Maps;
import net.minecraft.o.IChatComponent;
import java.util.Map;
import net.minecraft.q.ILockableContainer;
import net.minecraft.b.InventoryBasic;

public class ContainerLocalMenu extends InventoryBasic implements ILockableContainer
{
    private String zerodayisaminecraftcheat;
    private Map<Integer, Integer> zeroday;
    
    public ContainerLocalMenu(final String id, final IChatComponent title, final int slotCount) {
        super(title, slotCount);
        this.zeroday = (Map<Integer, Integer>)Maps.newHashMap();
        this.zerodayisaminecraftcheat = id;
    }
    
    @Override
    public int zerodayisaminecraftcheat(final int id) {
        return this.zeroday.containsKey(id) ? this.zeroday.get(id) : 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final int value) {
        this.zeroday.put(id, value);
    }
    
    @Override
    public int C_() {
        return this.zeroday.size();
    }
    
    @Override
    public boolean flux() {
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final LockCode code) {
    }
    
    @Override
    public LockCode vape() {
        return LockCode.zerodayisaminecraftcheat;
    }
    
    @Override
    public String pandora() {
        return this.zerodayisaminecraftcheat;
    }
    
    @Override
    public Container zerodayisaminecraftcheat(final InventoryPlayer playerInventory, final EntityPlayer playerIn) {
        throw new UnsupportedOperationException();
    }
}

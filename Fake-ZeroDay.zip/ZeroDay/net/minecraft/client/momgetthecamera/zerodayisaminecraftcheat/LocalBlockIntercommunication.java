// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.momgetthecamera.zerodayisaminecraftcheat;

import net.minecraft.b.Container;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.o.IChatComponent;
import net.minecraft.q.IInteractionObject;

public class LocalBlockIntercommunication implements IInteractionObject
{
    private String zerodayisaminecraftcheat;
    private IChatComponent zeroday;
    
    public LocalBlockIntercommunication(final String guiIdIn, final IChatComponent displayNameIn) {
        this.zerodayisaminecraftcheat = guiIdIn;
        this.zeroday = displayNameIn;
    }
    
    @Override
    public Container zerodayisaminecraftcheat(final InventoryPlayer playerInventory, final EntityPlayer playerIn) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public String l_() {
        return this.zeroday.momgetthecamera();
    }
    
    @Override
    public boolean p_() {
        return true;
    }
    
    @Override
    public String pandora() {
        return this.zerodayisaminecraftcheat;
    }
    
    @Override
    public IChatComponent sigma() {
        return this.zeroday;
    }
}

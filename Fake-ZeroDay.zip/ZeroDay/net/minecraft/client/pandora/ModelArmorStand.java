// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.pandora.EntityArmorStand;
import net.minecraft.vape.Entity;

public class ModelArmorStand extends ModelArmorStandArmor
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    
    public ModelArmorStand() {
        this(0.0f);
    }
    
    public ModelArmorStand(final float p_i46306_1_) {
        super(p_i46306_1_, 64, 64);
        (this.c = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-1.0f, -7.0f, -1.0f, 2, 7, 2, p_i46306_1_);
        this.c.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
        (this.e = new ModelRenderer(this, 0, 26)).zerodayisaminecraftcheat(-6.0f, 0.0f, -1.5f, 12, 3, 3, p_i46306_1_);
        this.e.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
        (this.f = new ModelRenderer(this, 24, 0)).zerodayisaminecraftcheat(-2.0f, -2.0f, -1.0f, 2, 12, 2, p_i46306_1_);
        this.f.zerodayisaminecraftcheat(-5.0f, 2.0f, 0.0f);
        this.g = new ModelRenderer(this, 32, 16);
        this.g.a = true;
        this.g.zerodayisaminecraftcheat(0.0f, -2.0f, -1.0f, 2, 12, 2, p_i46306_1_);
        this.g.zerodayisaminecraftcheat(5.0f, 2.0f, 0.0f);
        (this.h = new ModelRenderer(this, 8, 0)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 11, 2, p_i46306_1_);
        this.h.zerodayisaminecraftcheat(-1.9f, 12.0f, 0.0f);
        this.i = new ModelRenderer(this, 40, 16);
        this.i.a = true;
        this.i.zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 11, 2, p_i46306_1_);
        this.i.zerodayisaminecraftcheat(1.9f, 12.0f, 0.0f);
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 16, 0)).zerodayisaminecraftcheat(-3.0f, 3.0f, -1.0f, 2, 7, 2, p_i46306_1_);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
        this.zerodayisaminecraftcheat.b = true;
        (this.zeroday = new ModelRenderer(this, 48, 16)).zerodayisaminecraftcheat(1.0f, 3.0f, -1.0f, 2, 7, 2, p_i46306_1_);
        this.zeroday.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
        (this.sigma = new ModelRenderer(this, 0, 48)).zerodayisaminecraftcheat(-4.0f, 10.0f, -1.0f, 8, 2, 2, p_i46306_1_);
        this.sigma.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
        (this.pandora = new ModelRenderer(this, 0, 32)).zerodayisaminecraftcheat(-6.0f, 11.0f, -6.0f, 12, 1, 12, p_i46306_1_);
        this.pandora.zerodayisaminecraftcheat(0.0f, 12.0f, 0.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        if (entityIn instanceof EntityArmorStand) {
            final EntityArmorStand entityarmorstand = (EntityArmorStand)entityIn;
            this.g.b = entityarmorstand.j();
            this.f.b = entityarmorstand.j();
            this.pandora.b = !entityarmorstand.k();
            this.i.zerodayisaminecraftcheat(1.9f, 12.0f, 0.0f);
            this.h.zerodayisaminecraftcheat(-1.9f, 12.0f, 0.0f);
            this.zerodayisaminecraftcheat.flux = 0.017453292f * entityarmorstand.n().zeroday();
            this.zerodayisaminecraftcheat.vape = 0.017453292f * entityarmorstand.n().sigma();
            this.zerodayisaminecraftcheat.momgetthecamera = 0.017453292f * entityarmorstand.n().pandora();
            this.zeroday.flux = 0.017453292f * entityarmorstand.n().zeroday();
            this.zeroday.vape = 0.017453292f * entityarmorstand.n().sigma();
            this.zeroday.momgetthecamera = 0.017453292f * entityarmorstand.n().pandora();
            this.sigma.flux = 0.017453292f * entityarmorstand.n().zeroday();
            this.sigma.vape = 0.017453292f * entityarmorstand.n().sigma();
            this.sigma.momgetthecamera = 0.017453292f * entityarmorstand.n().pandora();
            final float f = (entityarmorstand.r().zeroday() + entityarmorstand.s().zeroday()) / 2.0f;
            final float f2 = (entityarmorstand.r().sigma() + entityarmorstand.s().sigma()) / 2.0f;
            final float f3 = (entityarmorstand.r().pandora() + entityarmorstand.s().pandora()) / 2.0f;
            this.pandora.flux = 0.0f;
            this.pandora.vape = 0.017453292f * -entityIn.y;
            this.pandora.momgetthecamera = 0.0f;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        super.zerodayisaminecraftcheat(entityIn, p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale);
        GlStateManager.v();
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
        }
        else {
            if (entityIn.y()) {
                GlStateManager.zeroday(0.0f, 0.2f, 0.0f);
            }
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
        }
        GlStateManager.w();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float scale) {
        final boolean flag = this.f.b;
        this.f.b = true;
        super.zerodayisaminecraftcheat(scale);
        this.f.b = flag;
    }
}

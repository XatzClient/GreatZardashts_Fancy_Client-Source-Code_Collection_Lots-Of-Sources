// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.pandora.EntityArmorStand;
import net.minecraft.vape.Entity;

public class ModelArmorStandArmor extends ModelBiped
{
    public ModelArmorStandArmor() {
        this(0.0f);
    }
    
    public ModelArmorStandArmor(final float modelSize) {
        this(modelSize, 64, 32);
    }
    
    protected ModelArmorStandArmor(final float modelSize, final int textureWidthIn, final int textureHeightIn) {
        super(modelSize, 0.0f, textureWidthIn, textureHeightIn);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        if (entityIn instanceof EntityArmorStand) {
            final EntityArmorStand entityarmorstand = (EntityArmorStand)entityIn;
            this.c.flux = 0.017453292f * entityarmorstand.m().zeroday();
            this.c.vape = 0.017453292f * entityarmorstand.m().sigma();
            this.c.momgetthecamera = 0.017453292f * entityarmorstand.m().pandora();
            this.c.zerodayisaminecraftcheat(0.0f, 1.0f, 0.0f);
            this.e.flux = 0.017453292f * entityarmorstand.n().zeroday();
            this.e.vape = 0.017453292f * entityarmorstand.n().sigma();
            this.e.momgetthecamera = 0.017453292f * entityarmorstand.n().pandora();
            this.g.flux = 0.017453292f * entityarmorstand.o().zeroday();
            this.g.vape = 0.017453292f * entityarmorstand.o().sigma();
            this.g.momgetthecamera = 0.017453292f * entityarmorstand.o().pandora();
            this.f.flux = 0.017453292f * entityarmorstand.p().zeroday();
            this.f.vape = 0.017453292f * entityarmorstand.p().sigma();
            this.f.momgetthecamera = 0.017453292f * entityarmorstand.p().pandora();
            this.i.flux = 0.017453292f * entityarmorstand.r().zeroday();
            this.i.vape = 0.017453292f * entityarmorstand.r().sigma();
            this.i.momgetthecamera = 0.017453292f * entityarmorstand.r().pandora();
            this.i.zerodayisaminecraftcheat(1.9f, 11.0f, 0.0f);
            this.h.flux = 0.017453292f * entityarmorstand.s().zeroday();
            this.h.vape = 0.017453292f * entityarmorstand.s().sigma();
            this.h.momgetthecamera = 0.017453292f * entityarmorstand.s().pandora();
            this.h.zerodayisaminecraftcheat(-1.9f, 11.0f, 0.0f);
            ModelBase.zerodayisaminecraftcheat(this.c, this.d);
        }
    }
}

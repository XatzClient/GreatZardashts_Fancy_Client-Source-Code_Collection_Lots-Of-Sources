// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

public class ModelBanner extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    
    public ModelBanner() {
        this.a = 64;
        this.b = 64;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-10.0f, 0.0f, -2.0f, 20, 40, 1, 0.0f);
        (this.zeroday = new ModelRenderer(this, 44, 0)).zerodayisaminecraftcheat(-1.0f, -30.0f, -1.0f, 2, 42, 2, 0.0f);
        (this.sigma = new ModelRenderer(this, 0, 42)).zerodayisaminecraftcheat(-10.0f, -32.0f, -1.0f, 20, 2, 2, 0.0f);
    }
    
    public void zerodayisaminecraftcheat() {
        this.zerodayisaminecraftcheat.pandora = -32.0f;
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0625f);
        this.zeroday.zerodayisaminecraftcheat(0.0625f);
        this.sigma.zerodayisaminecraftcheat(0.0625f);
    }
}

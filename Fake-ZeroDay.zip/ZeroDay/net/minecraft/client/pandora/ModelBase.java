// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import java.util.Random;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;
import com.google.common.collect.Maps;
import com.google.common.collect.Lists;
import java.util.Map;
import java.util.List;

public abstract class ModelBase
{
    public float zues;
    public boolean flux;
    public boolean vape;
    public List<ModelRenderer> momgetthecamera;
    private Map<String, TextureOffset> zerodayisaminecraftcheat;
    public int a;
    public int b;
    
    public ModelBase() {
        this.vape = true;
        this.momgetthecamera = (List<ModelRenderer>)Lists.newArrayList();
        this.zerodayisaminecraftcheat = (Map<String, TextureOffset>)Maps.newHashMap();
        this.a = 64;
        this.b = 32;
    }
    
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
    }
    
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
    }
    
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
    }
    
    public ModelRenderer zerodayisaminecraftcheat(final Random rand) {
        return this.momgetthecamera.get(rand.nextInt(this.momgetthecamera.size()));
    }
    
    protected void zerodayisaminecraftcheat(final String partName, final int x, final int y) {
        this.zerodayisaminecraftcheat.put(partName, new TextureOffset(x, y));
    }
    
    public TextureOffset zerodayisaminecraftcheat(final String partName) {
        return this.zerodayisaminecraftcheat.get(partName);
    }
    
    public static void zerodayisaminecraftcheat(final ModelRenderer source, final ModelRenderer dest) {
        dest.flux = source.flux;
        dest.vape = source.vape;
        dest.momgetthecamera = source.momgetthecamera;
        dest.sigma = source.sigma;
        dest.pandora = source.pandora;
        dest.zues = source.zues;
    }
    
    public void zerodayisaminecraftcheat(final ModelBase model) {
        this.zues = model.zues;
        this.flux = model.flux;
        this.vape = model.vape;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.flux.EntityBat;
import net.minecraft.vape.Entity;

public class ModelBat extends ModelBase
{
    private ModelRenderer zerodayisaminecraftcheat;
    private ModelRenderer zeroday;
    private ModelRenderer sigma;
    private ModelRenderer pandora;
    private ModelRenderer c;
    private ModelRenderer d;
    
    public ModelBat() {
        this.a = 64;
        this.b = 64;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-3.0f, -3.0f, -3.0f, 6, 6, 6);
        final ModelRenderer modelrenderer = new ModelRenderer(this, 24, 0);
        modelrenderer.zerodayisaminecraftcheat(-4.0f, -6.0f, -2.0f, 3, 4, 1);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(modelrenderer);
        final ModelRenderer modelrenderer2 = new ModelRenderer(this, 24, 0);
        modelrenderer2.a = true;
        modelrenderer2.zerodayisaminecraftcheat(1.0f, -6.0f, -2.0f, 3, 4, 1);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(modelrenderer2);
        (this.zeroday = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-3.0f, 4.0f, -3.0f, 6, 12, 6);
        this.zeroday.zerodayisaminecraftcheat(0, 34).zerodayisaminecraftcheat(-5.0f, 16.0f, 0.0f, 10, 6, 1);
        (this.sigma = new ModelRenderer(this, 42, 0)).zerodayisaminecraftcheat(-12.0f, 1.0f, 1.5f, 10, 16, 1);
        (this.c = new ModelRenderer(this, 24, 16)).zerodayisaminecraftcheat(-12.0f, 1.0f, 1.5f);
        this.c.zerodayisaminecraftcheat(-8.0f, 1.0f, 0.0f, 8, 12, 1);
        this.pandora = new ModelRenderer(this, 42, 0);
        this.pandora.a = true;
        this.pandora.zerodayisaminecraftcheat(2.0f, 1.0f, 1.5f, 10, 16, 1);
        this.d = new ModelRenderer(this, 24, 16);
        this.d.a = true;
        this.d.zerodayisaminecraftcheat(12.0f, 1.0f, 1.5f);
        this.d.zerodayisaminecraftcheat(0.0f, 1.0f, 0.0f, 8, 12, 1);
        this.zeroday.zerodayisaminecraftcheat(this.sigma);
        this.zeroday.zerodayisaminecraftcheat(this.pandora);
        this.sigma.zerodayisaminecraftcheat(this.c);
        this.pandora.zerodayisaminecraftcheat(this.d);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        this.zeroday.zerodayisaminecraftcheat(scale);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        if (((EntityBat)entityIn).momgetthecamera()) {
            final float f = 57.295776f;
            this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
            this.zerodayisaminecraftcheat.vape = 3.1415927f - p_78087_4_ / 57.295776f;
            this.zerodayisaminecraftcheat.momgetthecamera = 3.1415927f;
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, -2.0f, 0.0f);
            this.sigma.zerodayisaminecraftcheat(-3.0f, 0.0f, 3.0f);
            this.pandora.zerodayisaminecraftcheat(3.0f, 0.0f, 3.0f);
            this.zeroday.flux = 3.1415927f;
            this.sigma.flux = -0.15707964f;
            this.sigma.vape = -1.2566371f;
            this.c.vape = -1.7278761f;
            this.pandora.flux = this.sigma.flux;
            this.pandora.vape = -this.sigma.vape;
            this.d.vape = -this.c.vape;
        }
        else {
            final float f2 = 57.295776f;
            this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
            this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
            this.zerodayisaminecraftcheat.momgetthecamera = 0.0f;
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
            this.sigma.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
            this.pandora.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
            this.zeroday.flux = 0.7853982f + MathHelper.zeroday(p_78087_3_ * 0.1f) * 0.15f;
            this.zeroday.vape = 0.0f;
            this.sigma.vape = MathHelper.zeroday(p_78087_3_ * 1.3f) * 3.1415927f * 0.25f;
            this.pandora.vape = -this.sigma.vape;
            this.c.vape = this.sigma.vape * 0.5f;
            this.d.vape = -this.sigma.vape * 0.5f;
        }
    }
}

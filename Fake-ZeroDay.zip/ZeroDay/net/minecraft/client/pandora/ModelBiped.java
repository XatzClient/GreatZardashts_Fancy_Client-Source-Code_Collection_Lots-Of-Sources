// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelBiped extends ModelBase
{
    public ModelRenderer c;
    public ModelRenderer d;
    public ModelRenderer e;
    public ModelRenderer f;
    public ModelRenderer g;
    public ModelRenderer h;
    public ModelRenderer i;
    public int j;
    public int k;
    public boolean l;
    public boolean m;
    
    public ModelBiped() {
        this(0.0f);
    }
    
    public ModelBiped(final float modelSize) {
        this(modelSize, 0.0f, 64, 32);
    }
    
    public ModelBiped(final float modelSize, final float p_i1149_2_, final int textureWidthIn, final int textureHeightIn) {
        this.a = textureWidthIn;
        this.b = textureHeightIn;
        (this.c = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-4.0f, -8.0f, -4.0f, 8, 8, 8, modelSize);
        this.c.zerodayisaminecraftcheat(0.0f, 0.0f + p_i1149_2_, 0.0f);
        (this.d = new ModelRenderer(this, 32, 0)).zerodayisaminecraftcheat(-4.0f, -8.0f, -4.0f, 8, 8, 8, modelSize + 0.5f);
        this.d.zerodayisaminecraftcheat(0.0f, 0.0f + p_i1149_2_, 0.0f);
        (this.e = new ModelRenderer(this, 16, 16)).zerodayisaminecraftcheat(-4.0f, 0.0f, -2.0f, 8, 12, 4, modelSize);
        this.e.zerodayisaminecraftcheat(0.0f, 0.0f + p_i1149_2_, 0.0f);
        (this.f = new ModelRenderer(this, 40, 16)).zerodayisaminecraftcheat(-3.0f, -2.0f, -2.0f, 4, 12, 4, modelSize);
        this.f.zerodayisaminecraftcheat(-5.0f, 2.0f + p_i1149_2_, 0.0f);
        this.g = new ModelRenderer(this, 40, 16);
        this.g.a = true;
        this.g.zerodayisaminecraftcheat(-1.0f, -2.0f, -2.0f, 4, 12, 4, modelSize);
        this.g.zerodayisaminecraftcheat(5.0f, 2.0f + p_i1149_2_, 0.0f);
        (this.h = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize);
        this.h.zerodayisaminecraftcheat(-1.9f, 12.0f + p_i1149_2_, 0.0f);
        this.i = new ModelRenderer(this, 0, 16);
        this.i.a = true;
        this.i.zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize);
        this.i.zerodayisaminecraftcheat(1.9f, 12.0f + p_i1149_2_, 0.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        GlStateManager.v();
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.zerodayisaminecraftcheat(1.5f / f, 1.5f / f, 1.5f / f);
            GlStateManager.zeroday(0.0f, 16.0f * scale, 0.0f);
            this.c.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.e.zerodayisaminecraftcheat(scale);
            this.f.zerodayisaminecraftcheat(scale);
            this.g.zerodayisaminecraftcheat(scale);
            this.h.zerodayisaminecraftcheat(scale);
            this.i.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
        }
        else {
            if (entityIn.y()) {
                GlStateManager.zeroday(0.0f, 0.2f, 0.0f);
            }
            this.c.zerodayisaminecraftcheat(scale);
            this.e.zerodayisaminecraftcheat(scale);
            this.f.zerodayisaminecraftcheat(scale);
            this.g.zerodayisaminecraftcheat(scale);
            this.h.zerodayisaminecraftcheat(scale);
            this.i.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
        }
        GlStateManager.w();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        this.c.vape = p_78087_4_ / 57.295776f;
        this.c.flux = p_78087_5_ / 57.295776f;
        this.f.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 2.0f * p_78087_2_ * 0.5f;
        this.g.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 2.0f * p_78087_2_ * 0.5f;
        this.f.momgetthecamera = 0.0f;
        this.g.momgetthecamera = 0.0f;
        this.h.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.4f * p_78087_2_;
        this.i.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.4f * p_78087_2_;
        this.h.vape = 0.0f;
        this.i.vape = 0.0f;
        if (this.flux) {
            final ModelRenderer f6 = this.f;
            f6.flux -= 0.62831855f;
            final ModelRenderer g = this.g;
            g.flux -= 0.62831855f;
            this.h.flux = -1.2566371f;
            this.i.flux = -1.2566371f;
            this.h.vape = 0.31415927f;
            this.i.vape = -0.31415927f;
        }
        if (this.j != 0) {
            this.g.flux = this.g.flux * 0.5f - 0.31415927f * this.j;
        }
        this.f.vape = 0.0f;
        this.f.momgetthecamera = 0.0f;
        switch (this.k) {
            case 1: {
                this.f.flux = this.f.flux * 0.5f - 0.31415927f * this.k;
                break;
            }
            case 3: {
                this.f.flux = this.f.flux * 0.5f - 0.31415927f * this.k;
                this.f.vape = -0.5235988f;
                break;
            }
        }
        this.g.vape = 0.0f;
        if (this.zues > -9990.0f) {
            float f = this.zues;
            this.e.vape = MathHelper.zerodayisaminecraftcheat(MathHelper.sigma(f) * 3.1415927f * 2.0f) * 0.2f;
            this.f.zues = MathHelper.zerodayisaminecraftcheat(this.e.vape) * 5.0f;
            this.f.sigma = -MathHelper.zeroday(this.e.vape) * 5.0f;
            this.g.zues = -MathHelper.zerodayisaminecraftcheat(this.e.vape) * 5.0f;
            this.g.sigma = MathHelper.zeroday(this.e.vape) * 5.0f;
            final ModelRenderer f7 = this.f;
            f7.vape += this.e.vape;
            final ModelRenderer g2 = this.g;
            g2.vape += this.e.vape;
            final ModelRenderer g3 = this.g;
            g3.flux += this.e.vape;
            f = 1.0f - this.zues;
            f *= f;
            f *= f;
            f = 1.0f - f;
            final float f2 = MathHelper.zerodayisaminecraftcheat(f * 3.1415927f);
            final float f3 = MathHelper.zerodayisaminecraftcheat(this.zues * 3.1415927f) * -(this.c.flux - 0.7f) * 0.75f;
            this.f.flux -= (float)(f2 * 1.2 + f3);
            final ModelRenderer f8 = this.f;
            f8.vape += this.e.vape * 2.0f;
            final ModelRenderer f9 = this.f;
            f9.momgetthecamera += MathHelper.zerodayisaminecraftcheat(this.zues * 3.1415927f) * -0.4f;
        }
        if (this.l) {
            this.e.flux = 0.5f;
            final ModelRenderer f10 = this.f;
            f10.flux += 0.4f;
            final ModelRenderer g4 = this.g;
            g4.flux += 0.4f;
            this.h.zues = 4.0f;
            this.i.zues = 4.0f;
            this.h.pandora = 9.0f;
            this.i.pandora = 9.0f;
            this.c.pandora = 1.0f;
        }
        else {
            this.e.flux = 0.0f;
            this.h.zues = 0.1f;
            this.i.zues = 0.1f;
            this.h.pandora = 12.0f;
            this.i.pandora = 12.0f;
            this.c.pandora = 0.0f;
        }
        final ModelRenderer f11 = this.f;
        f11.momgetthecamera += MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer g5 = this.g;
        g5.momgetthecamera -= MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer f12 = this.f;
        f12.flux += MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
        final ModelRenderer g6 = this.g;
        g6.flux -= MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
        if (this.m) {
            final float f4 = 0.0f;
            final float f5 = 0.0f;
            this.f.momgetthecamera = 0.0f;
            this.g.momgetthecamera = 0.0f;
            this.f.vape = -(0.1f - f4 * 0.6f) + this.c.vape;
            this.g.vape = 0.1f - f4 * 0.6f + this.c.vape + 0.4f;
            this.f.flux = -1.5707964f + this.c.flux;
            this.g.flux = -1.5707964f + this.c.flux;
            final ModelRenderer f13 = this.f;
            f13.flux -= f4 * 1.2f - f5 * 0.4f;
            final ModelRenderer g7 = this.g;
            g7.flux -= f4 * 1.2f - f5 * 0.4f;
            final ModelRenderer f14 = this.f;
            f14.momgetthecamera += MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
            final ModelRenderer g8 = this.g;
            g8.momgetthecamera -= MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
            final ModelRenderer f15 = this.f;
            f15.flux += MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
            final ModelRenderer g9 = this.g;
            g9.flux -= MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
        }
        ModelBase.zerodayisaminecraftcheat(this.c, this.d);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final ModelBase model) {
        super.zerodayisaminecraftcheat(model);
        if (model instanceof ModelBiped) {
            final ModelBiped modelbiped = (ModelBiped)model;
            this.j = modelbiped.j;
            this.k = modelbiped.k;
            this.l = modelbiped.l;
            this.m = modelbiped.m;
        }
    }
    
    public void zerodayisaminecraftcheat(final boolean invisible) {
        this.c.b = invisible;
        this.d.b = invisible;
        this.e.b = invisible;
        this.f.b = invisible;
        this.g.b = invisible;
        this.h.b = invisible;
        this.i.b = invisible;
    }
    
    public void zerodayisaminecraftcheat(final float scale) {
        this.f.sigma(scale);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelBlaze extends ModelBase
{
    private ModelRenderer[] zerodayisaminecraftcheat;
    private ModelRenderer zeroday;
    
    public ModelBlaze() {
        this.zerodayisaminecraftcheat = new ModelRenderer[12];
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            (this.zerodayisaminecraftcheat[i] = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 2, 8, 2);
        }
        (this.zeroday = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-4.0f, -4.0f, -4.0f, 8, 8, 8);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zeroday.zerodayisaminecraftcheat(scale);
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            this.zerodayisaminecraftcheat[i].zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        float f = p_78087_3_ * 3.1415927f * -0.1f;
        for (int i = 0; i < 4; ++i) {
            this.zerodayisaminecraftcheat[i].pandora = -2.0f + MathHelper.zeroday((i * 2 + p_78087_3_) * 0.25f);
            this.zerodayisaminecraftcheat[i].sigma = MathHelper.zeroday(f) * 9.0f;
            this.zerodayisaminecraftcheat[i].zues = MathHelper.zerodayisaminecraftcheat(f) * 9.0f;
            ++f;
        }
        f = 0.7853982f + p_78087_3_ * 3.1415927f * 0.03f;
        for (int j = 4; j < 8; ++j) {
            this.zerodayisaminecraftcheat[j].pandora = 2.0f + MathHelper.zeroday((j * 2 + p_78087_3_) * 0.25f);
            this.zerodayisaminecraftcheat[j].sigma = MathHelper.zeroday(f) * 7.0f;
            this.zerodayisaminecraftcheat[j].zues = MathHelper.zerodayisaminecraftcheat(f) * 7.0f;
            ++f;
        }
        f = 0.47123894f + p_78087_3_ * 3.1415927f * -0.05f;
        for (int k = 8; k < 12; ++k) {
            this.zerodayisaminecraftcheat[k].pandora = 11.0f + MathHelper.zeroday((k * 1.5f + p_78087_3_) * 0.5f);
            this.zerodayisaminecraftcheat[k].sigma = MathHelper.zeroday(f) * 5.0f;
            this.zerodayisaminecraftcheat[k].zues = MathHelper.zerodayisaminecraftcheat(f) * 5.0f;
            ++f;
        }
        this.zeroday.vape = p_78087_4_ / 57.295776f;
        this.zeroday.flux = p_78087_5_ / 57.295776f;
    }
}

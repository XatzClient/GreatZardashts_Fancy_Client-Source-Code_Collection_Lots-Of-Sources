// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelBook extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    public ModelRenderer d;
    public ModelRenderer e;
    
    public ModelBook() {
        this.zerodayisaminecraftcheat = new ModelRenderer(this).zerodayisaminecraftcheat(0, 0).zerodayisaminecraftcheat(-6.0f, -5.0f, 0.0f, 6, 10, 0);
        this.zeroday = new ModelRenderer(this).zerodayisaminecraftcheat(16, 0).zerodayisaminecraftcheat(0.0f, -5.0f, 0.0f, 6, 10, 0);
        this.sigma = new ModelRenderer(this).zerodayisaminecraftcheat(0, 10).zerodayisaminecraftcheat(0.0f, -4.0f, -0.99f, 5, 8, 1);
        this.pandora = new ModelRenderer(this).zerodayisaminecraftcheat(12, 10).zerodayisaminecraftcheat(0.0f, -4.0f, -0.01f, 5, 8, 1);
        this.c = new ModelRenderer(this).zerodayisaminecraftcheat(24, 10).zerodayisaminecraftcheat(0.0f, -4.0f, 0.0f, 5, 8, 0);
        this.d = new ModelRenderer(this).zerodayisaminecraftcheat(24, 10).zerodayisaminecraftcheat(0.0f, -4.0f, 0.0f, 5, 8, 0);
        this.e = new ModelRenderer(this).zerodayisaminecraftcheat(12, 0).zerodayisaminecraftcheat(-1.0f, -5.0f, 0.0f, 2, 10, 0);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 0.0f, -1.0f);
        this.zeroday.zerodayisaminecraftcheat(0.0f, 0.0f, 1.0f);
        this.e.vape = 1.5707964f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        this.zeroday.zerodayisaminecraftcheat(scale);
        this.e.zerodayisaminecraftcheat(scale);
        this.sigma.zerodayisaminecraftcheat(scale);
        this.pandora.zerodayisaminecraftcheat(scale);
        this.c.zerodayisaminecraftcheat(scale);
        this.d.zerodayisaminecraftcheat(scale);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        final float f = (MathHelper.zerodayisaminecraftcheat(p_78087_1_ * 0.02f) * 0.1f + 1.25f) * p_78087_4_;
        this.zerodayisaminecraftcheat.vape = 3.1415927f + f;
        this.zeroday.vape = -f;
        this.sigma.vape = f;
        this.pandora.vape = -f;
        this.c.vape = f - f * 2.0f * p_78087_2_;
        this.d.vape = f - f * 2.0f * p_78087_3_;
        this.sigma.sigma = MathHelper.zerodayisaminecraftcheat(f);
        this.pandora.sigma = MathHelper.zerodayisaminecraftcheat(f);
        this.c.sigma = MathHelper.zerodayisaminecraftcheat(f);
        this.d.sigma = MathHelper.zerodayisaminecraftcheat(f);
    }
}

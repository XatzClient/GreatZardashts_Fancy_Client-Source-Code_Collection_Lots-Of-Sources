// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.client.a.WorldRenderer;

public class ModelBox
{
    private PositionTextureVertex[] momgetthecamera;
    private TexturedQuad[] a;
    public final float zerodayisaminecraftcheat;
    public final float zeroday;
    public final float sigma;
    public final float pandora;
    public final float zues;
    public final float flux;
    public String vape;
    
    public ModelBox(final ModelRenderer renderer, final int p_i46359_2_, final int p_i46359_3_, final float p_i46359_4_, final float p_i46359_5_, final float p_i46359_6_, final int p_i46359_7_, final int p_i46359_8_, final int p_i46359_9_, final float p_i46359_10_) {
        this(renderer, p_i46359_2_, p_i46359_3_, p_i46359_4_, p_i46359_5_, p_i46359_6_, p_i46359_7_, p_i46359_8_, p_i46359_9_, p_i46359_10_, renderer.a);
    }
    
    public ModelBox(final ModelRenderer renderer, final int textureX, final int textureY, float p_i46301_4_, float p_i46301_5_, float p_i46301_6_, final int p_i46301_7_, final int p_i46301_8_, final int p_i46301_9_, final float p_i46301_10_, final boolean p_i46301_11_) {
        this.zerodayisaminecraftcheat = p_i46301_4_;
        this.zeroday = p_i46301_5_;
        this.sigma = p_i46301_6_;
        this.pandora = p_i46301_4_ + p_i46301_7_;
        this.zues = p_i46301_5_ + p_i46301_8_;
        this.flux = p_i46301_6_ + p_i46301_9_;
        this.momgetthecamera = new PositionTextureVertex[8];
        this.a = new TexturedQuad[6];
        float f = p_i46301_4_ + p_i46301_7_;
        float f2 = p_i46301_5_ + p_i46301_8_;
        float f3 = p_i46301_6_ + p_i46301_9_;
        p_i46301_4_ -= p_i46301_10_;
        p_i46301_5_ -= p_i46301_10_;
        p_i46301_6_ -= p_i46301_10_;
        f += p_i46301_10_;
        f2 += p_i46301_10_;
        f3 += p_i46301_10_;
        if (p_i46301_11_) {
            final float f4 = f;
            f = p_i46301_4_;
            p_i46301_4_ = f4;
        }
        final PositionTextureVertex positiontexturevertex7 = new PositionTextureVertex(p_i46301_4_, p_i46301_5_, p_i46301_6_, 0.0f, 0.0f);
        final PositionTextureVertex positiontexturevertex8 = new PositionTextureVertex(f, p_i46301_5_, p_i46301_6_, 0.0f, 8.0f);
        final PositionTextureVertex positiontexturevertex9 = new PositionTextureVertex(f, f2, p_i46301_6_, 8.0f, 8.0f);
        final PositionTextureVertex positiontexturevertex10 = new PositionTextureVertex(p_i46301_4_, f2, p_i46301_6_, 8.0f, 0.0f);
        final PositionTextureVertex positiontexturevertex11 = new PositionTextureVertex(p_i46301_4_, p_i46301_5_, f3, 0.0f, 0.0f);
        final PositionTextureVertex positiontexturevertex12 = new PositionTextureVertex(f, p_i46301_5_, f3, 0.0f, 8.0f);
        final PositionTextureVertex positiontexturevertex13 = new PositionTextureVertex(f, f2, f3, 8.0f, 8.0f);
        final PositionTextureVertex positiontexturevertex14 = new PositionTextureVertex(p_i46301_4_, f2, f3, 8.0f, 0.0f);
        this.momgetthecamera[0] = positiontexturevertex7;
        this.momgetthecamera[1] = positiontexturevertex8;
        this.momgetthecamera[2] = positiontexturevertex9;
        this.momgetthecamera[3] = positiontexturevertex10;
        this.momgetthecamera[4] = positiontexturevertex11;
        this.momgetthecamera[5] = positiontexturevertex12;
        this.momgetthecamera[6] = positiontexturevertex13;
        this.momgetthecamera[7] = positiontexturevertex14;
        this.a[0] = new TexturedQuad(new PositionTextureVertex[] { positiontexturevertex12, positiontexturevertex8, positiontexturevertex9, positiontexturevertex13 }, textureX + p_i46301_9_ + p_i46301_7_, textureY + p_i46301_9_, textureX + p_i46301_9_ + p_i46301_7_ + p_i46301_9_, textureY + p_i46301_9_ + p_i46301_8_, renderer.zerodayisaminecraftcheat, renderer.zeroday);
        this.a[1] = new TexturedQuad(new PositionTextureVertex[] { positiontexturevertex7, positiontexturevertex11, positiontexturevertex14, positiontexturevertex10 }, textureX, textureY + p_i46301_9_, textureX + p_i46301_9_, textureY + p_i46301_9_ + p_i46301_8_, renderer.zerodayisaminecraftcheat, renderer.zeroday);
        this.a[2] = new TexturedQuad(new PositionTextureVertex[] { positiontexturevertex12, positiontexturevertex11, positiontexturevertex7, positiontexturevertex8 }, textureX + p_i46301_9_, textureY, textureX + p_i46301_9_ + p_i46301_7_, textureY + p_i46301_9_, renderer.zerodayisaminecraftcheat, renderer.zeroday);
        this.a[3] = new TexturedQuad(new PositionTextureVertex[] { positiontexturevertex9, positiontexturevertex10, positiontexturevertex14, positiontexturevertex13 }, textureX + p_i46301_9_ + p_i46301_7_, textureY + p_i46301_9_, textureX + p_i46301_9_ + p_i46301_7_ + p_i46301_7_, textureY, renderer.zerodayisaminecraftcheat, renderer.zeroday);
        this.a[4] = new TexturedQuad(new PositionTextureVertex[] { positiontexturevertex8, positiontexturevertex7, positiontexturevertex10, positiontexturevertex9 }, textureX + p_i46301_9_, textureY + p_i46301_9_, textureX + p_i46301_9_ + p_i46301_7_, textureY + p_i46301_9_ + p_i46301_8_, renderer.zerodayisaminecraftcheat, renderer.zeroday);
        this.a[5] = new TexturedQuad(new PositionTextureVertex[] { positiontexturevertex11, positiontexturevertex12, positiontexturevertex13, positiontexturevertex14 }, textureX + p_i46301_9_ + p_i46301_7_ + p_i46301_9_, textureY + p_i46301_9_, textureX + p_i46301_9_ + p_i46301_7_ + p_i46301_9_ + p_i46301_7_, textureY + p_i46301_9_ + p_i46301_8_, renderer.zerodayisaminecraftcheat, renderer.zeroday);
        if (p_i46301_11_) {
            for (int i = 0; i < this.a.length; ++i) {
                this.a[i].zerodayisaminecraftcheat();
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final WorldRenderer renderer, final float scale) {
        for (int i = 0; i < this.a.length; ++i) {
            this.a[i].zerodayisaminecraftcheat(renderer, scale);
        }
    }
    
    public ModelBox zerodayisaminecraftcheat(final String name) {
        this.vape = name;
        return this;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

public class ModelChest extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    
    public ModelChest() {
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0).zeroday(64, 64)).zerodayisaminecraftcheat(0.0f, -5.0f, -14.0f, 14, 5, 14, 0.0f);
        this.zerodayisaminecraftcheat.sigma = 1.0f;
        this.zerodayisaminecraftcheat.pandora = 7.0f;
        this.zerodayisaminecraftcheat.zues = 15.0f;
        (this.sigma = new ModelRenderer(this, 0, 0).zeroday(64, 64)).zerodayisaminecraftcheat(-1.0f, -2.0f, -15.0f, 2, 4, 1, 0.0f);
        this.sigma.sigma = 8.0f;
        this.sigma.pandora = 7.0f;
        this.sigma.zues = 15.0f;
        (this.zeroday = new ModelRenderer(this, 0, 19).zeroday(64, 64)).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 14, 10, 14, 0.0f);
        this.zeroday.sigma = 1.0f;
        this.zeroday.pandora = 6.0f;
        this.zeroday.zues = 1.0f;
    }
    
    public void zerodayisaminecraftcheat() {
        this.sigma.flux = this.zerodayisaminecraftcheat.flux;
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0625f);
        this.sigma.zerodayisaminecraftcheat(0.0625f);
        this.zeroday.zerodayisaminecraftcheat(0.0625f);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelChicken extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    public ModelRenderer d;
    public ModelRenderer e;
    public ModelRenderer f;
    
    public ModelChicken() {
        final int i = 16;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-2.0f, -6.0f, -2.0f, 4, 6, 3, 0.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, (float)(-1 + i), -4.0f);
        (this.e = new ModelRenderer(this, 14, 0)).zerodayisaminecraftcheat(-2.0f, -4.0f, -4.0f, 4, 2, 2, 0.0f);
        this.e.zerodayisaminecraftcheat(0.0f, (float)(-1 + i), -4.0f);
        (this.f = new ModelRenderer(this, 14, 4)).zerodayisaminecraftcheat(-1.0f, -2.0f, -3.0f, 2, 2, 2, 0.0f);
        this.f.zerodayisaminecraftcheat(0.0f, (float)(-1 + i), -4.0f);
        (this.zeroday = new ModelRenderer(this, 0, 9)).zerodayisaminecraftcheat(-3.0f, -4.0f, -3.0f, 6, 8, 6, 0.0f);
        this.zeroday.zerodayisaminecraftcheat(0.0f, (float)i, 0.0f);
        (this.sigma = new ModelRenderer(this, 26, 0)).zerodayisaminecraftcheat(-1.0f, 0.0f, -3.0f, 3, 5, 3);
        this.sigma.zerodayisaminecraftcheat(-2.0f, (float)(3 + i), 1.0f);
        (this.pandora = new ModelRenderer(this, 26, 0)).zerodayisaminecraftcheat(-1.0f, 0.0f, -3.0f, 3, 5, 3);
        this.pandora.zerodayisaminecraftcheat(1.0f, (float)(3 + i), 1.0f);
        (this.c = new ModelRenderer(this, 24, 13)).zerodayisaminecraftcheat(0.0f, 0.0f, -3.0f, 1, 4, 6);
        this.c.zerodayisaminecraftcheat(-4.0f, (float)(-3 + i), 0.0f);
        (this.d = new ModelRenderer(this, 24, 13)).zerodayisaminecraftcheat(-1.0f, 0.0f, -3.0f, 1, 4, 6);
        this.d.zerodayisaminecraftcheat(4.0f, (float)(-3 + i), 0.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, 5.0f * scale, 2.0f * scale);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.e.zerodayisaminecraftcheat(scale);
            this.f.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
        }
        else {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.e.zerodayisaminecraftcheat(scale);
            this.f.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
        this.e.flux = this.zerodayisaminecraftcheat.flux;
        this.e.vape = this.zerodayisaminecraftcheat.vape;
        this.f.flux = this.zerodayisaminecraftcheat.flux;
        this.f.vape = this.zerodayisaminecraftcheat.vape;
        this.zeroday.flux = 1.5707964f;
        this.sigma.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.4f * p_78087_2_;
        this.pandora.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.4f * p_78087_2_;
        this.c.momgetthecamera = p_78087_3_;
        this.d.momgetthecamera = -p_78087_3_;
    }
}

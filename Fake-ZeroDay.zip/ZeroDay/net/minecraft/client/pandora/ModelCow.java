// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

public class ModelCow extends ModelQuadruped
{
    public ModelCow() {
        super(12, 0.0f);
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-4.0f, -4.0f, -6.0f, 8, 8, 6, 0.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 4.0f, -8.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(22, 0).zerodayisaminecraftcheat(-5.0f, -5.0f, -4.0f, 1, 3, 1, 0.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(22, 0).zerodayisaminecraftcheat(4.0f, -5.0f, -4.0f, 1, 3, 1, 0.0f);
        (this.zeroday = new ModelRenderer(this, 18, 4)).zerodayisaminecraftcheat(-6.0f, -10.0f, -7.0f, 12, 18, 10, 0.0f);
        this.zeroday.zerodayisaminecraftcheat(0.0f, 5.0f, 2.0f);
        this.zeroday.zerodayisaminecraftcheat(52, 0).zerodayisaminecraftcheat(-2.0f, 2.0f, -8.0f, 4, 6, 1);
        final ModelRenderer sigma = this.sigma;
        --sigma.sigma;
        final ModelRenderer pandora = this.pandora;
        ++pandora.sigma;
        final ModelRenderer sigma2 = this.sigma;
        sigma2.zues += 0.0f;
        final ModelRenderer pandora2 = this.pandora;
        pandora2.zues += 0.0f;
        final ModelRenderer c = this.c;
        --c.sigma;
        final ModelRenderer d = this.d;
        ++d.sigma;
        final ModelRenderer c2 = this.c;
        --c2.zues;
        final ModelRenderer d2 = this.d;
        --d2.zues;
        this.f += 2.0f;
    }
}

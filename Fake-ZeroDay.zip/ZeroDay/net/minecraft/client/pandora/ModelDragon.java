// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.zeroday.EntityDragon;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;
import net.minecraft.vape.EntityLivingBase;

public class ModelDragon extends ModelBase
{
    private ModelRenderer zerodayisaminecraftcheat;
    private ModelRenderer zeroday;
    private ModelRenderer sigma;
    private ModelRenderer pandora;
    private ModelRenderer c;
    private ModelRenderer d;
    private ModelRenderer e;
    private ModelRenderer f;
    private ModelRenderer g;
    private ModelRenderer h;
    private ModelRenderer i;
    private ModelRenderer j;
    private float k;
    
    public ModelDragon(final float p_i46360_1_) {
        this.a = 256;
        this.b = 256;
        this.zerodayisaminecraftcheat("body.body", 0, 0);
        this.zerodayisaminecraftcheat("wing.skin", -56, 88);
        this.zerodayisaminecraftcheat("wingtip.skin", -56, 144);
        this.zerodayisaminecraftcheat("rearleg.main", 0, 0);
        this.zerodayisaminecraftcheat("rearfoot.main", 112, 0);
        this.zerodayisaminecraftcheat("rearlegtip.main", 196, 0);
        this.zerodayisaminecraftcheat("head.upperhead", 112, 30);
        this.zerodayisaminecraftcheat("wing.bone", 112, 88);
        this.zerodayisaminecraftcheat("head.upperlip", 176, 44);
        this.zerodayisaminecraftcheat("jaw.jaw", 176, 65);
        this.zerodayisaminecraftcheat("frontleg.main", 112, 104);
        this.zerodayisaminecraftcheat("wingtip.bone", 112, 136);
        this.zerodayisaminecraftcheat("frontfoot.main", 144, 104);
        this.zerodayisaminecraftcheat("neck.box", 192, 104);
        this.zerodayisaminecraftcheat("frontlegtip.main", 226, 138);
        this.zerodayisaminecraftcheat("body.scale", 220, 53);
        this.zerodayisaminecraftcheat("head.scale", 0, 0);
        this.zerodayisaminecraftcheat("neck.scale", 48, 0);
        this.zerodayisaminecraftcheat("head.nostril", 112, 0);
        final float f = -16.0f;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, "head")).zerodayisaminecraftcheat("upperlip", -6.0f, -1.0f, -8.0f + f, 12, 5, 16);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat("upperhead", -8.0f, -8.0f, 6.0f + f, 16, 16, 16);
        this.zerodayisaminecraftcheat.a = true;
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat("scale", -5.0f, -12.0f, 12.0f + f, 2, 4, 6);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat("nostril", -5.0f, -3.0f, -6.0f + f, 2, 2, 4);
        this.zerodayisaminecraftcheat.a = false;
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat("scale", 3.0f, -12.0f, 12.0f + f, 2, 4, 6);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat("nostril", 3.0f, -3.0f, -6.0f + f, 2, 2, 4);
        (this.sigma = new ModelRenderer(this, "jaw")).zerodayisaminecraftcheat(0.0f, 4.0f, 8.0f + f);
        this.sigma.zerodayisaminecraftcheat("jaw", -6.0f, 0.0f, -16.0f, 12, 4, 16);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.sigma);
        (this.zeroday = new ModelRenderer(this, "neck")).zerodayisaminecraftcheat("box", -5.0f, -5.0f, -5.0f, 10, 10, 10);
        this.zeroday.zerodayisaminecraftcheat("scale", -1.0f, -9.0f, -3.0f, 2, 4, 6);
        (this.pandora = new ModelRenderer(this, "body")).zerodayisaminecraftcheat(0.0f, 4.0f, 8.0f);
        this.pandora.zerodayisaminecraftcheat("body", -12.0f, 0.0f, -16.0f, 24, 24, 64);
        this.pandora.zerodayisaminecraftcheat("scale", -1.0f, -6.0f, -10.0f, 2, 6, 12);
        this.pandora.zerodayisaminecraftcheat("scale", -1.0f, -6.0f, 10.0f, 2, 6, 12);
        this.pandora.zerodayisaminecraftcheat("scale", -1.0f, -6.0f, 30.0f, 2, 6, 12);
        (this.i = new ModelRenderer(this, "wing")).zerodayisaminecraftcheat(-12.0f, 5.0f, 2.0f);
        this.i.zerodayisaminecraftcheat("bone", -56.0f, -4.0f, -4.0f, 56, 8, 8);
        this.i.zerodayisaminecraftcheat("skin", -56.0f, 0.0f, 2.0f, 56, 0, 56);
        (this.j = new ModelRenderer(this, "wingtip")).zerodayisaminecraftcheat(-56.0f, 0.0f, 0.0f);
        this.j.zerodayisaminecraftcheat("bone", -56.0f, -2.0f, -2.0f, 56, 4, 4);
        this.j.zerodayisaminecraftcheat("skin", -56.0f, 0.0f, 2.0f, 56, 0, 56);
        this.i.zerodayisaminecraftcheat(this.j);
        (this.d = new ModelRenderer(this, "frontleg")).zerodayisaminecraftcheat(-12.0f, 20.0f, 2.0f);
        this.d.zerodayisaminecraftcheat("main", -4.0f, -4.0f, -4.0f, 8, 24, 8);
        (this.f = new ModelRenderer(this, "frontlegtip")).zerodayisaminecraftcheat(0.0f, 20.0f, -1.0f);
        this.f.zerodayisaminecraftcheat("main", -3.0f, -1.0f, -3.0f, 6, 24, 6);
        this.d.zerodayisaminecraftcheat(this.f);
        (this.h = new ModelRenderer(this, "frontfoot")).zerodayisaminecraftcheat(0.0f, 23.0f, 0.0f);
        this.h.zerodayisaminecraftcheat("main", -4.0f, 0.0f, -12.0f, 8, 4, 16);
        this.f.zerodayisaminecraftcheat(this.h);
        (this.c = new ModelRenderer(this, "rearleg")).zerodayisaminecraftcheat(-16.0f, 16.0f, 42.0f);
        this.c.zerodayisaminecraftcheat("main", -8.0f, -4.0f, -8.0f, 16, 32, 16);
        (this.e = new ModelRenderer(this, "rearlegtip")).zerodayisaminecraftcheat(0.0f, 32.0f, -4.0f);
        this.e.zerodayisaminecraftcheat("main", -6.0f, -2.0f, 0.0f, 12, 32, 12);
        this.c.zerodayisaminecraftcheat(this.e);
        (this.g = new ModelRenderer(this, "rearfoot")).zerodayisaminecraftcheat(0.0f, 31.0f, 4.0f);
        this.g.zerodayisaminecraftcheat("main", -9.0f, 0.0f, -20.0f, 18, 6, 24);
        this.e.zerodayisaminecraftcheat(this.g);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        this.k = partialTickTime;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        GlStateManager.v();
        final EntityDragon entitydragon = (EntityDragon)entityIn;
        final float f = entitydragon.bt + (entitydragon.bu - entitydragon.bt) * this.k;
        this.sigma.flux = (float)(Math.sin(f * 3.1415927f * 2.0f) + 1.0) * 0.2f;
        float f2 = (float)(Math.sin(f * 3.1415927f * 2.0f - 1.0f) + 1.0);
        f2 = (f2 * f2 * 1.0f + f2 * 2.0f) * 0.05f;
        GlStateManager.zeroday(0.0f, f2 - 2.0f, -3.0f);
        GlStateManager.zeroday(f2 * 2.0f, 1.0f, 0.0f, 0.0f);
        float f3 = -30.0f;
        float f4 = 0.0f;
        final float f5 = 1.5f;
        double[] adouble = entitydragon.zeroday(6, this.k);
        final float f6 = this.zerodayisaminecraftcheat(entitydragon.zeroday(5, this.k)[0] - entitydragon.zeroday(10, this.k)[0]);
        final float f7 = this.zerodayisaminecraftcheat(entitydragon.zeroday(5, this.k)[0] + f6 / 2.0f);
        f3 += 2.0f;
        float f8 = f * 3.1415927f * 2.0f;
        f3 = 20.0f;
        float f9 = -12.0f;
        for (int i = 0; i < 5; ++i) {
            final double[] adouble2 = entitydragon.zeroday(5 - i, this.k);
            final float f10 = (float)Math.cos(i * 0.45f + f8) * 0.15f;
            this.zeroday.vape = this.zerodayisaminecraftcheat(adouble2[0] - adouble[0]) * 3.1415927f / 180.0f * f5;
            this.zeroday.flux = f10 + (float)(adouble2[1] - adouble[1]) * 3.1415927f / 180.0f * f5 * 5.0f;
            this.zeroday.momgetthecamera = -this.zerodayisaminecraftcheat(adouble2[0] - f7) * 3.1415927f / 180.0f * f5;
            this.zeroday.pandora = f3;
            this.zeroday.zues = f9;
            this.zeroday.sigma = f4;
            f3 += (float)(Math.sin(this.zeroday.flux) * 10.0);
            f9 -= (float)(Math.cos(this.zeroday.vape) * Math.cos(this.zeroday.flux) * 10.0);
            f4 -= (float)(Math.sin(this.zeroday.vape) * Math.cos(this.zeroday.flux) * 10.0);
            this.zeroday.zerodayisaminecraftcheat(scale);
        }
        this.zerodayisaminecraftcheat.pandora = f3;
        this.zerodayisaminecraftcheat.zues = f9;
        this.zerodayisaminecraftcheat.sigma = f4;
        double[] adouble3 = entitydragon.zeroday(0, this.k);
        this.zerodayisaminecraftcheat.vape = this.zerodayisaminecraftcheat(adouble3[0] - adouble[0]) * 3.1415927f / 180.0f * 1.0f;
        this.zerodayisaminecraftcheat.momgetthecamera = -this.zerodayisaminecraftcheat(adouble3[0] - f7) * 3.1415927f / 180.0f * 1.0f;
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        GlStateManager.v();
        GlStateManager.zeroday(0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(-f6 * f5 * 1.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.zeroday(0.0f, -1.0f, 0.0f);
        this.pandora.momgetthecamera = 0.0f;
        this.pandora.zerodayisaminecraftcheat(scale);
        for (int j = 0; j < 2; ++j) {
            GlStateManager.g();
            final float f11 = f * 3.1415927f * 2.0f;
            this.i.flux = 0.125f - (float)Math.cos(f11) * 0.2f;
            this.i.vape = 0.25f;
            this.i.momgetthecamera = (float)(Math.sin(f11) + 0.125) * 0.8f;
            this.j.momgetthecamera = -(float)(Math.sin(f11 + 2.0f) + 0.5) * 0.75f;
            this.c.flux = 1.0f + f2 * 0.1f;
            this.e.flux = 0.5f + f2 * 0.1f;
            this.g.flux = 0.75f + f2 * 0.1f;
            this.d.flux = 1.3f + f2 * 0.1f;
            this.f.flux = -0.5f - f2 * 0.1f;
            this.h.flux = 0.75f + f2 * 0.1f;
            this.i.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            GlStateManager.zerodayisaminecraftcheat(-1.0f, 1.0f, 1.0f);
            if (j == 0) {
                GlStateManager.zues(1028);
            }
        }
        GlStateManager.w();
        GlStateManager.zues(1029);
        GlStateManager.h();
        float f12 = -(float)Math.sin(f * 3.1415927f * 2.0f) * 0.0f;
        f8 = f * 3.1415927f * 2.0f;
        f3 = 10.0f;
        f9 = 60.0f;
        f4 = 0.0f;
        adouble = entitydragon.zeroday(11, this.k);
        for (int k = 0; k < 12; ++k) {
            adouble3 = entitydragon.zeroday(12 + k, this.k);
            f12 += (float)(Math.sin(k * 0.45f + f8) * 0.05000000074505806);
            this.zeroday.vape = (this.zerodayisaminecraftcheat(adouble3[0] - adouble[0]) * f5 + 180.0f) * 3.1415927f / 180.0f;
            this.zeroday.flux = f12 + (float)(adouble3[1] - adouble[1]) * 3.1415927f / 180.0f * f5 * 5.0f;
            this.zeroday.momgetthecamera = this.zerodayisaminecraftcheat(adouble3[0] - f7) * 3.1415927f / 180.0f * f5;
            this.zeroday.pandora = f3;
            this.zeroday.zues = f9;
            this.zeroday.sigma = f4;
            f3 += (float)(Math.sin(this.zeroday.flux) * 10.0);
            f9 -= (float)(Math.cos(this.zeroday.vape) * Math.cos(this.zeroday.flux) * 10.0);
            f4 -= (float)(Math.sin(this.zeroday.vape) * Math.cos(this.zeroday.flux) * 10.0);
            this.zeroday.zerodayisaminecraftcheat(scale);
        }
        GlStateManager.w();
    }
    
    private float zerodayisaminecraftcheat(double p_78214_1_) {
        while (p_78214_1_ >= 180.0) {
            p_78214_1_ -= 360.0;
        }
        while (p_78214_1_ < -180.0) {
            p_78214_1_ += 360.0;
        }
        return (float)p_78214_1_;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelEnderCrystal extends ModelBase
{
    private ModelRenderer zerodayisaminecraftcheat;
    private ModelRenderer zeroday;
    private ModelRenderer sigma;
    
    public ModelEnderCrystal(final float p_i1170_1_, final boolean p_i1170_2_) {
        this.zeroday = new ModelRenderer(this, "glass");
        this.zeroday.zerodayisaminecraftcheat(0, 0).zerodayisaminecraftcheat(-4.0f, -4.0f, -4.0f, 8, 8, 8);
        this.zerodayisaminecraftcheat = new ModelRenderer(this, "cube");
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(32, 0).zerodayisaminecraftcheat(-4.0f, -4.0f, -4.0f, 8, 8, 8);
        if (p_i1170_2_) {
            this.sigma = new ModelRenderer(this, "base");
            this.sigma.zerodayisaminecraftcheat(0, 16).zerodayisaminecraftcheat(-6.0f, 0.0f, -6.0f, 12, 4, 12);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        GlStateManager.v();
        GlStateManager.zerodayisaminecraftcheat(2.0f, 2.0f, 2.0f);
        GlStateManager.zeroday(0.0f, -0.5f, 0.0f);
        if (this.sigma != null) {
            this.sigma.zerodayisaminecraftcheat(scale);
        }
        GlStateManager.zeroday(p_78088_3_, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(0.0f, 0.8f + p_78088_4_, 0.0f);
        GlStateManager.zeroday(60.0f, 0.7071f, 0.0f, 0.7071f);
        this.zeroday.zerodayisaminecraftcheat(scale);
        final float f = 0.875f;
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        GlStateManager.zeroday(60.0f, 0.7071f, 0.0f, 0.7071f);
        GlStateManager.zeroday(p_78088_3_, 0.0f, 1.0f, 0.0f);
        this.zeroday.zerodayisaminecraftcheat(scale);
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        GlStateManager.zeroday(60.0f, 0.7071f, 0.0f, 0.7071f);
        GlStateManager.zeroday(p_78088_3_, 0.0f, 1.0f, 0.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        GlStateManager.w();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelEnderMite extends ModelBase
{
    private static final int[][] zerodayisaminecraftcheat;
    private static final int[][] zeroday;
    private static final int sigma;
    private final ModelRenderer[] pandora;
    
    static {
        zerodayisaminecraftcheat = new int[][] { { 4, 3, 2 }, { 6, 4, 5 }, { 3, 3, 1 }, { 1, 2, 1 } };
        zeroday = new int[][] { new int[2], { 0, 5 }, { 0, 14 }, { 0, 18 } };
        sigma = ModelEnderMite.zerodayisaminecraftcheat.length;
    }
    
    public ModelEnderMite() {
        this.pandora = new ModelRenderer[ModelEnderMite.sigma];
        float f = -3.5f;
        for (int i = 0; i < this.pandora.length; ++i) {
            (this.pandora[i] = new ModelRenderer(this, ModelEnderMite.zeroday[i][0], ModelEnderMite.zeroday[i][1])).zerodayisaminecraftcheat(ModelEnderMite.zerodayisaminecraftcheat[i][0] * -0.5f, 0.0f, ModelEnderMite.zerodayisaminecraftcheat[i][2] * -0.5f, ModelEnderMite.zerodayisaminecraftcheat[i][0], ModelEnderMite.zerodayisaminecraftcheat[i][1], ModelEnderMite.zerodayisaminecraftcheat[i][2]);
            this.pandora[i].zerodayisaminecraftcheat(0.0f, (float)(24 - ModelEnderMite.zerodayisaminecraftcheat[i][1]), f);
            if (i < this.pandora.length - 1) {
                f += (ModelEnderMite.zerodayisaminecraftcheat[i][2] + ModelEnderMite.zerodayisaminecraftcheat[i + 1][2]) * 0.5f;
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        for (int i = 0; i < this.pandora.length; ++i) {
            this.pandora[i].zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        for (int i = 0; i < this.pandora.length; ++i) {
            this.pandora[i].vape = MathHelper.zeroday(p_78087_3_ * 0.9f + i * 0.15f * 3.1415927f) * 3.1415927f * 0.01f * (1 + Math.abs(i - 2));
            this.pandora[i].sigma = MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.9f + i * 0.15f * 3.1415927f) * 3.1415927f * 0.1f * Math.abs(i - 2);
        }
    }
}

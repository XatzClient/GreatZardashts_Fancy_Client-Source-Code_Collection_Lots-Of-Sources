// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.Entity;

public class ModelEnderman extends ModelBiped
{
    public boolean zerodayisaminecraftcheat;
    public boolean zeroday;
    
    public ModelEnderman(final float p_i46305_1_) {
        super(0.0f, -14.0f, 64, 32);
        final float f = -14.0f;
        (this.d = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-4.0f, -8.0f, -4.0f, 8, 8, 8, p_i46305_1_ - 0.5f);
        this.d.zerodayisaminecraftcheat(0.0f, 0.0f + f, 0.0f);
        (this.e = new ModelRenderer(this, 32, 16)).zerodayisaminecraftcheat(-4.0f, 0.0f, -2.0f, 8, 12, 4, p_i46305_1_);
        this.e.zerodayisaminecraftcheat(0.0f, 0.0f + f, 0.0f);
        (this.f = new ModelRenderer(this, 56, 0)).zerodayisaminecraftcheat(-1.0f, -2.0f, -1.0f, 2, 30, 2, p_i46305_1_);
        this.f.zerodayisaminecraftcheat(-3.0f, 2.0f + f, 0.0f);
        this.g = new ModelRenderer(this, 56, 0);
        this.g.a = true;
        this.g.zerodayisaminecraftcheat(-1.0f, -2.0f, -1.0f, 2, 30, 2, p_i46305_1_);
        this.g.zerodayisaminecraftcheat(5.0f, 2.0f + f, 0.0f);
        (this.h = new ModelRenderer(this, 56, 0)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 30, 2, p_i46305_1_);
        this.h.zerodayisaminecraftcheat(-2.0f, 12.0f + f, 0.0f);
        this.i = new ModelRenderer(this, 56, 0);
        this.i.a = true;
        this.i.zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 30, 2, p_i46305_1_);
        this.i.zerodayisaminecraftcheat(2.0f, 12.0f + f, 0.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        this.c.b = true;
        final float f = -14.0f;
        this.e.flux = 0.0f;
        this.e.pandora = f;
        this.e.zues = -0.0f;
        final ModelRenderer h = this.h;
        h.flux -= 0.0f;
        final ModelRenderer i = this.i;
        i.flux -= 0.0f;
        this.f.flux *= 0.5;
        this.g.flux *= 0.5;
        this.h.flux *= 0.5;
        this.i.flux *= 0.5;
        final float f2 = 0.4f;
        if (this.f.flux > f2) {
            this.f.flux = f2;
        }
        if (this.g.flux > f2) {
            this.g.flux = f2;
        }
        if (this.f.flux < -f2) {
            this.f.flux = -f2;
        }
        if (this.g.flux < -f2) {
            this.g.flux = -f2;
        }
        if (this.h.flux > f2) {
            this.h.flux = f2;
        }
        if (this.i.flux > f2) {
            this.i.flux = f2;
        }
        if (this.h.flux < -f2) {
            this.h.flux = -f2;
        }
        if (this.i.flux < -f2) {
            this.i.flux = -f2;
        }
        if (this.zerodayisaminecraftcheat) {
            this.f.flux = -0.5f;
            this.g.flux = -0.5f;
            this.f.momgetthecamera = 0.05f;
            this.g.momgetthecamera = -0.05f;
        }
        this.f.zues = 0.0f;
        this.g.zues = 0.0f;
        this.h.zues = 0.0f;
        this.i.zues = 0.0f;
        this.h.pandora = 9.0f + f;
        this.i.pandora = 9.0f + f;
        this.c.zues = -0.0f;
        this.c.pandora = f + 1.0f;
        this.d.sigma = this.c.sigma;
        this.d.pandora = this.c.pandora;
        this.d.zues = this.c.zues;
        this.d.flux = this.c.flux;
        this.d.vape = this.c.vape;
        this.d.momgetthecamera = this.c.momgetthecamera;
        if (this.zeroday) {
            final float f3 = 1.0f;
            final ModelRenderer c = this.c;
            c.pandora -= f3 * 5.0f;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;
import java.util.Random;

public class ModelGhast extends ModelBase
{
    ModelRenderer zerodayisaminecraftcheat;
    ModelRenderer[] zeroday;
    
    public ModelGhast() {
        this.zeroday = new ModelRenderer[9];
        final int i = -16;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-8.0f, -8.0f, -8.0f, 16, 16, 16);
        final ModelRenderer zerodayisaminecraftcheat = this.zerodayisaminecraftcheat;
        zerodayisaminecraftcheat.pandora += 24 + i;
        final Random random = new Random(1660L);
        for (int j = 0; j < this.zeroday.length; ++j) {
            this.zeroday[j] = new ModelRenderer(this, 0, 0);
            final float f = ((j % 3 - j / 3 % 2 * 0.5f + 0.25f) / 2.0f * 2.0f - 1.0f) * 5.0f;
            final float f2 = (j / 3 / 2.0f * 2.0f - 1.0f) * 5.0f;
            final int k = random.nextInt(7) + 8;
            this.zeroday[j].zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, k, 2);
            this.zeroday[j].sigma = f;
            this.zeroday[j].zues = f2;
            this.zeroday[j].pandora = (float)(31 + i);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        for (int i = 0; i < this.zeroday.length; ++i) {
            this.zeroday[i].flux = 0.2f * MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.3f + i) + 0.4f;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        GlStateManager.v();
        GlStateManager.zeroday(0.0f, 0.6f, 0.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        ModelRenderer[] zeroday;
        for (int length = (zeroday = this.zeroday).length, i = 0; i < length; ++i) {
            final ModelRenderer modelrenderer = zeroday[i];
            modelrenderer.zerodayisaminecraftcheat(scale);
        }
        GlStateManager.w();
    }
}

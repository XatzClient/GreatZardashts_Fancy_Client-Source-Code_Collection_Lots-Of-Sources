// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.Vec3;
import net.minecraft.client.Minecraft;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.zues.EntityGuardian;
import net.minecraft.vape.Entity;

public class ModelGuardian extends ModelBase
{
    private ModelRenderer zerodayisaminecraftcheat;
    private ModelRenderer zeroday;
    private ModelRenderer[] sigma;
    private ModelRenderer[] pandora;
    
    public ModelGuardian() {
        this.a = 64;
        this.b = 64;
        this.sigma = new ModelRenderer[12];
        this.zerodayisaminecraftcheat = new ModelRenderer(this);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0, 0).zerodayisaminecraftcheat(-6.0f, 10.0f, -8.0f, 12, 12, 16);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0, 28).zerodayisaminecraftcheat(-8.0f, 10.0f, -6.0f, 2, 12, 12);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0, 28).zerodayisaminecraftcheat(6.0f, 10.0f, -6.0f, 2, 12, 12, true);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(16, 40).zerodayisaminecraftcheat(-6.0f, 8.0f, -6.0f, 12, 2, 12);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(16, 40).zerodayisaminecraftcheat(-6.0f, 22.0f, -6.0f, 12, 2, 12);
        for (int i = 0; i < this.sigma.length; ++i) {
            (this.sigma[i] = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-1.0f, -4.5f, -1.0f, 2, 9, 2);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.sigma[i]);
        }
        (this.zeroday = new ModelRenderer(this, 8, 0)).zerodayisaminecraftcheat(-1.0f, 15.0f, 0.0f, 2, 2, 1);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zeroday);
        this.pandora = new ModelRenderer[3];
        (this.pandora[0] = new ModelRenderer(this, 40, 0)).zerodayisaminecraftcheat(-2.0f, 14.0f, 7.0f, 4, 4, 8);
        (this.pandora[1] = new ModelRenderer(this, 0, 54)).zerodayisaminecraftcheat(0.0f, 14.0f, 0.0f, 3, 3, 7);
        this.pandora[2] = new ModelRenderer(this);
        this.pandora[2].zerodayisaminecraftcheat(41, 32).zerodayisaminecraftcheat(0.0f, 14.0f, 0.0f, 2, 2, 6);
        this.pandora[2].zerodayisaminecraftcheat(25, 19).zerodayisaminecraftcheat(1.0f, 10.5f, 3.0f, 1, 9, 9);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.pandora[0]);
        this.pandora[0].zerodayisaminecraftcheat(this.pandora[1]);
        this.pandora[1].zerodayisaminecraftcheat(this.pandora[2]);
    }
    
    public int zerodayisaminecraftcheat() {
        return 54;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        final EntityGuardian entityguardian = (EntityGuardian)entityIn;
        final float f = p_78087_3_ - entityguardian.X;
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
        this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
        final float[] afloat = { 1.75f, 0.25f, 0.0f, 0.0f, 0.5f, 0.5f, 0.5f, 0.5f, 1.25f, 0.75f, 0.0f, 0.0f };
        final float[] afloat2 = { 0.0f, 0.0f, 0.0f, 0.0f, 0.25f, 1.75f, 1.25f, 0.75f, 0.0f, 0.0f, 0.0f, 0.0f };
        final float[] afloat3 = { 0.0f, 0.0f, 0.25f, 1.75f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.75f, 1.25f };
        final float[] afloat4 = { 0.0f, 0.0f, 8.0f, -8.0f, -8.0f, 8.0f, 8.0f, -8.0f, 0.0f, 0.0f, 8.0f, -8.0f };
        final float[] afloat5 = { -8.0f, -8.0f, -8.0f, -8.0f, 0.0f, 0.0f, 0.0f, 0.0f, 8.0f, 8.0f, 8.0f, 8.0f };
        final float[] afloat6 = { 8.0f, -8.0f, 0.0f, 0.0f, -8.0f, -8.0f, 8.0f, 8.0f, 8.0f, -8.0f, 0.0f, 0.0f };
        final float f2 = (1.0f - entityguardian.g(f)) * 0.55f;
        for (int i = 0; i < 12; ++i) {
            this.sigma[i].flux = 3.1415927f * afloat[i];
            this.sigma[i].vape = 3.1415927f * afloat2[i];
            this.sigma[i].momgetthecamera = 3.1415927f * afloat3[i];
            this.sigma[i].sigma = afloat4[i] * (1.0f + MathHelper.zeroday(p_78087_3_ * 1.5f + i) * 0.01f - f2);
            this.sigma[i].pandora = 16.0f + afloat5[i] * (1.0f + MathHelper.zeroday(p_78087_3_ * 1.5f + i) * 0.01f - f2);
            this.sigma[i].zues = afloat6[i] * (1.0f + MathHelper.zeroday(p_78087_3_ * 1.5f + i) * 0.01f - f2);
        }
        this.zeroday.zues = -8.25f;
        Entity entity = Minecraft.s().V();
        if (entityguardian.ce()) {
            entity = entityguardian.cf();
        }
        if (entity != null) {
            final Vec3 vec3 = entity.vape(0.0f);
            final Vec3 vec4 = entityIn.vape(0.0f);
            final double d0 = vec3.zeroday - vec4.zeroday;
            if (d0 > 0.0) {
                this.zeroday.pandora = 0.0f;
            }
            else {
                this.zeroday.pandora = 1.0f;
            }
            Vec3 vec5 = entityIn.flux(0.0f);
            vec5 = new Vec3(vec5.zerodayisaminecraftcheat, 0.0, vec5.sigma);
            final Vec3 vec6 = new Vec3(vec4.zerodayisaminecraftcheat - vec3.zerodayisaminecraftcheat, 0.0, vec4.sigma - vec3.sigma).zerodayisaminecraftcheat().zeroday(1.5707964f);
            final double d2 = vec5.zeroday(vec6);
            this.zeroday.sigma = MathHelper.sigma((float)Math.abs(d2)) * 2.0f * (float)Math.signum(d2);
        }
        this.zeroday.b = true;
        final float f3 = entityguardian.sigma(f);
        this.pandora[0].vape = MathHelper.zerodayisaminecraftcheat(f3) * 3.1415927f * 0.05f;
        this.pandora[1].vape = MathHelper.zerodayisaminecraftcheat(f3) * 3.1415927f * 0.1f;
        this.pandora[1].sigma = -1.5f;
        this.pandora[1].pandora = 0.5f;
        this.pandora[1].zues = 14.0f;
        this.pandora[2].vape = MathHelper.zerodayisaminecraftcheat(f3) * 3.1415927f * 0.15f;
        this.pandora[2].sigma = 0.5f;
        this.pandora[2].pandora = 0.5f;
        this.pandora[2].zues = 6.0f;
    }
}

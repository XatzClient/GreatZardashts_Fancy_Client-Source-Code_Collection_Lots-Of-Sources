// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.flux.EntityHorse;
import net.minecraft.vape.Entity;

public class ModelHorse extends ModelBase
{
    private ModelRenderer zerodayisaminecraftcheat;
    private ModelRenderer zeroday;
    private ModelRenderer sigma;
    private ModelRenderer pandora;
    private ModelRenderer c;
    private ModelRenderer d;
    private ModelRenderer e;
    private ModelRenderer f;
    private ModelRenderer g;
    private ModelRenderer h;
    private ModelRenderer i;
    private ModelRenderer j;
    private ModelRenderer k;
    private ModelRenderer l;
    private ModelRenderer m;
    private ModelRenderer n;
    private ModelRenderer o;
    private ModelRenderer p;
    private ModelRenderer q;
    private ModelRenderer r;
    private ModelRenderer s;
    private ModelRenderer t;
    private ModelRenderer u;
    private ModelRenderer v;
    private ModelRenderer w;
    private ModelRenderer x;
    private ModelRenderer y;
    private ModelRenderer z;
    private ModelRenderer A;
    private ModelRenderer B;
    private ModelRenderer C;
    private ModelRenderer D;
    private ModelRenderer E;
    private ModelRenderer F;
    private ModelRenderer G;
    private ModelRenderer H;
    private ModelRenderer I;
    private ModelRenderer J;
    private ModelRenderer K;
    
    public ModelHorse() {
        this.a = 128;
        this.b = 128;
        (this.i = new ModelRenderer(this, 0, 34)).zerodayisaminecraftcheat(-5.0f, -8.0f, -19.0f, 10, 10, 24);
        this.i.zerodayisaminecraftcheat(0.0f, 11.0f, 9.0f);
        (this.j = new ModelRenderer(this, 44, 0)).zerodayisaminecraftcheat(-1.0f, -1.0f, 0.0f, 2, 2, 3);
        this.j.zerodayisaminecraftcheat(0.0f, 3.0f, 14.0f);
        this.zerodayisaminecraftcheat(this.j, -1.134464f, 0.0f, 0.0f);
        (this.k = new ModelRenderer(this, 38, 7)).zerodayisaminecraftcheat(-1.5f, -2.0f, 3.0f, 3, 4, 7);
        this.k.zerodayisaminecraftcheat(0.0f, 3.0f, 14.0f);
        this.zerodayisaminecraftcheat(this.k, -1.134464f, 0.0f, 0.0f);
        (this.l = new ModelRenderer(this, 24, 3)).zerodayisaminecraftcheat(-1.5f, -4.5f, 9.0f, 3, 4, 7);
        this.l.zerodayisaminecraftcheat(0.0f, 3.0f, 14.0f);
        this.zerodayisaminecraftcheat(this.l, -1.40215f, 0.0f, 0.0f);
        (this.m = new ModelRenderer(this, 78, 29)).zerodayisaminecraftcheat(-2.5f, -2.0f, -2.5f, 4, 9, 5);
        this.m.zerodayisaminecraftcheat(4.0f, 9.0f, 11.0f);
        (this.n = new ModelRenderer(this, 78, 43)).zerodayisaminecraftcheat(-2.0f, 0.0f, -1.5f, 3, 5, 3);
        this.n.zerodayisaminecraftcheat(4.0f, 16.0f, 11.0f);
        (this.o = new ModelRenderer(this, 78, 51)).zerodayisaminecraftcheat(-2.5f, 5.1f, -2.0f, 4, 3, 4);
        this.o.zerodayisaminecraftcheat(4.0f, 16.0f, 11.0f);
        (this.p = new ModelRenderer(this, 96, 29)).zerodayisaminecraftcheat(-1.5f, -2.0f, -2.5f, 4, 9, 5);
        this.p.zerodayisaminecraftcheat(-4.0f, 9.0f, 11.0f);
        (this.q = new ModelRenderer(this, 96, 43)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.5f, 3, 5, 3);
        this.q.zerodayisaminecraftcheat(-4.0f, 16.0f, 11.0f);
        (this.r = new ModelRenderer(this, 96, 51)).zerodayisaminecraftcheat(-1.5f, 5.1f, -2.0f, 4, 3, 4);
        this.r.zerodayisaminecraftcheat(-4.0f, 16.0f, 11.0f);
        (this.s = new ModelRenderer(this, 44, 29)).zerodayisaminecraftcheat(-1.9f, -1.0f, -2.1f, 3, 8, 4);
        this.s.zerodayisaminecraftcheat(4.0f, 9.0f, -8.0f);
        (this.t = new ModelRenderer(this, 44, 41)).zerodayisaminecraftcheat(-1.9f, 0.0f, -1.6f, 3, 5, 3);
        this.t.zerodayisaminecraftcheat(4.0f, 16.0f, -8.0f);
        (this.u = new ModelRenderer(this, 44, 51)).zerodayisaminecraftcheat(-2.4f, 5.1f, -2.1f, 4, 3, 4);
        this.u.zerodayisaminecraftcheat(4.0f, 16.0f, -8.0f);
        (this.v = new ModelRenderer(this, 60, 29)).zerodayisaminecraftcheat(-1.1f, -1.0f, -2.1f, 3, 8, 4);
        this.v.zerodayisaminecraftcheat(-4.0f, 9.0f, -8.0f);
        (this.w = new ModelRenderer(this, 60, 41)).zerodayisaminecraftcheat(-1.1f, 0.0f, -1.6f, 3, 5, 3);
        this.w.zerodayisaminecraftcheat(-4.0f, 16.0f, -8.0f);
        (this.x = new ModelRenderer(this, 60, 51)).zerodayisaminecraftcheat(-1.6f, 5.1f, -2.1f, 4, 3, 4);
        this.x.zerodayisaminecraftcheat(-4.0f, 16.0f, -8.0f);
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-2.5f, -10.0f, -1.5f, 5, 5, 7);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, 0.5235988f, 0.0f, 0.0f);
        (this.zeroday = new ModelRenderer(this, 24, 18)).zerodayisaminecraftcheat(-2.0f, -10.0f, -7.0f, 4, 3, 6);
        this.zeroday.zerodayisaminecraftcheat(0.0f, 3.95f, -10.0f);
        this.zerodayisaminecraftcheat(this.zeroday, 0.5235988f, 0.0f, 0.0f);
        (this.sigma = new ModelRenderer(this, 24, 27)).zerodayisaminecraftcheat(-2.0f, -7.0f, -6.5f, 4, 2, 5);
        this.sigma.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.sigma, 0.5235988f, 0.0f, 0.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zeroday);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.sigma);
        (this.pandora = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(0.45f, -12.0f, 4.0f, 2, 3, 1);
        this.pandora.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.pandora, 0.5235988f, 0.0f, 0.0f);
        (this.c = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-2.45f, -12.0f, 4.0f, 2, 3, 1);
        this.c.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.c, 0.5235988f, 0.0f, 0.0f);
        (this.d = new ModelRenderer(this, 0, 12)).zerodayisaminecraftcheat(-2.0f, -16.0f, 4.0f, 2, 7, 1);
        this.d.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.d, 0.5235988f, 0.0f, 0.2617994f);
        (this.e = new ModelRenderer(this, 0, 12)).zerodayisaminecraftcheat(0.0f, -16.0f, 4.0f, 2, 7, 1);
        this.e.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.e, 0.5235988f, 0.0f, -0.2617994f);
        (this.f = new ModelRenderer(this, 0, 12)).zerodayisaminecraftcheat(-2.05f, -9.8f, -2.0f, 4, 14, 8);
        this.f.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.f, 0.5235988f, 0.0f, 0.0f);
        (this.y = new ModelRenderer(this, 0, 34)).zerodayisaminecraftcheat(-3.0f, 0.0f, 0.0f, 8, 8, 3);
        this.y.zerodayisaminecraftcheat(-7.5f, 3.0f, 10.0f);
        this.zerodayisaminecraftcheat(this.y, 0.0f, 1.5707964f, 0.0f);
        (this.z = new ModelRenderer(this, 0, 47)).zerodayisaminecraftcheat(-3.0f, 0.0f, 0.0f, 8, 8, 3);
        this.z.zerodayisaminecraftcheat(4.5f, 3.0f, 10.0f);
        this.zerodayisaminecraftcheat(this.z, 0.0f, 1.5707964f, 0.0f);
        (this.A = new ModelRenderer(this, 80, 0)).zerodayisaminecraftcheat(-5.0f, 0.0f, -3.0f, 10, 1, 8);
        this.A.zerodayisaminecraftcheat(0.0f, 2.0f, 2.0f);
        (this.B = new ModelRenderer(this, 106, 9)).zerodayisaminecraftcheat(-1.5f, -1.0f, -3.0f, 3, 1, 2);
        this.B.zerodayisaminecraftcheat(0.0f, 2.0f, 2.0f);
        (this.C = new ModelRenderer(this, 80, 9)).zerodayisaminecraftcheat(-4.0f, -1.0f, 3.0f, 8, 1, 2);
        this.C.zerodayisaminecraftcheat(0.0f, 2.0f, 2.0f);
        (this.E = new ModelRenderer(this, 74, 0)).zerodayisaminecraftcheat(-0.5f, 6.0f, -1.0f, 1, 2, 2);
        this.E.zerodayisaminecraftcheat(5.0f, 3.0f, 2.0f);
        (this.D = new ModelRenderer(this, 70, 0)).zerodayisaminecraftcheat(-0.5f, 0.0f, -0.5f, 1, 6, 1);
        this.D.zerodayisaminecraftcheat(5.0f, 3.0f, 2.0f);
        (this.G = new ModelRenderer(this, 74, 4)).zerodayisaminecraftcheat(-0.5f, 6.0f, -1.0f, 1, 2, 2);
        this.G.zerodayisaminecraftcheat(-5.0f, 3.0f, 2.0f);
        (this.F = new ModelRenderer(this, 80, 0)).zerodayisaminecraftcheat(-0.5f, 0.0f, -0.5f, 1, 6, 1);
        this.F.zerodayisaminecraftcheat(-5.0f, 3.0f, 2.0f);
        (this.H = new ModelRenderer(this, 74, 13)).zerodayisaminecraftcheat(1.5f, -8.0f, -4.0f, 1, 2, 2);
        this.H.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.H, 0.5235988f, 0.0f, 0.0f);
        (this.I = new ModelRenderer(this, 74, 13)).zerodayisaminecraftcheat(-2.5f, -8.0f, -4.0f, 1, 2, 2);
        this.I.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.I, 0.5235988f, 0.0f, 0.0f);
        (this.J = new ModelRenderer(this, 44, 10)).zerodayisaminecraftcheat(2.6f, -6.0f, -6.0f, 0, 3, 16);
        this.J.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        (this.K = new ModelRenderer(this, 44, 5)).zerodayisaminecraftcheat(-2.6f, -6.0f, -6.0f, 0, 3, 16);
        this.K.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        (this.h = new ModelRenderer(this, 58, 0)).zerodayisaminecraftcheat(-1.0f, -11.5f, 5.0f, 2, 16, 4);
        this.h.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.h, 0.5235988f, 0.0f, 0.0f);
        (this.g = new ModelRenderer(this, 80, 12)).zerodayisaminecraftcheat(-2.5f, -10.1f, -7.0f, 5, 5, 12, 0.2f);
        this.g.zerodayisaminecraftcheat(0.0f, 4.0f, -10.0f);
        this.zerodayisaminecraftcheat(this.g, 0.5235988f, 0.0f, 0.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        final EntityHorse entityhorse = (EntityHorse)entityIn;
        final int i = entityhorse.cd();
        final float f = entityhorse.g(0.0f);
        final boolean flag = entityhorse.cf();
        final boolean flag2 = flag && entityhorse.cv();
        final boolean flag3 = flag && entityhorse.cl();
        final boolean flag4 = i == 1 || i == 2;
        final float f2 = entityhorse.cj();
        final boolean flag5 = entityhorse.l != null;
        if (flag2) {
            this.g.zerodayisaminecraftcheat(scale);
            this.A.zerodayisaminecraftcheat(scale);
            this.B.zerodayisaminecraftcheat(scale);
            this.C.zerodayisaminecraftcheat(scale);
            this.D.zerodayisaminecraftcheat(scale);
            this.E.zerodayisaminecraftcheat(scale);
            this.F.zerodayisaminecraftcheat(scale);
            this.G.zerodayisaminecraftcheat(scale);
            this.H.zerodayisaminecraftcheat(scale);
            this.I.zerodayisaminecraftcheat(scale);
            if (flag5) {
                this.J.zerodayisaminecraftcheat(scale);
                this.K.zerodayisaminecraftcheat(scale);
            }
        }
        if (!flag) {
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(f2, 0.5f + f2 * 0.5f, f2);
            GlStateManager.zeroday(0.0f, 0.95f * (1.0f - f2), 0.0f);
        }
        this.m.zerodayisaminecraftcheat(scale);
        this.n.zerodayisaminecraftcheat(scale);
        this.o.zerodayisaminecraftcheat(scale);
        this.p.zerodayisaminecraftcheat(scale);
        this.q.zerodayisaminecraftcheat(scale);
        this.r.zerodayisaminecraftcheat(scale);
        this.s.zerodayisaminecraftcheat(scale);
        this.t.zerodayisaminecraftcheat(scale);
        this.u.zerodayisaminecraftcheat(scale);
        this.v.zerodayisaminecraftcheat(scale);
        this.w.zerodayisaminecraftcheat(scale);
        this.x.zerodayisaminecraftcheat(scale);
        if (!flag) {
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(f2, f2, f2);
            GlStateManager.zeroday(0.0f, 1.35f * (1.0f - f2), 0.0f);
        }
        this.i.zerodayisaminecraftcheat(scale);
        this.j.zerodayisaminecraftcheat(scale);
        this.k.zerodayisaminecraftcheat(scale);
        this.l.zerodayisaminecraftcheat(scale);
        this.f.zerodayisaminecraftcheat(scale);
        this.h.zerodayisaminecraftcheat(scale);
        if (!flag) {
            GlStateManager.w();
            GlStateManager.v();
            final float f3 = 0.5f + f2 * f2 * 0.5f;
            GlStateManager.zerodayisaminecraftcheat(f3, f3, f3);
            if (f <= 0.0f) {
                GlStateManager.zeroday(0.0f, 1.35f * (1.0f - f2), 0.0f);
            }
            else {
                GlStateManager.zeroday(0.0f, 0.9f * (1.0f - f2) * f + 1.35f * (1.0f - f2) * (1.0f - f), 0.15f * (1.0f - f2) * f);
            }
        }
        if (flag4) {
            this.d.zerodayisaminecraftcheat(scale);
            this.e.zerodayisaminecraftcheat(scale);
        }
        else {
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
        }
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        if (!flag) {
            GlStateManager.w();
        }
        if (flag3) {
            this.y.zerodayisaminecraftcheat(scale);
            this.z.zerodayisaminecraftcheat(scale);
        }
    }
    
    private void zerodayisaminecraftcheat(final ModelRenderer p_110682_1_, final float p_110682_2_, final float p_110682_3_, final float p_110682_4_) {
        p_110682_1_.flux = p_110682_2_;
        p_110682_1_.vape = p_110682_3_;
        p_110682_1_.momgetthecamera = p_110682_4_;
    }
    
    private float zerodayisaminecraftcheat(final float p_110683_1_, final float p_110683_2_, final float p_110683_3_) {
        float f;
        for (f = p_110683_2_ - p_110683_1_; f < -180.0f; f += 360.0f) {}
        while (f >= 180.0f) {
            f -= 360.0f;
        }
        return p_110683_1_ + p_110683_3_ * f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        super.zerodayisaminecraftcheat(entitylivingbaseIn, p_78086_2_, p_78086_3_, partialTickTime);
        final float f = this.zerodayisaminecraftcheat(entitylivingbaseIn.aM, entitylivingbaseIn.aL, partialTickTime);
        final float f2 = this.zerodayisaminecraftcheat(entitylivingbaseIn.aO, entitylivingbaseIn.aN, partialTickTime);
        final float f3 = entitylivingbaseIn.B + (entitylivingbaseIn.z - entitylivingbaseIn.B) * partialTickTime;
        float f4 = f2 - f;
        float f5 = f3 / 57.295776f;
        if (f4 > 20.0f) {
            f4 = 20.0f;
        }
        if (f4 < -20.0f) {
            f4 = -20.0f;
        }
        if (p_78086_3_ > 0.2f) {
            f5 += MathHelper.zeroday(p_78086_2_ * 0.4f) * 0.15f * p_78086_3_;
        }
        final EntityHorse entityhorse = (EntityHorse)entitylivingbaseIn;
        final float f6 = entityhorse.g(partialTickTime);
        final float f7 = entityhorse.h(partialTickTime);
        final float f8 = 1.0f - f7;
        final float f9 = entityhorse.i(partialTickTime);
        final boolean flag = entityhorse.bm != 0;
        final boolean flag2 = entityhorse.cv();
        final boolean flag3 = entityhorse.l != null;
        final float f10 = entitylivingbaseIn.X + partialTickTime;
        final float f11 = MathHelper.zeroday(p_78086_2_ * 0.6662f + 3.1415927f);
        final float f12 = f11 * 0.8f * p_78086_3_;
        this.zerodayisaminecraftcheat.pandora = 4.0f;
        this.zerodayisaminecraftcheat.zues = -10.0f;
        this.j.pandora = 3.0f;
        this.k.zues = 14.0f;
        this.z.pandora = 3.0f;
        this.z.zues = 10.0f;
        this.i.flux = 0.0f;
        this.zerodayisaminecraftcheat.flux = 0.5235988f + f5;
        this.zerodayisaminecraftcheat.vape = f4 / 57.295776f;
        this.zerodayisaminecraftcheat.flux = f7 * (0.2617994f + f5) + f6 * 2.18166f + (1.0f - Math.max(f7, f6)) * this.zerodayisaminecraftcheat.flux;
        this.zerodayisaminecraftcheat.vape = f7 * f4 / 57.295776f + (1.0f - Math.max(f7, f6)) * this.zerodayisaminecraftcheat.vape;
        this.zerodayisaminecraftcheat.pandora = f7 * -6.0f + f6 * 11.0f + (1.0f - Math.max(f7, f6)) * this.zerodayisaminecraftcheat.pandora;
        this.zerodayisaminecraftcheat.zues = f7 * -1.0f + f6 * -10.0f + (1.0f - Math.max(f7, f6)) * this.zerodayisaminecraftcheat.zues;
        this.j.pandora = f7 * 9.0f + f8 * this.j.pandora;
        this.k.zues = f7 * 18.0f + f8 * this.k.zues;
        this.z.pandora = f7 * 5.5f + f8 * this.z.pandora;
        this.z.zues = f7 * 15.0f + f8 * this.z.zues;
        this.i.flux = f7 * -45.0f / 57.295776f + f8 * this.i.flux;
        this.pandora.pandora = this.zerodayisaminecraftcheat.pandora;
        this.c.pandora = this.zerodayisaminecraftcheat.pandora;
        this.d.pandora = this.zerodayisaminecraftcheat.pandora;
        this.e.pandora = this.zerodayisaminecraftcheat.pandora;
        this.f.pandora = this.zerodayisaminecraftcheat.pandora;
        this.zeroday.pandora = 0.02f;
        this.sigma.pandora = 0.0f;
        this.h.pandora = this.zerodayisaminecraftcheat.pandora;
        this.pandora.zues = this.zerodayisaminecraftcheat.zues;
        this.c.zues = this.zerodayisaminecraftcheat.zues;
        this.d.zues = this.zerodayisaminecraftcheat.zues;
        this.e.zues = this.zerodayisaminecraftcheat.zues;
        this.f.zues = this.zerodayisaminecraftcheat.zues;
        this.zeroday.zues = 0.02f - f9 * 1.0f;
        this.sigma.zues = 0.0f + f9 * 1.0f;
        this.h.zues = this.zerodayisaminecraftcheat.zues;
        this.pandora.flux = this.zerodayisaminecraftcheat.flux;
        this.c.flux = this.zerodayisaminecraftcheat.flux;
        this.d.flux = this.zerodayisaminecraftcheat.flux;
        this.e.flux = this.zerodayisaminecraftcheat.flux;
        this.f.flux = this.zerodayisaminecraftcheat.flux;
        this.zeroday.flux = 0.0f - 0.09424778f * f9;
        this.sigma.flux = 0.0f + 0.15707964f * f9;
        this.h.flux = this.zerodayisaminecraftcheat.flux;
        this.pandora.vape = this.zerodayisaminecraftcheat.vape;
        this.c.vape = this.zerodayisaminecraftcheat.vape;
        this.d.vape = this.zerodayisaminecraftcheat.vape;
        this.e.vape = this.zerodayisaminecraftcheat.vape;
        this.f.vape = this.zerodayisaminecraftcheat.vape;
        this.zeroday.vape = 0.0f;
        this.sigma.vape = 0.0f;
        this.h.vape = this.zerodayisaminecraftcheat.vape;
        this.y.flux = f12 / 5.0f;
        this.z.flux = -f12 / 5.0f;
        float f13 = 1.5707964f;
        final float f14 = 4.712389f;
        final float f15 = -1.0471976f;
        final float f16 = 0.2617994f * f7;
        final float f17 = MathHelper.zeroday(f10 * 0.6f + 3.1415927f);
        this.s.pandora = -2.0f * f7 + 9.0f * f8;
        this.s.zues = -2.0f * f7 + -8.0f * f8;
        this.v.pandora = this.s.pandora;
        this.v.zues = this.s.zues;
        this.n.pandora = this.m.pandora + MathHelper.zerodayisaminecraftcheat(1.5707964f + f16 + f8 * -f11 * 0.5f * p_78086_3_) * 7.0f;
        this.n.zues = this.m.zues + MathHelper.zeroday(4.712389f + f16 + f8 * -f11 * 0.5f * p_78086_3_) * 7.0f;
        this.q.pandora = this.p.pandora + MathHelper.zerodayisaminecraftcheat(1.5707964f + f16 + f8 * f11 * 0.5f * p_78086_3_) * 7.0f;
        this.q.zues = this.p.zues + MathHelper.zeroday(4.712389f + f16 + f8 * f11 * 0.5f * p_78086_3_) * 7.0f;
        final float f18 = (-1.0471976f + f17) * f7 + f12 * f8;
        final float f19 = (-1.0471976f + -f17) * f7 + -f12 * f8;
        this.t.pandora = this.s.pandora + MathHelper.zerodayisaminecraftcheat(1.5707964f + f18) * 7.0f;
        this.t.zues = this.s.zues + MathHelper.zeroday(4.712389f + f18) * 7.0f;
        this.w.pandora = this.v.pandora + MathHelper.zerodayisaminecraftcheat(1.5707964f + f19) * 7.0f;
        this.w.zues = this.v.zues + MathHelper.zeroday(4.712389f + f19) * 7.0f;
        this.m.flux = f16 + -f11 * 0.5f * p_78086_3_ * f8;
        this.n.flux = -0.08726646f * f7 + (-f11 * 0.5f * p_78086_3_ - Math.max(0.0f, f11 * 0.5f * p_78086_3_)) * f8;
        this.o.flux = this.n.flux;
        this.p.flux = f16 + f11 * 0.5f * p_78086_3_ * f8;
        this.q.flux = -0.08726646f * f7 + (f11 * 0.5f * p_78086_3_ - Math.max(0.0f, -f11 * 0.5f * p_78086_3_)) * f8;
        this.r.flux = this.q.flux;
        this.s.flux = f18;
        this.t.flux = (this.s.flux + 3.1415927f * Math.max(0.0f, 0.2f + f17 * 0.2f)) * f7 + (f12 + Math.max(0.0f, f11 * 0.5f * p_78086_3_)) * f8;
        this.u.flux = this.t.flux;
        this.v.flux = f19;
        this.w.flux = (this.v.flux + 3.1415927f * Math.max(0.0f, 0.2f - f17 * 0.2f)) * f7 + (-f12 + Math.max(0.0f, -f11 * 0.5f * p_78086_3_)) * f8;
        this.x.flux = this.w.flux;
        this.o.pandora = this.n.pandora;
        this.o.zues = this.n.zues;
        this.r.pandora = this.q.pandora;
        this.r.zues = this.q.zues;
        this.u.pandora = this.t.pandora;
        this.u.zues = this.t.zues;
        this.x.pandora = this.w.pandora;
        this.x.zues = this.w.zues;
        if (flag2) {
            this.A.pandora = f7 * 0.5f + f8 * 2.0f;
            this.A.zues = f7 * 11.0f + f8 * 2.0f;
            this.B.pandora = this.A.pandora;
            this.C.pandora = this.A.pandora;
            this.D.pandora = this.A.pandora;
            this.F.pandora = this.A.pandora;
            this.E.pandora = this.A.pandora;
            this.G.pandora = this.A.pandora;
            this.y.pandora = this.z.pandora;
            this.B.zues = this.A.zues;
            this.C.zues = this.A.zues;
            this.D.zues = this.A.zues;
            this.F.zues = this.A.zues;
            this.E.zues = this.A.zues;
            this.G.zues = this.A.zues;
            this.y.zues = this.z.zues;
            this.A.flux = this.i.flux;
            this.B.flux = this.i.flux;
            this.C.flux = this.i.flux;
            this.J.pandora = this.zerodayisaminecraftcheat.pandora;
            this.K.pandora = this.zerodayisaminecraftcheat.pandora;
            this.g.pandora = this.zerodayisaminecraftcheat.pandora;
            this.H.pandora = this.zerodayisaminecraftcheat.pandora;
            this.I.pandora = this.zerodayisaminecraftcheat.pandora;
            this.J.zues = this.zerodayisaminecraftcheat.zues;
            this.K.zues = this.zerodayisaminecraftcheat.zues;
            this.g.zues = this.zerodayisaminecraftcheat.zues;
            this.H.zues = this.zerodayisaminecraftcheat.zues;
            this.I.zues = this.zerodayisaminecraftcheat.zues;
            this.J.flux = f5;
            this.K.flux = f5;
            this.g.flux = this.zerodayisaminecraftcheat.flux;
            this.H.flux = this.zerodayisaminecraftcheat.flux;
            this.I.flux = this.zerodayisaminecraftcheat.flux;
            this.g.vape = this.zerodayisaminecraftcheat.vape;
            this.H.vape = this.zerodayisaminecraftcheat.vape;
            this.J.vape = this.zerodayisaminecraftcheat.vape;
            this.I.vape = this.zerodayisaminecraftcheat.vape;
            this.K.vape = this.zerodayisaminecraftcheat.vape;
            if (flag3) {
                this.D.flux = -1.0471976f;
                this.E.flux = -1.0471976f;
                this.F.flux = -1.0471976f;
                this.G.flux = -1.0471976f;
                this.D.momgetthecamera = 0.0f;
                this.E.momgetthecamera = 0.0f;
                this.F.momgetthecamera = 0.0f;
                this.G.momgetthecamera = 0.0f;
            }
            else {
                this.D.flux = f12 / 3.0f;
                this.E.flux = f12 / 3.0f;
                this.F.flux = f12 / 3.0f;
                this.G.flux = f12 / 3.0f;
                this.D.momgetthecamera = f12 / 5.0f;
                this.E.momgetthecamera = f12 / 5.0f;
                this.F.momgetthecamera = -f12 / 5.0f;
                this.G.momgetthecamera = -f12 / 5.0f;
            }
        }
        f13 = -1.3089f + p_78086_3_ * 1.5f;
        if (f13 > 0.0f) {
            f13 = 0.0f;
        }
        if (flag) {
            this.j.vape = MathHelper.zeroday(f10 * 0.7f);
            f13 = 0.0f;
        }
        else {
            this.j.vape = 0.0f;
        }
        this.k.vape = this.j.vape;
        this.l.vape = this.j.vape;
        this.k.pandora = this.j.pandora;
        this.l.pandora = this.j.pandora;
        this.k.zues = this.j.zues;
        this.l.zues = this.j.zues;
        this.j.flux = f13;
        this.k.flux = f13;
        this.l.flux = -0.2618f + f13;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.zues.EntityIronGolem;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.vape.Entity;

public class ModelIronGolem extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    public ModelRenderer d;
    
    public ModelIronGolem() {
        this(0.0f);
    }
    
    public ModelIronGolem(final float p_i1161_1_) {
        this(p_i1161_1_, -7.0f);
    }
    
    public ModelIronGolem(final float p_i46362_1_, final float p_i46362_2_) {
        final int i = 128;
        final int j = 128;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this).zeroday(i, j)).zerodayisaminecraftcheat(0.0f, 0.0f + p_i46362_2_, -2.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0, 0).zerodayisaminecraftcheat(-4.0f, -12.0f, -5.5f, 8, 10, 8, p_i46362_1_);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(24, 0).zerodayisaminecraftcheat(-1.0f, -5.0f, -7.5f, 2, 4, 2, p_i46362_1_);
        (this.zeroday = new ModelRenderer(this).zeroday(i, j)).zerodayisaminecraftcheat(0.0f, 0.0f + p_i46362_2_, 0.0f);
        this.zeroday.zerodayisaminecraftcheat(0, 40).zerodayisaminecraftcheat(-9.0f, -2.0f, -6.0f, 18, 12, 11, p_i46362_1_);
        this.zeroday.zerodayisaminecraftcheat(0, 70).zerodayisaminecraftcheat(-4.5f, 10.0f, -3.0f, 9, 5, 6, p_i46362_1_ + 0.5f);
        (this.sigma = new ModelRenderer(this).zeroday(i, j)).zerodayisaminecraftcheat(0.0f, -7.0f, 0.0f);
        this.sigma.zerodayisaminecraftcheat(60, 21).zerodayisaminecraftcheat(-13.0f, -2.5f, -3.0f, 4, 30, 6, p_i46362_1_);
        (this.pandora = new ModelRenderer(this).zeroday(i, j)).zerodayisaminecraftcheat(0.0f, -7.0f, 0.0f);
        this.pandora.zerodayisaminecraftcheat(60, 58).zerodayisaminecraftcheat(9.0f, -2.5f, -3.0f, 4, 30, 6, p_i46362_1_);
        (this.c = new ModelRenderer(this, 0, 22).zeroday(i, j)).zerodayisaminecraftcheat(-4.0f, 18.0f + p_i46362_2_, 0.0f);
        this.c.zerodayisaminecraftcheat(37, 0).zerodayisaminecraftcheat(-3.5f, -3.0f, -3.0f, 6, 16, 5, p_i46362_1_);
        this.d = new ModelRenderer(this, 0, 22).zeroday(i, j);
        this.d.a = true;
        this.d.zerodayisaminecraftcheat(60, 0).zerodayisaminecraftcheat(5.0f, 18.0f + p_i46362_2_, 0.0f);
        this.d.zerodayisaminecraftcheat(-3.5f, -3.0f, -3.0f, 6, 16, 5, p_i46362_1_);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        this.zeroday.zerodayisaminecraftcheat(scale);
        this.c.zerodayisaminecraftcheat(scale);
        this.d.zerodayisaminecraftcheat(scale);
        this.sigma.zerodayisaminecraftcheat(scale);
        this.pandora.zerodayisaminecraftcheat(scale);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
        this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
        this.c.flux = -1.5f * this.zerodayisaminecraftcheat(p_78087_1_, 13.0f) * p_78087_2_;
        this.d.flux = 1.5f * this.zerodayisaminecraftcheat(p_78087_1_, 13.0f) * p_78087_2_;
        this.c.vape = 0.0f;
        this.d.vape = 0.0f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        final EntityIronGolem entityirongolem = (EntityIronGolem)entitylivingbaseIn;
        final int i = entityirongolem.ca();
        if (i > 0) {
            this.sigma.flux = -2.0f + 1.5f * this.zerodayisaminecraftcheat(i - partialTickTime, 10.0f);
            this.pandora.flux = -2.0f + 1.5f * this.zerodayisaminecraftcheat(i - partialTickTime, 10.0f);
        }
        else {
            final int j = entityirongolem.cb();
            if (j > 0) {
                this.sigma.flux = -0.8f + 0.025f * this.zerodayisaminecraftcheat((float)j, 70.0f);
                this.pandora.flux = 0.0f;
            }
            else {
                this.sigma.flux = (-0.2f + 1.5f * this.zerodayisaminecraftcheat(p_78086_2_, 13.0f)) * p_78086_3_;
                this.pandora.flux = (-0.2f - 1.5f * this.zerodayisaminecraftcheat(p_78086_2_, 13.0f)) * p_78086_3_;
            }
        }
    }
    
    private float zerodayisaminecraftcheat(final float p_78172_1_, final float p_78172_2_) {
        return (Math.abs(p_78172_1_ % p_78172_2_ - p_78172_2_ * 0.5f) - p_78172_2_ * 0.25f) / (p_78172_2_ * 0.25f);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

public class ModelLargeChest extends ModelChest
{
    public ModelLargeChest() {
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0).zeroday(128, 64)).zerodayisaminecraftcheat(0.0f, -5.0f, -14.0f, 30, 5, 14, 0.0f);
        this.zerodayisaminecraftcheat.sigma = 1.0f;
        this.zerodayisaminecraftcheat.pandora = 7.0f;
        this.zerodayisaminecraftcheat.zues = 15.0f;
        (this.sigma = new ModelRenderer(this, 0, 0).zeroday(128, 64)).zerodayisaminecraftcheat(-1.0f, -2.0f, -15.0f, 2, 4, 1, 0.0f);
        this.sigma.sigma = 16.0f;
        this.sigma.pandora = 7.0f;
        this.sigma.zues = 15.0f;
        (this.zeroday = new ModelRenderer(this, 0, 19).zeroday(128, 64)).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 30, 10, 14, 0.0f);
        this.zeroday.sigma = 1.0f;
        this.zeroday.pandora = 6.0f;
        this.zeroday.zues = 1.0f;
    }
}

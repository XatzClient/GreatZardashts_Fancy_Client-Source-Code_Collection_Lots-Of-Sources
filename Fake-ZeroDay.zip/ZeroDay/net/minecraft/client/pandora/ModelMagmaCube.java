// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.zues.EntityMagmaCube;
import net.minecraft.vape.EntityLivingBase;

public class ModelMagmaCube extends ModelBase
{
    ModelRenderer[] zerodayisaminecraftcheat;
    ModelRenderer zeroday;
    
    public ModelMagmaCube() {
        this.zerodayisaminecraftcheat = new ModelRenderer[8];
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            int j = 0;
            int k;
            if ((k = i) == 2) {
                j = 24;
                k = 10;
            }
            else if (i == 3) {
                j = 24;
                k = 19;
            }
            (this.zerodayisaminecraftcheat[i] = new ModelRenderer(this, j, k)).zerodayisaminecraftcheat(-4.0f, (float)(16 + i), -4.0f, 8, 1, 8);
        }
        (this.zeroday = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 18.0f, -2.0f, 4, 4, 4);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        final EntityMagmaCube entitymagmacube = (EntityMagmaCube)entitylivingbaseIn;
        float f = entitymagmacube.sigma + (entitymagmacube.zeroday - entitymagmacube.sigma) * partialTickTime;
        if (f < 0.0f) {
            f = 0.0f;
        }
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            this.zerodayisaminecraftcheat[i].pandora = -(4 - i) * f * 1.7f;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zeroday.zerodayisaminecraftcheat(scale);
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            this.zerodayisaminecraftcheat[i].zerodayisaminecraftcheat(scale);
        }
    }
}

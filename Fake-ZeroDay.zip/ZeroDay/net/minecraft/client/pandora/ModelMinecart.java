// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.Entity;

public class ModelMinecart extends ModelBase
{
    public ModelRenderer[] zerodayisaminecraftcheat;
    
    public ModelMinecart() {
        (this.zerodayisaminecraftcheat = new ModelRenderer[7])[0] = new ModelRenderer(this, 0, 10);
        this.zerodayisaminecraftcheat[1] = new ModelRenderer(this, 0, 0);
        this.zerodayisaminecraftcheat[2] = new ModelRenderer(this, 0, 0);
        this.zerodayisaminecraftcheat[3] = new ModelRenderer(this, 0, 0);
        this.zerodayisaminecraftcheat[4] = new ModelRenderer(this, 0, 0);
        this.zerodayisaminecraftcheat[5] = new ModelRenderer(this, 44, 10);
        final int i = 20;
        final int j = 8;
        final int k = 16;
        final int l = 4;
        this.zerodayisaminecraftcheat[0].zerodayisaminecraftcheat((float)(-i / 2), (float)(-k / 2), -1.0f, i, k, 2, 0.0f);
        this.zerodayisaminecraftcheat[0].zerodayisaminecraftcheat(0.0f, (float)l, 0.0f);
        this.zerodayisaminecraftcheat[5].zerodayisaminecraftcheat((float)(-i / 2 + 1), (float)(-k / 2 + 1), -1.0f, i - 2, k - 2, 1, 0.0f);
        this.zerodayisaminecraftcheat[5].zerodayisaminecraftcheat(0.0f, (float)l, 0.0f);
        this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat((float)(-i / 2 + 2), (float)(-j - 1), -1.0f, i - 4, j, 2, 0.0f);
        this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat((float)(-i / 2 + 1), (float)l, 0.0f);
        this.zerodayisaminecraftcheat[2].zerodayisaminecraftcheat((float)(-i / 2 + 2), (float)(-j - 1), -1.0f, i - 4, j, 2, 0.0f);
        this.zerodayisaminecraftcheat[2].zerodayisaminecraftcheat((float)(i / 2 - 1), (float)l, 0.0f);
        this.zerodayisaminecraftcheat[3].zerodayisaminecraftcheat((float)(-i / 2 + 2), (float)(-j - 1), -1.0f, i - 4, j, 2, 0.0f);
        this.zerodayisaminecraftcheat[3].zerodayisaminecraftcheat(0.0f, (float)l, (float)(-k / 2 + 1));
        this.zerodayisaminecraftcheat[4].zerodayisaminecraftcheat((float)(-i / 2 + 2), (float)(-j - 1), -1.0f, i - 4, j, 2, 0.0f);
        this.zerodayisaminecraftcheat[4].zerodayisaminecraftcheat(0.0f, (float)l, (float)(k / 2 - 1));
        this.zerodayisaminecraftcheat[0].flux = 1.5707964f;
        this.zerodayisaminecraftcheat[1].vape = 4.712389f;
        this.zerodayisaminecraftcheat[2].vape = 1.5707964f;
        this.zerodayisaminecraftcheat[3].vape = 3.1415927f;
        this.zerodayisaminecraftcheat[5].flux = -1.5707964f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat[5].pandora = 4.0f - p_78088_4_;
        for (int i = 0; i < 6; ++i) {
            this.zerodayisaminecraftcheat[i].zerodayisaminecraftcheat(scale);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.flux.EntityOcelot;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelOcelot extends ModelBase
{
    ModelRenderer zerodayisaminecraftcheat;
    ModelRenderer zeroday;
    ModelRenderer sigma;
    ModelRenderer pandora;
    ModelRenderer c;
    ModelRenderer d;
    ModelRenderer e;
    ModelRenderer f;
    int g;
    
    public ModelOcelot() {
        this.g = 1;
        this.zerodayisaminecraftcheat("head.main", 0, 0);
        this.zerodayisaminecraftcheat("head.nose", 0, 24);
        this.zerodayisaminecraftcheat("head.ear1", 0, 10);
        this.zerodayisaminecraftcheat("head.ear2", 6, 10);
        (this.e = new ModelRenderer(this, "head")).zerodayisaminecraftcheat("main", -2.5f, -2.0f, -3.0f, 5, 4, 5);
        this.e.zerodayisaminecraftcheat("nose", -1.5f, 0.0f, -4.0f, 3, 2, 2);
        this.e.zerodayisaminecraftcheat("ear1", -2.0f, -3.0f, 0.0f, 1, 1, 2);
        this.e.zerodayisaminecraftcheat("ear2", 1.0f, -3.0f, 0.0f, 1, 1, 2);
        this.e.zerodayisaminecraftcheat(0.0f, 15.0f, -9.0f);
        (this.f = new ModelRenderer(this, 20, 0)).zerodayisaminecraftcheat(-2.0f, 3.0f, -8.0f, 4, 16, 6, 0.0f);
        this.f.zerodayisaminecraftcheat(0.0f, 12.0f, -10.0f);
        (this.c = new ModelRenderer(this, 0, 15)).zerodayisaminecraftcheat(-0.5f, 0.0f, 0.0f, 1, 8, 1);
        this.c.flux = 0.9f;
        this.c.zerodayisaminecraftcheat(0.0f, 15.0f, 8.0f);
        (this.d = new ModelRenderer(this, 4, 15)).zerodayisaminecraftcheat(-0.5f, 0.0f, 0.0f, 1, 8, 1);
        this.d.zerodayisaminecraftcheat(0.0f, 20.0f, 14.0f);
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 8, 13)).zerodayisaminecraftcheat(-1.0f, 0.0f, 1.0f, 2, 6, 2);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(1.1f, 18.0f, 5.0f);
        (this.zeroday = new ModelRenderer(this, 8, 13)).zerodayisaminecraftcheat(-1.0f, 0.0f, 1.0f, 2, 6, 2);
        this.zeroday.zerodayisaminecraftcheat(-1.1f, 18.0f, 5.0f);
        (this.sigma = new ModelRenderer(this, 40, 0)).zerodayisaminecraftcheat(-1.0f, 0.0f, 0.0f, 2, 10, 2);
        this.sigma.zerodayisaminecraftcheat(1.2f, 13.8f, -5.0f);
        (this.pandora = new ModelRenderer(this, 40, 0)).zerodayisaminecraftcheat(-1.0f, 0.0f, 0.0f, 2, 10, 2);
        this.pandora.zerodayisaminecraftcheat(-1.2f, 13.8f, -5.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.5f / f, 1.5f / f, 1.5f / f);
            GlStateManager.zeroday(0.0f, 10.0f * scale, 4.0f * scale);
            this.e.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.f.zerodayisaminecraftcheat(scale);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
        }
        else {
            this.e.zerodayisaminecraftcheat(scale);
            this.f.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        this.e.flux = p_78087_5_ / 57.295776f;
        this.e.vape = p_78087_4_ / 57.295776f;
        if (this.g != 3) {
            this.f.flux = 1.5707964f;
            if (this.g == 2) {
                this.zerodayisaminecraftcheat.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.0f * p_78087_2_;
                this.zeroday.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 0.3f) * 1.0f * p_78087_2_;
                this.sigma.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f + 0.3f) * 1.0f * p_78087_2_;
                this.pandora.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.0f * p_78087_2_;
                this.d.flux = 1.7278761f + 0.31415927f * MathHelper.zeroday(p_78087_1_) * p_78087_2_;
            }
            else {
                this.zerodayisaminecraftcheat.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.0f * p_78087_2_;
                this.zeroday.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.0f * p_78087_2_;
                this.sigma.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.0f * p_78087_2_;
                this.pandora.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.0f * p_78087_2_;
                if (this.g == 1) {
                    this.d.flux = 1.7278761f + 0.7853982f * MathHelper.zeroday(p_78087_1_) * p_78087_2_;
                }
                else {
                    this.d.flux = 1.7278761f + 0.47123894f * MathHelper.zeroday(p_78087_1_) * p_78087_2_;
                }
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        final EntityOcelot entityocelot = (EntityOcelot)entitylivingbaseIn;
        this.f.pandora = 12.0f;
        this.f.zues = -10.0f;
        this.e.pandora = 15.0f;
        this.e.zues = -9.0f;
        this.c.pandora = 15.0f;
        this.c.zues = 8.0f;
        this.d.pandora = 20.0f;
        this.d.zues = 14.0f;
        final ModelRenderer sigma = this.sigma;
        final ModelRenderer pandora = this.pandora;
        final float n = 13.8f;
        pandora.pandora = n;
        sigma.pandora = n;
        final ModelRenderer sigma2 = this.sigma;
        final ModelRenderer pandora2 = this.pandora;
        final float n2 = -5.0f;
        pandora2.zues = n2;
        sigma2.zues = n2;
        final ModelRenderer zerodayisaminecraftcheat = this.zerodayisaminecraftcheat;
        final ModelRenderer zeroday = this.zeroday;
        final float n3 = 18.0f;
        zeroday.pandora = n3;
        zerodayisaminecraftcheat.pandora = n3;
        final ModelRenderer zerodayisaminecraftcheat2 = this.zerodayisaminecraftcheat;
        final ModelRenderer zeroday2 = this.zeroday;
        final float n4 = 5.0f;
        zeroday2.zues = n4;
        zerodayisaminecraftcheat2.zues = n4;
        this.c.flux = 0.9f;
        if (entityocelot.y()) {
            final ModelRenderer f = this.f;
            ++f.pandora;
            final ModelRenderer e = this.e;
            e.pandora += 2.0f;
            final ModelRenderer c = this.c;
            ++c.pandora;
            final ModelRenderer d = this.d;
            d.pandora -= 4.0f;
            final ModelRenderer d2 = this.d;
            d2.zues += 2.0f;
            this.c.flux = 1.5707964f;
            this.d.flux = 1.5707964f;
            this.g = 0;
        }
        else if (entityocelot.ao()) {
            this.d.pandora = this.c.pandora;
            final ModelRenderer d3 = this.d;
            d3.zues += 2.0f;
            this.c.flux = 1.5707964f;
            this.d.flux = 1.5707964f;
            this.g = 2;
        }
        else if (entityocelot.cg()) {
            this.f.flux = 0.7853982f;
            final ModelRenderer f2 = this.f;
            f2.pandora -= 4.0f;
            final ModelRenderer f3 = this.f;
            f3.zues += 5.0f;
            final ModelRenderer e2 = this.e;
            e2.pandora -= 3.3f;
            final ModelRenderer e3 = this.e;
            ++e3.zues;
            final ModelRenderer c2 = this.c;
            c2.pandora += 8.0f;
            final ModelRenderer c3 = this.c;
            c3.zues -= 2.0f;
            final ModelRenderer d4 = this.d;
            d4.pandora += 2.0f;
            final ModelRenderer d5 = this.d;
            d5.zues -= 0.8f;
            this.c.flux = 1.7278761f;
            this.d.flux = 2.670354f;
            final ModelRenderer sigma3 = this.sigma;
            final ModelRenderer pandora3 = this.pandora;
            final float n5 = -0.15707964f;
            pandora3.flux = n5;
            sigma3.flux = n5;
            final ModelRenderer sigma4 = this.sigma;
            final ModelRenderer pandora4 = this.pandora;
            final float n6 = 15.8f;
            pandora4.pandora = n6;
            sigma4.pandora = n6;
            final ModelRenderer sigma5 = this.sigma;
            final ModelRenderer pandora5 = this.pandora;
            final float n7 = -7.0f;
            pandora5.zues = n7;
            sigma5.zues = n7;
            final ModelRenderer zerodayisaminecraftcheat3 = this.zerodayisaminecraftcheat;
            final ModelRenderer zeroday3 = this.zeroday;
            final float n8 = -1.5707964f;
            zeroday3.flux = n8;
            zerodayisaminecraftcheat3.flux = n8;
            final ModelRenderer zerodayisaminecraftcheat4 = this.zerodayisaminecraftcheat;
            final ModelRenderer zeroday4 = this.zeroday;
            final float n9 = 21.0f;
            zeroday4.pandora = n9;
            zerodayisaminecraftcheat4.pandora = n9;
            final ModelRenderer zerodayisaminecraftcheat5 = this.zerodayisaminecraftcheat;
            final ModelRenderer zeroday5 = this.zeroday;
            final float n10 = 1.0f;
            zeroday5.zues = n10;
            zerodayisaminecraftcheat5.zues = n10;
            this.g = 3;
        }
        else {
            this.g = 1;
        }
    }
}

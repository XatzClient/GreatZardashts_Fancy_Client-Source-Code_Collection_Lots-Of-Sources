// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelPlayer extends ModelBiped
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer n;
    private ModelRenderer o;
    private ModelRenderer p;
    private boolean q;
    
    public ModelPlayer(final float p_i46304_1_, final boolean p_i46304_2_) {
        super(p_i46304_1_, 0.0f, 64, 64);
        this.q = p_i46304_2_;
        (this.p = new ModelRenderer(this, 24, 0)).zerodayisaminecraftcheat(-3.0f, -6.0f, -1.0f, 6, 6, 1, p_i46304_1_);
        (this.o = new ModelRenderer(this, 0, 0)).zeroday(64, 32);
        this.o.zerodayisaminecraftcheat(-5.0f, 0.0f, -1.0f, 10, 16, 1, p_i46304_1_);
        if (p_i46304_2_) {
            (this.g = new ModelRenderer(this, 32, 48)).zerodayisaminecraftcheat(-1.0f, -2.0f, -2.0f, 3, 12, 4, p_i46304_1_);
            this.g.zerodayisaminecraftcheat(5.0f, 2.5f, 0.0f);
            (this.f = new ModelRenderer(this, 40, 16)).zerodayisaminecraftcheat(-2.0f, -2.0f, -2.0f, 3, 12, 4, p_i46304_1_);
            this.f.zerodayisaminecraftcheat(-5.0f, 2.5f, 0.0f);
            (this.zerodayisaminecraftcheat = new ModelRenderer(this, 48, 48)).zerodayisaminecraftcheat(-1.0f, -2.0f, -2.0f, 3, 12, 4, p_i46304_1_ + 0.25f);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(5.0f, 2.5f, 0.0f);
            (this.zeroday = new ModelRenderer(this, 40, 32)).zerodayisaminecraftcheat(-2.0f, -2.0f, -2.0f, 3, 12, 4, p_i46304_1_ + 0.25f);
            this.zeroday.zerodayisaminecraftcheat(-5.0f, 2.5f, 10.0f);
        }
        else {
            (this.g = new ModelRenderer(this, 32, 48)).zerodayisaminecraftcheat(-1.0f, -2.0f, -2.0f, 4, 12, 4, p_i46304_1_);
            this.g.zerodayisaminecraftcheat(5.0f, 2.0f, 0.0f);
            (this.zerodayisaminecraftcheat = new ModelRenderer(this, 48, 48)).zerodayisaminecraftcheat(-1.0f, -2.0f, -2.0f, 4, 12, 4, p_i46304_1_ + 0.25f);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(5.0f, 2.0f, 0.0f);
            (this.zeroday = new ModelRenderer(this, 40, 32)).zerodayisaminecraftcheat(-3.0f, -2.0f, -2.0f, 4, 12, 4, p_i46304_1_ + 0.25f);
            this.zeroday.zerodayisaminecraftcheat(-5.0f, 2.0f, 10.0f);
        }
        (this.i = new ModelRenderer(this, 16, 48)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 12, 4, p_i46304_1_);
        this.i.zerodayisaminecraftcheat(1.9f, 12.0f, 0.0f);
        (this.sigma = new ModelRenderer(this, 0, 48)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 12, 4, p_i46304_1_ + 0.25f);
        this.sigma.zerodayisaminecraftcheat(1.9f, 12.0f, 0.0f);
        (this.pandora = new ModelRenderer(this, 0, 32)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 12, 4, p_i46304_1_ + 0.25f);
        this.pandora.zerodayisaminecraftcheat(-1.9f, 12.0f, 0.0f);
        (this.n = new ModelRenderer(this, 16, 32)).zerodayisaminecraftcheat(-4.0f, 0.0f, -2.0f, 8, 12, 4, p_i46304_1_ + 0.25f);
        this.n.zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        super.zerodayisaminecraftcheat(entityIn, p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale);
        GlStateManager.v();
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.n.zerodayisaminecraftcheat(scale);
        }
        else {
            if (entityIn.y()) {
                GlStateManager.zeroday(0.0f, 0.2f, 0.0f);
            }
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.n.zerodayisaminecraftcheat(scale);
        }
        GlStateManager.w();
    }
    
    public void zeroday(final float p_178727_1_) {
        ModelBase.zerodayisaminecraftcheat(this.c, this.p);
        this.p.sigma = 0.0f;
        this.p.pandora = 0.0f;
        this.p.zerodayisaminecraftcheat(p_178727_1_);
    }
    
    public void sigma(final float p_178728_1_) {
        this.o.zerodayisaminecraftcheat(p_178728_1_);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        ModelBase.zerodayisaminecraftcheat(this.i, this.sigma);
        ModelBase.zerodayisaminecraftcheat(this.h, this.pandora);
        ModelBase.zerodayisaminecraftcheat(this.g, this.zerodayisaminecraftcheat);
        ModelBase.zerodayisaminecraftcheat(this.f, this.zeroday);
        ModelBase.zerodayisaminecraftcheat(this.e, this.n);
        if (entityIn.y()) {
            this.o.pandora = 2.0f;
        }
        else {
            this.o.pandora = 0.0f;
        }
    }
    
    public void zerodayisaminecraftcheat() {
        this.f.zerodayisaminecraftcheat(0.0625f);
        this.zeroday.zerodayisaminecraftcheat(0.0625f);
    }
    
    public void zeroday() {
        this.g.zerodayisaminecraftcheat(0.0625f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0625f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean invisible) {
        super.zerodayisaminecraftcheat(invisible);
        this.zerodayisaminecraftcheat.b = invisible;
        this.zeroday.b = invisible;
        this.sigma.b = invisible;
        this.pandora.b = invisible;
        this.n.b = invisible;
        this.o.b = invisible;
        this.p.b = invisible;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float scale) {
        if (this.q) {
            final ModelRenderer f = this.f;
            ++f.sigma;
            this.f.sigma(scale);
            final ModelRenderer f2 = this.f;
            --f2.sigma;
        }
        else {
            this.f.sigma(scale);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelQuadruped extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    public ModelRenderer d;
    protected float e;
    protected float f;
    
    public ModelQuadruped(final int p_i1154_1_, final float p_i1154_2_) {
        this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0);
        this.e = 8.0f;
        this.f = 4.0f;
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(-4.0f, -4.0f, -8.0f, 8, 8, 8, p_i1154_2_);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, (float)(18 - p_i1154_1_), -6.0f);
        (this.zeroday = new ModelRenderer(this, 28, 8)).zerodayisaminecraftcheat(-5.0f, -10.0f, -7.0f, 10, 16, 8, p_i1154_2_);
        this.zeroday.zerodayisaminecraftcheat(0.0f, (float)(17 - p_i1154_1_), 2.0f);
        (this.sigma = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, p_i1154_1_, 4, p_i1154_2_);
        this.sigma.zerodayisaminecraftcheat(-3.0f, (float)(24 - p_i1154_1_), 7.0f);
        (this.pandora = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, p_i1154_1_, 4, p_i1154_2_);
        this.pandora.zerodayisaminecraftcheat(3.0f, (float)(24 - p_i1154_1_), 7.0f);
        (this.c = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, p_i1154_1_, 4, p_i1154_2_);
        this.c.zerodayisaminecraftcheat(-3.0f, (float)(24 - p_i1154_1_), -5.0f);
        (this.d = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, p_i1154_1_, 4, p_i1154_2_);
        this.d.zerodayisaminecraftcheat(3.0f, (float)(24 - p_i1154_1_), -5.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, this.e * scale, this.f * scale);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
        }
        else {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        final float f = 57.295776f;
        this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
        this.zeroday.flux = 1.5707964f;
        this.sigma.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.4f * p_78087_2_;
        this.pandora.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.4f * p_78087_2_;
        this.c.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.4f * p_78087_2_;
        this.d.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.4f * p_78087_2_;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.flux.EntityRabbit;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelRabbit extends ModelBase
{
    ModelRenderer zerodayisaminecraftcheat;
    ModelRenderer zeroday;
    ModelRenderer sigma;
    ModelRenderer pandora;
    ModelRenderer c;
    ModelRenderer d;
    ModelRenderer e;
    ModelRenderer f;
    ModelRenderer g;
    ModelRenderer h;
    ModelRenderer i;
    ModelRenderer j;
    private float k;
    private float l;
    
    public ModelRabbit() {
        this.k = 0.0f;
        this.l = 0.0f;
        this.zerodayisaminecraftcheat("head.main", 0, 0);
        this.zerodayisaminecraftcheat("head.nose", 0, 24);
        this.zerodayisaminecraftcheat("head.ear1", 0, 10);
        this.zerodayisaminecraftcheat("head.ear2", 6, 10);
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 26, 24)).zerodayisaminecraftcheat(-1.0f, 5.5f, -3.7f, 2, 1, 7);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(3.0f, 17.5f, 3.7f);
        this.zerodayisaminecraftcheat.a = true;
        this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, 0.0f, 0.0f, 0.0f);
        (this.zeroday = new ModelRenderer(this, 8, 24)).zerodayisaminecraftcheat(-1.0f, 5.5f, -3.7f, 2, 1, 7);
        this.zeroday.zerodayisaminecraftcheat(-3.0f, 17.5f, 3.7f);
        this.zeroday.a = true;
        this.zerodayisaminecraftcheat(this.zeroday, 0.0f, 0.0f, 0.0f);
        (this.sigma = new ModelRenderer(this, 30, 15)).zerodayisaminecraftcheat(-1.0f, 0.0f, 0.0f, 2, 4, 5);
        this.sigma.zerodayisaminecraftcheat(3.0f, 17.5f, 3.7f);
        this.sigma.a = true;
        this.zerodayisaminecraftcheat(this.sigma, -0.34906584f, 0.0f, 0.0f);
        (this.pandora = new ModelRenderer(this, 16, 15)).zerodayisaminecraftcheat(-1.0f, 0.0f, 0.0f, 2, 4, 5);
        this.pandora.zerodayisaminecraftcheat(-3.0f, 17.5f, 3.7f);
        this.pandora.a = true;
        this.zerodayisaminecraftcheat(this.pandora, -0.34906584f, 0.0f, 0.0f);
        (this.c = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-3.0f, -2.0f, -10.0f, 6, 5, 10);
        this.c.zerodayisaminecraftcheat(0.0f, 19.0f, 8.0f);
        this.c.a = true;
        this.zerodayisaminecraftcheat(this.c, -0.34906584f, 0.0f, 0.0f);
        (this.d = new ModelRenderer(this, 8, 15)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 7, 2);
        this.d.zerodayisaminecraftcheat(3.0f, 17.0f, -1.0f);
        this.d.a = true;
        this.zerodayisaminecraftcheat(this.d, -0.17453292f, 0.0f, 0.0f);
        (this.e = new ModelRenderer(this, 0, 15)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 7, 2);
        this.e.zerodayisaminecraftcheat(-3.0f, 17.0f, -1.0f);
        this.e.a = true;
        this.zerodayisaminecraftcheat(this.e, -0.17453292f, 0.0f, 0.0f);
        (this.f = new ModelRenderer(this, 32, 0)).zerodayisaminecraftcheat(-2.5f, -4.0f, -5.0f, 5, 4, 5);
        this.f.zerodayisaminecraftcheat(0.0f, 16.0f, -1.0f);
        this.f.a = true;
        this.zerodayisaminecraftcheat(this.f, 0.0f, 0.0f, 0.0f);
        (this.g = new ModelRenderer(this, 52, 0)).zerodayisaminecraftcheat(-2.5f, -9.0f, -1.0f, 2, 5, 1);
        this.g.zerodayisaminecraftcheat(0.0f, 16.0f, -1.0f);
        this.g.a = true;
        this.zerodayisaminecraftcheat(this.g, 0.0f, -0.2617994f, 0.0f);
        (this.h = new ModelRenderer(this, 58, 0)).zerodayisaminecraftcheat(0.5f, -9.0f, -1.0f, 2, 5, 1);
        this.h.zerodayisaminecraftcheat(0.0f, 16.0f, -1.0f);
        this.h.a = true;
        this.zerodayisaminecraftcheat(this.h, 0.0f, 0.2617994f, 0.0f);
        (this.i = new ModelRenderer(this, 52, 6)).zerodayisaminecraftcheat(-1.5f, -1.5f, 0.0f, 3, 3, 2);
        this.i.zerodayisaminecraftcheat(0.0f, 20.0f, 7.0f);
        this.i.a = true;
        this.zerodayisaminecraftcheat(this.i, -0.3490659f, 0.0f, 0.0f);
        (this.j = new ModelRenderer(this, 32, 9)).zerodayisaminecraftcheat(-0.5f, -2.5f, -5.5f, 1, 1, 1);
        this.j.zerodayisaminecraftcheat(0.0f, 16.0f, -1.0f);
        this.j.a = true;
        this.zerodayisaminecraftcheat(this.j, 0.0f, 0.0f, 0.0f);
    }
    
    private void zerodayisaminecraftcheat(final ModelRenderer p_178691_1_, final float p_178691_2_, final float p_178691_3_, final float p_178691_4_) {
        p_178691_1_.flux = p_178691_2_;
        p_178691_1_.vape = p_178691_3_;
        p_178691_1_.momgetthecamera = p_178691_4_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, 5.0f * scale, 2.0f * scale);
            this.f.zerodayisaminecraftcheat(scale);
            this.h.zerodayisaminecraftcheat(scale);
            this.g.zerodayisaminecraftcheat(scale);
            this.j.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            this.e.zerodayisaminecraftcheat(scale);
            this.i.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
        }
        else {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            this.e.zerodayisaminecraftcheat(scale);
            this.f.zerodayisaminecraftcheat(scale);
            this.g.zerodayisaminecraftcheat(scale);
            this.h.zerodayisaminecraftcheat(scale);
            this.i.zerodayisaminecraftcheat(scale);
            this.j.zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        final float f = p_78087_3_ - entityIn.X;
        final EntityRabbit entityrabbit = (EntityRabbit)entityIn;
        final ModelRenderer j = this.j;
        final ModelRenderer f2 = this.f;
        final ModelRenderer g = this.g;
        final ModelRenderer h = this.h;
        final float n = p_78087_5_ * 0.017453292f;
        h.flux = n;
        g.flux = n;
        f2.flux = n;
        j.flux = n;
        final ModelRenderer i = this.j;
        final ModelRenderer f3 = this.f;
        final float n2 = p_78087_4_ * 0.017453292f;
        f3.vape = n2;
        i.vape = n2;
        this.g.vape = this.j.vape - 0.2617994f;
        this.h.vape = this.j.vape + 0.2617994f;
        this.k = MathHelper.zerodayisaminecraftcheat(entityrabbit.g(f) * 3.1415927f);
        final ModelRenderer sigma = this.sigma;
        final ModelRenderer pandora = this.pandora;
        final float n3 = (this.k * 50.0f - 21.0f) * 0.017453292f;
        pandora.flux = n3;
        sigma.flux = n3;
        final ModelRenderer zerodayisaminecraftcheat = this.zerodayisaminecraftcheat;
        final ModelRenderer zeroday = this.zeroday;
        final float n4 = this.k * 50.0f * 0.017453292f;
        zeroday.flux = n4;
        zerodayisaminecraftcheat.flux = n4;
        final ModelRenderer d = this.d;
        final ModelRenderer e = this.e;
        final float n5 = (this.k * -40.0f - 11.0f) * 0.017453292f;
        e.flux = n5;
        d.flux = n5;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.client.a.WorldRenderer;
import net.minecraft.l.ModelSprite;
import net.minecraft.client.a.Tessellator;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.GLAllocation;
import net.minecraft.client.a.GlStateManager;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;

public class ModelRenderer
{
    public float zerodayisaminecraftcheat;
    public float zeroday;
    private int m;
    private int n;
    public float sigma;
    public float pandora;
    public float zues;
    public float flux;
    public float vape;
    public float momgetthecamera;
    private boolean o;
    private int p;
    public boolean a;
    public boolean b;
    public boolean c;
    public List d;
    public List e;
    public final String f;
    private ModelBase q;
    public float g;
    public float h;
    public float i;
    public List j;
    public boolean k;
    float l;
    
    public ModelRenderer(final ModelBase model, final String boxNameIn) {
        this.j = new ArrayList();
        this.k = false;
        this.zerodayisaminecraftcheat = 64.0f;
        this.zeroday = 32.0f;
        this.b = true;
        this.d = Lists.newArrayList();
        this.q = model;
        model.momgetthecamera.add(this);
        this.f = boxNameIn;
        this.zeroday(model.a, model.b);
    }
    
    public ModelRenderer(final ModelBase model) {
        this(model, null);
    }
    
    public ModelRenderer(final ModelBase model, final int texOffX, final int texOffY) {
        this(model);
        this.zerodayisaminecraftcheat(texOffX, texOffY);
    }
    
    public void zerodayisaminecraftcheat(final ModelRenderer renderer) {
        if (this.e == null) {
            this.e = Lists.newArrayList();
        }
        this.e.add(renderer);
    }
    
    public ModelRenderer zerodayisaminecraftcheat(final int x, final int y) {
        this.m = x;
        this.n = y;
        return this;
    }
    
    public ModelRenderer zerodayisaminecraftcheat(String partName, final float offX, final float offY, final float offZ, final int width, final int height, final int depth) {
        partName = String.valueOf(this.f) + "." + partName;
        final TextureOffset textureoffset = this.q.zerodayisaminecraftcheat(partName);
        this.zerodayisaminecraftcheat(textureoffset.zerodayisaminecraftcheat, textureoffset.zeroday);
        this.d.add(new ModelBox(this, this.m, this.n, offX, offY, offZ, width, height, depth, 0.0f).zerodayisaminecraftcheat(partName));
        return this;
    }
    
    public ModelRenderer zerodayisaminecraftcheat(final float offX, final float offY, final float offZ, final int width, final int height, final int depth) {
        this.d.add(new ModelBox(this, this.m, this.n, offX, offY, offZ, width, height, depth, 0.0f));
        return this;
    }
    
    public ModelRenderer zerodayisaminecraftcheat(final float p_178769_1_, final float p_178769_2_, final float p_178769_3_, final int p_178769_4_, final int p_178769_5_, final int p_178769_6_, final boolean p_178769_7_) {
        this.d.add(new ModelBox(this, this.m, this.n, p_178769_1_, p_178769_2_, p_178769_3_, p_178769_4_, p_178769_5_, p_178769_6_, 0.0f, p_178769_7_));
        return this;
    }
    
    public void zerodayisaminecraftcheat(final float p_78790_1_, final float p_78790_2_, final float p_78790_3_, final int width, final int height, final int depth, final float scaleFactor) {
        this.d.add(new ModelBox(this, this.m, this.n, p_78790_1_, p_78790_2_, p_78790_3_, width, height, depth, scaleFactor));
    }
    
    public void zerodayisaminecraftcheat(final float rotationPointXIn, final float rotationPointYIn, final float rotationPointZIn) {
        this.sigma = rotationPointXIn;
        this.pandora = rotationPointYIn;
        this.zues = rotationPointZIn;
    }
    
    public void zerodayisaminecraftcheat(final float p_78785_1_) {
        if (!this.c && this.b) {
            if (!this.o) {
                this.pandora(p_78785_1_);
            }
            GlStateManager.zeroday(this.g, this.h, this.i);
            if (this.flux == 0.0f && this.vape == 0.0f && this.momgetthecamera == 0.0f) {
                if (this.sigma == 0.0f && this.pandora == 0.0f && this.zues == 0.0f) {
                    GlStateManager.e(this.p);
                    if (this.e != null) {
                        for (int k = 0; k < this.e.size(); ++k) {
                            this.e.get(k).zerodayisaminecraftcheat(p_78785_1_);
                        }
                    }
                }
                else {
                    GlStateManager.zeroday(this.sigma * p_78785_1_, this.pandora * p_78785_1_, this.zues * p_78785_1_);
                    GlStateManager.e(this.p);
                    if (this.e != null) {
                        for (int j = 0; j < this.e.size(); ++j) {
                            this.e.get(j).zerodayisaminecraftcheat(p_78785_1_);
                        }
                    }
                    GlStateManager.zeroday(-this.sigma * p_78785_1_, -this.pandora * p_78785_1_, -this.zues * p_78785_1_);
                }
            }
            else {
                GlStateManager.v();
                GlStateManager.zeroday(this.sigma * p_78785_1_, this.pandora * p_78785_1_, this.zues * p_78785_1_);
                if (this.momgetthecamera != 0.0f) {
                    GlStateManager.zeroday(this.momgetthecamera * 57.295776f, 0.0f, 0.0f, 1.0f);
                }
                if (this.vape != 0.0f) {
                    GlStateManager.zeroday(this.vape * 57.295776f, 0.0f, 1.0f, 0.0f);
                }
                if (this.flux != 0.0f) {
                    GlStateManager.zeroday(this.flux * 57.295776f, 1.0f, 0.0f, 0.0f);
                }
                GlStateManager.e(this.p);
                if (this.e != null) {
                    for (int i = 0; i < this.e.size(); ++i) {
                        this.e.get(i).zerodayisaminecraftcheat(p_78785_1_);
                    }
                }
                GlStateManager.w();
            }
            GlStateManager.zeroday(-this.g, -this.h, -this.i);
        }
    }
    
    public void zeroday(final float p_78791_1_) {
        if (!this.c && this.b) {
            if (!this.o) {
                this.pandora(p_78791_1_);
            }
            GlStateManager.v();
            GlStateManager.zeroday(this.sigma * p_78791_1_, this.pandora * p_78791_1_, this.zues * p_78791_1_);
            if (this.vape != 0.0f) {
                GlStateManager.zeroday(this.vape * 57.295776f, 0.0f, 1.0f, 0.0f);
            }
            if (this.flux != 0.0f) {
                GlStateManager.zeroday(this.flux * 57.295776f, 1.0f, 0.0f, 0.0f);
            }
            if (this.momgetthecamera != 0.0f) {
                GlStateManager.zeroday(this.momgetthecamera * 57.295776f, 0.0f, 0.0f, 1.0f);
            }
            GlStateManager.e(this.p);
            GlStateManager.w();
        }
    }
    
    public void sigma(final float scale) {
        if (!this.c && this.b) {
            if (!this.o) {
                this.pandora(scale);
            }
            if (this.flux == 0.0f && this.vape == 0.0f && this.momgetthecamera == 0.0f) {
                if (this.sigma != 0.0f || this.pandora != 0.0f || this.zues != 0.0f) {
                    GlStateManager.zeroday(this.sigma * scale, this.pandora * scale, this.zues * scale);
                }
            }
            else {
                GlStateManager.zeroday(this.sigma * scale, this.pandora * scale, this.zues * scale);
                if (this.momgetthecamera != 0.0f) {
                    GlStateManager.zeroday(this.momgetthecamera * 57.295776f, 0.0f, 0.0f, 1.0f);
                }
                if (this.vape != 0.0f) {
                    GlStateManager.zeroday(this.vape * 57.295776f, 0.0f, 1.0f, 0.0f);
                }
                if (this.flux != 0.0f) {
                    GlStateManager.zeroday(this.flux * 57.295776f, 1.0f, 0.0f, 0.0f);
                }
            }
        }
    }
    
    private void pandora(final float scale) {
        if (this.p == 0) {
            this.l = scale;
            this.p = GLAllocation.zerodayisaminecraftcheat(1);
        }
        GL11.glNewList(this.p, 4864);
        final WorldRenderer worldrenderer = Tessellator.zerodayisaminecraftcheat().sigma();
        for (int i = 0; i < this.d.size(); ++i) {
            this.d.get(i).zerodayisaminecraftcheat(worldrenderer, scale);
        }
        for (int j = 0; j < this.j.size(); ++j) {
            final ModelSprite modelsprite = this.j.get(j);
            modelsprite.zerodayisaminecraftcheat(Tessellator.zerodayisaminecraftcheat(), scale);
        }
        GL11.glEndList();
        this.o = true;
    }
    
    public ModelRenderer zeroday(final int textureWidthIn, final int textureHeightIn) {
        this.zerodayisaminecraftcheat = (float)textureWidthIn;
        this.zeroday = (float)textureHeightIn;
        return this;
    }
    
    public void zeroday(final float p_addSprite_1_, final float p_addSprite_2_, final float p_addSprite_3_, final int p_addSprite_4_, final int p_addSprite_5_, final int p_addSprite_6_, final float p_addSprite_7_) {
        this.j.add(new ModelSprite(this, this.m, this.n, p_addSprite_1_, p_addSprite_2_, p_addSprite_3_, p_addSprite_4_, p_addSprite_5_, p_addSprite_6_, p_addSprite_7_));
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.o;
    }
    
    public int zeroday() {
        return this.p;
    }
    
    public void sigma() {
        if (this.o) {
            this.o = false;
            this.pandora(this.l);
        }
    }
}

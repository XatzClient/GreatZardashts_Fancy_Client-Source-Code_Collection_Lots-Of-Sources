// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.flux.EntitySheep;
import net.minecraft.vape.EntityLivingBase;

public class ModelSheep1 extends ModelQuadruped
{
    private float g;
    
    public ModelSheep1() {
        super(12, 0.0f);
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-3.0f, -4.0f, -4.0f, 6, 6, 6, 0.6f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 6.0f, -8.0f);
        (this.zeroday = new ModelRenderer(this, 28, 8)).zerodayisaminecraftcheat(-4.0f, -10.0f, -7.0f, 8, 16, 6, 1.75f);
        this.zeroday.zerodayisaminecraftcheat(0.0f, 5.0f, 2.0f);
        final float f = 0.5f;
        (this.sigma = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.sigma.zerodayisaminecraftcheat(-3.0f, 12.0f, 7.0f);
        (this.pandora = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.pandora.zerodayisaminecraftcheat(3.0f, 12.0f, 7.0f);
        (this.c = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.c.zerodayisaminecraftcheat(-3.0f, 12.0f, -5.0f);
        (this.d = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.d.zerodayisaminecraftcheat(3.0f, 12.0f, -5.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        super.zerodayisaminecraftcheat(entitylivingbaseIn, p_78086_2_, p_78086_3_, partialTickTime);
        this.zerodayisaminecraftcheat.pandora = 6.0f + ((EntitySheep)entitylivingbaseIn).g(partialTickTime) * 9.0f;
        this.g = ((EntitySheep)entitylivingbaseIn).h(partialTickTime);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        this.zerodayisaminecraftcheat.flux = this.g;
    }
}

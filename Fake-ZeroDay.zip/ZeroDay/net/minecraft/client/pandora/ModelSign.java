// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

public class ModelSign extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    
    public ModelSign() {
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-12.0f, -14.0f, -1.0f, 24, 12, 2, 0.0f);
        (this.zeroday = new ModelRenderer(this, 0, 14)).zerodayisaminecraftcheat(-1.0f, -2.0f, -1.0f, 2, 14, 2, 0.0f);
    }
    
    public void zerodayisaminecraftcheat() {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0625f);
        this.zeroday.zerodayisaminecraftcheat(0.0625f);
    }
}

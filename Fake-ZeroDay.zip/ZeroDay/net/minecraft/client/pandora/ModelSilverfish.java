// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelSilverfish extends ModelBase
{
    private ModelRenderer[] zerodayisaminecraftcheat;
    private ModelRenderer[] zeroday;
    private float[] sigma;
    private static final int[][] pandora;
    private static final int[][] c;
    
    static {
        pandora = new int[][] { { 3, 2, 2 }, { 4, 3, 2 }, { 6, 4, 3 }, { 3, 3, 3 }, { 2, 2, 3 }, { 2, 1, 2 }, { 1, 1, 2 } };
        c = new int[][] { new int[2], { 0, 4 }, { 0, 9 }, { 0, 16 }, { 0, 22 }, { 11, 0 }, { 13, 4 } };
    }
    
    public ModelSilverfish() {
        this.zerodayisaminecraftcheat = new ModelRenderer[7];
        this.sigma = new float[7];
        float f = -3.5f;
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            (this.zerodayisaminecraftcheat[i] = new ModelRenderer(this, ModelSilverfish.c[i][0], ModelSilverfish.c[i][1])).zerodayisaminecraftcheat(ModelSilverfish.pandora[i][0] * -0.5f, 0.0f, ModelSilverfish.pandora[i][2] * -0.5f, ModelSilverfish.pandora[i][0], ModelSilverfish.pandora[i][1], ModelSilverfish.pandora[i][2]);
            this.zerodayisaminecraftcheat[i].zerodayisaminecraftcheat(0.0f, (float)(24 - ModelSilverfish.pandora[i][1]), f);
            this.sigma[i] = f;
            if (i < this.zerodayisaminecraftcheat.length - 1) {
                f += (ModelSilverfish.pandora[i][2] + ModelSilverfish.pandora[i + 1][2]) * 0.5f;
            }
        }
        this.zeroday = new ModelRenderer[3];
        (this.zeroday[0] = new ModelRenderer(this, 20, 0)).zerodayisaminecraftcheat(-5.0f, 0.0f, ModelSilverfish.pandora[2][2] * -0.5f, 10, 8, ModelSilverfish.pandora[2][2]);
        this.zeroday[0].zerodayisaminecraftcheat(0.0f, 16.0f, this.sigma[2]);
        (this.zeroday[1] = new ModelRenderer(this, 20, 11)).zerodayisaminecraftcheat(-3.0f, 0.0f, ModelSilverfish.pandora[4][2] * -0.5f, 6, 4, ModelSilverfish.pandora[4][2]);
        this.zeroday[1].zerodayisaminecraftcheat(0.0f, 20.0f, this.sigma[4]);
        (this.zeroday[2] = new ModelRenderer(this, 20, 18)).zerodayisaminecraftcheat(-3.0f, 0.0f, ModelSilverfish.pandora[4][2] * -0.5f, 6, 5, ModelSilverfish.pandora[1][2]);
        this.zeroday[2].zerodayisaminecraftcheat(0.0f, 19.0f, this.sigma[1]);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            this.zerodayisaminecraftcheat[i].zerodayisaminecraftcheat(scale);
        }
        for (int j = 0; j < this.zeroday.length; ++j) {
            this.zeroday[j].zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            this.zerodayisaminecraftcheat[i].vape = MathHelper.zeroday(p_78087_3_ * 0.9f + i * 0.15f * 3.1415927f) * 3.1415927f * 0.05f * (1 + Math.abs(i - 2));
            this.zerodayisaminecraftcheat[i].sigma = MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.9f + i * 0.15f * 3.1415927f) * 3.1415927f * 0.2f * Math.abs(i - 2);
        }
        this.zeroday[0].vape = this.zerodayisaminecraftcheat[2].vape;
        this.zeroday[1].vape = this.zerodayisaminecraftcheat[4].vape;
        this.zeroday[1].sigma = this.zerodayisaminecraftcheat[4].sigma;
        this.zeroday[2].vape = this.zerodayisaminecraftcheat[1].vape;
        this.zeroday[2].sigma = this.zerodayisaminecraftcheat[1].sigma;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.Entity;
import net.minecraft.vape.zues.EntitySkeleton;
import net.minecraft.vape.EntityLivingBase;

public class ModelSkeleton extends ModelZombie
{
    public ModelSkeleton() {
        this(0.0f, false);
    }
    
    public ModelSkeleton(final float p_i46303_1_, final boolean p_i46303_2_) {
        super(p_i46303_1_, 0.0f, 64, 32);
        if (!p_i46303_2_) {
            (this.f = new ModelRenderer(this, 40, 16)).zerodayisaminecraftcheat(-1.0f, -2.0f, -1.0f, 2, 12, 2, p_i46303_1_);
            this.f.zerodayisaminecraftcheat(-5.0f, 2.0f, 0.0f);
            this.g = new ModelRenderer(this, 40, 16);
            this.g.a = true;
            this.g.zerodayisaminecraftcheat(-1.0f, -2.0f, -1.0f, 2, 12, 2, p_i46303_1_);
            this.g.zerodayisaminecraftcheat(5.0f, 2.0f, 0.0f);
            (this.h = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 12, 2, p_i46303_1_);
            this.h.zerodayisaminecraftcheat(-2.0f, 12.0f, 0.0f);
            this.i = new ModelRenderer(this, 0, 16);
            this.i.a = true;
            this.i.zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 12, 2, p_i46303_1_);
            this.i.zerodayisaminecraftcheat(2.0f, 12.0f, 0.0f);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        this.m = (((EntitySkeleton)entitylivingbaseIn).cb() == 1);
        super.zerodayisaminecraftcheat(entitylivingbaseIn, p_78086_2_, p_78086_3_, partialTickTime);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
    }
}

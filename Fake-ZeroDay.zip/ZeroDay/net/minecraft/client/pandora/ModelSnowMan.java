// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelSnowMan extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    
    public ModelSnowMan() {
        final float f = 4.0f;
        final float f2 = 0.0f;
        (this.sigma = new ModelRenderer(this, 0, 0).zeroday(64, 64)).zerodayisaminecraftcheat(-4.0f, -8.0f, -4.0f, 8, 8, 8, f2 - 0.5f);
        this.sigma.zerodayisaminecraftcheat(0.0f, 0.0f + f, 0.0f);
        (this.pandora = new ModelRenderer(this, 32, 0).zeroday(64, 64)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 12, 2, 2, f2 - 0.5f);
        this.pandora.zerodayisaminecraftcheat(0.0f, 0.0f + f + 9.0f - 7.0f, 0.0f);
        (this.c = new ModelRenderer(this, 32, 0).zeroday(64, 64)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 12, 2, 2, f2 - 0.5f);
        this.c.zerodayisaminecraftcheat(0.0f, 0.0f + f + 9.0f - 7.0f, 0.0f);
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 16).zeroday(64, 64)).zerodayisaminecraftcheat(-5.0f, -10.0f, -5.0f, 10, 10, 10, f2 - 0.5f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, 0.0f + f + 9.0f, 0.0f);
        (this.zeroday = new ModelRenderer(this, 0, 36).zeroday(64, 64)).zerodayisaminecraftcheat(-6.0f, -12.0f, -6.0f, 12, 12, 12, f2 - 0.5f);
        this.zeroday.zerodayisaminecraftcheat(0.0f, 0.0f + f + 20.0f, 0.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        this.sigma.vape = p_78087_4_ / 57.295776f;
        this.sigma.flux = p_78087_5_ / 57.295776f;
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f * 0.25f;
        final float f = MathHelper.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.vape);
        final float f2 = MathHelper.zeroday(this.zerodayisaminecraftcheat.vape);
        this.pandora.momgetthecamera = 1.0f;
        this.c.momgetthecamera = -1.0f;
        this.pandora.vape = 0.0f + this.zerodayisaminecraftcheat.vape;
        this.c.vape = 3.1415927f + this.zerodayisaminecraftcheat.vape;
        this.pandora.sigma = f2 * 5.0f;
        this.pandora.zues = -f * 5.0f;
        this.c.sigma = -f2 * 5.0f;
        this.c.zues = f * 5.0f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        this.zeroday.zerodayisaminecraftcheat(scale);
        this.sigma.zerodayisaminecraftcheat(scale);
        this.pandora.zerodayisaminecraftcheat(scale);
        this.c.zerodayisaminecraftcheat(scale);
    }
}

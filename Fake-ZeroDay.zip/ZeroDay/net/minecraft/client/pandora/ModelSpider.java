// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelSpider extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    public ModelRenderer d;
    public ModelRenderer e;
    public ModelRenderer f;
    public ModelRenderer g;
    public ModelRenderer h;
    public ModelRenderer i;
    
    public ModelSpider() {
        final float f = 0.0f;
        final int i = 15;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 32, 4)).zerodayisaminecraftcheat(-4.0f, -4.0f, -8.0f, 8, 8, 8, f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0.0f, (float)i, -3.0f);
        (this.zeroday = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-3.0f, -3.0f, -3.0f, 6, 6, 6, f);
        this.zeroday.zerodayisaminecraftcheat(0.0f, (float)i, 0.0f);
        (this.sigma = new ModelRenderer(this, 0, 12)).zerodayisaminecraftcheat(-5.0f, -4.0f, -6.0f, 10, 8, 12, f);
        this.sigma.zerodayisaminecraftcheat(0.0f, (float)i, 9.0f);
        (this.pandora = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.pandora.zerodayisaminecraftcheat(-4.0f, (float)i, 2.0f);
        (this.c = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.c.zerodayisaminecraftcheat(4.0f, (float)i, 2.0f);
        (this.d = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.d.zerodayisaminecraftcheat(-4.0f, (float)i, 1.0f);
        (this.e = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.e.zerodayisaminecraftcheat(4.0f, (float)i, 1.0f);
        (this.f = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.f.zerodayisaminecraftcheat(-4.0f, (float)i, 0.0f);
        (this.g = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.g.zerodayisaminecraftcheat(4.0f, (float)i, 0.0f);
        (this.h = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.h.zerodayisaminecraftcheat(-4.0f, (float)i, -1.0f);
        (this.i = new ModelRenderer(this, 18, 0)).zerodayisaminecraftcheat(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.i.zerodayisaminecraftcheat(4.0f, (float)i, -1.0f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        this.zeroday.zerodayisaminecraftcheat(scale);
        this.sigma.zerodayisaminecraftcheat(scale);
        this.pandora.zerodayisaminecraftcheat(scale);
        this.c.zerodayisaminecraftcheat(scale);
        this.d.zerodayisaminecraftcheat(scale);
        this.e.zerodayisaminecraftcheat(scale);
        this.f.zerodayisaminecraftcheat(scale);
        this.g.zerodayisaminecraftcheat(scale);
        this.h.zerodayisaminecraftcheat(scale);
        this.i.zerodayisaminecraftcheat(scale);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
        this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
        final float f = 0.7853982f;
        this.pandora.momgetthecamera = -f;
        this.c.momgetthecamera = f;
        this.d.momgetthecamera = -f * 0.74f;
        this.e.momgetthecamera = f * 0.74f;
        this.f.momgetthecamera = -f * 0.74f;
        this.g.momgetthecamera = f * 0.74f;
        this.h.momgetthecamera = -f;
        this.i.momgetthecamera = f;
        final float f2 = -0.0f;
        final float f3 = 0.3926991f;
        this.pandora.vape = f3 * 2.0f + f2;
        this.c.vape = -f3 * 2.0f - f2;
        this.d.vape = f3 * 1.0f + f2;
        this.e.vape = -f3 * 1.0f - f2;
        this.f.vape = -f3 * 1.0f + f2;
        this.g.vape = f3 * 1.0f - f2;
        this.h.vape = -f3 * 2.0f + f2;
        this.i.vape = f3 * 2.0f - f2;
        final float f4 = -(MathHelper.zeroday(p_78087_1_ * 0.6662f * 2.0f + 0.0f) * 0.4f) * p_78087_2_;
        final float f5 = -(MathHelper.zeroday(p_78087_1_ * 0.6662f * 2.0f + 3.1415927f) * 0.4f) * p_78087_2_;
        final float f6 = -(MathHelper.zeroday(p_78087_1_ * 0.6662f * 2.0f + 1.5707964f) * 0.4f) * p_78087_2_;
        final float f7 = -(MathHelper.zeroday(p_78087_1_ * 0.6662f * 2.0f + 4.712389f) * 0.4f) * p_78087_2_;
        final float f8 = Math.abs(MathHelper.zerodayisaminecraftcheat(p_78087_1_ * 0.6662f + 0.0f) * 0.4f) * p_78087_2_;
        final float f9 = Math.abs(MathHelper.zerodayisaminecraftcheat(p_78087_1_ * 0.6662f + 3.1415927f) * 0.4f) * p_78087_2_;
        final float f10 = Math.abs(MathHelper.zerodayisaminecraftcheat(p_78087_1_ * 0.6662f + 1.5707964f) * 0.4f) * p_78087_2_;
        final float f11 = Math.abs(MathHelper.zerodayisaminecraftcheat(p_78087_1_ * 0.6662f + 4.712389f) * 0.4f) * p_78087_2_;
        final ModelRenderer pandora = this.pandora;
        pandora.vape += f4;
        final ModelRenderer c = this.c;
        c.vape += -f4;
        final ModelRenderer d = this.d;
        d.vape += f5;
        final ModelRenderer e = this.e;
        e.vape += -f5;
        final ModelRenderer f12 = this.f;
        f12.vape += f6;
        final ModelRenderer g = this.g;
        g.vape += -f6;
        final ModelRenderer h = this.h;
        h.vape += f7;
        final ModelRenderer i = this.i;
        i.vape += -f7;
        final ModelRenderer pandora2 = this.pandora;
        pandora2.momgetthecamera += f8;
        final ModelRenderer c2 = this.c;
        c2.momgetthecamera += -f8;
        final ModelRenderer d2 = this.d;
        d2.momgetthecamera += f9;
        final ModelRenderer e2 = this.e;
        e2.momgetthecamera += -f9;
        final ModelRenderer f13 = this.f;
        f13.momgetthecamera += f10;
        final ModelRenderer g2 = this.g;
        g2.momgetthecamera += -f10;
        final ModelRenderer h2 = this.h;
        h2.momgetthecamera += f11;
        final ModelRenderer j = this.i;
        j.momgetthecamera += -f11;
    }
}

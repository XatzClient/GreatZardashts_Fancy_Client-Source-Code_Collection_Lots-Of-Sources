// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.Entity;

public class ModelSquid extends ModelBase
{
    ModelRenderer zerodayisaminecraftcheat;
    ModelRenderer[] zeroday;
    
    public ModelSquid() {
        this.zeroday = new ModelRenderer[8];
        final int i = -16;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-6.0f, -8.0f, -6.0f, 12, 16, 12);
        final ModelRenderer zerodayisaminecraftcheat = this.zerodayisaminecraftcheat;
        zerodayisaminecraftcheat.pandora += 24 + i;
        for (int j = 0; j < this.zeroday.length; ++j) {
            this.zeroday[j] = new ModelRenderer(this, 48, 0);
            double d0 = j * 3.141592653589793 * 2.0 / this.zeroday.length;
            final float f = (float)Math.cos(d0) * 5.0f;
            final float f2 = (float)Math.sin(d0) * 5.0f;
            this.zeroday[j].zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 18, 2);
            this.zeroday[j].sigma = f;
            this.zeroday[j].zues = f2;
            this.zeroday[j].pandora = (float)(31 + i);
            d0 = j * 3.141592653589793 * -2.0 / this.zeroday.length + 1.5707963267948966;
            this.zeroday[j].vape = (float)d0;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        ModelRenderer[] zeroday;
        for (int length = (zeroday = this.zeroday).length, i = 0; i < length; ++i) {
            final ModelRenderer modelrenderer = zeroday[i];
            modelrenderer.flux = p_78087_3_;
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        for (int i = 0; i < this.zeroday.length; ++i) {
            this.zeroday[i].zerodayisaminecraftcheat(scale);
        }
    }
}

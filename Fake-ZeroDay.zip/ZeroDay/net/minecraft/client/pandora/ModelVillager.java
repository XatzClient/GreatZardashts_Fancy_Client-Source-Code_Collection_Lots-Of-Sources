// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelVillager extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    public ModelRenderer d;
    
    public ModelVillager(final float p_i1163_1_) {
        this(p_i1163_1_, 0.0f, 64, 64);
    }
    
    public ModelVillager(final float p_i1164_1_, final float p_i1164_2_, final int p_i1164_3_, final int p_i1164_4_) {
        (this.zerodayisaminecraftcheat = new ModelRenderer(this).zeroday(p_i1164_3_, p_i1164_4_)).zerodayisaminecraftcheat(0.0f, 0.0f + p_i1164_2_, 0.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0, 0).zerodayisaminecraftcheat(-4.0f, -10.0f, -4.0f, 8, 10, 8, p_i1164_1_);
        (this.d = new ModelRenderer(this).zeroday(p_i1164_3_, p_i1164_4_)).zerodayisaminecraftcheat(0.0f, p_i1164_2_ - 2.0f, 0.0f);
        this.d.zerodayisaminecraftcheat(24, 0).zerodayisaminecraftcheat(-1.0f, -1.0f, -6.0f, 2, 4, 2, p_i1164_1_);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.d);
        (this.zeroday = new ModelRenderer(this).zeroday(p_i1164_3_, p_i1164_4_)).zerodayisaminecraftcheat(0.0f, 0.0f + p_i1164_2_, 0.0f);
        this.zeroday.zerodayisaminecraftcheat(16, 20).zerodayisaminecraftcheat(-4.0f, 0.0f, -3.0f, 8, 12, 6, p_i1164_1_);
        this.zeroday.zerodayisaminecraftcheat(0, 38).zerodayisaminecraftcheat(-4.0f, 0.0f, -3.0f, 8, 18, 6, p_i1164_1_ + 0.5f);
        (this.sigma = new ModelRenderer(this).zeroday(p_i1164_3_, p_i1164_4_)).zerodayisaminecraftcheat(0.0f, 0.0f + p_i1164_2_ + 2.0f, 0.0f);
        this.sigma.zerodayisaminecraftcheat(44, 22).zerodayisaminecraftcheat(-8.0f, -2.0f, -2.0f, 4, 8, 4, p_i1164_1_);
        this.sigma.zerodayisaminecraftcheat(44, 22).zerodayisaminecraftcheat(4.0f, -2.0f, -2.0f, 4, 8, 4, p_i1164_1_);
        this.sigma.zerodayisaminecraftcheat(40, 38).zerodayisaminecraftcheat(-4.0f, 2.0f, -2.0f, 8, 4, 4, p_i1164_1_);
        (this.pandora = new ModelRenderer(this, 0, 22).zeroday(p_i1164_3_, p_i1164_4_)).zerodayisaminecraftcheat(-2.0f, 12.0f + p_i1164_2_, 0.0f);
        this.pandora.zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 12, 4, p_i1164_1_);
        this.c = new ModelRenderer(this, 0, 22).zeroday(p_i1164_3_, p_i1164_4_);
        this.c.a = true;
        this.c.zerodayisaminecraftcheat(2.0f, 12.0f + p_i1164_2_, 0.0f);
        this.c.zerodayisaminecraftcheat(-2.0f, 0.0f, -2.0f, 4, 12, 4, p_i1164_1_);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(scale);
        this.zeroday.zerodayisaminecraftcheat(scale);
        this.pandora.zerodayisaminecraftcheat(scale);
        this.c.zerodayisaminecraftcheat(scale);
        this.sigma.zerodayisaminecraftcheat(scale);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
        this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
        this.sigma.pandora = 3.0f;
        this.sigma.zues = -1.0f;
        this.sigma.flux = -0.75f;
        this.pandora.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f) * 1.4f * p_78087_2_ * 0.5f;
        this.c.flux = MathHelper.zeroday(p_78087_1_ * 0.6662f + 3.1415927f) * 1.4f * p_78087_2_ * 0.5f;
        this.pandora.vape = 0.0f;
        this.c.vape = 0.0f;
    }
}

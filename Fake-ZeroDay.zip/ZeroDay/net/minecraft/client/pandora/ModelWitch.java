// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelWitch extends ModelVillager
{
    public boolean e;
    private ModelRenderer f;
    private ModelRenderer g;
    
    public ModelWitch(final float p_i46361_1_) {
        super(p_i46361_1_, 0.0f, 64, 128);
        (this.f = new ModelRenderer(this).zeroday(64, 128)).zerodayisaminecraftcheat(0.0f, -2.0f, 0.0f);
        this.f.zerodayisaminecraftcheat(0, 0).zerodayisaminecraftcheat(0.0f, 3.0f, -6.75f, 1, 1, 1, -0.25f);
        this.d.zerodayisaminecraftcheat(this.f);
        (this.g = new ModelRenderer(this).zeroday(64, 128)).zerodayisaminecraftcheat(-5.0f, -10.03125f, -5.0f);
        this.g.zerodayisaminecraftcheat(0, 64).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 10, 2, 10);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.g);
        final ModelRenderer modelrenderer = new ModelRenderer(this).zeroday(64, 128);
        modelrenderer.zerodayisaminecraftcheat(1.75f, -4.0f, 2.0f);
        modelrenderer.zerodayisaminecraftcheat(0, 76).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 7, 4, 7);
        modelrenderer.flux = -0.05235988f;
        modelrenderer.momgetthecamera = 0.02617994f;
        this.g.zerodayisaminecraftcheat(modelrenderer);
        final ModelRenderer modelrenderer2 = new ModelRenderer(this).zeroday(64, 128);
        modelrenderer2.zerodayisaminecraftcheat(1.75f, -4.0f, 2.0f);
        modelrenderer2.zerodayisaminecraftcheat(0, 87).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 4, 4, 4);
        modelrenderer2.flux = -0.10471976f;
        modelrenderer2.momgetthecamera = 0.05235988f;
        modelrenderer.zerodayisaminecraftcheat(modelrenderer2);
        final ModelRenderer modelrenderer3 = new ModelRenderer(this).zeroday(64, 128);
        modelrenderer3.zerodayisaminecraftcheat(1.75f, -2.0f, 2.0f);
        modelrenderer3.zerodayisaminecraftcheat(0, 95).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 1, 2, 1, 0.25f);
        modelrenderer3.flux = -0.20943952f;
        modelrenderer3.momgetthecamera = 0.10471976f;
        modelrenderer2.zerodayisaminecraftcheat(modelrenderer3);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        final ModelRenderer d = this.d;
        final ModelRenderer d2 = this.d;
        final ModelRenderer d3 = this.d;
        final float g = 0.0f;
        d3.i = g;
        d2.h = g;
        d.g = g;
        final float f = 0.01f * (entityIn.B() % 10);
        this.d.flux = MathHelper.zerodayisaminecraftcheat(entityIn.X * f) * 4.5f * 3.1415927f / 180.0f;
        this.d.vape = 0.0f;
        this.d.momgetthecamera = MathHelper.zeroday(entityIn.X * f) * 2.5f * 3.1415927f / 180.0f;
        if (this.e) {
            this.d.flux = -0.9f;
            this.d.i = -0.09375f;
            this.d.h = 0.1875f;
        }
    }
}

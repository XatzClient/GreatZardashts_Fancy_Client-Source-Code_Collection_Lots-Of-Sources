// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.vape.zeroday.EntityWither;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelWither extends ModelBase
{
    private ModelRenderer[] zerodayisaminecraftcheat;
    private ModelRenderer[] zeroday;
    
    public ModelWither(final float p_i46302_1_) {
        this.a = 64;
        this.b = 64;
        this.zerodayisaminecraftcheat = new ModelRenderer[3];
        (this.zerodayisaminecraftcheat[0] = new ModelRenderer(this, 0, 16)).zerodayisaminecraftcheat(-10.0f, 3.9f, -0.5f, 20, 3, 3, p_i46302_1_);
        (this.zerodayisaminecraftcheat[1] = new ModelRenderer(this).zeroday(this.a, this.b)).zerodayisaminecraftcheat(-2.0f, 6.9f, -0.5f);
        this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat(0, 22).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 3, 10, 3, p_i46302_1_);
        this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat(24, 22).zerodayisaminecraftcheat(-4.0f, 1.5f, 0.5f, 11, 2, 2, p_i46302_1_);
        this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat(24, 22).zerodayisaminecraftcheat(-4.0f, 4.0f, 0.5f, 11, 2, 2, p_i46302_1_);
        this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat(24, 22).zerodayisaminecraftcheat(-4.0f, 6.5f, 0.5f, 11, 2, 2, p_i46302_1_);
        (this.zerodayisaminecraftcheat[2] = new ModelRenderer(this, 12, 22)).zerodayisaminecraftcheat(0.0f, 0.0f, 0.0f, 3, 6, 3, p_i46302_1_);
        this.zeroday = new ModelRenderer[3];
        (this.zeroday[0] = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-4.0f, -4.0f, -4.0f, 8, 8, 8, p_i46302_1_);
        (this.zeroday[1] = new ModelRenderer(this, 32, 0)).zerodayisaminecraftcheat(-4.0f, -4.0f, -4.0f, 6, 6, 6, p_i46302_1_);
        this.zeroday[1].sigma = -8.0f;
        this.zeroday[1].pandora = 4.0f;
        (this.zeroday[2] = new ModelRenderer(this, 32, 0)).zerodayisaminecraftcheat(-4.0f, -4.0f, -4.0f, 6, 6, 6, p_i46302_1_);
        this.zeroday[2].sigma = 10.0f;
        this.zeroday[2].pandora = 4.0f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        ModelRenderer[] zeroday;
        for (int length = (zeroday = this.zeroday).length, i = 0; i < length; ++i) {
            final ModelRenderer modelrenderer = zeroday[i];
            modelrenderer.zerodayisaminecraftcheat(scale);
        }
        ModelRenderer[] zerodayisaminecraftcheat;
        for (int length2 = (zerodayisaminecraftcheat = this.zerodayisaminecraftcheat).length, j = 0; j < length2; ++j) {
            final ModelRenderer modelrenderer2 = zerodayisaminecraftcheat[j];
            modelrenderer2.zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        final float f = MathHelper.zeroday(p_78087_3_ * 0.1f);
        this.zerodayisaminecraftcheat[1].flux = (0.065f + 0.05f * f) * 3.1415927f;
        this.zerodayisaminecraftcheat[2].zerodayisaminecraftcheat(-2.0f, 6.9f + MathHelper.zeroday(this.zerodayisaminecraftcheat[1].flux) * 10.0f, -0.5f + MathHelper.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat[1].flux) * 10.0f);
        this.zerodayisaminecraftcheat[2].flux = (0.265f + 0.1f * f) * 3.1415927f;
        this.zeroday[0].vape = p_78087_4_ / 57.295776f;
        this.zeroday[0].flux = p_78087_5_ / 57.295776f;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        final EntityWither entitywither = (EntityWither)entitylivingbaseIn;
        for (int i = 1; i < 3; ++i) {
            this.zeroday[i].vape = (entitywither.zerodayisaminecraftcheat(i - 1) - entitylivingbaseIn.aL) / 57.295776f;
            this.zeroday[i].flux = entitywither.zeroday(i - 1) / 57.295776f;
        }
    }
}

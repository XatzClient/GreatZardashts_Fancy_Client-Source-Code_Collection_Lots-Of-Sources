// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.flux.EntityWolf;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.Entity;

public class ModelWolf extends ModelBase
{
    public ModelRenderer zerodayisaminecraftcheat;
    public ModelRenderer zeroday;
    public ModelRenderer sigma;
    public ModelRenderer pandora;
    public ModelRenderer c;
    public ModelRenderer d;
    ModelRenderer e;
    ModelRenderer f;
    
    public ModelWolf() {
        final float f = 0.0f;
        final float f2 = 13.5f;
        (this.zerodayisaminecraftcheat = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-3.0f, -3.0f, -2.0f, 6, 6, 4, f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(-1.0f, f2, -7.0f);
        (this.zeroday = new ModelRenderer(this, 18, 14)).zerodayisaminecraftcheat(-4.0f, -2.0f, -3.0f, 6, 9, 6, f);
        this.zeroday.zerodayisaminecraftcheat(0.0f, 14.0f, 2.0f);
        (this.f = new ModelRenderer(this, 21, 0)).zerodayisaminecraftcheat(-4.0f, -3.0f, -3.0f, 8, 6, 7, f);
        this.f.zerodayisaminecraftcheat(-1.0f, 14.0f, 2.0f);
        (this.sigma = new ModelRenderer(this, 0, 18)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 8, 2, f);
        this.sigma.zerodayisaminecraftcheat(-2.5f, 16.0f, 7.0f);
        (this.pandora = new ModelRenderer(this, 0, 18)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 8, 2, f);
        this.pandora.zerodayisaminecraftcheat(0.5f, 16.0f, 7.0f);
        (this.c = new ModelRenderer(this, 0, 18)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 8, 2, f);
        this.c.zerodayisaminecraftcheat(-2.5f, 16.0f, -4.0f);
        (this.d = new ModelRenderer(this, 0, 18)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 8, 2, f);
        this.d.zerodayisaminecraftcheat(0.5f, 16.0f, -4.0f);
        (this.e = new ModelRenderer(this, 9, 18)).zerodayisaminecraftcheat(-1.0f, 0.0f, -1.0f, 2, 8, 2, f);
        this.e.zerodayisaminecraftcheat(-1.0f, 12.0f, 8.0f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(16, 14).zerodayisaminecraftcheat(-3.0f, -5.0f, 0.0f, 2, 2, 1, f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(16, 14).zerodayisaminecraftcheat(1.0f, -5.0f, 0.0f, 2, 2, 1, f);
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(0, 10).zerodayisaminecraftcheat(-1.5f, 0.0f, -5.0f, 3, 3, 4, f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Entity entityIn, final float p_78088_2_, final float p_78088_3_, final float p_78088_4_, final float p_78088_5_, final float p_78088_6_, final float scale) {
        super.zerodayisaminecraftcheat(entityIn, p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale);
        this.zerodayisaminecraftcheat(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale, entityIn);
        if (this.vape) {
            final float f = 2.0f;
            GlStateManager.v();
            GlStateManager.zeroday(0.0f, 5.0f * scale, 2.0f * scale);
            this.zerodayisaminecraftcheat.zeroday(scale);
            GlStateManager.w();
            GlStateManager.v();
            GlStateManager.zerodayisaminecraftcheat(1.0f / f, 1.0f / f, 1.0f / f);
            GlStateManager.zeroday(0.0f, 24.0f * scale, 0.0f);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            this.e.zeroday(scale);
            this.f.zerodayisaminecraftcheat(scale);
            GlStateManager.w();
        }
        else {
            this.zerodayisaminecraftcheat.zeroday(scale);
            this.zeroday.zerodayisaminecraftcheat(scale);
            this.sigma.zerodayisaminecraftcheat(scale);
            this.pandora.zerodayisaminecraftcheat(scale);
            this.c.zerodayisaminecraftcheat(scale);
            this.d.zerodayisaminecraftcheat(scale);
            this.e.zeroday(scale);
            this.f.zerodayisaminecraftcheat(scale);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final EntityLivingBase entitylivingbaseIn, final float p_78086_2_, final float p_78086_3_, final float partialTickTime) {
        final EntityWolf entitywolf = (EntityWolf)entitylivingbaseIn;
        if (entitywolf.ck()) {
            this.e.vape = 0.0f;
        }
        else {
            this.e.vape = MathHelper.zeroday(p_78086_2_ * 0.6662f) * 1.4f * p_78086_3_;
        }
        if (entitywolf.cg()) {
            this.f.zerodayisaminecraftcheat(-1.0f, 16.0f, -3.0f);
            this.f.flux = 1.2566371f;
            this.f.vape = 0.0f;
            this.zeroday.zerodayisaminecraftcheat(0.0f, 18.0f, 0.0f);
            this.zeroday.flux = 0.7853982f;
            this.e.zerodayisaminecraftcheat(-1.0f, 21.0f, 6.0f);
            this.sigma.zerodayisaminecraftcheat(-2.5f, 22.0f, 2.0f);
            this.sigma.flux = 4.712389f;
            this.pandora.zerodayisaminecraftcheat(0.5f, 22.0f, 2.0f);
            this.pandora.flux = 4.712389f;
            this.c.flux = 5.811947f;
            this.c.zerodayisaminecraftcheat(-2.49f, 17.0f, -4.0f);
            this.d.flux = 5.811947f;
            this.d.zerodayisaminecraftcheat(0.51f, 17.0f, -4.0f);
        }
        else {
            this.zeroday.zerodayisaminecraftcheat(0.0f, 14.0f, 2.0f);
            this.zeroday.flux = 1.5707964f;
            this.f.zerodayisaminecraftcheat(-1.0f, 14.0f, -3.0f);
            this.f.flux = this.zeroday.flux;
            this.e.zerodayisaminecraftcheat(-1.0f, 12.0f, 8.0f);
            this.sigma.zerodayisaminecraftcheat(-2.5f, 16.0f, 7.0f);
            this.pandora.zerodayisaminecraftcheat(0.5f, 16.0f, 7.0f);
            this.c.zerodayisaminecraftcheat(-2.5f, 16.0f, -4.0f);
            this.d.zerodayisaminecraftcheat(0.5f, 16.0f, -4.0f);
            this.sigma.flux = MathHelper.zeroday(p_78086_2_ * 0.6662f) * 1.4f * p_78086_3_;
            this.pandora.flux = MathHelper.zeroday(p_78086_2_ * 0.6662f + 3.1415927f) * 1.4f * p_78086_3_;
            this.c.flux = MathHelper.zeroday(p_78086_2_ * 0.6662f + 3.1415927f) * 1.4f * p_78086_3_;
            this.d.flux = MathHelper.zeroday(p_78086_2_ * 0.6662f) * 1.4f * p_78086_3_;
        }
        this.zerodayisaminecraftcheat.momgetthecamera = entitywolf.h(partialTickTime) + entitywolf.momgetthecamera(partialTickTime, 0.0f);
        this.f.momgetthecamera = entitywolf.momgetthecamera(partialTickTime, -0.08f);
        this.zeroday.momgetthecamera = entitywolf.momgetthecamera(partialTickTime, -0.16f);
        this.e.momgetthecamera = entitywolf.momgetthecamera(partialTickTime, -0.2f);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        this.zerodayisaminecraftcheat.flux = p_78087_5_ / 57.295776f;
        this.zerodayisaminecraftcheat.vape = p_78087_4_ / 57.295776f;
        this.e.flux = p_78087_3_;
    }
}

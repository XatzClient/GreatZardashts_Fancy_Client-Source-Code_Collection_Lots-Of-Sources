// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelZombie extends ModelBiped
{
    public ModelZombie() {
        this(0.0f, false);
    }
    
    protected ModelZombie(final float modelSize, final float p_i1167_2_, final int textureWidthIn, final int textureHeightIn) {
        super(modelSize, p_i1167_2_, textureWidthIn, textureHeightIn);
    }
    
    public ModelZombie(final float modelSize, final boolean p_i1168_2_) {
        super(modelSize, 0.0f, 64, p_i1168_2_ ? 32 : 64);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        final float f = MathHelper.zerodayisaminecraftcheat(this.zues * 3.1415927f);
        final float f2 = MathHelper.zerodayisaminecraftcheat((1.0f - (1.0f - this.zues) * (1.0f - this.zues)) * 3.1415927f);
        this.f.momgetthecamera = 0.0f;
        this.g.momgetthecamera = 0.0f;
        this.f.vape = -(0.1f - f * 0.6f);
        this.g.vape = 0.1f - f * 0.6f;
        this.f.flux = -1.5707964f;
        this.g.flux = -1.5707964f;
        final ModelRenderer f3 = this.f;
        f3.flux -= f * 1.2f - f2 * 0.4f;
        final ModelRenderer g = this.g;
        g.flux -= f * 1.2f - f2 * 0.4f;
        final ModelRenderer f4 = this.f;
        f4.momgetthecamera += MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer g2 = this.g;
        g2.momgetthecamera -= MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer f5 = this.f;
        f5.flux += MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
        final ModelRenderer g3 = this.g;
        g3.flux -= MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
    }
}

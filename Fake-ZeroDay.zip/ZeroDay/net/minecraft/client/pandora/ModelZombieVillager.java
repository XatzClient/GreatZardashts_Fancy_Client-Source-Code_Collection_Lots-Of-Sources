// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.MathHelper;
import net.minecraft.vape.Entity;

public class ModelZombieVillager extends ModelBiped
{
    public ModelZombieVillager() {
        this(0.0f, 0.0f, false);
    }
    
    public ModelZombieVillager(final float p_i1165_1_, final float p_i1165_2_, final boolean p_i1165_3_) {
        super(p_i1165_1_, 0.0f, 64, p_i1165_3_ ? 32 : 64);
        if (p_i1165_3_) {
            (this.c = new ModelRenderer(this, 0, 0)).zerodayisaminecraftcheat(-4.0f, -10.0f, -4.0f, 8, 8, 8, p_i1165_1_);
            this.c.zerodayisaminecraftcheat(0.0f, 0.0f + p_i1165_2_, 0.0f);
        }
        else {
            (this.c = new ModelRenderer(this)).zerodayisaminecraftcheat(0.0f, 0.0f + p_i1165_2_, 0.0f);
            this.c.zerodayisaminecraftcheat(0, 32).zerodayisaminecraftcheat(-4.0f, -10.0f, -4.0f, 8, 10, 8, p_i1165_1_);
            this.c.zerodayisaminecraftcheat(24, 32).zerodayisaminecraftcheat(-1.0f, -3.0f, -6.0f, 2, 4, 2, p_i1165_1_);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final float p_78087_1_, final float p_78087_2_, final float p_78087_3_, final float p_78087_4_, final float p_78087_5_, final float p_78087_6_, final Entity entityIn) {
        super.zerodayisaminecraftcheat(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
        final float f = MathHelper.zerodayisaminecraftcheat(this.zues * 3.1415927f);
        final float f2 = MathHelper.zerodayisaminecraftcheat((1.0f - (1.0f - this.zues) * (1.0f - this.zues)) * 3.1415927f);
        this.f.momgetthecamera = 0.0f;
        this.g.momgetthecamera = 0.0f;
        this.f.vape = -(0.1f - f * 0.6f);
        this.g.vape = 0.1f - f * 0.6f;
        this.f.flux = -1.5707964f;
        this.g.flux = -1.5707964f;
        final ModelRenderer f3 = this.f;
        f3.flux -= f * 1.2f - f2 * 0.4f;
        final ModelRenderer g = this.g;
        g.flux -= f * 1.2f - f2 * 0.4f;
        final ModelRenderer f4 = this.f;
        f4.momgetthecamera += MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer g2 = this.g;
        g2.momgetthecamera -= MathHelper.zeroday(p_78087_3_ * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer f5 = this.f;
        f5.flux += MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
        final ModelRenderer g3 = this.g;
        g3.flux -= MathHelper.zerodayisaminecraftcheat(p_78087_3_ * 0.067f) * 0.05f;
    }
}

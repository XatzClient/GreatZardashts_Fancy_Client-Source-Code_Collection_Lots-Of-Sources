// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

public class TextureOffset
{
    public final int zerodayisaminecraftcheat;
    public final int zeroday;
    
    public TextureOffset(final int textureOffsetXIn, final int textureOffsetYIn) {
        this.zerodayisaminecraftcheat = textureOffsetXIn;
        this.zeroday = textureOffsetYIn;
    }
}

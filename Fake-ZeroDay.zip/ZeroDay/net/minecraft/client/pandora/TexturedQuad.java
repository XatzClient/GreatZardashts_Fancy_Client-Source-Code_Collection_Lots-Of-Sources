// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.pandora;

import net.minecraft.o.Vec3;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import sigma.zerodayisaminecraftcheat.c;
import net.minecraft.l.Config;
import net.minecraft.client.a.WorldRenderer;

public class TexturedQuad
{
    public PositionTextureVertex[] zerodayisaminecraftcheat;
    public int zeroday;
    private boolean sigma;
    private static final String pandora = "CL_00000850";
    
    public TexturedQuad(final PositionTextureVertex[] vertices) {
        this.zerodayisaminecraftcheat = vertices;
        this.zeroday = vertices.length;
    }
    
    public TexturedQuad(final PositionTextureVertex[] vertices, final int texcoordU1, final int texcoordV1, final int texcoordU2, final int texcoordV2, final float textureWidth, final float textureHeight) {
        this(vertices);
        final float f = 0.0f / textureWidth;
        final float f2 = 0.0f / textureHeight;
        vertices[0] = vertices[0].zerodayisaminecraftcheat(texcoordU2 / textureWidth - f, texcoordV1 / textureHeight + f2);
        vertices[1] = vertices[1].zerodayisaminecraftcheat(texcoordU1 / textureWidth + f, texcoordV1 / textureHeight + f2);
        vertices[2] = vertices[2].zerodayisaminecraftcheat(texcoordU1 / textureWidth + f, texcoordV2 / textureHeight - f2);
        vertices[3] = vertices[3].zerodayisaminecraftcheat(texcoordU2 / textureWidth - f, texcoordV2 / textureHeight - f2);
    }
    
    public void zerodayisaminecraftcheat() {
        final PositionTextureVertex[] apositiontexturevertex = new PositionTextureVertex[this.zerodayisaminecraftcheat.length];
        for (int i = 0; i < this.zerodayisaminecraftcheat.length; ++i) {
            apositiontexturevertex[i] = this.zerodayisaminecraftcheat[this.zerodayisaminecraftcheat.length - i - 1];
        }
        this.zerodayisaminecraftcheat = apositiontexturevertex;
    }
    
    public void zerodayisaminecraftcheat(final WorldRenderer renderer, final float scale) {
        final Vec3 vec3 = this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat[0].zerodayisaminecraftcheat);
        final Vec3 vec4 = this.zerodayisaminecraftcheat[1].zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat[2].zerodayisaminecraftcheat);
        final Vec3 vec5 = vec4.sigma(vec3).zerodayisaminecraftcheat();
        float f = (float)vec5.zerodayisaminecraftcheat;
        float f2 = (float)vec5.zeroday;
        float f3 = (float)vec5.sigma;
        if (this.sigma) {
            f = -f;
            f2 = -f2;
            f3 = -f3;
        }
        if (Config.aC()) {
            renderer.zerodayisaminecraftcheat(7, c.zues);
        }
        else {
            renderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.sigma);
        }
        for (int i = 0; i < 4; ++i) {
            final PositionTextureVertex positiontexturevertex = this.zerodayisaminecraftcheat[i];
            renderer.zeroday(positiontexturevertex.zerodayisaminecraftcheat.zerodayisaminecraftcheat * scale, positiontexturevertex.zerodayisaminecraftcheat.zeroday * scale, positiontexturevertex.zerodayisaminecraftcheat.sigma * scale).zerodayisaminecraftcheat(positiontexturevertex.zeroday, positiontexturevertex.sigma).sigma(f, f2, f3).zues();
        }
        Tessellator.zerodayisaminecraftcheat().zeroday();
    }
}

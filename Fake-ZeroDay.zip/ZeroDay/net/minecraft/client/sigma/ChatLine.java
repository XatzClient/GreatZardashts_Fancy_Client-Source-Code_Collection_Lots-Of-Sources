// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.o.IChatComponent;

public class ChatLine
{
    private final int zerodayisaminecraftcheat;
    private final IChatComponent zeroday;
    private final int sigma;
    
    public ChatLine(final int p_i45000_1_, final IChatComponent p_i45000_2_, final int p_i45000_3_) {
        this.zeroday = p_i45000_2_;
        this.zerodayisaminecraftcheat = p_i45000_1_;
        this.sigma = p_i45000_3_;
    }
    
    public IChatComponent zerodayisaminecraftcheat() {
        return this.zeroday;
    }
    
    public int zeroday() {
        return this.zerodayisaminecraftcheat;
    }
    
    public int sigma() {
        return this.sigma;
    }
}

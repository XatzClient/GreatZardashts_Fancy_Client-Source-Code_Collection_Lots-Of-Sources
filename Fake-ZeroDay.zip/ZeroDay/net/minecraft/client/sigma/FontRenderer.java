// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.util.Hashtable;
import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.a.WorldRenderer;
import java.util.Iterator;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.Tessellator;
import net.minecraft.l.CustomColorizer;
import net.minecraft.l.Config;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.L;
import net.minecraft.client.flux.NetworkPlayerInfo;
import zeroday.pandora.zerodayisaminecraftcheat.d.av;
import net.minecraft.client.Minecraft;
import com.ibm.icu.text.ArabicShapingException;
import com.ibm.icu.text.Bidi;
import com.ibm.icu.text.ArabicShaping;
import org.lwjgl.opengl.GL11;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import java.awt.image.BufferedImage;
import java.io.IOException;
import net.minecraft.client.a.zues.TextureUtil;
import net.minecraft.client.b.IResourceManager;
import net.minecraft.client.c.GameSettings;
import net.minecraft.client.a.zues.TextureManager;
import java.util.Random;
import java.util.ArrayList;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.b.IResourceManagerReloadListener;

public class FontRenderer implements IResourceManagerReloadListener
{
    private static final ResourceLocation[] momgetthecamera;
    private float[] a;
    public static ArrayList<String> zerodayisaminecraftcheat;
    public int zeroday;
    public Random sigma;
    private byte[] b;
    private int[] c;
    private ResourceLocation d;
    private final TextureManager e;
    private float f;
    private float g;
    private boolean h;
    private boolean i;
    private float j;
    private float k;
    private float l;
    private float m;
    private int n;
    private boolean o;
    private boolean p;
    private boolean q;
    private boolean r;
    private boolean s;
    public GameSettings pandora;
    public ResourceLocation zues;
    public boolean flux;
    public float vape;
    
    static {
        momgetthecamera = new ResourceLocation[256];
        FontRenderer.zerodayisaminecraftcheat = new ArrayList<String>();
    }
    
    public FontRenderer(final GameSettings gameSettingsIn, final ResourceLocation location, final TextureManager textureManagerIn, final boolean unicode) {
        this.a = new float[256];
        this.zeroday = 9;
        this.sigma = new Random();
        this.b = new byte[65536];
        this.c = new int[32];
        this.flux = true;
        this.vape = 1.0f;
        this.pandora = gameSettingsIn;
        this.zues = location;
        this.d = location;
        this.e = textureManagerIn;
        this.h = unicode;
        this.zerodayisaminecraftcheat(this.d = sigma(this.zues));
        for (int i = 0; i < 32; ++i) {
            final int j = (i >> 3 & 0x1) * 85;
            int k = (i >> 2 & 0x1) * 170 + j;
            int l = (i >> 1 & 0x1) * 170 + j;
            int i2 = (i >> 0 & 0x1) * 170 + j;
            if (i == 6) {
                k += 85;
            }
            if (gameSettingsIn.zues) {
                final int j2 = (k * 30 + l * 59 + i2 * 11) / 100;
                final int k2 = (k * 30 + l * 70) / 100;
                final int l2 = (k * 30 + i2 * 70) / 100;
                k = j2;
                l = k2;
                i2 = l2;
            }
            if (i >= 16) {
                k /= 4;
                l /= 4;
                i2 /= 4;
            }
            this.c[i] = ((k & 0xFF) << 16 | (l & 0xFF) << 8 | (i2 & 0xFF));
        }
        this.zues();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final IResourceManager resourceManager) {
        this.d = sigma(this.zues);
        for (int i = 0; i < FontRenderer.momgetthecamera.length; ++i) {
            FontRenderer.momgetthecamera[i] = null;
        }
        this.pandora();
        this.zues();
    }
    
    private void pandora() {
        BufferedImage bufferedimage;
        try {
            bufferedimage = TextureUtil.zerodayisaminecraftcheat(this.zeroday(this.d));
        }
        catch (IOException ioexception) {
            throw new RuntimeException(ioexception);
        }
        final int i = bufferedimage.getWidth();
        final int j = bufferedimage.getHeight();
        final int k = i / 16;
        final int l = j / 16;
        final float f = i / 128.0f;
        this.vape = f;
        final int[] aint = new int[i * j];
        bufferedimage.getRGB(0, 0, i, j, aint, 0, i);
        for (int i2 = 0; i2 < 256; ++i2) {
            final int j2 = i2 % 16;
            final int k2 = i2 / 16;
            int l2;
            int i3;
            boolean flag;
            int j3;
            int k3;
            int l3;
            int i4;
            for (l2 = 0, l2 = k - 1; l2 >= 0; --l2) {
                i3 = j2 * k + l2;
                for (flag = true, j3 = 0; j3 < l && flag; ++j3) {
                    k3 = (k2 * l + j3) * i;
                    l3 = aint[i3 + k3];
                    i4 = (l3 >> 24 & 0xFF);
                    if (i4 > 16) {
                        flag = false;
                    }
                }
                if (!flag) {
                    break;
                }
            }
            if (i2 == 65) {
                i2 = i2;
            }
            if (i2 == 32) {
                if (k <= 8) {
                    l2 = (int)(2.0f * f);
                }
                else {
                    l2 = (int)(1.5f * f);
                }
            }
            this.a[i2] = (l2 + 1) / f + 1.0f;
        }
        this.vape();
    }
    
    private void zues() {
        InputStream inputstream = null;
        try {
            inputstream = this.zeroday(new ResourceLocation("font/glyph_sizes.bin"));
            inputstream.read(this.b);
        }
        catch (IOException ioexception) {
            throw new RuntimeException(ioexception);
        }
        finally {
            IOUtils.closeQuietly(inputstream);
        }
        IOUtils.closeQuietly(inputstream);
    }
    
    private float zerodayisaminecraftcheat(final char p_181559_1_, final boolean p_181559_2_) {
        if (p_181559_1_ == ' ') {
            return this.a[p_181559_1_];
        }
        final int i = "\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8�\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1����������\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261�\u2265\u2264\u2320\u2321\u00f7\u2248�\u2219�\u221a\u207f�\u25a0\u0000".indexOf(p_181559_1_);
        return (i != -1 && !this.h) ? this.zerodayisaminecraftcheat(i, p_181559_2_) : this.zeroday(p_181559_1_, p_181559_2_);
    }
    
    private float zerodayisaminecraftcheat(final int p_78266_1_, final boolean p_78266_2_) {
        final int i = p_78266_1_ % 16 * 8;
        final int j = p_78266_1_ / 16 * 8;
        final int k = p_78266_2_ ? 1 : 0;
        this.zerodayisaminecraftcheat(this.d);
        final float f = this.a[p_78266_1_];
        final float f2 = 7.99f;
        GL11.glBegin(5);
        GL11.glTexCoord2f(i / 128.0f, j / 128.0f);
        GL11.glVertex3f(this.f + k, this.g, 0.0f);
        GL11.glTexCoord2f(i / 128.0f, (j + 7.99f) / 128.0f);
        GL11.glVertex3f(this.f - k, this.g + 7.99f, 0.0f);
        GL11.glTexCoord2f((i + f2 - 1.0f) / 128.0f, j / 128.0f);
        GL11.glVertex3f(this.f + f2 - 1.0f + k, this.g, 0.0f);
        GL11.glTexCoord2f((i + f2 - 1.0f) / 128.0f, (j + 7.99f) / 128.0f);
        GL11.glVertex3f(this.f + f2 - 1.0f - k, this.g + 7.99f, 0.0f);
        GL11.glEnd();
        return f;
    }
    
    private ResourceLocation zerodayisaminecraftcheat(final int p_111271_1_) {
        if (FontRenderer.momgetthecamera[p_111271_1_] == null) {
            FontRenderer.momgetthecamera[p_111271_1_] = new ResourceLocation(String.format("textures/font/unicode_page_%02x.png", p_111271_1_));
            FontRenderer.momgetthecamera[p_111271_1_] = sigma(FontRenderer.momgetthecamera[p_111271_1_]);
        }
        return FontRenderer.momgetthecamera[p_111271_1_];
    }
    
    private void zeroday(final int p_78257_1_) {
        this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(p_78257_1_));
    }
    
    private float zeroday(final char p_78277_1_, final boolean p_78277_2_) {
        if (this.b[p_78277_1_] == 0) {
            return 0.0f;
        }
        final int i = p_78277_1_ / '\u0100';
        this.zeroday(i);
        int j = this.b[p_78277_1_] >>> 4;
        final int k = this.b[p_78277_1_] & 0xF;
        j &= 0xF;
        final float f = (float)j;
        final float f2 = (float)(k + 1);
        final float f3 = p_78277_1_ % '\u0010' * 16 + f;
        final float f4 = (float)((p_78277_1_ & '\u00ff') / 16 * 16);
        final float f5 = f2 - f - 0.02f;
        final float f6 = p_78277_2_ ? 1.0f : 0.0f;
        GL11.glBegin(5);
        GL11.glTexCoord2f(f3 / 256.0f, f4 / 256.0f);
        GL11.glVertex3f(this.f + f6, this.g, 0.0f);
        GL11.glTexCoord2f(f3 / 256.0f, (f4 + 15.98f) / 256.0f);
        GL11.glVertex3f(this.f - f6, this.g + 7.99f, 0.0f);
        GL11.glTexCoord2f((f3 + f5) / 256.0f, f4 / 256.0f);
        GL11.glVertex3f(this.f + f5 / 2.0f + f6, this.g, 0.0f);
        GL11.glTexCoord2f((f3 + f5) / 256.0f, (f4 + 15.98f) / 256.0f);
        GL11.glVertex3f(this.f + f5 / 2.0f - f6, this.g + 7.99f, 0.0f);
        GL11.glEnd();
        return (f2 - f) / 2.0f + 1.0f;
    }
    
    public int zerodayisaminecraftcheat(final String text, final float x, final float y, final int color) {
        return this.zerodayisaminecraftcheat(text, x, y, color, true);
    }
    
    public int zerodayisaminecraftcheat(final String text, final int x, final int y, final int color) {
        return this.flux ? this.zerodayisaminecraftcheat(text, (float)x, (float)y, color, false) : 0;
    }
    
    public int zerodayisaminecraftcheat(final String text, final float x, final float y, final int color, final boolean dropShadow) {
        this.sigma();
        this.flux();
        int i;
        if (dropShadow) {
            i = this.zeroday(text, x + 1.0f, y + 1.0f, color, true);
            i = Math.max(i, this.zeroday(text, x, y, color, false));
        }
        else {
            i = this.zeroday(text, x, y, color, false);
        }
        return i;
    }
    
    private String sigma(final String p_147647_1_) {
        try {
            final Bidi bidi = new Bidi(new ArabicShaping(8).shape(p_147647_1_), 127);
            bidi.setReorderingMode(0);
            return bidi.writeReordered(2);
        }
        catch (ArabicShapingException var3) {
            return p_147647_1_;
        }
    }
    
    private void flux() {
        this.o = false;
        this.p = false;
        this.q = false;
        this.r = false;
        this.s = false;
    }
    
    private void zerodayisaminecraftcheat(String p_78255_1_, final boolean p_78255_2_) {
        if (Minecraft.s().o() != null && av.c) {
            final Iterator<NetworkPlayerInfo> itr = Minecraft.s().o().sigma().iterator();
            int i = 0;
            while (itr.hasNext()) {
                final NetworkPlayerInfo info = itr.next();
                final String name = info.h();
                ++i;
                if (p_78255_1_.contains(Minecraft.s().e.l_())) {
                    p_78255_1_ = p_78255_1_.replace(Minecraft.s().e.l_(), L.zerodayisaminecraftcheat);
                }
                else {
                    if (!L.zeroday) {
                        continue;
                    }
                    if (!p_78255_1_.toLowerCase().contains(name.toLowerCase())) {
                        continue;
                    }
                    p_78255_1_ = p_78255_1_.replace(name, "Player " + i);
                }
            }
        }
        for (int j = 0; j < p_78255_1_.length(); ++j) {
            char c0 = p_78255_1_.charAt(j);
            if (c0 == '�' && j + 1 < p_78255_1_.length()) {
                int i2 = "0123456789abcdefklmnor".indexOf(p_78255_1_.toLowerCase().charAt(j + 1));
                if (i2 < 16) {
                    this.o = false;
                    this.p = false;
                    this.s = false;
                    this.r = false;
                    this.q = false;
                    if (i2 < 0 || i2 > 15) {
                        i2 = 15;
                    }
                    if (p_78255_2_) {
                        i2 += 16;
                    }
                    int j2 = this.c[i2];
                    if (Config.at()) {
                        j2 = CustomColorizer.zerodayisaminecraftcheat(i2, j2);
                    }
                    this.n = j2;
                    this.zerodayisaminecraftcheat((j2 >> 16) / 255.0f, (j2 >> 8 & 0xFF) / 255.0f, (j2 & 0xFF) / 255.0f, this.m);
                }
                else if (i2 == 16) {
                    this.o = true;
                }
                else if (i2 == 17) {
                    this.p = true;
                }
                else if (i2 == 18) {
                    this.s = true;
                }
                else if (i2 == 19) {
                    this.r = true;
                }
                else if (i2 == 20) {
                    this.q = true;
                }
                else if (i2 == 21) {
                    this.o = false;
                    this.p = false;
                    this.s = false;
                    this.r = false;
                    this.q = false;
                    this.zerodayisaminecraftcheat(this.j, this.k, this.l, this.m);
                }
                ++j;
            }
            else {
                int k = "\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8�\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1����������\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261�\u2265\u2264\u2320\u2321\u00f7\u2248�\u2219�\u221a\u207f�\u25a0\u0000".indexOf(c0);
                if (this.o && k != -1) {
                    final int l = this.zerodayisaminecraftcheat(c0);
                    char c2;
                    do {
                        k = this.sigma.nextInt("\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8�\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1����������\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261�\u2265\u2264\u2320\u2321\u00f7\u2248�\u2219�\u221a\u207f�\u25a0\u0000".length());
                        c2 = "\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8�\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1����������\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261�\u2265\u2264\u2320\u2321\u00f7\u2248�\u2219�\u221a\u207f�\u25a0\u0000".charAt(k);
                    } while (l != this.zerodayisaminecraftcheat(c2));
                    c0 = c2;
                }
                final float f1 = this.h ? 0.5f : (1.0f / this.vape);
                final boolean flag = (c0 == '\0' || k == -1 || this.h) && p_78255_2_;
                if (flag) {
                    this.f -= f1;
                    this.g -= f1;
                }
                float f2 = this.zerodayisaminecraftcheat(c0, this.q);
                if (flag) {
                    this.f += f1;
                    this.g += f1;
                }
                if (this.p) {
                    this.f += f1;
                    if (flag) {
                        this.f -= f1;
                        this.g -= f1;
                    }
                    this.zerodayisaminecraftcheat(c0, this.q);
                    this.f -= f1;
                    if (flag) {
                        this.f += f1;
                        this.g += f1;
                    }
                    f2 += f1;
                }
                if (this.s) {
                    final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
                    final WorldRenderer worldrenderer = tessellator.sigma();
                    GlStateManager.n();
                    worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.zues);
                    worldrenderer.zeroday(this.f, this.g + this.zeroday / 2, 0.0).zues();
                    worldrenderer.zeroday(this.f + f2, this.g + this.zeroday / 2, 0.0).zues();
                    worldrenderer.zeroday(this.f + f2, this.g + this.zeroday / 2 - 1.0f, 0.0).zues();
                    worldrenderer.zeroday(this.f, this.g + this.zeroday / 2 - 1.0f, 0.0).zues();
                    tessellator.zeroday();
                    GlStateManager.m();
                }
                if (this.r) {
                    final Tessellator tessellator2 = Tessellator.zerodayisaminecraftcheat();
                    final WorldRenderer worldrenderer2 = tessellator2.sigma();
                    GlStateManager.n();
                    worldrenderer2.zerodayisaminecraftcheat(7, DefaultVertexFormats.zues);
                    final int m = this.r ? -1 : 0;
                    worldrenderer2.zeroday(this.f + m, this.g + this.zeroday, 0.0).zues();
                    worldrenderer2.zeroday(this.f + f2, this.g + this.zeroday, 0.0).zues();
                    worldrenderer2.zeroday(this.f + f2, this.g + this.zeroday - 1.0f, 0.0).zues();
                    worldrenderer2.zeroday(this.f + m, this.g + this.zeroday - 1.0f, 0.0).zues();
                    tessellator2.zeroday();
                    GlStateManager.m();
                }
                this.f += f2;
            }
        }
    }
    
    private int zerodayisaminecraftcheat(final String text, int x, final int y, final int p_78274_4_, final int color, final boolean dropShadow) {
        if (this.i) {
            final int i = this.zerodayisaminecraftcheat(this.sigma(text));
            x = x + p_78274_4_ - i;
        }
        return this.zeroday(text, (float)x, (float)y, color, dropShadow);
    }
    
    private int zeroday(String text, final float x, final float y, int color, final boolean dropShadow) {
        if (text == null) {
            return 0;
        }
        if (this.i) {
            text = this.sigma(text);
        }
        if ((color & 0xFC000000) == 0x0) {
            color |= 0xFF000000;
        }
        if (dropShadow) {
            color = ((color & 0xFCFCFC) >> 2 | (color & 0xFF000000));
        }
        this.j = (color >> 16 & 0xFF) / 255.0f;
        this.k = (color >> 8 & 0xFF) / 255.0f;
        this.l = (color & 0xFF) / 255.0f;
        this.m = (color >> 24 & 0xFF) / 255.0f;
        this.zerodayisaminecraftcheat(this.j, this.k, this.l, this.m);
        this.f = x;
        this.g = y;
        this.zerodayisaminecraftcheat(text, dropShadow);
        return (int)this.f;
    }
    
    public int zerodayisaminecraftcheat(final String text) {
        if (text == null) {
            return 0;
        }
        float f = 0.0f;
        boolean flag = false;
        for (int i = 0; i < text.length(); ++i) {
            char c0 = text.charAt(i);
            float f2 = this.sigma(c0);
            if (f2 < 0.0f && i < text.length() - 1) {
                ++i;
                c0 = text.charAt(i);
                if (c0 != 'l' && c0 != 'L') {
                    if (c0 == 'r' || c0 == 'R') {
                        flag = false;
                    }
                }
                else {
                    flag = true;
                }
                f2 = 0.0f;
            }
            f += f2;
            if (flag && f2 > 0.0f) {
                ++f;
            }
        }
        return (int)f;
    }
    
    public int zerodayisaminecraftcheat(final char character) {
        return Math.round(this.sigma(character));
    }
    
    private float sigma(final char p_getCharWidthFloat_1_) {
        if (p_getCharWidthFloat_1_ == '�') {
            return -1.0f;
        }
        if (p_getCharWidthFloat_1_ == ' ') {
            return this.a[32];
        }
        final int i = "\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8�\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1����������\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261�\u2265\u2264\u2320\u2321\u00f7\u2248�\u2219�\u221a\u207f�\u25a0\u0000".indexOf(p_getCharWidthFloat_1_);
        if (p_getCharWidthFloat_1_ > '\0' && i != -1 && !this.h) {
            return this.a[i];
        }
        if (this.b[p_getCharWidthFloat_1_] != 0) {
            int j = this.b[p_getCharWidthFloat_1_] >>> 4;
            int k = this.b[p_getCharWidthFloat_1_] & 0xF;
            j &= 0xF;
            return (float)((++k - j) / 2 + 1);
        }
        return 0.0f;
    }
    
    public String zerodayisaminecraftcheat(final String text, final int width) {
        return this.zerodayisaminecraftcheat(text, width, false);
    }
    
    public String zerodayisaminecraftcheat(final String text, final int width, final boolean reverse) {
        final StringBuilder stringbuilder = new StringBuilder();
        float f = 0.0f;
        final int i = reverse ? (text.length() - 1) : 0;
        final int j = reverse ? -1 : 1;
        boolean flag = false;
        boolean flag2 = false;
        for (int k = i; k >= 0 && k < text.length() && f < width; k += j) {
            final char c0 = text.charAt(k);
            final float f2 = this.sigma(c0);
            if (flag) {
                flag = false;
                if (c0 != 'l' && c0 != 'L') {
                    if (c0 == 'r' || c0 == 'R') {
                        flag2 = false;
                    }
                }
                else {
                    flag2 = true;
                }
            }
            else if (f2 < 0.0f) {
                flag = true;
            }
            else {
                f += f2;
                if (flag2) {
                    ++f;
                }
            }
            if (f > width) {
                break;
            }
            if (reverse) {
                stringbuilder.insert(0, c0);
            }
            else {
                stringbuilder.append(c0);
            }
        }
        return stringbuilder.toString();
    }
    
    private String pandora(String text) {
        while (text != null && text.endsWith("\n")) {
            text = text.substring(0, text.length() - 1);
        }
        return text;
    }
    
    public void zerodayisaminecraftcheat(String str, final int x, final int y, final int wrapWidth, final int textColor) {
        this.flux();
        this.n = textColor;
        str = this.pandora(str);
        this.zerodayisaminecraftcheat(str, x, y, wrapWidth, false);
    }
    
    private void zerodayisaminecraftcheat(final String str, final int x, int y, final int wrapWidth, final boolean addShadow) {
        for (final Object s : this.sigma(str, wrapWidth)) {
            this.zerodayisaminecraftcheat((String)s, x, y, wrapWidth, this.n, addShadow);
            y += this.zeroday;
        }
    }
    
    public int zeroday(final String p_78267_1_, final int p_78267_2_) {
        return this.zeroday * this.sigma(p_78267_1_, p_78267_2_).size();
    }
    
    public void zerodayisaminecraftcheat(final boolean unicodeFlagIn) {
        this.h = unicodeFlagIn;
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.h;
    }
    
    public void zeroday(final boolean bidiFlagIn) {
        this.i = bidiFlagIn;
    }
    
    public List sigma(final String str, final int wrapWidth) {
        return Arrays.asList(this.pandora(str, wrapWidth).split("\n"));
    }
    
    String pandora(final String str, final int wrapWidth) {
        final int i = this.zues(str, wrapWidth);
        if (str.length() <= i) {
            return str;
        }
        final String s = str.substring(0, i);
        final char c0 = str.charAt(i);
        final boolean flag = c0 == ' ' || c0 == '\n';
        final String s2 = String.valueOf(zeroday(s)) + str.substring(i + (flag ? 1 : 0));
        return String.valueOf(s) + "\n" + this.pandora(s2, wrapWidth);
    }
    
    private int zues(final String str, final int wrapWidth) {
        final int i = str.length();
        float f = 0.0f;
        int j = 0;
        int k = -1;
        boolean flag = false;
        while (j < i) {
            final char c0 = str.charAt(j);
            Label_0163: {
                switch (c0) {
                    case '\n': {
                        --j;
                        break Label_0163;
                    }
                    case ' ': {
                        k = j;
                        break;
                    }
                    case '�': {
                        if (j >= i - 1) {
                            break Label_0163;
                        }
                        ++j;
                        final char c2 = str.charAt(j);
                        if (c2 == 'l' || c2 == 'L') {
                            flag = true;
                            break Label_0163;
                        }
                        if (c2 == 'r' || c2 == 'R' || pandora(c2)) {
                            flag = false;
                        }
                        break Label_0163;
                    }
                }
                f += this.sigma(c0);
                if (flag) {
                    ++f;
                }
            }
            if (c0 == '\n') {
                k = ++j;
                break;
            }
            if (f > wrapWidth) {
                break;
            }
            ++j;
        }
        return (j != i && k != -1 && k < j) ? k : j;
    }
    
    private static boolean pandora(final char colorChar) {
        return (colorChar >= '0' && colorChar <= '9') || (colorChar >= 'a' && colorChar <= 'f') || (colorChar >= 'A' && colorChar <= 'F');
    }
    
    private static boolean zues(final char formatChar) {
        return (formatChar >= 'k' && formatChar <= 'o') || (formatChar >= 'K' && formatChar <= 'O') || formatChar == 'r' || formatChar == 'R';
    }
    
    public static String zeroday(final String text) {
        String s = "";
        int i = -1;
        final int j = text.length();
        while ((i = text.indexOf(167, i + 1)) != -1) {
            if (i < j - 1) {
                final char c0 = text.charAt(i + 1);
                if (pandora(c0)) {
                    s = "�" + c0;
                }
                else {
                    if (!zues(c0)) {
                        continue;
                    }
                    s = String.valueOf(s) + "�" + c0;
                }
            }
        }
        return s;
    }
    
    public boolean zeroday() {
        return this.i;
    }
    
    public int zeroday(final char character) {
        final int i = "0123456789abcdef".indexOf(character);
        if (i >= 0 && i < this.c.length) {
            int j = this.c[i];
            if (Config.at()) {
                j = CustomColorizer.zerodayisaminecraftcheat(i, j);
            }
            return j;
        }
        return 16777215;
    }
    
    protected void zerodayisaminecraftcheat(final float p_setColor_1_, final float p_setColor_2_, final float p_setColor_3_, final float p_setColor_4_) {
        GlStateManager.sigma(p_setColor_1_, p_setColor_2_, p_setColor_3_, p_setColor_4_);
    }
    
    protected void sigma() {
        GlStateManager.pandora();
    }
    
    protected void zerodayisaminecraftcheat(final ResourceLocation p_bindTexture_1_) {
        this.e.zerodayisaminecraftcheat(p_bindTexture_1_);
    }
    
    protected InputStream zeroday(final ResourceLocation p_getResourceInputStream_1_) throws IOException {
        return Minecraft.s().J().zerodayisaminecraftcheat(p_getResourceInputStream_1_).zeroday();
    }
    
    private void vape() {
        final String s = this.d.zeroday();
        final String s2 = ".png";
        if (s.endsWith(s2)) {
            final String s3 = String.valueOf(s.substring(0, s.length() - s2.length())) + ".properties";
            try {
                final ResourceLocation resourcelocation = new ResourceLocation(this.d.sigma(), s3);
                final InputStream inputstream = Config.zerodayisaminecraftcheat(Config.M(), resourcelocation);
                if (inputstream == null) {
                    return;
                }
                Config.pandora("Loading " + s3);
                final Properties properties = new Properties();
                properties.load(inputstream);
                for (final Object s4 : ((Hashtable<Object, V>)properties).keySet()) {
                    final String s5 = "width.";
                    if (((String)s4).startsWith(s5)) {
                        final String s6 = ((String)s4).substring(s5.length());
                        final int i = Config.zerodayisaminecraftcheat(s6, -1);
                        if (i < 0 || i >= this.a.length) {
                            continue;
                        }
                        final String s7 = properties.getProperty((String)s4);
                        final float f = Config.zerodayisaminecraftcheat(s7, -1.0f);
                        if (f < 0.0f) {
                            continue;
                        }
                        this.a[i] = f;
                    }
                }
            }
            catch (FileNotFoundException ex) {}
            catch (IOException ioexception) {
                ioexception.printStackTrace();
            }
        }
    }
    
    private static ResourceLocation sigma(final ResourceLocation p_getHdFontLocation_0_) {
        if (!Config.av()) {
            return p_getHdFontLocation_0_;
        }
        if (p_getHdFontLocation_0_ == null) {
            return p_getHdFontLocation_0_;
        }
        String s = p_getHdFontLocation_0_.zeroday();
        final String s2 = "textures/";
        final String s3 = "mcpatcher/";
        if (!s.startsWith(s2)) {
            return p_getHdFontLocation_0_;
        }
        s = s.substring(s2.length());
        s = String.valueOf(s3) + s;
        final ResourceLocation resourcelocation = new ResourceLocation(p_getHdFontLocation_0_.sigma(), s);
        return Config.zeroday(Config.M(), resourcelocation) ? resourcelocation : p_getHdFontLocation_0_;
    }
}

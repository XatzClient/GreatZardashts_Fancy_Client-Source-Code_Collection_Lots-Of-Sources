// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.zues.TextureAtlasSprite;
import zeroday.pandora.zerodayisaminecraftcheat.h.ar;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.Tessellator;
import net.minecraft.o.ResourceLocation;

public class Gui
{
    public static final ResourceLocation m;
    public static final ResourceLocation n;
    public static final ResourceLocation o;
    protected float p;
    
    static {
        m = new ResourceLocation("textures/gui/options_background.png");
        n = new ResourceLocation("textures/gui/container/stats_icons.png");
        o = new ResourceLocation("textures/gui/icons.png");
    }
    
    protected void zues(int startX, int endX, final int y, final int color) {
        if (endX < startX) {
            final int i = startX;
            startX = endX;
            endX = i;
        }
        zerodayisaminecraftcheat(startX, y, endX + 1, y + 1, color);
    }
    
    protected void flux(final int x, int startY, int endY, final int color) {
        if (endY < startY) {
            final int i = startY;
            startY = endY;
            endY = i;
        }
        zerodayisaminecraftcheat(x, startY + 1, x + 1, endY, color);
    }
    
    public static void zerodayisaminecraftcheat(int left, int top, int right, int bottom, final int color) {
        if (left < right) {
            final int i = left;
            left = right;
            right = i;
        }
        if (top < bottom) {
            final int j = top;
            top = bottom;
            bottom = j;
        }
        final float f3 = (color >> 24 & 0xFF) / 255.0f;
        final float f4 = (color >> 16 & 0xFF) / 255.0f;
        final float f5 = (color >> 8 & 0xFF) / 255.0f;
        final float f6 = (color & 0xFF) / 255.0f;
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        GlStateManager.d();
        GlStateManager.n();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.sigma(f4, f5, f6, f3);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.zues);
        worldrenderer.zeroday(left, bottom, 0.0).zues();
        worldrenderer.zeroday(right, bottom, 0.0).zues();
        worldrenderer.zeroday(right, top, 0.0).zues();
        worldrenderer.zeroday(left, top, 0.0).zues();
        tessellator.zeroday();
        GlStateManager.m();
        GlStateManager.c();
    }
    
    public static void zeroday(final int left, final int top, final int right, final int bottom, final int color) {
        zerodayisaminecraftcheat(left, top, left + 3, bottom, color);
        zerodayisaminecraftcheat(left + 3, top, right, top + 3, color);
        zerodayisaminecraftcheat(right - 3, top + 3, right, bottom, color);
        zerodayisaminecraftcheat(left + 3, bottom - 3, right - 3, bottom, color);
        zerodayisaminecraftcheat(left, top, left + 1, bottom, color);
        zerodayisaminecraftcheat(left + 1, top, right, top + 1, color);
        zerodayisaminecraftcheat(right - 1, top + 1, right, bottom, color);
        zerodayisaminecraftcheat(left + 1, bottom - 1, right - 1, bottom, color);
        zerodayisaminecraftcheat(left + 3, top + 4, left + 4, bottom - 3, -870309856);
        zerodayisaminecraftcheat(left + 3, top + 3, right - 3, top + 4, -870309856);
        zerodayisaminecraftcheat(right - 4, top + 4, right - 3, bottom - 3, -870309856);
        zerodayisaminecraftcheat(left + 4, bottom - 4, right - 4, bottom - 3, -870309856);
        zerodayisaminecraftcheat(left + 4, top + 4, right - 4, bottom - 4, color);
    }
    
    public static void zeroday(double left, double top, double right, double bottom, final int color) {
        if (left < right) {
            final double i = left;
            left = right;
            right = i;
        }
        if (top < bottom) {
            final double j = top;
            top = bottom;
            bottom = j;
        }
        final float f3 = (color >> 24 & 0xFF) / 255.0f;
        final float f4 = (color >> 16 & 0xFF) / 255.0f;
        final float f5 = (color >> 8 & 0xFF) / 255.0f;
        final float f6 = (color & 0xFF) / 255.0f;
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        GlStateManager.d();
        GlStateManager.n();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.sigma(f4, f5, f6, f3);
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.zues);
        worldrenderer.zeroday(left, bottom, 0.0).zues();
        worldrenderer.zeroday(right, bottom, 0.0).zues();
        worldrenderer.zeroday(right, top, 0.0).zues();
        worldrenderer.zeroday(left, top, 0.0).zues();
        tessellator.zeroday();
        GlStateManager.m();
        GlStateManager.c();
    }
    
    protected void zerodayisaminecraftcheat(final int left, final int top, final int right, final int bottom, final int startColor, final int endColor) {
        final float f = (startColor >> 24 & 0xFF) / 255.0f;
        final float f2 = (startColor >> 16 & 0xFF) / 255.0f;
        final float f3 = (startColor >> 8 & 0xFF) / 255.0f;
        final float f4 = (startColor & 0xFF) / 255.0f;
        final float f5 = (endColor >> 24 & 0xFF) / 255.0f;
        final float f6 = (endColor >> 16 & 0xFF) / 255.0f;
        final float f7 = (endColor >> 8 & 0xFF) / 255.0f;
        final float f8 = (endColor & 0xFF) / 255.0f;
        GlStateManager.n();
        GlStateManager.d();
        GlStateManager.sigma();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.b(7425);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.flux);
        worldrenderer.zeroday(right, top, (double)this.p).zerodayisaminecraftcheat(f2, f3, f4, f).zues();
        worldrenderer.zeroday(left, top, (double)this.p).zerodayisaminecraftcheat(f2, f3, f4, f).zues();
        worldrenderer.zeroday(left, bottom, (double)this.p).zerodayisaminecraftcheat(f6, f7, f8, f5).zues();
        worldrenderer.zeroday(right, bottom, (double)this.p).zerodayisaminecraftcheat(f6, f7, f8, f5).zues();
        tessellator.zeroday();
        GlStateManager.b(7424);
        GlStateManager.c();
        GlStateManager.pandora();
        GlStateManager.m();
    }
    
    public static void zerodayisaminecraftcheat(final FontRenderer fontRendererIn, final String text, final int x, final int y, final int color) {
        fontRendererIn.zerodayisaminecraftcheat(text, (float)(x - fontRendererIn.zerodayisaminecraftcheat(text) / 2), (float)y, color);
    }
    
    public static void zerodayisaminecraftcheat(final ar fontRendererIn, final String text, final int x, final int y, final int color) {
        fontRendererIn.zerodayisaminecraftcheat(text, (float)(x - fontRendererIn.zeroday(text) / 2), (float)y, color);
    }
    
    public static void zeroday(final FontRenderer fontRendererIn, final String text, final int x, final int y, final int color) {
        fontRendererIn.zerodayisaminecraftcheat(text, (float)x, (float)y, color);
    }
    
    public void zeroday(final int x, final int y, final int textureX, final int textureY, final int width, final int height) {
        final float f = 0.00390625f;
        final float f2 = 0.00390625f;
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(x + 0, y + height, (double)this.p).zerodayisaminecraftcheat((textureX + 0) * f, (textureY + height) * f2).zues();
        worldrenderer.zeroday(x + width, y + height, (double)this.p).zerodayisaminecraftcheat((textureX + width) * f, (textureY + height) * f2).zues();
        worldrenderer.zeroday(x + width, y + 0, (double)this.p).zerodayisaminecraftcheat((textureX + width) * f, (textureY + 0) * f2).zues();
        worldrenderer.zeroday(x + 0, y + 0, (double)this.p).zerodayisaminecraftcheat((textureX + 0) * f, (textureY + 0) * f2).zues();
        tessellator.zeroday();
    }
    
    public void zerodayisaminecraftcheat(final float xCoord, final float yCoord, final int minU, final int minV, final int maxU, final int maxV) {
        final float f = 0.00390625f;
        final float f2 = 0.00390625f;
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(xCoord + 0.0f, yCoord + maxV, (double)this.p).zerodayisaminecraftcheat((minU + 0) * f, (minV + maxV) * f2).zues();
        worldrenderer.zeroday(xCoord + maxU, yCoord + maxV, (double)this.p).zerodayisaminecraftcheat((minU + maxU) * f, (minV + maxV) * f2).zues();
        worldrenderer.zeroday(xCoord + maxU, yCoord + 0.0f, (double)this.p).zerodayisaminecraftcheat((minU + maxU) * f, (minV + 0) * f2).zues();
        worldrenderer.zeroday(xCoord + 0.0f, yCoord + 0.0f, (double)this.p).zerodayisaminecraftcheat((minU + 0) * f, (minV + 0) * f2).zues();
        tessellator.zeroday();
    }
    
    public void zerodayisaminecraftcheat(final int xCoord, final int yCoord, final TextureAtlasSprite textureSprite, final int widthIn, final int heightIn) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(xCoord + 0, yCoord + heightIn, (double)this.p).zerodayisaminecraftcheat(textureSprite.zues(), textureSprite.momgetthecamera()).zues();
        worldrenderer.zeroday(xCoord + widthIn, yCoord + heightIn, (double)this.p).zerodayisaminecraftcheat(textureSprite.flux(), textureSprite.momgetthecamera()).zues();
        worldrenderer.zeroday(xCoord + widthIn, yCoord + 0, (double)this.p).zerodayisaminecraftcheat(textureSprite.flux(), textureSprite.vape()).zues();
        worldrenderer.zeroday(xCoord + 0, yCoord + 0, (double)this.p).zerodayisaminecraftcheat(textureSprite.zues(), textureSprite.vape()).zues();
        tessellator.zeroday();
    }
    
    public static void zerodayisaminecraftcheat(final int x, final int y, final float u, final float v, final int width, final int height, final float textureWidth, final float textureHeight) {
        final float f = 1.0f / textureWidth;
        final float f2 = 1.0f / textureHeight;
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(x, y + height, 0.0).zerodayisaminecraftcheat(u * f, (v + height) * f2).zues();
        worldrenderer.zeroday(x + width, y + height, 0.0).zerodayisaminecraftcheat((u + width) * f, (v + height) * f2).zues();
        worldrenderer.zeroday(x + width, y, 0.0).zerodayisaminecraftcheat((u + width) * f, v * f2).zues();
        worldrenderer.zeroday(x, y, 0.0).zerodayisaminecraftcheat(u * f, v * f2).zues();
        tessellator.zeroday();
    }
    
    public static void zerodayisaminecraftcheat(final int x, final int y, final float u, final float v, final int uWidth, final int vHeight, final int width, final int height, final float tileWidth, final float tileHeight) {
        final float f = 1.0f / tileWidth;
        final float f2 = 1.0f / tileHeight;
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(x, y + height, 0.0).zerodayisaminecraftcheat(u * f, (v + vHeight) * f2).zues();
        worldrenderer.zeroday(x + width, y + height, 0.0).zerodayisaminecraftcheat((u + uWidth) * f, (v + vHeight) * f2).zues();
        worldrenderer.zeroday(x + width, y, 0.0).zerodayisaminecraftcheat((u + uWidth) * f, v * f2).zues();
        worldrenderer.zeroday(x, y, 0.0).zerodayisaminecraftcheat(u * f, v * f2).zues();
        tessellator.zeroday();
    }
}

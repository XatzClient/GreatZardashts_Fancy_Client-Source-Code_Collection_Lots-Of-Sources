// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;

public class GuiButtonLanguage extends GuiButton
{
    public GuiButtonLanguage(final int buttonID, final int xPos, final int yPos) {
        super(buttonID, xPos, yPos, 20, 20, "");
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Minecraft mc, final int mouseX, final int mouseY) {
        if (this.a) {
            mc.I().zerodayisaminecraftcheat(GuiButton.zerodayisaminecraftcheat);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            final boolean flag = mouseX >= this.pandora && mouseY >= this.zues && mouseX < this.pandora + this.zeroday && mouseY < this.zues + this.sigma;
            int i = 106;
            if (flag) {
                i += this.sigma;
            }
            this.zeroday(this.pandora, this.zues, 0, i, this.zeroday, this.sigma);
        }
    }
}

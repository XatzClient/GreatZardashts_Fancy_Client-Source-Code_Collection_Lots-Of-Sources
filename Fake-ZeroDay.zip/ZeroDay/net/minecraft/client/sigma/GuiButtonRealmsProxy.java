// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.Minecraft;
import net.minecraft.i.RealmsButton;

public class GuiButtonRealmsProxy extends GuiButton
{
    private RealmsButton e;
    
    public GuiButtonRealmsProxy(final RealmsButton realmsButtonIn, final int buttonId, final int x, final int y, final String text) {
        super(buttonId, x, y, text);
        this.e = realmsButtonIn;
    }
    
    public GuiButtonRealmsProxy(final RealmsButton realmsButtonIn, final int buttonId, final int x, final int y, final String text, final int widthIn, final int heightIn) {
        super(buttonId, x, y, widthIn, heightIn, text);
        this.e = realmsButtonIn;
    }
    
    public int sigma() {
        return super.vape;
    }
    
    public boolean pandora() {
        return super.momgetthecamera;
    }
    
    public void zeroday(final boolean isEnabled) {
        super.momgetthecamera = isEnabled;
    }
    
    public void zerodayisaminecraftcheat(final String text) {
        super.flux = text;
    }
    
    @Override
    public int zeroday() {
        return super.zeroday();
    }
    
    public int zues() {
        return super.zues;
    }
    
    @Override
    public boolean sigma(final Minecraft mc, final int mouseX, final int mouseY) {
        if (super.sigma(mc, mouseX, mouseY)) {
            this.e.zeroday(mouseX, mouseY);
        }
        return super.sigma(mc, mouseX, mouseY);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY) {
        this.e.sigma(mouseX, mouseY);
    }
    
    public void zeroday(final Minecraft mc, final int mouseX, final int mouseY) {
        this.e.pandora(mouseX, mouseY);
    }
    
    public RealmsButton flux() {
        return this.e;
    }
    
    public int zerodayisaminecraftcheat(final boolean mouseOver) {
        return this.e.zeroday(mouseOver);
    }
    
    public int sigma(final boolean p_154312_1_) {
        return super.zerodayisaminecraftcheat(p_154312_1_);
    }
    
    public int vape() {
        return this.sigma;
    }
}

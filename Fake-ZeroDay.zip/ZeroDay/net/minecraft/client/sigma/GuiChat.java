// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import org.apache.commons.lang3.StringUtils;
import net.minecraft.o.MathHelper;
import net.minecraft.o.BlockPos;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C14PacketTabComplete;
import net.minecraft.o.MovingObjectPosition;
import java.util.Iterator;
import net.minecraft.o.ChatComponentText;
import net.minecraft.o.IChatComponent;
import org.lwjgl.input.Mouse;
import java.io.IOException;
import org.lwjgl.input.Keyboard;
import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import java.util.List;
import org.apache.logging.log4j.Logger;

public class GuiChat extends GuiScreen
{
    private static final Logger sigma;
    private String pandora;
    public static boolean zerodayisaminecraftcheat;
    private int zues;
    private boolean flux;
    private boolean vape;
    private int momgetthecamera;
    private List<String> a;
    protected GuiTextField zeroday;
    private String b;
    
    static {
        sigma = LogManager.getLogger();
        GuiChat.zerodayisaminecraftcheat = false;
    }
    
    public GuiChat() {
        this.pandora = "";
        this.zues = -1;
        this.a = (List<String>)Lists.newArrayList();
        this.b = "";
    }
    
    public GuiChat(final String defaultText) {
        this.pandora = "";
        this.zues = -1;
        this.a = (List<String>)Lists.newArrayList();
        this.b = "";
        this.b = defaultText;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        Keyboard.enableRepeatEvents(true);
        GuiChat.zerodayisaminecraftcheat = true;
        this.zues = this.u.o.pandora().sigma().size();
        (this.zeroday = new GuiTextField(0, this.C, 4, this.x - 12, this.w - 4, 12)).flux(100);
        this.zeroday.zerodayisaminecraftcheat(false);
        this.zeroday.zeroday(true);
        this.zeroday.zerodayisaminecraftcheat(this.b);
        this.zeroday.pandora(false);
    }
    
    @Override
    public void u_() {
        Keyboard.enableRepeatEvents(false);
        GuiChat.zerodayisaminecraftcheat = false;
        this.u.o.pandora().pandora();
    }
    
    @Override
    public void sigma() {
        this.zeroday.zerodayisaminecraftcheat();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        this.vape = false;
        if (keyCode == 15) {
            this.flux();
        }
        else {
            this.flux = false;
        }
        if (keyCode == 1) {
            this.u.zerodayisaminecraftcheat((GuiScreen)null);
        }
        else if (keyCode != 28 && keyCode != 156) {
            if (keyCode == 200) {
                this.zerodayisaminecraftcheat(-1);
                this.zeroday.flux();
            }
            else if (keyCode == 208) {
                this.zerodayisaminecraftcheat(1);
                this.zeroday.flux();
            }
            else if (keyCode == 201) {
                this.u.o.pandora().zeroday(this.u.o.pandora().a() - 1);
            }
            else if (keyCode == 209) {
                this.u.o.pandora().zeroday(-this.u.o.pandora().a() + 1);
            }
            else {
                this.zeroday.zerodayisaminecraftcheat(typedChar, keyCode);
            }
        }
        else {
            final String s = this.zeroday.zeroday().trim();
            if (s.length() > 0) {
                this.zues(s);
            }
            this.u.zerodayisaminecraftcheat((GuiScreen)null);
        }
    }
    
    @Override
    public void b_() throws IOException {
        super.b_();
        int i = Mouse.getEventDWheel();
        if (i != 0) {
            if (i > 1) {
                i = 1;
            }
            if (i < -1) {
                i = -1;
            }
            if (!GuiScreen.m()) {
                i *= 7;
            }
            this.u.o.pandora().zeroday(i);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        if (mouseButton == 0) {
            final IChatComponent ichatcomponent = this.u.o.pandora().zerodayisaminecraftcheat(Mouse.getX(), Mouse.getY());
            if (this.zerodayisaminecraftcheat(ichatcomponent)) {
                this.zeroday.flux();
                return;
            }
        }
        this.zeroday.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final String newChatText, final boolean shouldOverwrite) {
        if (shouldOverwrite) {
            this.zeroday.zerodayisaminecraftcheat(newChatText);
        }
        else {
            this.zeroday.zeroday(newChatText);
        }
    }
    
    public void flux() {
        if (this.flux) {
            this.zeroday.zeroday(this.zeroday.zerodayisaminecraftcheat(-1, this.zeroday.a(), false) - this.zeroday.a());
            if (this.momgetthecamera >= this.a.size()) {
                this.momgetthecamera = 0;
            }
        }
        else {
            final int i = this.zeroday.zerodayisaminecraftcheat(-1, this.zeroday.a(), false);
            this.a.clear();
            this.momgetthecamera = 0;
            final String s = this.zeroday.zeroday().substring(i).toLowerCase();
            final String s2 = this.zeroday.zeroday().substring(0, this.zeroday.a());
            this.zerodayisaminecraftcheat(s2, s);
            if (this.a.isEmpty()) {
                return;
            }
            this.flux = true;
            this.zeroday.zeroday(i - this.zeroday.a());
        }
        if (this.a.size() > 1) {
            final StringBuilder stringbuilder = new StringBuilder();
            for (final String s3 : this.a) {
                if (stringbuilder.length() > 0) {
                    stringbuilder.append(", ");
                }
                stringbuilder.append(s3);
            }
            this.u.o.pandora().zerodayisaminecraftcheat(new ChatComponentText(stringbuilder.toString()), 1);
        }
        this.zeroday.zeroday(this.a.get(this.momgetthecamera++));
    }
    
    private void zerodayisaminecraftcheat(final String p_146405_1_, final String p_146405_2_) {
        if (p_146405_1_.length() >= 1) {
            BlockPos blockpos = null;
            if (this.u.q != null && this.u.q.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
                blockpos = this.u.q.zerodayisaminecraftcheat();
            }
            this.u.e.zerodayisaminecraftcheat.zerodayisaminecraftcheat(new C14PacketTabComplete(p_146405_1_, blockpos));
            this.vape = true;
        }
    }
    
    public void zerodayisaminecraftcheat(final int msgPos) {
        int i = this.zues + msgPos;
        final int j = this.u.o.pandora().sigma().size();
        i = MathHelper.zerodayisaminecraftcheat(i, 0, j);
        if (i != this.zues) {
            if (i == j) {
                this.zues = j;
                this.zeroday.zerodayisaminecraftcheat(this.pandora);
            }
            else {
                if (this.zues == j) {
                    this.pandora = this.zeroday.zeroday();
                }
                this.zeroday.zerodayisaminecraftcheat(this.u.o.pandora().sigma().get(i));
                this.zues = i;
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        Gui.zerodayisaminecraftcheat(2, this.x - 14, this.w - 2 - 14, this.x - 2, Integer.MIN_VALUE);
        this.zeroday.vape();
        final IChatComponent ichatcomponent = this.u.o.pandora().zerodayisaminecraftcheat(Mouse.getX(), Mouse.getY());
        if (ichatcomponent != null && ichatcomponent.vape().a() != null) {
            this.zerodayisaminecraftcheat(ichatcomponent, mouseX, mouseY);
        }
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    public void zerodayisaminecraftcheat(final String[] p_146406_1_) {
        if (this.vape) {
            this.flux = false;
            this.a.clear();
            for (final String s : p_146406_1_) {
                if (s.length() > 0) {
                    this.a.add(s);
                }
            }
            final String s2 = this.zeroday.zeroday().substring(this.zeroday.zerodayisaminecraftcheat(-1, this.zeroday.a(), false));
            final String s3 = StringUtils.getCommonPrefix(p_146406_1_);
            if (s3.length() > 0 && !s2.equalsIgnoreCase(s3)) {
                this.zeroday.zeroday(this.zeroday.zerodayisaminecraftcheat(-1, this.zeroday.a(), false) - this.zeroday.a());
                this.zeroday.zeroday(s3);
            }
            else if (this.a.size() > 0) {
                this.flux = true;
                this.flux();
            }
        }
    }
    
    @Override
    public boolean zues() {
        return false;
    }
}

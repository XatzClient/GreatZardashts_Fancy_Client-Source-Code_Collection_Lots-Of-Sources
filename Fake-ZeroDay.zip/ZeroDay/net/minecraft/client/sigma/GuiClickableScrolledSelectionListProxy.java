// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.i.Tezzelator;
import org.lwjgl.input.Mouse;
import net.minecraft.client.Minecraft;
import net.minecraft.i.RealmsClickableScrolledSelectionList;

public class GuiClickableScrolledSelectionListProxy extends GuiSlot
{
    private final RealmsClickableScrolledSelectionList zerodayisaminecraftcheat;
    
    public GuiClickableScrolledSelectionListProxy(final RealmsClickableScrolledSelectionList selectionList, final int p_i45526_2_, final int p_i45526_3_, final int p_i45526_4_, final int p_i45526_5_, final int p_i45526_6_) {
        super(Minecraft.s(), p_i45526_2_, p_i45526_3_, p_i45526_4_, p_i45526_5_, p_i45526_6_);
        this.zerodayisaminecraftcheat = selectionList;
    }
    
    @Override
    protected int zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat.pandora();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int slotIndex, final boolean isDoubleClick, final int mouseX, final int mouseY) {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(slotIndex, isDoubleClick, mouseX, mouseY);
    }
    
    @Override
    protected boolean zerodayisaminecraftcheat(final int slotIndex) {
        return this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(slotIndex);
    }
    
    @Override
    protected void sigma() {
        this.zerodayisaminecraftcheat.zues();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int entryID, final int p_180791_2_, final int p_180791_3_, final int p_180791_4_, final int mouseXIn, final int mouseYIn) {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(entryID, p_180791_2_, p_180791_3_, p_180791_4_, mouseXIn, mouseYIn);
    }
    
    public int pandora() {
        return super.pandora;
    }
    
    public int zues() {
        return super.d;
    }
    
    public int flux() {
        return super.c;
    }
    
    @Override
    protected int zeroday() {
        return this.zerodayisaminecraftcheat.flux();
    }
    
    @Override
    protected int vape() {
        return this.zerodayisaminecraftcheat.vape();
    }
    
    @Override
    public void momgetthecamera() {
        super.momgetthecamera();
        if (this.g > 0.0f && Mouse.getEventButtonState()) {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.flux, this.vape, this.n, this.h, this.b);
        }
    }
    
    public void zerodayisaminecraftcheat(final int p_178043_1_, final int p_178043_2_, final int p_178043_3_, final Tezzelator p_178043_4_) {
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_178043_1_, p_178043_2_, p_178043_3_, p_178043_4_);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int p_148120_1_, final int p_148120_2_, final int mouseXIn, final int mouseYIn) {
        for (int i = this.zerodayisaminecraftcheat(), j = 0; j < i; ++j) {
            final int k = p_148120_2_ + j * this.b + this.n;
            final int l = this.b - 4;
            if (k > this.vape || k + l < this.flux) {
                this.zerodayisaminecraftcheat(j, p_148120_1_, k);
            }
            if (this.l && this.zerodayisaminecraftcheat(j)) {
                this.zerodayisaminecraftcheat(this.pandora, k, l, Tezzelator.zeroday);
            }
            this.zerodayisaminecraftcheat(j, p_148120_1_, k, l, mouseXIn, mouseYIn);
        }
    }
}

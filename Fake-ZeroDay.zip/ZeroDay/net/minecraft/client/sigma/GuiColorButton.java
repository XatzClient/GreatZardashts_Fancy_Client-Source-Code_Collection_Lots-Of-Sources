// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.zerodayisaminecraftcheat.ISound;
import net.minecraft.client.zerodayisaminecraftcheat.PositionedSoundRecord;
import net.minecraft.client.zerodayisaminecraftcheat.SoundHandler;
import zeroday.pandora.zerodayisaminecraftcheat.h.h;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.o.ResourceLocation;

public class GuiColorButton extends Gui
{
    protected static final ResourceLocation zerodayisaminecraftcheat;
    protected int zeroday;
    protected int sigma;
    public int pandora;
    public int zues;
    public String flux;
    public int vape;
    private int e;
    private int f;
    private int g;
    private int h;
    public boolean momgetthecamera;
    public boolean a;
    public boolean b;
    public boolean c;
    protected boolean d;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/gui/widgets.png");
    }
    
    public GuiColorButton(final int buttonId, final int x, final int y, final int color) {
        this(buttonId, x, y, 200, 20, color);
    }
    
    public GuiColorButton(final int buttonId, final int x, final int y, final int widthIn, final int heightIn, final int color) {
        this.zeroday = 200;
        this.sigma = 20;
        this.momgetthecamera = true;
        this.a = true;
        this.vape = buttonId;
        this.pandora = x;
        this.zues = y;
        this.zeroday = widthIn;
        this.sigma = heightIn;
        this.h = color;
    }
    
    protected int zerodayisaminecraftcheat(final boolean mouseOver) {
        int i = 1;
        if (this.e < 4) {
            ++this.e;
        }
        if (this.f < 4) {
            ++this.f;
        }
        if (this.b && this.g < 10) {
            ++this.g;
        }
        else if (this.g == 10) {
            this.b = false;
            this.c = true;
        }
        if (this.c && this.g > 0) {
            --this.g;
        }
        else if (this.g == 0) {
            this.c = false;
            this.b = true;
        }
        if (!this.momgetthecamera) {
            i = 0;
        }
        else if (mouseOver) {
            i = 2;
        }
        return i;
    }
    
    public void zerodayisaminecraftcheat(final Minecraft mc, final int mouseX, final int mouseY) {
        if (this.a) {
            final FontRenderer fontrenderer = mc.i;
            mc.I().zerodayisaminecraftcheat(GuiColorButton.zerodayisaminecraftcheat);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.d = (mouseX >= this.pandora && mouseY >= this.zues && mouseX < this.pandora + this.zeroday && mouseY < this.zues + this.sigma);
            final int i = this.zerodayisaminecraftcheat(this.d);
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            GlStateManager.zeroday(770, 771);
            if (!this.momgetthecamera) {
                Gui.zerodayisaminecraftcheat(this.pandora, this.zues, this.pandora + this.zeroday, this.zues + this.sigma, 1073741824);
            }
            else if (!this.d) {
                this.g = 0;
                this.e = 0;
                Gui.zerodayisaminecraftcheat(this.pandora - 2, this.zues - 2, this.pandora + this.zeroday + 2, this.zues + this.sigma + 2, -1610612736);
                Gui.zerodayisaminecraftcheat(this.pandora + 1, this.zues + 1, this.pandora + this.zeroday - 1, this.zues + this.sigma - 1, (this.h == -15584170) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(50000000L, 1.0f).getRGB() : ((this.h == -10140895) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : this.h));
            }
            else {
                this.f = 0;
                Gui.zerodayisaminecraftcheat(this.pandora - 2, this.zues - 2, this.pandora + this.zeroday + 2, this.zues + this.sigma + 2, 1879048192);
                Gui.zerodayisaminecraftcheat(this.pandora, this.zues, this.pandora + this.zeroday, this.zues + this.sigma, (this.h == -15584170) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(50000000L, 1.0f).getRGB() : ((this.h == -10140895) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : this.h));
            }
            this.zeroday(mc, mouseX, mouseY);
            int j = (zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat == -869335296) ? -6684928 : ((zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat == 0) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(50000000L, 1.0f).getRGB() : ((zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat == 65536) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat));
            if (!this.momgetthecamera) {
                j = 10526880;
            }
            else if (!this.d) {
                j = 14737632;
            }
        }
    }
    
    protected void zeroday(final Minecraft mc, final int mouseX, final int mouseY) {
    }
    
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY) {
    }
    
    public boolean sigma(final Minecraft mc, final int mouseX, final int mouseY) {
        return this.momgetthecamera && this.a && mouseX >= this.pandora && mouseY >= this.zues && mouseX < this.pandora + this.zeroday && mouseY < this.zues + this.sigma;
    }
    
    public boolean zerodayisaminecraftcheat() {
        return this.d;
    }
    
    public void zeroday(final int mouseX, final int mouseY) {
    }
    
    public void zerodayisaminecraftcheat(final SoundHandler soundHandlerIn) {
        soundHandlerIn.zerodayisaminecraftcheat(PositionedSoundRecord.zerodayisaminecraftcheat(new ResourceLocation("gui.button.press"), 1.0f));
    }
    
    public int zeroday() {
        return this.zeroday;
    }
    
    public void zerodayisaminecraftcheat(final int width) {
        this.zeroday = width;
    }
}

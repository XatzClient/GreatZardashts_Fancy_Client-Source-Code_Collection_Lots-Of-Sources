// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.o.IChatComponent;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C17PacketCustomPayload;
import io.netty.buffer.ByteBuf;
import net.minecraft.e.PacketBuffer;
import io.netty.buffer.Unpooled;
import net.minecraft.client.a.EntityRenderer;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.client.a.OpenGlHelper;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.c;
import net.minecraft.client.b.I18n;
import org.lwjgl.input.Keyboard;
import org.apache.logging.log4j.LogManager;
import net.minecraft.zeroday.zerodayisaminecraftcheat.CommandBlockLogic;
import org.apache.logging.log4j.Logger;

public class GuiCommandBlock extends GuiScreen
{
    private static final Logger zerodayisaminecraftcheat;
    private GuiTextField zeroday;
    private GuiTextField sigma;
    private final CommandBlockLogic pandora;
    private GuiButton zues;
    private GuiButton flux;
    private GuiButton vape;
    private boolean momgetthecamera;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public GuiCommandBlock(final CommandBlockLogic p_i45032_1_) {
        this.pandora = p_i45032_1_;
    }
    
    @Override
    public void sigma() {
        this.zeroday.zerodayisaminecraftcheat();
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        Keyboard.enableRepeatEvents(true);
        this.y.clear();
        this.y.add(this.zues = new GuiButton(0, this.w / 2 - 4 - 150, this.x / 4 + 120 + 12, 150, 20, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
        this.y.add(this.flux = new GuiButton(1, this.w / 2 + 4, this.x / 4 + 120 + 12, 150, 20, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        this.y.add(this.vape = new GuiButton(4, this.w / 2 + 150 - 20, 150, 20, 20, "O"));
        (this.zeroday = new GuiTextField(2, this.C, this.w / 2 - 150, 50, 300, 20)).flux(32767);
        this.zeroday.zeroday(true);
        this.zeroday.zerodayisaminecraftcheat(this.pandora.a());
        (this.sigma = new GuiTextField(3, this.C, this.w / 2 - 150, 150, 276, 20)).flux(32767);
        this.sigma.sigma(false);
        this.sigma.zerodayisaminecraftcheat("-");
        this.momgetthecamera = this.pandora.d();
        this.flux();
        this.zues.momgetthecamera = (this.zeroday.zeroday().trim().length() > 0);
        if (c.zerodayisaminecraftcheat && OpenGlHelper.G && this.u.V() instanceof EntityPlayer) {
            if (this.u.m.vape != null) {
                this.u.m.vape.zerodayisaminecraftcheat();
            }
            this.u.m.b = 5;
            if (this.u.m.b != EntityRenderer.a) {
                this.u.m.zerodayisaminecraftcheat(EntityRenderer.momgetthecamera[18]);
            }
        }
    }
    
    @Override
    public void u_() {
        this.u.m.vape = null;
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            if (button.vape == 1) {
                this.pandora.zerodayisaminecraftcheat(this.momgetthecamera);
                this.u.zerodayisaminecraftcheat((GuiScreen)null);
            }
            else if (button.vape == 0) {
                final PacketBuffer packetbuffer = new PacketBuffer(Unpooled.buffer());
                packetbuffer.writeByte(this.pandora.c());
                this.pandora.zerodayisaminecraftcheat(packetbuffer);
                packetbuffer.zerodayisaminecraftcheat(this.zeroday.zeroday());
                packetbuffer.writeBoolean(this.pandora.d());
                this.u.o().zerodayisaminecraftcheat(new C17PacketCustomPayload("MC|AdvCdm", packetbuffer));
                if (!this.pandora.d()) {
                    this.pandora.zeroday((IChatComponent)null);
                }
                this.u.zerodayisaminecraftcheat((GuiScreen)null);
            }
            else if (button.vape == 4) {
                this.pandora.zerodayisaminecraftcheat(!this.pandora.d());
                this.flux();
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        this.zeroday.zerodayisaminecraftcheat(typedChar, keyCode);
        this.sigma.zerodayisaminecraftcheat(typedChar, keyCode);
        this.zues.momgetthecamera = (this.zeroday.zeroday().trim().length() > 0);
        if (keyCode != 28 && keyCode != 156) {
            if (keyCode == 1) {
                this.zerodayisaminecraftcheat(this.flux);
            }
        }
        else {
            this.zerodayisaminecraftcheat(this.zues);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        this.zeroday.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        this.sigma.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("advMode.setCommand", new Object[0]), this.w / 2, 20, 16777215);
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("advMode.command", new Object[0]), this.w / 2 - 150, 37, 10526880);
        this.zeroday.vape();
        int i = 75;
        int j = 0;
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("advMode.nearestPlayer", new Object[0]), this.w / 2 - 150, i + j++ * this.C.zeroday, 10526880);
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("advMode.randomPlayer", new Object[0]), this.w / 2 - 150, i + j++ * this.C.zeroday, 10526880);
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("advMode.allPlayers", new Object[0]), this.w / 2 - 150, i + j++ * this.C.zeroday, 10526880);
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("advMode.allEntities", new Object[0]), this.w / 2 - 150, i + j++ * this.C.zeroday, 10526880);
        Gui.zeroday(this.C, "", this.w / 2 - 150, i + j++ * this.C.zeroday, 10526880);
        if (this.sigma.zeroday().length() > 0) {
            i = i + j * this.C.zeroday + 16;
            Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("advMode.previousOutput", new Object[0]), this.w / 2 - 150, i, 10526880);
            this.sigma.vape();
        }
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    private void flux() {
        if (this.pandora.d()) {
            this.vape.flux = "O";
            if (this.pandora.momgetthecamera() != null) {
                this.sigma.zerodayisaminecraftcheat(this.pandora.momgetthecamera().momgetthecamera());
            }
        }
        else {
            this.vape.flux = "X";
            this.sigma.zerodayisaminecraftcheat("-");
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.client.b.I18n;

public class GuiConfirmOpenLink extends GuiYesNo
{
    private final String flux;
    private final String vape;
    private final String momgetthecamera;
    private boolean a;
    
    public GuiConfirmOpenLink(final GuiYesNoCallback p_i1084_1_, final String linkTextIn, final int p_i1084_3_, final boolean p_i1084_4_) {
        super(p_i1084_1_, I18n.zerodayisaminecraftcheat(p_i1084_4_ ? "chat.link.confirmTrusted" : "chat.link.confirm", new Object[0]), linkTextIn, p_i1084_3_);
        this.a = true;
        this.sigma = I18n.zerodayisaminecraftcheat(p_i1084_4_ ? "chat.link.open" : "gui.yes", new Object[0]);
        this.pandora = I18n.zerodayisaminecraftcheat(p_i1084_4_ ? "gui.cancel" : "gui.no", new Object[0]);
        this.vape = I18n.zerodayisaminecraftcheat("chat.copy", new Object[0]);
        this.flux = I18n.zerodayisaminecraftcheat("chat.link.warning", new Object[0]);
        this.momgetthecamera = linkTextIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        super.zerodayisaminecraftcheat();
        this.y.clear();
        this.y.add(new GuiButton(0, this.w / 2 - 50 - 105, this.x / 6 + 96, 100, 20, this.sigma));
        this.y.add(new GuiButton(2, this.w / 2 - 50, this.x / 6 + 96, 100, 20, this.vape));
        this.y.add(new GuiButton(1, this.w / 2 - 50 + 105, this.x / 6 + 96, 100, 20, this.pandora));
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.vape == 2) {
            this.flux();
        }
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(button.vape == 0, this.zues);
    }
    
    public void flux() {
        GuiScreen.pandora(this.momgetthecamera);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        if (this.a) {
            Gui.zerodayisaminecraftcheat(this.C, this.flux, this.w / 2, 110, 16764108);
        }
    }
    
    public void vape() {
        this.a = false;
    }
}

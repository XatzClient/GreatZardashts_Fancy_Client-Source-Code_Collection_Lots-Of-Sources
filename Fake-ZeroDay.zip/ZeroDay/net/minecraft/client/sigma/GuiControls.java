// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.Minecraft;
import java.io.IOException;
import net.minecraft.client.b.I18n;
import net.minecraft.client.c.KeyBinding;
import net.minecraft.client.c.GameSettings;

public class GuiControls extends GuiScreen
{
    private static final GameSettings.zeroday[] pandora;
    private GuiScreen zues;
    protected String zerodayisaminecraftcheat;
    private GameSettings flux;
    public KeyBinding zeroday;
    public long sigma;
    private GuiKeyBindingList vape;
    private GuiButton momgetthecamera;
    
    static {
        pandora = new GameSettings.zeroday[] { GameSettings.zeroday.zerodayisaminecraftcheat, GameSettings.zeroday.zeroday, GameSettings.zeroday.q };
    }
    
    public GuiControls(final GuiScreen screen, final GameSettings settings) {
        this.zerodayisaminecraftcheat = "Controls";
        this.zeroday = null;
        this.zues = screen;
        this.flux = settings;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.vape = new GuiKeyBindingList(this, this.u);
        this.y.add(new GuiButton(200, this.w / 2 - 155, this.x - 29, 150, 20, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
        this.y.add(this.momgetthecamera = new GuiButton(201, this.w / 2 - 155 + 160, this.x - 29, 150, 20, I18n.zerodayisaminecraftcheat("controls.resetAll", new Object[0])));
        this.y.add(new GuiButton(202, this.w / 2 - 155 + 160, 42, 150, 20, "SettingsProfiles"));
        this.zerodayisaminecraftcheat = I18n.zerodayisaminecraftcheat("controls.title", new Object[0]);
        int i = 0;
        GameSettings.zeroday[] pandora;
        for (int length = (pandora = GuiControls.pandora).length, j = 0; j < length; ++j) {
            final GameSettings.zeroday gamesettings$options = pandora[j];
            if (gamesettings$options.zerodayisaminecraftcheat()) {
                this.y.add(new GuiOptionSlider(gamesettings$options.sigma(), this.w / 2 - 155 + i % 2 * 160, 18 + 24 * (i >> 1), gamesettings$options));
            }
            else {
                this.y.add(new GuiOptionButton(gamesettings$options.sigma(), this.w / 2 - 155 + i % 2 * 160, 18 + 24 * (i >> 1), gamesettings$options, this.flux.sigma(gamesettings$options)));
            }
            ++i;
        }
    }
    
    @Override
    public void b_() throws IOException {
        super.b_();
        this.vape.momgetthecamera();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.vape == 200) {
            this.u.zerodayisaminecraftcheat(this.zues);
        }
        else if (button.vape == 201) {
            KeyBinding[] ao;
            for (int length = (ao = this.u.r.ao).length, i = 0; i < length; ++i) {
                final KeyBinding keybinding = ao[i];
                keybinding.zeroday(keybinding.momgetthecamera());
            }
            KeyBinding.zeroday();
        }
        else if (button.vape < 100 && button instanceof GuiOptionButton) {
            this.flux.zerodayisaminecraftcheat(((GuiOptionButton)button).sigma(), 1);
            button.flux = this.flux.sigma(GameSettings.zeroday.zerodayisaminecraftcheat(button.vape));
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        if (this.zeroday != null) {
            this.flux.zerodayisaminecraftcheat(this.zeroday, -100 + mouseButton);
            this.zeroday = null;
            KeyBinding.zeroday();
        }
        else if (mouseButton != 0 || !this.vape.zeroday(mouseX, mouseY, mouseButton)) {
            super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        }
    }
    
    @Override
    protected void zeroday(final int mouseX, final int mouseY, final int state) {
        if (state != 0 || !this.vape.sigma(mouseX, mouseY, state)) {
            super.zeroday(mouseX, mouseY, state);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        if (this.zeroday != null) {
            if (keyCode == 1) {
                this.flux.zerodayisaminecraftcheat(this.zeroday, 0);
            }
            else if (keyCode != 0) {
                this.flux.zerodayisaminecraftcheat(this.zeroday, keyCode);
            }
            else if (typedChar > '\0') {
                this.flux.zerodayisaminecraftcheat(this.zeroday, typedChar + '\u0100');
            }
            this.zeroday = null;
            this.sigma = Minecraft.C();
            KeyBinding.zeroday();
        }
        else {
            super.zerodayisaminecraftcheat(typedChar, keyCode);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        this.vape.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        Gui.zerodayisaminecraftcheat(this.C, this.zerodayisaminecraftcheat, this.w / 2, 8, 16777215);
        boolean flag = true;
        KeyBinding[] ao;
        for (int length = (ao = this.flux.ao).length, i = 0; i < length; ++i) {
            final KeyBinding keybinding = ao[i];
            if (keybinding.a() != keybinding.momgetthecamera()) {
                flag = false;
                break;
            }
        }
        this.momgetthecamera.momgetthecamera = !flag;
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
}

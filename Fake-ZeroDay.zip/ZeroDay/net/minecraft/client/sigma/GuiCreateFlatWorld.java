// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.a.Items;
import net.minecraft.a.Blocks;
import net.minecraft.c.Item;
import net.minecraft.q.zues.FlatLayerInfo;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.c.ItemStack;
import java.io.IOException;
import net.minecraft.client.b.I18n;
import net.minecraft.q.zues.FlatGeneratorInfo;

public class GuiCreateFlatWorld extends GuiScreen
{
    private final GuiCreateWorld zerodayisaminecraftcheat;
    private FlatGeneratorInfo zeroday;
    private String sigma;
    private String pandora;
    private String zues;
    private zerodayisaminecraftcheat flux;
    private GuiButton vape;
    private GuiButton momgetthecamera;
    private GuiButton a;
    
    public GuiCreateFlatWorld(final GuiCreateWorld createWorldGuiIn, final String p_i1029_2_) {
        this.zeroday = FlatGeneratorInfo.zues();
        this.zerodayisaminecraftcheat = createWorldGuiIn;
        this.zerodayisaminecraftcheat(p_i1029_2_);
    }
    
    public String flux() {
        return this.zeroday.toString();
    }
    
    public void zerodayisaminecraftcheat(final String p_146383_1_) {
        this.zeroday = FlatGeneratorInfo.zerodayisaminecraftcheat(p_146383_1_);
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.clear();
        this.sigma = I18n.zerodayisaminecraftcheat("createWorld.customize.flat.title", new Object[0]);
        this.pandora = I18n.zerodayisaminecraftcheat("createWorld.customize.flat.tile", new Object[0]);
        this.zues = I18n.zerodayisaminecraftcheat("createWorld.customize.flat.height", new Object[0]);
        this.flux = new zerodayisaminecraftcheat();
        this.y.add(this.vape = new GuiButton(2, this.w / 2 - 154, this.x - 52, 100, 20, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.flat.addLayer", new Object[0])) + " (NYI)"));
        this.y.add(this.momgetthecamera = new GuiButton(3, this.w / 2 - 50, this.x - 52, 100, 20, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.flat.editLayer", new Object[0])) + " (NYI)"));
        this.y.add(this.a = new GuiButton(4, this.w / 2 - 155, this.x - 52, 150, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.flat.removeLayer", new Object[0])));
        this.y.add(new GuiButton(0, this.w / 2 - 155, this.x - 28, 150, 20, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
        this.y.add(new GuiButton(5, this.w / 2 + 5, this.x - 52, 150, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.presets", new Object[0])));
        this.y.add(new GuiButton(1, this.w / 2 + 5, this.x - 28, 150, 20, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        final GuiButton vape = this.vape;
        final GuiButton momgetthecamera = this.momgetthecamera;
        final boolean b = false;
        momgetthecamera.a = b;
        vape.a = b;
        this.zeroday.pandora();
        this.vape();
    }
    
    @Override
    public void b_() throws IOException {
        super.b_();
        this.flux.momgetthecamera();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        final int i = this.zeroday.sigma().size() - this.flux.zerodayisaminecraftcheat - 1;
        if (button.vape == 1) {
            this.u.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
        }
        else if (button.vape == 0) {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat = this.flux();
            this.u.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
        }
        else if (button.vape == 5) {
            this.u.zerodayisaminecraftcheat(new GuiFlatPresets(this));
        }
        else if (button.vape == 4 && this.momgetthecamera()) {
            this.zeroday.sigma().remove(i);
            this.flux.zerodayisaminecraftcheat = Math.min(this.flux.zerodayisaminecraftcheat, this.zeroday.sigma().size() - 1);
        }
        this.zeroday.pandora();
        this.vape();
    }
    
    public void vape() {
        final boolean flag = this.momgetthecamera();
        this.a.momgetthecamera = flag;
        this.momgetthecamera.momgetthecamera = flag;
        this.momgetthecamera.momgetthecamera = false;
        this.vape.momgetthecamera = false;
    }
    
    private boolean momgetthecamera() {
        return this.flux.zerodayisaminecraftcheat > -1 && this.flux.zerodayisaminecraftcheat < this.zeroday.sigma().size();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        this.flux.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        Gui.zerodayisaminecraftcheat(this.C, this.sigma, this.w / 2, 8, 16777215);
        final int i = this.w / 2 - 92 - 16;
        Gui.zeroday(this.C, this.pandora, i, 32, 16777215);
        Gui.zeroday(this.C, this.zues, i + 2 + 213 - this.C.zerodayisaminecraftcheat(this.zues), 32, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    class zerodayisaminecraftcheat extends GuiSlot
    {
        public int zerodayisaminecraftcheat;
        
        public zerodayisaminecraftcheat() {
            super(GuiCreateFlatWorld.this.u, GuiCreateFlatWorld.this.w, GuiCreateFlatWorld.this.x, 43, GuiCreateFlatWorld.this.x - 60, 24);
            this.zerodayisaminecraftcheat = -1;
        }
        
        private void zerodayisaminecraftcheat(final int p_148225_1_, final int p_148225_2_, final ItemStack p_148225_3_) {
            this.zues(p_148225_1_ + 1, p_148225_2_ + 1);
            GlStateManager.s();
            if (p_148225_3_ != null && p_148225_3_.zerodayisaminecraftcheat() != null) {
                RenderHelper.sigma();
                GuiCreateFlatWorld.this.v.zerodayisaminecraftcheat(p_148225_3_, p_148225_1_ + 2, p_148225_2_ + 2);
                RenderHelper.zerodayisaminecraftcheat();
            }
            GlStateManager.t();
        }
        
        private void zues(final int p_148226_1_, final int p_148226_2_) {
            this.pandora(p_148226_1_, p_148226_2_, 0, 0);
        }
        
        private void pandora(final int p_148224_1_, final int p_148224_2_, final int p_148224_3_, final int p_148224_4_) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.sigma.I().zerodayisaminecraftcheat(Gui.n);
            final float f = 0.0078125f;
            final float f2 = 0.0078125f;
            final int i = 18;
            final int j = 18;
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
            worldrenderer.zeroday(p_148224_1_ + 0, p_148224_2_ + 18, (double)GuiCreateFlatWorld.this.p).zerodayisaminecraftcheat((p_148224_3_ + 0) * 0.0078125f, (p_148224_4_ + 18) * 0.0078125f).zues();
            worldrenderer.zeroday(p_148224_1_ + 18, p_148224_2_ + 18, (double)GuiCreateFlatWorld.this.p).zerodayisaminecraftcheat((p_148224_3_ + 18) * 0.0078125f, (p_148224_4_ + 18) * 0.0078125f).zues();
            worldrenderer.zeroday(p_148224_1_ + 18, p_148224_2_ + 0, (double)GuiCreateFlatWorld.this.p).zerodayisaminecraftcheat((p_148224_3_ + 18) * 0.0078125f, (p_148224_4_ + 0) * 0.0078125f).zues();
            worldrenderer.zeroday(p_148224_1_ + 0, p_148224_2_ + 0, (double)GuiCreateFlatWorld.this.p).zerodayisaminecraftcheat((p_148224_3_ + 0) * 0.0078125f, (p_148224_4_ + 0) * 0.0078125f).zues();
            tessellator.zeroday();
        }
        
        @Override
        protected int zerodayisaminecraftcheat() {
            return GuiCreateFlatWorld.this.zeroday.sigma().size();
        }
        
        @Override
        protected void zerodayisaminecraftcheat(final int slotIndex, final boolean isDoubleClick, final int mouseX, final int mouseY) {
            this.zerodayisaminecraftcheat = slotIndex;
            GuiCreateFlatWorld.this.vape();
        }
        
        @Override
        protected boolean zerodayisaminecraftcheat(final int slotIndex) {
            return slotIndex == this.zerodayisaminecraftcheat;
        }
        
        @Override
        protected void sigma() {
        }
        
        @Override
        protected void zerodayisaminecraftcheat(final int entryID, final int p_180791_2_, final int p_180791_3_, final int p_180791_4_, final int mouseXIn, final int mouseYIn) {
            final FlatLayerInfo flatlayerinfo = GuiCreateFlatWorld.this.zeroday.sigma().get(GuiCreateFlatWorld.this.zeroday.sigma().size() - entryID - 1);
            final IBlockState iblockstate = flatlayerinfo.zeroday();
            final Block block = iblockstate.sigma();
            Item item = Item.zerodayisaminecraftcheat(block);
            ItemStack itemstack = (block != Blocks.zerodayisaminecraftcheat && item != null) ? new ItemStack(item, 1, block.sigma(iblockstate)) : null;
            String s = (itemstack == null) ? "Air" : item.vape(itemstack);
            if (item == null) {
                if (block != Blocks.b && block != Blocks.a) {
                    if (block == Blocks.d || block == Blocks.c) {
                        item = Items.aq;
                    }
                }
                else {
                    item = Items.ap;
                }
                if (item != null) {
                    itemstack = new ItemStack(item, 1, block.sigma(iblockstate));
                    s = block.u();
                }
            }
            this.zerodayisaminecraftcheat(p_180791_2_, p_180791_3_, itemstack);
            GuiCreateFlatWorld.this.C.zerodayisaminecraftcheat(s, p_180791_2_ + 18 + 5, p_180791_3_ + 3, 16777215);
            String s2;
            if (entryID == 0) {
                s2 = I18n.zerodayisaminecraftcheat("createWorld.customize.flat.layer.top", flatlayerinfo.zerodayisaminecraftcheat());
            }
            else if (entryID == GuiCreateFlatWorld.this.zeroday.sigma().size() - 1) {
                s2 = I18n.zerodayisaminecraftcheat("createWorld.customize.flat.layer.bottom", flatlayerinfo.zerodayisaminecraftcheat());
            }
            else {
                s2 = I18n.zerodayisaminecraftcheat("createWorld.customize.flat.layer", flatlayerinfo.zerodayisaminecraftcheat());
            }
            GuiCreateFlatWorld.this.C.zerodayisaminecraftcheat(s2, p_180791_2_ + 2 + 213 - GuiCreateFlatWorld.this.C.zerodayisaminecraftcheat(s2), p_180791_3_ + 3, 16777215);
        }
        
        @Override
        protected int vape() {
            return this.pandora - 70;
        }
    }
}

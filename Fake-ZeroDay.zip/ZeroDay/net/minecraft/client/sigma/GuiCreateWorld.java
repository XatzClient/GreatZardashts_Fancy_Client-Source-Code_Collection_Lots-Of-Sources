// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.q.vape.WorldInfo;
import java.io.IOException;
import net.minecraft.q.WorldSettings;
import java.util.Random;
import net.minecraft.q.vape.ISaveFormat;
import net.minecraft.q.WorldType;
import org.apache.commons.lang3.StringUtils;
import net.minecraft.o.ChatAllowedCharacters;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.b.I18n;

public class GuiCreateWorld extends GuiScreen
{
    private GuiScreen zeroday;
    private GuiTextField sigma;
    private GuiTextField pandora;
    private String zues;
    private String flux;
    private String vape;
    private boolean momgetthecamera;
    private boolean a;
    private boolean b;
    private boolean c;
    private boolean d;
    private boolean e;
    private boolean f;
    private GuiButton g;
    private GuiButton h;
    private GuiButton i;
    private GuiButton j;
    private GuiButton k;
    private GuiButton l;
    private GuiButton q;
    private String r;
    private String s;
    private String t;
    private String G;
    private int H;
    public String zerodayisaminecraftcheat;
    private static final String[] I;
    
    static {
        I = new String[] { "CON", "COM", "PRN", "AUX", "CLOCK$", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9" };
    }
    
    public GuiCreateWorld(final GuiScreen p_i46320_1_) {
        this.flux = "survival";
        this.momgetthecamera = true;
        this.zerodayisaminecraftcheat = "";
        this.zeroday = p_i46320_1_;
        this.t = "";
        this.G = I18n.zerodayisaminecraftcheat("selectWorld.newWorld", new Object[0]);
    }
    
    @Override
    public void sigma() {
        this.sigma.zerodayisaminecraftcheat();
        this.pandora.zerodayisaminecraftcheat();
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        Keyboard.enableRepeatEvents(true);
        this.y.clear();
        this.y.add(new GuiButton(0, this.w / 2 - 155, this.x - 28, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.create", new Object[0])));
        this.y.add(new GuiButton(1, this.w / 2 + 5, this.x - 28, 150, 20, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        this.y.add(this.g = new GuiButton(2, this.w / 2 - 75, 115, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.gameMode", new Object[0])));
        this.y.add(this.h = new GuiButton(3, this.w / 2 - 75, 187, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.moreWorldOptions", new Object[0])));
        this.y.add(this.i = new GuiButton(4, this.w / 2 - 155, 100, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.mapFeatures", new Object[0])));
        this.i.a = false;
        this.y.add(this.j = new GuiButton(7, this.w / 2 + 5, 151, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.bonusItems", new Object[0])));
        this.j.a = false;
        this.y.add(this.k = new GuiButton(5, this.w / 2 + 5, 100, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.mapType", new Object[0])));
        this.k.a = false;
        this.y.add(this.l = new GuiButton(6, this.w / 2 - 155, 151, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.allowCommands", new Object[0])));
        this.l.a = false;
        this.y.add(this.q = new GuiButton(8, this.w / 2 + 5, 120, 150, 20, I18n.zerodayisaminecraftcheat("selectWorld.customizeType", new Object[0])));
        this.q.a = false;
        (this.sigma = new GuiTextField(9, this.C, this.w / 2 - 100, 60, 200, 20)).zeroday(true);
        this.sigma.zerodayisaminecraftcheat(this.G);
        (this.pandora = new GuiTextField(10, this.C, this.w / 2 - 100, 60, 200, 20)).zerodayisaminecraftcheat(this.t);
        this.zerodayisaminecraftcheat(this.f);
        this.flux();
        this.vape();
    }
    
    private void flux() {
        this.zues = this.sigma.zeroday().trim();
        char[] zerodayisaminecraftcheat;
        for (int length = (zerodayisaminecraftcheat = ChatAllowedCharacters.zerodayisaminecraftcheat).length, i = 0; i < length; ++i) {
            final char c0 = zerodayisaminecraftcheat[i];
            this.zues = this.zues.replace(c0, '_');
        }
        if (StringUtils.isEmpty((CharSequence)this.zues)) {
            this.zues = "World";
        }
        this.zues = zerodayisaminecraftcheat(this.u.vape(), this.zues);
    }
    
    private void vape() {
        this.g.flux = String.valueOf(I18n.zerodayisaminecraftcheat("selectWorld.gameMode", new Object[0])) + ": " + I18n.zerodayisaminecraftcheat("selectWorld.gameMode." + this.flux, new Object[0]);
        this.r = I18n.zerodayisaminecraftcheat("selectWorld.gameMode." + this.flux + ".line1", new Object[0]);
        this.s = I18n.zerodayisaminecraftcheat("selectWorld.gameMode." + this.flux + ".line2", new Object[0]);
        this.i.flux = String.valueOf(I18n.zerodayisaminecraftcheat("selectWorld.mapFeatures", new Object[0])) + " ";
        if (this.momgetthecamera) {
            this.i.flux = String.valueOf(this.i.flux) + I18n.zerodayisaminecraftcheat("options.on", new Object[0]);
        }
        else {
            this.i.flux = String.valueOf(this.i.flux) + I18n.zerodayisaminecraftcheat("options.off", new Object[0]);
        }
        this.j.flux = String.valueOf(I18n.zerodayisaminecraftcheat("selectWorld.bonusItems", new Object[0])) + " ";
        if (this.c && !this.d) {
            this.j.flux = String.valueOf(this.j.flux) + I18n.zerodayisaminecraftcheat("options.on", new Object[0]);
        }
        else {
            this.j.flux = String.valueOf(this.j.flux) + I18n.zerodayisaminecraftcheat("options.off", new Object[0]);
        }
        this.k.flux = String.valueOf(I18n.zerodayisaminecraftcheat("selectWorld.mapType", new Object[0])) + " " + I18n.zerodayisaminecraftcheat(WorldType.zerodayisaminecraftcheat[this.H].zeroday(), new Object[0]);
        this.l.flux = String.valueOf(I18n.zerodayisaminecraftcheat("selectWorld.allowCommands", new Object[0])) + " ";
        if (this.a && !this.d) {
            this.l.flux = String.valueOf(this.l.flux) + I18n.zerodayisaminecraftcheat("options.on", new Object[0]);
        }
        else {
            this.l.flux = String.valueOf(this.l.flux) + I18n.zerodayisaminecraftcheat("options.off", new Object[0]);
        }
    }
    
    public static String zerodayisaminecraftcheat(final ISaveFormat p_146317_0_, String p_146317_1_) {
        p_146317_1_ = p_146317_1_.replaceAll("[\\./\"]", "_");
        String[] i;
        for (int length = (i = GuiCreateWorld.I).length, j = 0; j < length; ++j) {
            final String s = i[j];
            if (p_146317_1_.equalsIgnoreCase(s)) {
                p_146317_1_ = "_" + p_146317_1_ + "_";
            }
        }
        while (p_146317_0_.sigma(p_146317_1_) != null) {
            p_146317_1_ = String.valueOf(p_146317_1_) + "-";
        }
        return p_146317_1_;
    }
    
    @Override
    public void u_() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            if (button.vape == 1) {
                this.u.zerodayisaminecraftcheat(this.zeroday);
            }
            else if (button.vape == 0) {
                this.u.zerodayisaminecraftcheat((GuiScreen)null);
                if (this.e) {
                    return;
                }
                this.e = true;
                long i = new Random().nextLong();
                final String s = this.pandora.zeroday();
                if (!StringUtils.isEmpty((CharSequence)s)) {
                    try {
                        final long j = Long.parseLong(s);
                        if (j != 0L) {
                            i = j;
                        }
                    }
                    catch (NumberFormatException var7) {
                        i = s.hashCode();
                    }
                }
                final WorldSettings.zerodayisaminecraftcheat worldsettings$gametype = WorldSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.flux);
                final WorldSettings worldsettings = new WorldSettings(i, worldsettings$gametype, this.momgetthecamera, this.d, WorldType.zerodayisaminecraftcheat[this.H]);
                worldsettings.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
                if (this.c && !this.d) {
                    worldsettings.zerodayisaminecraftcheat();
                }
                if (this.a && !this.d) {
                    worldsettings.zeroday();
                }
                this.u.zerodayisaminecraftcheat(this.zues, this.sigma.zeroday().trim(), worldsettings);
            }
            else if (button.vape == 3) {
                this.a();
            }
            else if (button.vape == 2) {
                if (this.flux.equals("survival")) {
                    if (!this.b) {
                        this.a = false;
                    }
                    this.d = false;
                    this.flux = "hardcore";
                    this.d = true;
                    this.l.momgetthecamera = false;
                    this.j.momgetthecamera = false;
                    this.vape();
                }
                else if (this.flux.equals("hardcore")) {
                    if (!this.b) {
                        this.a = true;
                    }
                    this.d = false;
                    this.flux = "creative";
                    this.vape();
                    this.d = false;
                    this.l.momgetthecamera = true;
                    this.j.momgetthecamera = true;
                }
                else {
                    if (!this.b) {
                        this.a = false;
                    }
                    this.flux = "survival";
                    this.vape();
                    this.l.momgetthecamera = true;
                    this.j.momgetthecamera = true;
                    this.d = false;
                }
                this.vape();
            }
            else if (button.vape == 4) {
                this.momgetthecamera = !this.momgetthecamera;
                this.vape();
            }
            else if (button.vape == 7) {
                this.c = !this.c;
                this.vape();
            }
            else if (button.vape == 5) {
                ++this.H;
                if (this.H >= WorldType.zerodayisaminecraftcheat.length) {
                    this.H = 0;
                }
                while (!this.momgetthecamera()) {
                    ++this.H;
                    if (this.H >= WorldType.zerodayisaminecraftcheat.length) {
                        this.H = 0;
                    }
                }
                this.zerodayisaminecraftcheat = "";
                this.vape();
                this.zerodayisaminecraftcheat(this.f);
            }
            else if (button.vape == 6) {
                this.b = true;
                this.a = !this.a;
                this.vape();
            }
            else if (button.vape == 8) {
                if (WorldType.zerodayisaminecraftcheat[this.H] == WorldType.sigma) {
                    this.u.zerodayisaminecraftcheat(new GuiCreateFlatWorld(this, this.zerodayisaminecraftcheat));
                }
                else {
                    this.u.zerodayisaminecraftcheat(new GuiCustomizeWorldScreen(this, this.zerodayisaminecraftcheat));
                }
            }
        }
    }
    
    private boolean momgetthecamera() {
        final WorldType worldtype = WorldType.zerodayisaminecraftcheat[this.H];
        return worldtype != null && worldtype.zues() && (worldtype != WorldType.vape || GuiScreen.m());
    }
    
    private void a() {
        this.zerodayisaminecraftcheat(!this.f);
    }
    
    private void zerodayisaminecraftcheat(final boolean p_146316_1_) {
        this.f = p_146316_1_;
        if (WorldType.zerodayisaminecraftcheat[this.H] == WorldType.vape) {
            this.g.a = !this.f;
            this.g.momgetthecamera = false;
            if (this.vape == null) {
                this.vape = this.flux;
            }
            this.flux = "spectator";
            this.i.a = false;
            this.j.a = false;
            this.k.a = this.f;
            this.l.a = false;
            this.q.a = false;
        }
        else {
            this.g.a = !this.f;
            this.g.momgetthecamera = true;
            if (this.vape != null) {
                this.flux = this.vape;
                this.vape = null;
            }
            this.i.a = (this.f && WorldType.zerodayisaminecraftcheat[this.H] != WorldType.flux);
            this.j.a = this.f;
            this.k.a = this.f;
            this.l.a = this.f;
            this.q.a = (this.f && (WorldType.zerodayisaminecraftcheat[this.H] == WorldType.sigma || WorldType.zerodayisaminecraftcheat[this.H] == WorldType.flux));
        }
        this.vape();
        if (this.f) {
            this.h.flux = I18n.zerodayisaminecraftcheat("gui.done", new Object[0]);
        }
        else {
            this.h.flux = I18n.zerodayisaminecraftcheat("selectWorld.moreWorldOptions", new Object[0]);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        if (this.sigma.c() && !this.f) {
            this.sigma.zerodayisaminecraftcheat(typedChar, keyCode);
            this.G = this.sigma.zeroday();
        }
        else if (this.pandora.c() && this.f) {
            this.pandora.zerodayisaminecraftcheat(typedChar, keyCode);
            this.t = this.pandora.zeroday();
        }
        if (keyCode == 28 || keyCode == 156) {
            this.zerodayisaminecraftcheat(this.y.get(0));
        }
        this.y.get(0).momgetthecamera = (this.sigma.zeroday().length() > 0);
        this.flux();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        if (this.f) {
            this.pandora.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        }
        else {
            this.sigma.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("selectWorld.create", new Object[0]), this.w / 2, 20, -1);
        if (this.f) {
            Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("selectWorld.enterSeed", new Object[0]), this.w / 2 - 100, 47, -6250336);
            Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("selectWorld.seedInfo", new Object[0]), this.w / 2 - 100, 85, -6250336);
            if (this.i.a) {
                Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("selectWorld.mapFeatures.info", new Object[0]), this.w / 2 - 150, 122, -6250336);
            }
            if (this.l.a) {
                Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("selectWorld.allowCommands.info", new Object[0]), this.w / 2 - 150, 172, -6250336);
            }
            this.pandora.vape();
            if (WorldType.zerodayisaminecraftcheat[this.H].momgetthecamera()) {
                this.C.zerodayisaminecraftcheat(I18n.zerodayisaminecraftcheat(WorldType.zerodayisaminecraftcheat[this.H].sigma(), new Object[0]), this.k.pandora + 2, this.k.zues + 22, this.k.zeroday(), 10526880);
            }
        }
        else {
            Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("selectWorld.enterName", new Object[0]), this.w / 2 - 100, 47, -6250336);
            Gui.zeroday(this.C, String.valueOf(I18n.zerodayisaminecraftcheat("selectWorld.resultFolder", new Object[0])) + " " + this.zues, this.w / 2 - 100, 85, -6250336);
            this.sigma.vape();
            Gui.zeroday(this.C, this.r, this.w / 2 - 100, 137, -6250336);
            Gui.zeroday(this.C, this.s, this.w / 2 - 100, 149, -6250336);
        }
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    public void zerodayisaminecraftcheat(final WorldInfo p_146318_1_) {
        this.G = I18n.zerodayisaminecraftcheat("selectWorld.newWorld.copyOf", p_146318_1_.b());
        this.t = new StringBuilder(String.valueOf(p_146318_1_.zeroday())).toString();
        this.H = p_146318_1_.l().vape();
        this.zerodayisaminecraftcheat = p_146318_1_.s();
        this.momgetthecamera = p_146318_1_.j();
        this.a = p_146318_1_.m();
        if (p_146318_1_.k()) {
            this.flux = "hardcore";
        }
        else if (p_146318_1_.i().zues()) {
            this.flux = "survival";
        }
        else if (p_146318_1_.i().pandora()) {
            this.flux = "creative";
        }
    }
}

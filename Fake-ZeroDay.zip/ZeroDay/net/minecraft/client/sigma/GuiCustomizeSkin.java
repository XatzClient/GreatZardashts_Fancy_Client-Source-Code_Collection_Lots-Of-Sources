// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.vape.vape.EnumPlayerModelParts;
import net.minecraft.client.b.I18n;

public class GuiCustomizeSkin extends GuiScreen
{
    private final GuiScreen zerodayisaminecraftcheat;
    private String zeroday;
    
    public GuiCustomizeSkin(final GuiScreen parentScreenIn) {
        this.zerodayisaminecraftcheat = parentScreenIn;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        int i = 0;
        this.zeroday = I18n.zerodayisaminecraftcheat("options.skinCustomisation.title", new Object[0]);
        EnumPlayerModelParts[] values;
        for (int length = (values = EnumPlayerModelParts.values()).length, j = 0; j < length; ++j) {
            final EnumPlayerModelParts enumplayermodelparts = values[j];
            this.y.add(new zerodayisaminecraftcheat(enumplayermodelparts.zeroday(), this.w / 2 - 155 + i % 2 * 160, this.x / 6 + 24 * (i >> 1), 150, 20, enumplayermodelparts, (zerodayisaminecraftcheat)null));
            ++i;
        }
        if (i % 2 == 1) {
            ++i;
        }
        this.y.add(new GuiButton(200, this.w / 2 - 100, this.x / 6 + 24 * (i >> 1), I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            if (button.vape == 200) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
            }
            else if (button instanceof zerodayisaminecraftcheat) {
                final EnumPlayerModelParts enumplayermodelparts = ((zerodayisaminecraftcheat)button).f;
                this.u.r.zerodayisaminecraftcheat(enumplayermodelparts);
                button.flux = this.zerodayisaminecraftcheat(enumplayermodelparts);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, this.zeroday, this.w / 2, 20, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    private String zerodayisaminecraftcheat(final EnumPlayerModelParts playerModelParts) {
        String s;
        if (this.u.r.pandora().contains(playerModelParts)) {
            s = I18n.zerodayisaminecraftcheat("options.on", new Object[0]);
        }
        else {
            s = I18n.zerodayisaminecraftcheat("options.off", new Object[0]);
        }
        return String.valueOf(playerModelParts.pandora().a()) + ": " + s;
    }
    
    class zerodayisaminecraftcheat extends GuiButton
    {
        private final EnumPlayerModelParts f;
        
        private zerodayisaminecraftcheat(final int p_i45514_2_, final int p_i45514_3_, final int p_i45514_4_, final int p_i45514_5_, final int p_i45514_6_, final EnumPlayerModelParts playerModelParts) {
            super(p_i45514_2_, p_i45514_3_, p_i45514_4_, p_i45514_5_, p_i45514_6_, GuiCustomizeSkin.this.zerodayisaminecraftcheat(playerModelParts));
            this.f = playerModelParts;
        }
    }
}

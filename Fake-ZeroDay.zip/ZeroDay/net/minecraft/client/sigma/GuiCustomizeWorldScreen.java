// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.q.zerodayisaminecraftcheat.BiomeGenBase;
import net.minecraft.o.MathHelper;
import java.io.IOException;
import net.minecraft.client.b.I18n;
import com.google.common.primitives.Floats;
import java.util.Random;
import net.minecraft.q.zues.ChunkProviderSettings;
import com.google.common.base.Predicate;

public class GuiCustomizeWorldScreen extends GuiScreen implements GuiPageButtonList.flux, GuiSlider.zerodayisaminecraftcheat
{
    private GuiCreateWorld zues;
    protected String zerodayisaminecraftcheat;
    protected String zeroday;
    protected String sigma;
    protected String[] pandora;
    private GuiPageButtonList flux;
    private GuiButton vape;
    private GuiButton momgetthecamera;
    private GuiButton a;
    private GuiButton b;
    private GuiButton c;
    private GuiButton d;
    private GuiButton e;
    private GuiButton f;
    private boolean g;
    private int h;
    private boolean i;
    private Predicate<String> j;
    private ChunkProviderSettings.zerodayisaminecraftcheat k;
    private ChunkProviderSettings.zerodayisaminecraftcheat l;
    private Random q;
    
    public GuiCustomizeWorldScreen(final GuiScreen p_i45521_1_, final String p_i45521_2_) {
        this.zerodayisaminecraftcheat = "Customize World Settings";
        this.zeroday = "Page 1 of 3";
        this.sigma = "Basic Settings";
        this.pandora = new String[4];
        this.g = false;
        this.h = 0;
        this.i = false;
        this.j = (Predicate<String>)new Predicate<String>() {
            public boolean zerodayisaminecraftcheat(final String p_apply_1_) {
                final Float f = Floats.tryParse(p_apply_1_);
                return p_apply_1_.length() == 0 || (f != null && Floats.isFinite((float)f) && f >= 0.0f);
            }
        };
        this.k = new ChunkProviderSettings.zerodayisaminecraftcheat();
        this.q = new Random();
        this.zues = (GuiCreateWorld)p_i45521_1_;
        this.zerodayisaminecraftcheat(p_i45521_2_);
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        int i = 0;
        int j = 0;
        if (this.flux != null) {
            i = this.flux.zues();
            j = this.flux.f();
        }
        this.zerodayisaminecraftcheat = I18n.zerodayisaminecraftcheat("options.customizeTitle", new Object[0]);
        this.y.clear();
        this.y.add(this.b = new GuiButton(302, 20, 5, 80, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.prev", new Object[0])));
        this.y.add(this.c = new GuiButton(303, this.w - 100, 5, 80, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.next", new Object[0])));
        this.y.add(this.a = new GuiButton(304, this.w / 2 - 187, this.x - 27, 90, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.defaults", new Object[0])));
        this.y.add(this.momgetthecamera = new GuiButton(301, this.w / 2 - 92, this.x - 27, 90, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.randomize", new Object[0])));
        this.y.add(this.f = new GuiButton(305, this.w / 2 + 3, this.x - 27, 90, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.presets", new Object[0])));
        this.y.add(this.vape = new GuiButton(300, this.w / 2 + 98, this.x - 27, 90, 20, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
        this.a.momgetthecamera = this.g;
        this.d = new GuiButton(306, this.w / 2 - 55, 160, 50, 20, I18n.zerodayisaminecraftcheat("gui.yes", new Object[0]));
        this.d.a = false;
        this.y.add(this.d);
        this.e = new GuiButton(307, this.w / 2 + 5, 160, 50, 20, I18n.zerodayisaminecraftcheat("gui.no", new Object[0]));
        this.e.a = false;
        this.y.add(this.e);
        if (this.h != 0) {
            this.d.a = true;
            this.e.a = true;
        }
        this.vape();
        if (i != 0) {
            this.flux.sigma(i);
            this.flux.vape(j);
            this.b();
        }
    }
    
    @Override
    public void b_() throws IOException {
        super.b_();
        this.flux.momgetthecamera();
    }
    
    private void vape() {
        final GuiPageButtonList.zues[] aguipagebuttonlist$guilistentry = { new GuiPageButtonList.vape(160, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.seaLevel", new Object[0]), true, this, 1.0f, 255.0f, (float)this.l.j), new GuiPageButtonList.zeroday(148, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useCaves", new Object[0]), true, this.l.k), new GuiPageButtonList.zeroday(150, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useStrongholds", new Object[0]), true, this.l.n), new GuiPageButtonList.zeroday(151, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useVillages", new Object[0]), true, this.l.o), new GuiPageButtonList.zeroday(152, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useMineShafts", new Object[0]), true, this.l.p), new GuiPageButtonList.zeroday(153, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useTemples", new Object[0]), true, this.l.q), new GuiPageButtonList.zeroday(210, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useMonuments", new Object[0]), true, this.l.r), new GuiPageButtonList.zeroday(154, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useRavines", new Object[0]), true, this.l.s), new GuiPageButtonList.zeroday(149, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useDungeons", new Object[0]), true, this.l.l), new GuiPageButtonList.vape(157, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.dungeonChance", new Object[0]), true, this, 1.0f, 100.0f, (float)this.l.m), new GuiPageButtonList.zeroday(155, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useWaterLakes", new Object[0]), true, this.l.t), new GuiPageButtonList.vape(158, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.waterLakeChance", new Object[0]), true, this, 1.0f, 100.0f, (float)this.l.u), new GuiPageButtonList.zeroday(156, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useLavaLakes", new Object[0]), true, this.l.v), new GuiPageButtonList.vape(159, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.lavaLakeChance", new Object[0]), true, this, 10.0f, 100.0f, (float)this.l.w), new GuiPageButtonList.zeroday(161, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.useLavaOceans", new Object[0]), true, this.l.x), new GuiPageButtonList.vape(162, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.fixedBiome", new Object[0]), true, this, -1.0f, 37.0f, (float)this.l.y), new GuiPageButtonList.vape(163, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeSize", new Object[0]), true, this, 1.0f, 8.0f, (float)this.l.z), new GuiPageButtonList.vape(164, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.riverSize", new Object[0]), true, this, 1.0f, 5.0f, (float)this.l.A) };
        final GuiPageButtonList.zues[] aguipagebuttonlist$guilistentry2 = { new GuiPageButtonList.pandora(416, I18n.zerodayisaminecraftcheat("tile.dirt.name", new Object[0]), false), null, new GuiPageButtonList.vape(165, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.B), new GuiPageButtonList.vape(166, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.C), new GuiPageButtonList.vape(167, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.D), new GuiPageButtonList.vape(168, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.E), new GuiPageButtonList.pandora(417, I18n.zerodayisaminecraftcheat("tile.gravel.name", new Object[0]), false), null, new GuiPageButtonList.vape(169, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.F), new GuiPageButtonList.vape(170, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.G), new GuiPageButtonList.vape(171, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.H), new GuiPageButtonList.vape(172, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.I), new GuiPageButtonList.pandora(418, I18n.zerodayisaminecraftcheat("tile.stone.granite.name", new Object[0]), false), null, new GuiPageButtonList.vape(173, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.J), new GuiPageButtonList.vape(174, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.K), new GuiPageButtonList.vape(175, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.L), new GuiPageButtonList.vape(176, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.M), new GuiPageButtonList.pandora(419, I18n.zerodayisaminecraftcheat("tile.stone.diorite.name", new Object[0]), false), null, new GuiPageButtonList.vape(177, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.N), new GuiPageButtonList.vape(178, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.O), new GuiPageButtonList.vape(179, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.P), new GuiPageButtonList.vape(180, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.Q), new GuiPageButtonList.pandora(420, I18n.zerodayisaminecraftcheat("tile.stone.andesite.name", new Object[0]), false), null, new GuiPageButtonList.vape(181, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.R), new GuiPageButtonList.vape(182, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.S), new GuiPageButtonList.vape(183, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.T), new GuiPageButtonList.vape(184, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.U), new GuiPageButtonList.pandora(421, I18n.zerodayisaminecraftcheat("tile.oreCoal.name", new Object[0]), false), null, new GuiPageButtonList.vape(185, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.V), new GuiPageButtonList.vape(186, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.W), new GuiPageButtonList.vape(187, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.X), new GuiPageButtonList.vape(189, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.Y), new GuiPageButtonList.pandora(422, I18n.zerodayisaminecraftcheat("tile.oreIron.name", new Object[0]), false), null, new GuiPageButtonList.vape(190, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.Z), new GuiPageButtonList.vape(191, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.aa), new GuiPageButtonList.vape(192, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.ab), new GuiPageButtonList.vape(193, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.ac), new GuiPageButtonList.pandora(423, I18n.zerodayisaminecraftcheat("tile.oreGold.name", new Object[0]), false), null, new GuiPageButtonList.vape(194, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.ad), new GuiPageButtonList.vape(195, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.ae), new GuiPageButtonList.vape(196, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.af), new GuiPageButtonList.vape(197, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.ag), new GuiPageButtonList.pandora(424, I18n.zerodayisaminecraftcheat("tile.oreRedstone.name", new Object[0]), false), null, new GuiPageButtonList.vape(198, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.ah), new GuiPageButtonList.vape(199, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.ai), new GuiPageButtonList.vape(200, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.aj), new GuiPageButtonList.vape(201, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.ak), new GuiPageButtonList.pandora(425, I18n.zerodayisaminecraftcheat("tile.oreDiamond.name", new Object[0]), false), null, new GuiPageButtonList.vape(202, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.al), new GuiPageButtonList.vape(203, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.am), new GuiPageButtonList.vape(204, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.minHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.an), new GuiPageButtonList.vape(205, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.maxHeight", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.ao), new GuiPageButtonList.pandora(426, I18n.zerodayisaminecraftcheat("tile.oreLapis.name", new Object[0]), false), null, new GuiPageButtonList.vape(206, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.size", new Object[0]), false, this, 1.0f, 50.0f, (float)this.l.ap), new GuiPageButtonList.vape(207, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.count", new Object[0]), false, this, 0.0f, 40.0f, (float)this.l.aq), new GuiPageButtonList.vape(208, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.center", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.ar), new GuiPageButtonList.vape(209, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.spread", new Object[0]), false, this, 0.0f, 255.0f, (float)this.l.as) };
        final GuiPageButtonList.zues[] aguipagebuttonlist$guilistentry3 = { new GuiPageButtonList.vape(100, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.mainNoiseScaleX", new Object[0]), false, this, 1.0f, 5000.0f, this.l.a), new GuiPageButtonList.vape(101, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.mainNoiseScaleY", new Object[0]), false, this, 1.0f, 5000.0f, this.l.b), new GuiPageButtonList.vape(102, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.mainNoiseScaleZ", new Object[0]), false, this, 1.0f, 5000.0f, this.l.c), new GuiPageButtonList.vape(103, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.depthNoiseScaleX", new Object[0]), false, this, 1.0f, 2000.0f, this.l.flux), new GuiPageButtonList.vape(104, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.depthNoiseScaleZ", new Object[0]), false, this, 1.0f, 2000.0f, this.l.vape), new GuiPageButtonList.vape(105, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.depthNoiseScaleExponent", new Object[0]), false, this, 0.01f, 20.0f, this.l.momgetthecamera), new GuiPageButtonList.vape(106, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.baseSize", new Object[0]), false, this, 1.0f, 25.0f, this.l.d), new GuiPageButtonList.vape(107, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.coordinateScale", new Object[0]), false, this, 1.0f, 6000.0f, this.l.zeroday), new GuiPageButtonList.vape(108, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.heightScale", new Object[0]), false, this, 1.0f, 6000.0f, this.l.sigma), new GuiPageButtonList.vape(109, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.stretchY", new Object[0]), false, this, 0.01f, 50.0f, this.l.e), new GuiPageButtonList.vape(110, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.upperLimitScale", new Object[0]), false, this, 1.0f, 5000.0f, this.l.pandora), new GuiPageButtonList.vape(111, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.lowerLimitScale", new Object[0]), false, this, 1.0f, 5000.0f, this.l.zues), new GuiPageButtonList.vape(112, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeDepthWeight", new Object[0]), false, this, 1.0f, 20.0f, this.l.f), new GuiPageButtonList.vape(113, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeDepthOffset", new Object[0]), false, this, 0.0f, 20.0f, this.l.g), new GuiPageButtonList.vape(114, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeScaleWeight", new Object[0]), false, this, 1.0f, 20.0f, this.l.h), new GuiPageButtonList.vape(115, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeScaleOffset", new Object[0]), false, this, 0.0f, 20.0f, this.l.i) };
        final GuiPageButtonList.zues[] aguipagebuttonlist$guilistentry4 = { new GuiPageButtonList.pandora(400, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.mainNoiseScaleX", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(132, String.format("%5.3f", this.l.a), false, this.j), new GuiPageButtonList.pandora(401, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.mainNoiseScaleY", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(133, String.format("%5.3f", this.l.b), false, this.j), new GuiPageButtonList.pandora(402, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.mainNoiseScaleZ", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(134, String.format("%5.3f", this.l.c), false, this.j), new GuiPageButtonList.pandora(403, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.depthNoiseScaleX", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(135, String.format("%5.3f", this.l.flux), false, this.j), new GuiPageButtonList.pandora(404, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.depthNoiseScaleZ", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(136, String.format("%5.3f", this.l.vape), false, this.j), new GuiPageButtonList.pandora(405, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.depthNoiseScaleExponent", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(137, String.format("%2.3f", this.l.momgetthecamera), false, this.j), new GuiPageButtonList.pandora(406, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.baseSize", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(138, String.format("%2.3f", this.l.d), false, this.j), new GuiPageButtonList.pandora(407, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.coordinateScale", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(139, String.format("%5.3f", this.l.zeroday), false, this.j), new GuiPageButtonList.pandora(408, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.heightScale", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(140, String.format("%5.3f", this.l.sigma), false, this.j), new GuiPageButtonList.pandora(409, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.stretchY", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(141, String.format("%2.3f", this.l.e), false, this.j), new GuiPageButtonList.pandora(410, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.upperLimitScale", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(142, String.format("%5.3f", this.l.pandora), false, this.j), new GuiPageButtonList.pandora(411, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.lowerLimitScale", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(143, String.format("%5.3f", this.l.zues), false, this.j), new GuiPageButtonList.pandora(412, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeDepthWeight", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(144, String.format("%2.3f", this.l.f), false, this.j), new GuiPageButtonList.pandora(413, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeDepthOffset", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(145, String.format("%2.3f", this.l.g), false, this.j), new GuiPageButtonList.pandora(414, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeScaleWeight", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(146, String.format("%2.3f", this.l.h), false, this.j), new GuiPageButtonList.pandora(415, String.valueOf(I18n.zerodayisaminecraftcheat("createWorld.customize.custom.biomeScaleOffset", new Object[0])) + ":", false), new GuiPageButtonList.zerodayisaminecraftcheat(147, String.format("%2.3f", this.l.i), false, this.j) };
        this.flux = new GuiPageButtonList(this.u, this.w, this.x, 32, this.x - 32, 25, this, new GuiPageButtonList.zues[][] { aguipagebuttonlist$guilistentry, aguipagebuttonlist$guilistentry2, aguipagebuttonlist$guilistentry3, aguipagebuttonlist$guilistentry4 });
        for (int i = 0; i < 4; ++i) {
            this.pandora[i] = I18n.zerodayisaminecraftcheat("createWorld.customize.custom.page" + i, new Object[0]);
        }
        this.b();
    }
    
    public String flux() {
        return this.l.toString().replace("\n", "");
    }
    
    public void zerodayisaminecraftcheat(final String p_175324_1_) {
        if (p_175324_1_ != null && p_175324_1_.length() != 0) {
            this.l = ChunkProviderSettings.zerodayisaminecraftcheat.zerodayisaminecraftcheat(p_175324_1_);
        }
        else {
            this.l = new ChunkProviderSettings.zerodayisaminecraftcheat();
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int p_175319_1_, final String p_175319_2_) {
        float f = 0.0f;
        try {
            f = Float.parseFloat(p_175319_2_);
        }
        catch (NumberFormatException ex) {}
        float f2 = 0.0f;
        switch (p_175319_1_) {
            case 132: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l = this.l;
                final float zerodayisaminecraftcheat = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 5000.0f);
                l.a = zerodayisaminecraftcheat;
                f2 = zerodayisaminecraftcheat;
                break;
            }
            case 133: {
                final ChunkProviderSettings.zerodayisaminecraftcheat i = this.l;
                final float zerodayisaminecraftcheat2 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 5000.0f);
                i.b = zerodayisaminecraftcheat2;
                f2 = zerodayisaminecraftcheat2;
                break;
            }
            case 134: {
                final ChunkProviderSettings.zerodayisaminecraftcheat j = this.l;
                final float zerodayisaminecraftcheat3 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 5000.0f);
                j.c = zerodayisaminecraftcheat3;
                f2 = zerodayisaminecraftcheat3;
                break;
            }
            case 135: {
                final ChunkProviderSettings.zerodayisaminecraftcheat k = this.l;
                final float zerodayisaminecraftcheat4 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 2000.0f);
                k.flux = zerodayisaminecraftcheat4;
                f2 = zerodayisaminecraftcheat4;
                break;
            }
            case 136: {
                final ChunkProviderSettings.zerodayisaminecraftcheat m = this.l;
                final float zerodayisaminecraftcheat5 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 2000.0f);
                m.vape = zerodayisaminecraftcheat5;
                f2 = zerodayisaminecraftcheat5;
                break;
            }
            case 137: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l2 = this.l;
                final float zerodayisaminecraftcheat6 = MathHelper.zerodayisaminecraftcheat(f, 0.01f, 20.0f);
                l2.momgetthecamera = zerodayisaminecraftcheat6;
                f2 = zerodayisaminecraftcheat6;
                break;
            }
            case 138: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l3 = this.l;
                final float zerodayisaminecraftcheat7 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 25.0f);
                l3.d = zerodayisaminecraftcheat7;
                f2 = zerodayisaminecraftcheat7;
                break;
            }
            case 139: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l4 = this.l;
                final float zerodayisaminecraftcheat8 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 6000.0f);
                l4.zeroday = zerodayisaminecraftcheat8;
                f2 = zerodayisaminecraftcheat8;
                break;
            }
            case 140: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l5 = this.l;
                final float zerodayisaminecraftcheat9 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 6000.0f);
                l5.sigma = zerodayisaminecraftcheat9;
                f2 = zerodayisaminecraftcheat9;
                break;
            }
            case 141: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l6 = this.l;
                final float zerodayisaminecraftcheat10 = MathHelper.zerodayisaminecraftcheat(f, 0.01f, 50.0f);
                l6.e = zerodayisaminecraftcheat10;
                f2 = zerodayisaminecraftcheat10;
                break;
            }
            case 142: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l7 = this.l;
                final float zerodayisaminecraftcheat11 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 5000.0f);
                l7.pandora = zerodayisaminecraftcheat11;
                f2 = zerodayisaminecraftcheat11;
                break;
            }
            case 143: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l8 = this.l;
                final float zerodayisaminecraftcheat12 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 5000.0f);
                l8.zues = zerodayisaminecraftcheat12;
                f2 = zerodayisaminecraftcheat12;
                break;
            }
            case 144: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l9 = this.l;
                final float zerodayisaminecraftcheat13 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 20.0f);
                l9.f = zerodayisaminecraftcheat13;
                f2 = zerodayisaminecraftcheat13;
                break;
            }
            case 145: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l10 = this.l;
                final float zerodayisaminecraftcheat14 = MathHelper.zerodayisaminecraftcheat(f, 0.0f, 20.0f);
                l10.g = zerodayisaminecraftcheat14;
                f2 = zerodayisaminecraftcheat14;
                break;
            }
            case 146: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l11 = this.l;
                final float zerodayisaminecraftcheat15 = MathHelper.zerodayisaminecraftcheat(f, 1.0f, 20.0f);
                l11.h = zerodayisaminecraftcheat15;
                f2 = zerodayisaminecraftcheat15;
                break;
            }
            case 147: {
                final ChunkProviderSettings.zerodayisaminecraftcheat l12 = this.l;
                final float zerodayisaminecraftcheat16 = MathHelper.zerodayisaminecraftcheat(f, 0.0f, 20.0f);
                l12.i = zerodayisaminecraftcheat16;
                f2 = zerodayisaminecraftcheat16;
                break;
            }
        }
        if (f2 != f && f != 0.0f) {
            ((GuiTextField)this.flux.pandora(p_175319_1_)).zerodayisaminecraftcheat(this.zeroday(p_175319_1_, f2));
        }
        ((GuiSlider)this.flux.pandora(p_175319_1_ - 132 + 100)).zerodayisaminecraftcheat(f2, false);
        if (!this.l.equals(this.k)) {
            this.zerodayisaminecraftcheat(true);
        }
    }
    
    private void zerodayisaminecraftcheat(final boolean p_181031_1_) {
        this.g = p_181031_1_;
        this.a.momgetthecamera = p_181031_1_;
    }
    
    @Override
    public String zerodayisaminecraftcheat(final int id, final String name, final float value) {
        return String.valueOf(name) + ": " + this.zeroday(id, value);
    }
    
    private String zeroday(final int p_175330_1_, final float p_175330_2_) {
        switch (p_175330_1_) {
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 107:
            case 108:
            case 110:
            case 111:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 139:
            case 140:
            case 142:
            case 143: {
                return String.format("%5.3f", p_175330_2_);
            }
            case 105:
            case 106:
            case 109:
            case 112:
            case 113:
            case 114:
            case 115:
            case 137:
            case 138:
            case 141:
            case 144:
            case 145:
            case 146:
            case 147: {
                return String.format("%2.3f", p_175330_2_);
            }
            default: {
                return String.format("%d", (int)p_175330_2_);
            }
            case 162: {
                if (p_175330_2_ < 0.0f) {
                    return I18n.zerodayisaminecraftcheat("gui.all", new Object[0]);
                }
                if ((int)p_175330_2_ >= BiomeGenBase.p.ar) {
                    final BiomeGenBase biomegenbase1 = BiomeGenBase.f()[(int)p_175330_2_ + 2];
                    return (biomegenbase1 != null) ? biomegenbase1.Z : "?";
                }
                final BiomeGenBase biomegenbase2 = BiomeGenBase.f()[(int)p_175330_2_];
                return (biomegenbase2 != null) ? biomegenbase2.Z : "?";
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int p_175321_1_, final boolean p_175321_2_) {
        switch (p_175321_1_) {
            case 148: {
                this.l.k = p_175321_2_;
                break;
            }
            case 149: {
                this.l.l = p_175321_2_;
                break;
            }
            case 150: {
                this.l.n = p_175321_2_;
                break;
            }
            case 151: {
                this.l.o = p_175321_2_;
                break;
            }
            case 152: {
                this.l.p = p_175321_2_;
                break;
            }
            case 153: {
                this.l.q = p_175321_2_;
                break;
            }
            case 154: {
                this.l.s = p_175321_2_;
                break;
            }
            case 155: {
                this.l.t = p_175321_2_;
                break;
            }
            case 156: {
                this.l.v = p_175321_2_;
                break;
            }
            case 161: {
                this.l.x = p_175321_2_;
                break;
            }
            case 210: {
                this.l.r = p_175321_2_;
                break;
            }
        }
        if (!this.l.equals(this.k)) {
            this.zerodayisaminecraftcheat(true);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int id, final float value) {
        switch (id) {
            case 100: {
                this.l.a = value;
                break;
            }
            case 101: {
                this.l.b = value;
                break;
            }
            case 102: {
                this.l.c = value;
                break;
            }
            case 103: {
                this.l.flux = value;
                break;
            }
            case 104: {
                this.l.vape = value;
                break;
            }
            case 105: {
                this.l.momgetthecamera = value;
                break;
            }
            case 106: {
                this.l.d = value;
                break;
            }
            case 107: {
                this.l.zeroday = value;
                break;
            }
            case 108: {
                this.l.sigma = value;
                break;
            }
            case 109: {
                this.l.e = value;
                break;
            }
            case 110: {
                this.l.pandora = value;
                break;
            }
            case 111: {
                this.l.zues = value;
                break;
            }
            case 112: {
                this.l.f = value;
                break;
            }
            case 113: {
                this.l.g = value;
                break;
            }
            case 114: {
                this.l.h = value;
                break;
            }
            case 115: {
                this.l.i = value;
                break;
            }
            case 157: {
                this.l.m = (int)value;
                break;
            }
            case 158: {
                this.l.u = (int)value;
                break;
            }
            case 159: {
                this.l.w = (int)value;
                break;
            }
            case 160: {
                this.l.j = (int)value;
                break;
            }
            case 162: {
                this.l.y = (int)value;
                break;
            }
            case 163: {
                this.l.z = (int)value;
                break;
            }
            case 164: {
                this.l.A = (int)value;
                break;
            }
            case 165: {
                this.l.B = (int)value;
                break;
            }
            case 166: {
                this.l.C = (int)value;
                break;
            }
            case 167: {
                this.l.D = (int)value;
                break;
            }
            case 168: {
                this.l.E = (int)value;
                break;
            }
            case 169: {
                this.l.F = (int)value;
                break;
            }
            case 170: {
                this.l.G = (int)value;
                break;
            }
            case 171: {
                this.l.H = (int)value;
                break;
            }
            case 172: {
                this.l.I = (int)value;
                break;
            }
            case 173: {
                this.l.J = (int)value;
                break;
            }
            case 174: {
                this.l.K = (int)value;
                break;
            }
            case 175: {
                this.l.L = (int)value;
                break;
            }
            case 176: {
                this.l.M = (int)value;
                break;
            }
            case 177: {
                this.l.N = (int)value;
                break;
            }
            case 178: {
                this.l.O = (int)value;
                break;
            }
            case 179: {
                this.l.P = (int)value;
                break;
            }
            case 180: {
                this.l.Q = (int)value;
                break;
            }
            case 181: {
                this.l.R = (int)value;
                break;
            }
            case 182: {
                this.l.S = (int)value;
                break;
            }
            case 183: {
                this.l.T = (int)value;
                break;
            }
            case 184: {
                this.l.U = (int)value;
                break;
            }
            case 185: {
                this.l.V = (int)value;
                break;
            }
            case 186: {
                this.l.W = (int)value;
                break;
            }
            case 187: {
                this.l.X = (int)value;
                break;
            }
            case 189: {
                this.l.Y = (int)value;
                break;
            }
            case 190: {
                this.l.Z = (int)value;
                break;
            }
            case 191: {
                this.l.aa = (int)value;
                break;
            }
            case 192: {
                this.l.ab = (int)value;
                break;
            }
            case 193: {
                this.l.ac = (int)value;
                break;
            }
            case 194: {
                this.l.ad = (int)value;
                break;
            }
            case 195: {
                this.l.ae = (int)value;
                break;
            }
            case 196: {
                this.l.af = (int)value;
                break;
            }
            case 197: {
                this.l.ag = (int)value;
                break;
            }
            case 198: {
                this.l.ah = (int)value;
                break;
            }
            case 199: {
                this.l.ai = (int)value;
                break;
            }
            case 200: {
                this.l.aj = (int)value;
                break;
            }
            case 201: {
                this.l.ak = (int)value;
                break;
            }
            case 202: {
                this.l.al = (int)value;
                break;
            }
            case 203: {
                this.l.am = (int)value;
                break;
            }
            case 204: {
                this.l.an = (int)value;
                break;
            }
            case 205: {
                this.l.ao = (int)value;
                break;
            }
            case 206: {
                this.l.ap = (int)value;
                break;
            }
            case 207: {
                this.l.aq = (int)value;
                break;
            }
            case 208: {
                this.l.ar = (int)value;
                break;
            }
            case 209: {
                this.l.as = (int)value;
                break;
            }
        }
        if (id >= 100 && id < 116) {
            final Gui gui = this.flux.pandora(id - 100 + 132);
            if (gui != null) {
                ((GuiTextField)gui).zerodayisaminecraftcheat(this.zeroday(id, value));
            }
        }
        if (!this.l.equals(this.k)) {
            this.zerodayisaminecraftcheat(true);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            switch (button.vape) {
                case 300: {
                    this.zues.zerodayisaminecraftcheat = this.l.toString();
                    this.u.zerodayisaminecraftcheat(this.zues);
                    break;
                }
                case 301: {
                    for (int i = 0; i < this.flux.zerodayisaminecraftcheat(); ++i) {
                        final GuiPageButtonList.sigma guipagebuttonlist$guientry = this.flux.zues(i);
                        final Gui gui = guipagebuttonlist$guientry.zerodayisaminecraftcheat();
                        if (gui instanceof GuiButton) {
                            final GuiButton guibutton = (GuiButton)gui;
                            if (guibutton instanceof GuiSlider) {
                                final float f = ((GuiSlider)guibutton).pandora() * (0.75f + this.q.nextFloat() * 0.5f) + (this.q.nextFloat() * 0.1f - 0.05f);
                                ((GuiSlider)guibutton).zerodayisaminecraftcheat(MathHelper.zerodayisaminecraftcheat(f, 0.0f, 1.0f));
                            }
                            else if (guibutton instanceof GuiListButton) {
                                ((GuiListButton)guibutton).zeroday(this.q.nextBoolean());
                            }
                        }
                        final Gui gui2 = guipagebuttonlist$guientry.zeroday();
                        if (gui2 instanceof GuiButton) {
                            final GuiButton guibutton2 = (GuiButton)gui2;
                            if (guibutton2 instanceof GuiSlider) {
                                final float f2 = ((GuiSlider)guibutton2).pandora() * (0.75f + this.q.nextFloat() * 0.5f) + (this.q.nextFloat() * 0.1f - 0.05f);
                                ((GuiSlider)guibutton2).zerodayisaminecraftcheat(MathHelper.zerodayisaminecraftcheat(f2, 0.0f, 1.0f));
                            }
                            else if (guibutton2 instanceof GuiListButton) {
                                ((GuiListButton)guibutton2).zeroday(this.q.nextBoolean());
                            }
                        }
                    }
                }
                case 302: {
                    this.flux.b();
                    this.b();
                    break;
                }
                case 303: {
                    this.flux.c();
                    this.b();
                    break;
                }
                case 304: {
                    if (this.g) {
                        this.zerodayisaminecraftcheat(304);
                        break;
                    }
                    break;
                }
                case 305: {
                    this.u.zerodayisaminecraftcheat(new GuiScreenCustomizePresets(this));
                    break;
                }
                case 306: {
                    this.a();
                    break;
                }
                case 307: {
                    this.h = 0;
                    this.a();
                    break;
                }
            }
        }
    }
    
    private void momgetthecamera() {
        this.l.zerodayisaminecraftcheat();
        this.vape();
        this.zerodayisaminecraftcheat(false);
    }
    
    private void zerodayisaminecraftcheat(final int p_175322_1_) {
        this.h = p_175322_1_;
        this.zeroday(true);
    }
    
    private void a() throws IOException {
        switch (this.h) {
            case 300: {
                this.zerodayisaminecraftcheat((GuiButton)this.flux.pandora(300));
                break;
            }
            case 304: {
                this.momgetthecamera();
                break;
            }
        }
        this.h = 0;
        this.i = true;
        this.zeroday(false);
    }
    
    private void zeroday(final boolean p_175329_1_) {
        this.d.a = p_175329_1_;
        this.e.a = p_175329_1_;
        this.momgetthecamera.momgetthecamera = !p_175329_1_;
        this.vape.momgetthecamera = !p_175329_1_;
        this.b.momgetthecamera = !p_175329_1_;
        this.c.momgetthecamera = !p_175329_1_;
        this.a.momgetthecamera = (this.g && !p_175329_1_);
        this.f.momgetthecamera = !p_175329_1_;
        this.flux.zerodayisaminecraftcheat(!p_175329_1_);
    }
    
    private void b() {
        this.b.momgetthecamera = (this.flux.zues() != 0);
        this.c.momgetthecamera = (this.flux.zues() != this.flux.flux() - 1);
        this.zeroday = I18n.zerodayisaminecraftcheat("book.pageIndicator", this.flux.zues() + 1, this.flux.flux());
        this.sigma = this.pandora[this.flux.zues()];
        this.momgetthecamera.momgetthecamera = (this.flux.zues() != this.flux.flux() - 1);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        super.zerodayisaminecraftcheat(typedChar, keyCode);
        if (this.h == 0) {
            switch (keyCode) {
                case 200: {
                    this.zerodayisaminecraftcheat(1.0f);
                    break;
                }
                case 208: {
                    this.zerodayisaminecraftcheat(-1.0f);
                    break;
                }
                default: {
                    this.flux.zerodayisaminecraftcheat(typedChar, keyCode);
                    break;
                }
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final float p_175327_1_) {
        final Gui gui = this.flux.a();
        if (gui instanceof GuiTextField) {
            float f = p_175327_1_;
            if (GuiScreen.m()) {
                f = p_175327_1_ * 0.1f;
                if (GuiScreen.l()) {
                    f *= 0.1f;
                }
            }
            else if (GuiScreen.l()) {
                f = p_175327_1_ * 10.0f;
                if (GuiScreen.n()) {
                    f *= 10.0f;
                }
            }
            final GuiTextField guitextfield = (GuiTextField)gui;
            Float f2 = Floats.tryParse(guitextfield.zeroday());
            if (f2 != null) {
                f2 += f;
                final int i = guitextfield.pandora();
                final String s = this.zeroday(guitextfield.pandora(), f2);
                guitextfield.zerodayisaminecraftcheat(s);
                this.zerodayisaminecraftcheat(i, s);
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        if (this.h == 0 && !this.i) {
            this.flux.zeroday(mouseX, mouseY, mouseButton);
        }
    }
    
    @Override
    protected void zeroday(final int mouseX, final int mouseY, final int state) {
        super.zeroday(mouseX, mouseY, state);
        if (this.i) {
            this.i = false;
        }
        else if (this.h == 0) {
            this.flux.sigma(mouseX, mouseY, state);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        this.flux.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        Gui.zerodayisaminecraftcheat(this.C, this.zerodayisaminecraftcheat, this.w / 2, 2, 16777215);
        Gui.zerodayisaminecraftcheat(this.C, this.zeroday, this.w / 2, 12, 16777215);
        Gui.zerodayisaminecraftcheat(this.C, this.sigma, this.w / 2, 22, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        if (this.h != 0) {
            Gui.zerodayisaminecraftcheat(0, 0, this.w, this.x, Integer.MIN_VALUE);
            this.zues(this.w / 2 - 91, this.w / 2 + 90, 99, -2039584);
            this.zues(this.w / 2 - 91, this.w / 2 + 90, 185, -6250336);
            this.flux(this.w / 2 - 91, 99, 185, -2039584);
            this.flux(this.w / 2 + 90, 99, 185, -6250336);
            final float f = 85.0f;
            final float f2 = 180.0f;
            GlStateManager.flux();
            GlStateManager.f();
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            this.u.I().zerodayisaminecraftcheat(GuiCustomizeWorldScreen.m);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            final float f3 = 32.0f;
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
            worldrenderer.zeroday(this.w / 2 - 90, 185.0, 0.0).zerodayisaminecraftcheat(0.0, 2.65625).zeroday(64, 64, 64, 64).zues();
            worldrenderer.zeroday(this.w / 2 + 90, 185.0, 0.0).zerodayisaminecraftcheat(5.625, 2.65625).zeroday(64, 64, 64, 64).zues();
            worldrenderer.zeroday(this.w / 2 + 90, 100.0, 0.0).zerodayisaminecraftcheat(5.625, 0.0).zeroday(64, 64, 64, 64).zues();
            worldrenderer.zeroday(this.w / 2 - 90, 100.0, 0.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(64, 64, 64, 64).zues();
            tessellator.zeroday();
            Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.confirmTitle", new Object[0]), this.w / 2, 105, 16777215);
            Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.confirm1", new Object[0]), this.w / 2, 125, 16777215);
            Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("createWorld.customize.custom.confirm2", new Object[0]), this.w / 2, 135, 16777215);
            this.d.zerodayisaminecraftcheat(this.u, mouseX, mouseY);
            this.e.zerodayisaminecraftcheat(this.u, mouseX, mouseY);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.util.Iterator;
import java.util.Random;
import zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat;
import zeroday.pandora.zerodayisaminecraftcheat.h.zeroday;
import zeroday.pandora.zerodayisaminecraftcheat.h.ab;
import zeroday.zerodayisaminecraftcheat.vape;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.V;
import java.io.IOException;
import net.minecraft.client.b.I18n;
import java.util.List;
import net.minecraft.o.IChatComponent;

public class GuiDisconnected extends GuiScreen
{
    private String zerodayisaminecraftcheat;
    private IChatComponent zeroday;
    private List<String> sigma;
    private final GuiScreen pandora;
    private int zues;
    
    public GuiDisconnected(final GuiScreen screen, final String reasonLocalizationKey, final IChatComponent chatComp) {
        this.pandora = screen;
        this.zerodayisaminecraftcheat = I18n.zerodayisaminecraftcheat(reasonLocalizationKey, new Object[0]);
        this.zeroday = chatComp;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.clear();
        this.sigma = (List<String>)this.C.sigma(this.zeroday.a(), this.w - 50);
        this.zues = this.sigma.size() * this.C.zeroday;
        this.y.add(new GuiButton(0, this.w / 2 - 100, this.x / 2 + this.zues / 2 + this.C.zeroday, I18n.zerodayisaminecraftcheat("gui.toMenu", new Object[0])));
        if (!V.zerodayisaminecraftcheat) {
            this.y.add(new GuiButton(1, this.w / 2 - 100, this.x / 2 + this.zues / 2 + this.C.zeroday + 24, I18n.zerodayisaminecraftcheat("Alt Manager", new Object[0])));
            this.y.add(new GuiButton(2, this.w / 2 - 100, this.x / 2 + this.zues / 2 + this.C.zeroday + 48, "Reconnect"));
            this.y.add(new GuiButton(3, this.w / 2 - 100, this.x / 2 + this.zues / 2 + this.C.zeroday + 72, "Reconnect with a Random Alt"));
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.vape == 0) {
            this.u.zerodayisaminecraftcheat(this.pandora);
        }
        if (button.vape == 1) {
            this.u.zerodayisaminecraftcheat(new vape());
        }
        if (button.vape == 2) {
            ab.zerodayisaminecraftcheat(this);
        }
        if (button.vape == 3) {
            final zeroday randomAlt = zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.h().sigma().get(new Random().nextInt(zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.h().sigma().size()));
            final String user2 = randomAlt.sigma();
            final String pass2 = randomAlt.zeroday();
            (vape.zerodayisaminecraftcheat = new zeroday.zerodayisaminecraftcheat.zeroday(user2, pass2)).start();
            ab.zerodayisaminecraftcheat(this);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, this.zerodayisaminecraftcheat, this.w / 2, this.x / 2 - this.zues / 2 - this.C.zeroday * 2, 11184810);
        int i = this.x / 2 - this.zues / 2;
        if (this.sigma != null) {
            for (final String s : this.sigma) {
                Gui.zerodayisaminecraftcheat(this.C, s, this.w / 2, i, 16777215);
                i += this.C.zeroday;
            }
        }
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
}

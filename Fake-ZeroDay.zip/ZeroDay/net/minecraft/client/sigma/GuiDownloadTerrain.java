// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.b.I18n;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C00PacketKeepAlive;
import java.io.IOException;
import net.minecraft.client.flux.NetHandlerPlayClient;

public class GuiDownloadTerrain extends GuiScreen
{
    private NetHandlerPlayClient zerodayisaminecraftcheat;
    private int zeroday;
    
    public GuiDownloadTerrain(final NetHandlerPlayClient netHandler) {
        this.zerodayisaminecraftcheat = netHandler;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.clear();
    }
    
    @Override
    public void sigma() {
        ++this.zeroday;
        if (this.zeroday % 20 == 0) {
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(new C00PacketKeepAlive());
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.flux(0);
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("multiplayer.downloadingTerrain", new Object[0]), this.w / 2, this.x / 2 - 50, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    @Override
    public boolean zues() {
        return false;
    }
}

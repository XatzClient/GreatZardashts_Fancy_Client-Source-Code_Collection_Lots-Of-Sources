// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.util.List;
import net.minecraft.client.b.I18n;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.flux.Enchantment;
import com.google.common.collect.Lists;
import net.minecraft.o.EnchantmentNameParts;
import net.minecraft.vape.Entity;
import net.minecraft.o.MathHelper;
import net.minecraft.client.a.RenderHelper;
import org.lwjgl.util.glu.Project;
import net.minecraft.client.a.GlStateManager;
import java.io.IOException;
import net.minecraft.client.a.EntityRenderer;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.client.a.OpenGlHelper;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.c;
import net.minecraft.b.Container;
import net.minecraft.q.World;
import net.minecraft.q.IWorldNameable;
import net.minecraft.c.ItemStack;
import net.minecraft.b.ContainerEnchantment;
import java.util.Random;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.client.pandora.ModelBook;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.sigma.zeroday.GuiContainer;

public class GuiEnchantment extends GuiContainer
{
    private static final ResourceLocation i;
    private static final ResourceLocation j;
    private static final ModelBook k;
    private final InventoryPlayer l;
    private Random q;
    private ContainerEnchantment r;
    public int zerodayisaminecraftcheat;
    public float zeroday;
    public float sigma;
    public float pandora;
    public float zues;
    public float flux;
    public float vape;
    ItemStack momgetthecamera;
    private final IWorldNameable s;
    
    static {
        i = new ResourceLocation("textures/gui/container/enchanting_table.png");
        j = new ResourceLocation("textures/entity/enchanting_table_book.png");
        k = new ModelBook();
    }
    
    public GuiEnchantment(final InventoryPlayer inventory, final World worldIn, final IWorldNameable p_i45502_3_) {
        super(new ContainerEnchantment(inventory, worldIn));
        this.q = new Random();
        this.l = inventory;
        this.r = (ContainerEnchantment)this.d;
        this.s = p_i45502_3_;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY) {
        this.C.zerodayisaminecraftcheat(this.s.sigma().momgetthecamera(), 12, 5, 4210752);
        this.C.zerodayisaminecraftcheat(this.l.sigma().momgetthecamera(), 8, this.c - 96 + 2, 4210752);
    }
    
    @Override
    public void sigma() {
        super.sigma();
        this.flux();
        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.c.zerodayisaminecraftcheat && OpenGlHelper.G && this.u.V() instanceof EntityPlayer) {
            if (this.u.m.vape != null) {
                this.u.m.vape.zerodayisaminecraftcheat();
            }
            this.u.m.b = 5;
            if (this.u.m.b != EntityRenderer.a) {
                this.u.m.zerodayisaminecraftcheat(EntityRenderer.momgetthecamera[18]);
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        final int i = (this.w - this.b) / 2;
        final int j = (this.x - this.c) / 2;
        for (int k = 0; k < 3; ++k) {
            final int l = mouseX - (i + 60);
            final int i2 = mouseY - (j + 14 + 19 * k);
            if (l >= 0 && i2 >= 0 && l < 108 && i2 < 19 && this.r.zeroday(this.u.e, k)) {
                this.u.zues.zerodayisaminecraftcheat(this.r.pandora, k);
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final float partialTicks, final int mouseX, final int mouseY) {
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.u.I().zerodayisaminecraftcheat(GuiEnchantment.i);
        final int i = (this.w - this.b) / 2;
        final int j = (this.x - this.c) / 2;
        this.zeroday(i, j, 0, 0, this.b, this.c);
        GlStateManager.v();
        GlStateManager.d(5889);
        GlStateManager.v();
        GlStateManager.u();
        final ScaledResolution scaledresolution = new ScaledResolution(this.u);
        GlStateManager.zeroday((scaledresolution.zerodayisaminecraftcheat() - 320) / 2 * scaledresolution.zues(), (scaledresolution.zeroday() - 240) / 2 * scaledresolution.zues(), 320 * scaledresolution.zues(), 240 * scaledresolution.zues());
        GlStateManager.zeroday(-0.34f, 0.23f, 0.0f);
        Project.gluPerspective(90.0f, 1.3333334f, 9.0f, 80.0f);
        final float f = 1.0f;
        GlStateManager.d(5888);
        GlStateManager.u();
        RenderHelper.zeroday();
        GlStateManager.zeroday(0.0f, 3.3f, -16.0f);
        GlStateManager.zerodayisaminecraftcheat(f, f, f);
        final float f2 = 5.0f;
        GlStateManager.zerodayisaminecraftcheat(f2, f2, f2);
        GlStateManager.zeroday(180.0f, 0.0f, 0.0f, 1.0f);
        this.u.I().zerodayisaminecraftcheat(GuiEnchantment.j);
        GlStateManager.zeroday(20.0f, 1.0f, 0.0f, 0.0f);
        final float f3 = this.vape + (this.flux - this.vape) * partialTicks;
        GlStateManager.zeroday((1.0f - f3) * 0.2f, (1.0f - f3) * 0.1f, (1.0f - f3) * 0.25f);
        GlStateManager.zeroday(-(1.0f - f3) * 90.0f - 90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.zeroday(180.0f, 1.0f, 0.0f, 0.0f);
        float f4 = this.sigma + (this.zeroday - this.sigma) * partialTicks + 0.25f;
        float f5 = this.sigma + (this.zeroday - this.sigma) * partialTicks + 0.75f;
        f4 = (f4 - MathHelper.zeroday((double)f4)) * 1.6f - 0.3f;
        f5 = (f5 - MathHelper.zeroday((double)f5)) * 1.6f - 0.3f;
        if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        if (f5 < 0.0f) {
            f5 = 0.0f;
        }
        if (f4 > 1.0f) {
            f4 = 1.0f;
        }
        if (f5 > 1.0f) {
            f5 = 1.0f;
        }
        GlStateManager.s();
        GuiEnchantment.k.zerodayisaminecraftcheat(null, 0.0f, f4, f5, f3, 0.0f, 0.0625f);
        GlStateManager.t();
        RenderHelper.zerodayisaminecraftcheat();
        GlStateManager.d(5889);
        GlStateManager.zeroday(0, 0, this.u.flux, this.u.vape);
        GlStateManager.w();
        GlStateManager.d(5888);
        GlStateManager.w();
        RenderHelper.zerodayisaminecraftcheat();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        EnchantmentNameParts.zerodayisaminecraftcheat().zerodayisaminecraftcheat(this.r.flux);
        final int k = this.r.zerodayisaminecraftcheat();
        for (int l = 0; l < 3; ++l) {
            final int i2 = i + 60;
            final int j2 = i2 + 20;
            final int k2 = 86;
            final String s = EnchantmentNameParts.zerodayisaminecraftcheat().zeroday();
            this.p = 0.0f;
            this.u.I().zerodayisaminecraftcheat(GuiEnchantment.i);
            final int l2 = this.r.vape[l];
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            if (l2 == 0) {
                this.zeroday(i2, j + 14 + 19 * l, 0, 185, 108, 19);
            }
            else {
                final String s2 = new StringBuilder().append(l2).toString();
                FontRenderer fontrenderer = this.u.j;
                int i3 = 6839882;
                if ((k < l + 1 || this.u.e.bA < l2) && !this.u.e.bz.pandora) {
                    this.zeroday(i2, j + 14 + 19 * l, 0, 185, 108, 19);
                    this.zeroday(i2 + 1, j + 15 + 19 * l, 16 * l, 239, 16, 16);
                    fontrenderer.zerodayisaminecraftcheat(s, j2, j + 16 + 19 * l, k2, (i3 & 0xFEFEFE) >> 1);
                    i3 = 4226832;
                }
                else {
                    final int j3 = mouseX - (i + 60);
                    final int k3 = mouseY - (j + 14 + 19 * l);
                    if (j3 >= 0 && k3 >= 0 && j3 < 108 && k3 < 19) {
                        this.zeroday(i2, j + 14 + 19 * l, 0, 204, 108, 19);
                        i3 = 16777088;
                    }
                    else {
                        this.zeroday(i2, j + 14 + 19 * l, 0, 166, 108, 19);
                    }
                    this.zeroday(i2 + 1, j + 15 + 19 * l, 16 * l, 223, 16, 16);
                    fontrenderer.zerodayisaminecraftcheat(s, j2, j + 16 + 19 * l, k2, i3);
                    i3 = 8453920;
                }
                fontrenderer = this.u.i;
                fontrenderer.zerodayisaminecraftcheat(s2, (float)(j2 + 86 - fontrenderer.zerodayisaminecraftcheat(s2)), (float)(j + 16 + 19 * l + 7), i3);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        final boolean flag = this.u.e.bz.pandora;
        final int i = this.r.zerodayisaminecraftcheat();
        for (int j = 0; j < 3; ++j) {
            final int k = this.r.vape[j];
            final int l = this.r.momgetthecamera[j];
            final int i2 = j + 1;
            if (this.sigma(60, 14 + 19 * j, 108, 17, mouseX, mouseY) && k > 0 && l >= 0) {
                final List<String> list = (List<String>)Lists.newArrayList();
                if (l >= 0 && Enchantment.zerodayisaminecraftcheat(l & 0xFF) != null) {
                    final String s = Enchantment.zerodayisaminecraftcheat(l & 0xFF).pandora((l & 0xFF00) >> 8);
                    list.add(String.valueOf(EnumChatFormatting.h.toString()) + EnumChatFormatting.m.toString() + I18n.zerodayisaminecraftcheat("container.enchant.clue", s));
                }
                if (!flag) {
                    if (l >= 0) {
                        list.add("");
                    }
                    if (this.u.e.bA < k) {
                        list.add(String.valueOf(EnumChatFormatting.e.toString()) + "Level Requirement: " + this.r.vape[j]);
                    }
                    else {
                        String s2 = "";
                        if (i2 == 1) {
                            s2 = I18n.zerodayisaminecraftcheat("container.enchant.lapis.one", new Object[0]);
                        }
                        else {
                            s2 = I18n.zerodayisaminecraftcheat("container.enchant.lapis.many", i2);
                        }
                        if (i >= i2) {
                            list.add(String.valueOf(EnumChatFormatting.momgetthecamera.toString()) + s2);
                        }
                        else {
                            list.add(String.valueOf(EnumChatFormatting.e.toString()) + s2);
                        }
                        if (i2 == 1) {
                            s2 = I18n.zerodayisaminecraftcheat("container.enchant.level.one", new Object[0]);
                        }
                        else {
                            s2 = I18n.zerodayisaminecraftcheat("container.enchant.level.many", i2);
                        }
                        list.add(String.valueOf(EnumChatFormatting.momgetthecamera.toString()) + s2);
                    }
                }
                this.zerodayisaminecraftcheat(list, mouseX, mouseY);
                break;
            }
        }
    }
    
    public void flux() {
        final ItemStack itemstack = this.d.zerodayisaminecraftcheat(0).zerodayisaminecraftcheat();
        if (!ItemStack.zeroday(itemstack, this.momgetthecamera)) {
            this.momgetthecamera = itemstack;
            do {
                this.pandora += this.q.nextInt(4) - this.q.nextInt(4);
            } while (this.zeroday <= this.pandora + 1.0f && this.zeroday >= this.pandora - 1.0f);
        }
        ++this.zerodayisaminecraftcheat;
        this.sigma = this.zeroday;
        this.vape = this.flux;
        boolean flag = false;
        for (int i = 0; i < 3; ++i) {
            if (this.r.vape[i] != 0) {
                flag = true;
            }
        }
        if (flag) {
            this.flux += 0.2f;
        }
        else {
            this.flux -= 0.2f;
        }
        this.flux = MathHelper.zerodayisaminecraftcheat(this.flux, 0.0f, 1.0f);
        float f1 = (this.pandora - this.zeroday) * 0.4f;
        final float f2 = 0.2f;
        f1 = MathHelper.zerodayisaminecraftcheat(f1, -f2, f2);
        this.zues += (f1 - this.zues) * 0.9f;
        this.zeroday += this.zues;
    }
}

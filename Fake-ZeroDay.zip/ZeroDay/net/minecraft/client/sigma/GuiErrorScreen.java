// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.client.b.I18n;

public class GuiErrorScreen extends GuiScreen
{
    private String zerodayisaminecraftcheat;
    private String zeroday;
    
    public GuiErrorScreen(final String p_i46319_1_, final String p_i46319_2_) {
        this.zerodayisaminecraftcheat = p_i46319_1_;
        this.zeroday = p_i46319_2_;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        super.zerodayisaminecraftcheat();
        this.y.add(new GuiButton(0, this.w / 2 - 100, 140, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.zerodayisaminecraftcheat(0, 0, this.w, this.x, -12574688, -11530224);
        Gui.zerodayisaminecraftcheat(this.C, this.zerodayisaminecraftcheat, this.w / 2, 90, 16777215);
        Gui.zerodayisaminecraftcheat(this.C, this.zeroday, this.w / 2, 110, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        this.u.zerodayisaminecraftcheat((GuiScreen)null);
    }
}

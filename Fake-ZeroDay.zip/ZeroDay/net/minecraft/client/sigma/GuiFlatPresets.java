// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.c.ItemStack;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.client.a.GlStateManager;
import java.util.Iterator;
import java.util.Map;
import com.google.common.collect.Maps;
import net.minecraft.q.zues.FlatGeneratorInfo;
import java.io.IOException;
import net.minecraft.client.b.I18n;
import org.lwjgl.input.Keyboard;
import net.minecraft.zerodayisaminecraftcheat.BlockTallGrass;
import net.minecraft.a.Items;
import net.minecraft.q.zues.FlatLayerInfo;
import java.util.Arrays;
import net.minecraft.q.zerodayisaminecraftcheat.BiomeGenBase;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.c.Item;
import net.minecraft.a.Blocks;
import com.google.common.collect.Lists;
import java.util.List;

public class GuiFlatPresets extends GuiScreen
{
    private static final List<zerodayisaminecraftcheat> zerodayisaminecraftcheat;
    private final GuiCreateFlatWorld zeroday;
    private String sigma;
    private String pandora;
    private String zues;
    private zeroday flux;
    private GuiButton vape;
    private GuiTextField momgetthecamera;
    
    static {
        zerodayisaminecraftcheat = Lists.newArrayList();
        zerodayisaminecraftcheat("Classic Flat", Item.zerodayisaminecraftcheat(Blocks.sigma), BiomeGenBase.i, Arrays.asList("village"), new FlatLayerInfo(1, Blocks.sigma), new FlatLayerInfo(2, Blocks.pandora), new FlatLayerInfo(1, Blocks.momgetthecamera));
        zerodayisaminecraftcheat("Tunnelers' Dream", Item.zerodayisaminecraftcheat(Blocks.zeroday), BiomeGenBase.k, Arrays.asList("biome_1", "dungeon", "decoration", "stronghold", "mineshaft"), new FlatLayerInfo(1, Blocks.sigma), new FlatLayerInfo(5, Blocks.pandora), new FlatLayerInfo(230, Blocks.zeroday), new FlatLayerInfo(1, Blocks.momgetthecamera));
        zerodayisaminecraftcheat("Water World", Items.ap, BiomeGenBase.F, Arrays.asList("biome_1", "oceanmonument"), new FlatLayerInfo(90, Blocks.b), new FlatLayerInfo(5, Blocks.e), new FlatLayerInfo(5, Blocks.pandora), new FlatLayerInfo(5, Blocks.zeroday), new FlatLayerInfo(1, Blocks.momgetthecamera));
        zerodayisaminecraftcheat("Overworld", Item.zerodayisaminecraftcheat(Blocks.z), BlockTallGrass.zerodayisaminecraftcheat.zeroday.zeroday(), BiomeGenBase.i, Arrays.asList("village", "biome_1", "decoration", "stronghold", "mineshaft", "dungeon", "lake", "lava_lake"), new FlatLayerInfo(1, Blocks.sigma), new FlatLayerInfo(3, Blocks.pandora), new FlatLayerInfo(59, Blocks.zeroday), new FlatLayerInfo(1, Blocks.momgetthecamera));
        zerodayisaminecraftcheat("Snowy Kingdom", Item.zerodayisaminecraftcheat(Blocks.az), BiomeGenBase.t, Arrays.asList("village", "biome_1"), new FlatLayerInfo(1, Blocks.az), new FlatLayerInfo(1, Blocks.sigma), new FlatLayerInfo(3, Blocks.pandora), new FlatLayerInfo(59, Blocks.zeroday), new FlatLayerInfo(1, Blocks.momgetthecamera));
        zerodayisaminecraftcheat("Bottomless Pit", Items.y, BiomeGenBase.i, Arrays.asList("village", "biome_1"), new FlatLayerInfo(1, Blocks.sigma), new FlatLayerInfo(3, Blocks.pandora), new FlatLayerInfo(2, Blocks.zues));
        zerodayisaminecraftcheat("Desert", Item.zerodayisaminecraftcheat(Blocks.e), BiomeGenBase.j, Arrays.asList("village", "biome_1", "decoration", "stronghold", "mineshaft", "dungeon"), new FlatLayerInfo(8, Blocks.e), new FlatLayerInfo(52, Blocks.s), new FlatLayerInfo(3, Blocks.zeroday), new FlatLayerInfo(1, Blocks.momgetthecamera));
        zerodayisaminecraftcheat("Redstone Ready", Items.au, BiomeGenBase.j, new FlatLayerInfo(52, Blocks.s), new FlatLayerInfo(3, Blocks.zeroday), new FlatLayerInfo(1, Blocks.momgetthecamera));
    }
    
    public GuiFlatPresets(final GuiCreateFlatWorld p_i46318_1_) {
        this.zeroday = p_i46318_1_;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.clear();
        Keyboard.enableRepeatEvents(true);
        this.sigma = I18n.zerodayisaminecraftcheat("createWorld.customize.presets.title", new Object[0]);
        this.pandora = I18n.zerodayisaminecraftcheat("createWorld.customize.presets.share", new Object[0]);
        this.zues = I18n.zerodayisaminecraftcheat("createWorld.customize.presets.list", new Object[0]);
        this.momgetthecamera = new GuiTextField(2, this.C, 50, 40, this.w - 100, 20);
        this.flux = new zeroday();
        this.momgetthecamera.flux(1230);
        this.momgetthecamera.zerodayisaminecraftcheat(this.zeroday.flux());
        this.y.add(this.vape = new GuiButton(0, this.w / 2 - 155, this.x - 28, 150, 20, I18n.zerodayisaminecraftcheat("createWorld.customize.presets.select", new Object[0])));
        this.y.add(new GuiButton(1, this.w / 2 + 5, this.x - 28, 150, 20, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        this.flux();
    }
    
    @Override
    public void b_() throws IOException {
        super.b_();
        this.flux.momgetthecamera();
    }
    
    @Override
    public void u_() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        this.momgetthecamera.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        if (!this.momgetthecamera.zerodayisaminecraftcheat(typedChar, keyCode)) {
            super.zerodayisaminecraftcheat(typedChar, keyCode);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.vape == 0 && this.momgetthecamera()) {
            this.zeroday.zerodayisaminecraftcheat(this.momgetthecamera.zeroday());
            this.u.zerodayisaminecraftcheat(this.zeroday);
        }
        else if (button.vape == 1) {
            this.u.zerodayisaminecraftcheat(this.zeroday);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        this.flux.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        Gui.zerodayisaminecraftcheat(this.C, this.sigma, this.w / 2, 8, 16777215);
        Gui.zeroday(this.C, this.pandora, 50, 30, 10526880);
        Gui.zeroday(this.C, this.zues, 50, 70, 10526880);
        this.momgetthecamera.vape();
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    @Override
    public void sigma() {
        this.momgetthecamera.zerodayisaminecraftcheat();
        super.sigma();
    }
    
    public void flux() {
        final boolean flag = this.momgetthecamera();
        this.vape.momgetthecamera = flag;
    }
    
    private boolean momgetthecamera() {
        return (this.flux.zerodayisaminecraftcheat > -1 && this.flux.zerodayisaminecraftcheat < GuiFlatPresets.zerodayisaminecraftcheat.size()) || this.momgetthecamera.zeroday().length() > 1;
    }
    
    private static void zerodayisaminecraftcheat(final String p_146425_0_, final Item p_146425_1_, final BiomeGenBase p_146425_2_, final FlatLayerInfo... p_146425_3_) {
        zerodayisaminecraftcheat(p_146425_0_, p_146425_1_, 0, p_146425_2_, null, p_146425_3_);
    }
    
    private static void zerodayisaminecraftcheat(final String p_146421_0_, final Item p_146421_1_, final BiomeGenBase p_146421_2_, final List<String> p_146421_3_, final FlatLayerInfo... p_146421_4_) {
        zerodayisaminecraftcheat(p_146421_0_, p_146421_1_, 0, p_146421_2_, p_146421_3_, p_146421_4_);
    }
    
    private static void zerodayisaminecraftcheat(final String p_175354_0_, final Item p_175354_1_, final int p_175354_2_, final BiomeGenBase p_175354_3_, final List<String> p_175354_4_, final FlatLayerInfo... p_175354_5_) {
        final FlatGeneratorInfo flatgeneratorinfo = new FlatGeneratorInfo();
        for (int i = p_175354_5_.length - 1; i >= 0; --i) {
            flatgeneratorinfo.sigma().add(p_175354_5_[i]);
        }
        flatgeneratorinfo.zerodayisaminecraftcheat(p_175354_3_.ar);
        flatgeneratorinfo.pandora();
        if (p_175354_4_ != null) {
            for (final String s : p_175354_4_) {
                flatgeneratorinfo.zeroday().put(s, Maps.newHashMap());
            }
        }
        GuiFlatPresets.zerodayisaminecraftcheat.add(new zerodayisaminecraftcheat(p_175354_1_, p_175354_2_, p_175354_0_, flatgeneratorinfo.toString()));
    }
    
    static class zerodayisaminecraftcheat
    {
        public Item zerodayisaminecraftcheat;
        public int zeroday;
        public String sigma;
        public String pandora;
        
        public zerodayisaminecraftcheat(final Item p_i45518_1_, final int p_i45518_2_, final String p_i45518_3_, final String p_i45518_4_) {
            this.zerodayisaminecraftcheat = p_i45518_1_;
            this.zeroday = p_i45518_2_;
            this.sigma = p_i45518_3_;
            this.pandora = p_i45518_4_;
        }
    }
    
    class zeroday extends GuiSlot
    {
        public int zerodayisaminecraftcheat;
        
        public zeroday() {
            super(GuiFlatPresets.this.u, GuiFlatPresets.this.w, GuiFlatPresets.this.x, 80, GuiFlatPresets.this.x - 37, 24);
            this.zerodayisaminecraftcheat = -1;
        }
        
        private void zerodayisaminecraftcheat(final int p_178054_1_, final int p_178054_2_, final Item p_178054_3_, final int p_178054_4_) {
            this.zues(p_178054_1_ + 1, p_178054_2_ + 1);
            GlStateManager.s();
            RenderHelper.sigma();
            GuiFlatPresets.this.v.zerodayisaminecraftcheat(new ItemStack(p_178054_3_, 1, p_178054_4_), p_178054_1_ + 2, p_178054_2_ + 2);
            RenderHelper.zerodayisaminecraftcheat();
            GlStateManager.t();
        }
        
        private void zues(final int p_148173_1_, final int p_148173_2_) {
            this.pandora(p_148173_1_, p_148173_2_, 0, 0);
        }
        
        private void pandora(final int p_148171_1_, final int p_148171_2_, final int p_148171_3_, final int p_148171_4_) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.sigma.I().zerodayisaminecraftcheat(Gui.n);
            final float f = 0.0078125f;
            final float f2 = 0.0078125f;
            final int i = 18;
            final int j = 18;
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
            worldrenderer.zeroday(p_148171_1_ + 0, p_148171_2_ + 18, (double)GuiFlatPresets.this.p).zerodayisaminecraftcheat((p_148171_3_ + 0) * 0.0078125f, (p_148171_4_ + 18) * 0.0078125f).zues();
            worldrenderer.zeroday(p_148171_1_ + 18, p_148171_2_ + 18, (double)GuiFlatPresets.this.p).zerodayisaminecraftcheat((p_148171_3_ + 18) * 0.0078125f, (p_148171_4_ + 18) * 0.0078125f).zues();
            worldrenderer.zeroday(p_148171_1_ + 18, p_148171_2_ + 0, (double)GuiFlatPresets.this.p).zerodayisaminecraftcheat((p_148171_3_ + 18) * 0.0078125f, (p_148171_4_ + 0) * 0.0078125f).zues();
            worldrenderer.zeroday(p_148171_1_ + 0, p_148171_2_ + 0, (double)GuiFlatPresets.this.p).zerodayisaminecraftcheat((p_148171_3_ + 0) * 0.0078125f, (p_148171_4_ + 0) * 0.0078125f).zues();
            tessellator.zeroday();
        }
        
        @Override
        protected int zerodayisaminecraftcheat() {
            return GuiFlatPresets.zerodayisaminecraftcheat.size();
        }
        
        @Override
        protected void zerodayisaminecraftcheat(final int slotIndex, final boolean isDoubleClick, final int mouseX, final int mouseY) {
            this.zerodayisaminecraftcheat = slotIndex;
            GuiFlatPresets.this.flux();
            GuiFlatPresets.this.momgetthecamera.zerodayisaminecraftcheat(GuiFlatPresets.zerodayisaminecraftcheat.get(GuiFlatPresets.this.flux.zerodayisaminecraftcheat).pandora);
        }
        
        @Override
        protected boolean zerodayisaminecraftcheat(final int slotIndex) {
            return slotIndex == this.zerodayisaminecraftcheat;
        }
        
        @Override
        protected void sigma() {
        }
        
        @Override
        protected void zerodayisaminecraftcheat(final int entryID, final int p_180791_2_, final int p_180791_3_, final int p_180791_4_, final int mouseXIn, final int mouseYIn) {
            final zerodayisaminecraftcheat guiflatpresets$layeritem = GuiFlatPresets.zerodayisaminecraftcheat.get(entryID);
            this.zerodayisaminecraftcheat(p_180791_2_, p_180791_3_, guiflatpresets$layeritem.zerodayisaminecraftcheat, guiflatpresets$layeritem.zeroday);
            GuiFlatPresets.this.C.zerodayisaminecraftcheat(guiflatpresets$layeritem.sigma, p_180791_2_ + 18 + 5, p_180791_3_ + 6, 16777215);
        }
    }
}

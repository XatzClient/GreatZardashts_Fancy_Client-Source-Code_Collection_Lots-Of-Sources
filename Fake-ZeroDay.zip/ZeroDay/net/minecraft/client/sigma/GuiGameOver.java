// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.o.EnumChatFormatting;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.zues.WorldClient;
import java.io.IOException;
import java.util.Iterator;
import net.minecraft.client.b.I18n;

public class GuiGameOver extends GuiScreen implements GuiYesNoCallback
{
    private int zerodayisaminecraftcheat;
    private boolean zeroday;
    
    public GuiGameOver() {
        this.zeroday = false;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.clear();
        if (this.u.a.u().k()) {
            if (this.u.x()) {
                this.y.add(new GuiButton(1, this.w / 2 - 100, this.x / 4 + 96, I18n.zerodayisaminecraftcheat("deathScreen.deleteWorld", new Object[0])));
            }
            else {
                this.y.add(new GuiButton(1, this.w / 2 - 100, this.x / 4 + 96, I18n.zerodayisaminecraftcheat("deathScreen.leaveServer", new Object[0])));
            }
        }
        else {
            this.y.add(new GuiButton(0, this.w / 2 - 100, this.x / 4 + 72, I18n.zerodayisaminecraftcheat("deathScreen.respawn", new Object[0])));
            this.y.add(new GuiButton(1, this.w / 2 - 100, this.x / 4 + 96, I18n.zerodayisaminecraftcheat("deathScreen.titleScreen", new Object[0])));
            if (this.u.E() == null) {
                this.y.get(1).momgetthecamera = false;
            }
        }
        for (final GuiButton guibutton : this.y) {
            guibutton.momgetthecamera = false;
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        switch (button.vape) {
            case 0: {
                this.u.e.f_();
                this.u.zerodayisaminecraftcheat((GuiScreen)null);
                break;
            }
            case 1: {
                if (this.u.a.u().k()) {
                    this.u.zerodayisaminecraftcheat(new GuiMainMenu());
                    break;
                }
                final GuiYesNo guiyesno = new GuiYesNo(this, I18n.zerodayisaminecraftcheat("deathScreen.quit.confirm", new Object[0]), "", I18n.zerodayisaminecraftcheat("deathScreen.titleScreen", new Object[0]), I18n.zerodayisaminecraftcheat("deathScreen.respawn", new Object[0]), 0);
                this.u.zerodayisaminecraftcheat(guiyesno);
                guiyesno.zerodayisaminecraftcheat(20);
                break;
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean result, final int id) {
        if (result) {
            this.u.a.pandora();
            this.u.zerodayisaminecraftcheat((WorldClient)null);
            this.u.zerodayisaminecraftcheat(new GuiMainMenu());
        }
        else {
            this.u.e.f_();
            this.u.zerodayisaminecraftcheat((GuiScreen)null);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.zerodayisaminecraftcheat(0, 0, this.w, this.x, 1615855616, -1602211792);
        GlStateManager.v();
        GlStateManager.zerodayisaminecraftcheat(2.0f, 2.0f, 2.0f);
        final boolean flag = this.u.a.u().k();
        final String s = flag ? I18n.zerodayisaminecraftcheat("deathScreen.title.hardcore", new Object[0]) : I18n.zerodayisaminecraftcheat("deathScreen.title", new Object[0]);
        Gui.zerodayisaminecraftcheat(this.C, s, this.w / 2 / 2, 30, 16777215);
        GlStateManager.w();
        if (flag) {
            Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("deathScreen.hardcoreInfo", new Object[0]), this.w / 2, 144, 16777215);
        }
        Gui.zerodayisaminecraftcheat(this.C, String.valueOf(I18n.zerodayisaminecraftcheat("deathScreen.score", new Object[0])) + ": " + EnumChatFormatting.g + this.u.e.aV(), this.w / 2, 100, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    @Override
    public boolean zues() {
        return false;
    }
    
    @Override
    public void sigma() {
        super.sigma();
        ++this.zerodayisaminecraftcheat;
        if (this.zerodayisaminecraftcheat == 20) {
            for (final GuiButton guibutton : this.y) {
                guibutton.momgetthecamera = true;
            }
        }
    }
}

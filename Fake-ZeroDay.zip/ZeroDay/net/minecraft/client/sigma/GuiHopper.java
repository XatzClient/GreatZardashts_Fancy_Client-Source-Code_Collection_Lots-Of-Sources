// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.EntityRenderer;
import net.minecraft.client.a.OpenGlHelper;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.c;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.b.Container;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.b.ContainerHopper;
import net.minecraft.client.Minecraft;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.b.IInventory;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.sigma.zeroday.GuiContainer;

public class GuiHopper extends GuiContainer
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private IInventory zeroday;
    private IInventory sigma;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/gui/container/hopper.png");
    }
    
    public GuiHopper(final InventoryPlayer playerInv, final IInventory hopperInv) {
        super(new ContainerHopper(playerInv, hopperInv, Minecraft.s().e));
        this.zeroday = playerInv;
        this.sigma = hopperInv;
        this.B = false;
        this.c = 133;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY) {
        this.C.zerodayisaminecraftcheat(this.sigma.sigma().momgetthecamera(), 8, 6, 4210752);
        this.C.zerodayisaminecraftcheat(this.zeroday.sigma().momgetthecamera(), 8, this.c - 96 + 2, 4210752);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final float partialTicks, final int mouseX, final int mouseY) {
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.u.I().zerodayisaminecraftcheat(GuiHopper.zerodayisaminecraftcheat);
        final int i = (this.w - this.b) / 2;
        final int j = (this.x - this.c) / 2;
        this.zeroday(i, j, 0, 0, this.b, this.c);
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        super.zerodayisaminecraftcheat();
        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.c.zerodayisaminecraftcheat && OpenGlHelper.G && this.u.V() instanceof EntityPlayer) {
            if (this.u.m.vape != null) {
                this.u.m.vape.zerodayisaminecraftcheat();
            }
            this.u.m.b = 5;
            if (this.u.m.b != EntityRenderer.a) {
                this.u.m.zerodayisaminecraftcheat(EntityRenderer.momgetthecamera[18]);
            }
        }
    }
}

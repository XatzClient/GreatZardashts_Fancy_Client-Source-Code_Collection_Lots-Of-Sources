// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.o.IChatComponent;
import net.minecraft.client.a.zues.TextureAtlasSprite;
import net.minecraft.client.a.zues.TextureMap;
import net.minecraft.q.zeroday.WorldBorder;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.vape.zeroday.BossStatus;
import net.minecraft.vape.Entity;
import net.minecraft.vape.zerodayisaminecraftcheat.zerodayisaminecraftcheat.IAttributeInstance;
import net.minecraft.o.FoodStats;
import net.minecraft.zerodayisaminecraftcheat.zerodayisaminecraftcheat.Material;
import net.minecraft.vape.SharedMonsterAttributes;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import net.minecraft.j.Team;
import com.google.common.collect.Lists;
import com.google.common.collect.Iterables;
import net.minecraft.j.Score;
import com.google.common.base.Predicate;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.L;
import zeroday.pandora.zerodayisaminecraftcheat.d.av;
import net.minecraft.o.BlockPos;
import net.minecraft.b.IInventory;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.o.StringUtils;
import net.minecraft.client.b.I18n;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.client.a.RenderHelper;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.vape;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.j.ScorePlayerTeam;
import net.minecraft.j.ScoreObjective;
import net.minecraft.j.Scoreboard;
import zeroday.pandora.zerodayisaminecraftcheat.e.flux;
import zeroday.pandora.zerodayisaminecraftcheat.e.momgetthecamera;
import zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat;
import net.minecraft.o.MathHelper;
import net.minecraft.g.Potion;
import net.minecraft.c.Item;
import net.minecraft.a.Blocks;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.vape.EntityLivingBase;
import net.minecraft.client.sigma.zeroday.GuiInventory;
import zeroday.pandora.zerodayisaminecraftcheat.d.x;
import net.minecraft.c.ItemStack;
import net.minecraft.client.a.pandora.RenderItem;
import net.minecraft.client.Minecraft;
import java.util.Random;
import net.minecraft.o.ResourceLocation;

public class GuiIngame extends Gui
{
    private static final ResourceLocation sigma;
    private static final ResourceLocation pandora;
    private static final ResourceLocation zues;
    private final Random flux;
    private final Minecraft vape;
    private final RenderItem momgetthecamera;
    private final GuiNewChat a;
    private final GuiStreamIndicator b;
    private int c;
    private String d;
    private int e;
    private boolean f;
    public float zerodayisaminecraftcheat;
    private int g;
    public static int zeroday;
    private ItemStack h;
    private final GuiOverlayDebug i;
    private final GuiSpectator j;
    private final GuiPlayerTabOverlay k;
    private int l;
    private String q;
    private String r;
    private int s;
    private int t;
    private int u;
    private int v;
    private int w;
    private long x;
    private long y;
    
    static {
        sigma = new ResourceLocation("textures/misc/vignette.png");
        pandora = new ResourceLocation("textures/gui/widgets.png");
        zues = new ResourceLocation("textures/misc/pumpkinblur.png");
    }
    
    public GuiIngame(final Minecraft mcIn) {
        this.flux = new Random();
        this.d = "";
        this.zerodayisaminecraftcheat = 1.0f;
        this.q = "";
        this.r = "";
        this.v = 0;
        this.w = 0;
        this.x = 0L;
        this.y = 0L;
        this.vape = mcIn;
        this.momgetthecamera = mcIn.Z();
        this.i = new GuiOverlayDebug(mcIn);
        this.j = new GuiSpectator(mcIn);
        this.a = new GuiNewChat(mcIn);
        this.b = new GuiStreamIndicator(mcIn);
        this.k = new GuiPlayerTabOverlay(mcIn, this);
        this.zerodayisaminecraftcheat();
    }
    
    public void zerodayisaminecraftcheat() {
        this.s = 10;
        this.t = 70;
        this.u = 20;
    }
    
    public void zerodayisaminecraftcheat(final float partialTicks) {
        final ScaledResolution scaledresolution = new ScaledResolution(this.vape);
        final int i = scaledresolution.zerodayisaminecraftcheat();
        final int j = scaledresolution.zeroday();
        this.vape.m.a();
        if (zeroday.pandora.zerodayisaminecraftcheat.d.x.c) {
            GuiInventory.zerodayisaminecraftcheat(scaledresolution.zerodayisaminecraftcheat() - 30, scaledresolution.zeroday() - 15, 30, 0.0f, 25.0f - this.vape.e.z, this.vape.e);
        }
        GlStateManager.d();
        if (Minecraft.q()) {
            this.zerodayisaminecraftcheat(this.vape.e.zeroday(partialTicks), scaledresolution);
        }
        else {
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        }
        final ItemStack itemstack = this.vape.e.d.sigma(3);
        if (this.vape.r.as == 0 && itemstack != null && itemstack.zerodayisaminecraftcheat() == Item.zerodayisaminecraftcheat(Blocks.aM)) {
            this.zues(scaledresolution);
        }
        if (!this.vape.e.zerodayisaminecraftcheat(Potion.c)) {
            final float f = this.vape.e.c + (this.vape.e.b - this.vape.e.c) * partialTicks;
            if (f > 0.0f) {
                this.zeroday(f, scaledresolution);
            }
        }
        if (this.vape.zues.zerodayisaminecraftcheat()) {
            this.j.zerodayisaminecraftcheat(scaledresolution, partialTicks);
        }
        else {
            this.zerodayisaminecraftcheat(scaledresolution, partialTicks);
        }
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.vape.I().zerodayisaminecraftcheat(GuiIngame.o);
        GlStateManager.d();
        if (this.zeroday()) {
            GlStateManager.zerodayisaminecraftcheat(775, 769, 1, 0);
            GlStateManager.pandora();
            this.zeroday(i / 2 - 7, j / 2 - 7, 0, 0, 16, 16);
        }
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        this.vape.z.zerodayisaminecraftcheat("bossHealth");
        this.b();
        this.vape.z.zeroday();
        if (this.vape.zues.zeroday()) {
            this.pandora(scaledresolution);
        }
        GlStateManager.c();
        if (this.vape.e.bd() > 0) {
            this.vape.z.zerodayisaminecraftcheat("sleep");
            GlStateManager.a();
            GlStateManager.sigma();
            final int j2 = this.vape.e.bd();
            float f2 = j2 / 100.0f;
            if (f2 > 1.0f) {
                f2 = 1.0f - (j2 - 100) / 10.0f;
            }
            final int k = (int)(220.0f * f2) << 24 | 0x101020;
            Gui.zerodayisaminecraftcheat(0, 0, i, j, k);
            GlStateManager.pandora();
            GlStateManager.b();
            this.vape.z.zeroday();
        }
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        final int k2 = i / 2 - 91;
        if (this.vape.e.w()) {
            this.zerodayisaminecraftcheat(scaledresolution, k2);
        }
        else if (this.vape.zues.vape()) {
            this.zeroday(scaledresolution, k2);
        }
        if (this.vape.r.v && !this.vape.zues.zerodayisaminecraftcheat()) {
            this.zerodayisaminecraftcheat(scaledresolution);
        }
        else if (this.vape.e.h_()) {
            this.j.zerodayisaminecraftcheat(scaledresolution);
        }
        if (this.vape.n()) {
            this.zeroday(scaledresolution);
        }
        if (this.vape.r.at) {
            this.i.zerodayisaminecraftcheat(scaledresolution);
        }
        if (this.e > 0) {
            this.vape.z.zerodayisaminecraftcheat("overlayMessage");
            final float f3 = this.e - partialTicks;
            int l1 = (int)(f3 * 255.0f / 20.0f);
            if (l1 > 255) {
                l1 = 255;
            }
            if (l1 > 8) {
                GlStateManager.v();
                GlStateManager.zeroday((float)(i / 2), (float)(j - 68), 0.0f);
                GlStateManager.d();
                GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
                int m = 16777215;
                if (this.f) {
                    m = (MathHelper.sigma(f3 / 50.0f, 0.7f, 0.6f) & 0xFFFFFF);
                }
                this.flux().zerodayisaminecraftcheat(this.d, -this.flux().zerodayisaminecraftcheat(this.d) / 2, -4, m + (l1 << 24 & 0xFF000000));
                GlStateManager.c();
                GlStateManager.w();
            }
            this.vape.z.zeroday();
        }
        if (this.l > 0) {
            this.vape.z.zerodayisaminecraftcheat("titleAndSubtitle");
            final float f4 = this.l - partialTicks;
            int i2 = 255;
            if (this.l > this.u + this.t) {
                final float f5 = this.s + this.t + this.u - f4;
                i2 = (int)(f5 * 255.0f / this.s);
            }
            if (this.l <= this.u) {
                i2 = (int)(f4 * 255.0f / this.u);
            }
            i2 = MathHelper.zerodayisaminecraftcheat(i2, 0, 255);
            if (i2 > 8) {
                GlStateManager.v();
                GlStateManager.zeroday((float)(i / 2), (float)(j / 2), 0.0f);
                GlStateManager.d();
                GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
                GlStateManager.v();
                GlStateManager.zerodayisaminecraftcheat(4.0f, 4.0f, 4.0f);
                final int j3 = i2 << 24 & 0xFF000000;
                this.flux().zerodayisaminecraftcheat(this.q, (float)(-this.flux().zerodayisaminecraftcheat(this.q) / 2), -10.0f, 0xFFFFFF | j3, true);
                GlStateManager.w();
                GlStateManager.v();
                GlStateManager.zerodayisaminecraftcheat(2.0f, 2.0f, 2.0f);
                this.flux().zerodayisaminecraftcheat(this.r, (float)(-this.flux().zerodayisaminecraftcheat(this.r) / 2), 5.0f, 0xFFFFFF | j3, true);
                GlStateManager.w();
                GlStateManager.c();
                GlStateManager.w();
            }
            this.vape.z.zeroday();
        }
        final Scoreboard scoreboard = this.vape.a.E();
        ScoreObjective scoreobjective = null;
        final ScorePlayerTeam scoreplayerteam = scoreboard.flux(this.vape.e.l_());
        if (scoreplayerteam != null) {
            final int i3 = scoreplayerteam.c().zerodayisaminecraftcheat();
            if (i3 >= 0) {
                scoreobjective = scoreboard.zerodayisaminecraftcheat(3 + i3);
            }
        }
        ScoreObjective scoreobjective2 = (scoreobjective != null) ? scoreobjective : scoreboard.zerodayisaminecraftcheat(1);
        if (scoreobjective2 != null) {
            this.zerodayisaminecraftcheat(scoreobjective2, scaledresolution);
        }
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.sigma();
        GlStateManager.v();
        GlStateManager.zeroday(0.0f, (float)(j - 48), 0.0f);
        this.vape.z.zerodayisaminecraftcheat("chat");
        this.a.zerodayisaminecraftcheat(this.c);
        this.vape.z.zeroday();
        GlStateManager.w();
        scoreobjective2 = scoreboard.zerodayisaminecraftcheat(0);
        if (!this.vape.r.ac.pandora() || (this.vape.x() && this.vape.e.zerodayisaminecraftcheat.sigma().size() <= 1 && scoreobjective2 == null)) {
            this.k.zerodayisaminecraftcheat(false);
        }
        else {
            this.k.zerodayisaminecraftcheat(true);
            this.k.zerodayisaminecraftcheat(i, scoreboard, scoreobjective2);
        }
        zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.vape().a();
        final ScaledResolution sr = new ScaledResolution(this.vape);
        if (zeroday.pandora.zerodayisaminecraftcheat.e.momgetthecamera.zeroday) {
            Gui.zerodayisaminecraftcheat(0, 0, zeroday.pandora.zerodayisaminecraftcheat.e.flux.flux ? (178 + zeroday.pandora.zerodayisaminecraftcheat.e.flux.pandora - zeroday.pandora.zerodayisaminecraftcheat.e.flux.sigma) : (zeroday.pandora.zerodayisaminecraftcheat.e.flux.flux ? 90 : (90 - zeroday.pandora.zerodayisaminecraftcheat.e.momgetthecamera.sigma)), sr.zeroday(), -12566464);
        }
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.flux();
        GlStateManager.pandora();
    }
    
    protected void zerodayisaminecraftcheat(final ScaledResolution sr, final float partialTicks) {
        if (this.vape.V() instanceof EntityPlayer) {
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.vape.I().zerodayisaminecraftcheat(GuiIngame.pandora);
            final EntityPlayer entityplayer = (EntityPlayer)this.vape.V();
            final int i = sr.zerodayisaminecraftcheat() / 2;
            final float f = this.p;
            this.p = -90.0f;
            if (zeroday.pandora.zerodayisaminecraftcheat.pandora.vape.zeroday) {
                Gui.zerodayisaminecraftcheat(0, sr.zeroday() - 22, sr.zerodayisaminecraftcheat(), sr.zeroday(), -1879048192);
                final int left = i - 91 + entityplayer.d.sigma * 20 + 22;
                final int right = i - 91 + Minecraft.c * 20 + 22;
                if (Minecraft.pandora) {
                    GuiIngame.zeroday += right - left;
                    Minecraft.pandora = false;
                }
                Gui.zerodayisaminecraftcheat(i - 91 + entityplayer.d.sigma * 20 + 22 + GuiIngame.zeroday, sr.zeroday() - 22, i - 91 + entityplayer.d.sigma * 20 + GuiIngame.zeroday, sr.zeroday(), -1426063361);
                if (GuiIngame.zeroday > 0) {
                    --GuiIngame.zeroday;
                }
                if (GuiIngame.zeroday < 0) {
                    ++GuiIngame.zeroday;
                }
                if (Minecraft.ab() < 90) {
                    if (GuiIngame.zeroday > 0) {
                        --GuiIngame.zeroday;
                    }
                    if (GuiIngame.zeroday < 0) {
                        ++GuiIngame.zeroday;
                    }
                }
                if (Minecraft.ab() < 45) {
                    if (GuiIngame.zeroday > 0) {
                        --GuiIngame.zeroday;
                    }
                    if (GuiIngame.zeroday < 0) {
                        ++GuiIngame.zeroday;
                    }
                }
                if (Minecraft.ab() < 25) {
                    if (GuiIngame.zeroday > 0) {
                        --GuiIngame.zeroday;
                    }
                    if (GuiIngame.zeroday < 0) {
                        ++GuiIngame.zeroday;
                    }
                }
            }
            else {
                this.zeroday(i - 91, sr.zeroday() - 22, 0, 0, 182, 22);
                this.zeroday(i - 91 - 1 + entityplayer.d.sigma * 20, sr.zeroday() - 22 - 1, 0, 22, 24, 22);
            }
            this.p = f;
            GlStateManager.s();
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            RenderHelper.sigma();
            for (int j = 0; j < 9; ++j) {
                final int k = sr.zerodayisaminecraftcheat() / 2 - 90 + j * 20 + 2;
                final int l = sr.zeroday() - 16 - 3;
                this.zerodayisaminecraftcheat(j, k, l, partialTicks, entityplayer);
            }
            RenderHelper.zerodayisaminecraftcheat();
            GlStateManager.t();
            GlStateManager.c();
        }
    }
    
    public void zerodayisaminecraftcheat(final ScaledResolution p_175186_1_, final int p_175186_2_) {
        this.vape.z.zerodayisaminecraftcheat("jumpBar");
        this.vape.I().zerodayisaminecraftcheat(Gui.o);
        final float f = this.vape.e.x();
        final int i = 182;
        final int j = (int)(f * (i + 1));
        final int k = p_175186_1_.zeroday() - 32 + 3;
        this.zeroday(p_175186_2_, k, 0, 84, i, 5);
        if (j > 0) {
            this.zeroday(p_175186_2_, k, 0, 89, j, 5);
        }
        this.vape.z.zeroday();
    }
    
    public void zeroday(final ScaledResolution p_175176_1_, final int p_175176_2_) {
        this.vape.z.zerodayisaminecraftcheat("expBar");
        this.vape.I().zerodayisaminecraftcheat(Gui.o);
        final int i = this.vape.e.bh();
        if (i > 0) {
            final int j = 182;
            final int k = (int)(this.vape.e.bC * (j + 1));
            final int l = p_175176_1_.zeroday() - 32 + 3;
            this.zeroday(p_175176_2_, l, 0, 64, j, 5);
            if (k > 0) {
                this.zeroday(p_175176_2_, l, 0, 69, k, 5);
            }
        }
        this.vape.z.zeroday();
        if (this.vape.e.bA > 0) {
            this.vape.z.zerodayisaminecraftcheat("expLevel");
            final int k2 = 8453920;
            final String s = new StringBuilder().append(this.vape.e.bA).toString();
            final int l2 = (p_175176_1_.zerodayisaminecraftcheat() - this.flux().zerodayisaminecraftcheat(s)) / 2;
            final int i2 = p_175176_1_.zeroday() - 31 - 4;
            final int j2 = 0;
            this.flux().zerodayisaminecraftcheat(s, l2 + 1, i2, 0);
            this.flux().zerodayisaminecraftcheat(s, l2 - 1, i2, 0);
            this.flux().zerodayisaminecraftcheat(s, l2, i2 + 1, 0);
            this.flux().zerodayisaminecraftcheat(s, l2, i2 - 1, 0);
            this.flux().zerodayisaminecraftcheat(s, l2, i2, k2);
            this.vape.z.zeroday();
        }
    }
    
    public void zerodayisaminecraftcheat(final ScaledResolution p_181551_1_) {
        this.vape.z.zerodayisaminecraftcheat("selectedItemName");
        if (this.g > 0 && this.h != null) {
            String s = this.h.i();
            if (this.h.k()) {
                s = EnumChatFormatting.m + s;
            }
            final int i = (p_181551_1_.zerodayisaminecraftcheat() - this.flux().zerodayisaminecraftcheat(s)) / 2;
            int j = p_181551_1_.zeroday() - 59;
            if (!this.vape.zues.zeroday()) {
                j += 14;
            }
            int k = (int)(this.g * 256.0f / 10.0f);
            if (k > 255) {
                k = 255;
            }
            if (k > 0) {
                GlStateManager.v();
                GlStateManager.d();
                GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
                this.flux().zerodayisaminecraftcheat(s, (float)i, (float)j, 16777215 + (k << 24));
                GlStateManager.c();
                GlStateManager.w();
            }
        }
        this.vape.z.zeroday();
    }
    
    public void zeroday(final ScaledResolution p_175185_1_) {
        this.vape.z.zerodayisaminecraftcheat("demo");
        String s = "";
        if (this.vape.a.p() >= 120500L) {
            s = I18n.zerodayisaminecraftcheat("demo.demoExpired", new Object[0]);
        }
        else {
            s = I18n.zerodayisaminecraftcheat("demo.remainingTime", StringUtils.zerodayisaminecraftcheat((int)(120500L - this.vape.a.p())));
        }
        final int i = this.flux().zerodayisaminecraftcheat(s);
        this.flux().zerodayisaminecraftcheat(s, (float)(p_175185_1_.zerodayisaminecraftcheat() - i - 10), 5.0f, 16777215);
        this.vape.z.zeroday();
    }
    
    protected boolean zeroday() {
        if (this.vape.r.at && !this.vape.e.cf() && !this.vape.r.o) {
            return false;
        }
        if (!this.vape.zues.zerodayisaminecraftcheat()) {
            return true;
        }
        if (this.vape.f != null) {
            return true;
        }
        if (this.vape.q != null && this.vape.q.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday) {
            final BlockPos blockpos = this.vape.q.zerodayisaminecraftcheat();
            if (this.vape.a.zerodayisaminecraftcheat(blockpos) instanceof IInventory) {
                return true;
            }
        }
        return false;
    }
    
    public void sigma(final ScaledResolution p_180478_1_) {
        this.b.zerodayisaminecraftcheat(p_180478_1_.zerodayisaminecraftcheat() - 10, 10);
    }
    
    private void zerodayisaminecraftcheat(final ScoreObjective p_180475_1_, final ScaledResolution p_180475_2_) {
        if (av.c && !L.sigma) {
            return;
        }
        final Scoreboard scoreboard = p_180475_1_.zerodayisaminecraftcheat();
        Collection<Score> collection = scoreboard.zerodayisaminecraftcheat(p_180475_1_);
        final List<Score> list = (List<Score>)Lists.newArrayList(Iterables.filter((Iterable)collection, (Predicate)new Predicate<Score>() {
            public boolean zerodayisaminecraftcheat(final Score p_apply_1_) {
                return p_apply_1_.pandora() != null && !p_apply_1_.pandora().startsWith("#");
            }
        }));
        if (list.size() > 15) {
            collection = (Collection<Score>)Lists.newArrayList(Iterables.skip((Iterable)list, collection.size() - 15));
        }
        else {
            collection = list;
        }
        int i = this.flux().zerodayisaminecraftcheat(p_180475_1_.pandora());
        for (final Score score : collection) {
            final ScorePlayerTeam scoreplayerteam = scoreboard.flux(score.pandora());
            final String s = String.valueOf(ScorePlayerTeam.zerodayisaminecraftcheat(scoreplayerteam, score.pandora())) + ": " + EnumChatFormatting.e + score.zeroday();
            i = Math.max(i, this.flux().zerodayisaminecraftcheat(s));
        }
        final int i2 = collection.size() * this.flux().zeroday;
        final int j1 = p_180475_2_.zeroday() / 2 + i2 / 3;
        final int k1 = 3;
        final int l1 = p_180475_2_.zerodayisaminecraftcheat() - i - k1;
        int m = 0;
        for (final Score score2 : collection) {
            ++m;
            final ScorePlayerTeam scoreplayerteam2 = scoreboard.flux(score2.pandora());
            final String s2 = ScorePlayerTeam.zerodayisaminecraftcheat(scoreplayerteam2, score2.pandora());
            final String s3 = new StringBuilder().append(EnumChatFormatting.e).append(score2.zeroday()).toString();
            final int k2 = j1 - m * this.flux().zeroday;
            final int l2 = p_180475_2_.zerodayisaminecraftcheat() - k1 + 2;
            Gui.zerodayisaminecraftcheat(l1 - 2, k2, l2, k2 + this.flux().zeroday, 1342177280);
            this.flux().zerodayisaminecraftcheat(s2, l1, k2, 553648127);
            this.flux().zerodayisaminecraftcheat(s3, l2 - this.flux().zerodayisaminecraftcheat(s3), k2, 553648127);
            if (m == collection.size()) {
                final String s4 = p_180475_1_.pandora();
                Gui.zerodayisaminecraftcheat(l1 - 2, k2 - this.flux().zeroday - 1, l2, k2 - 1, 1610612736);
                Gui.zerodayisaminecraftcheat(l1 - 2, k2 - 1, l2, k2, 1342177280);
                this.flux().zerodayisaminecraftcheat(s4, l1 + i / 2 - this.flux().zerodayisaminecraftcheat(s4) / 2, k2 - this.flux().zeroday, 553648127);
            }
        }
    }
    
    private void pandora(final ScaledResolution p_180477_1_) {
        if (this.vape.V() instanceof EntityPlayer) {
            final EntityPlayer entityplayer = (EntityPlayer)this.vape.V();
            final int i = MathHelper.flux(entityplayer.by());
            final boolean flag = this.y > this.c && (this.y - this.c) / 3L % 2L == 1L;
            if (i < this.v && entityplayer.aa > 0) {
                this.x = Minecraft.C();
                this.y = this.c + 20;
            }
            else if (i > this.v && entityplayer.aa > 0) {
                this.x = Minecraft.C();
                this.y = this.c + 10;
            }
            if (Minecraft.C() - this.x > 1000L) {
                this.v = i;
                this.w = i;
                this.x = Minecraft.C();
            }
            this.v = i;
            final int j = this.w;
            this.flux.setSeed(this.c * 312871);
            final boolean flag2 = false;
            final FoodStats foodstats = entityplayer.ca();
            final int k = foodstats.zerodayisaminecraftcheat();
            final int l = foodstats.zeroday();
            final IAttributeInstance iattributeinstance = entityplayer.zerodayisaminecraftcheat(SharedMonsterAttributes.zerodayisaminecraftcheat);
            final int i2 = p_180477_1_.zerodayisaminecraftcheat() / 2 - 91;
            final int j2 = p_180477_1_.zerodayisaminecraftcheat() / 2 + 91;
            final int k2 = p_180477_1_.zeroday() - 39;
            final float f = (float)iattributeinstance.zues();
            final float f2 = entityplayer.bV();
            final int l2 = MathHelper.flux((f + f2) / 2.0f / 10.0f);
            final int i3 = Math.max(10 - (l2 - 2), 3);
            final int j3 = k2 - (l2 - 1) * i3 - 10;
            float f3 = f2;
            final int k3 = entityplayer.bC();
            int l3 = -1;
            if (entityplayer.zerodayisaminecraftcheat(Potion.d)) {
                l3 = this.c % MathHelper.flux(f + 5.0f);
            }
            this.vape.z.zerodayisaminecraftcheat("armor");
            for (int i4 = 0; i4 < 10; ++i4) {
                if (k3 > 0) {
                    final int j4 = i2 + i4 * 8;
                    if (i4 * 2 + 1 < k3) {
                        this.zeroday(j4, j3, 34, 9, 9, 9);
                    }
                    if (i4 * 2 + 1 == k3) {
                        this.zeroday(j4, j3, 25, 9, 9, 9);
                    }
                    if (i4 * 2 + 1 > k3) {
                        this.zeroday(j4, j3, 16, 9, 9, 9);
                    }
                }
            }
            this.vape.z.sigma("health");
            for (int i5 = MathHelper.flux((f + f2) / 2.0f) - 1; i5 >= 0; --i5) {
                int j5 = 16;
                if (entityplayer.zerodayisaminecraftcheat(Potion.m)) {
                    j5 += 36;
                }
                else if (entityplayer.zerodayisaminecraftcheat(Potion.n)) {
                    j5 += 72;
                }
                int k4 = 0;
                if (flag) {
                    k4 = 1;
                }
                final int l4 = MathHelper.flux((i5 + 1) / 10.0f) - 1;
                final int i6 = i2 + i5 % 10 * 8;
                int j6 = k2 - l4 * i3;
                if (i <= 4) {
                    j6 += this.flux.nextInt(2);
                }
                if (i5 == l3) {
                    j6 -= 2;
                }
                int k5 = 0;
                if (entityplayer.o.u().k()) {
                    k5 = 5;
                }
                this.zeroday(i6, j6, 16 + k4 * 9, 9 * k5, 9, 9);
                if (flag) {
                    if (i5 * 2 + 1 < j) {
                        this.zeroday(i6, j6, j5 + 54, 9 * k5, 9, 9);
                    }
                    if (i5 * 2 + 1 == j) {
                        this.zeroday(i6, j6, j5 + 63, 9 * k5, 9, 9);
                    }
                }
                if (f3 > 0.0f) {
                    if (f3 == f2 && f2 % 2.0f == 1.0f) {
                        this.zeroday(i6, j6, j5 + 153, 9 * k5, 9, 9);
                    }
                    else {
                        this.zeroday(i6, j6, j5 + 144, 9 * k5, 9, 9);
                    }
                    f3 -= 2.0f;
                }
                else {
                    if (i5 * 2 + 1 < i) {
                        this.zeroday(i6, j6, j5 + 36, 9 * k5, 9, 9);
                    }
                    if (i5 * 2 + 1 == i) {
                        this.zeroday(i6, j6, j5 + 45, 9 * k5, 9, 9);
                    }
                }
            }
            final Entity entity = entityplayer.m;
            if (entity == null) {
                this.vape.z.sigma("food");
                for (int k6 = 0; k6 < 10; ++k6) {
                    int i7 = k2;
                    int l5 = 16;
                    int j7 = 0;
                    if (entityplayer.zerodayisaminecraftcheat(Potion.k)) {
                        l5 += 36;
                        j7 = 13;
                    }
                    if (entityplayer.ca().pandora() <= 0.0f && this.c % (k * 3 + 1) == 0) {
                        i7 = k2 + (this.flux.nextInt(3) - 1);
                    }
                    if (flag2) {
                        j7 = 1;
                    }
                    final int i8 = j2 - k6 * 8 - 9;
                    this.zeroday(i8, i7, 16 + j7 * 9, 27, 9, 9);
                    if (flag2) {
                        if (k6 * 2 + 1 < l) {
                            this.zeroday(i8, i7, l5 + 54, 27, 9, 9);
                        }
                        if (k6 * 2 + 1 == l) {
                            this.zeroday(i8, i7, l5 + 63, 27, 9, 9);
                        }
                    }
                    if (k6 * 2 + 1 < k) {
                        this.zeroday(i8, i7, l5 + 36, 27, 9, 9);
                    }
                    if (k6 * 2 + 1 == k) {
                        this.zeroday(i8, i7, l5 + 45, 27, 9, 9);
                    }
                }
            }
            else if (entity instanceof EntityLivingBase) {
                this.vape.z.sigma("mountHealth");
                final EntityLivingBase entitylivingbase = (EntityLivingBase)entity;
                final int j8 = (int)Math.ceil(entitylivingbase.by());
                final float f4 = entitylivingbase.bF();
                int k7 = (int)(f4 + 0.5f) / 2;
                if (k7 > 30) {
                    k7 = 30;
                }
                int j9 = k2;
                int k8 = 0;
                while (k7 > 0) {
                    final int l6 = Math.min(k7, 10);
                    k7 -= l6;
                    for (int i9 = 0; i9 < l6; ++i9) {
                        final int j10 = 52;
                        int k9 = 0;
                        if (flag2) {
                            k9 = 1;
                        }
                        final int l7 = j2 - i9 * 8 - 9;
                        this.zeroday(l7, j9, j10 + k9 * 9, 9, 9, 9);
                        if (i9 * 2 + 1 + k8 < j8) {
                            this.zeroday(l7, j9, j10 + 36, 9, 9, 9);
                        }
                        if (i9 * 2 + 1 + k8 == j8) {
                            this.zeroday(l7, j9, j10 + 45, 9, 9, 9);
                        }
                    }
                    j9 -= 10;
                    k8 += 20;
                }
            }
            this.vape.z.sigma("air");
            if (entityplayer.zerodayisaminecraftcheat(Material.momgetthecamera)) {
                final int l8 = this.vape.e.ar();
                for (int k10 = MathHelper.flux((l8 - 2) * 10.0 / 300.0), i10 = MathHelper.flux(l8 * 10.0 / 300.0) - k10, l9 = 0; l9 < k10 + i10; ++l9) {
                    if (l9 < k10) {
                        this.zeroday(j2 - l9 * 8 - 9, j3, 16, 18, 9, 9);
                    }
                    else {
                        this.zeroday(j2 - l9 * 8 - 9, j3, 25, 18, 9, 9);
                    }
                }
            }
            this.vape.z.zeroday();
        }
    }
    
    private void b() {
        if (BossStatus.sigma != null && BossStatus.zeroday > 0) {
            --BossStatus.zeroday;
            final FontRenderer fontrenderer = this.vape.i;
            final ScaledResolution scaledresolution = new ScaledResolution(this.vape);
            final int i = scaledresolution.zerodayisaminecraftcheat();
            final int j = 182;
            final int k = i / 2 - j / 2;
            final int l = (int)(BossStatus.zerodayisaminecraftcheat * (j + 1));
            final int i2 = 12;
            this.zeroday(k, i2, 0, 74, j, 5);
            this.zeroday(k, i2, 0, 74, j, 5);
            if (l > 0) {
                this.zeroday(k, i2, 0, 79, l, 5);
            }
            final String s = BossStatus.sigma;
            this.flux().zerodayisaminecraftcheat(s, (float)(i / 2 - this.flux().zerodayisaminecraftcheat(s) / 2), (float)(i2 - 10), 16777215);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.vape.I().zerodayisaminecraftcheat(GuiIngame.o);
        }
    }
    
    private void zues(final ScaledResolution p_180476_1_) {
        GlStateManager.a();
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.sigma();
        this.vape.I().zerodayisaminecraftcheat(GuiIngame.zues);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(0.0, p_180476_1_.zeroday(), -90.0).zerodayisaminecraftcheat(0.0, 1.0).zues();
        worldrenderer.zeroday(p_180476_1_.zerodayisaminecraftcheat(), p_180476_1_.zeroday(), -90.0).zerodayisaminecraftcheat(1.0, 1.0).zues();
        worldrenderer.zeroday(p_180476_1_.zerodayisaminecraftcheat(), 0.0, -90.0).zerodayisaminecraftcheat(1.0, 0.0).zues();
        worldrenderer.zeroday(0.0, 0.0, -90.0).zerodayisaminecraftcheat(0.0, 0.0).zues();
        tessellator.zeroday();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.b();
        GlStateManager.pandora();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    private void zerodayisaminecraftcheat(float p_180480_1_, final ScaledResolution p_180480_2_) {
        p_180480_1_ = 1.0f - p_180480_1_;
        p_180480_1_ = MathHelper.zerodayisaminecraftcheat(p_180480_1_, 0.0f, 1.0f);
        final WorldBorder worldborder = this.vape.a.K();
        float f = (float)worldborder.zerodayisaminecraftcheat(this.vape.e);
        final double d0 = Math.min(worldborder.g() * worldborder.h() * 1000.0, Math.abs(worldborder.b() - worldborder.momgetthecamera()));
        final double d2 = Math.max(worldborder.i(), d0);
        if (f < d2) {
            f = 1.0f - (float)(f / d2);
        }
        else {
            f = 0.0f;
        }
        this.zerodayisaminecraftcheat += (float)((p_180480_1_ - this.zerodayisaminecraftcheat) * 0.01);
        GlStateManager.a();
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.zerodayisaminecraftcheat(0, 769, 1, 0);
        if (f > 0.0f) {
            GlStateManager.sigma(0.0f, f, f, 1.0f);
        }
        else {
            GlStateManager.sigma(this.zerodayisaminecraftcheat, this.zerodayisaminecraftcheat, this.zerodayisaminecraftcheat, 1.0f);
        }
        this.vape.I().zerodayisaminecraftcheat(GuiIngame.sigma);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(0.0, p_180480_2_.zeroday(), -90.0).zerodayisaminecraftcheat(0.0, 1.0).zues();
        worldrenderer.zeroday(p_180480_2_.zerodayisaminecraftcheat(), p_180480_2_.zeroday(), -90.0).zerodayisaminecraftcheat(1.0, 1.0).zues();
        worldrenderer.zeroday(p_180480_2_.zerodayisaminecraftcheat(), 0.0, -90.0).zerodayisaminecraftcheat(1.0, 0.0).zues();
        worldrenderer.zeroday(0.0, 0.0, -90.0).zerodayisaminecraftcheat(0.0, 0.0).zues();
        tessellator.zeroday();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.b();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
    }
    
    private void zeroday(float p_180474_1_, final ScaledResolution p_180474_2_) {
        if (p_180474_1_ < 1.0f) {
            p_180474_1_ *= p_180474_1_;
            p_180474_1_ *= p_180474_1_;
            p_180474_1_ = p_180474_1_ * 0.8f + 0.2f;
        }
        GlStateManager.sigma();
        GlStateManager.a();
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, p_180474_1_);
        this.vape.I().zerodayisaminecraftcheat(TextureMap.zeroday);
        final TextureAtlasSprite textureatlassprite = this.vape.X().zerodayisaminecraftcheat().zerodayisaminecraftcheat(Blocks.aQ.G());
        final float f = textureatlassprite.zues();
        final float f2 = textureatlassprite.vape();
        final float f3 = textureatlassprite.flux();
        final float f4 = textureatlassprite.momgetthecamera();
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.vape);
        worldrenderer.zeroday(0.0, p_180474_2_.zeroday(), -90.0).zerodayisaminecraftcheat(f, f4).zues();
        worldrenderer.zeroday(p_180474_2_.zerodayisaminecraftcheat(), p_180474_2_.zeroday(), -90.0).zerodayisaminecraftcheat(f3, f4).zues();
        worldrenderer.zeroday(p_180474_2_.zerodayisaminecraftcheat(), 0.0, -90.0).zerodayisaminecraftcheat(f3, f2).zues();
        worldrenderer.zeroday(0.0, 0.0, -90.0).zerodayisaminecraftcheat(f, f2).zues();
        tessellator.zeroday();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.b();
        GlStateManager.pandora();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    private void zerodayisaminecraftcheat(final int index, final int xPos, final int yPos, final float partialTicks, final EntityPlayer p_175184_5_) {
        final ItemStack itemstack = p_175184_5_.d.zerodayisaminecraftcheat[index];
        if (itemstack != null) {
            final float f = itemstack.sigma - partialTicks;
            if (f > 0.0f) {
                GlStateManager.v();
                final float f2 = 1.0f + f / 5.0f;
                GlStateManager.zeroday((float)(xPos + 8), (float)(yPos + 12), 0.0f);
                GlStateManager.zerodayisaminecraftcheat(1.0f / f2, (f2 + 1.0f) / 2.0f, 1.0f);
                GlStateManager.zeroday((float)(-(xPos + 8)), (float)(-(yPos + 12)), 0.0f);
            }
            this.momgetthecamera.zeroday(itemstack, xPos, yPos);
            if (f > 0.0f) {
                GlStateManager.w();
            }
            this.momgetthecamera.zerodayisaminecraftcheat(this.vape.i, itemstack, xPos, yPos);
        }
    }
    
    public void sigma() {
        if (this.e > 0) {
            --this.e;
        }
        if (this.l > 0) {
            --this.l;
            if (this.l <= 0) {
                this.q = "";
                this.r = "";
            }
        }
        ++this.c;
        this.b.zerodayisaminecraftcheat();
        if (this.vape.e != null) {
            final ItemStack itemstack = this.vape.e.d.pandora();
            if (itemstack == null) {
                this.g = 0;
            }
            else if (this.h != null && itemstack.zerodayisaminecraftcheat() == this.h.zerodayisaminecraftcheat() && ItemStack.zerodayisaminecraftcheat(itemstack, this.h) && (itemstack.pandora() || itemstack.momgetthecamera() == this.h.momgetthecamera())) {
                if (this.g > 0) {
                    --this.g;
                }
            }
            else {
                this.g = 40;
            }
            this.h = itemstack;
        }
    }
    
    public void zerodayisaminecraftcheat(final String p_73833_1_) {
        this.zerodayisaminecraftcheat(I18n.zerodayisaminecraftcheat("record.nowPlaying", p_73833_1_), true);
    }
    
    public void zerodayisaminecraftcheat(final String p_110326_1_, final boolean p_110326_2_) {
        this.d = p_110326_1_;
        this.e = 60;
        this.f = p_110326_2_;
    }
    
    public void zerodayisaminecraftcheat(final String p_175178_1_, final String p_175178_2_, final int p_175178_3_, final int p_175178_4_, final int p_175178_5_) {
        if (p_175178_1_ == null && p_175178_2_ == null && p_175178_3_ < 0 && p_175178_4_ < 0 && p_175178_5_ < 0) {
            this.q = "";
            this.r = "";
            this.l = 0;
        }
        else if (p_175178_1_ != null) {
            this.q = p_175178_1_;
            this.l = this.s + this.t + this.u;
        }
        else if (p_175178_2_ != null) {
            this.r = p_175178_2_;
        }
        else {
            if (p_175178_3_ >= 0) {
                this.s = p_175178_3_;
            }
            if (p_175178_4_ >= 0) {
                this.t = p_175178_4_;
            }
            if (p_175178_5_ >= 0) {
                this.u = p_175178_5_;
            }
            if (this.l > 0) {
                this.l = this.s + this.t + this.u;
            }
        }
    }
    
    public void zerodayisaminecraftcheat(final IChatComponent p_175188_1_, final boolean p_175188_2_) {
        this.zerodayisaminecraftcheat(p_175188_1_.momgetthecamera(), p_175188_2_);
    }
    
    public GuiNewChat pandora() {
        return this.a;
    }
    
    public int zues() {
        return this.c;
    }
    
    public FontRenderer flux() {
        return this.vape.i;
    }
    
    public GuiSpectator vape() {
        return this.j;
    }
    
    public GuiPlayerTabOverlay momgetthecamera() {
        return this.k;
    }
    
    public void a() {
        this.k.zeroday();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import zeroday.pandora.zerodayisaminecraftcheat.d.aR;
import net.minecraft.client.sigma.zerodayisaminecraftcheat.GuiStats;
import net.minecraft.client.sigma.zerodayisaminecraftcheat.GuiAchievements;
import net.minecraft.i.RealmsBridge;
import net.minecraft.client.zues.WorldClient;
import java.util.List;
import pandora.b;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.V;
import net.minecraft.client.b.I18n;
import zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday;
import zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat;

public class GuiIngameMenu extends GuiScreen
{
    private int zues;
    private int flux;
    int zerodayisaminecraftcheat;
    GuiButton zeroday;
    public static boolean sigma;
    public static String pandora;
    
    static {
        GuiIngameMenu.sigma = false;
        GuiIngameMenu.pandora = "";
    }
    
    public GuiIngameMenu() {
        this.zerodayisaminecraftcheat = 0;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.zeroday();
        zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
        this.zues = 0;
        this.y.clear();
        final int i = -16;
        final int j = 98;
        this.y.add(new GuiButton(1, this.w / 2 - 100, this.x / 4 + 120 + i, I18n.zerodayisaminecraftcheat("menu.returnToMenu", new Object[0])));
        if (!this.u.x()) {
            this.y.get(0).flux = I18n.zerodayisaminecraftcheat("menu.disconnect", new Object[0]);
        }
        this.y.add(new GuiButton(4, this.w / 2 - 100, this.x / 4 + 24 + i, I18n.zerodayisaminecraftcheat("menu.returnToGame", new Object[0])));
        this.y.add(new GuiButton(0, this.w / 2 - 100, this.x / 4 + 96 + i, 98, 20, I18n.zerodayisaminecraftcheat("menu.options", new Object[0])));
        final GuiButton guibutton;
        this.y.add(guibutton = new GuiButton(7, this.w / 2 + 2, this.x / 4 + 96 + i, 98, 20, I18n.zerodayisaminecraftcheat("menu.shareToLan", new Object[0])));
        this.y.add(new GuiButton(5, this.w / 2 - 100, this.x / 4 + 48 + i, 98, 20, I18n.zerodayisaminecraftcheat("gui.achievements", new Object[0])));
        this.y.add(new GuiButton(6, this.w / 2 + 2, this.x / 4 + 48 + i, 98, 20, I18n.zerodayisaminecraftcheat("gui.stats", new Object[0])));
        if (!V.zerodayisaminecraftcheat) {
            b.zerodayisaminecraftcheat(this, this.y);
            this.y.add(new GuiButton(9, this.w / 2 - 100, this.x / 4 + 144 + i, I18n.zerodayisaminecraftcheat("Disconnect with Multi-Server Exploit", new Object[0])));
        }
        guibutton.momgetthecamera = (this.u.y() && !this.u.z().aA());
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        b.zerodayisaminecraftcheat(this, button);
        Label_0200: {
            switch (button.vape) {
                case 0: {
                    this.u.zerodayisaminecraftcheat(new GuiOptions(this, this.u.r));
                    break;
                }
                case 1: {
                    final boolean flag = this.u.x();
                    final boolean flag2 = this.u.ae();
                    button.momgetthecamera = false;
                    GuiIngameMenu.pandora = "";
                    GuiIngameMenu.sigma = false;
                    this.u.a.pandora();
                    this.u.zerodayisaminecraftcheat((WorldClient)null);
                    if (flag) {
                        this.u.zerodayisaminecraftcheat(new GuiMainMenu());
                        break Label_0200;
                    }
                    if (flag2) {
                        final RealmsBridge realmsbridge = new RealmsBridge();
                        realmsbridge.zerodayisaminecraftcheat(new GuiMainMenu());
                        break Label_0200;
                    }
                    this.u.zerodayisaminecraftcheat(new GuiMainMenu());
                    break Label_0200;
                }
                case 9: {
                    final boolean flag3 = this.u.x();
                    final boolean flag4 = this.u.ae();
                    button.momgetthecamera = false;
                    GuiIngameMenu.sigma = true;
                    this.u.zerodayisaminecraftcheat((WorldClient)null);
                    if (flag3) {
                        this.u.zerodayisaminecraftcheat(new GuiMainMenu());
                        break;
                    }
                    if (flag4) {
                        final RealmsBridge realmsbridge2 = new RealmsBridge();
                        realmsbridge2.zerodayisaminecraftcheat(new GuiMainMenu());
                        break;
                    }
                    this.u.zerodayisaminecraftcheat(new GuiMainMenu());
                    break;
                }
                case 4: {
                    this.u.zerodayisaminecraftcheat((GuiScreen)null);
                    this.u.g();
                    break;
                }
                case 5: {
                    this.u.zerodayisaminecraftcheat(new GuiAchievements(this, this.u.e.u()));
                    break;
                }
                case 6: {
                    this.u.zerodayisaminecraftcheat(new GuiStats(this, this.u.e.u()));
                    break;
                }
                case 7: {
                    this.u.zerodayisaminecraftcheat(new GuiShareToLan(this));
                }
                case 8: {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                aR.c = false;
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    break;
                }
            }
        }
    }
    
    @Override
    public void sigma() {
        super.sigma();
        ++this.flux;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        final ScaledResolution sr = new ScaledResolution(this.u);
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("menu.game", new Object[0]), this.w / 2, 40, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
}

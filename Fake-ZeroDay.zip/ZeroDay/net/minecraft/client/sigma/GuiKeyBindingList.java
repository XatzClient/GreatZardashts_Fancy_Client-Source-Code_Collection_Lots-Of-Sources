// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.o.EnumChatFormatting;
import net.minecraft.client.c.GameSettings;
import net.minecraft.client.b.I18n;
import java.util.Arrays;
import org.apache.commons.lang3.ArrayUtils;
import net.minecraft.client.c.KeyBinding;
import net.minecraft.client.Minecraft;

public class GuiKeyBindingList extends GuiListExtended
{
    private final GuiControls zerodayisaminecraftcheat;
    private final Minecraft zeroday;
    private final GuiListExtended.zerodayisaminecraftcheat[] o;
    private int p;
    
    public GuiKeyBindingList(final GuiControls controls, final Minecraft mcIn) {
        super(mcIn, controls.w, controls.x, 63, controls.x - 32, 20);
        this.p = 0;
        this.zerodayisaminecraftcheat = controls;
        this.zeroday = mcIn;
        final KeyBinding[] akeybinding = (KeyBinding[])ArrayUtils.clone((Object[])mcIn.r.ao);
        this.o = new GuiListExtended.zerodayisaminecraftcheat[akeybinding.length + KeyBinding.sigma().size()];
        Arrays.sort(akeybinding);
        int i = 0;
        String s = null;
        KeyBinding[] array;
        for (int length = (array = akeybinding).length, k = 0; k < length; ++k) {
            final KeyBinding keybinding = array[k];
            final String s2 = keybinding.zues();
            if (!s2.equals(s)) {
                s = s2;
                this.o[i++] = new zerodayisaminecraftcheat(s2);
            }
            final int j = mcIn.i.zerodayisaminecraftcheat(I18n.zerodayisaminecraftcheat(keybinding.vape(), new Object[0]));
            if (j > this.p) {
                this.p = j;
            }
            this.o[i++] = new zeroday(keybinding, (zeroday)null);
        }
    }
    
    @Override
    protected int zerodayisaminecraftcheat() {
        return this.o.length;
    }
    
    @Override
    public GuiListExtended.zerodayisaminecraftcheat zeroday(final int index) {
        return this.o[index];
    }
    
    @Override
    protected int vape() {
        return super.vape() + 15;
    }
    
    @Override
    public int s_() {
        return super.s_() + 32;
    }
    
    public class zerodayisaminecraftcheat implements GuiListExtended.zerodayisaminecraftcheat
    {
        private final String zeroday;
        private final int sigma;
        
        public zerodayisaminecraftcheat(final String p_i45028_2_) {
            this.zeroday = I18n.zerodayisaminecraftcheat(p_i45028_2_, new Object[0]);
            this.sigma = GuiKeyBindingList.this.zeroday.i.zerodayisaminecraftcheat(this.zeroday);
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int slotIndex, final int x, final int y, final int listWidth, final int slotHeight, final int mouseX, final int mouseY, final boolean isSelected) {
            GuiKeyBindingList.this.zeroday.i.zerodayisaminecraftcheat(this.zeroday, GuiKeyBindingList.this.zeroday.k.w / 2 - this.sigma / 2, y + slotHeight - GuiKeyBindingList.this.zeroday.i.zeroday - 1, 16777215);
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final int slotIndex, final int p_148278_2_, final int p_148278_3_, final int p_148278_4_, final int p_148278_5_, final int p_148278_6_) {
            return false;
        }
        
        @Override
        public void zeroday(final int slotIndex, final int x, final int y, final int mouseEvent, final int relativeX, final int relativeY) {
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int p_178011_1_, final int p_178011_2_, final int p_178011_3_) {
        }
    }
    
    public class zeroday implements GuiListExtended.zerodayisaminecraftcheat
    {
        private final KeyBinding zeroday;
        private final String sigma;
        private final GuiButton pandora;
        private final GuiButton zues;
        
        private zeroday(final KeyBinding p_i45029_2_) {
            this.zeroday = p_i45029_2_;
            this.sigma = I18n.zerodayisaminecraftcheat(p_i45029_2_.vape(), new Object[0]);
            this.pandora = new GuiButton(0, 0, 0, 75, 20, I18n.zerodayisaminecraftcheat(p_i45029_2_.vape(), new Object[0]));
            this.zues = new GuiButton(0, 0, 0, 50, 20, I18n.zerodayisaminecraftcheat("controls.reset", new Object[0]));
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int slotIndex, final int x, final int y, final int listWidth, final int slotHeight, final int mouseX, final int mouseY, final boolean isSelected) {
            final boolean flag = GuiKeyBindingList.this.zerodayisaminecraftcheat.zeroday == this.zeroday;
            GuiKeyBindingList.this.zeroday.i.zerodayisaminecraftcheat(this.sigma, x + 90 - GuiKeyBindingList.this.p, y + slotHeight / 2 - GuiKeyBindingList.this.zeroday.i.zeroday / 2, 16777215);
            this.zues.pandora = x + 190;
            this.zues.zues = y;
            this.zues.momgetthecamera = (this.zeroday.a() != this.zeroday.momgetthecamera());
            this.zues.zerodayisaminecraftcheat(GuiKeyBindingList.this.zeroday, mouseX, mouseY);
            this.pandora.pandora = x + 105;
            this.pandora.zues = y;
            this.pandora.flux = GameSettings.zerodayisaminecraftcheat(this.zeroday.a());
            boolean flag2 = false;
            if (this.zeroday.a() != 0) {
                KeyBinding[] ao;
                for (int length = (ao = GuiKeyBindingList.this.zeroday.r.ao).length, i = 0; i < length; ++i) {
                    final KeyBinding keybinding = ao[i];
                    if (keybinding != this.zeroday && keybinding.a() == this.zeroday.a()) {
                        flag2 = true;
                        break;
                    }
                }
            }
            if (flag) {
                this.pandora.flux = EnumChatFormatting.h + "> " + EnumChatFormatting.g + this.pandora.flux + EnumChatFormatting.h + " <";
            }
            else if (flag2) {
                this.pandora.flux = EnumChatFormatting.e + this.pandora.flux;
            }
            this.pandora.zerodayisaminecraftcheat(GuiKeyBindingList.this.zeroday, mouseX, mouseY);
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final int slotIndex, final int p_148278_2_, final int p_148278_3_, final int p_148278_4_, final int p_148278_5_, final int p_148278_6_) {
            if (this.pandora.sigma(GuiKeyBindingList.this.zeroday, p_148278_2_, p_148278_3_)) {
                GuiKeyBindingList.this.zerodayisaminecraftcheat.zeroday = this.zeroday;
                return true;
            }
            if (this.zues.sigma(GuiKeyBindingList.this.zeroday, p_148278_2_, p_148278_3_)) {
                GuiKeyBindingList.this.zeroday.r.zerodayisaminecraftcheat(this.zeroday, this.zeroday.momgetthecamera());
                KeyBinding.zeroday();
                return true;
            }
            return false;
        }
        
        @Override
        public void zeroday(final int slotIndex, final int x, final int y, final int mouseEvent, final int relativeX, final int relativeY) {
            this.pandora.zerodayisaminecraftcheat(x, y);
            this.zues.zerodayisaminecraftcheat(x, y);
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int p_178011_1_, final int p_178011_2_, final int p_178011_3_) {
        }
    }
}

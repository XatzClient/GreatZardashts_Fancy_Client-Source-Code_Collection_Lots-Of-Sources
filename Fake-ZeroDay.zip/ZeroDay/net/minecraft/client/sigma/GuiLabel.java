// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.b.I18n;
import com.google.common.collect.Lists;
import java.util.List;

public class GuiLabel extends Gui
{
    protected int zerodayisaminecraftcheat;
    protected int zeroday;
    public int sigma;
    public int pandora;
    private List<String> vape;
    public int zues;
    private boolean momgetthecamera;
    public boolean flux;
    private boolean a;
    private int b;
    private int c;
    private int d;
    private int e;
    private FontRenderer f;
    private int g;
    
    public GuiLabel(final FontRenderer fontRendererObj, final int p_i45540_2_, final int p_i45540_3_, final int p_i45540_4_, final int p_i45540_5_, final int p_i45540_6_, final int p_i45540_7_) {
        this.zerodayisaminecraftcheat = 200;
        this.zeroday = 20;
        this.flux = true;
        this.f = fontRendererObj;
        this.zues = p_i45540_2_;
        this.sigma = p_i45540_3_;
        this.pandora = p_i45540_4_;
        this.zerodayisaminecraftcheat = p_i45540_5_;
        this.zeroday = p_i45540_6_;
        this.vape = (List<String>)Lists.newArrayList();
        this.momgetthecamera = false;
        this.a = false;
        this.b = p_i45540_7_;
        this.c = -1;
        this.d = -1;
        this.e = -1;
        this.g = 0;
    }
    
    public void zerodayisaminecraftcheat(final String p_175202_1_) {
        this.vape.add(I18n.zerodayisaminecraftcheat(p_175202_1_, new Object[0]));
    }
    
    public GuiLabel zerodayisaminecraftcheat() {
        this.momgetthecamera = true;
        return this;
    }
    
    public void zerodayisaminecraftcheat(final Minecraft mc, final int mouseX, final int mouseY) {
        if (this.flux) {
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            this.zeroday(mc, mouseX, mouseY);
            final int i = this.pandora + this.zeroday / 2 + this.g / 2;
            final int j = i - this.vape.size() * 10 / 2;
            for (int k = 0; k < this.vape.size(); ++k) {
                if (this.momgetthecamera) {
                    Gui.zerodayisaminecraftcheat(this.f, this.vape.get(k), this.sigma + this.zerodayisaminecraftcheat / 2, j + k * 10, this.b);
                }
                else {
                    Gui.zeroday(this.f, this.vape.get(k), this.sigma, j + k * 10, this.b);
                }
            }
        }
    }
    
    protected void zeroday(final Minecraft mcIn, final int p_146160_2_, final int p_146160_3_) {
        if (this.a) {
            final int i = this.zerodayisaminecraftcheat + this.g * 2;
            final int j = this.zeroday + this.g * 2;
            final int k = this.sigma - this.g;
            final int l = this.pandora - this.g;
            Gui.zerodayisaminecraftcheat(k, l, k + i, l + j, this.c);
            this.zues(k, k + i, l, this.d);
            this.zues(k, k + i, l + j, this.e);
            this.flux(k, l, l + j, this.d);
            this.flux(k + i, l, l + j, this.e);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.util.Iterator;
import com.google.common.collect.Maps;
import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.client.b.Language;
import java.util.Map;
import java.util.List;
import java.io.IOException;
import net.minecraft.client.b.I18n;
import net.minecraft.client.b.LanguageManager;
import net.minecraft.client.c.GameSettings;

public class GuiLanguage extends GuiScreen
{
    protected GuiScreen zerodayisaminecraftcheat;
    private zerodayisaminecraftcheat zeroday;
    private final GameSettings sigma;
    private final LanguageManager pandora;
    private GuiOptionButton zues;
    private GuiOptionButton flux;
    
    public GuiLanguage(final GuiScreen screen, final GameSettings gameSettingsObj, final LanguageManager manager) {
        this.zerodayisaminecraftcheat = screen;
        this.sigma = gameSettingsObj;
        this.pandora = manager;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.add(this.zues = new GuiOptionButton(100, this.w / 2 - 155, this.x - 38, GameSettings.zeroday.w, this.sigma.sigma(GameSettings.zeroday.w)));
        this.y.add(this.flux = new GuiOptionButton(6, this.w / 2 - 155 + 160, this.x - 38, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
        (this.zeroday = new zerodayisaminecraftcheat(this.u)).pandora(7, 8);
    }
    
    @Override
    public void b_() throws IOException {
        super.b_();
        this.zeroday.momgetthecamera();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            switch (button.vape) {
                case 5: {
                    break;
                }
                case 6: {
                    this.u.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
                    break;
                }
                case 100: {
                    if (button instanceof GuiOptionButton) {
                        this.sigma.zerodayisaminecraftcheat(((GuiOptionButton)button).sigma(), 1);
                        button.flux = this.sigma.sigma(GameSettings.zeroday.w);
                        final ScaledResolution scaledresolution = new ScaledResolution(this.u);
                        final int i = scaledresolution.zerodayisaminecraftcheat();
                        final int j = scaledresolution.zeroday();
                        this.zerodayisaminecraftcheat(this.u, i, j);
                        break;
                    }
                    break;
                }
                default: {
                    this.zeroday.zerodayisaminecraftcheat(button);
                    break;
                }
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.zeroday.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("options.language", new Object[0]), this.w / 2, 16, 16777215);
        Gui.zerodayisaminecraftcheat(this.C, "(" + I18n.zerodayisaminecraftcheat("options.languageWarning", new Object[0]) + ")", this.w / 2, this.x - 56, 8421504);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    class zerodayisaminecraftcheat extends GuiSlot
    {
        private final List<String> zeroday;
        private final Map<String, Language> o;
        
        public zerodayisaminecraftcheat(final Minecraft mcIn) {
            super(mcIn, GuiLanguage.this.w, GuiLanguage.this.x, 32, GuiLanguage.this.x - 65 + 4, 18);
            this.zeroday = (List<String>)Lists.newArrayList();
            this.o = (Map<String, Language>)Maps.newHashMap();
            for (final Language language : GuiLanguage.this.pandora.pandora()) {
                this.o.put(language.zerodayisaminecraftcheat(), language);
                this.zeroday.add(language.zerodayisaminecraftcheat());
            }
        }
        
        @Override
        protected int zerodayisaminecraftcheat() {
            return this.zeroday.size();
        }
        
        @Override
        protected void zerodayisaminecraftcheat(final int slotIndex, final boolean isDoubleClick, final int mouseX, final int mouseY) {
            final Language language = this.o.get(this.zeroday.get(slotIndex));
            GuiLanguage.this.pandora.zerodayisaminecraftcheat(language);
            GuiLanguage.this.sigma.aE = language.zerodayisaminecraftcheat();
            this.sigma.flux();
            GuiLanguage.this.C.zerodayisaminecraftcheat(GuiLanguage.this.pandora.zerodayisaminecraftcheat() || GuiLanguage.this.sigma.aF);
            GuiLanguage.this.C.zeroday(GuiLanguage.this.pandora.zeroday());
            GuiLanguage.this.flux.flux = I18n.zerodayisaminecraftcheat("gui.done", new Object[0]);
            GuiLanguage.this.zues.flux = GuiLanguage.this.sigma.sigma(GameSettings.zeroday.w);
            GuiLanguage.this.sigma.zeroday();
        }
        
        @Override
        protected boolean zerodayisaminecraftcheat(final int slotIndex) {
            return this.zeroday.get(slotIndex).equals(GuiLanguage.this.pandora.sigma().zerodayisaminecraftcheat());
        }
        
        @Override
        protected int zeroday() {
            return this.zerodayisaminecraftcheat() * 18;
        }
        
        @Override
        protected void sigma() {
            GuiLanguage.this.k();
        }
        
        @Override
        protected void zerodayisaminecraftcheat(final int entryID, final int p_180791_2_, final int p_180791_3_, final int p_180791_4_, final int mouseXIn, final int mouseYIn) {
            GuiLanguage.this.C.zeroday(true);
            Gui.zerodayisaminecraftcheat(GuiLanguage.this.C, this.o.get(this.zeroday.get(entryID)).toString(), this.pandora / 2, p_180791_3_ + 1, 16777215);
            GuiLanguage.this.C.zeroday(GuiLanguage.this.pandora.sigma().zeroday());
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.Minecraft;
import net.minecraft.client.b.I18n;

public class GuiListButton extends GuiButton
{
    private boolean e;
    private String f;
    private final GuiPageButtonList.flux g;
    
    public GuiListButton(final GuiPageButtonList.flux responder, final int p_i45539_2_, final int p_i45539_3_, final int p_i45539_4_, final String p_i45539_5_, final boolean p_i45539_6_) {
        super(p_i45539_2_, p_i45539_3_, p_i45539_4_, 150, 20, "");
        this.f = p_i45539_5_;
        this.e = p_i45539_6_;
        this.flux = this.sigma();
        this.g = responder;
    }
    
    private String sigma() {
        return String.valueOf(I18n.zerodayisaminecraftcheat(this.f, new Object[0])) + ": " + (this.e ? I18n.zerodayisaminecraftcheat("gui.yes", new Object[0]) : I18n.zerodayisaminecraftcheat("gui.no", new Object[0]));
    }
    
    public void zeroday(final boolean p_175212_1_) {
        this.e = p_175212_1_;
        this.flux = this.sigma();
        this.g.zerodayisaminecraftcheat(this.vape, p_175212_1_);
    }
    
    @Override
    public boolean sigma(final Minecraft mc, final int mouseX, final int mouseY) {
        if (super.sigma(mc, mouseX, mouseY)) {
            this.e = !this.e;
            this.flux = this.sigma();
            this.g.zerodayisaminecraftcheat(this.vape, this.e);
            return true;
        }
        return false;
    }
}

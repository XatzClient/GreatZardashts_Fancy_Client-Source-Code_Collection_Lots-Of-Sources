// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.Minecraft;

public abstract class GuiListExtended extends GuiSlot
{
    public GuiListExtended(final Minecraft mcIn, final int widthIn, final int heightIn, final int topIn, final int bottomIn, final int slotHeightIn) {
        super(mcIn, widthIn, heightIn, topIn, bottomIn, slotHeightIn);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int slotIndex, final boolean isDoubleClick, final int mouseX, final int mouseY) {
    }
    
    @Override
    protected boolean zerodayisaminecraftcheat(final int slotIndex) {
        return false;
    }
    
    @Override
    protected void sigma() {
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int entryID, final int p_180791_2_, final int p_180791_3_, final int p_180791_4_, final int mouseXIn, final int mouseYIn) {
        this.zeroday(entryID).zerodayisaminecraftcheat(entryID, p_180791_2_, p_180791_3_, this.s_(), p_180791_4_, mouseXIn, mouseYIn, this.sigma(mouseXIn, mouseYIn) == entryID);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int p_178040_1_, final int p_178040_2_, final int p_178040_3_) {
        this.zeroday(p_178040_1_).zerodayisaminecraftcheat(p_178040_1_, p_178040_2_, p_178040_3_);
    }
    
    public boolean zeroday(final int mouseX, final int mouseY, final int mouseEvent) {
        if (this.flux(mouseY)) {
            final int i = this.sigma(mouseX, mouseY);
            if (i >= 0) {
                final int j = this.a + this.pandora / 2 - this.s_() / 2 + 2;
                final int k = this.flux + 4 - this.f() + i * this.b + this.n;
                final int l = mouseX - j;
                final int i2 = mouseY - k;
                if (this.zeroday(i).zerodayisaminecraftcheat(i, mouseX, mouseY, mouseEvent, l, i2)) {
                    this.sigma(false);
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean sigma(final int p_148181_1_, final int p_148181_2_, final int p_148181_3_) {
        for (int i = 0; i < this.zerodayisaminecraftcheat(); ++i) {
            final int j = this.a + this.pandora / 2 - this.s_() / 2 + 2;
            final int k = this.flux + 4 - this.f() + i * this.b + this.n;
            final int l = p_148181_1_ - j;
            final int i2 = p_148181_2_ - k;
            this.zeroday(i).zeroday(i, p_148181_1_, p_148181_2_, p_148181_3_, l, i2);
        }
        this.sigma(true);
        return false;
    }
    
    public abstract zerodayisaminecraftcheat zeroday(final int p0);
    
    public interface zerodayisaminecraftcheat
    {
        void zerodayisaminecraftcheat(final int p0, final int p1, final int p2);
        
        void zerodayisaminecraftcheat(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final boolean p7);
        
        boolean zerodayisaminecraftcheat(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5);
        
        void zeroday(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5);
    }
}

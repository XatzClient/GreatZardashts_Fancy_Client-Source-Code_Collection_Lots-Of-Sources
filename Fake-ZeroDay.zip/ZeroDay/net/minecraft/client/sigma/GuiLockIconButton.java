// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;

public class GuiLockIconButton extends GuiButton
{
    private boolean e;
    
    public GuiLockIconButton(final int p_i45538_1_, final int p_i45538_2_, final int p_i45538_3_) {
        super(p_i45538_1_, p_i45538_2_, p_i45538_3_, 20, 20, "");
        this.e = false;
    }
    
    public boolean sigma() {
        return this.e;
    }
    
    public void zeroday(final boolean p_175229_1_) {
        this.e = p_175229_1_;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Minecraft mc, final int mouseX, final int mouseY) {
        if (this.a) {
            mc.I().zerodayisaminecraftcheat(GuiButton.zerodayisaminecraftcheat);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            final boolean flag = mouseX >= this.pandora && mouseY >= this.zues && mouseX < this.pandora + this.zeroday && mouseY < this.zues + this.sigma;
            zerodayisaminecraftcheat guilockiconbutton$icon;
            if (this.e) {
                if (!this.momgetthecamera) {
                    guilockiconbutton$icon = zerodayisaminecraftcheat.sigma;
                }
                else if (flag) {
                    guilockiconbutton$icon = zerodayisaminecraftcheat.zeroday;
                }
                else {
                    guilockiconbutton$icon = zerodayisaminecraftcheat.zerodayisaminecraftcheat;
                }
            }
            else if (!this.momgetthecamera) {
                guilockiconbutton$icon = zerodayisaminecraftcheat.flux;
            }
            else if (flag) {
                guilockiconbutton$icon = zerodayisaminecraftcheat.zues;
            }
            else {
                guilockiconbutton$icon = zerodayisaminecraftcheat.pandora;
            }
            this.zeroday(this.pandora, this.zues, guilockiconbutton$icon.zerodayisaminecraftcheat(), guilockiconbutton$icon.zeroday(), this.zeroday, this.sigma);
        }
    }
    
    enum zerodayisaminecraftcheat
    {
        zerodayisaminecraftcheat("LOCKED", 0, 0, 146), 
        zeroday("LOCKED_HOVER", 1, 0, 166), 
        sigma("LOCKED_DISABLED", 2, 0, 186), 
        pandora("UNLOCKED", 3, 20, 146), 
        zues("UNLOCKED_HOVER", 4, 20, 166), 
        flux("UNLOCKED_DISABLED", 5, 20, 186);
        
        private final int vape;
        private final int momgetthecamera;
        
        static {
            a = new zerodayisaminecraftcheat[] { zerodayisaminecraftcheat.zerodayisaminecraftcheat, zerodayisaminecraftcheat.zeroday, zerodayisaminecraftcheat.sigma, zerodayisaminecraftcheat.pandora, zerodayisaminecraftcheat.zues, zerodayisaminecraftcheat.flux };
        }
        
        private zerodayisaminecraftcheat(final String s, final int n, final int p_i45537_3_, final int p_i45537_4_) {
            this.vape = p_i45537_3_;
            this.momgetthecamera = p_i45537_4_;
        }
        
        public int zerodayisaminecraftcheat() {
            return this.vape;
        }
        
        public int zeroday() {
            return this.momgetthecamera;
        }
    }
}

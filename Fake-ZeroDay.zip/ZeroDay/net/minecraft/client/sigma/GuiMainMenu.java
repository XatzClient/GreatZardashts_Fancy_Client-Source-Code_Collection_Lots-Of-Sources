// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import org.lwjgl.input.Keyboard;
import java.util.ArrayList;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.o.MathHelper;
import org.lwjgl.util.glu.Project;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.a.Tessellator;
import net.minecraft.i.RealmsBridge;
import java.net.URISyntaxException;
import java.net.URI;
import java.awt.Desktop;
import zeroday.pandora.zerodayisaminecraftcheat.b.zerodayisaminecraftcheat.f;
import net.minecraft.q.pandora.DemoWorldServer;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.W;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.X;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.c;
import zeroday.pandora.zerodayisaminecraftcheat.h.v;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.R;
import zeroday.pandora.zerodayisaminecraftcheat.b.zerodayisaminecraftcheat.flux;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.o;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.af;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.g;
import zeroday.zerodayisaminecraftcheat.vape;
import zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.h;
import net.minecraft.q.vape.WorldInfo;
import net.minecraft.q.vape.ISaveFormat;
import zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat;
import java.util.Date;
import java.util.Calendar;
import net.minecraft.client.zues.GuiConnecting;
import net.minecraft.client.zues.ServerData;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.b.I18n;
import net.minecraft.client.a.OpenGlHelper;
import org.lwjgl.opengl.GLContext;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.commons.io.Charsets;
import net.minecraft.client.Minecraft;
import com.google.common.collect.Lists;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.V;
import zeroday.pandora.zerodayisaminecraftcheat.d.aT;
import zeroday.pandora.zerodayisaminecraftcheat.h.w;
import net.minecraft.o.EnumChatFormatting;
import org.apache.logging.log4j.LogManager;
import net.minecraft.o.ResourceLocation;
import net.minecraft.client.a.zues.DynamicTexture;
import zeroday.pandora.zerodayisaminecraftcheat.h.u;
import zeroday.pandora.zerodayisaminecraftcheat.h.an;
import zeroday.pandora.zerodayisaminecraftcheat.h.P;
import java.util.Random;
import org.apache.logging.log4j.Logger;
import java.util.concurrent.atomic.AtomicInteger;

public class GuiMainMenu extends GuiScreen implements GuiYesNoCallback
{
    private static final AtomicInteger G;
    private static final Logger H;
    private static final Random I;
    private P J;
    private an K;
    public static int zerodayisaminecraftcheat;
    public static String zeroday;
    public static boolean sigma;
    private float L;
    private String M;
    private GuiButton N;
    public static boolean pandora;
    public static boolean zues;
    public static boolean flux;
    public static boolean vape;
    public static boolean momgetthecamera;
    public static boolean a;
    public static boolean b;
    public static boolean c;
    public static boolean d;
    public static boolean e;
    public static int f;
    public static int g;
    public static int h;
    public u i;
    public u j;
    public static String k;
    private int O;
    private DynamicTexture P;
    private boolean Q;
    private final Object R;
    private String S;
    private String T;
    private String U;
    private static final ResourceLocation V;
    private static final ResourceLocation W;
    private static final ResourceLocation[] X;
    public static final String l;
    private int Y;
    private int Z;
    private int aa;
    private int ab;
    private int ac;
    public static int q;
    public static int r;
    public static int s;
    public static boolean t;
    private int ad;
    private ResourceLocation ae;
    private GuiButton af;
    
    static {
        G = new AtomicInteger(0);
        H = LogManager.getLogger();
        I = new Random();
        GuiMainMenu.sigma = true;
        GuiMainMenu.flux = true;
        GuiMainMenu.h = 1;
        V = new ResourceLocation("texts/splashes.txt");
        W = new ResourceLocation("textures/gui/title/minecraft.png");
        X = new ResourceLocation[] { new ResourceLocation("textures/gui/title/background/panorama_0.png"), new ResourceLocation("textures/gui/title/background/panorama_1.png"), new ResourceLocation("textures/gui/title/background/panorama_2.png"), new ResourceLocation("textures/gui/title/background/panorama_3.png"), new ResourceLocation("textures/gui/title/background/panorama_4.png"), new ResourceLocation("textures/gui/title/background/panorama_5.png") };
        l = "Please click " + EnumChatFormatting.l + "here" + EnumChatFormatting.n + " for more information.";
    }
    
    public GuiMainMenu() {
        this.K = new an();
        this.i = new u(0.0f, 0.0f, 0.0f, 0.0f);
        this.j = new u(200.0f, 175.0f, 0.0f, 0.0f);
        this.Q = true;
        this.R = new Object();
        if (zeroday.pandora.zerodayisaminecraftcheat.h.w.zerodayisaminecraftcheat("Removed").exists()) {
            final List<String> file = (List<String>)zeroday.pandora.zerodayisaminecraftcheat.h.w.zerodayisaminecraftcheat(aT.e);
            for (final String s1 : file) {
                try {
                    if (!s1.contains("true") || zeroday.pandora.zerodayisaminecraftcheat.pandora.V.zerodayisaminecraftcheat) {
                        continue;
                    }
                    GuiMainMenu.t = true;
                    this.y.clear();
                    this.z.clear();
                    GuiMainMenu.pandora = false;
                    GuiMainMenu.flux = false;
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        this.T = GuiMainMenu.l;
        this.M = "missingno";
        BufferedReader bufferedreader = null;
        try {
            final List<String> list = (List<String>)Lists.newArrayList();
            bufferedreader = new BufferedReader(new InputStreamReader(Minecraft.s().J().zerodayisaminecraftcheat(GuiMainMenu.V).zeroday(), Charsets.UTF_8));
            String s2;
            while ((s2 = bufferedreader.readLine()) != null) {
                s2 = s2.trim();
                if (!s2.isEmpty()) {
                    list.add(s2);
                }
            }
            if (!list.isEmpty()) {
                do {
                    this.M = list.get(GuiMainMenu.I.nextInt(list.size()));
                } while (this.M.hashCode() == 125780783);
            }
        }
        catch (IOException ex) {}
        finally {
            if (bufferedreader != null) {
                try {
                    bufferedreader.close();
                }
                catch (IOException ex2) {}
            }
        }
        if (bufferedreader != null) {
            try {
                bufferedreader.close();
            }
            catch (IOException ex3) {}
        }
        this.L = GuiMainMenu.I.nextFloat();
        this.S = "";
        if (!GLContext.getCapabilities().OpenGL20 && !OpenGlHelper.zeroday()) {
            this.S = I18n.zerodayisaminecraftcheat("title.oldgl1", new Object[0]);
            this.T = I18n.zerodayisaminecraftcheat("title.oldgl2", new Object[0]);
            this.U = "https://help.mojang.com/customer/portal/articles/325948?ref=game";
        }
    }
    
    @Override
    public void sigma() {
        ++this.O;
    }
    
    @Override
    public boolean zues() {
        return false;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
    }
    
    public void zerodayisaminecraftcheat(final ServerData server) {
        this.u.zerodayisaminecraftcheat(new GuiConnecting(this, this.u, server));
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        if (!zeroday.pandora.zerodayisaminecraftcheat.pandora.V.zerodayisaminecraftcheat) {
            final ScaledResolution sr = new ScaledResolution(this.u);
            final int amount = (sr.zerodayisaminecraftcheat() + sr.zeroday()) / 20;
            this.J = new P(amount, this.w, this.x);
        }
        this.P = new DynamicTexture(256, 256);
        this.ae = this.u.I().zerodayisaminecraftcheat("background", this.P);
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        if (calendar.get(2) + 1 == 12 && calendar.get(5) == 24) {
            this.M = "Merry Christmas!";
        }
        else if (calendar.get(2) + 1 == 1 && calendar.get(5) == 1) {
            this.M = "Happy new year!";
        }
        else if (calendar.get(2) + 1 == 10 && calendar.get(5) == 31) {
            this.M = "OOoooOOOoooo! Spooky!";
        }
        final int i = 24;
        final int j = this.x / 4 + 48;
        if (this.u.n()) {
            this.zeroday(j, 24);
        }
        else {
            this.zerodayisaminecraftcheat(j, 24);
            if (zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r && !GuiMainMenu.pandora) {
                GuiMainMenu.zerodayisaminecraftcheat = 100;
            }
            if (GuiMainMenu.t) {
                this.b();
            }
            if (zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r) {
                if (!GuiMainMenu.d) {
                    this.flux();
                }
                if (GuiMainMenu.flux) {
                    this.z.clear();
                    this.vape();
                }
                else if (GuiMainMenu.vape) {
                    this.z.clear();
                    this.a();
                }
                else if (GuiMainMenu.momgetthecamera) {
                    this.momgetthecamera();
                }
                else if (GuiMainMenu.a) {
                    this.c();
                }
                else if (GuiMainMenu.b) {
                    this.d();
                }
                else if (GuiMainMenu.c) {
                    this.e();
                }
                else if (GuiMainMenu.d) {
                    this.o();
                }
            }
        }
        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.V.zerodayisaminecraftcheat) {
            this.y.add(new GuiButton(0, this.w / 2 - 100, j + 72 + 12, 98, 20, I18n.zerodayisaminecraftcheat("menu.options", new Object[0])));
            this.y.add(new GuiButton(4, this.w / 2 + 2, j + 72 + 12, 98, 20, I18n.zerodayisaminecraftcheat("menu.quit", new Object[0])));
            this.y.add(new GuiButtonLanguage(5, this.w / 2 - 124, j + 72 + 12));
        }
        else if (!zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r && !GuiMainMenu.t) {
            this.y.add(new GuiButton(0, this.w / 2, j + 48, 48, 20, I18n.zerodayisaminecraftcheat("menu.options", new Object[0])));
            this.y.add(new GuiButton(4, this.w / 2 - 50, j + 72 + 24, 98, 20, I18n.zerodayisaminecraftcheat("menu.quit", new Object[0])));
            this.y.add(new GuiButton(69, this.w / 2 - 50, j + 48, 46, 20, I18n.zerodayisaminecraftcheat("Twitter", new Object[0])));
            this.y.add(new GuiButton(5473, 2, this.x - 74, 110, 20, I18n.zerodayisaminecraftcheat("Help / Info", new Object[0])));
            this.y.add(new GuiButton(123, this.w - 112, this.x - 50, 110, 20, I18n.zerodayisaminecraftcheat("Particles", new Object[0])));
            this.y.add(new GuiButton(666, 2, this.x - 50, 110, 20, I18n.zerodayisaminecraftcheat("Profiles", new Object[0])));
            this.y.add(new GuiButton(1738, 2, this.x - 98, 110, 20, I18n.zerodayisaminecraftcheat("ChangeLog", new Object[0])));
            this.y.add(new GuiButton(333, this.w - 112, this.x - 74, 110, 20, I18n.zerodayisaminecraftcheat("Change Wallpaper", new Object[0])));
            this.y.add(new GuiButton(334, this.w - 112, this.x - 98, 110, 20, I18n.zerodayisaminecraftcheat("Client Setup Wizard", new Object[0])));
        }
        synchronized (this.R) {
            this.Z = this.C.zerodayisaminecraftcheat(this.S);
            this.Y = this.C.zerodayisaminecraftcheat(this.T);
            final int k = Math.max(this.Z, this.Y);
            this.aa = (this.w - k) / 2;
            this.ab = this.y.get(0).zues - 24;
            this.ac = this.aa + k;
            this.ad = this.ab + 24;
        }
        // monitorexit(this.R)
        this.u.zerodayisaminecraftcheat(false);
    }
    
    private void zerodayisaminecraftcheat(final int p_73969_1_, final int p_73969_2_) {
        if (zeroday.pandora.zerodayisaminecraftcheat.pandora.V.zerodayisaminecraftcheat) {
            if (!zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.q) {
                this.y.add(new GuiButton(1, this.w / 2 - 100, p_73969_1_, I18n.zerodayisaminecraftcheat("menu.singleplayer", new Object[0])));
                this.y.add(new GuiButton(2, this.w / 2 - 100, p_73969_1_ + p_73969_2_ * 1, I18n.zerodayisaminecraftcheat("menu.multiplayer", new Object[0])));
                this.y.add(this.af = new GuiButton(14, this.w / 2 - 100, p_73969_1_ + p_73969_2_ * 2, I18n.zerodayisaminecraftcheat("menu.online", new Object[0])));
            }
        }
        else if (!zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.q) {
            final ScaledResolution sr = new ScaledResolution(this.u);
            this.y.add(new GuiButton(1, 1, sr.zeroday() + 100, I18n.zerodayisaminecraftcheat("", new Object[0])));
            if (!zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r && !GuiMainMenu.t) {
                this.y.add(new GuiButton(1, this.w / 2 - 50, p_73969_1_, 98, 20, I18n.zerodayisaminecraftcheat("Single", new Object[0])));
                this.y.add(new GuiButton(2, this.w / 2 - 50, p_73969_1_ + p_73969_2_ * 1, 98, 20, I18n.zerodayisaminecraftcheat("Multi", new Object[0])));
                this.y.add(new GuiButton(1337, this.w / 2 - 50, p_73969_1_ + p_73969_2_ * 3, 46, 20, I18n.zerodayisaminecraftcheat("Alts", new Object[0])));
                this.y.add(new GuiButton(5, this.w / 2 - 0, p_73969_1_ + p_73969_2_ * 3, 48, 20, "Lang"));
            }
        }
    }
    
    private void flux() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(999, sr.zerodayisaminecraftcheat() / 2 - 49, sr.zeroday() - 25, 98, 20, I18n.zerodayisaminecraftcheat("Quit Setup", new Object[0])));
    }
    
    private void vape() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        final int width = sr.zerodayisaminecraftcheat();
        this.z.add(new GuiColorButton(444, width / 2 - 77, 75, 25, 25, -855703552));
        this.z.add(new GuiColorButton(445, width / 2 - 37, 75, 25, 25, -855665408));
        this.z.add(new GuiColorButton(446, width / 2 + 7, 75, 25, 25, -855638272));
        this.z.add(new GuiColorButton(447, width / 2 + 47, 75, 25, 25, -869335296));
        this.z.add(new GuiColorButton(448, width / 2 - 77, 125, 25, 25, -869020417));
        this.z.add(new GuiColorButton(449, width / 2 - 37, 125, 25, 25, -859032577));
        this.z.add(new GuiColorButton(450, width / 2 + 7, 125, 25, 25, -855677185));
        this.z.add(new GuiColorButton(451, width / 2 + 47, 125, 25, 25, -1));
        this.z.add(new GuiColorButton(452, width / 2 - 37, 175, 25, 25, -15584170));
        this.z.add(new GuiColorButton(453, width / 2 + 7, 175, 25, 25, -10140895));
    }
    
    private void momgetthecamera() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(998, 33, 74, 98, 20, I18n.zerodayisaminecraftcheat("Zues", new Object[0])));
        this.y.add(new GuiButton(997, 163, 74, 98, 20, I18n.zerodayisaminecraftcheat("ZeroDay", new Object[0])));
        this.y.add(new GuiButton(996, 295, 74, 98, 20, I18n.zerodayisaminecraftcheat("Flux", new Object[0])));
    }
    
    private void a() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(365, sr.zerodayisaminecraftcheat() / 2 - 98 - 49 - 10, 74, 98, 20, I18n.zerodayisaminecraftcheat("Chill", new Object[0])));
        this.y.add(new GuiButton(364, sr.zerodayisaminecraftcheat() / 2 - 49, 74, 98, 20, I18n.zerodayisaminecraftcheat("Classic", new Object[0])));
        this.y.add(new GuiButton(363, sr.zerodayisaminecraftcheat() / 2 + 98 - 49 + 10, 74, 98, 20, I18n.zerodayisaminecraftcheat("Customize Classic", new Object[0])));
    }
    
    private void b() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(287, sr.zerodayisaminecraftcheat() / 2 - 45, 120, 40, 20, I18n.zerodayisaminecraftcheat("Yes", new Object[0])));
        this.y.add(new GuiButton(286, sr.zerodayisaminecraftcheat() / 2 + 5, 120, 40, 20, I18n.zerodayisaminecraftcheat("No", new Object[0])));
    }
    
    private void c() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(995, 50, 70, 98, 20, I18n.zerodayisaminecraftcheat("Rainbow", new Object[0])));
        this.y.add(new GuiButton(994, 50, 94, 98, 20, I18n.zerodayisaminecraftcheat("German", new Object[0])));
        this.y.add(new GuiButton(993, 50, 118, 98, 20, I18n.zerodayisaminecraftcheat("Category", new Object[0])));
        this.y.add(new GuiButton(992, 50, 142, 98, 20, I18n.zerodayisaminecraftcheat("Solid", new Object[0])));
        this.y.add(new GuiButton(9921, 50, 166, 98, 20, I18n.zerodayisaminecraftcheat("Chill", new Object[0])));
        this.y.add(new GuiButton(991, 50, 190, 98, 20, I18n.zerodayisaminecraftcheat("Background", new Object[0])));
        this.y.add(new GuiButton(987, 50, 214, 98, 20, I18n.zerodayisaminecraftcheat("Boxes", new Object[0])));
        this.y.add(new GuiButton(990, 280, 170, 98, 20, I18n.zerodayisaminecraftcheat("Next", new Object[0])));
    }
    
    private void d() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(989, 105, 75, 48, 20, I18n.zerodayisaminecraftcheat("Yes", new Object[0])));
        this.y.add(new GuiButton(988, 265, 75, 48, 20, I18n.zerodayisaminecraftcheat("No", new Object[0])));
    }
    
    private void e() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(777, 85, 75, 98, 20, I18n.zerodayisaminecraftcheat("Hypixel", new Object[0])));
        this.y.add(new GuiButton(776, 245, 75, 98, 20, I18n.zerodayisaminecraftcheat("Mineplex", new Object[0])));
        this.y.add(new GuiButton(775, 85, 105, 98, 20, I18n.zerodayisaminecraftcheat("CubeCraft", new Object[0])));
        this.y.add(new GuiButton(774, 245, 105, 98, 20, I18n.zerodayisaminecraftcheat("FadeCloud", new Object[0])));
        this.y.add(new GuiButton(773, 85, 135, 98, 20, I18n.zerodayisaminecraftcheat("MC-Central | NCP", new Object[0])));
        this.y.add(new GuiButton(772, 245, 135, 98, 20, I18n.zerodayisaminecraftcheat("MC-Central | AAC", new Object[0])));
        this.y.add(new GuiButton(771, 85, 165, 98, 20, I18n.zerodayisaminecraftcheat("Duels / Ghost", new Object[0])));
        this.y.add(new GuiButton(770, 245, 165, 98, 20, I18n.zerodayisaminecraftcheat("Factions", new Object[0])));
    }
    
    private void o() {
        final ScaledResolution sr = new ScaledResolution(this.u);
        this.y.add(new GuiButton(665, sr.zerodayisaminecraftcheat() / 2 - 64, 75, 128, 20, I18n.zerodayisaminecraftcheat("Go Multiplayer", new Object[0])));
        this.y.add(new GuiButton(664, sr.zerodayisaminecraftcheat() / 2 - 64, 105, 128, 20, I18n.zerodayisaminecraftcheat("Alt Manager", new Object[0])));
        this.y.add(new GuiButton(663, sr.zerodayisaminecraftcheat() / 2 - 64, 135, 128, 20, I18n.zerodayisaminecraftcheat("Main Menu", new Object[0])));
    }
    
    private void zeroday(final int p_73972_1_, final int p_73972_2_) {
        this.y.add(new GuiButton(11, this.w / 2 - 100, p_73972_1_, I18n.zerodayisaminecraftcheat("menu.playdemo", new Object[0])));
        this.y.add(this.N = new GuiButton(12, this.w / 2 - 100, p_73972_1_ + p_73972_2_ * 1, I18n.zerodayisaminecraftcheat("menu.resetdemo", new Object[0])));
        final ISaveFormat isaveformat = this.u.vape();
        final WorldInfo worldinfo = isaveformat.sigma("Demo_World");
        if (worldinfo == null) {
            this.N.momgetthecamera = false;
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiColorButton button) throws IOException {
        if (button.vape == 444) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855703552;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 12237498;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855703552;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426128896;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862336512;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627324416;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5636096;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1431699456;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867907072;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890189312;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890189312;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 445) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855665408;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 16749824;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -27392;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855665408;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426090752;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862298368;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627362560;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5615616;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1431678976;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867886592;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890209792;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890209792;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 446) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855638272;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 15662848;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -256;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855638272;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426063616;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862271232;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627389696;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5592576;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1431655936;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867863552;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890232832;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890232832;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 447) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -869335296;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 65424;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -13697280;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -869335296;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1439760640;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1875968256;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1613692672;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -16733696;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1442797056;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1879004672;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1879091712;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1879091712;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 448) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -869020417;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 65535;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -13382401;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -869020417;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1439445761;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1875653377;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1614007551;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -16733526;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1610569046;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1879004502;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1879091882;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1879091882;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 449) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -859032577;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 13893887;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -3394561;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -859032577;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1429457921;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1865665537;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1623995391;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5635926;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1599471446;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867906902;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890189482;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890189482;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 450) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855677185;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 16711922;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -39169;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855677185;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426102529;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862310145;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627350783;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5635952;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1599471472;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867906928;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890189456;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890189456;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 451) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855638017;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 11184810;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -1;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855638017;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426063361;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862270977;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627389951;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -8355712;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1602191232;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1870626688;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1887469696;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1887469696;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 452) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 0;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 0;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 453) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 65536;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.vape == 0) {
            this.u.zerodayisaminecraftcheat(new GuiOptions(this, this.u.r));
        }
        if (button.vape == 5) {
            this.u.zerodayisaminecraftcheat(new GuiLanguage(this, this.u.r, this.u.L()));
        }
        if (button.vape == 1) {
            this.u.zerodayisaminecraftcheat(new GuiSelectWorld(this));
        }
        if (button.vape == 1337) {
            this.u.zerodayisaminecraftcheat(new vape());
        }
        if (button.vape == 365) {
            GuiMainMenu.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zerodayisaminecraftcheat = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.af.zeroday = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.pandora = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.o.zerodayisaminecraftcheat = true;
            GuiMainMenu.b = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 364) {
            GuiMainMenu.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zerodayisaminecraftcheat = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.af.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.pandora = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.o.zerodayisaminecraftcheat = false;
            GuiMainMenu.b = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 363) {
            GuiMainMenu.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zerodayisaminecraftcheat = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.sigma = false;
            GuiMainMenu.momgetthecamera = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 334) {
            GuiMainMenu.pandora = false;
            GuiMainMenu.flux = true;
            GuiMainMenu.vape = false;
            GuiMainMenu.momgetthecamera = false;
            GuiMainMenu.a = false;
            GuiMainMenu.b = false;
            GuiMainMenu.c = false;
            GuiMainMenu.d = false;
            this.y.clear();
            this.z.clear();
            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r = true;
        }
        if (button.vape == 333) {
            if (GuiMainMenu.h == 1) {
                GuiMainMenu.h = 2;
            }
            else if (GuiMainMenu.h == 2) {
                GuiMainMenu.h = 3;
            }
            else if (GuiMainMenu.h == 3) {
                GuiMainMenu.h = 4;
            }
            else if (GuiMainMenu.h == 4) {
                GuiMainMenu.h = 5;
            }
            else if (GuiMainMenu.h == 5) {
                GuiMainMenu.h = 6;
            }
            else if (GuiMainMenu.h == 6) {
                GuiMainMenu.h = 1;
            }
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
        }
        if (button.vape == 1738) {
            this.u.zerodayisaminecraftcheat(new flux(this));
        }
        if (button.vape == 999) {
            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r = false;
            this.u.zerodayisaminecraftcheat(new GuiMainMenu());
        }
        if (button.vape == 444) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855703552;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 12237498;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -65536;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855703552;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426128896;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862336512;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627324416;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5636096;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1431699456;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867907072;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890189312;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890189312;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 445) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855665408;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 16749824;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -27392;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855665408;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426090752;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862298368;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627362560;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5615616;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1431678976;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867886592;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890209792;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890209792;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 446) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855638272;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 15662848;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -256;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855638272;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426063616;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862271232;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627389696;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5592576;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1431655936;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867863552;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890232832;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890232832;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 447) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -869335296;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 65424;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -13697280;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -869335296;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1439760640;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1875968256;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1613692672;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -16733696;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1442797056;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1879004672;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1879091712;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1879091712;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 448) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -869020417;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 65535;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -13382401;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -869020417;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1439445761;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1875653377;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1614007551;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -16733526;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1610569046;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1879004502;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1879091882;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1879091882;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 449) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -859032577;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 13893887;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -3394561;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -859032577;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1429457921;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1865665537;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1623995391;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5635926;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1599471446;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867906902;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890189482;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890189482;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 450) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855677185;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 16711922;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -39169;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855677185;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426102529;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862310145;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627350783;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -5635952;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1599471472;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1867906928;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1890189456;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1890189456;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 451) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat = -855638017;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zeroday = 11184810;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.sigma = -1;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.pandora = -855638017;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zues = -1426063361;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.flux = -1862270977;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.vape = 1627389951;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.momgetthecamera = -8355712;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.a = -1602191232;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.b = -1870626688;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.c = 1887469696;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.h.d = 1887469696;
            GuiMainMenu.flux = false;
            GuiMainMenu.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 287) {
            GuiMainMenu.t = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.R.zeroday("LF4Kt7xGH20vB");
            GuiMainMenu.pandora = false;
            this.y.clear();
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.h.v.zeroday(aT.e);
        }
        if (button.vape == 286) {
            GuiMainMenu.t = false;
            GuiMainMenu.pandora = false;
            this.y.clear();
            this.zerodayisaminecraftcheat();
            zeroday.pandora.zerodayisaminecraftcheat.h.v.zeroday(aT.e);
        }
        if (button.vape == 998) {
            GuiMainMenu.momgetthecamera = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zeroday = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zerodayisaminecraftcheat = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.sigma = false;
            GuiMainMenu.a = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 997) {
            GuiMainMenu.momgetthecamera = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zerodayisaminecraftcheat = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.sigma = false;
            GuiMainMenu.a = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 996) {
            GuiMainMenu.momgetthecamera = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.zerodayisaminecraftcheat = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.g.sigma = true;
            GuiMainMenu.a = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 995) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues = false;
        }
        if (button.vape == 994) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues = false;
        }
        if (button.vape == 993) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues = false;
        }
        if (button.vape == 992) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape = true;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues = false;
        }
        if (button.vape == 9921) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape = false;
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues = true;
        }
        if (button.vape == 991) {
            if (!zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera) {
                zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera = true;
                zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux = false;
            }
            else if (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera && !zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux) {
                zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux = true;
            }
            else {
                zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera = false;
            }
        }
        if (button.vape == 990) {
            GuiMainMenu.a = false;
            GuiMainMenu.b = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 989) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.c.zerodayisaminecraftcheat = true;
            GuiMainMenu.b = false;
            GuiMainMenu.c = true;
            Minecraft.s().r.bw = false;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 988) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.c.zerodayisaminecraftcheat = false;
            GuiMainMenu.b = false;
            GuiMainMenu.c = true;
            zeroday.pandora.zerodayisaminecraftcheat.sigma.zeroday.sigma();
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 987) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.pandora = !zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.pandora;
        }
        if (button.vape == 777) {
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/mW78DXpe");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/5zMuULZJ");
            GuiMainMenu.k = "Hypixel";
            GuiMainMenu.zeroday = "mc.hypixel.net";
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 776) {
            GuiMainMenu.k = "Mineplex";
            GuiMainMenu.zeroday = "mineplex.com";
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/TynwwyFE");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/PvpBxGyP");
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 775) {
            GuiMainMenu.k = "CubeCraft";
            GuiMainMenu.zeroday = "play.cubecraftgames.net";
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/LqBtr9Em");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/CeRvVkF9");
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 774) {
            GuiMainMenu.zeroday = "fadecloud.com";
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/kLrDwHHu");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/aPKyxRBH");
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 773) {
            GuiMainMenu.k = "MC-Central";
            GuiMainMenu.zeroday = "mc-central.net";
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/H7P2mRAG");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/8waVn1ci");
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 772) {
            GuiMainMenu.k = "MC-Central";
            GuiMainMenu.zeroday = "mc-central.net";
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/0NdnyjXz");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/R26TVQYE");
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 771) {
            GuiMainMenu.k = "Duels";
            GuiMainMenu.zeroday = "";
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/ZZGZEBtD");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/BuVGZ9iG");
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 770) {
            GuiMainMenu.k = "Factions";
            GuiMainMenu.zeroday = "";
            zeroday.pandora.zerodayisaminecraftcheat.pandora.X.zerodayisaminecraftcheat("https://pastebin.com/raw/qZw7GAAb");
            zeroday.pandora.zerodayisaminecraftcheat.pandora.W.zerodayisaminecraftcheat("https://pastebin.com/raw/W10jgFA6");
            GuiMainMenu.c = false;
            GuiMainMenu.d = true;
            GuiMainMenu.pandora = false;
        }
        if (button.vape == 665) {
            this.u.zerodayisaminecraftcheat(new GuiMultiplayer(this));
        }
        if (button.vape == 664) {
            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r = false;
            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.pandora();
            this.u.zerodayisaminecraftcheat(new vape());
        }
        if (button.vape == 663) {
            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r = false;
            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.pandora();
            this.u.zerodayisaminecraftcheat(new GuiMainMenu());
        }
        if (button.vape == 2) {
            this.u.zerodayisaminecraftcheat(new GuiMultiplayer(this));
        }
        if (button.vape == 14 && this.af.a) {
            this.p();
        }
        if (button.vape == 4) {
            zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.pandora();
            this.u.f();
        }
        if (button.vape == 123) {
            GuiMainMenu.sigma = !GuiMainMenu.sigma;
        }
        if (button.vape == 11) {
            this.u.zerodayisaminecraftcheat("Demo_World", "Demo_World", DemoWorldServer.z);
        }
        if (button.vape == 5473) {
            this.u.zerodayisaminecraftcheat(new zeroday.pandora.zerodayisaminecraftcheat.b.zerodayisaminecraftcheat.c(this));
        }
        if (button.vape == 420) {
            this.u.zerodayisaminecraftcheat(new flux(this));
        }
        if (button.vape == 666) {
            this.u.zerodayisaminecraftcheat(new f(this));
        }
        if (button.vape == 12) {
            final ISaveFormat isaveformat = this.u.vape();
            final WorldInfo worldinfo = isaveformat.sigma("Demo_World");
            if (worldinfo != null) {
                final GuiYesNo guiyesno = GuiSelectWorld.zerodayisaminecraftcheat(this, worldinfo.b(), 12);
                this.u.zerodayisaminecraftcheat(guiyesno);
            }
        }
        if (button.vape == 69) {
            zerodayisaminecraftcheat("https://twitter.com/RealNefIntent");
        }
    }
    
    public static void zerodayisaminecraftcheat(final String s) {
        try {
            if (Desktop.isDesktopSupported()) {
                try {
                    Desktop.getDesktop().browse(new URI(s));
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        catch (URISyntaxException e2) {
            e2.printStackTrace();
        }
    }
    
    private void p() {
        final RealmsBridge realmsbridge = new RealmsBridge();
        realmsbridge.zerodayisaminecraftcheat(this);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean result, final int id) {
        if (result && id == 12) {
            final ISaveFormat isaveformat = this.u.vape();
            isaveformat.pandora();
            isaveformat.zues("Demo_World");
            this.u.zerodayisaminecraftcheat(this);
        }
        else if (id == 13) {
            if (result) {
                try {
                    final Class<?> oclass = Class.forName("java.awt.Desktop");
                    final Object object = oclass.getMethod("getDesktop", (Class<?>[])new Class[0]).invoke(null, new Object[0]);
                    oclass.getMethod("browse", URI.class).invoke(object, new URI(this.U));
                }
                catch (Throwable throwable) {
                    GuiMainMenu.H.error("Couldn't open link", throwable);
                }
            }
            this.u.zerodayisaminecraftcheat(this);
        }
    }
    
    private void zeroday(final int p_73970_1_, final int p_73970_2_, final float p_73970_3_) {
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        GlStateManager.d(5889);
        GlStateManager.v();
        GlStateManager.u();
        Project.gluPerspective(120.0f, 1.0f, 0.05f, 10.0f);
        GlStateManager.d(5888);
        GlStateManager.v();
        GlStateManager.u();
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.zeroday(180.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.zeroday(90.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.d();
        GlStateManager.sigma();
        GlStateManager.h();
        GlStateManager.zerodayisaminecraftcheat(false);
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        for (int i = 8, j = 0; j < i * i; ++j) {
            GlStateManager.v();
            final float f = (j % i / (float)i - 0.5f) / 64.0f;
            final float f2 = (j / i / (float)i - 0.5f) / 64.0f;
            final float f3 = 0.0f;
            GlStateManager.zeroday(f, f2, f3);
            GlStateManager.zeroday(MathHelper.zerodayisaminecraftcheat((this.O + p_73970_3_) / 400.0f) * 25.0f + 20.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.zeroday(-(this.O + p_73970_3_) * 0.1f, 0.0f, 1.0f, 0.0f);
            for (int k = 0; k < 6; ++k) {
                GlStateManager.v();
                if (k == 1) {
                    GlStateManager.zeroday(90.0f, 0.0f, 1.0f, 0.0f);
                }
                if (k == 2) {
                    GlStateManager.zeroday(180.0f, 0.0f, 1.0f, 0.0f);
                }
                if (k == 3) {
                    GlStateManager.zeroday(-90.0f, 0.0f, 1.0f, 0.0f);
                }
                if (k == 4) {
                    GlStateManager.zeroday(90.0f, 1.0f, 0.0f, 0.0f);
                }
                if (k == 5) {
                    GlStateManager.zeroday(-90.0f, 1.0f, 0.0f, 0.0f);
                }
                this.u.I().zerodayisaminecraftcheat(GuiMainMenu.X[k]);
                worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
                final int l = 255 / (j + 1);
                final float f4 = 0.0f;
                worldrenderer.zeroday(-1.0, -1.0, 1.0).zerodayisaminecraftcheat(0.0, 0.0).zeroday(255, 255, 255, l).zues();
                worldrenderer.zeroday(1.0, -1.0, 1.0).zerodayisaminecraftcheat(1.0, 0.0).zeroday(255, 255, 255, l).zues();
                worldrenderer.zeroday(1.0, 1.0, 1.0).zerodayisaminecraftcheat(1.0, 1.0).zeroday(255, 255, 255, l).zues();
                worldrenderer.zeroday(-1.0, 1.0, 1.0).zerodayisaminecraftcheat(0.0, 1.0).zeroday(255, 255, 255, l).zues();
                tessellator.zeroday();
                GlStateManager.w();
            }
            GlStateManager.w();
            GlStateManager.zerodayisaminecraftcheat(true, true, true, false);
        }
        worldrenderer.sigma(0.0, 0.0, 0.0);
        GlStateManager.zerodayisaminecraftcheat(true, true, true, true);
        GlStateManager.d(5889);
        GlStateManager.w();
        GlStateManager.d(5888);
        GlStateManager.w();
        GlStateManager.zerodayisaminecraftcheat(true);
        GlStateManager.g();
        GlStateManager.b();
    }
    
    private void zerodayisaminecraftcheat(final float p_73968_1_) {
        this.u.I().zerodayisaminecraftcheat(this.ae);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, 256, 256);
        GlStateManager.d();
        GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
        GlStateManager.zerodayisaminecraftcheat(true, true, true, false);
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
        GlStateManager.sigma();
        for (int i = 3, j = 0; j < i; ++j) {
            final float f = 1.0f / (j + 1);
            final int k = this.w;
            final int l = this.x;
            final float f2 = (j - i / 2) / 256.0f;
            worldrenderer.zeroday(k, l, (double)this.p).zerodayisaminecraftcheat(0.0f + f2, 1.0).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f).zues();
            worldrenderer.zeroday(k, 0.0, this.p).zerodayisaminecraftcheat(1.0f + f2, 1.0).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f).zues();
            worldrenderer.zeroday(0.0, 0.0, this.p).zerodayisaminecraftcheat(1.0f + f2, 0.0).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f).zues();
            worldrenderer.zeroday(0.0, l, this.p).zerodayisaminecraftcheat(0.0f + f2, 0.0).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, f).zues();
        }
        tessellator.zeroday();
        GlStateManager.pandora();
        GlStateManager.zerodayisaminecraftcheat(true, true, true, true);
    }
    
    private void sigma(final int p_73971_1_, final int p_73971_2_, final float p_73971_3_) {
        this.u.sigma().zues();
        GlStateManager.zeroday(0, 0, 256, 256);
        this.zeroday(p_73971_1_, p_73971_2_, p_73971_3_);
        this.zerodayisaminecraftcheat(p_73971_3_);
        this.zerodayisaminecraftcheat(p_73971_3_);
        this.zerodayisaminecraftcheat(p_73971_3_);
        this.zerodayisaminecraftcheat(p_73971_3_);
        this.zerodayisaminecraftcheat(p_73971_3_);
        this.zerodayisaminecraftcheat(p_73971_3_);
        this.zerodayisaminecraftcheat(p_73971_3_);
        this.u.sigma().zerodayisaminecraftcheat(true);
        GlStateManager.zeroday(0, 0, this.u.flux, this.u.vape);
        final float f = (this.w > this.x) ? (120.0f / this.w) : (120.0f / this.x);
        final float f2 = this.x * f / 256.0f;
        final float f3 = this.w * f / 256.0f;
        final int i = this.w;
        final int j = this.x;
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
        worldrenderer.zeroday(0.0, j, this.p).zerodayisaminecraftcheat(0.5f - f2, 0.5f + f3).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, 1.0f).zues();
        worldrenderer.zeroday(i, j, (double)this.p).zerodayisaminecraftcheat(0.5f - f2, 0.5f - f3).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, 1.0f).zues();
        worldrenderer.zeroday(i, 0.0, this.p).zerodayisaminecraftcheat(0.5f + f2, 0.5f - f3).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, 1.0f).zues();
        worldrenderer.zeroday(0.0, 0.0, this.p).zerodayisaminecraftcheat(0.5f + f2, 0.5f + f3).zerodayisaminecraftcheat(1.0f, 1.0f, 1.0f, 1.0f).zues();
        tessellator.zeroday();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        if (!zeroday.pandora.zerodayisaminecraftcheat.pandora.V.zerodayisaminecraftcheat) {
            this.k();
            if (zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r || GuiMainMenu.t) {
                this.i();
            }
            final ScaledResolution sr = new ScaledResolution(this.u);
            final FontRenderer fr = Minecraft.s().i;
            if (!zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.r && !GuiMainMenu.t) {
                final float halfwayx1 = (float)(sr.zerodayisaminecraftcheat() / 2);
                final float halfwayy1 = (float)(sr.zeroday() / 2);
                this.u.I().zerodayisaminecraftcheat(new ResourceLocation((GuiMainMenu.h == 1) ? "ZeroDay/nebulalit.jpg" : ((GuiMainMenu.h == 2) ? "ZeroDay/othernebulalit.jpg" : ((GuiMainMenu.h == 3) ? "ZeroDay/snowyforestzerodaysized.jpg" : ((GuiMainMenu.h == 4) ? "ZeroDay/snowyzeroday2sized.jpg" : ((GuiMainMenu.h == 5) ? "ZeroDay/snowyzeroday4.jpg" : "ZeroDay/zerodaysnowy3.jpg"))))));
                GL11.glPushMatrix();
                GL11.glTranslatef(0.0f + (mouseX - halfwayx1) / 90.0f, 0.0f + (mouseY - halfwayy1) / 90.0f, 0.0f);
                Gui.zerodayisaminecraftcheat(-5, -5, 0.0f, 0.0f, sr.zerodayisaminecraftcheat() + 10, sr.zeroday() + 10, (float)(sr.zerodayisaminecraftcheat() + 10), (float)(sr.zeroday() + 10));
                GlStateManager.d();
                GlStateManager.zeroday(770, 771);
                GL11.glScalef(1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
                GL11.glPushMatrix();
                GL11.glScalef(1.0f, 1.0f, 1.0f);
                final String client_name1 = "Zn".replace("n", "e");
                final String client_name2 = "rg".replace("g", "o");
                final String client_name3 = "2a".replace("2", "D");
                final String client_name4 = "k".replace("k", "y");
                final String client_name5 = String.valueOf(client_name1) + client_name2 + client_name3 + client_name4;
                final String s2 = zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.zues ? ("�aYou are using the latest version! �r" + client_name5 + " " + zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.vape) : ("�cYou are using an outdated version. �fLatest Version: �r" + client_name5 + " " + zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.vape);
                final String s3 = "�f" + client_name5 + " (MC 1.8.8)";
                Gui.zeroday(this.C, s3, 2, this.x - 10, -1);
                GL11.glScalef(4.0f, 4.0f, 1.0f);
                final float halfwayx2 = (float)(sr.zerodayisaminecraftcheat() / 2);
                final float halfwayy2 = (float)(sr.zeroday() / 2);
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.f < mouseX) {
                    ++GuiMainMenu.f;
                }
                else if (GuiMainMenu.f > mouseX) {
                    --GuiMainMenu.f;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                if (GuiMainMenu.g < mouseY) {
                    ++GuiMainMenu.g;
                }
                else if (GuiMainMenu.g > mouseY) {
                    --GuiMainMenu.g;
                }
                GL11.glPopMatrix();
                final String s4 = "Cgpy".replace("g", "o");
                final String s5 = "30".replace("3", "2");
                final String s6 = "r";
                final String s7 = "yent".replace("y", "Int");
                final String s8 = "boght".replaceAll("bo", "ri");
                final String s9 = "19".replace("9", "7");
                final String s10 = "kus".replace("k", "io");
                final String s11 = "jjfa".replace("jj", "Ne");
                Gui.zeroday(this.C, String.valueOf(s4) + s8 + " " + s5 + s9 + " " + s11 + s6 + s10 + " " + s7, this.w - this.C.zerodayisaminecraftcheat(String.valueOf(s4) + s8 + " " + s5 + s9 + " " + s11 + s6 + s10 + " " + s7) - 2, this.x - 10, -1);
                GL11.glTranslatef(0.0f + (mouseX - halfwayx2) / 30.0f, 0.0f + (mouseY - halfwayy2) / 30.0f, 0.0f);
                this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/logo.png"));
                Gui.zerodayisaminecraftcheat(sr.zerodayisaminecraftcheat() / 2 - 110, this.x / 4 - 74, 0.0f, 0.0f, 210, 117, 210.0f, 117.0f);
                if (GuiMainMenu.sigma) {
                    this.J.zerodayisaminecraftcheat(mouseX, mouseY);
                }
                GL11.glTranslatef(0.0f - (mouseX - halfwayx2) / 30.0f, 0.0f - (mouseY - halfwayy2) / 30.0f, 0.0f);
                Minecraft.s().i.zerodayisaminecraftcheat("Account: �f" + Minecraft.s().h.sigma(), 2.0f, (float)(this.x - Minecraft.s().i.zeroday - 12), (zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat == 0) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(50000000L, 1.0f).getRGB() : ((zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat == 65536) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat));
                Gui.zeroday(this.C, s2, 2, 2, (zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat == 0) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(50000000L, 1.0f).getRGB() : ((zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat == 65536) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat));
                GL11.glTranslatef(0.0f + (mouseX - halfwayx2) / 50.0f, 0.0f + (mouseY - halfwayy2) / 50.0f, 0.0f);
                GL11.glPushMatrix();
                GL11.glTranslatef(0.0f + (mouseX - halfwayx2) / 150.0f, 0.0f + (mouseY - halfwayy2) / 150.0f, 0.0f);
                if (GuiMainMenu.q < 5) {
                    ++GuiMainMenu.q;
                }
                else {
                    GuiMainMenu.q = 0;
                    if (GuiMainMenu.r != mouseX) {
                        GuiMainMenu.r = mouseX;
                    }
                }
                if (GuiMainMenu.r - mouseX < 0) {
                    ++GuiMainMenu.s;
                }
                if (GuiMainMenu.r - mouseX > 0) {
                    --GuiMainMenu.s;
                }
                GL11.glScalef(1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
            }
            else {
                if (GuiMainMenu.zerodayisaminecraftcheat > 0) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.zerodayisaminecraftcheat > 10) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.zerodayisaminecraftcheat > 30) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.zerodayisaminecraftcheat > 50) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.zerodayisaminecraftcheat > 60) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.zerodayisaminecraftcheat > 70) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.zerodayisaminecraftcheat > 80) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.zerodayisaminecraftcheat > 90) {
                    --GuiMainMenu.zerodayisaminecraftcheat;
                }
                if (GuiMainMenu.t) {
                    Gui.zeroday(sr.zerodayisaminecraftcheat() / 2 - 90, 50, sr.zerodayisaminecraftcheat() / 2 + 90, 150, -1876942816);
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        this.b();
                        GuiMainMenu.pandora = true;
                    }
                    this.u.i.zerodayisaminecraftcheat("It appears as if you are", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("It appears as if you are")) / 2), 60.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("launching after a �cSelf Destruct", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("launching after a Self Destruct")) / 2), 70.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("Would you like to �arestore ZeroDay", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Would you like to restore ZeroDay")) / 2), 90.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("from the backup we saved?", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("from the backup we saved?")) / 2), 100.0f, 16777215);
                }
                if (GuiMainMenu.flux) {
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        this.flux();
                        this.vape();
                        GuiMainMenu.pandora = true;
                    }
                    this.u.i.zerodayisaminecraftcheat("Welcome to �aZeroDay", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Welcome to ZeroDay")) / 2), 20.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("What is your favorite color?", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("What is your favorite color?")) / 2), 50.0f, 16777215);
                }
                else if (GuiMainMenu.vape) {
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        GuiMainMenu.pandora = true;
                    }
                    this.u.i.zerodayisaminecraftcheat("Visual Setup", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Visual Setup")) / 2), 20.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("What visual setup path would you like to choose?", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("What visual setup path would you like to choose?")) / 2), 50.0f, 16777215);
                }
                else if (GuiMainMenu.momgetthecamera) {
                    this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/ThemeZues.png"));
                    Gui.zerodayisaminecraftcheat(20, 100 + GuiMainMenu.zerodayisaminecraftcheat, 0.0f, 0.0f, 125, 117, 127.0f, 117.0f);
                    this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/ThemeZeroDay.png"));
                    Gui.zerodayisaminecraftcheat(150, 100 + GuiMainMenu.zerodayisaminecraftcheat, 0.0f, 0.0f, 125, 117, 127.0f, 117.0f);
                    this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/ThemeFlux.png"));
                    Gui.zerodayisaminecraftcheat(280, 100 + GuiMainMenu.zerodayisaminecraftcheat, 0.0f, 0.0f, 128, 117, 127.0f, 117.0f);
                    Gui.zerodayisaminecraftcheat(145, 102 + GuiMainMenu.zerodayisaminecraftcheat, 147, 217 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(22, 217 + GuiMainMenu.zerodayisaminecraftcheat, 147, 219 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(275, 102 + GuiMainMenu.zerodayisaminecraftcheat, 277, 217 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(152, 217 + GuiMainMenu.zerodayisaminecraftcheat, 277, 219 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(408, 102 + GuiMainMenu.zerodayisaminecraftcheat, 410, 217 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(282, 217 + GuiMainMenu.zerodayisaminecraftcheat, 410, 219 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        this.z.clear();
                        this.y.clear();
                        this.flux();
                        this.momgetthecamera();
                        GuiMainMenu.pandora = true;
                    }
                    this.u.i.zerodayisaminecraftcheat("Theme Setup", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Welcome to ZeroDay")) / 2), 20.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("What Theme would you like to pick? (Colors only apply to ZeroDay Theme)", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("What Theme would you like to pick? (Colors only apply to ZeroDay Theme)")) / 2), 50.0f, 16777215);
                }
                else if (GuiMainMenu.a) {
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        this.y.clear();
                        this.flux();
                        this.c();
                        GuiMainMenu.pandora = true;
                    }
                    this.u.i.zerodayisaminecraftcheat("ArrayList Setup", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Arraylist Setup")) / 2), 20.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("Easily Configure your Arraylist here", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Easily Configure your Arraylist here")) / 2), 50.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("Background: " + ((zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera && zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux) ? "Chill" : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera ? "On" : "Off")), 260.0f, 70.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("Color: " + (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat ? "Rainbow" : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.vape ? "Solid" : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday ? "German" : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma ? "Category" : "Chill")))), 260.0f, 80.0f, 16777215);
                    if (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.pandora) {
                        Gui.zerodayisaminecraftcheat(180, 69, 178, 79, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(350000000L, 1.0f).getRGB() : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday ? -16733526 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma ? -597760 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat))));
                        Gui.zerodayisaminecraftcheat(189, 79, 187, 89, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(350000000L, 1.0f).getRGB() : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday ? -5592576 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma ? -1113857 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat))));
                        Gui.zerodayisaminecraftcheat(192, 89, 190, 99, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(350000000L, 1.0f).getRGB() : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday ? -5635926 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma ? -1113857 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat))));
                    }
                    if (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera) {
                        Gui.zerodayisaminecraftcheat(180, 69, 233, 79, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux ? -1728053248 : -1442840576);
                    }
                    this.u.i.zerodayisaminecraftcheat("PlayerESP", 182.0f, 70.0f, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(350000000L, 1.0f).getRGB() : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday ? -16733526 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma ? -597760 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(350000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat))));
                    if (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera) {
                        Gui.zerodayisaminecraftcheat(189, 79, 233, 89, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux ? -1728053248 : -1442840576);
                    }
                    this.u.i.zerodayisaminecraftcheat("Criticals", 191.0f, 80.0f, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(200000000L, 1.0f).getRGB() : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday ? -5592576 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma ? -1113857 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(200000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat))));
                    if (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.momgetthecamera) {
                        Gui.zerodayisaminecraftcheat(192, 89, 233, 99, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.flux ? -1728053248 : -1442840576);
                    }
                    this.u.i.zerodayisaminecraftcheat("KillAura", 194.0f, 90.0f, zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zerodayisaminecraftcheat ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(50000000L, 1.0f).getRGB() : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zeroday ? -5635926 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.sigma ? -1113857 : (zeroday.pandora.zerodayisaminecraftcheat.pandora.sigma.zues ? zeroday.pandora.zerodayisaminecraftcheat.h.h.sigma(50000000L, 1.0f).getRGB() : zeroday.pandora.zerodayisaminecraftcheat.pandora.h.zerodayisaminecraftcheat))));
                }
                else if (GuiMainMenu.b) {
                    this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/ZeroDayBlur.png"));
                    Gui.zerodayisaminecraftcheat(60, 100 + GuiMainMenu.zerodayisaminecraftcheat, 0.0f, 0.0f, 147, 117, 149.0f, 117.0f);
                    this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/ZeroDayNoBlur.png"));
                    Gui.zerodayisaminecraftcheat(220, 100 + GuiMainMenu.zerodayisaminecraftcheat, 0.0f, 0.0f, 147, 117, 149.0f, 117.0f);
                    Gui.zerodayisaminecraftcheat(207, 102 + GuiMainMenu.zerodayisaminecraftcheat, 209, 217 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(62, 217 + GuiMainMenu.zerodayisaminecraftcheat, 209, 219 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(367, 102 + GuiMainMenu.zerodayisaminecraftcheat, 369, 217 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    Gui.zerodayisaminecraftcheat(222, 217 + GuiMainMenu.zerodayisaminecraftcheat, 369, 219 + GuiMainMenu.zerodayisaminecraftcheat, -14671840);
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        this.y.clear();
                        this.flux();
                        this.d();
                        GuiMainMenu.pandora = true;
                    }
                    this.u.i.zerodayisaminecraftcheat("Blur Setup", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Blur Setup")) / 2), 20.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("Would you like a nice blur effect when in interfaces?", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Would you like a nice blur effect when in interfaces?")) / 2), 50.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("(Can cause lag if your PC isn't that powerful)", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("(Can cause lag if your PC isn't that powerful)")) / 2), 60.0f, 16777215);
                }
                else if (GuiMainMenu.c) {
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        this.y.clear();
                        this.flux();
                        this.e();
                        GuiMainMenu.pandora = true;
                    }
                    this.u.i.zerodayisaminecraftcheat("Module Setup", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("Blur Setup")) / 2), 20.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("What game/server are you planning on playing?", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("What game/server are you planning on playing?")) / 2), 50.0f, 16777215);
                }
                else if (GuiMainMenu.d) {
                    if (!GuiMainMenu.pandora && !this.K.zerodayisaminecraftcheat(1000L, true)) {
                        this.y.clear();
                        this.o();
                        GuiMainMenu.pandora = true;
                    }
                    final ArrayList<String> binds = new ArrayList<String>();
                    for (final zeroday.pandora.zerodayisaminecraftcheat.zerodayisaminecraftcheat m : zeroday.pandora.zerodayisaminecraftcheat.c.zerodayisaminecraftcheat.flux()) {
                        if (m.f() != 0) {
                            binds.add("�f[�a" + m.d() + " �f: �a" + Keyboard.getKeyName(m.f()) + "�f]");
                        }
                    }
                    int y = 0;
                    for (final String s12 : binds) {
                        this.u.i.zerodayisaminecraftcheat(String.valueOf(s12).replace("]]", "]").replace("[�f[", "[").replace(",", ""), (float)((s12.indexOf(s12) > 7) ? 120 : 10), (float)(10 + y * 10), 16777215);
                        ++y;
                    }
                    this.u.i.zerodayisaminecraftcheat("You're All Set", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("You're All Set")) / 2), 20.0f, 16777215);
                    this.u.i.zerodayisaminecraftcheat("ZeroDay Setup Complete!", (float)((sr.zerodayisaminecraftcheat() - this.u.i.zerodayisaminecraftcheat("ZeroDay Setup Complete!")) / 2), 50.0f, 16777215);
                }
            }
            super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        }
        else {
            GlStateManager.sigma();
            this.sigma(mouseX, mouseY, partialTicks);
            GlStateManager.pandora();
            final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
            final WorldRenderer worldrenderer = tessellator.sigma();
            final int i = 274;
            final int j = this.w / 2 - i / 2;
            final int k = 30;
            this.zerodayisaminecraftcheat(0, 0, this.w, this.x, -2130706433, 16777215);
            this.zerodayisaminecraftcheat(0, 0, this.w, this.x, 0, Integer.MIN_VALUE);
            this.u.I().zerodayisaminecraftcheat(GuiMainMenu.W);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            if (this.L < 1.0E-4) {
                this.zeroday(j + 0, k + 0, 0, 0, 99, 44);
                this.zeroday(j + 99, k + 0, 129, 0, 27, 44);
                this.zeroday(j + 99 + 26, k + 0, 126, 0, 3, 44);
                this.zeroday(j + 99 + 26 + 3, k + 0, 99, 0, 26, 44);
                this.zeroday(j + 155, k + 0, 0, 45, 155, 44);
            }
            else {
                this.zeroday(j + 0, k + 0, 0, 0, 155, 44);
                this.zeroday(j + 155, k + 0, 0, 45, 155, 44);
            }
            GlStateManager.v();
            GlStateManager.zeroday((float)(this.w / 2 + 90), 70.0f, 0.0f);
            GlStateManager.zeroday(-20.0f, 0.0f, 0.0f, 1.0f);
            float f = 1.8f - MathHelper.zues(MathHelper.zerodayisaminecraftcheat(Minecraft.C() % 1000L / 1000.0f * 3.1415927f * 2.0f) * 0.1f);
            f = f * 100.0f / (this.C.zerodayisaminecraftcheat(this.M) + 32);
            GlStateManager.zerodayisaminecraftcheat(f, f, f);
            Gui.zerodayisaminecraftcheat(this.C, this.M, 0, -8, -256);
            GlStateManager.w();
            String s13 = "Minecraft 1.8.8";
            if (this.u.n()) {
                s13 = String.valueOf(s13) + " Demo";
            }
            Gui.zeroday(this.C, s13, 2, this.x - 10, -1);
            final String s14 = "Copyright Mojang AB. Do not distribute!";
            Gui.zeroday(this.C, s14, this.w - this.C.zerodayisaminecraftcheat(s14) - 2, this.x - 10, -1);
            if (this.S != null && this.S.length() > 0) {
                Gui.zerodayisaminecraftcheat(this.aa - 2, this.ab - 2, this.ac + 2, this.ad - 1, 1428160512);
                Gui.zeroday(this.C, this.S, this.aa, this.ab, -1);
                Gui.zeroday(this.C, this.T, (this.w - this.Y) / 2, this.y.get(0).zues - 12, -1);
            }
            super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        synchronized (this.R) {
            if (this.S.length() > 0 && mouseX >= this.aa && mouseX <= this.ac && mouseY >= this.ab && mouseY <= this.ad) {
                final GuiConfirmOpenLink guiconfirmopenlink = new GuiConfirmOpenLink(this, this.U, 13, true);
                guiconfirmopenlink.vape();
                this.u.zerodayisaminecraftcheat(guiconfirmopenlink);
            }
        }
        // monitorexit(this.R)
    }
}

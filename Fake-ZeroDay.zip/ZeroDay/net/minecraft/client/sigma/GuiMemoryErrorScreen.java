// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.client.b.I18n;

public class GuiMemoryErrorScreen extends GuiScreen
{
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.clear();
        this.y.add(new GuiOptionButton(0, this.w / 2 - 155, this.x / 4 + 120 + 12, I18n.zerodayisaminecraftcheat("gui.toTitle", new Object[0])));
        this.y.add(new GuiOptionButton(1, this.w / 2 - 155 + 160, this.x / 4 + 120 + 12, I18n.zerodayisaminecraftcheat("menu.quit", new Object[0])));
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.vape == 0) {
            this.u.zerodayisaminecraftcheat(new GuiMainMenu());
        }
        else if (button.vape == 1) {
            this.u.f();
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, "Out of memory!", this.w / 2, this.x / 4 - 60 + 20, 16777215);
        Gui.zeroday(this.C, "Minecraft has run out of memory.", this.w / 2 - 140, this.x / 4 - 60 + 60 + 0, 10526880);
        Gui.zeroday(this.C, "This could be caused by a bug in the game or by the", this.w / 2 - 140, this.x / 4 - 60 + 60 + 18, 10526880);
        Gui.zeroday(this.C, "Java Virtual Machine not being allocated enough", this.w / 2 - 140, this.x / 4 - 60 + 60 + 27, 10526880);
        Gui.zeroday(this.C, "memory.", this.w / 2 - 140, this.x / 4 - 60 + 60 + 36, 10526880);
        Gui.zeroday(this.C, "To prevent level corruption, the current game has quit.", this.w / 2 - 140, this.x / 4 - 60 + 60 + 54, 10526880);
        Gui.zeroday(this.C, "We've tried to free up enough memory to let you go back to", this.w / 2 - 140, this.x / 4 - 60 + 60 + 63, 10526880);
        Gui.zeroday(this.C, "the main menu and back to playing, but this may not have worked.", this.w / 2 - 140, this.x / 4 - 60 + 60 + 72, 10526880);
        Gui.zeroday(this.C, "Please restart the game if you see this message again.", this.w / 2 - 140, this.x / 4 - 60 + 60 + 81, 10526880);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
}

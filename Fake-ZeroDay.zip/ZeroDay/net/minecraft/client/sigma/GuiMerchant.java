// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.Minecraft;
import net.minecraft.c.ItemStack;
import net.minecraft.client.a.EntityRenderer;
import net.minecraft.client.a.OpenGlHelper;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.c;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.p.MerchantRecipe;
import net.minecraft.client.a.GlStateManager;
import java.io.IOException;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C17PacketCustomPayload;
import net.minecraft.e.PacketBuffer;
import io.netty.buffer.Unpooled;
import net.minecraft.p.MerchantRecipeList;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.client.b.I18n;
import net.minecraft.b.Container;
import net.minecraft.b.ContainerMerchant;
import net.minecraft.q.World;
import net.minecraft.vape.vape.InventoryPlayer;
import org.apache.logging.log4j.LogManager;
import net.minecraft.o.IChatComponent;
import net.minecraft.vape.IMerchant;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;
import net.minecraft.client.sigma.zeroday.GuiContainer;

public class GuiMerchant extends GuiContainer
{
    private static final Logger zerodayisaminecraftcheat;
    private static final ResourceLocation zeroday;
    private IMerchant sigma;
    private zerodayisaminecraftcheat pandora;
    private zerodayisaminecraftcheat zues;
    private int flux;
    private IChatComponent vape;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
        zeroday = new ResourceLocation("textures/gui/container/villager.png");
    }
    
    public GuiMerchant(final InventoryPlayer p_i45500_1_, final IMerchant p_i45500_2_, final World worldIn) {
        super(new ContainerMerchant(p_i45500_1_, p_i45500_2_, worldIn));
        this.sigma = p_i45500_2_;
        this.vape = p_i45500_2_.sigma();
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        super.zerodayisaminecraftcheat();
        final int i = (this.w - this.b) / 2;
        final int j = (this.x - this.c) / 2;
        this.y.add(this.pandora = new zerodayisaminecraftcheat(1, i + 120 + 27, j + 24 - 1, true));
        this.y.add(this.zues = new zerodayisaminecraftcheat(2, i + 36 - 19, j + 24 - 1, false));
        this.pandora.momgetthecamera = false;
        this.zues.momgetthecamera = false;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY) {
        final String s = this.vape.momgetthecamera();
        this.C.zerodayisaminecraftcheat(s, this.b / 2 - this.C.zerodayisaminecraftcheat(s) / 2, 6, 4210752);
        this.C.zerodayisaminecraftcheat(I18n.zerodayisaminecraftcheat("container.inventory", new Object[0]), 8, this.c - 96 + 2, 4210752);
    }
    
    @Override
    public void sigma() {
        super.sigma();
        final MerchantRecipeList merchantrecipelist = this.sigma.zeroday(this.u.e);
        if (merchantrecipelist != null) {
            this.pandora.momgetthecamera = (this.flux < merchantrecipelist.size() - 1);
            this.zues.momgetthecamera = (this.flux > 0);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        boolean flag = false;
        if (button == this.pandora) {
            ++this.flux;
            final MerchantRecipeList merchantrecipelist = this.sigma.zeroday(this.u.e);
            if (merchantrecipelist != null && this.flux >= merchantrecipelist.size()) {
                this.flux = merchantrecipelist.size() - 1;
            }
            flag = true;
        }
        else if (button == this.zues) {
            --this.flux;
            if (this.flux < 0) {
                this.flux = 0;
            }
            flag = true;
        }
        if (flag) {
            ((ContainerMerchant)this.d).pandora(this.flux);
            final PacketBuffer packetbuffer = new PacketBuffer(Unpooled.buffer());
            packetbuffer.writeInt(this.flux);
            this.u.o().zerodayisaminecraftcheat(new C17PacketCustomPayload("MC|TrSel", packetbuffer));
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final float partialTicks, final int mouseX, final int mouseY) {
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.u.I().zerodayisaminecraftcheat(GuiMerchant.zeroday);
        final int i = (this.w - this.b) / 2;
        final int j = (this.x - this.c) / 2;
        this.zeroday(i, j, 0, 0, this.b, this.c);
        final MerchantRecipeList merchantrecipelist = this.sigma.zeroday(this.u.e);
        if (merchantrecipelist != null && !merchantrecipelist.isEmpty()) {
            final int k = this.flux;
            if (k < 0 || k >= merchantrecipelist.size()) {
                return;
            }
            final MerchantRecipe merchantrecipe = merchantrecipelist.get(k);
            if (merchantrecipe.momgetthecamera()) {
                this.u.I().zerodayisaminecraftcheat(GuiMerchant.zeroday);
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.flux();
                this.zeroday(this.e + 83, this.f + 21, 212, 0, 28, 21);
                this.zeroday(this.e + 83, this.f + 51, 212, 0, 28, 21);
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        final MerchantRecipeList merchantrecipelist = this.sigma.zeroday(this.u.e);
        if (merchantrecipelist != null && !merchantrecipelist.isEmpty()) {
            final int i = (this.w - this.b) / 2;
            final int j = (this.x - this.c) / 2;
            final int k = this.flux;
            final MerchantRecipe merchantrecipe = merchantrecipelist.get(k);
            final ItemStack itemstack = merchantrecipe.zerodayisaminecraftcheat();
            final ItemStack itemstack2 = merchantrecipe.zeroday();
            final ItemStack itemstack3 = merchantrecipe.pandora();
            GlStateManager.v();
            RenderHelper.sigma();
            GlStateManager.flux();
            GlStateManager.s();
            GlStateManager.vape();
            GlStateManager.zues();
            this.v.zerodayisaminecraftcheat = 100.0f;
            this.v.zeroday(itemstack, i + 36, j + 24);
            this.v.zerodayisaminecraftcheat(this.C, itemstack, i + 36, j + 24);
            if (itemstack2 != null) {
                this.v.zeroday(itemstack2, i + 62, j + 24);
                this.v.zerodayisaminecraftcheat(this.C, itemstack2, i + 62, j + 24);
            }
            this.v.zeroday(itemstack3, i + 120, j + 24);
            this.v.zerodayisaminecraftcheat(this.C, itemstack3, i + 120, j + 24);
            this.v.zerodayisaminecraftcheat = 0.0f;
            GlStateManager.flux();
            if (this.sigma(36, 24, 16, 16, mouseX, mouseY) && itemstack != null) {
                this.zeroday(itemstack, mouseX, mouseY);
            }
            else if (itemstack2 != null && this.sigma(62, 24, 16, 16, mouseX, mouseY) && itemstack2 != null) {
                this.zeroday(itemstack2, mouseX, mouseY);
            }
            else if (itemstack3 != null && this.sigma(120, 24, 16, 16, mouseX, mouseY) && itemstack3 != null) {
                this.zeroday(itemstack3, mouseX, mouseY);
            }
            else if (merchantrecipe.momgetthecamera() && (this.sigma(83, 21, 28, 21, mouseX, mouseY) || this.sigma(83, 51, 28, 21, mouseX, mouseY))) {
                this.zerodayisaminecraftcheat(I18n.zerodayisaminecraftcheat("merchant.deprecated", new Object[0]), mouseX, mouseY);
            }
            if (zeroday.pandora.zerodayisaminecraftcheat.pandora.c.zerodayisaminecraftcheat && OpenGlHelper.G && this.u.V() instanceof EntityPlayer) {
                if (this.u.m.vape != null) {
                    this.u.m.vape.zerodayisaminecraftcheat();
                }
                this.u.m.b = 5;
                if (this.u.m.b != EntityRenderer.a) {
                    this.u.m.zerodayisaminecraftcheat(EntityRenderer.momgetthecamera[18]);
                }
            }
            GlStateManager.w();
            GlStateManager.zues();
            GlStateManager.b();
            RenderHelper.zeroday();
        }
    }
    
    public IMerchant flux() {
        return this.sigma;
    }
    
    static class zerodayisaminecraftcheat extends GuiButton
    {
        private final boolean e;
        
        public zerodayisaminecraftcheat(final int buttonID, final int x, final int y, final boolean p_i1095_4_) {
            super(buttonID, x, y, 12, 19, "");
            this.e = p_i1095_4_;
        }
        
        @Override
        public void zerodayisaminecraftcheat(final Minecraft mc, final int mouseX, final int mouseY) {
            if (this.a) {
                mc.I().zerodayisaminecraftcheat(GuiMerchant.zeroday);
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                final boolean flag = mouseX >= this.pandora && mouseY >= this.zues && mouseX < this.pandora + this.zeroday && mouseY < this.zues + this.sigma;
                int i = 0;
                int j = 176;
                if (!this.momgetthecamera) {
                    j += this.zeroday * 2;
                }
                else if (flag) {
                    j += this.zeroday;
                }
                if (!this.e) {
                    i += this.sigma;
                }
                this.zeroday(this.pandora, this.zues, j, i, this.zeroday, this.sigma);
            }
        }
    }
}

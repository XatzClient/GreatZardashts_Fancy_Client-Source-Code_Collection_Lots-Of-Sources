// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.zues.GuiConnecting;
import zeroday.pandora.zerodayisaminecraftcheat.h.ab;
import com.google.common.collect.Lists;
import com.google.common.base.Splitter;
import zeroday.zerodayisaminecraftcheat.vape;
import java.util.List;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.V;
import net.minecraft.client.b.I18n;
import java.io.IOException;
import org.lwjgl.input.Keyboard;
import org.apache.logging.log4j.LogManager;
import net.minecraft.client.flux.LanServerDetector;
import net.minecraft.client.zues.ServerData;
import net.minecraft.client.zues.ServerList;
import net.minecraft.client.flux.OldServerPinger;
import org.apache.logging.log4j.Logger;

public class GuiMultiplayer extends GuiScreen implements GuiYesNoCallback
{
    private static final Logger zeroday;
    private final OldServerPinger sigma;
    private GuiScreen pandora;
    public ServerSelectionList zerodayisaminecraftcheat;
    private ServerList zues;
    private GuiButton flux;
    private GuiButton vape;
    private GuiButton momgetthecamera;
    private boolean a;
    private boolean b;
    private boolean c;
    private boolean d;
    private String e;
    private ServerData f;
    private LanServerDetector.zeroday g;
    private LanServerDetector.sigma h;
    private boolean i;
    
    static {
        zeroday = LogManager.getLogger();
    }
    
    public GuiMultiplayer(final GuiScreen parentScreen) {
        this.sigma = new OldServerPinger();
        this.pandora = parentScreen;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        Keyboard.enableRepeatEvents(true);
        this.y.clear();
        if (!this.i) {
            this.i = true;
            (this.zues = new ServerList(this.u)).zerodayisaminecraftcheat();
            this.g = new LanServerDetector.zeroday();
            try {
                (this.h = new LanServerDetector.sigma(this.g)).start();
            }
            catch (Exception exception) {
                GuiMultiplayer.zeroday.warn("Unable to start LAN server detection: " + exception.getMessage());
            }
            (this.zerodayisaminecraftcheat = new ServerSelectionList(this, this.u, this.w, this.x, 32, this.x - 64, 36)).zerodayisaminecraftcheat(this.zues);
        }
        else {
            this.zerodayisaminecraftcheat.zeroday(this.w, this.x, 32, this.x - 64);
        }
        this.flux();
    }
    
    @Override
    public void b_() throws IOException {
        super.b_();
        this.zerodayisaminecraftcheat.momgetthecamera();
    }
    
    public void flux() {
        this.y.add(this.flux = new GuiButton(7, this.w / 2 - 154, this.x - 28, 70, 20, I18n.zerodayisaminecraftcheat("selectServer.edit", new Object[0])));
        this.y.add(this.momgetthecamera = new GuiButton(2, this.w / 2 - 74, this.x - 28, 70, 20, I18n.zerodayisaminecraftcheat("selectServer.delete", new Object[0])));
        this.y.add(this.vape = new GuiButton(1, this.w / 2 - 154, this.x - 52, 100, 20, I18n.zerodayisaminecraftcheat("selectServer.select", new Object[0])));
        this.y.add(new GuiButton(4, this.w / 2 - 50, this.x - 52, 100, 20, I18n.zerodayisaminecraftcheat("selectServer.direct", new Object[0])));
        this.y.add(new GuiButton(3, this.w / 2 + 4 + 50, this.x - 52, 100, 20, I18n.zerodayisaminecraftcheat("selectServer.add", new Object[0])));
        this.y.add(new GuiButton(8, this.w / 2 + 4, this.x - 28, 70, 20, I18n.zerodayisaminecraftcheat("selectServer.refresh", new Object[0])));
        this.y.add(new GuiButton(0, this.w / 2 + 4 + 76, this.x - 28, 75, 20, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        if (!V.zerodayisaminecraftcheat) {
            this.y.add(new GuiButton(1738, this.w - 68, 6, 62, 20, I18n.zerodayisaminecraftcheat("Alt Manager", new Object[0])));
        }
        this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zues());
    }
    
    @Override
    public void sigma() {
        super.sigma();
        if (this.g.zerodayisaminecraftcheat()) {
            final List<LanServerDetector.zerodayisaminecraftcheat> list = this.g.sigma();
            this.g.zeroday();
            this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(list);
        }
        this.sigma.zerodayisaminecraftcheat();
    }
    
    @Override
    public void u_() {
        Keyboard.enableRepeatEvents(false);
        if (this.h != null) {
            this.h.interrupt();
            this.h = null;
        }
        this.sigma.zeroday();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            final GuiListExtended.zerodayisaminecraftcheat guilistextended$iguilistentry = (this.zerodayisaminecraftcheat.zues() < 0) ? null : this.zerodayisaminecraftcheat.zeroday(this.zerodayisaminecraftcheat.zues());
            if (button.vape == 2 && guilistextended$iguilistentry instanceof ServerListEntryNormal) {
                final String s4 = ((ServerListEntryNormal)guilistextended$iguilistentry).zerodayisaminecraftcheat().zerodayisaminecraftcheat;
                if (s4 != null) {
                    this.a = true;
                    final String s5 = I18n.zerodayisaminecraftcheat("selectServer.deleteQuestion", new Object[0]);
                    final String s6 = "'" + s4 + "' " + I18n.zerodayisaminecraftcheat("selectServer.deleteWarning", new Object[0]);
                    final String s7 = I18n.zerodayisaminecraftcheat("selectServer.deleteButton", new Object[0]);
                    final String s8 = I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0]);
                    final GuiYesNo guiyesno = new GuiYesNo(this, s5, s6, s7, s8, this.zerodayisaminecraftcheat.zues());
                    this.u.zerodayisaminecraftcheat(guiyesno);
                }
            }
            else if (button.vape == 1) {
                this.vape();
            }
            else if (button.vape == 4) {
                this.d = true;
                this.u.zerodayisaminecraftcheat(new GuiScreenServerList(this, this.f = new ServerData(I18n.zerodayisaminecraftcheat("selectServer.defaultName", new Object[0]), "", false)));
            }
            else if (button.vape == 3) {
                this.b = true;
                this.u.zerodayisaminecraftcheat(new GuiScreenAddServer(this, this.f = new ServerData(I18n.zerodayisaminecraftcheat("selectServer.defaultName", new Object[0]), "", false)));
            }
            else if (button.vape == 7 && guilistextended$iguilistentry instanceof ServerListEntryNormal) {
                this.c = true;
                final ServerData serverdata = ((ServerListEntryNormal)guilistextended$iguilistentry).zerodayisaminecraftcheat();
                (this.f = new ServerData(serverdata.zerodayisaminecraftcheat, serverdata.zeroday, false)).zerodayisaminecraftcheat(serverdata);
                this.u.zerodayisaminecraftcheat(new GuiScreenAddServer(this, this.f));
            }
            else if (button.vape == 0) {
                this.u.zerodayisaminecraftcheat(this.pandora);
            }
            else if (button.vape == 8) {
                this.b();
            }
            else if (button.vape == 1738) {
                this.u.zerodayisaminecraftcheat(new vape());
            }
            else {
                final int vape = button.vape;
            }
        }
    }
    
    private void b() {
        this.u.zerodayisaminecraftcheat(new GuiMultiplayer(this.pandora));
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean result, final int id) {
        final GuiListExtended.zerodayisaminecraftcheat guilistextended$iguilistentry = (this.zerodayisaminecraftcheat.zues() < 0) ? null : this.zerodayisaminecraftcheat.zeroday(this.zerodayisaminecraftcheat.zues());
        if (this.a) {
            this.a = false;
            if (result && guilistextended$iguilistentry instanceof ServerListEntryNormal) {
                this.zues.zeroday(this.zerodayisaminecraftcheat.zues());
                this.zues.zeroday();
                this.zerodayisaminecraftcheat.sigma(-1);
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues);
            }
            this.u.zerodayisaminecraftcheat(this);
        }
        else if (this.d) {
            this.d = false;
            if (result) {
                this.zerodayisaminecraftcheat(this.f);
            }
            else {
                this.u.zerodayisaminecraftcheat(this);
            }
        }
        else if (this.b) {
            this.b = false;
            if (result) {
                this.zues.zerodayisaminecraftcheat(this.f);
                this.zues.zeroday();
                this.zerodayisaminecraftcheat.sigma(-1);
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues);
            }
            this.u.zerodayisaminecraftcheat(this);
        }
        else if (this.c) {
            this.c = false;
            if (result && guilistextended$iguilistentry instanceof ServerListEntryNormal) {
                final ServerData serverdata = ((ServerListEntryNormal)guilistextended$iguilistentry).zerodayisaminecraftcheat();
                serverdata.zerodayisaminecraftcheat = this.f.zerodayisaminecraftcheat;
                serverdata.zeroday = this.f.zeroday;
                serverdata.zerodayisaminecraftcheat(this.f);
                this.zues.zeroday();
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues);
            }
            this.u.zerodayisaminecraftcheat(this);
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        final int i = this.zerodayisaminecraftcheat.zues();
        final GuiListExtended.zerodayisaminecraftcheat guilistextended$iguilistentry = (i < 0) ? null : this.zerodayisaminecraftcheat.zeroday(i);
        if (keyCode == 63) {
            this.b();
        }
        else if (i >= 0) {
            if (keyCode == 200) {
                if (m()) {
                    if (i > 0 && guilistextended$iguilistentry instanceof ServerListEntryNormal) {
                        this.zues.zerodayisaminecraftcheat(i, i - 1);
                        this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zues() - 1);
                        this.zerodayisaminecraftcheat.vape(-this.zerodayisaminecraftcheat.h());
                        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues);
                    }
                }
                else if (i > 0) {
                    this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zues() - 1);
                    this.zerodayisaminecraftcheat.vape(-this.zerodayisaminecraftcheat.h());
                    if (this.zerodayisaminecraftcheat.zeroday(this.zerodayisaminecraftcheat.zues()) instanceof ServerListEntryLanScan) {
                        if (this.zerodayisaminecraftcheat.zues() > 0) {
                            this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zerodayisaminecraftcheat() - 1);
                            this.zerodayisaminecraftcheat.vape(-this.zerodayisaminecraftcheat.h());
                        }
                        else {
                            this.zerodayisaminecraftcheat(-1);
                        }
                    }
                }
                else {
                    this.zerodayisaminecraftcheat(-1);
                }
            }
            else if (keyCode == 208) {
                if (m()) {
                    if (i < this.zues.sigma() - 1) {
                        this.zues.zerodayisaminecraftcheat(i, i + 1);
                        this.zerodayisaminecraftcheat(i + 1);
                        this.zerodayisaminecraftcheat.vape(this.zerodayisaminecraftcheat.h());
                        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues);
                    }
                }
                else if (i < this.zerodayisaminecraftcheat.zerodayisaminecraftcheat()) {
                    this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zues() + 1);
                    this.zerodayisaminecraftcheat.vape(this.zerodayisaminecraftcheat.h());
                    if (this.zerodayisaminecraftcheat.zeroday(this.zerodayisaminecraftcheat.zues()) instanceof ServerListEntryLanScan) {
                        if (this.zerodayisaminecraftcheat.zues() < this.zerodayisaminecraftcheat.zerodayisaminecraftcheat() - 1) {
                            this.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.zerodayisaminecraftcheat() + 1);
                            this.zerodayisaminecraftcheat.vape(this.zerodayisaminecraftcheat.h());
                        }
                        else {
                            this.zerodayisaminecraftcheat(-1);
                        }
                    }
                }
                else {
                    this.zerodayisaminecraftcheat(-1);
                }
            }
            else if (keyCode != 28 && keyCode != 156) {
                super.zerodayisaminecraftcheat(typedChar, keyCode);
            }
            else {
                this.zerodayisaminecraftcheat(this.y.get(2));
            }
        }
        else {
            super.zerodayisaminecraftcheat(typedChar, keyCode);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.e = null;
        this.k();
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        if (GuiIngameMenu.sigma && !GuiIngameMenu.pandora.isEmpty()) {
            Gui.zeroday(this.u.i, "MultiServer Connections: " + GuiIngameMenu.pandora, 5, 5, -1);
        }
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("multiplayer.title", new Object[0]), this.w / 2, 20, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        if (this.e != null) {
            this.zerodayisaminecraftcheat(Lists.newArrayList(Splitter.on("\n").split((CharSequence)this.e)), mouseX, mouseY);
        }
    }
    
    public void vape() {
        final GuiListExtended.zerodayisaminecraftcheat guilistextended$iguilistentry = (this.zerodayisaminecraftcheat.zues() < 0) ? null : this.zerodayisaminecraftcheat.zeroday(this.zerodayisaminecraftcheat.zues());
        ab.zerodayisaminecraftcheat(guilistextended$iguilistentry, this);
        if (guilistextended$iguilistentry instanceof ServerListEntryNormal) {
            this.zerodayisaminecraftcheat(((ServerListEntryNormal)guilistextended$iguilistentry).zerodayisaminecraftcheat());
        }
        else if (guilistextended$iguilistentry instanceof ServerListEntryLanDetected) {
            final LanServerDetector.zerodayisaminecraftcheat lanserverdetector$lanserver = ((ServerListEntryLanDetected)guilistextended$iguilistentry).zerodayisaminecraftcheat();
            this.zerodayisaminecraftcheat(new ServerData(lanserverdetector$lanserver.zerodayisaminecraftcheat(), lanserverdetector$lanserver.zeroday(), true));
        }
    }
    
    public void zerodayisaminecraftcheat(final ServerData server) {
        this.u.zerodayisaminecraftcheat(new GuiConnecting(this, this.u, server));
    }
    
    public void zerodayisaminecraftcheat(final int index) {
        this.zerodayisaminecraftcheat.sigma(index);
        final GuiListExtended.zerodayisaminecraftcheat guilistextended$iguilistentry = (index < 0) ? null : this.zerodayisaminecraftcheat.zeroday(index);
        this.vape.momgetthecamera = false;
        this.flux.momgetthecamera = false;
        this.momgetthecamera.momgetthecamera = false;
        if (guilistextended$iguilistentry != null && !(guilistextended$iguilistentry instanceof ServerListEntryLanScan)) {
            this.vape.momgetthecamera = true;
            if (guilistextended$iguilistentry instanceof ServerListEntryNormal) {
                this.flux.momgetthecamera = true;
                this.momgetthecamera.momgetthecamera = true;
            }
        }
    }
    
    public OldServerPinger momgetthecamera() {
        return this.sigma;
    }
    
    public void zerodayisaminecraftcheat(final String p_146793_1_) {
        this.e = p_146793_1_;
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        this.zerodayisaminecraftcheat.zeroday(mouseX, mouseY, mouseButton);
    }
    
    @Override
    protected void zeroday(final int mouseX, final int mouseY, final int state) {
        super.zeroday(mouseX, mouseY, state);
        this.zerodayisaminecraftcheat.sigma(mouseX, mouseY, state);
    }
    
    public ServerList a() {
        return this.zues;
    }
    
    public boolean zerodayisaminecraftcheat(final ServerListEntryNormal p_175392_1_, final int p_175392_2_) {
        return p_175392_2_ > 0;
    }
    
    public boolean zeroday(final ServerListEntryNormal p_175394_1_, final int p_175394_2_) {
        return p_175394_2_ < this.zues.sigma() - 1;
    }
    
    public void zerodayisaminecraftcheat(final ServerListEntryNormal p_175391_1_, final int p_175391_2_, final boolean p_175391_3_) {
        final int i = p_175391_3_ ? 0 : (p_175391_2_ - 1);
        this.zues.zerodayisaminecraftcheat(p_175391_2_, i);
        if (this.zerodayisaminecraftcheat.zues() == p_175391_2_) {
            this.zerodayisaminecraftcheat(i);
        }
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues);
    }
    
    public void zeroday(final ServerListEntryNormal p_175393_1_, final int p_175393_2_, final boolean p_175393_3_) {
        final int i = p_175393_3_ ? (this.zues.sigma() - 1) : (p_175393_2_ + 1);
        this.zues.zerodayisaminecraftcheat(p_175393_2_, i);
        if (this.zerodayisaminecraftcheat.zues() == p_175393_2_) {
            this.zerodayisaminecraftcheat(i);
        }
        this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(this.zues);
    }
}

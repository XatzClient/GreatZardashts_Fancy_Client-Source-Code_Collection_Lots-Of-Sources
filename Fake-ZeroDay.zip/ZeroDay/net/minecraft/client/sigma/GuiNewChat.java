// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.o.ChatComponentText;
import java.util.Iterator;
import net.minecraft.o.IChatComponent;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.MathHelper;
import net.minecraft.vape.vape.EntityPlayer;
import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import java.util.List;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.Logger;

public class GuiNewChat extends Gui
{
    private static final Logger zerodayisaminecraftcheat;
    private final Minecraft zeroday;
    private final List<String> sigma;
    private final List<ChatLine> pandora;
    private final List<ChatLine> zues;
    private int flux;
    private boolean vape;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
    }
    
    public GuiNewChat(final Minecraft mcIn) {
        this.sigma = (List<String>)Lists.newArrayList();
        this.pandora = (List<ChatLine>)Lists.newArrayList();
        this.zues = (List<ChatLine>)Lists.newArrayList();
        this.zeroday = mcIn;
    }
    
    public void zerodayisaminecraftcheat(final int p_146230_1_) {
        if (this.zeroday.r.e != EntityPlayer.zerodayisaminecraftcheat.sigma) {
            final int i = this.a();
            boolean flag = false;
            int j = 0;
            final int k = this.zues.size();
            final float f = this.zeroday.r.i * 0.9f + 0.1f;
            if (k > 0) {
                if (this.zues()) {
                    flag = true;
                }
                final float f2 = this.momgetthecamera();
                final int l = MathHelper.flux(this.flux() / f2);
                GlStateManager.v();
                GlStateManager.zeroday(2.0f, 20.0f, 0.0f);
                GlStateManager.zerodayisaminecraftcheat(f2, f2, 1.0f);
                for (int i2 = 0; i2 + this.flux < this.zues.size() && i2 < i; ++i2) {
                    final ChatLine chatline = this.zues.get(i2 + this.flux);
                    if (chatline != null) {
                        final int j2 = p_146230_1_ - chatline.zeroday();
                        if (j2 < 200 || flag) {
                            double d0 = j2 / 200.0;
                            d0 = 1.0 - d0;
                            d0 *= 10.0;
                            d0 = MathHelper.zerodayisaminecraftcheat(d0, 0.0, 1.0);
                            d0 *= d0;
                            int l2 = (int)(255.0 * d0);
                            if (flag) {
                                l2 = 255;
                            }
                            l2 *= (int)f;
                            ++j;
                            if (l2 > 3) {
                                final int i3 = 0;
                                final int j3 = -i2 * 9;
                                Gui.zerodayisaminecraftcheat(i3, j3 - 9, i3 + l + 4, j3, l2 / 2 << 24);
                                final String s = chatline.zerodayisaminecraftcheat().a();
                                GlStateManager.d();
                                this.zeroday.i.zerodayisaminecraftcheat(s, (float)i3, (float)(j3 - 8), 16777215 + (l2 << 24));
                                GlStateManager.sigma();
                                GlStateManager.c();
                            }
                        }
                    }
                }
                if (flag) {
                    final int k2 = this.zeroday.i.zeroday;
                    GlStateManager.zeroday(-3.0f, 0.0f, 0.0f);
                    final int l3 = k * k2 + k;
                    final int i4 = j * k2 + j;
                    final int j4 = this.flux * i4 / k;
                    final int k3 = i4 * i4 / l3;
                    if (l3 != i4) {
                        final int k4 = (j4 > 0) ? 170 : 96;
                        final int l4 = this.vape ? 13382451 : 3355562;
                        Gui.zerodayisaminecraftcheat(0, -j4, 2, -j4 - k3, l4 + (k4 << 24));
                        Gui.zerodayisaminecraftcheat(2, -j4, 1, -j4 - k3, 13421772 + (k4 << 24));
                    }
                }
                GlStateManager.w();
            }
        }
    }
    
    public void zerodayisaminecraftcheat() {
        this.zues.clear();
        this.pandora.clear();
        this.sigma.clear();
    }
    
    public void zerodayisaminecraftcheat(final IChatComponent p_146227_1_) {
        this.zerodayisaminecraftcheat(p_146227_1_, 0);
    }
    
    public void zerodayisaminecraftcheat(final IChatComponent p_146234_1_, final int p_146234_2_) {
        this.zerodayisaminecraftcheat(p_146234_1_, p_146234_2_, this.zeroday.o.zues(), false);
        GuiNewChat.zerodayisaminecraftcheat.info("[CHAT] " + p_146234_1_.momgetthecamera());
    }
    
    private void zerodayisaminecraftcheat(final IChatComponent p_146237_1_, final int p_146237_2_, final int p_146237_3_, final boolean p_146237_4_) {
        if (p_146237_2_ != 0) {
            this.sigma(p_146237_2_);
        }
        final int i = MathHelper.pandora(this.flux() / this.momgetthecamera());
        final List<IChatComponent> list = GuiUtilRenderComponents.zerodayisaminecraftcheat(p_146237_1_, i, this.zeroday.i, false, false);
        final boolean flag = this.zues();
        for (final IChatComponent ichatcomponent : list) {
            if (flag && this.flux > 0) {
                this.vape = true;
                this.zeroday(1);
            }
            this.zues.add(0, new ChatLine(p_146237_3_, ichatcomponent, p_146237_2_));
        }
        while (this.zues.size() > 100) {
            this.zues.remove(this.zues.size() - 1);
        }
        if (!p_146237_4_) {
            this.pandora.add(0, new ChatLine(p_146237_3_, p_146237_1_, p_146237_2_));
            while (this.pandora.size() > 100) {
                this.pandora.remove(this.pandora.size() - 1);
            }
        }
    }
    
    public void zeroday() {
        this.zues.clear();
        this.pandora();
        for (int i = this.pandora.size() - 1; i >= 0; --i) {
            final ChatLine chatline = this.pandora.get(i);
            this.zerodayisaminecraftcheat(chatline.zerodayisaminecraftcheat(), chatline.sigma(), chatline.zeroday(), true);
        }
    }
    
    public List<String> sigma() {
        return this.sigma;
    }
    
    public void zerodayisaminecraftcheat(final String p_146239_1_) {
        if (this.sigma.isEmpty() || !this.sigma.get(this.sigma.size() - 1).equals(p_146239_1_)) {
            this.sigma.add(p_146239_1_);
        }
    }
    
    public void pandora() {
        this.flux = 0;
        this.vape = false;
    }
    
    public void zeroday(final int p_146229_1_) {
        this.flux += p_146229_1_;
        final int i = this.zues.size();
        if (this.flux > i - this.a()) {
            this.flux = i - this.a();
        }
        if (this.flux <= 0) {
            this.flux = 0;
            this.vape = false;
        }
    }
    
    public IChatComponent zerodayisaminecraftcheat(final int p_146236_1_, final int p_146236_2_) {
        if (!this.zues()) {
            return null;
        }
        final ScaledResolution scaledresolution = new ScaledResolution(this.zeroday);
        final int i = scaledresolution.zues();
        final float f = this.momgetthecamera();
        int j = p_146236_1_ / i - 3;
        int k = p_146236_2_ / i - 27;
        j = MathHelper.pandora(j / f);
        k = MathHelper.pandora(k / f);
        if (j < 0 || k < 0) {
            return null;
        }
        final int l = Math.min(this.a(), this.zues.size());
        if (j <= MathHelper.pandora(this.flux() / this.momgetthecamera()) && k < this.zeroday.i.zeroday * l + l) {
            final int i2 = k / this.zeroday.i.zeroday + this.flux;
            if (i2 >= 0 && i2 < this.zues.size()) {
                final ChatLine chatline = this.zues.get(i2);
                int j2 = 0;
                for (final IChatComponent ichatcomponent : chatline.zerodayisaminecraftcheat()) {
                    if (ichatcomponent instanceof ChatComponentText) {
                        j2 += this.zeroday.i.zerodayisaminecraftcheat(GuiUtilRenderComponents.zerodayisaminecraftcheat(((ChatComponentText)ichatcomponent).zerodayisaminecraftcheat(), false));
                        if (j2 > j) {
                            return ichatcomponent;
                        }
                        continue;
                    }
                }
            }
            return null;
        }
        return null;
    }
    
    public boolean zues() {
        return this.zeroday.k instanceof GuiChat;
    }
    
    public void sigma(final int p_146242_1_) {
        Iterator<ChatLine> iterator = this.zues.iterator();
        while (iterator.hasNext()) {
            final ChatLine chatline = iterator.next();
            if (chatline.sigma() == p_146242_1_) {
                iterator.remove();
            }
        }
        iterator = this.pandora.iterator();
        while (iterator.hasNext()) {
            final ChatLine chatline2 = iterator.next();
            if (chatline2.sigma() == p_146242_1_) {
                iterator.remove();
                break;
            }
        }
    }
    
    public int flux() {
        return zerodayisaminecraftcheat(this.zeroday.r.x);
    }
    
    public int vape() {
        return zeroday(this.zues() ? this.zeroday.r.z : this.zeroday.r.y);
    }
    
    public float momgetthecamera() {
        return this.zeroday.r.w;
    }
    
    public static int zerodayisaminecraftcheat(final float p_146233_0_) {
        final int i = 320;
        final int j = 40;
        return MathHelper.pandora(p_146233_0_ * (i - j) + j);
    }
    
    public static int zeroday(final float p_146243_0_) {
        final int i = 180;
        final int j = 20;
        return MathHelper.pandora(p_146243_0_ * (i - j) + j);
    }
    
    public int a() {
        return this.vape() / 9;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.MathHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.c.GameSettings;

public class GuiOptionSlider extends GuiButton
{
    private float f;
    public boolean e;
    private GameSettings.zeroday g;
    private final float h;
    private final float i;
    
    public GuiOptionSlider(final int p_i45016_1_, final int p_i45016_2_, final int p_i45016_3_, final GameSettings.zeroday p_i45016_4_) {
        this(p_i45016_1_, p_i45016_2_, p_i45016_3_, p_i45016_4_, 0.0f, 1.0f);
    }
    
    public GuiOptionSlider(final int p_i45017_1_, final int p_i45017_2_, final int p_i45017_3_, final GameSettings.zeroday p_i45017_4_, final float p_i45017_5_, final float p_i45017_6_) {
        super(p_i45017_1_, p_i45017_2_, p_i45017_3_, 150, 20, "");
        this.f = 1.0f;
        this.g = p_i45017_4_;
        this.h = p_i45017_5_;
        this.i = p_i45017_6_;
        final Minecraft minecraft = Minecraft.s();
        this.f = p_i45017_4_.zeroday(minecraft.r.zerodayisaminecraftcheat(p_i45017_4_));
        this.flux = minecraft.r.sigma(p_i45017_4_);
    }
    
    @Override
    protected int zerodayisaminecraftcheat(final boolean mouseOver) {
        return 0;
    }
    
    @Override
    protected void zeroday(final Minecraft mc, final int mouseX, final int mouseY) {
        if (this.a) {
            if (this.e) {
                this.f = (mouseX - (this.pandora + 4)) / (float)(this.zeroday - 8);
                this.f = MathHelper.zerodayisaminecraftcheat(this.f, 0.0f, 1.0f);
                final float f = this.g.sigma(this.f);
                mc.r.zerodayisaminecraftcheat(this.g, f);
                this.f = this.g.zeroday(f);
                this.flux = mc.r.sigma(this.g);
            }
            mc.I().zerodayisaminecraftcheat(GuiOptionSlider.zerodayisaminecraftcheat);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            this.zeroday(this.pandora + (int)(this.f * (this.zeroday - 8)), this.zues, 0, 66, 4, 20);
            this.zeroday(this.pandora + (int)(this.f * (this.zeroday - 8)) + 4, this.zues, 196, 66, 4, 20);
        }
    }
    
    @Override
    public boolean sigma(final Minecraft mc, final int mouseX, final int mouseY) {
        if (super.sigma(mc, mouseX, mouseY)) {
            this.f = (mouseX - (this.pandora + 4)) / (float)(this.zeroday - 8);
            this.f = MathHelper.zerodayisaminecraftcheat(this.f, 0.0f, 1.0f);
            mc.r.zerodayisaminecraftcheat(this.g, this.g.sigma(this.f));
            this.flux = mc.r.sigma(this.g);
            return this.e = true;
        }
        return false;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY) {
        this.e = false;
    }
}

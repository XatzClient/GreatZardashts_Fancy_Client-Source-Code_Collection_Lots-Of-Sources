// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.client.e.IStream;
import net.minecraft.client.sigma.pandora.GuiStreamUnavailable;
import net.minecraft.client.sigma.pandora.GuiStreamOptions;
import net.minecraft.o.IChatComponent;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.o.ChatComponentText;
import net.minecraft.q.EnumDifficulty;
import net.minecraft.client.zerodayisaminecraftcheat.SoundEventAccessorComposite;
import net.minecraft.client.zerodayisaminecraftcheat.ISound;
import net.minecraft.client.zerodayisaminecraftcheat.PositionedSoundRecord;
import net.minecraft.client.zerodayisaminecraftcheat.SoundCategory;
import net.minecraft.client.zerodayisaminecraftcheat.SoundHandler;
import net.minecraft.client.b.I18n;
import net.minecraft.client.c.GameSettings;

public class GuiOptions extends GuiScreen implements GuiYesNoCallback
{
    private static final GameSettings.zeroday[] zeroday;
    private final GuiScreen sigma;
    private final GameSettings pandora;
    private GuiButton zues;
    private GuiLockIconButton flux;
    protected String zerodayisaminecraftcheat;
    
    static {
        zeroday = new GameSettings.zeroday[] { GameSettings.zeroday.sigma };
    }
    
    public GuiOptions(final GuiScreen p_i1046_1_, final GameSettings p_i1046_2_) {
        this.zerodayisaminecraftcheat = "Options";
        this.sigma = p_i1046_1_;
        this.pandora = p_i1046_2_;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        int i = 0;
        this.zerodayisaminecraftcheat = I18n.zerodayisaminecraftcheat("options.title", new Object[0]);
        GameSettings.zeroday[] zeroday;
        for (int length = (zeroday = GuiOptions.zeroday).length, j = 0; j < length; ++j) {
            final GameSettings.zeroday gamesettings$options = zeroday[j];
            if (gamesettings$options.zerodayisaminecraftcheat()) {
                this.y.add(new GuiOptionSlider(gamesettings$options.sigma(), this.w / 2 - 155 + i % 2 * 160, this.x / 6 - 12 + 24 * (i >> 1), gamesettings$options));
            }
            else {
                final GuiOptionButton guioptionbutton = new GuiOptionButton(gamesettings$options.sigma(), this.w / 2 - 155 + i % 2 * 160, this.x / 6 - 12 + 24 * (i >> 1), gamesettings$options, this.pandora.sigma(gamesettings$options));
                this.y.add(guioptionbutton);
            }
            ++i;
        }
        if (this.u.a != null) {
            final EnumDifficulty enumdifficulty = this.u.a.F();
            this.zues = new GuiButton(108, this.w / 2 - 155 + i % 2 * 160, this.x / 6 - 12 + 24 * (i >> 1), 150, 20, this.zerodayisaminecraftcheat(enumdifficulty));
            this.y.add(this.zues);
            if (this.u.y() && !this.u.a.u().k()) {
                this.zues.zerodayisaminecraftcheat(this.zues.zeroday() - 20);
                this.flux = new GuiLockIconButton(109, this.zues.pandora + this.zues.zeroday(), this.zues.zues);
                this.y.add(this.flux);
                this.flux.zeroday(this.u.a.u().q());
                this.flux.momgetthecamera = !this.flux.sigma();
                this.zues.momgetthecamera = !this.flux.sigma();
            }
            else {
                this.zues.momgetthecamera = false;
            }
        }
        this.y.add(new GuiButton(110, this.w / 2 - 155, this.x / 6 + 48 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.skinCustomisation", new Object[0])));
        this.y.add(new GuiButton(8675309, this.w / 2 + 5, this.x / 6 + 48 - 6, 150, 20, "Super Secret Settings...") {
            @Override
            public void zerodayisaminecraftcheat(final SoundHandler soundHandlerIn) {
                final SoundEventAccessorComposite soundeventaccessorcomposite = soundHandlerIn.zerodayisaminecraftcheat(SoundCategory.vape, SoundCategory.zues, SoundCategory.flux, SoundCategory.momgetthecamera, SoundCategory.pandora);
                if (soundeventaccessorcomposite != null) {
                    soundHandlerIn.zerodayisaminecraftcheat(PositionedSoundRecord.zerodayisaminecraftcheat(soundeventaccessorcomposite.pandora(), 0.5f));
                }
            }
        });
        this.y.add(new GuiButton(106, this.w / 2 - 155, this.x / 6 + 72 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.sounds", new Object[0])));
        this.y.add(new GuiButton(107, this.w / 2 + 5, this.x / 6 + 72 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.stream", new Object[0])));
        this.y.add(new GuiButton(101, this.w / 2 - 155, this.x / 6 + 96 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.video", new Object[0])));
        this.y.add(new GuiButton(100, this.w / 2 + 5, this.x / 6 + 96 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.controls", new Object[0])));
        this.y.add(new GuiButton(102, this.w / 2 - 155, this.x / 6 + 120 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.language", new Object[0])));
        this.y.add(new GuiButton(103, this.w / 2 + 5, this.x / 6 + 120 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.chat.title", new Object[0])));
        this.y.add(new GuiButton(105, this.w / 2 - 155, this.x / 6 + 144 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.resourcepack", new Object[0])));
        this.y.add(new GuiButton(104, this.w / 2 + 5, this.x / 6 + 144 - 6, 150, 20, I18n.zerodayisaminecraftcheat("options.snooper.view", new Object[0])));
        this.y.add(new GuiButton(200, this.w / 2 - 100, this.x / 6 + 168, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
    }
    
    public String zerodayisaminecraftcheat(final EnumDifficulty p_175355_1_) {
        final IChatComponent ichatcomponent = new ChatComponentText("");
        ichatcomponent.zerodayisaminecraftcheat(new ChatComponentTranslation("options.difficulty", new Object[0]));
        ichatcomponent.zeroday(": ");
        ichatcomponent.zerodayisaminecraftcheat(new ChatComponentTranslation(p_175355_1_.zeroday(), new Object[0]));
        return ichatcomponent.a();
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean result, final int id) {
        this.u.zerodayisaminecraftcheat(this);
        if (id == 109 && result && this.u.a != null) {
            this.u.a.u().zues(true);
            this.flux.zeroday(true);
            this.flux.momgetthecamera = false;
            this.zues.momgetthecamera = false;
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            if (button.vape < 100 && button instanceof GuiOptionButton) {
                final GameSettings.zeroday gamesettings$options = ((GuiOptionButton)button).sigma();
                this.pandora.zerodayisaminecraftcheat(gamesettings$options, 1);
                button.flux = this.pandora.sigma(GameSettings.zeroday.zerodayisaminecraftcheat(button.vape));
            }
            if (button.vape == 108) {
                this.u.a.u().zerodayisaminecraftcheat(EnumDifficulty.zerodayisaminecraftcheat(this.u.a.F().zerodayisaminecraftcheat() + 1));
                this.zues.flux = this.zerodayisaminecraftcheat(this.u.a.F());
            }
            if (button.vape == 109) {
                this.u.zerodayisaminecraftcheat(new GuiYesNo(this, new ChatComponentTranslation("difficulty.lock.title", new Object[0]).a(), new ChatComponentTranslation("difficulty.lock.question", new Object[] { new ChatComponentTranslation(this.u.a.u().p().zeroday(), new Object[0]) }).a(), 109));
            }
            if (button.vape == 110) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new GuiCustomizeSkin(this));
            }
            if (button.vape == 8675309) {
                this.u.m.pandora();
            }
            if (button.vape == 101) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new GuiVideoSettings(this, this.pandora));
            }
            if (button.vape == 100) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new GuiControls(this, this.pandora));
            }
            if (button.vape == 102) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new GuiLanguage(this, this.pandora, this.u.L()));
            }
            if (button.vape == 103) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new ScreenChatOptions(this, this.pandora));
            }
            if (button.vape == 104) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new GuiSnooper(this, this.pandora));
            }
            if (button.vape == 200) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(this.sigma);
            }
            if (button.vape == 105) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new GuiScreenResourcePacks(this));
            }
            if (button.vape == 106) {
                this.u.r.zeroday();
                this.u.zerodayisaminecraftcheat(new GuiScreenOptionsSounds(this, this.pandora));
            }
            if (button.vape == 107) {
                this.u.r.zeroday();
                final IStream istream = this.u.R();
                if (istream.a() && istream.r()) {
                    this.u.zerodayisaminecraftcheat(new GuiStreamOptions(this, this.pandora));
                }
                else {
                    GuiStreamUnavailable.zerodayisaminecraftcheat(this);
                }
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, this.zerodayisaminecraftcheat, this.w / 2, 15, 16777215);
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
}

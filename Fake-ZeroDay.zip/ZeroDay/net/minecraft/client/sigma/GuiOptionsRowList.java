// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import com.google.common.collect.Lists;
import net.minecraft.client.c.GameSettings;
import net.minecraft.client.Minecraft;
import java.util.List;

public class GuiOptionsRowList extends GuiListExtended
{
    private final List<zerodayisaminecraftcheat> zerodayisaminecraftcheat;
    
    public GuiOptionsRowList(final Minecraft mcIn, final int p_i45015_2_, final int p_i45015_3_, final int p_i45015_4_, final int p_i45015_5_, final int p_i45015_6_, final GameSettings.zeroday... p_i45015_7_) {
        super(mcIn, p_i45015_2_, p_i45015_3_, p_i45015_4_, p_i45015_5_, p_i45015_6_);
        this.zerodayisaminecraftcheat = (List<zerodayisaminecraftcheat>)Lists.newArrayList();
        this.e = false;
        for (int i = 0; i < p_i45015_7_.length; i += 2) {
            final GameSettings.zeroday gamesettings$options = p_i45015_7_[i];
            final GameSettings.zeroday gamesettings$options2 = (i < p_i45015_7_.length - 1) ? p_i45015_7_[i + 1] : null;
            final GuiButton guibutton = this.zerodayisaminecraftcheat(mcIn, p_i45015_2_ / 2 - 155, 0, gamesettings$options);
            final GuiButton guibutton2 = this.zerodayisaminecraftcheat(mcIn, p_i45015_2_ / 2 - 155 + 160, 0, gamesettings$options2);
            this.zerodayisaminecraftcheat.add(new zerodayisaminecraftcheat(guibutton, guibutton2));
        }
    }
    
    private GuiButton zerodayisaminecraftcheat(final Minecraft mcIn, final int p_148182_2_, final int p_148182_3_, final GameSettings.zeroday p_148182_4_) {
        if (p_148182_4_ == null) {
            return null;
        }
        final int i = p_148182_4_.sigma();
        return p_148182_4_.zerodayisaminecraftcheat() ? new GuiOptionSlider(i, p_148182_2_, p_148182_3_, p_148182_4_) : new GuiOptionButton(i, p_148182_2_, p_148182_3_, p_148182_4_, mcIn.r.sigma(p_148182_4_));
    }
    
    public zerodayisaminecraftcheat sigma(final int index) {
        return this.zerodayisaminecraftcheat.get(index);
    }
    
    @Override
    protected int zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat.size();
    }
    
    @Override
    public int s_() {
        return 400;
    }
    
    @Override
    protected int vape() {
        return super.vape() + 32;
    }
    
    public static class zerodayisaminecraftcheat implements GuiListExtended.zerodayisaminecraftcheat
    {
        private final Minecraft zerodayisaminecraftcheat;
        private final GuiButton zeroday;
        private final GuiButton sigma;
        
        public zerodayisaminecraftcheat(final GuiButton p_i45014_1_, final GuiButton p_i45014_2_) {
            this.zerodayisaminecraftcheat = Minecraft.s();
            this.zeroday = p_i45014_1_;
            this.sigma = p_i45014_2_;
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int slotIndex, final int x, final int y, final int listWidth, final int slotHeight, final int mouseX, final int mouseY, final boolean isSelected) {
            if (this.zeroday != null) {
                this.zeroday.zues = y;
                this.zeroday.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, mouseX, mouseY);
            }
            if (this.sigma != null) {
                this.sigma.zues = y;
                this.sigma.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, mouseX, mouseY);
            }
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final int slotIndex, final int p_148278_2_, final int p_148278_3_, final int p_148278_4_, final int p_148278_5_, final int p_148278_6_) {
            if (this.zeroday.sigma(this.zerodayisaminecraftcheat, p_148278_2_, p_148278_3_)) {
                if (this.zeroday instanceof GuiOptionButton) {
                    this.zerodayisaminecraftcheat.r.zerodayisaminecraftcheat(((GuiOptionButton)this.zeroday).sigma(), 1);
                    this.zeroday.flux = this.zerodayisaminecraftcheat.r.sigma(GameSettings.zeroday.zerodayisaminecraftcheat(this.zeroday.vape));
                }
                return true;
            }
            if (this.sigma != null && this.sigma.sigma(this.zerodayisaminecraftcheat, p_148278_2_, p_148278_3_)) {
                if (this.sigma instanceof GuiOptionButton) {
                    this.zerodayisaminecraftcheat.r.zerodayisaminecraftcheat(((GuiOptionButton)this.sigma).sigma(), 1);
                    this.sigma.flux = this.zerodayisaminecraftcheat.r.sigma(GameSettings.zeroday.zerodayisaminecraftcheat(this.sigma.vape));
                }
                return true;
            }
            return false;
        }
        
        @Override
        public void zeroday(final int slotIndex, final int x, final int y, final int mouseEvent, final int relativeX, final int relativeY) {
            if (this.zeroday != null) {
                this.zeroday.zerodayisaminecraftcheat(x, y);
            }
            if (this.sigma != null) {
                this.sigma.zerodayisaminecraftcheat(x, y);
            }
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int p_178011_1_, final int p_178011_2_, final int p_178011_3_) {
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.o.FrameTimer;
import java.util.Iterator;
import net.minecraft.zerodayisaminecraftcheat.sigma.IBlockState;
import net.minecraft.zerodayisaminecraftcheat.zeroday.IProperty;
import net.minecraft.o.EnumChatFormatting;
import java.util.Map;
import net.minecraft.zerodayisaminecraftcheat.Block;
import net.minecraft.q.IBlockAccess;
import net.minecraft.q.WorldType;
import java.util.Collection;
import net.minecraft.l.Reflector;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.Display;
import net.minecraft.client.a.OpenGlHelper;
import net.minecraft.vape.vape.EntityPlayerMP;
import net.minecraft.q.DifficultyInstance;
import net.minecraft.q.sigma.Chunk;
import java.util.ArrayList;
import net.minecraft.o.EnumFacing;
import net.minecraft.o.MovingObjectPosition;
import net.minecraft.vape.Entity;
import net.minecraft.q.EnumSkyBlock;
import net.minecraft.o.MathHelper;
import com.google.common.collect.Lists;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.o.BlockPos;
import java.util.List;
import com.google.common.base.Strings;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.client.Minecraft;

public class GuiOverlayDebug extends Gui
{
    private final Minecraft zerodayisaminecraftcheat;
    private final FontRenderer zeroday;
    private static final String sigma = "CL_00001956";
    
    public GuiOverlayDebug(final Minecraft mc) {
        this.zerodayisaminecraftcheat = mc;
        this.zeroday = mc.i;
    }
    
    public void zerodayisaminecraftcheat(final ScaledResolution scaledResolutionIn) {
        this.zerodayisaminecraftcheat.z.zerodayisaminecraftcheat("debug");
        GlStateManager.v();
        this.zerodayisaminecraftcheat();
        this.zeroday(scaledResolutionIn);
        GlStateManager.w();
        this.zerodayisaminecraftcheat.z.zeroday();
    }
    
    private boolean pandora() {
        return this.zerodayisaminecraftcheat.e.cf() || this.zerodayisaminecraftcheat.r.o;
    }
    
    protected void zerodayisaminecraftcheat() {
        final List list = this.zeroday();
        for (int i = 0; i < list.size(); ++i) {
            final String s = list.get(i);
            if (!Strings.isNullOrEmpty(s)) {
                final int j = this.zeroday.zeroday;
                final int k = this.zeroday.zerodayisaminecraftcheat(s);
                final boolean flag = true;
                final int l = 2 + j * i;
                Gui.zerodayisaminecraftcheat(1, l - 1, 2 + k + 1, l + j - 1, -1873784752);
                this.zeroday.zerodayisaminecraftcheat(s, 2, l, 14737632);
            }
        }
    }
    
    protected void zeroday(final ScaledResolution p_175239_1_) {
        final List list = this.sigma();
        for (int i = 0; i < list.size(); ++i) {
            final String s = list.get(i);
            if (!Strings.isNullOrEmpty(s)) {
                final int j = this.zeroday.zeroday;
                final int k = this.zeroday.zerodayisaminecraftcheat(s);
                final int l = p_175239_1_.zerodayisaminecraftcheat() - 2 - k;
                final int i2 = 2 + j * i;
                Gui.zerodayisaminecraftcheat(l - 1, i2 - 1, l + k + 1, i2 + j - 1, -1873784752);
                this.zeroday.zerodayisaminecraftcheat(s, l, i2, 14737632);
            }
        }
    }
    
    protected List zeroday() {
        final BlockPos blockpos = new BlockPos(this.zerodayisaminecraftcheat.V().s, this.zerodayisaminecraftcheat.V().aH().zeroday, this.zerodayisaminecraftcheat.V().u);
        if (this.pandora()) {
            return Lists.newArrayList((Object[])new String[] { "Minecraft 1.8.8 (" + this.zerodayisaminecraftcheat.pandora() + "/" + ClientBrandRetriever.zerodayisaminecraftcheat() + ")", this.zerodayisaminecraftcheat.F, this.zerodayisaminecraftcheat.b.flux(), this.zerodayisaminecraftcheat.b.vape(), "P: " + this.zerodayisaminecraftcheat.g.zeroday() + ". T: " + this.zerodayisaminecraftcheat.a.g(), this.zerodayisaminecraftcheat.a.h(), "", String.format("Chunk-relative: %d %d %d", blockpos.zerodayisaminecraftcheat() & 0xF, blockpos.zeroday() & 0xF, blockpos.sigma() & 0xF) });
        }
        final Entity entity = this.zerodayisaminecraftcheat.V();
        final EnumFacing enumfacing = entity.aF();
        String s = "Invalid";
        switch (GuiOverlayDebug.zerodayisaminecraftcheat.zerodayisaminecraftcheat[enumfacing.ordinal()]) {
            case 1: {
                s = "Towards negative Z";
                break;
            }
            case 2: {
                s = "Towards positive Z";
                break;
            }
            case 3: {
                s = "Towards negative X";
                break;
            }
            case 4: {
                s = "Towards positive X";
                break;
            }
        }
        final ArrayList arraylist = Lists.newArrayList((Object[])new String[] { "Minecraft 1.8.8 (" + this.zerodayisaminecraftcheat.pandora() + "/" + ClientBrandRetriever.zerodayisaminecraftcheat() + ")", this.zerodayisaminecraftcheat.F, this.zerodayisaminecraftcheat.b.flux(), this.zerodayisaminecraftcheat.b.vape(), "P: " + this.zerodayisaminecraftcheat.g.zeroday() + ". T: " + this.zerodayisaminecraftcheat.a.g(), this.zerodayisaminecraftcheat.a.h(), "", String.format("XYZ: %.3f / %.5f / %.3f", this.zerodayisaminecraftcheat.V().s, this.zerodayisaminecraftcheat.V().aH().zeroday, this.zerodayisaminecraftcheat.V().u), String.format("Block: %d %d %d", blockpos.zerodayisaminecraftcheat(), blockpos.zeroday(), blockpos.sigma()), String.format("Chunk: %d %d %d in %d %d %d", blockpos.zerodayisaminecraftcheat() & 0xF, blockpos.zeroday() & 0xF, blockpos.sigma() & 0xF, blockpos.zerodayisaminecraftcheat() >> 4, blockpos.zeroday() >> 4, blockpos.sigma() >> 4), String.format("Facing: %s (%s) (%.1f / %.1f)", enumfacing, s, MathHelper.vape(entity.y), MathHelper.vape(entity.z)) });
        if (this.zerodayisaminecraftcheat.a != null && this.zerodayisaminecraftcheat.a.flux(blockpos)) {
            final Chunk chunk = this.zerodayisaminecraftcheat.a.vape(blockpos);
            arraylist.add("Biome: " + chunk.zerodayisaminecraftcheat(blockpos, this.zerodayisaminecraftcheat.a.a()).Z);
            arraylist.add("Light: " + chunk.zerodayisaminecraftcheat(blockpos, 0) + " (" + chunk.zerodayisaminecraftcheat(EnumSkyBlock.zerodayisaminecraftcheat, blockpos) + " sky, " + chunk.zerodayisaminecraftcheat(EnumSkyBlock.zeroday, blockpos) + " block)");
            DifficultyInstance difficultyinstance = this.zerodayisaminecraftcheat.a.v(blockpos);
            if (this.zerodayisaminecraftcheat.x() && this.zerodayisaminecraftcheat.z() != null) {
                final EntityPlayerMP entityplayermp = this.zerodayisaminecraftcheat.z().ae().zerodayisaminecraftcheat(this.zerodayisaminecraftcheat.e.aA());
                if (entityplayermp != null) {
                    difficultyinstance = entityplayermp.o.v(new BlockPos(entityplayermp));
                }
            }
            arraylist.add(String.format("Local Difficulty: %.2f (Day %d)", difficultyinstance.zerodayisaminecraftcheat(), this.zerodayisaminecraftcheat.a.q() / 24000L));
        }
        if (this.zerodayisaminecraftcheat.m != null && this.zerodayisaminecraftcheat.m.zerodayisaminecraftcheat()) {
            arraylist.add("Shader: " + this.zerodayisaminecraftcheat.m.flux().zeroday());
        }
        if (this.zerodayisaminecraftcheat.q != null && this.zerodayisaminecraftcheat.q.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday && this.zerodayisaminecraftcheat.q.zerodayisaminecraftcheat() != null) {
            final BlockPos blockpos2 = this.zerodayisaminecraftcheat.q.zerodayisaminecraftcheat();
            arraylist.add(String.format("Looking at: %d %d %d", blockpos2.zerodayisaminecraftcheat(), blockpos2.zeroday(), blockpos2.sigma()));
        }
        return arraylist;
    }
    
    protected List sigma() {
        final long i = Runtime.getRuntime().maxMemory();
        final long j = Runtime.getRuntime().totalMemory();
        final long k = Runtime.getRuntime().freeMemory();
        final long l = j - k;
        final ArrayList arraylist = Lists.newArrayList((Object[])new String[] { String.format("Java: %s %dbit", System.getProperty("java.version"), this.zerodayisaminecraftcheat.N() ? 64 : 32), String.format("Mem: % 2d%% %03d/%03dMB", l * 100L / i, zerodayisaminecraftcheat(l), zerodayisaminecraftcheat(i)), String.format("Allocated: % 2d%% %03dMB", j * 100L / i, zerodayisaminecraftcheat(j)), "", String.format("CPU: %s", OpenGlHelper.b()), "", String.format("Display: %dx%d (%s)", Display.getWidth(), Display.getHeight(), GL11.glGetString(7936)), GL11.glGetString(7937), GL11.glGetString(7938) });
        if (Reflector.E.zeroday()) {
            final Object object = Reflector.vape(Reflector.A, new Object[0]);
            arraylist.add("");
            arraylist.addAll((Collection)Reflector.vape(object, Reflector.E, false));
        }
        if (this.pandora()) {
            return arraylist;
        }
        if (this.zerodayisaminecraftcheat.q != null && this.zerodayisaminecraftcheat.q.zerodayisaminecraftcheat == MovingObjectPosition.zerodayisaminecraftcheat.zeroday && this.zerodayisaminecraftcheat.q.zerodayisaminecraftcheat() != null) {
            final BlockPos blockpos = this.zerodayisaminecraftcheat.q.zerodayisaminecraftcheat();
            IBlockState iblockstate = this.zerodayisaminecraftcheat.a.zeroday(blockpos);
            if (this.zerodayisaminecraftcheat.a.w_() != WorldType.vape) {
                iblockstate = iblockstate.sigma().zerodayisaminecraftcheat(iblockstate, this.zerodayisaminecraftcheat.a, blockpos);
            }
            arraylist.add("");
            arraylist.add(String.valueOf(Block.zerodayisaminecraftcheat.zeroday(iblockstate.sigma())));
            for (final Map.Entry entry : iblockstate.zeroday().entrySet()) {
                String s = entry.getValue().toString();
                if (entry.getValue() == Boolean.TRUE) {
                    s = EnumChatFormatting.c + s;
                }
                else if (entry.getValue() == Boolean.FALSE) {
                    s = EnumChatFormatting.e + s;
                }
                arraylist.add(String.valueOf(entry.getKey().zerodayisaminecraftcheat()) + ": " + s);
            }
        }
        return arraylist;
    }
    
    private void zues() {
        GlStateManager.a();
        final FrameTimer frametimer = this.zerodayisaminecraftcheat.ac();
        final int i = frametimer.zerodayisaminecraftcheat();
        final int j = frametimer.zeroday();
        final long[] along = frametimer.sigma();
        final ScaledResolution scaledresolution = new ScaledResolution(this.zerodayisaminecraftcheat);
        int k = i;
        int l = 0;
        Gui.zerodayisaminecraftcheat(0, scaledresolution.zeroday() - 60, 240, scaledresolution.zeroday(), -1873784752);
        while (k != j) {
            final int i2 = frametimer.zerodayisaminecraftcheat(along[k], 30);
            final int j2 = this.zerodayisaminecraftcheat(MathHelper.zerodayisaminecraftcheat(i2, 0, 60), 0, 30, 60);
            this.flux(l, scaledresolution.zeroday(), scaledresolution.zeroday() - i2, j2);
            ++l;
            k = frametimer.zerodayisaminecraftcheat(k + 1);
        }
        Gui.zerodayisaminecraftcheat(1, scaledresolution.zeroday() - 30 + 1, 14, scaledresolution.zeroday() - 30 + 10, -1873784752);
        this.zeroday.zerodayisaminecraftcheat("60", 2, scaledresolution.zeroday() - 30 + 2, 14737632);
        this.zues(0, 239, scaledresolution.zeroday() - 30, -1);
        Gui.zerodayisaminecraftcheat(1, scaledresolution.zeroday() - 60 + 1, 14, scaledresolution.zeroday() - 60 + 10, -1873784752);
        this.zeroday.zerodayisaminecraftcheat("30", 2, scaledresolution.zeroday() - 60 + 2, 14737632);
        this.zues(0, 239, scaledresolution.zeroday() - 60, -1);
        this.zues(0, 239, scaledresolution.zeroday() - 1, -1);
        this.flux(0, scaledresolution.zeroday() - 60, scaledresolution.zeroday(), -1);
        this.flux(239, scaledresolution.zeroday() - 60, scaledresolution.zeroday(), -1);
        if (this.zerodayisaminecraftcheat.r.vape <= 120) {
            this.zues(0, 239, scaledresolution.zeroday() - 60 + this.zerodayisaminecraftcheat.r.vape / 2, -16711681);
        }
        GlStateManager.b();
    }
    
    private int zerodayisaminecraftcheat(final int p_181552_1_, final int p_181552_2_, final int p_181552_3_, final int p_181552_4_) {
        return (p_181552_1_ < p_181552_3_) ? this.zerodayisaminecraftcheat(-16711936, -256, p_181552_1_ / (float)p_181552_3_) : this.zerodayisaminecraftcheat(-256, -65536, (p_181552_1_ - p_181552_3_) / (float)(p_181552_4_ - p_181552_3_));
    }
    
    private int zerodayisaminecraftcheat(final int p_181553_1_, final int p_181553_2_, final float p_181553_3_) {
        final int i = p_181553_1_ >> 24 & 0xFF;
        final int j = p_181553_1_ >> 16 & 0xFF;
        final int k = p_181553_1_ >> 8 & 0xFF;
        final int l = p_181553_1_ & 0xFF;
        final int i2 = p_181553_2_ >> 24 & 0xFF;
        final int j2 = p_181553_2_ >> 16 & 0xFF;
        final int k2 = p_181553_2_ >> 8 & 0xFF;
        final int l2 = p_181553_2_ & 0xFF;
        final int i3 = MathHelper.zerodayisaminecraftcheat((int)(i + (i2 - i) * p_181553_3_), 0, 255);
        final int j3 = MathHelper.zerodayisaminecraftcheat((int)(j + (j2 - j) * p_181553_3_), 0, 255);
        final int k3 = MathHelper.zerodayisaminecraftcheat((int)(k + (k2 - k) * p_181553_3_), 0, 255);
        final int l3 = MathHelper.zerodayisaminecraftcheat((int)(l + (l2 - l) * p_181553_3_), 0, 255);
        return i3 << 24 | j3 << 16 | k3 << 8 | l3;
    }
    
    private static long zerodayisaminecraftcheat(final long bytes) {
        return bytes / 1024L / 1024L;
    }
    
    static final class zerodayisaminecraftcheat
    {
        static final int[] zerodayisaminecraftcheat;
        private static final String zeroday = "CL_00001955";
        
        static {
            zerodayisaminecraftcheat = new int[EnumFacing.values().length];
            try {
                GuiOverlayDebug.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.sigma.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                GuiOverlayDebug.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.pandora.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                GuiOverlayDebug.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.zues.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                GuiOverlayDebug.zerodayisaminecraftcheat.zerodayisaminecraftcheat[EnumFacing.flux.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
        }
    }
}

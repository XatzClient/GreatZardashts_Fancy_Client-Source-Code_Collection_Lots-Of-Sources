// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import com.google.common.base.Objects;
import com.google.common.base.Predicates;
import com.google.common.base.Predicate;
import java.util.Iterator;
import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.o.IntHashMap;
import java.util.List;

public class GuiPageButtonList extends GuiListExtended
{
    private final List<sigma> zerodayisaminecraftcheat;
    private final IntHashMap<Gui> zeroday;
    private final List<GuiTextField> o;
    private final zues[][] p;
    private int q;
    private flux r;
    private Gui s;
    
    public GuiPageButtonList(final Minecraft mcIn, final int widthIn, final int heightIn, final int topIn, final int bottomIn, final int slotHeightIn, final flux p_i45536_7_, final zues[]... p_i45536_8_) {
        super(mcIn, widthIn, heightIn, topIn, bottomIn, slotHeightIn);
        this.zerodayisaminecraftcheat = (List<sigma>)Lists.newArrayList();
        this.zeroday = new IntHashMap<Gui>();
        this.o = (List<GuiTextField>)Lists.newArrayList();
        this.r = p_i45536_7_;
        this.p = p_i45536_8_;
        this.e = false;
        this.i();
        this.j();
    }
    
    private void i() {
        zues[][] p;
        for (int length = (p = this.p).length, j = 0; j < length; ++j) {
            final zues[] aguipagebuttonlist$guilistentry = p[j];
            for (int i = 0; i < aguipagebuttonlist$guilistentry.length; i += 2) {
                final zues guipagebuttonlist$guilistentry = aguipagebuttonlist$guilistentry[i];
                final zues guipagebuttonlist$guilistentry2 = (i < aguipagebuttonlist$guilistentry.length - 1) ? aguipagebuttonlist$guilistentry[i + 1] : null;
                final Gui gui = this.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry, 0, guipagebuttonlist$guilistentry2 == null);
                final Gui gui2 = this.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry2, 160, guipagebuttonlist$guilistentry == null);
                final sigma guipagebuttonlist$guientry = new sigma(gui, gui2);
                this.zerodayisaminecraftcheat.add(guipagebuttonlist$guientry);
                if (guipagebuttonlist$guilistentry != null && gui != null) {
                    this.zeroday.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry.zeroday(), gui);
                    if (gui instanceof GuiTextField) {
                        this.o.add((GuiTextField)gui);
                    }
                }
                if (guipagebuttonlist$guilistentry2 != null && gui2 != null) {
                    this.zeroday.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry2.zeroday(), gui2);
                    if (gui2 instanceof GuiTextField) {
                        this.o.add((GuiTextField)gui2);
                    }
                }
            }
        }
    }
    
    private void j() {
        this.zerodayisaminecraftcheat.clear();
        for (int i = 0; i < this.p[this.q].length; i += 2) {
            final zues guipagebuttonlist$guilistentry = this.p[this.q][i];
            final zues guipagebuttonlist$guilistentry2 = (i < this.p[this.q].length - 1) ? this.p[this.q][i + 1] : null;
            final Gui gui = this.zeroday.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry.zeroday());
            final Gui gui2 = (guipagebuttonlist$guilistentry2 != null) ? this.zeroday.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry2.zeroday()) : null;
            final sigma guipagebuttonlist$guientry = new sigma(gui, gui2);
            this.zerodayisaminecraftcheat.add(guipagebuttonlist$guientry);
        }
    }
    
    public void sigma(final int p_181156_1_) {
        if (p_181156_1_ != this.q) {
            final int i = this.q;
            this.q = p_181156_1_;
            this.j();
            this.zues(i, p_181156_1_);
            this.h = 0.0f;
        }
    }
    
    public int zues() {
        return this.q;
    }
    
    public int flux() {
        return this.p.length;
    }
    
    public Gui a() {
        return this.s;
    }
    
    public void b() {
        if (this.q > 0) {
            this.sigma(this.q - 1);
        }
    }
    
    public void c() {
        if (this.q < this.p.length - 1) {
            this.sigma(this.q + 1);
        }
    }
    
    public Gui pandora(final int p_178061_1_) {
        return this.zeroday.zerodayisaminecraftcheat(p_178061_1_);
    }
    
    private void zues(final int p_178060_1_, final int p_178060_2_) {
        zues[] array;
        for (int length = (array = this.p[p_178060_1_]).length, i = 0; i < length; ++i) {
            final zues guipagebuttonlist$guilistentry = array[i];
            if (guipagebuttonlist$guilistentry != null) {
                this.zerodayisaminecraftcheat(this.zeroday.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry.zeroday()), false);
            }
        }
        zues[] array2;
        for (int length2 = (array2 = this.p[p_178060_2_]).length, j = 0; j < length2; ++j) {
            final zues guipagebuttonlist$guilistentry2 = array2[j];
            if (guipagebuttonlist$guilistentry2 != null) {
                this.zerodayisaminecraftcheat(this.zeroday.zerodayisaminecraftcheat(guipagebuttonlist$guilistentry2.zeroday()), true);
            }
        }
    }
    
    private void zerodayisaminecraftcheat(final Gui p_178066_1_, final boolean p_178066_2_) {
        if (p_178066_1_ instanceof GuiButton) {
            ((GuiButton)p_178066_1_).a = p_178066_2_;
        }
        else if (p_178066_1_ instanceof GuiTextField) {
            ((GuiTextField)p_178066_1_).zues(p_178066_2_);
        }
        else if (p_178066_1_ instanceof GuiLabel) {
            ((GuiLabel)p_178066_1_).flux = p_178066_2_;
        }
    }
    
    private Gui zerodayisaminecraftcheat(final zues p_178058_1_, final int p_178058_2_, final boolean p_178058_3_) {
        return (p_178058_1_ instanceof vape) ? this.zerodayisaminecraftcheat(this.pandora / 2 - 155 + p_178058_2_, 0, (vape)p_178058_1_) : ((p_178058_1_ instanceof zeroday) ? this.zerodayisaminecraftcheat(this.pandora / 2 - 155 + p_178058_2_, 0, (zeroday)p_178058_1_) : ((p_178058_1_ instanceof zerodayisaminecraftcheat) ? this.zerodayisaminecraftcheat(this.pandora / 2 - 155 + p_178058_2_, 0, (zerodayisaminecraftcheat)p_178058_1_) : ((p_178058_1_ instanceof pandora) ? this.zerodayisaminecraftcheat(this.pandora / 2 - 155 + p_178058_2_, 0, (pandora)p_178058_1_, p_178058_3_) : null)));
    }
    
    public void zerodayisaminecraftcheat(final boolean p_181155_1_) {
        for (final sigma guipagebuttonlist$guientry : this.zerodayisaminecraftcheat) {
            if (guipagebuttonlist$guientry.zeroday instanceof GuiButton) {
                ((GuiButton)guipagebuttonlist$guientry.zeroday).momgetthecamera = p_181155_1_;
            }
            if (guipagebuttonlist$guientry.sigma instanceof GuiButton) {
                ((GuiButton)guipagebuttonlist$guientry.sigma).momgetthecamera = p_181155_1_;
            }
        }
    }
    
    @Override
    public boolean zeroday(final int mouseX, final int mouseY, final int mouseEvent) {
        final boolean flag = super.zeroday(mouseX, mouseY, mouseEvent);
        final int i = this.sigma(mouseX, mouseY);
        if (i >= 0) {
            final sigma guipagebuttonlist$guientry = this.zues(i);
            if (this.s != guipagebuttonlist$guientry.pandora && this.s != null && this.s instanceof GuiTextField) {
                ((GuiTextField)this.s).zeroday(false);
            }
            this.s = guipagebuttonlist$guientry.pandora;
        }
        return flag;
    }
    
    private GuiSlider zerodayisaminecraftcheat(final int p_178067_1_, final int p_178067_2_, final vape p_178067_3_) {
        final GuiSlider guislider = new GuiSlider(this.r, p_178067_3_.zeroday(), p_178067_1_, p_178067_2_, p_178067_3_.sigma(), p_178067_3_.zues(), p_178067_3_.flux(), p_178067_3_.vape(), p_178067_3_.zerodayisaminecraftcheat());
        guislider.a = p_178067_3_.pandora();
        return guislider;
    }
    
    private GuiListButton zerodayisaminecraftcheat(final int p_178065_1_, final int p_178065_2_, final zeroday p_178065_3_) {
        final GuiListButton guilistbutton = new GuiListButton(this.r, p_178065_3_.zeroday(), p_178065_1_, p_178065_2_, p_178065_3_.sigma(), p_178065_3_.zerodayisaminecraftcheat());
        guilistbutton.a = p_178065_3_.pandora();
        return guilistbutton;
    }
    
    private GuiTextField zerodayisaminecraftcheat(final int p_178068_1_, final int p_178068_2_, final zerodayisaminecraftcheat p_178068_3_) {
        final GuiTextField guitextfield = new GuiTextField(p_178068_3_.zeroday(), this.sigma.i, p_178068_1_, p_178068_2_, 150, 20);
        guitextfield.zerodayisaminecraftcheat(p_178068_3_.sigma());
        guitextfield.zerodayisaminecraftcheat(this.r);
        guitextfield.zues(p_178068_3_.pandora());
        guitextfield.zerodayisaminecraftcheat(p_178068_3_.zerodayisaminecraftcheat());
        return guitextfield;
    }
    
    private GuiLabel zerodayisaminecraftcheat(final int p_178063_1_, final int p_178063_2_, final pandora p_178063_3_, final boolean p_178063_4_) {
        GuiLabel guilabel;
        if (p_178063_4_) {
            guilabel = new GuiLabel(this.sigma.i, p_178063_3_.zeroday(), p_178063_1_, p_178063_2_, this.pandora - p_178063_1_ * 2, 20, -1);
        }
        else {
            guilabel = new GuiLabel(this.sigma.i, p_178063_3_.zeroday(), p_178063_1_, p_178063_2_, 150, 20, -1);
        }
        guilabel.flux = p_178063_3_.pandora();
        guilabel.zerodayisaminecraftcheat(p_178063_3_.sigma());
        guilabel.zerodayisaminecraftcheat();
        return guilabel;
    }
    
    public void zerodayisaminecraftcheat(final char p_178062_1_, final int p_178062_2_) {
        if (this.s instanceof GuiTextField) {
            GuiTextField guitextfield = (GuiTextField)this.s;
            if (!GuiScreen.momgetthecamera(p_178062_2_)) {
                if (p_178062_2_ == 15) {
                    guitextfield.zeroday(false);
                    int k = this.o.indexOf(this.s);
                    if (GuiScreen.m()) {
                        if (k == 0) {
                            k = this.o.size() - 1;
                        }
                        else {
                            --k;
                        }
                    }
                    else if (k == this.o.size() - 1) {
                        k = 0;
                    }
                    else {
                        ++k;
                    }
                    this.s = this.o.get(k);
                    guitextfield = (GuiTextField)this.s;
                    guitextfield.zeroday(true);
                    final int l = guitextfield.zeroday + this.b;
                    final int i1 = guitextfield.zeroday;
                    if (l > this.vape) {
                        this.h += l - this.vape;
                    }
                    else if (i1 < this.flux) {
                        this.h = (float)i1;
                    }
                }
                else {
                    guitextfield.zerodayisaminecraftcheat(p_178062_1_, p_178062_2_);
                }
            }
            else {
                final String s = GuiScreen.f();
                final String[] astring = s.split(";");
                int m;
                final int j = m = this.o.indexOf(this.s);
                String[] array;
                for (int length = (array = astring).length, n = 0; n < length; ++n) {
                    final String s2 = array[n];
                    this.o.get(m).zerodayisaminecraftcheat(s2);
                    if (m == this.o.size() - 1) {
                        m = 0;
                    }
                    else {
                        ++m;
                    }
                    if (m == j) {
                        break;
                    }
                }
            }
        }
    }
    
    public sigma zues(final int index) {
        return this.zerodayisaminecraftcheat.get(index);
    }
    
    public int zerodayisaminecraftcheat() {
        return this.zerodayisaminecraftcheat.size();
    }
    
    @Override
    public int s_() {
        return 400;
    }
    
    @Override
    protected int vape() {
        return super.vape() + 32;
    }
    
    public static class zerodayisaminecraftcheat extends zues
    {
        private final Predicate<String> zerodayisaminecraftcheat;
        
        public zerodayisaminecraftcheat(final int p_i45534_1_, final String p_i45534_2_, final boolean p_i45534_3_, final Predicate<String> p_i45534_4_) {
            super(p_i45534_1_, p_i45534_2_, p_i45534_3_);
            this.zerodayisaminecraftcheat = (Predicate<String>)Objects.firstNonNull((Object)p_i45534_4_, (Object)Predicates.alwaysTrue());
        }
        
        public Predicate<String> zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
    }
    
    public static class zeroday extends zues
    {
        private final boolean zerodayisaminecraftcheat;
        
        public zeroday(final int p_i45535_1_, final String p_i45535_2_, final boolean p_i45535_3_, final boolean p_i45535_4_) {
            super(p_i45535_1_, p_i45535_2_, p_i45535_3_);
            this.zerodayisaminecraftcheat = p_i45535_4_;
        }
        
        public boolean zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
    }
    
    public static class sigma implements GuiListExtended.zerodayisaminecraftcheat
    {
        private final Minecraft zerodayisaminecraftcheat;
        private final Gui zeroday;
        private final Gui sigma;
        private Gui pandora;
        
        public sigma(final Gui p_i45533_1_, final Gui p_i45533_2_) {
            this.zerodayisaminecraftcheat = Minecraft.s();
            this.zeroday = p_i45533_1_;
            this.sigma = p_i45533_2_;
        }
        
        public Gui zerodayisaminecraftcheat() {
            return this.zeroday;
        }
        
        public Gui zeroday() {
            return this.sigma;
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int slotIndex, final int x, final int y, final int listWidth, final int slotHeight, final int mouseX, final int mouseY, final boolean isSelected) {
            this.zerodayisaminecraftcheat(this.zeroday, y, mouseX, mouseY, false);
            this.zerodayisaminecraftcheat(this.sigma, y, mouseX, mouseY, false);
        }
        
        private void zerodayisaminecraftcheat(final Gui p_178017_1_, final int p_178017_2_, final int p_178017_3_, final int p_178017_4_, final boolean p_178017_5_) {
            if (p_178017_1_ != null) {
                if (p_178017_1_ instanceof GuiButton) {
                    this.zerodayisaminecraftcheat((GuiButton)p_178017_1_, p_178017_2_, p_178017_3_, p_178017_4_, p_178017_5_);
                }
                else if (p_178017_1_ instanceof GuiTextField) {
                    this.zerodayisaminecraftcheat((GuiTextField)p_178017_1_, p_178017_2_, p_178017_5_);
                }
                else if (p_178017_1_ instanceof GuiLabel) {
                    this.zerodayisaminecraftcheat((GuiLabel)p_178017_1_, p_178017_2_, p_178017_3_, p_178017_4_, p_178017_5_);
                }
            }
        }
        
        private void zerodayisaminecraftcheat(final GuiButton p_178024_1_, final int p_178024_2_, final int p_178024_3_, final int p_178024_4_, final boolean p_178024_5_) {
            p_178024_1_.zues = p_178024_2_;
            if (!p_178024_5_) {
                p_178024_1_.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, p_178024_3_, p_178024_4_);
            }
        }
        
        private void zerodayisaminecraftcheat(final GuiTextField p_178027_1_, final int p_178027_2_, final boolean p_178027_3_) {
            p_178027_1_.zeroday = p_178027_2_;
            if (!p_178027_3_) {
                p_178027_1_.vape();
            }
        }
        
        private void zerodayisaminecraftcheat(final GuiLabel p_178025_1_, final int p_178025_2_, final int p_178025_3_, final int p_178025_4_, final boolean p_178025_5_) {
            p_178025_1_.pandora = p_178025_2_;
            if (!p_178025_5_) {
                p_178025_1_.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat, p_178025_3_, p_178025_4_);
            }
        }
        
        @Override
        public void zerodayisaminecraftcheat(final int p_178011_1_, final int p_178011_2_, final int p_178011_3_) {
            this.zerodayisaminecraftcheat(this.zeroday, p_178011_3_, 0, 0, true);
            this.zerodayisaminecraftcheat(this.sigma, p_178011_3_, 0, 0, true);
        }
        
        @Override
        public boolean zerodayisaminecraftcheat(final int slotIndex, final int p_148278_2_, final int p_148278_3_, final int p_148278_4_, final int p_148278_5_, final int p_148278_6_) {
            final boolean flag = this.zerodayisaminecraftcheat(this.zeroday, p_148278_2_, p_148278_3_, p_148278_4_);
            final boolean flag2 = this.zerodayisaminecraftcheat(this.sigma, p_148278_2_, p_148278_3_, p_148278_4_);
            return flag || flag2;
        }
        
        private boolean zerodayisaminecraftcheat(final Gui p_178026_1_, final int p_178026_2_, final int p_178026_3_, final int p_178026_4_) {
            if (p_178026_1_ == null) {
                return false;
            }
            if (p_178026_1_ instanceof GuiButton) {
                return this.zerodayisaminecraftcheat((GuiButton)p_178026_1_, p_178026_2_, p_178026_3_, p_178026_4_);
            }
            if (p_178026_1_ instanceof GuiTextField) {
                this.zerodayisaminecraftcheat((GuiTextField)p_178026_1_, p_178026_2_, p_178026_3_, p_178026_4_);
            }
            return false;
        }
        
        private boolean zerodayisaminecraftcheat(final GuiButton p_178023_1_, final int p_178023_2_, final int p_178023_3_, final int p_178023_4_) {
            final boolean flag = p_178023_1_.sigma(this.zerodayisaminecraftcheat, p_178023_2_, p_178023_3_);
            if (flag) {
                this.pandora = p_178023_1_;
            }
            return flag;
        }
        
        private void zerodayisaminecraftcheat(final GuiTextField p_178018_1_, final int p_178018_2_, final int p_178018_3_, final int p_178018_4_) {
            p_178018_1_.zerodayisaminecraftcheat(p_178018_2_, p_178018_3_, p_178018_4_);
            if (p_178018_1_.c()) {
                this.pandora = p_178018_1_;
            }
        }
        
        @Override
        public void zeroday(final int slotIndex, final int x, final int y, final int mouseEvent, final int relativeX, final int relativeY) {
            this.zeroday(this.zeroday, x, y, mouseEvent);
            this.zeroday(this.sigma, x, y, mouseEvent);
        }
        
        private void zeroday(final Gui p_178016_1_, final int p_178016_2_, final int p_178016_3_, final int p_178016_4_) {
            if (p_178016_1_ != null && p_178016_1_ instanceof GuiButton) {
                this.zeroday((GuiButton)p_178016_1_, p_178016_2_, p_178016_3_, p_178016_4_);
            }
        }
        
        private void zeroday(final GuiButton p_178019_1_, final int p_178019_2_, final int p_178019_3_, final int p_178019_4_) {
            p_178019_1_.zerodayisaminecraftcheat(p_178019_2_, p_178019_3_);
        }
    }
    
    public static class pandora extends zues
    {
        public pandora(final int p_i45532_1_, final String p_i45532_2_, final boolean p_i45532_3_) {
            super(p_i45532_1_, p_i45532_2_, p_i45532_3_);
        }
    }
    
    public static class zues
    {
        private final int zerodayisaminecraftcheat;
        private final String zeroday;
        private final boolean sigma;
        
        public zues(final int p_i45531_1_, final String p_i45531_2_, final boolean p_i45531_3_) {
            this.zerodayisaminecraftcheat = p_i45531_1_;
            this.zeroday = p_i45531_2_;
            this.sigma = p_i45531_3_;
        }
        
        public int zeroday() {
            return this.zerodayisaminecraftcheat;
        }
        
        public String sigma() {
            return this.zeroday;
        }
        
        public boolean pandora() {
            return this.sigma;
        }
    }
    
    public static class vape extends zues
    {
        private final GuiSlider.zerodayisaminecraftcheat zerodayisaminecraftcheat;
        private final float zeroday;
        private final float sigma;
        private final float pandora;
        
        public vape(final int p_i45530_1_, final String p_i45530_2_, final boolean p_i45530_3_, final GuiSlider.zerodayisaminecraftcheat p_i45530_4_, final float p_i45530_5_, final float p_i45530_6_, final float p_i45530_7_) {
            super(p_i45530_1_, p_i45530_2_, p_i45530_3_);
            this.zerodayisaminecraftcheat = p_i45530_4_;
            this.zeroday = p_i45530_5_;
            this.sigma = p_i45530_6_;
            this.pandora = p_i45530_7_;
        }
        
        public GuiSlider.zerodayisaminecraftcheat zerodayisaminecraftcheat() {
            return this.zerodayisaminecraftcheat;
        }
        
        public float zues() {
            return this.zeroday;
        }
        
        public float flux() {
            return this.sigma;
        }
        
        public float vape() {
            return this.pandora;
        }
    }
    
    public interface flux
    {
        void zerodayisaminecraftcheat(final int p0, final boolean p1);
        
        void zerodayisaminecraftcheat(final int p0, final float p1);
        
        void zerodayisaminecraftcheat(final int p0, final String p1);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import com.google.common.collect.ComparisonChain;
import net.minecraft.o.MathHelper;
import java.util.ArrayList;
import net.minecraft.vape.vape.EntityPlayer;
import com.mojang.authlib.GameProfile;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.flux.NetHandlerPlayClient;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.q.WorldSettings;
import net.minecraft.vape.vape.EnumPlayerModelParts;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.j.IScoreObjectiveCriteria;
import net.minecraft.j.ScoreObjective;
import net.minecraft.j.Scoreboard;
import net.minecraft.j.Team;
import net.minecraft.j.ScorePlayerTeam;
import java.util.Comparator;
import net.minecraft.o.IChatComponent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.flux.NetworkPlayerInfo;
import com.google.common.collect.Ordering;

public class GuiPlayerTabOverlay extends Gui
{
    public static final Ordering<NetworkPlayerInfo> zerodayisaminecraftcheat;
    private final Minecraft zeroday;
    private final GuiIngame sigma;
    private IChatComponent pandora;
    private IChatComponent zues;
    private long flux;
    private boolean vape;
    
    static {
        zerodayisaminecraftcheat = Ordering.from((Comparator)new zerodayisaminecraftcheat(null));
    }
    
    public GuiPlayerTabOverlay(final Minecraft mcIn, final GuiIngame guiIngameIn) {
        this.zeroday = mcIn;
        this.sigma = guiIngameIn;
    }
    
    public String zerodayisaminecraftcheat(final NetworkPlayerInfo networkPlayerInfoIn) {
        return (networkPlayerInfoIn.b() != null) ? networkPlayerInfoIn.b().a() : ScorePlayerTeam.zerodayisaminecraftcheat(networkPlayerInfoIn.momgetthecamera(), networkPlayerInfoIn.zerodayisaminecraftcheat().getName());
    }
    
    public void zerodayisaminecraftcheat(final boolean willBeRendered) {
        if (willBeRendered && !this.vape) {
            this.flux = Minecraft.C();
        }
        this.vape = willBeRendered;
    }
    
    public void zerodayisaminecraftcheat(final int width, final Scoreboard scoreboardIn, final ScoreObjective scoreObjectiveIn) {
        final NetHandlerPlayClient nethandlerplayclient = this.zeroday.e.zerodayisaminecraftcheat;
        List<NetworkPlayerInfo> list = (List<NetworkPlayerInfo>)GuiPlayerTabOverlay.zerodayisaminecraftcheat.sortedCopy((Iterable)nethandlerplayclient.sigma());
        int i = 0;
        int j = 0;
        for (final NetworkPlayerInfo networkplayerinfo : list) {
            int k = this.zeroday.i.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat(networkplayerinfo));
            i = Math.max(i, k);
            if (scoreObjectiveIn != null && scoreObjectiveIn.zues() != IScoreObjectiveCriteria.zerodayisaminecraftcheat.zeroday) {
                k = this.zeroday.i.zerodayisaminecraftcheat(" " + scoreboardIn.zeroday(networkplayerinfo.zerodayisaminecraftcheat().getName(), scoreObjectiveIn).zeroday());
                j = Math.max(j, k);
            }
        }
        list = list.subList(0, Math.min(list.size(), 80));
        int i2;
        int l3;
        int j2;
        for (l3 = (i2 = list.size()), j2 = 1; i2 > 20; i2 = (l3 + j2 - 1) / j2) {
            ++j2;
        }
        final boolean flag = this.zeroday.x() || this.zeroday.o().zeroday().pandora();
        int m;
        if (scoreObjectiveIn != null) {
            if (scoreObjectiveIn.zues() == IScoreObjectiveCriteria.zerodayisaminecraftcheat.zeroday) {
                m = 90;
            }
            else {
                m = j;
            }
        }
        else {
            m = 0;
        }
        final int i3 = Math.min(j2 * ((flag ? 9 : 0) + i + m + 13), width - 50) / j2;
        final int j3 = width / 2 - (i3 * j2 + (j2 - 1) * 5) / 2;
        int k2 = 10;
        int l4 = i3 * j2 + (j2 - 1) * 5;
        List<String> list2 = null;
        List<String> list3 = null;
        if (this.zues != null) {
            list2 = (List<String>)this.zeroday.i.sigma(this.zues.a(), width - 50);
            for (final String s : list2) {
                l4 = Math.max(l4, this.zeroday.i.zerodayisaminecraftcheat(s));
            }
        }
        if (this.pandora != null) {
            list3 = (List<String>)this.zeroday.i.sigma(this.pandora.a(), width - 50);
            for (final String s2 : list3) {
                l4 = Math.max(l4, this.zeroday.i.zerodayisaminecraftcheat(s2));
            }
        }
        if (list2 != null) {
            Gui.zerodayisaminecraftcheat(width / 2 - l4 / 2 - 1, k2 - 1, width / 2 + l4 / 2 + 1, k2 + list2.size() * this.zeroday.i.zeroday, Integer.MIN_VALUE);
            for (final String s3 : list2) {
                final int i4 = this.zeroday.i.zerodayisaminecraftcheat(s3);
                this.zeroday.i.zerodayisaminecraftcheat(s3, (float)(width / 2 - i4 / 2), (float)k2, -1);
                k2 += this.zeroday.i.zeroday;
            }
            ++k2;
        }
        Gui.zerodayisaminecraftcheat(width / 2 - l4 / 2 - 1, k2 - 1, width / 2 + l4 / 2 + 1, k2 + i2 * 9, Integer.MIN_VALUE);
        for (int k3 = 0; k3 < l3; ++k3) {
            final int l5 = k3 / i2;
            final int i5 = k3 % i2;
            int j4 = j3 + l5 * i3 + l5 * 5;
            final int k4 = k2 + i5 * 9;
            Gui.zerodayisaminecraftcheat(j4, k4, j4 + i3, k4 + 8, 553648127);
            GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.pandora();
            GlStateManager.d();
            GlStateManager.zerodayisaminecraftcheat(770, 771, 1, 0);
            if (k3 < list.size()) {
                final NetworkPlayerInfo networkplayerinfo2 = list.get(k3);
                String s4 = this.zerodayisaminecraftcheat(networkplayerinfo2);
                final GameProfile gameprofile = networkplayerinfo2.zerodayisaminecraftcheat();
                if (flag) {
                    final EntityPlayer entityplayer = this.zeroday.a.zerodayisaminecraftcheat(gameprofile.getId());
                    final boolean flag2 = entityplayer != null && entityplayer.zerodayisaminecraftcheat(EnumPlayerModelParts.zerodayisaminecraftcheat) && (gameprofile.getName().equals("Dinnerbone") || gameprofile.getName().equals("Grumm"));
                    this.zeroday.I().zerodayisaminecraftcheat(networkplayerinfo2.flux());
                    final int l6 = 8 + (flag2 ? 8 : 0);
                    final int i6 = 8 * (flag2 ? -1 : 1);
                    Gui.zerodayisaminecraftcheat(j4, k4, 8.0f, (float)l6, 8, i6, 8, 8, 64.0f, 64.0f);
                    if (entityplayer != null && entityplayer.zerodayisaminecraftcheat(EnumPlayerModelParts.vape)) {
                        final int j5 = 8 + (flag2 ? 8 : 0);
                        final int k5 = 8 * (flag2 ? -1 : 1);
                        Gui.zerodayisaminecraftcheat(j4, k4, 40.0f, (float)j5, 8, k5, 8, 8, 64.0f, 64.0f);
                    }
                    j4 += 9;
                }
                if (networkplayerinfo2.zeroday() == WorldSettings.zerodayisaminecraftcheat.zues) {
                    s4 = EnumChatFormatting.m + s4;
                    this.zeroday.i.zerodayisaminecraftcheat(s4, (float)j4, (float)k4, -1862270977);
                }
                else {
                    this.zeroday.i.zerodayisaminecraftcheat(s4, (float)j4, (float)k4, -1);
                }
                if (scoreObjectiveIn != null && networkplayerinfo2.zeroday() != WorldSettings.zerodayisaminecraftcheat.zues) {
                    final int k6 = j4 + i + 1;
                    final int l7 = k6 + m;
                    if (l7 - k6 > 5) {
                        this.zerodayisaminecraftcheat(scoreObjectiveIn, k4, gameprofile.getName(), k6, l7, networkplayerinfo2);
                    }
                }
                this.zerodayisaminecraftcheat(i3, j4 - (flag ? 9 : 0), k4, networkplayerinfo2);
            }
        }
        if (list3 != null) {
            k2 = k2 + i2 * 9 + 1;
            Gui.zerodayisaminecraftcheat(width / 2 - l4 / 2 - 1, k2 - 1, width / 2 + l4 / 2 + 1, k2 + list3.size() * this.zeroday.i.zeroday, Integer.MIN_VALUE);
            for (final String s5 : list3) {
                final int j6 = this.zeroday.i.zerodayisaminecraftcheat(s5);
                this.zeroday.i.zerodayisaminecraftcheat(s5, (float)(width / 2 - j6 / 2), (float)k2, -1);
                k2 += this.zeroday.i.zeroday;
            }
        }
    }
    
    protected void zerodayisaminecraftcheat(final int p_175245_1_, final int p_175245_2_, final int p_175245_3_, final NetworkPlayerInfo networkPlayerInfoIn) {
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.zeroday.I().zerodayisaminecraftcheat(GuiPlayerTabOverlay.o);
        final int i = 0;
        int j = 0;
        if (networkPlayerInfoIn.sigma() < 0) {
            j = 5;
        }
        else if (networkPlayerInfoIn.sigma() < 150) {
            j = 0;
        }
        else if (networkPlayerInfoIn.sigma() < 300) {
            j = 1;
        }
        else if (networkPlayerInfoIn.sigma() < 600) {
            j = 2;
        }
        else if (networkPlayerInfoIn.sigma() < 1000) {
            j = 3;
        }
        else {
            j = 4;
        }
        this.p += 100.0f;
        this.zeroday(p_175245_2_ + p_175245_1_ - 11, p_175245_3_, 0 + i * 10, 176 + j * 8, 10, 8);
        this.p -= 100.0f;
    }
    
    public static List<EntityPlayer> zerodayisaminecraftcheat() {
        final NetHandlerPlayClient var4 = Minecraft.s().e.zerodayisaminecraftcheat;
        final List<EntityPlayer> list = new ArrayList<EntityPlayer>();
        final List players = GuiPlayerTabOverlay.zerodayisaminecraftcheat.sortedCopy((Iterable)var4.sigma());
        for (final Object o : players) {
            final NetworkPlayerInfo info = (NetworkPlayerInfo)o;
            if (info == null) {
                continue;
            }
            list.add(Minecraft.s().a.zerodayisaminecraftcheat(info.zerodayisaminecraftcheat().getName()));
        }
        return list;
    }
    
    private void zerodayisaminecraftcheat(final ScoreObjective p_175247_1_, final int p_175247_2_, final String p_175247_3_, final int p_175247_4_, final int p_175247_5_, final NetworkPlayerInfo p_175247_6_) {
        final int i = p_175247_1_.zerodayisaminecraftcheat().zeroday(p_175247_3_, p_175247_1_).zeroday();
        if (p_175247_1_.zues() == IScoreObjectiveCriteria.zerodayisaminecraftcheat.zeroday) {
            this.zeroday.I().zerodayisaminecraftcheat(GuiPlayerTabOverlay.o);
            if (this.flux == p_175247_6_.i()) {
                if (i < p_175247_6_.c()) {
                    p_175247_6_.zerodayisaminecraftcheat(Minecraft.C());
                    p_175247_6_.zeroday((long)(this.sigma.zues() + 20));
                }
                else if (i > p_175247_6_.c()) {
                    p_175247_6_.zerodayisaminecraftcheat(Minecraft.C());
                    p_175247_6_.zeroday((long)(this.sigma.zues() + 10));
                }
            }
            if (Minecraft.C() - p_175247_6_.e() > 1000L || this.flux != p_175247_6_.i()) {
                p_175247_6_.zeroday(i);
                p_175247_6_.sigma(i);
                p_175247_6_.zerodayisaminecraftcheat(Minecraft.C());
            }
            p_175247_6_.sigma(this.flux);
            p_175247_6_.zeroday(i);
            final int j = MathHelper.flux(Math.max(i, p_175247_6_.d()) / 2.0f);
            final int k = Math.max(MathHelper.flux((float)(i / 2)), Math.max(MathHelper.flux((float)(p_175247_6_.d() / 2)), 10));
            final boolean flag = p_175247_6_.f() > this.sigma.zues() && (p_175247_6_.f() - this.sigma.zues()) / 3L % 2L == 1L;
            if (j > 0) {
                final float f = Math.min((p_175247_5_ - p_175247_4_ - 4) / (float)k, 9.0f);
                if (f > 3.0f) {
                    for (int l = j; l < k; ++l) {
                        this.zerodayisaminecraftcheat(p_175247_4_ + l * f, (float)p_175247_2_, flag ? 25 : 16, 0, 9, 9);
                    }
                    for (int j2 = 0; j2 < j; ++j2) {
                        this.zerodayisaminecraftcheat(p_175247_4_ + j2 * f, (float)p_175247_2_, flag ? 25 : 16, 0, 9, 9);
                        if (flag) {
                            if (j2 * 2 + 1 < p_175247_6_.d()) {
                                this.zerodayisaminecraftcheat(p_175247_4_ + j2 * f, (float)p_175247_2_, 70, 0, 9, 9);
                            }
                            if (j2 * 2 + 1 == p_175247_6_.d()) {
                                this.zerodayisaminecraftcheat(p_175247_4_ + j2 * f, (float)p_175247_2_, 79, 0, 9, 9);
                            }
                        }
                        if (j2 * 2 + 1 < i) {
                            this.zerodayisaminecraftcheat(p_175247_4_ + j2 * f, (float)p_175247_2_, (j2 >= 10) ? 160 : 52, 0, 9, 9);
                        }
                        if (j2 * 2 + 1 == i) {
                            this.zerodayisaminecraftcheat(p_175247_4_ + j2 * f, (float)p_175247_2_, (j2 >= 10) ? 169 : 61, 0, 9, 9);
                        }
                    }
                }
                else {
                    final float f2 = MathHelper.zerodayisaminecraftcheat(i / 20.0f, 0.0f, 1.0f);
                    final int i2 = (int)((1.0f - f2) * 255.0f) << 16 | (int)(f2 * 255.0f) << 8;
                    String s = new StringBuilder().append(i / 2.0f).toString();
                    if (p_175247_5_ - this.zeroday.i.zerodayisaminecraftcheat(String.valueOf(s) + "hp") >= p_175247_4_) {
                        s = String.valueOf(s) + "hp";
                    }
                    this.zeroday.i.zerodayisaminecraftcheat(s, (float)((p_175247_5_ + p_175247_4_) / 2 - this.zeroday.i.zerodayisaminecraftcheat(s) / 2), (float)p_175247_2_, i2);
                }
            }
        }
        else {
            final String s2 = new StringBuilder().append(EnumChatFormatting.g).append(i).toString();
            this.zeroday.i.zerodayisaminecraftcheat(s2, (float)(p_175247_5_ - this.zeroday.i.zerodayisaminecraftcheat(s2)), (float)p_175247_2_, 16777215);
        }
    }
    
    public void zerodayisaminecraftcheat(final IChatComponent footerIn) {
        this.pandora = footerIn;
    }
    
    public void zeroday(final IChatComponent headerIn) {
        this.zues = headerIn;
    }
    
    public void zeroday() {
        this.zues = null;
        this.pandora = null;
    }
    
    static class zerodayisaminecraftcheat implements Comparator<NetworkPlayerInfo>
    {
        private zerodayisaminecraftcheat() {
        }
        
        public int zerodayisaminecraftcheat(final NetworkPlayerInfo p_compare_1_, final NetworkPlayerInfo p_compare_2_) {
            final ScorePlayerTeam scoreplayerteam = p_compare_1_.momgetthecamera();
            final ScorePlayerTeam scoreplayerteam2 = p_compare_2_.momgetthecamera();
            return ComparisonChain.start().compareTrueFirst(p_compare_1_.zeroday() != WorldSettings.zerodayisaminecraftcheat.zues, p_compare_2_.zeroday() != WorldSettings.zerodayisaminecraftcheat.zues).compare((Comparable)((scoreplayerteam != null) ? scoreplayerteam.zerodayisaminecraftcheat() : ""), (Comparable)((scoreplayerteam2 != null) ? scoreplayerteam2.zerodayisaminecraftcheat() : "")).compare((Comparable)p_compare_1_.zerodayisaminecraftcheat().getName(), (Comparable)p_compare_2_.zerodayisaminecraftcheat().getName()).result();
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.q.vape.WorldInfo;
import net.minecraft.q.vape.ISaveFormat;
import net.minecraft.client.b.I18n;
import org.lwjgl.input.Keyboard;

public class GuiRenameWorld extends GuiScreen
{
    private GuiScreen zerodayisaminecraftcheat;
    private GuiTextField zeroday;
    private final String sigma;
    
    public GuiRenameWorld(final GuiScreen parentScreenIn, final String saveNameIn) {
        this.zerodayisaminecraftcheat = parentScreenIn;
        this.sigma = saveNameIn;
    }
    
    @Override
    public void sigma() {
        this.zeroday.zerodayisaminecraftcheat();
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        Keyboard.enableRepeatEvents(true);
        this.y.clear();
        this.y.add(new GuiButton(0, this.w / 2 - 100, this.x / 4 + 96 + 12, I18n.zerodayisaminecraftcheat("selectWorld.renameButton", new Object[0])));
        this.y.add(new GuiButton(1, this.w / 2 - 100, this.x / 4 + 120 + 12, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        final ISaveFormat isaveformat = this.u.vape();
        final WorldInfo worldinfo = isaveformat.sigma(this.sigma);
        final String s = worldinfo.b();
        (this.zeroday = new GuiTextField(2, this.C, this.w / 2 - 100, 60, 200, 20)).zeroday(true);
        this.zeroday.zerodayisaminecraftcheat(s);
    }
    
    @Override
    public void u_() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            if (button.vape == 1) {
                this.u.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
            }
            else if (button.vape == 0) {
                final ISaveFormat isaveformat = this.u.vape();
                isaveformat.zerodayisaminecraftcheat(this.sigma, this.zeroday.zeroday().trim());
                this.u.zerodayisaminecraftcheat(this.zerodayisaminecraftcheat);
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        this.zeroday.zerodayisaminecraftcheat(typedChar, keyCode);
        this.y.get(0).momgetthecamera = (this.zeroday.zeroday().trim().length() > 0);
        if (keyCode == 28 || keyCode == 156) {
            this.zerodayisaminecraftcheat(this.y.get(0));
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        this.zeroday.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("selectWorld.renameTitle", new Object[0]), this.w / 2, 20, 16777215);
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("selectWorld.enterName", new Object[0]), this.w / 2 - 100, 47, 10526880);
        this.zeroday.vape();
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
}

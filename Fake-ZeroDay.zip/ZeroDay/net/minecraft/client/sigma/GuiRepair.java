// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.b.IInventory;
import net.minecraft.c.ItemStack;
import java.util.List;
import net.minecraft.b.Slot;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C17PacketCustomPayload;
import net.minecraft.e.PacketBuffer;
import io.netty.buffer.Unpooled;
import java.io.IOException;
import net.minecraft.client.b.I18n;
import net.minecraft.client.a.GlStateManager;
import org.lwjgl.input.Keyboard;
import net.minecraft.b.Container;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.q.World;
import net.minecraft.vape.vape.InventoryPlayer;
import net.minecraft.b.ContainerRepair;
import net.minecraft.o.ResourceLocation;
import net.minecraft.b.ICrafting;
import net.minecraft.client.sigma.zeroday.GuiContainer;

public class GuiRepair extends GuiContainer implements ICrafting
{
    private static final ResourceLocation zerodayisaminecraftcheat;
    private ContainerRepair zeroday;
    private GuiTextField sigma;
    private InventoryPlayer pandora;
    
    static {
        zerodayisaminecraftcheat = new ResourceLocation("textures/gui/container/anvil.png");
    }
    
    public GuiRepair(final InventoryPlayer inventoryIn, final World worldIn) {
        super(new ContainerRepair(inventoryIn, worldIn, Minecraft.s().e));
        this.pandora = inventoryIn;
        this.zeroday = (ContainerRepair)this.d;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        super.zerodayisaminecraftcheat();
        Keyboard.enableRepeatEvents(true);
        final int i = (this.w - this.b) / 2;
        final int j = (this.x - this.c) / 2;
        (this.sigma = new GuiTextField(0, this.C, i + 62, j + 24, 103, 12)).vape(-1);
        this.sigma.momgetthecamera(-1);
        this.sigma.zerodayisaminecraftcheat(false);
        this.sigma.flux(30);
        this.d.zeroday(this);
        this.d.zerodayisaminecraftcheat(this);
    }
    
    @Override
    public void u_() {
        super.u_();
        Keyboard.enableRepeatEvents(false);
        this.d.zeroday(this);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY) {
        GlStateManager.flux();
        GlStateManager.c();
        this.C.zerodayisaminecraftcheat(I18n.zerodayisaminecraftcheat("container.repair", new Object[0]), 60, 6, 4210752);
        if (this.zeroday.zerodayisaminecraftcheat > 0) {
            int i = 8453920;
            boolean flag = true;
            String s = I18n.zerodayisaminecraftcheat("container.repair.cost", this.zeroday.zerodayisaminecraftcheat);
            if (this.zeroday.zerodayisaminecraftcheat >= 40 && !this.u.e.bz.pandora) {
                s = I18n.zerodayisaminecraftcheat("container.repair.expensive", new Object[0]);
                i = 16736352;
            }
            else if (!this.zeroday.zerodayisaminecraftcheat(2).zeroday()) {
                flag = false;
            }
            else if (!this.zeroday.zerodayisaminecraftcheat(2).zerodayisaminecraftcheat(this.pandora.pandora)) {
                i = 16736352;
            }
            if (flag) {
                final int j = 0xFF000000 | (i & 0xFCFCFC) >> 2 | (i & 0xFF000000);
                final int k = this.b - 8 - this.C.zerodayisaminecraftcheat(s);
                final int l = 67;
                if (this.C.zerodayisaminecraftcheat()) {
                    Gui.zerodayisaminecraftcheat(k - 3, l - 2, this.b - 7, l + 10, -16777216);
                    Gui.zerodayisaminecraftcheat(k - 2, l - 1, this.b - 8, l + 9, -12895429);
                }
                else {
                    this.C.zerodayisaminecraftcheat(s, k, l + 1, j);
                    this.C.zerodayisaminecraftcheat(s, k + 1, l, j);
                    this.C.zerodayisaminecraftcheat(s, k + 1, l + 1, j);
                }
                this.C.zerodayisaminecraftcheat(s, k, l, i);
            }
        }
        GlStateManager.zues();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        if (this.sigma.zerodayisaminecraftcheat(typedChar, keyCode)) {
            this.flux();
        }
        else {
            super.zerodayisaminecraftcheat(typedChar, keyCode);
        }
    }
    
    private void flux() {
        String s = this.sigma.zeroday();
        final Slot slot = this.zeroday.zerodayisaminecraftcheat(0);
        if (slot != null && slot.zeroday() && !slot.zerodayisaminecraftcheat().k() && s.equals(slot.zerodayisaminecraftcheat().i())) {
            s = "";
        }
        this.zeroday.zerodayisaminecraftcheat(s);
        this.u.e.zerodayisaminecraftcheat.zerodayisaminecraftcheat(new C17PacketCustomPayload("MC|ItemName", new PacketBuffer(Unpooled.buffer()).zerodayisaminecraftcheat(s)));
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        this.sigma.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
        GlStateManager.flux();
        GlStateManager.c();
        this.sigma.vape();
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final float partialTicks, final int mouseX, final int mouseY) {
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.u.I().zerodayisaminecraftcheat(GuiRepair.zerodayisaminecraftcheat);
        final int i = (this.w - this.b) / 2;
        final int j = (this.x - this.c) / 2;
        this.zeroday(i, j, 0, 0, this.b, this.c);
        this.zeroday(i + 59, j + 20, 0, this.c + (this.zeroday.zerodayisaminecraftcheat(0).zeroday() ? 0 : 16), 110, 16);
        if ((this.zeroday.zerodayisaminecraftcheat(0).zeroday() || this.zeroday.zerodayisaminecraftcheat(1).zeroday()) && !this.zeroday.zerodayisaminecraftcheat(2).zeroday()) {
            this.zeroday(i + 99, j + 45, this.b, 0, 28, 21);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Container containerToSend, final List<ItemStack> itemsList) {
        this.zerodayisaminecraftcheat(containerToSend, 0, containerToSend.zerodayisaminecraftcheat(0).zerodayisaminecraftcheat());
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Container containerToSend, final int slotInd, final ItemStack stack) {
        if (slotInd == 0) {
            this.sigma.zerodayisaminecraftcheat((stack == null) ? "" : stack.i());
            this.sigma.sigma(stack != null);
            if (stack != null) {
                this.flux();
            }
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Container containerIn, final int varToUpdate, final int newValue) {
    }
    
    @Override
    public void zerodayisaminecraftcheat(final Container p_175173_1_, final IInventory p_175173_2_) {
    }
}

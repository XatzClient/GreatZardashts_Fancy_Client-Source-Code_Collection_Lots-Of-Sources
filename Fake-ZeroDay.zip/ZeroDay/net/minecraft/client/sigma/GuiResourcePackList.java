// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.o.EnumChatFormatting;
import net.minecraft.client.a.Tessellator;
import net.minecraft.client.b.ResourcePackListEntry;
import java.util.List;
import net.minecraft.client.Minecraft;

public abstract class GuiResourcePackList extends GuiListExtended
{
    protected final Minecraft zerodayisaminecraftcheat;
    protected final List<ResourcePackListEntry> zeroday;
    
    public GuiResourcePackList(final Minecraft mcIn, final int p_i45055_2_, final int p_i45055_3_, final List<ResourcePackListEntry> p_i45055_4_) {
        super(mcIn, p_i45055_2_, p_i45055_3_, 32, p_i45055_3_ - 55 + 4, 36);
        this.zerodayisaminecraftcheat = mcIn;
        this.zeroday = p_i45055_4_;
        this.e = false;
        this.zerodayisaminecraftcheat(true, (int)(mcIn.i.zeroday * 1.5f));
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int p_148129_1_, final int p_148129_2_, final Tessellator p_148129_3_) {
        final String s = new StringBuilder().append(EnumChatFormatting.l).append(EnumChatFormatting.j).append(this.zues()).toString();
        this.zerodayisaminecraftcheat.i.zerodayisaminecraftcheat(s, p_148129_1_ + this.pandora / 2 - this.zerodayisaminecraftcheat.i.zerodayisaminecraftcheat(s) / 2, Math.min(this.flux + 3, p_148129_2_), 16777215);
    }
    
    protected abstract String zues();
    
    public List<ResourcePackListEntry> flux() {
        return this.zeroday;
    }
    
    @Override
    protected int zerodayisaminecraftcheat() {
        return this.flux().size();
    }
    
    public ResourcePackListEntry sigma(final int index) {
        return this.flux().get(index);
    }
    
    @Override
    public int s_() {
        return this.pandora;
    }
    
    @Override
    protected int vape() {
        return this.momgetthecamera - 6;
    }
}

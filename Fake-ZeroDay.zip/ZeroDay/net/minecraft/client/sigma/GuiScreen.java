// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.a.WorldRenderer;
import net.minecraft.client.a.vape.DefaultVertexFormats;
import net.minecraft.client.a.Tessellator;
import net.minecraft.o.ResourceLocation;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.h;
import zeroday.pandora.zerodayisaminecraftcheat.pandora.v;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import tv.twitch.chat.ChatUserInfo;
import net.minecraft.client.sigma.pandora.GuiTwitchUserMode;
import java.io.File;
import java.net.URISyntaxException;
import net.minecraft.momgetthecamera.ClickEvent;
import net.minecraft.m.StatBase;
import net.minecraft.d.NBTBase;
import java.util.Collection;
import net.minecraft.m.Achievement;
import net.minecraft.o.ChatComponentTranslation;
import net.minecraft.m.StatList;
import net.minecraft.vape.EntityList;
import net.minecraft.d.NBTException;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.d.JsonToNBT;
import net.minecraft.momgetthecamera.HoverEvent;
import net.minecraft.o.IChatComponent;
import java.util.Iterator;
import net.minecraft.client.a.RenderHelper;
import net.minecraft.client.a.GlStateManager;
import java.util.Arrays;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.c.ItemStack;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import org.apache.commons.lang3.StringUtils;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.DataFlavor;
import java.awt.Toolkit;
import java.io.IOException;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.apache.logging.log4j.LogManager;
import java.net.URI;
import java.util.List;
import net.minecraft.client.a.pandora.RenderItem;
import net.minecraft.client.Minecraft;
import com.google.common.base.Splitter;
import java.util.Set;
import org.apache.logging.log4j.Logger;

public abstract class GuiScreen extends Gui implements GuiYesNoCallback
{
    private static final Logger zerodayisaminecraftcheat;
    private static final Set<String> zeroday;
    private static final Splitter sigma;
    protected Minecraft u;
    protected RenderItem v;
    public int w;
    public int x;
    protected List<GuiButton> y;
    protected List<GuiColorButton> z;
    protected List<GuiLabel> A;
    public boolean B;
    protected FontRenderer C;
    private GuiButton pandora;
    private GuiColorButton zues;
    protected int D;
    protected long E;
    protected int F;
    private URI flux;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
        zeroday = Sets.newHashSet((Object[])new String[] { "http", "https" });
        sigma = Splitter.on('\n');
    }
    
    public GuiScreen() {
        this.y = (List<GuiButton>)Lists.newArrayList();
        this.z = (List<GuiColorButton>)Lists.newArrayList();
        this.A = (List<GuiLabel>)Lists.newArrayList();
    }
    
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        for (int i = 0; i < this.y.size(); ++i) {
            this.y.get(i).zerodayisaminecraftcheat(this.u, mouseX, mouseY);
        }
        for (int b = 0; b < this.z.size(); ++b) {
            this.z.get(b).zerodayisaminecraftcheat(this.u, mouseX, mouseY);
        }
        for (int j = 0; j < this.A.size(); ++j) {
            this.A.get(j).zerodayisaminecraftcheat(this.u, mouseX, mouseY);
        }
    }
    
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        if (keyCode == 1) {
            this.u.zerodayisaminecraftcheat((GuiScreen)null);
            if (this.u.k == null) {
                this.u.g();
            }
        }
    }
    
    public static String f() {
        try {
            final Transferable transferable = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
            if (transferable != null && transferable.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                return (String)transferable.getTransferData(DataFlavor.stringFlavor);
            }
        }
        catch (Exception ex) {}
        return "";
    }
    
    public static void pandora(final String copyText) {
        if (!StringUtils.isEmpty((CharSequence)copyText)) {
            try {
                final StringSelection stringselection = new StringSelection(copyText);
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringselection, null);
            }
            catch (Exception ex) {}
        }
    }
    
    protected void zeroday(final ItemStack stack, final int x, final int y) {
        final List<String> list = stack.zerodayisaminecraftcheat(this.u.e, this.u.r.q);
        for (int i = 0; i < list.size(); ++i) {
            if (i == 0) {
                list.set(i, stack.m().zues + list.get(i));
            }
            else {
                list.set(i, EnumChatFormatting.momgetthecamera + list.get(i));
            }
        }
        this.zerodayisaminecraftcheat(list, x, y);
    }
    
    public void zerodayisaminecraftcheat(final String tabName, final int mouseX, final int mouseY) {
        this.zerodayisaminecraftcheat(Arrays.asList(tabName), mouseX, mouseY);
    }
    
    public void zerodayisaminecraftcheat(final List<String> textLines, final int x, final int y) {
        if (!textLines.isEmpty()) {
            GlStateManager.t();
            RenderHelper.zerodayisaminecraftcheat();
            GlStateManager.flux();
            GlStateManager.a();
            int i = 0;
            for (final String s : textLines) {
                final int j = this.C.zerodayisaminecraftcheat(s);
                if (j > i) {
                    i = j;
                }
            }
            int k1 = x + 12;
            int l1 = y - 12;
            int i2 = 8;
            if (textLines.size() > 1) {
                i2 += 2 + (textLines.size() - 1) * 10;
            }
            if (k1 + i > this.w) {
                k1 -= 28 + i;
            }
            if (l1 + i2 + 6 > this.x) {
                l1 = this.x - i2 - 6;
            }
            this.p = 300.0f;
            this.v.zerodayisaminecraftcheat = 300.0f;
            final int m = -267386864;
            this.zerodayisaminecraftcheat(k1 - 3, l1 - 4, k1 + i + 3, l1 - 3, m, m);
            this.zerodayisaminecraftcheat(k1 - 3, l1 + i2 + 3, k1 + i + 3, l1 + i2 + 4, m, m);
            this.zerodayisaminecraftcheat(k1 - 3, l1 - 3, k1 + i + 3, l1 + i2 + 3, m, m);
            this.zerodayisaminecraftcheat(k1 - 4, l1 - 3, k1 - 3, l1 + i2 + 3, m, m);
            this.zerodayisaminecraftcheat(k1 + i + 3, l1 - 3, k1 + i + 4, l1 + i2 + 3, m, m);
            final int l2 = 1347420415;
            final int i3 = (l2 & 0xFEFEFE) >> 1 | (l2 & 0xFF000000);
            this.zerodayisaminecraftcheat(k1 - 3, l1 - 3 + 1, k1 - 3 + 1, l1 + i2 + 3 - 1, l2, i3);
            this.zerodayisaminecraftcheat(k1 + i + 2, l1 - 3 + 1, k1 + i + 3, l1 + i2 + 3 - 1, l2, i3);
            this.zerodayisaminecraftcheat(k1 - 3, l1 - 3, k1 + i + 3, l1 - 3 + 1, l2, l2);
            this.zerodayisaminecraftcheat(k1 - 3, l1 + i2 + 2, k1 + i + 3, l1 + i2 + 3, i3, i3);
            for (int j2 = 0; j2 < textLines.size(); ++j2) {
                final String s2 = textLines.get(j2);
                this.C.zerodayisaminecraftcheat(s2, (float)k1, (float)l1, -1);
                if (j2 == 0) {
                    l1 += 2;
                }
                l1 += 10;
            }
            this.p = 0.0f;
            this.v.zerodayisaminecraftcheat = 0.0f;
            GlStateManager.zues();
            GlStateManager.b();
            RenderHelper.zeroday();
            GlStateManager.s();
        }
    }
    
    protected void zerodayisaminecraftcheat(final IChatComponent p_175272_1_, final int p_175272_2_, final int p_175272_3_) {
        if (p_175272_1_ != null && p_175272_1_.vape().a() != null) {
            final HoverEvent hoverevent = p_175272_1_.vape().a();
            if (hoverevent.zerodayisaminecraftcheat() == HoverEvent.zerodayisaminecraftcheat.sigma) {
                ItemStack itemstack = null;
                try {
                    final NBTBase nbtbase = JsonToNBT.zerodayisaminecraftcheat(hoverevent.zeroday().momgetthecamera());
                    if (nbtbase instanceof NBTTagCompound) {
                        itemstack = ItemStack.zerodayisaminecraftcheat((NBTTagCompound)nbtbase);
                    }
                }
                catch (NBTException ex) {}
                if (itemstack != null) {
                    this.zeroday(itemstack, p_175272_2_, p_175272_3_);
                }
                else {
                    this.zerodayisaminecraftcheat(EnumChatFormatting.e + "Invalid Item!", p_175272_2_, p_175272_3_);
                }
            }
            else if (hoverevent.zerodayisaminecraftcheat() == HoverEvent.zerodayisaminecraftcheat.pandora) {
                if (this.u.r.q) {
                    try {
                        final NBTBase nbtbase2 = JsonToNBT.zerodayisaminecraftcheat(hoverevent.zeroday().momgetthecamera());
                        if (nbtbase2 instanceof NBTTagCompound) {
                            final List<String> list1 = (List<String>)Lists.newArrayList();
                            final NBTTagCompound nbttagcompound = (NBTTagCompound)nbtbase2;
                            list1.add(nbttagcompound.b("name"));
                            if (nbttagcompound.zeroday("type", 8)) {
                                final String s = nbttagcompound.b("type");
                                list1.add("Type: " + s + " (" + EntityList.zerodayisaminecraftcheat(s) + ")");
                            }
                            list1.add(nbttagcompound.b("id"));
                            this.zerodayisaminecraftcheat(list1, p_175272_2_, p_175272_3_);
                        }
                        else {
                            this.zerodayisaminecraftcheat(EnumChatFormatting.e + "Invalid Entity!", p_175272_2_, p_175272_3_);
                        }
                    }
                    catch (NBTException var10) {
                        this.zerodayisaminecraftcheat(EnumChatFormatting.e + "Invalid Entity!", p_175272_2_, p_175272_3_);
                    }
                }
            }
            else if (hoverevent.zerodayisaminecraftcheat() == HoverEvent.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
                this.zerodayisaminecraftcheat(GuiScreen.sigma.splitToList((CharSequence)hoverevent.zeroday().a()), p_175272_2_, p_175272_3_);
            }
            else if (hoverevent.zerodayisaminecraftcheat() == HoverEvent.zerodayisaminecraftcheat.zeroday) {
                final StatBase statbase = StatList.zerodayisaminecraftcheat(hoverevent.zeroday().momgetthecamera());
                if (statbase != null) {
                    final IChatComponent ichatcomponent = statbase.zues();
                    final IChatComponent ichatcomponent2 = new ChatComponentTranslation("stats.tooltip.type." + (statbase.pandora() ? "achievement" : "statistic"), new Object[0]);
                    ichatcomponent2.vape().zeroday(true);
                    final String s2 = (statbase instanceof Achievement) ? ((Achievement)statbase).flux() : null;
                    final List<String> list2 = (List<String>)Lists.newArrayList((Object[])new String[] { ichatcomponent.a(), ichatcomponent2.a() });
                    if (s2 != null) {
                        list2.addAll(this.C.sigma(s2, 150));
                    }
                    this.zerodayisaminecraftcheat(list2, p_175272_2_, p_175272_3_);
                }
                else {
                    this.zerodayisaminecraftcheat(EnumChatFormatting.e + "Invalid statistic/achievement!", p_175272_2_, p_175272_3_);
                }
            }
            GlStateManager.flux();
        }
    }
    
    protected void zerodayisaminecraftcheat(final String newChatText, final boolean shouldOverwrite) {
    }
    
    protected boolean zerodayisaminecraftcheat(final IChatComponent p_175276_1_) {
        if (p_175276_1_ == null) {
            return false;
        }
        final ClickEvent clickevent = p_175276_1_.vape().momgetthecamera();
        if (m()) {
            if (p_175276_1_.vape().b() != null) {
                this.zerodayisaminecraftcheat(p_175276_1_.vape().b(), false);
            }
        }
        else if (clickevent != null) {
            if (clickevent.zerodayisaminecraftcheat() == ClickEvent.zerodayisaminecraftcheat.zerodayisaminecraftcheat) {
                if (!this.u.r.g) {
                    return false;
                }
                try {
                    final URI uri = new URI(clickevent.zeroday());
                    final String s = uri.getScheme();
                    if (s == null) {
                        throw new URISyntaxException(clickevent.zeroday(), "Missing protocol");
                    }
                    if (!GuiScreen.zeroday.contains(s.toLowerCase())) {
                        throw new URISyntaxException(clickevent.zeroday(), "Unsupported protocol: " + s.toLowerCase());
                    }
                    if (this.u.r.h) {
                        this.flux = uri;
                        this.u.zerodayisaminecraftcheat(new GuiConfirmOpenLink(this, clickevent.zeroday(), 31102009, false));
                    }
                    else {
                        this.zerodayisaminecraftcheat(uri);
                    }
                }
                catch (URISyntaxException urisyntaxexception) {
                    GuiScreen.zerodayisaminecraftcheat.error("Can't open url for " + clickevent, (Throwable)urisyntaxexception);
                }
            }
            else if (clickevent.zerodayisaminecraftcheat() == ClickEvent.zerodayisaminecraftcheat.zeroday) {
                final URI uri2 = new File(clickevent.zeroday()).toURI();
                this.zerodayisaminecraftcheat(uri2);
            }
            else if (clickevent.zerodayisaminecraftcheat() == ClickEvent.zerodayisaminecraftcheat.zues) {
                this.zerodayisaminecraftcheat(clickevent.zeroday(), true);
            }
            else if (clickevent.zerodayisaminecraftcheat() == ClickEvent.zerodayisaminecraftcheat.sigma) {
                this.zeroday(clickevent.zeroday(), false);
            }
            else if (clickevent.zerodayisaminecraftcheat() == ClickEvent.zerodayisaminecraftcheat.pandora) {
                final ChatUserInfo chatuserinfo = this.u.R().zues(clickevent.zeroday());
                if (chatuserinfo != null) {
                    this.u.zerodayisaminecraftcheat(new GuiTwitchUserMode(this.u.R(), chatuserinfo));
                }
                else {
                    GuiScreen.zerodayisaminecraftcheat.error("Tried to handle twitch user but couldn't find them!");
                }
            }
            else {
                GuiScreen.zerodayisaminecraftcheat.error("Don't know how to handle " + clickevent);
            }
            return true;
        }
        return false;
    }
    
    public void zues(final String msg) {
        this.zeroday(msg, true);
    }
    
    public void flux(final String msg) {
        this.zeroday(msg, false);
    }
    
    public void zeroday(final String msg, final boolean addToChat) {
        if (addToChat) {
            this.u.o.pandora().zerodayisaminecraftcheat(msg);
        }
        this.u.e.zeroday(msg);
    }
    
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        if (mouseButton == 0) {
            for (int i = 0; i < this.y.size(); ++i) {
                final GuiButton guibutton = this.y.get(i);
                if (guibutton.sigma(this.u, mouseX, mouseY)) {
                    (this.pandora = guibutton).zerodayisaminecraftcheat(this.u.P());
                    this.zerodayisaminecraftcheat(guibutton);
                }
            }
            for (int i = 0; i < this.z.size(); ++i) {
                final GuiColorButton guibutton2 = this.z.get(i);
                if (guibutton2.sigma(this.u, mouseX, mouseY)) {
                    (this.zues = guibutton2).zerodayisaminecraftcheat(this.u.P());
                    this.zerodayisaminecraftcheat(guibutton2);
                }
            }
        }
    }
    
    protected void zeroday(final int mouseX, final int mouseY, final int state) {
        if (this.pandora != null && state == 0) {
            this.pandora.zerodayisaminecraftcheat(mouseX, mouseY);
            this.pandora = null;
        }
        if (this.zues != null && state == 0) {
            this.zues.zerodayisaminecraftcheat(mouseX, mouseY);
            this.zues = null;
        }
    }
    
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int clickedMouseButton, final long timeSinceLastClick) {
    }
    
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
    }
    
    protected void zerodayisaminecraftcheat(final GuiColorButton button) throws IOException {
    }
    
    public void zerodayisaminecraftcheat(final Minecraft mc, final int width, final int height) {
        this.u = mc;
        this.v = mc.Z();
        this.C = mc.i;
        this.w = width;
        this.x = height;
        this.y.clear();
        this.z.clear();
        this.zerodayisaminecraftcheat();
    }
    
    public void zerodayisaminecraftcheat() {
    }
    
    public void g() throws IOException {
        if (Mouse.isCreated()) {
            while (Mouse.next()) {
                this.b_();
            }
        }
        if (Keyboard.isCreated()) {
            while (Keyboard.next()) {
                this.h();
            }
        }
    }
    
    public void b_() throws IOException {
        final int i = Mouse.getEventX() * this.w / this.u.flux;
        final int j = this.x - Mouse.getEventY() * this.x / this.u.vape - 1;
        final int k = Mouse.getEventButton();
        if (Mouse.getEventButtonState()) {
            if (this.u.r.s && this.F++ > 0) {
                return;
            }
            this.D = k;
            this.E = Minecraft.C();
            this.zerodayisaminecraftcheat(i, j, this.D);
        }
        else if (k != -1) {
            if (this.u.r.s && --this.F > 0) {
                return;
            }
            this.D = -1;
            this.zeroday(i, j, k);
        }
        else if (this.D != -1 && this.E > 0L) {
            final long l = Minecraft.C() - this.E;
            this.zerodayisaminecraftcheat(i, j, this.D, l);
        }
    }
    
    public void h() throws IOException {
        if (Keyboard.getEventKeyState()) {
            this.zerodayisaminecraftcheat(Keyboard.getEventCharacter(), Keyboard.getEventKey());
        }
        this.u.S();
    }
    
    public void sigma() {
    }
    
    public void u_() {
    }
    
    public void i() {
        this.pandora(0);
    }
    
    public void j() {
        this.zues(0);
    }
    
    public void k() {
        this.sigma(0);
    }
    
    public void sigma(final int tint) {
        if (this.u.a != null) {
            if (!zeroday.pandora.zerodayisaminecraftcheat.pandora.v.zerodayisaminecraftcheat) {
                this.zerodayisaminecraftcheat(0, 0, this.w, this.x, -1072689136, -804253680);
            }
            else {
                this.zerodayisaminecraftcheat(0, 0, this.w, this.x, 0, (h.zues == 0) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.zerodayisaminecraftcheat(50000000L, 1.0f).getRGB() : ((h.zerodayisaminecraftcheat == 65536) ? zeroday.pandora.zerodayisaminecraftcheat.h.h.pandora(50000000L, 1.0f).getRGB() : h.zues));
            }
        }
        else {
            this.flux(tint);
        }
    }
    
    public void pandora(final int tint) {
        if (this.u.a != null) {
            final ScaledResolution sr = new ScaledResolution(this.u);
            this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/ZeroDayBG.png"));
            Gui.zerodayisaminecraftcheat(0, 0, 0.0f, 0.0f, sr.zerodayisaminecraftcheat(), sr.zeroday(), (float)sr.zerodayisaminecraftcheat(), (float)sr.zeroday());
        }
        else {
            final ScaledResolution sr = new ScaledResolution(this.u);
            this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/ZeroDayBG.png"));
            Gui.zerodayisaminecraftcheat(0, 0, 0.0f, 0.0f, sr.zerodayisaminecraftcheat(), sr.zeroday(), (float)sr.zerodayisaminecraftcheat(), (float)sr.zeroday());
        }
    }
    
    public void zues(final int tint) {
        if (this.u.a != null) {
            final ScaledResolution sr = new ScaledResolution(this.u);
            this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/nebulalitzoom.jpg"));
            Gui.zerodayisaminecraftcheat(0, 0, 0.0f, 0.0f, sr.zerodayisaminecraftcheat(), sr.zeroday(), (float)sr.zerodayisaminecraftcheat(), (float)sr.zeroday());
        }
        else {
            final ScaledResolution sr = new ScaledResolution(this.u);
            this.u.I().zerodayisaminecraftcheat(new ResourceLocation("ZeroDay/nebulalitzoom.jpg"));
            Gui.zerodayisaminecraftcheat(0, 0, 0.0f, 0.0f, sr.zerodayisaminecraftcheat(), sr.zeroday(), (float)sr.zerodayisaminecraftcheat(), (float)sr.zeroday());
        }
    }
    
    public void flux(final int tint) {
        GlStateManager.flux();
        GlStateManager.f();
        final Tessellator tessellator = Tessellator.zerodayisaminecraftcheat();
        final WorldRenderer worldrenderer = tessellator.sigma();
        this.u.I().zerodayisaminecraftcheat(GuiScreen.m);
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        final float f = 32.0f;
        worldrenderer.zerodayisaminecraftcheat(7, DefaultVertexFormats.a);
        worldrenderer.zeroday(0.0, this.x, 0.0).zerodayisaminecraftcheat(0.0, this.x / 32.0f + tint).zeroday(64, 64, 64, 255).zues();
        worldrenderer.zeroday(this.w, this.x, 0.0).zerodayisaminecraftcheat(this.w / 32.0f, this.x / 32.0f + tint).zeroday(64, 64, 64, 255).zues();
        worldrenderer.zeroday(this.w, 0.0, 0.0).zerodayisaminecraftcheat(this.w / 32.0f, tint).zeroday(64, 64, 64, 255).zues();
        worldrenderer.zeroday(0.0, 0.0, 0.0).zerodayisaminecraftcheat(0.0, tint).zeroday(64, 64, 64, 255).zues();
        tessellator.zeroday();
    }
    
    public boolean zues() {
        return true;
    }
    
    @Override
    public void zerodayisaminecraftcheat(final boolean result, final int id) {
        if (id == 31102009) {
            if (result) {
                this.zerodayisaminecraftcheat(this.flux);
            }
            this.flux = null;
            this.u.zerodayisaminecraftcheat(this);
        }
    }
    
    private void zerodayisaminecraftcheat(final URI p_175282_1_) {
        try {
            final Class<?> oclass = Class.forName("java.awt.Desktop");
            final Object object = oclass.getMethod("getDesktop", (Class<?>[])new Class[0]).invoke(null, new Object[0]);
            oclass.getMethod("browse", URI.class).invoke(object, p_175282_1_);
        }
        catch (Throwable throwable) {
            GuiScreen.zerodayisaminecraftcheat.error("Couldn't open link", throwable);
        }
    }
    
    public static boolean l() {
        return Minecraft.zerodayisaminecraftcheat ? (Keyboard.isKeyDown(219) || Keyboard.isKeyDown(220)) : (Keyboard.isKeyDown(29) || Keyboard.isKeyDown(157));
    }
    
    public static boolean m() {
        return Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54);
    }
    
    public static boolean n() {
        return Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184);
    }
    
    public static boolean vape(final int p_175277_0_) {
        return p_175277_0_ == 45 && l() && !m() && !n();
    }
    
    public static boolean momgetthecamera(final int p_175279_0_) {
        return p_175279_0_ == 47 && l() && !m() && !n();
    }
    
    public static boolean a(final int p_175280_0_) {
        return p_175280_0_ == 46 && l() && !m() && !n();
    }
    
    public static boolean b(final int p_175278_0_) {
        return p_175278_0_ == 30 && l() && !m() && !n();
    }
    
    public void zeroday(final Minecraft mcIn, final int p_175273_2_, final int p_175273_3_) {
        this.zerodayisaminecraftcheat(mcIn, p_175273_2_, p_175273_3_);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import java.io.IOException;
import net.minecraft.client.b.I18n;
import org.lwjgl.input.Keyboard;
import java.net.IDN;
import com.google.common.base.Predicate;
import net.minecraft.client.zues.ServerData;

public class GuiScreenAddServer extends GuiScreen
{
    private final GuiScreen zerodayisaminecraftcheat;
    private final ServerData zeroday;
    private GuiTextField sigma;
    private GuiTextField pandora;
    private GuiButton zues;
    private Predicate<String> flux;
    
    public GuiScreenAddServer(final GuiScreen p_i1033_1_, final ServerData p_i1033_2_) {
        this.flux = (Predicate<String>)new Predicate<String>() {
            public boolean zerodayisaminecraftcheat(final String p_apply_1_) {
                if (p_apply_1_.length() == 0) {
                    return true;
                }
                final String[] astring = p_apply_1_.split(":");
                if (astring.length == 0) {
                    return true;
                }
                try {
                    final String s = IDN.toASCII(astring[0]);
                    return true;
                }
                catch (IllegalArgumentException var4) {
                    return false;
                }
            }
        };
        this.zerodayisaminecraftcheat = p_i1033_1_;
        this.zeroday = p_i1033_2_;
    }
    
    @Override
    public void sigma() {
        this.pandora.zerodayisaminecraftcheat();
        this.sigma.zerodayisaminecraftcheat();
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        Keyboard.enableRepeatEvents(true);
        this.y.clear();
        this.y.add(new GuiButton(0, this.w / 2 - 100, this.x / 4 + 96 + 18, I18n.zerodayisaminecraftcheat("addServer.add", new Object[0])));
        this.y.add(new GuiButton(1, this.w / 2 - 100, this.x / 4 + 120 + 18, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        this.y.add(this.zues = new GuiButton(2, this.w / 2 - 100, this.x / 4 + 72, String.valueOf(I18n.zerodayisaminecraftcheat("addServer.resourcePack", new Object[0])) + ": " + this.zeroday.zeroday().zerodayisaminecraftcheat().a()));
        (this.pandora = new GuiTextField(0, this.C, this.w / 2 - 100, 66, 200, 20)).zeroday(true);
        this.pandora.zerodayisaminecraftcheat(this.zeroday.zerodayisaminecraftcheat);
        (this.sigma = new GuiTextField(1, this.C, this.w / 2 - 100, 106, 200, 20)).flux(128);
        this.sigma.zerodayisaminecraftcheat(this.zeroday.zeroday);
        this.sigma.zerodayisaminecraftcheat(this.flux);
        this.y.get(0).momgetthecamera = (this.sigma.zeroday().length() > 0 && this.sigma.zeroday().split(":").length > 0 && this.pandora.zeroday().length() > 0);
    }
    
    @Override
    public void u_() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            if (button.vape == 2) {
                this.zeroday.zerodayisaminecraftcheat(ServerData.zerodayisaminecraftcheat.values()[(this.zeroday.zeroday().ordinal() + 1) % ServerData.zerodayisaminecraftcheat.values().length]);
                this.zues.flux = String.valueOf(I18n.zerodayisaminecraftcheat("addServer.resourcePack", new Object[0])) + ": " + this.zeroday.zeroday().zerodayisaminecraftcheat().a();
            }
            else if (button.vape == 1) {
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(false, 0);
            }
            else if (button.vape == 0) {
                this.zeroday.zerodayisaminecraftcheat = this.pandora.zeroday();
                this.zeroday.zeroday = this.sigma.zeroday();
                this.zerodayisaminecraftcheat.zerodayisaminecraftcheat(true, 0);
            }
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        this.pandora.zerodayisaminecraftcheat(typedChar, keyCode);
        this.sigma.zerodayisaminecraftcheat(typedChar, keyCode);
        if (keyCode == 15) {
            this.pandora.zeroday(!this.pandora.c());
            this.sigma.zeroday(!this.sigma.c());
        }
        if (keyCode == 28 || keyCode == 156) {
            this.zerodayisaminecraftcheat(this.y.get(0));
        }
        this.y.get(0).momgetthecamera = (this.sigma.zeroday().length() > 0 && this.sigma.zeroday().split(":").length > 0 && this.pandora.zeroday().length() > 0);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        this.sigma.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
        this.pandora.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        this.k();
        Gui.zerodayisaminecraftcheat(this.C, I18n.zerodayisaminecraftcheat("addServer.title", new Object[0]), this.w / 2, 17, 16777215);
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("addServer.enterName", new Object[0]), this.w / 2 - 100, 53, 10526880);
        Gui.zeroday(this.C, I18n.zerodayisaminecraftcheat("addServer.enterIp", new Object[0]), this.w / 2 - 100, 94, 10526880);
        this.pandora.vape();
        this.sigma.vape();
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
}

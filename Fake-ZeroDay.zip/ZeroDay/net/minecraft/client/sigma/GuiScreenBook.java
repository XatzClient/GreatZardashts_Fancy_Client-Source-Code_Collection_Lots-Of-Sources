// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.sigma;

import net.minecraft.client.Minecraft;
import java.util.Iterator;
import net.minecraft.momgetthecamera.ClickEvent;
import com.google.common.collect.Lists;
import com.google.gson.JsonParseException;
import net.minecraft.c.ItemEditableBook;
import net.minecraft.client.a.GlStateManager;
import net.minecraft.o.EnumChatFormatting;
import net.minecraft.o.ChatAllowedCharacters;
import java.io.IOException;
import net.minecraft.e.Packet;
import net.minecraft.e.sigma.zerodayisaminecraftcheat.C17PacketCustomPayload;
import net.minecraft.e.PacketBuffer;
import io.netty.buffer.Unpooled;
import net.minecraft.a.Items;
import net.minecraft.o.ChatComponentText;
import net.minecraft.client.b.I18n;
import org.lwjgl.input.Keyboard;
import net.minecraft.d.NBTTagCompound;
import net.minecraft.d.NBTBase;
import net.minecraft.d.NBTTagString;
import org.apache.logging.log4j.LogManager;
import net.minecraft.o.IChatComponent;
import java.util.List;
import net.minecraft.d.NBTTagList;
import net.minecraft.c.ItemStack;
import net.minecraft.vape.vape.EntityPlayer;
import net.minecraft.o.ResourceLocation;
import org.apache.logging.log4j.Logger;

public class GuiScreenBook extends GuiScreen
{
    private static final Logger zerodayisaminecraftcheat;
    private static final ResourceLocation zeroday;
    private final EntityPlayer sigma;
    private final ItemStack pandora;
    private final boolean zues;
    private boolean flux;
    private boolean vape;
    private int momgetthecamera;
    private int a;
    private int b;
    private int c;
    private int d;
    private NBTTagList e;
    private String f;
    private List<IChatComponent> g;
    private int h;
    private zerodayisaminecraftcheat i;
    private zerodayisaminecraftcheat j;
    private GuiButton k;
    private GuiButton l;
    private GuiButton q;
    private GuiButton r;
    
    static {
        zerodayisaminecraftcheat = LogManager.getLogger();
        zeroday = new ResourceLocation("textures/gui/book.png");
    }
    
    public GuiScreenBook(final EntityPlayer player, final ItemStack book, final boolean isUnsigned) {
        this.a = 192;
        this.b = 192;
        this.c = 1;
        this.f = "";
        this.h = -1;
        this.sigma = player;
        this.pandora = book;
        this.zues = isUnsigned;
        if (book.f()) {
            final NBTTagCompound nbttagcompound = book.g();
            this.e = nbttagcompound.sigma("pages", 8);
            if (this.e != null) {
                this.e = (NBTTagList)this.e.zeroday();
                this.c = this.e.zues();
                if (this.c < 1) {
                    this.c = 1;
                }
            }
        }
        if (this.e == null && isUnsigned) {
            (this.e = new NBTTagList()).zerodayisaminecraftcheat(new NBTTagString(""));
            this.c = 1;
        }
    }
    
    @Override
    public void sigma() {
        super.sigma();
        ++this.momgetthecamera;
    }
    
    @Override
    public void zerodayisaminecraftcheat() {
        this.y.clear();
        Keyboard.enableRepeatEvents(true);
        if (this.zues) {
            this.y.add(this.l = new GuiButton(3, this.w / 2 - 100, 4 + this.b, 98, 20, I18n.zerodayisaminecraftcheat("book.signButton", new Object[0])));
            this.y.add(this.k = new GuiButton(0, this.w / 2 + 2, 4 + this.b, 98, 20, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
            this.y.add(this.q = new GuiButton(5, this.w / 2 - 100, 4 + this.b, 98, 20, I18n.zerodayisaminecraftcheat("book.finalizeButton", new Object[0])));
            this.y.add(this.r = new GuiButton(4, this.w / 2 + 2, 4 + this.b, 98, 20, I18n.zerodayisaminecraftcheat("gui.cancel", new Object[0])));
        }
        else {
            this.y.add(this.k = new GuiButton(0, this.w / 2 - 100, 4 + this.b, 200, 20, I18n.zerodayisaminecraftcheat("gui.done", new Object[0])));
        }
        final int i = (this.w - this.a) / 2;
        final int j = 2;
        this.y.add(this.i = new zerodayisaminecraftcheat(1, i + 120, j + 154, true));
        this.y.add(this.j = new zerodayisaminecraftcheat(2, i + 38, j + 154, false));
        this.vape();
    }
    
    @Override
    public void u_() {
        Keyboard.enableRepeatEvents(false);
    }
    
    private void vape() {
        this.i.a = (!this.vape && (this.d < this.c - 1 || this.zues));
        this.j.a = (!this.vape && this.d > 0);
        this.k.a = (!this.zues || !this.vape);
        if (this.zues) {
            this.l.a = !this.vape;
            this.r.a = this.vape;
            this.q.a = this.vape;
            this.q.momgetthecamera = (this.f.trim().length() > 0);
        }
    }
    
    private void zerodayisaminecraftcheat(final boolean publish) throws IOException {
        if (this.zues && this.flux && this.e != null) {
            while (this.e.zues() > 1) {
                final String s = this.e.flux(this.e.zues() - 1);
                if (s.length() != 0) {
                    break;
                }
                this.e.zerodayisaminecraftcheat(this.e.zues() - 1);
            }
            if (this.pandora.f()) {
                final NBTTagCompound nbttagcompound = this.pandora.g();
                nbttagcompound.zerodayisaminecraftcheat("pages", this.e);
            }
            else {
                this.pandora.zerodayisaminecraftcheat("pages", this.e);
            }
            String s2 = "MC|BEdit";
            if (publish) {
                s2 = "MC|BSign";
                this.pandora.zerodayisaminecraftcheat("author", new NBTTagString(this.sigma.l_()));
                this.pandora.zerodayisaminecraftcheat("title", new NBTTagString(this.f.trim()));
                for (int i = 0; i < this.e.zues(); ++i) {
                    String s3 = this.e.flux(i);
                    final IChatComponent ichatcomponent = new ChatComponentText(s3);
                    s3 = IChatComponent.zerodayisaminecraftcheat.zerodayisaminecraftcheat(ichatcomponent);
                    this.e.zerodayisaminecraftcheat(i, new NBTTagString(s3));
                }
                this.pandora.zerodayisaminecraftcheat(Items.bF);
            }
            final PacketBuffer packetbuffer = new PacketBuffer(Unpooled.buffer());
            packetbuffer.zerodayisaminecraftcheat(this.pandora);
            this.u.o().zerodayisaminecraftcheat(new C17PacketCustomPayload(s2, packetbuffer));
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final GuiButton button) throws IOException {
        if (button.momgetthecamera) {
            if (button.vape == 0) {
                this.u.zerodayisaminecraftcheat((GuiScreen)null);
                this.zerodayisaminecraftcheat(false);
            }
            else if (button.vape == 3 && this.zues) {
                this.vape = true;
            }
            else if (button.vape == 1) {
                if (this.d < this.c - 1) {
                    ++this.d;
                }
                else if (this.zues) {
                    this.momgetthecamera();
                    if (this.d < this.c - 1) {
                        ++this.d;
                    }
                }
            }
            else if (button.vape == 2) {
                if (this.d > 0) {
                    --this.d;
                }
            }
            else if (button.vape == 5 && this.vape) {
                this.zerodayisaminecraftcheat(true);
                this.u.zerodayisaminecraftcheat((GuiScreen)null);
            }
            else if (button.vape == 4 && this.vape) {
                this.vape = false;
            }
            this.vape();
        }
    }
    
    private void momgetthecamera() {
        if (this.e != null && this.e.zues() < 50) {
            this.e.zerodayisaminecraftcheat(new NBTTagString(""));
            ++this.c;
            this.flux = true;
        }
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final char typedChar, final int keyCode) throws IOException {
        super.zerodayisaminecraftcheat(typedChar, keyCode);
        if (this.zues) {
            if (this.vape) {
                this.sigma(typedChar, keyCode);
            }
            else {
                this.zeroday(typedChar, keyCode);
            }
        }
    }
    
    private void zeroday(final char typedChar, final int keyCode) {
        if (GuiScreen.momgetthecamera(keyCode)) {
            this.zeroday(GuiScreen.f());
        }
        else {
            switch (keyCode) {
                case 14: {
                    final String s = this.a();
                    if (s.length() > 0) {
                        this.zerodayisaminecraftcheat(s.substring(0, s.length() - 1));
                    }
                }
                case 28:
                case 156: {
                    this.zeroday("\n");
                }
                default: {
                    if (ChatAllowedCharacters.zerodayisaminecraftcheat(typedChar)) {
                        this.zeroday(Character.toString(typedChar));
                        break;
                    }
                    break;
                }
            }
        }
    }
    
    private void sigma(final char p_146460_1_, final int p_146460_2_) throws IOException {
        switch (p_146460_2_) {
            case 14: {
                if (!this.f.isEmpty()) {
                    this.f = this.f.substring(0, this.f.length() - 1);
                    this.vape();
                }
            }
            case 28:
            case 156: {
                if (!this.f.isEmpty()) {
                    this.zerodayisaminecraftcheat(true);
                    this.u.zerodayisaminecraftcheat((GuiScreen)null);
                }
            }
            default: {
                if (this.f.length() < 16 && ChatAllowedCharacters.zerodayisaminecraftcheat(p_146460_1_)) {
                    this.f = String.valueOf(this.f) + Character.toString(p_146460_1_);
                    this.vape();
                    this.flux = true;
                }
            }
        }
    }
    
    private String a() {
        return (this.e != null && this.d >= 0 && this.d < this.e.zues()) ? this.e.flux(this.d) : "";
    }
    
    private void zerodayisaminecraftcheat(final String p_146457_1_) {
        if (this.e != null && this.d >= 0 && this.d < this.e.zues()) {
            this.e.zerodayisaminecraftcheat(this.d, new NBTTagString(p_146457_1_));
            this.flux = true;
        }
    }
    
    private void zeroday(final String p_146459_1_) {
        final String s = this.a();
        final String s2 = String.valueOf(s) + p_146459_1_;
        final int i = this.C.zeroday(String.valueOf(s2) + EnumChatFormatting.zerodayisaminecraftcheat + "_", 118);
        if (i <= 128 && s2.length() < 256) {
            this.zerodayisaminecraftcheat(s2);
        }
    }
    
    @Override
    public void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final float partialTicks) {
        GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
        this.u.I().zerodayisaminecraftcheat(GuiScreenBook.zeroday);
        final int i = (this.w - this.a) / 2;
        final int j = 2;
        this.zeroday(i, j, 0, 0, this.a, this.b);
        if (this.vape) {
            String s = this.f;
            if (this.zues) {
                if (this.momgetthecamera / 6 % 2 == 0) {
                    s = String.valueOf(s) + EnumChatFormatting.zerodayisaminecraftcheat + "_";
                }
                else {
                    s = String.valueOf(s) + EnumChatFormatting.momgetthecamera + "_";
                }
            }
            final String s2 = I18n.zerodayisaminecraftcheat("book.editTitle", new Object[0]);
            final int k = this.C.zerodayisaminecraftcheat(s2);
            this.C.zerodayisaminecraftcheat(s2, i + 36 + (116 - k) / 2, j + 16 + 16, 0);
            final int l = this.C.zerodayisaminecraftcheat(s);
            this.C.zerodayisaminecraftcheat(s, i + 36 + (116 - l) / 2, j + 48, 0);
            final String s3 = I18n.zerodayisaminecraftcheat("book.byAuthor", this.sigma.l_());
            final int i2 = this.C.zerodayisaminecraftcheat(s3);
            this.C.zerodayisaminecraftcheat(EnumChatFormatting.a + s3, i + 36 + (116 - i2) / 2, j + 48 + 10, 0);
            final String s4 = I18n.zerodayisaminecraftcheat("book.finalizeWarning", new Object[0]);
            this.C.zerodayisaminecraftcheat(s4, i + 36, j + 80, 116, 0);
        }
        else {
            final String s5 = I18n.zerodayisaminecraftcheat("book.pageIndicator", this.d + 1, this.c);
            String s6 = "";
            if (this.e != null && this.d >= 0 && this.d < this.e.zues()) {
                s6 = this.e.flux(this.d);
            }
            if (this.zues) {
                if (this.C.zeroday()) {
                    s6 = String.valueOf(s6) + "_";
                }
                else if (this.momgetthecamera / 6 % 2 == 0) {
                    s6 = String.valueOf(s6) + EnumChatFormatting.zerodayisaminecraftcheat + "_";
                }
                else {
                    s6 = String.valueOf(s6) + EnumChatFormatting.momgetthecamera + "_";
                }
            }
            else if (this.h != this.d) {
                if (ItemEditableBook.zeroday(this.pandora.g())) {
                    try {
                        final IChatComponent ichatcomponent = IChatComponent.zerodayisaminecraftcheat.zerodayisaminecraftcheat(s6);
                        this.g = ((ichatcomponent != null) ? GuiUtilRenderComponents.zerodayisaminecraftcheat(ichatcomponent, 116, this.C, true, true) : null);
                    }
                    catch (JsonParseException var13) {
                        this.g = null;
                    }
                }
                else {
                    final ChatComponentText chatcomponenttext = new ChatComponentText(String.valueOf(EnumChatFormatting.zues.toString()) + "* Invalid book tag *");
                    this.g = (List<IChatComponent>)Lists.newArrayList((Iterable)chatcomponenttext);
                }
                this.h = this.d;
            }
            final int j2 = this.C.zerodayisaminecraftcheat(s5);
            this.C.zerodayisaminecraftcheat(s5, i - j2 + this.a - 44, j + 16, 0);
            if (this.g == null) {
                this.C.zerodayisaminecraftcheat(s6, i + 36, j + 16 + 16, 116, 0);
            }
            else {
                for (int k2 = Math.min(128 / this.C.zeroday, this.g.size()), l2 = 0; l2 < k2; ++l2) {
                    final IChatComponent ichatcomponent2 = this.g.get(l2);
                    this.C.zerodayisaminecraftcheat(ichatcomponent2.momgetthecamera(), i + 36, j + 16 + 16 + l2 * this.C.zeroday, 0);
                }
                final IChatComponent ichatcomponent3 = this.zerodayisaminecraftcheat(mouseX, mouseY);
                if (ichatcomponent3 != null) {
                    this.zerodayisaminecraftcheat(ichatcomponent3, mouseX, mouseY);
                }
            }
        }
        super.zerodayisaminecraftcheat(mouseX, mouseY, partialTicks);
    }
    
    @Override
    protected void zerodayisaminecraftcheat(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        if (mouseButton == 0) {
            final IChatComponent ichatcomponent = this.zerodayisaminecraftcheat(mouseX, mouseY);
            if (this.zerodayisaminecraftcheat(ichatcomponent)) {
                return;
            }
        }
        super.zerodayisaminecraftcheat(mouseX, mouseY, mouseButton);
    }
    
    @Override
    protected boolean zerodayisaminecraftcheat(final IChatComponent p_175276_1_) {
        final ClickEvent clickevent = (p_175276_1_ == null) ? null : p_175276_1_.vape().momgetthecamera();
        if (clickevent == null) {
            return false;
        }
        if (clickevent.zerodayisaminecraftcheat() == ClickEvent.zerodayisaminecraftcheat.flux) {
            final String s = clickevent.zeroday();
            try {
                final int i = Integer.parseInt(s) - 1;
                if (i >= 0 && i < this.c && i != this.d) {
                    this.d = i;
                    this.vape();
                    return true;
                }
            }
            catch (Throwable t) {}
            return false;
        }
        final boolean flag = super.zerodayisaminecraftcheat(p_175276_1_);
        if (flag && clickevent.zerodayisaminecraftcheat() == ClickEvent.zerodayisaminecraftcheat.sigma) {
            this.u.zerodayisaminecraftcheat((GuiScreen)null);
        }
        return flag;
    }
    
    public IChatComponent zerodayisaminecraftcheat(final int p_175385_1_, final int p_175385_2_) {
        if (this.g == null) {
            return null;
        }
        final int i = p_175385_1_ - (this.w - this.a) / 2 - 36;
        final int j = p_175385_2_ - 2 - 16 - 16;
        if (i < 0 || j < 0) {
            return null;
        }
        final int k = Math.min(128 / this.C.zeroday, this.g.size());
        if (i <= 116 && j < this.u.i.zeroday * k + k) {
            final int l = j / this.u.i.zeroday;
            if (l >= 0 && l < this.g.size()) {
                final IChatComponent ichatcomponent = this.g.get(l);
                int i2 = 0;
                for (final IChatComponent ichatcomponent2 : ichatcomponent) {
                    if (ichatcomponent2 instanceof ChatComponentText) {
                        i2 += this.u.i.zerodayisaminecraftcheat(((ChatComponentText)ichatcomponent2).zerodayisaminecraftcheat());
                        if (i2 > i) {
                            return ichatcomponent2;
                        }
                        continue;
                    }
                }
            }
            return null;
        }
        return null;
    }
    
    static class zerodayisaminecraftcheat extends GuiButton
    {
        private final boolean e;
        
        public zerodayisaminecraftcheat(final int p_i46316_1_, final int p_i46316_2_, final int p_i46316_3_, final boolean p_i46316_4_) {
            super(p_i46316_1_, p_i46316_2_, p_i46316_3_, 23, 13, "");
            this.e = p_i46316_4_;
        }
        
        @Override
        public void zerodayisaminecraftcheat(final Minecraft mc, final int mouseX, final int mouseY) {
            if (this.a) {
                final boolean flag = mouseX >= this.pandora && mouseY >= this.zues && mouseX < this.pandora + this.zeroday && mouseY < this.zues + this.sigma;
                GlStateManager.sigma(1.0f, 1.0f, 1.0f, 1.0f);
                mc.I().zerodayisaminecraftcheat(GuiScreenBook.zeroday);
                int i = 0;
                int j = 192;
                if (flag) {
                    i += 23;
                }
                if (!this.e) {
                    j += 13;
                }
                this.zeroday(this.pandora, this.zues, i, j, 23, 13);
            }
        }
    }
}

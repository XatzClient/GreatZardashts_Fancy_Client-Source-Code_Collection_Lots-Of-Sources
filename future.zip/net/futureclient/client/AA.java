package net.futureclient.client;

import java.util.ArrayList;

public class AA extends ja {
   public final Wb field_308;

   public AA(Wb var1) {
      this.field_308 = var1;
   }

   public void method_4183(Xe var1) {
      if (Wb.method_1893(this.field_308).method_811(Wb.method_1888(this.field_308).method_3692().floatValue() * 1000.0F)) {
         Jh var2;
         if ((var2 = new Jh(Wb.method_4277().player.posX, Wb.method_4270().player.posY, Wb.method_4267().player.posZ)).equals(iI.f$e)) {
            return;
         }

         if (Wb.method_1892(this.field_308) == null) {
            Wb.method_1891(this.field_308, new ci(0, (String)null, Wb.method_4273().world.provider.getDimensionType(), var2, new ArrayList()));
         }

         Jh var3 = Wb.method_1892(this.field_308).method_3136().isEmpty() ? var2 : (Jh)Wb.method_1892(this.field_308).method_3136().get(Wb.method_1892(this.field_308).method_3136().size() - 1);
         if (!Wb.method_1892(this.field_308).method_3136().isEmpty() && (var2.method_165(var3) > 0.0D || Wb.method_1892(this.field_308).method_3138() != Wb.method_4276().world.provider.getDimensionType())) {
            Wb.method_1895(this.field_308).add(Wb.method_1892(this.field_308));
            Wb.method_1891(this.field_308, new ci(Wb.method_1895(this.field_308).size() + 1, (String)null, Wb.method_4274().world.provider.getDimensionType(), var2, new ArrayList()));
         }

         if (Wb.method_1892(this.field_308).method_3136().isEmpty() || !var2.equals(var3)) {
            Wb.method_1892(this.field_308).method_3136().add(var2);
         }

         Wb.method_1893(this.field_308).method_814();
      }

   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

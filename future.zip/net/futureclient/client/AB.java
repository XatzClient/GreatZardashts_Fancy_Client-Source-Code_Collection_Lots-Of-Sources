package net.futureclient.client;

public class AB extends ka {
   public U field_309;

   public AB() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoReconnect";
      var10002[1] = "Reconnect";
      var10002[2] = "AutoConnect";
      super("AutoReconnect", var10002, true, -11184743, bE.MISCELLANEOUS);
      Float var2 = 5.0F;
      Float var4 = 0.0F;
      Float var10005 = 100.0F;
      String[] var10006 = new String[2];
      boolean var10007 = true;
      byte var10008 = 1;
      var10006[0] = "Delay";
      var10006[1] = "Timer";
      this.field_309 = new U(var2, var4, var10005, var10006);
      t[] var10001 = new t[1];
      boolean var1 = true;
      byte var3 = 1;
      var10001[0] = this.field_309;
      this.f$c(var10001);
   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayer;

public class AD extends ja {
   public final tD field_320;

   public AD(tD var1) {
      this.field_320 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }

   public void method_4241(je var1) {
      if (var1.method_3084() instanceof CPacketPlayer) {
         CPacketPlayer var2 = (CPacketPlayer)var1.method_3084();
         if (tD.method_3896(this.field_320).contains(var2)) {
            tD.method_3896(this.field_320).remove(var2);
            return;
         }

         byte var10002 = 1;
         byte var10003 = 1;
         var1.f$c(true);
      }

   }
}

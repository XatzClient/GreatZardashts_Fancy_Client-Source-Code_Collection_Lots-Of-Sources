package net.futureclient.client;

public enum AE {
   FakeZero;

   private static final AE[] field_311;
   Off,
   Emotion,
   FakeDown,
   Up,
   Rocker,
   Zero,
   Down,
   FakeUp;

   static {
      AE[] var10000 = new AE[9];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Off;
      var10000[1] = Emotion;
      var10000[2] = Down;
      var10000[3] = FakeDown;
      var10000[4] = Up;
      var10000[5] = FakeUp;
      var10000[6] = Zero;
      var10000[7] = FakeZero;
      var10000[8] = Rocker;
      field_311 = var10000;
   }
}

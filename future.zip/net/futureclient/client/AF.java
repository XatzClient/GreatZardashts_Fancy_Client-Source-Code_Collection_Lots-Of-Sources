package net.futureclient.client;

public class AF extends WE {
   private ka field_321;

   public AF(ka var1) {
      this.field_321 = var1;
   }

   public void method_670() {
      this.field_321.method_2390();
   }

   public ka method_671() {
      return this.field_321;
   }
}

package net.futureclient.client;

import java.util.StringJoiner;

public final class AG extends xb {
   private static void method_667(StringJoiner var0, Bg var1) {
      var0.add(var1.method_757());
   }

   public String method_4224() {
      return "&e[add|del|list] [name]";
   }

   public AG() {
      String[] var10001 = new String[4];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Friend";
      var10001[1] = "FriendAdd";
      var10001[2] = "Friends";
      var10001[3] = "Frend";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      Object[] var10001;
      boolean var10002;
      byte var10003;
      String var5;
      if (var1.length == 3 && var1[0].equalsIgnoreCase("add")) {
         var5 = var1[1];
         String var6 = var1[2];
         if (YH.method_1211().method_1216().method_1481(var5)) {
            return "That user is already a friend.";
         } else {
            YH.method_1211().method_1216().method_3798(new Bg(var5, var6));
            var10001 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var10001[0] = var6;
            return String.format("Added friend with alias %s.", var10001);
         }
      } else {
         if (var1.length == 2) {
            if (var1[0].equalsIgnoreCase("add")) {
               var5 = var1[1];
               if (YH.method_1211().method_1216().method_1481(var5)) {
                  return "That user is already a friend.";
               }

               YH.method_1211().method_1216().method_3798(new Bg(var5, var5));
               var10001 = new Object[1];
               var10002 = true;
               var10003 = 1;
               var10001[0] = var5;
               return String.format("Added friend with alias %s.", var10001);
            }

            if (var1[0].equalsIgnoreCase("del") || var1[0].equalsIgnoreCase("remove") || var1[0].equalsIgnoreCase("rem")) {
               var5 = var1[1];
               if (!YH.method_1211().method_1216().method_1481(var5)) {
                  return "That user is not a friend.";
               }

               Bg var3;
               String var4 = (var3 = YH.method_1211().method_1216().method_1482(var5)).method_756();
               YH.method_1211().method_1216().method_3042(var3);
               var10001 = new Object[1];
               var10002 = true;
               var10003 = 1;
               var10001[0] = var4;
               return String.format("Removed friend with alias %s.", var10001);
            }
         }

         if (var1.length == 1 && var1[0].equalsIgnoreCase("list")) {
            StringJoiner var2 = new StringJoiner(", ");
            YH.method_1211().method_1216().method_3043().forEach(var2.accept<invokedynamic>(var2));
            var10001 = new Object[2];
            var10002 = true;
            var10003 = 1;
            var10001[0] = YH.method_1211().method_1216().method_3043().size();
            var10001[1] = var2.toString();
            return String.format("Friends (%s): %s.", var10001);
         } else {
            return null;
         }
      }
   }
}

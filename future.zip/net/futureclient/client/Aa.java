package net.futureclient.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;

public class Aa implements C {
   private static final Gson field_277 = (new GsonBuilder()).setPrettyPrinting().create();
   private String field_278;
   private List field_279 = new ArrayList();
   private List field_280 = new ArrayList();
   private String[] field_281;
   private String field_282;
   public bE field_283;
   public static Minecraft field_284 = Minecraft.getMinecraft();

   public Aa(String var1, String... var2) {
      this.field_282 = var1;
      this.field_278 = var1;
      this.field_281 = var2;
   }

   public List method_615() {
      return this.field_280;
   }

   public void method_616(String var1) {
      this.field_282 = var1;
   }

   private static void method_617(List var0, String var1) {
      Block var2;
      if ((var2 = Block.getBlockFromName(var1)) != null) {
         var0.add(var2);
      }
   }

   public String method_618() {
      return this.field_282;
   }

   public void method_619(List var1) {
      this.field_280 = var1;
   }

   private static void method_620(JsonArray var0, Block var1) {
      var0.add(((ResourceLocation)Block.REGISTRY.getNameForObject(var1)).toString());
   }

   private void method_621(Entry var1) {
      Iterator var2;
      for(Iterator var10000 = var2 = this.method_615().iterator(); var10000.hasNext(); var10000 = var2) {
         t var3;
         if ((var3 = (t)var2.next()).method_3801()[0].equalsIgnoreCase((String)var1.getKey())) {
            JsonElement var8 = (JsonElement)var1.getValue();
            Object var9 = var3.method_3690();
            if (var3 instanceof V) {
               if (var8.isJsonArray()) {
                  JsonArray var4 = var8.getAsJsonArray();
                  ArrayList var5 = new ArrayList();
                  var4.forEach(var5.accept<invokedynamic>(var5));
                  ArrayList var7;
                  if (var3 instanceof s) {
                     s var12 = (s)var3;
                     var7 = new ArrayList();
                     var5.forEach(var7.accept<invokedynamic>(var7));
                     var12.f$c(var7);
                     return;
                  }

                  if (var3 instanceof Y) {
                     Y var11 = (Y)var3;
                     var7 = new ArrayList();
                     var5.forEach(var7.accept<invokedynamic>(var7));
                     var11.method_3689(var7);
                     return;
                  }

                  if (var3 instanceof aa) {
                     aa var6 = (aa)var3;
                     var7 = new ArrayList();
                     var5.forEach(var7.accept<invokedynamic>(var7));
                     var6.method_3689(var7);
                     return;
                  }
               }
            } else if (var8.isJsonPrimitive()) {
               JsonPrimitive var10 = var8.getAsJsonPrimitive();
               if (var9 instanceof Number) {
                  if (var9 instanceof Integer) {
                     var3.method_3689(var10.getAsInt());
                     return;
                  }

                  if (var9 instanceof Long) {
                     var3.method_3689(var10.getAsLong());
                     return;
                  }

                  if (var9 instanceof Double) {
                     var3.method_3689(var10.getAsDouble());
                     return;
                  }

                  if (var9 instanceof Float) {
                     var3.method_3689(var10.getAsFloat());
                     return;
                  }
               } else {
                  if (var9 instanceof Enum) {
                     ((ga)var3).method_3565(var10.getAsString());
                     return;
                  }

                  if (var9 instanceof Boolean) {
                     var3.method_3689(var10.getAsBoolean());
                     return;
                  }

                  if (var9 instanceof String) {
                     var3.method_3689(var10.getAsString());
                     return;
                  }
               }
            }
            break;
         }
      }

   }

   private static void method_622(JsonObject var0, t var1) {
      if (var1 instanceof V) {
         JsonArray var2 = new JsonArray();
         JsonObject var10000;
         if (var1 instanceof s) {
            s var3;
            ((List)(var3 = (s)var1).f$c()).forEach(var2.accept<invokedynamic>(var2));
            var10000 = var0;
         } else if (var1 instanceof Y) {
            Y var5;
            ((List)(var5 = (Y)var1).method_3690()).forEach(var2.accept<invokedynamic>(var2));
            var10000 = var0;
         } else {
            if (var1 instanceof aa) {
               aa var6;
               ((List)(var6 = (aa)var1).method_3690()).stream().map(apply<invokedynamic>()).forEach(var2.accept<invokedynamic>(var2));
            }

            var10000 = var0;
         }

         var10000.add(var1.method_3801()[0], var2);
      } else {
         var0.addProperty(var1.method_3801()[0], var1.method_3690().toString());
      }
   }

   private static void method_623(List var0, String var1) {
      Item var2;
      if ((var2 = Item.getByNameOrId(var1)) != null) {
         var0.add(var2);
      }
   }

   public void method_624(String var1) {
      this.field_278 = var1;
   }

   public Gb method_625(String var1) {
      Iterator var2 = this.field_279.iterator();

      Gb var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (Gb)var2.next();
      } while(!var1.equalsIgnoreCase(var3.method_984()));

      return var3;
   }

   public void method_626(t... var1) {
      Collections.addAll(this.field_280, var1);
   }

   public void method_627(String[] var1) {
      this.field_281 = var1;
   }

   public void method_628(List var1) {
      this.field_279 = var1;
   }

   public List method_629() {
      return this.field_279;
   }

   public String[] method_630() {
      return this.field_281;
   }

   private static void method_631(JsonArray var0, Item var1) {
      ResourceLocation var2;
      if ((var2 = (ResourceLocation)Item.REGISTRY.getNameForObject(var1)) != null) {
         var0.add(var2.toString());
      }

   }

   private static void method_632(JsonArray var0, Block var1) {
      var0.add(((ResourceLocation)Block.REGISTRY.getNameForObject(var1)).toString());
   }

   public t method_633(String var1) {
      Iterator var2 = this.field_280.iterator();

      while(var2.hasNext()) {
         t var3;
         String[] var4;
         int var5 = (var4 = (var3 = (t)var2.next()).method_3801()).length;

         int var6;
         for(int var10000 = var6 = 0; var10000 < var5; var10000 = var6) {
            String var7 = var4[var6];
            if (var1.equalsIgnoreCase(var7)) {
               return var3;
            }

            ++var6;
         }
      }

      return null;
   }

   public bE method_634() {
      return this.field_283;
   }

   public void method_635(Gb... var1) {
      Collections.addAll(this.field_279, var1);
      this.field_279.sort(Comparator.comparing(apply<invokedynamic>()));
   }

   public String method_636() {
      return this.field_278;
   }

   private static void method_637(List var0, JsonElement var1) {
      JsonPrimitive var2;
      if (var1.isJsonPrimitive() && (var2 = var1.getAsJsonPrimitive()).isString()) {
         var0.add(var2.getAsString());
      }

   }

   private static void method_638(List var0, String var1) {
      Block var2;
      if ((var2 = Block.getBlockFromName(var1)) != null) {
         var0.add(var2.getDefaultState());
      }
   }

   public void method_639() {
      File var1;
      if (!(var1 = new File(YH.method_1211().method_1217(), "modules")).exists()) {
         var1.mkdir();
      }

      if ((var1 = new File(var1, this.method_636().toLowerCase().replace(" ", "") + ".json")).exists()) {
         var1.delete();
      }

      if (!this.method_615().isEmpty()) {
         File var10000 = var1;

         try {
            var10000.createNewFile();
         } catch (IOException var21) {
            var21.printStackTrace();
            return;
         }

         JsonObject var2 = new JsonObject();
         Collections.unmodifiableCollection(this.method_615()).forEach(var2.accept<invokedynamic>(var2));
         if (!var2.entrySet().isEmpty()) {
            try {
               FileWriter var3 = new FileWriter(var1);
               Throwable var4 = null;
               FileWriter var28 = var3;

               label268: {
                  Throwable var29;
                  label258: {
                     boolean var10001;
                     Throwable var27;
                     try {
                        try {
                           var28.write(field_277.toJson(var2));
                           break label268;
                        } catch (Throwable var24) {
                           var27 = var24;
                        }
                     } catch (Throwable var25) {
                        var29 = var25;
                        var10001 = false;
                        break label258;
                     }

                     var29 = var4 = var27;

                     label235:
                     try {
                        throw var29;
                     } catch (Throwable var23) {
                        var29 = var23;
                        var10001 = false;
                        break label235;
                     }
                  }

                  Throwable var5 = var29;
                  if (var3 != null) {
                     if (var4 != null) {
                        var28 = var3;

                        try {
                           var28.close();
                        } catch (Throwable var22) {
                           var29 = var5;
                           var4.addSuppressed(var22);
                           throw var29;
                        }

                        var29 = var5;
                        throw var29;
                     }

                     var3.close();
                  }

                  var29 = var5;
                  throw var29;
               }

               if (var3 != null) {
                  if (var4 != null) {
                     var28 = var3;

                     try {
                        var28.close();
                        return;
                     } catch (Throwable var20) {
                        var4.addSuppressed(var20);
                        return;
                     }
                  }

                  var3.close();
                  return;
               }
            } catch (Throwable var26) {
               var26.printStackTrace();
               var1.delete();
            }

         }
      }
   }

   public void method_640() {
      // $FF: Couldn't be decompiled
   }
}

package net.futureclient.client;

public enum Ab {
   private static final Ab[] field_297;
   Legit,
   Rage;

   static {
      Ab[] var10000 = new Ab[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Legit;
      var10000[1] = Rage;
      field_297 = var10000;
   }
}

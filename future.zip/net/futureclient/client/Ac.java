package net.futureclient.client;

import net.minecraft.util.math.AxisAlignedBB;

public class Ac extends ja {
   public final CB field_290;

   public Ac(CB var1) {
      this.field_290 = var1;
   }

   public void method_2495(be var1) {
      if (!CB.method_4319().player.isEntityAlive() && var1.method_2797() != null) {
         var1.method_2800((AxisAlignedBB)null);
      }

   }

   public void method_4312(CD var1) {
      this.method_2495((be)var1);
   }
}

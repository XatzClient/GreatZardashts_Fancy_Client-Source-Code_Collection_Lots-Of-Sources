package net.futureclient.client;

public class Ad extends ja {
   public final ac field_305;

   public Ad(ac var1) {
      this.field_305 = var1;
   }

   public void method_659(zd var1) {
      var1.f$c((Boolean)this.field_305.field_1186.method_3690());
   }

   public void method_4312(CD var1) {
      this.method_659((zd)var1);
   }
}

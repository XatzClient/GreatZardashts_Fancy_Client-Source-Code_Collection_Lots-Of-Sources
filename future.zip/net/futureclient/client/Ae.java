package net.futureclient.client;

public class Ae extends ja {
   public final tf field_304;

   public Ae(tf var1) {
      this.field_304 = var1;
   }

   public void method_3119(DE var1) {
      if (tf.method_4269().getRenderViewEntity() != null && tf.method_4315().world != null && tf.method_4319().playerController != null) {
         var1.method_2096(tf.method_3805(this.field_304).method_3692().floatValue());
         var1.method_3094(tf.method_3807(this.field_304).method_3692().floatValue());
      }

   }

   public void method_4312(CD var1) {
      this.method_3119((DE)var1);
   }
}

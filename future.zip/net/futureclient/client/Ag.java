package net.futureclient.client;

public class Ag extends CD {
   private String field_307;

   public Ag(String var1) {
      this.field_307 = var1.replaceAll(y.f$c("ÿV"), "");
   }

   public String method_3453() {
      return this.field_307;
   }
}

package net.futureclient.client;

public enum BA {
   private static final BA[] field_286;
   Hide,
   Remove,
   Off;

   static {
      BA[] var10000 = new BA[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Off;
      var10000[1] = Hide;
      var10000[2] = Remove;
      field_286 = var10000;
   }
}

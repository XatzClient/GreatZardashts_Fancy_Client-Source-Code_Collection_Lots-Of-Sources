package net.futureclient.client;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemLingeringPotion;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import org.lwjgl.opengl.GL11;

public class BB extends ja {
   public final GC field_285;

   public BB(GC var1) {
      this.field_285 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4042((Df)var1);
   }

   public void method_4042(Df var1) {
      if (var1.method_823().equals(GF.PRE)) {
         if (GC.method_1049(this.field_285).stream().anyMatch(test<invokedynamic>())) {
            boolean var2 = GC.method_3769().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemBow || GC.method_3747().player.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemBow;
            boolean var3 = GC.method_3745().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemSplashPotion || GC.method_3757().player.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemSplashPotion || GC.method_3761().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemLingeringPotion || GC.method_3767().player.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemLingeringPotion || GC.method_4296().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemExpBottle || GC.method_4301().player.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemExpBottle;
            if (GC.method_4288().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemBow || GC.method_4291().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemSnowball || GC.method_4292().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemEnderPearl || GC.method_4298().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemEgg) {
               var3 = false;
            }

            if (GC.method_4294().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemSplashPotion || GC.method_4300().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemLingeringPotion || GC.method_4299().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemSnowball || GC.method_4297().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemEnderPearl || GC.method_4285().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemEgg || GC.method_4284().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemExpBottle) {
               var2 = false;
            }

            if (var3 && (GC.method_4286().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemPotion || GC.method_4293().player.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemPotion)) {
               GC.method_1042(this.field_285, 0.5F);
               GC.method_1050(this.field_285, 0.05F);
            } else if (var3 && (GC.method_4287().player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemExpBottle || GC.method_4250().player.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemExpBottle)) {
               GC.method_1042(this.field_285, 0.7F);
               GC.method_1050(this.field_285, 0.07F);
            } else if (var2) {
               GC.method_1042(this.field_285, 1.5F);
               GC.method_1050(this.field_285, 0.05F);
            } else {
               GC.method_1042(this.field_285, 1.5F);
               GC.method_1050(this.field_285, 0.03F);
            }

            float var4;
            float var5;
            xE var6;
            if ((var6 = (xE)YH.method_1211().method_1205().method_2166(xE.class)) != null && var6.f$c() && var6.field_1888 != null && GC.method_4295().player.getActiveItemStack().getItem() instanceof ItemBow && var6.field_1880 != 0.0F && var6.field_1887 != 0.0F) {
               var4 = var6.field_1880;
               var5 = var6.field_1887;
            } else {
               var4 = GC.method_4282().player.rotationYaw;
               var5 = GC.method_4290().player.rotationPitch;
            }

            double var7 = GC.method_4272().player.posX - (double)(MathHelper.cos(var4 / 180.0F * 3.1415927F) * 0.16F);
            double var9 = GC.method_4244().player.posY + (double)GC.method_4289().player.getEyeHeight() - 1.3262473694E-314D;
            double var11 = GC.method_4283().player.posZ - (double)(MathHelper.sin(var4 / 180.0F * 3.1415927F) * 0.16F);
            double var13 = (double)(-MathHelper.sin(var4 / 180.0F * 3.1415927F) * MathHelper.cos(var5 / 180.0F * 3.1415927F)) * (var2 ? 1.0D : 1.273197475E-314D);
            double var15 = (double)(-MathHelper.sin((var5 - (float)(var3 ? 20 : 0)) / 180.0F * 3.1415927F)) * (var2 ? 1.0D : 1.273197475E-314D);
            double var17 = (double)(MathHelper.cos(var4 / 180.0F * 3.1415927F) * MathHelper.cos(var5 / 180.0F * 3.1415927F)) * (var2 ? 1.0D : 1.273197475E-314D);
            if (!GC.method_4243().player.onGround && !var2) {
               var15 += GC.method_4280().player.motionY;
            }

            float var22;
            float var10000 = var22 = (float)(72000 - GC.method_4279().player.getItemInUseCount()) / 20.0F;
            if ((double)(var22 = (var10000 * var10000 + var22 * 2.0F) / 3.0F) >= 1.273197475E-314D) {
               if (var22 > 1.0F) {
                  var22 = 1.0F;
               }

               var4 = MathHelper.sqrt(var13 * var13 + var15 * var15 + var17 * var17);
               var13 /= (double)var4;
               var15 /= (double)var4;
               var17 /= (double)var4;
               var13 *= (double)(var2 ? var22 * 2.0F : 1.0F) * (double)GC.method_1041(this.field_285);
               var15 *= (double)(var2 ? var22 * 2.0F : 1.0F) * (double)GC.method_1041(this.field_285);
               var17 *= (double)(var2 ? var22 * 2.0F : 1.0F) * (double)GC.method_1041(this.field_285);
               GlStateManager.pushMatrix();
               Di.method_894();
               GlStateManager.enableAlpha();
               GlStateManager.enableBlend();
               GL11.glLineWidth(1.5F);
               zF var21 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
               GL11.glColor3f((float)var21.field_1445.getRed() / 255.0F, (float)var21.field_1445.getGreen() / 255.0F, (float)var21.field_1445.getBlue() / 255.0F);
               GL11.glBegin(3);
               var3 = false;
               RayTraceResult var23 = null;

               for(boolean var26 = var3; !var26 && var9 > 0.0D; var26 = var3) {
                  double var27;
                  label139: {
                     Vec3d var24 = new Vec3d(var7, var9, var11);
                     Vec3d var25 = new Vec3d(var7 + var13, var9 + var15, var11 + var17);
                     RayTraceResult var19;
                     if ((var19 = GC.method_4271().world.rayTraceBlocks(var24, var25, false, true, false)) != null) {
                        if (var19.typeOfHit != Type.MISS) {
                           var23 = var19;
                           var3 = true;
                           var27 = var7;
                           break label139;
                        }
                     } else {
                        Entity var20;
                        if ((var20 = GC.method_1047(this.field_285, var24, var25)) != null) {
                           var23 = new RayTraceResult(var20);
                           var3 = true;
                        }
                     }

                     var27 = var7;
                  }

                  var7 = var27 + var13;
                  var9 += var15;
                  var11 += var17;
                  float var28 = 0.99F;
                  var13 *= (double)var28;
                  var15 *= (double)var28;
                  var17 *= (double)var28;
                  var15 -= (double)GC.method_1046(this.field_285);
                  GL11.glVertex3d(var7 - ((A)GC.method_4278().getRenderManager()).getRenderPosX(), var9 - ((A)GC.method_4275().getRenderManager()).getRenderPosY(), var11 - ((A)GC.method_4277().getRenderManager()).getRenderPosZ());
               }

               GL11.glEnd();
               GlStateManager.disableAlpha();
               GlStateManager.disableBlend();
               Di.method_942();
               GlStateManager.popMatrix();
               GlStateManager.pushMatrix();
               Di.method_894();
               GlStateManager.enableAlpha();
               GlStateManager.enableBlend();
               GL11.glTranslated(var7 - ((A)GC.method_4270().getRenderManager()).getRenderPosX(), var9 - ((A)GC.method_4267().getRenderManager()).getRenderPosY(), var11 - ((A)GC.method_4273().getRenderManager()).getRenderPosZ());
               if (var23 != null && var23.typeOfHit == Type.BLOCK) {
                  switch(var23.sideHit.getIndex()) {
                  case 1:
                     boolean var10001 = false;
                     GL11.glRotatef(180.0F, 1.0F, 0.0F, (float)0);
                     break;
                  case 2:
                     GL11.glRotatef(90.0F, 1.0F, 0.0F, (float)0);
                     break;
                  case 3:
                     GL11.glRotatef(-90.0F, 1.0F, 0.0F, (float)0);
                     break;
                  case 4:
                     GL11.glRotatef(-90.0F, 0.0F, (float)0, 1.0F);
                     break;
                  case 5:
                     GL11.glRotatef(90.0F, 0.0F, (float)0, 1.0F);
                  }

                  GL11.glRotatef(-90.0F, 1.0F, 0.0F, (float)0);
                  Di.method_898(-0.6F, -0.6F, 0.6F, 0.6F, 0.1F, var21.field_1445.getRGB() + -1728053248, var21.field_1445.getRGB() + -1728053248);
               }

               if (var23 != null && var23.typeOfHit == Type.ENTITY) {
                  GL11.glTranslated(-((A)GC.method_4276().getRenderManager()).getRenderPosX(), -((A)GC.method_4274().getRenderManager()).getRenderPosY(), -((A)GC.method_4245().getRenderManager()).getRenderPosZ());
                  GL11.glColor4f((float)var21.field_1445.getRed() / 255.0F, (float)var21.field_1445.getGreen() / 255.0F, (float)var21.field_1445.getBlue() / 255.0F, 0.17F);
                  Di.method_943(var23.entityHit.getEntityBoundingBox().grow(1.697596633E-314D, 1.0D, 1.697596633E-314D).offset(0.0D, 0.0D, 0.0D));
                  GL11.glTranslated(((A)GC.method_4281().getRenderManager()).getRenderPosX(), ((A)GC.method_4242().getRenderManager()).getRenderPosY(), ((A)GC.method_4269().getRenderManager()).getRenderPosZ());
               }

               GlStateManager.disableAlpha();
               GlStateManager.disableBlend();
               Di.method_942();
               GlStateManager.popMatrix();
            }
         }

      }
   }

   private static boolean method_1464(Class var0) {
      return var0.isInstance(GC.method_4315().player.getHeldItem(EnumHand.MAIN_HAND).getItem()) || var0.isInstance(GC.method_4319().player.getHeldItem(EnumHand.OFF_HAND).getItem());
   }
}

package net.futureclient.client;

public class BC extends ja {
   public final kc field_296;

   public BC(kc var1) {
      this.field_296 = var1;
   }

   public void method_2748(Le var1) {
      if ((Boolean)this.field_296.field_1014.method_3690()) {
         var1.method_729(true);
      }

   }

   public void method_4312(CD var1) {
      this.method_2748((Le)var1);
   }
}

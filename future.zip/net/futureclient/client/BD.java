package net.futureclient.client;

public enum BD {
   private static final BD[] field_291;
   Jump,
   Hypixel,
   Mini,
   Packet;

   static {
      BD[] var10000 = new BD[4];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Jump;
      var10000[1] = Mini;
      var10000[2] = Packet;
      var10000[3] = Hypixel;
      field_291 = var10000;
   }
}

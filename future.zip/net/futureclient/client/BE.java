package net.futureclient.client;

public final class BE extends ka {
   private final ga field_306;

   public static ga method_661(BE var0) {
      return var0.field_306;
   }

   public BE() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[3];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "Swing";
      byte var7 = 1;
      var10006 = 1;
      var10002[1] = "NoSwing";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "OffhandSwing";
      var10003 = true;
      var10004 = 1;
      var10006 = 1;
      super("Swing", var10002, true, -103, bE.EXPLOITS);
      mf var4 = mf.Cancel;
      var10005 = true;
      var10006 = 1;
      String[] var6 = new String[2];
      var10005 = true;
      var10006 = 1;
      boolean var10007 = true;
      byte var10008 = 1;
      var6[0] = "Mode";
      byte var9 = 1;
      var10008 = 1;
      var6[1] = "m";
      this.field_306 = new ga(var4, var6);
      byte var2 = 1;
      byte var5 = 1;
      t[] var10001 = new t[1];
      boolean var3 = true;
      var5 = 1;
      boolean var8 = true;
      var7 = 1;
      var10001[0] = this.field_306;
      this.f$c(var10001);
      var2 = 1;
      var5 = 1;
      ja[] var1 = new ja[1];
      var3 = true;
      var5 = 1;
      var8 = true;
      var7 = 1;
      var1[0] = new CE(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;

public final class BI extends xb {
   private mG field_300;
   private si field_301;
   private ki field_302;
   private Entity field_303;

   public static Minecraft method_648(BI var0) {
      return var0.field_1834;
   }

   public static Minecraft method_649(BI var0) {
      return var0.field_1834;
   }

   public static Entity method_650(BI var0) {
      return var0.field_303;
   }

   public static Minecraft method_651(BI var0) {
      return var0.field_1834;
   }

   public static Entity method_652(BI var0, Entity var1) {
      return var0.field_303 = var1;
   }

   public static Minecraft method_653(BI var0) {
      return var0.field_1834;
   }

   public static Minecraft method_654(BI var0) {
      return var0.field_1834;
   }

   public String method_4224() {
      return "&e[dismount|remount|reset]";
   }

   public BI() {
      boolean var10002 = true;
      byte var10003 = 1;
      String[] var10001 = new String[2];
      var10002 = true;
      var10003 = 1;
      boolean var10004 = true;
      byte var10005 = 1;
      var10001[0] = "EntityDesync";
      byte var1 = 1;
      var10005 = 1;
      var10001[1] = "Desync";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (this.field_301 == null && this.field_302 == null && this.field_300 == null) {
         YH.method_1211().method_1212().method_1330(this.field_301 = new si(this, (Fj)null));
         YH.method_1211().method_1212().method_1330(this.field_302 = new ki(this, (Fj)null));
         YH.method_1211().method_1212().method_1330(this.field_300 = new mG(this, (Fj)null));
      }

      int var10000 = var1.length;
      byte var10002 = 1;
      byte var10003 = 1;
      if (var10000 == 1) {
         boolean var4 = true;
         var10003 = 1;
         String var3;
         if ((var3 = var1[0]).equalsIgnoreCase("dismount")) {
            Entity var2;
            if ((var2 = this.field_1834.player.getRidingEntity()) == null) {
               return "You are not riding an entity.";
            }

            this.field_303 = var2;
            this.field_1834.player.dismountRidingEntity();
            this.field_1834.world.removeEntity(var2);
            return "Forced a dismount.";
         }

         if (var3.equalsIgnoreCase("remount")) {
            if (this.field_303 == null) {
               return "You have not forced a dismount.";
            }

            boolean var5 = true;
            byte var10004 = 1;
            this.field_303.isDead = false;
            this.field_1834.world.spawnEntity(this.field_303);
            var10004 = 1;
            byte var10005 = 1;
            this.field_1834.player.startRiding(this.field_303, true);
            return "Forced a remount.";
         }

         if (var3.equalsIgnoreCase("reset")) {
            if (this.field_303 == null) {
               return "You have not forced a dismount.";
            }

            this.field_303 = null;
            return "Reset.";
         }
      }

      return null;
   }
}

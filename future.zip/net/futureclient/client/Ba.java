package net.futureclient.client;

public enum Ba {
   Circuits,
   Normal;

   private static final Ba[] field_350;

   static {
      Ba[] var10000 = new Ba[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Normal;
      var10000[1] = Circuits;
      field_350 = var10000;
   }
}

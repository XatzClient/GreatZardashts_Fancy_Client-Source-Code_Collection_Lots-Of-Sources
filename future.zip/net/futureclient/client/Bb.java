package net.futureclient.client;

public class Bb extends ja {
   public final vA field_346;

   public Bb(vA var1) {
      this.field_346 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      bC.method_3037().field_1197 = this.field_346.field_1804.method_3692().doubleValue();
      vA.method_4319().displayGuiScreen(bC.method_3037());
      YH.method_1211().method_1212().method_1334(this);
   }
}

package net.futureclient.client;

import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPotion;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;

public class Bc extends ja {
   public final gb field_353;

   public Bc(gb var1) {
      this.field_353 = var1;
   }

   public void method_4183(Xe var1) {
      if ((Boolean)this.field_353.field_1411.method_3690() && (Boolean)this.field_353.field_1413.method_3690()) {
         Item var2 = gb.method_4269().player.getActiveItemStack().getItem();
         if (EI.method_890() && var2 instanceof ItemFood || var2 instanceof ItemBow || var2 instanceof ItemPotion) {
            gb.method_4319().player.connection.sendPacket(new CPacketPlayerDigging(Action.ABORT_DESTROY_BLOCK, gb.method_4315().player.getPosition(), EnumFacing.DOWN));
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

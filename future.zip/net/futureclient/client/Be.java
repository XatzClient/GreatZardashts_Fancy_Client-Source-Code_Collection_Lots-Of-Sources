package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Be extends ka {
   private double field_356;
   private t field_357;
   private double field_358;
   private EG field_359;
   private boolean field_360;
   private double field_361;

   public void method_4314() {
      super.method_4314();
      this.field_361 = 0.0D;
      this.field_356 = 0.0D;
      this.field_358 = 0.0D;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static double method_738(Be var0, double var1) {
      return var0.field_356 = var1;
   }

   public static double method_739(Be var0) {
      return var0.field_356;
   }

   public static t method_740(Be var0) {
      return var0.field_357;
   }

   public static boolean method_741(Be var0, boolean var1) {
      return var0.field_360 = var1;
   }

   public static boolean method_742(Be var0) {
      return var0.field_360;
   }

   public static double method_743(Be var0, double var1) {
      return var0.field_358 = var1;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static double method_745(Be var0) {
      return var0.field_358;
   }

   public static EG method_746(Be var0) {
      return var0.field_359;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static double method_748(Be var0, double var1) {
      return var0.field_361 = var1;
   }

   public static double method_749(Be var0) {
      return var0.field_361;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
      this.field_361 = 0.0D;
      this.field_356 = 0.0D;
      this.field_358 = 0.0D;
   }

   public Be() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "PortalGodMode";
      var10002[1] = "PortalGod";
      var10002[2] = "GodMode";
      var10002[3] = "God";
      super("PortalGodMode", var10002, true, -12069189, bE.EXPLOITS);
      Boolean var3 = true;
      String[] var5 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "PositionAdjust";
      var5[1] = "PosAdjust";
      var5[2] = "PositionAdjustment";
      var5[3] = "PosFix";
      this.field_357 = new t(var3, var5);
      this.field_360 = false;
      this.field_359 = new EG();
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_357;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var4 = 1;
      var1[0] = new re(this);
      var1[1] = new Mg(this);
      this.method_2383(var1);
   }
}

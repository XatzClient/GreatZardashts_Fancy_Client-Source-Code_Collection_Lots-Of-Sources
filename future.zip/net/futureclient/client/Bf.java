package net.futureclient.client;

import net.minecraft.world.DimensionType;

public class Bf extends xb {
   public String method_4224() {
      return "&e[blocks]";
   }

   public Bf() {
      String[] var10001 = new String[3];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Vclip";
      var10001[1] = "vc";
      var10001[2] = "v";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length == 1) {
         Object[] var10001;
         boolean var10002;
         byte var10003;
         if (var1[0].equalsIgnoreCase("nether") && this.field_1834.player.getRidingEntity() != null && this.field_1834.world.provider.getDimensionType() == DimensionType.NETHER) {
            this.field_1834.player.getRidingEntity().setEntityBoundingBox(this.field_1834.player.getRidingEntity().getEntityBoundingBox().offset(0.0D, 1.273197475E-314D - this.field_1834.player.getRidingEntity().posY, 0.0D));
            String var10000 = cH.f$c("@CxCdIfRqB4\u0003g\u00062C1U2\u00114DxIwM<U=\b");
            var10001 = new Object[2];
            var10002 = true;
            var10003 = 1;
            var10001[0] = 1.273197475E-314D - this.field_1834.player.getRidingEntity().posY < 0.0D ? "down" : "up";
            var10001[1] = 1.273197475E-314D - this.field_1834.player.getRidingEntity().posY;
            return String.format(var10000, var10001);
         } else {
            double var2 = Double.parseDouble(var1[0]);
            if (this.field_1834.player.getRidingEntity() != null) {
               this.field_1834.player.getRidingEntity().setEntityBoundingBox(this.field_1834.player.getRidingEntity().getEntityBoundingBox().offset(0.0D, var2, 0.0D));
            } else {
               this.field_1834.player.setEntityBoundingBox(this.field_1834.player.getEntityBoundingBox().offset(0.0D, var2, 0.0D));
            }

            var10001 = new Object[2];
            var10002 = true;
            var10003 = 1;
            var10001[0] = var2 < 0.0D ? "down" : "up";
            var10001[1] = var2;
            return String.format("Teleported %s &e%s&7 block(s).", var10001);
         }
      } else {
         return null;
      }
   }
}

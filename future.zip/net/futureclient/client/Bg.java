package net.futureclient.client;

public class Bg implements C {
   private String field_365;
   private String field_366;

   public Bg(String var1, String var2) {
      this.field_365 = var1;
      this.field_366 = var2;
   }

   public String method_756() {
      return this.field_366;
   }

   public String method_757() {
      return this.field_365;
   }
}

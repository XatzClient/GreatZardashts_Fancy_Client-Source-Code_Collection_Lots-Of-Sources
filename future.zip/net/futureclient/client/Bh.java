package net.futureclient.client;

import net.minecraft.client.gui.BossInfoClient;

public class Bh {
   public BossInfoClient field_363;
   public int field_364 = 0;
}

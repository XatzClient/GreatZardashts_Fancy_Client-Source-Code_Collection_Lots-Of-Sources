package net.futureclient.client;

public class CA extends ja {
   public final Nc field_355;

   public CA(Nc var1) {
      this.field_355 = var1;
   }

   public void method_4312(CD var1) {
      this.method_732((dg)var1);
   }

   public void method_732(dg var1) {
      if (Nc.method_4273().player.getRidingEntity() != null) {
         Nc.method_4276().player.getRidingEntity().stepHeight = (Boolean)this.field_355.field_276.method_3690() ? 256.0F : 1.0F;
      }

      Nc.method_599(this.field_355, var1.f$c().minY);
      if (Nc.method_595(this.field_355, Nc.method_589(this.field_355))) {
         var1.method_3094(Nc.method_591(this.field_355).method_3692().floatValue());
      }

   }
}

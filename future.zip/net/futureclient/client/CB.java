package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class CB extends ka {
   private U field_347;

   public static Minecraft method_4315() {
      return f$e;
   }

   public static U method_720(CB var0) {
      return var0.field_347;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public CB() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Heaven";
      var10002[1] = "GoHeaven";
      var10002[2] = "AutoHeaven";
      var10002[3] = "Blessing";
      super("Heaven", var10002, true, -10887189, bE.MISCELLANEOUS);
      Float var3 = 0.75F;
      Float var5 = -10.0F;
      Float var10005 = 10.0F;
      Double var10006 = 1.273197475E-314D;
      String[] var10007 = new String[2];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Speed";
      var10007[1] = "Sped";
      this.field_347 = new U(var3, var5, var10005, var10006, var10007);
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_347;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var4 = 1;
      var1[0] = new Db(this);
      var1[1] = new Ac(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public class CC extends ja {
   public final le field_345;

   public CC(le var1) {
      this.field_345 = var1;
   }

   public void method_715(GE var1) {
      byte var10003;
      if (!le.method_2289(this.field_345)) {
         boolean var2 = true;
         var10003 = 1;
         le.method_2291(this.field_345, false);
      } else {
         byte var10002 = 1;
         var10003 = 1;
         var1.f$c(true);
      }
   }

   public void method_4312(CD var1) {
      this.method_715((GE)var1);
   }
}

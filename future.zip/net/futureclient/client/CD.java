package net.futureclient.client;

public class CD {
   private boolean field_354;

   public void method_729(boolean var1) {
      this.field_354 = var1;
   }

   public boolean method_730() {
      return this.field_354;
   }
}

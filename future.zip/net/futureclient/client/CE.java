package net.futureclient.client;

import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumHand;

public class CE extends ja {
   public final BE field_351;

   public CE(BE var1) {
      this.field_351 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }

   public void method_4241(je var1) {
      if (var1.method_3084() instanceof CPacketAnimation) {
         D var2 = (D)var1.method_3084();
         switch(gF.f$e[((mf)BE.method_661(this.field_351).method_3690()).ordinal()]) {
         case 1:
            boolean var10001 = false;
            var1.f$c(true);
            return;
         case 2:
            var2.setHand(EnumHand.OFF_HAND);
         }
      }

   }
}

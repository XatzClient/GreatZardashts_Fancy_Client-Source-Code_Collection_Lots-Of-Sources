package net.futureclient.client;

import java.util.List;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayer;

public class CF extends ja {
   public final OD field_362;

   public CF(OD var1) {
      this.field_362 = var1;
   }

   private boolean method_3587(EntityPlayer var1) {
      return OD.method_551(this.field_362, var1) || OD.method_570(this.field_362, var1) || OD.method_560(this.field_362, var1) || OD.method_562(this.field_362, var1);
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (!OD.method_4243().player.isDead) {
         if (!OD.method_4280().player.isSpectator()) {
            if (OD.method_4279().player != null) {
               if ((Boolean)this.field_362.field_262.method_3690()) {
                  List var2 = OD.method_563(this.field_362);

                  int var3;
                  for(int var10000 = var3 = 0; var10000 < var2.size(); var10000 = var3) {
                     int var4;
                     for(var10000 = var4 = var3 + 1; var10000 < var2.size(); var10000 = var4) {
                        EntityPlayer var5 = (EntityPlayer)var2.get(var3);
                        EntityPlayer var6 = (EntityPlayer)var2.get(var4);
                        if (var5.getUniqueID() == var6.getUniqueID()) {
                           if (var5.getEntityId() > var6.getEntityId()) {
                              this.field_362.field_261.put(var5.getEntityId(), var5.getUniqueID());
                              this.field_362.field_261.remove(var6.getEntityId());
                           } else {
                              this.field_362.field_261.put(var6.getEntityId(), var6.getUniqueID());
                              this.field_362.field_261.remove(var5.getEntityId());
                           }
                           break;
                        }

                        ++var4;
                     }

                     ++var3;
                  }
               }

               OD.method_563(this.field_362).stream().filter(this.test<invokedynamic>(this)).forEach(this.accept<invokedynamic>(this));
            }
         }
      }
   }

   private void method_3585(EntityPlayer var1) {
      UUID var10000 = (UUID)this.field_362.field_261.put(var1.getEntityId(), var1.getUniqueID());
   }
}

package net.futureclient.client;

public class Ca extends ja {
   public final Da field_337;

   public Ca(Da var1) {
      this.field_337 = var1;
   }

   public void method_1908(ZD var1) {
      var1.f$c(true);
   }

   public void method_4312(CD var1) {
      this.method_1908((ZD)var1);
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import org.lwjgl.input.Keyboard;

public class Cb extends ja {
   public final pA field_330;

   public Cb(pA var1) {
      this.field_330 = var1;
   }

   public void method_4183(Xe var1) {
      switch(ed.f$G[((sd)pA.method_2526(this.field_330).method_3690()).ordinal()]) {
      case 3:
         Minecraft var10000 = pA.method_3021();
         boolean var10001 = false;
         if (var10000.world != null) {
            if (Keyboard.isKeyDown(50)) {
               pA.method_2535(this.field_330, 0.0D, 2.1199235295E-314D, 0.0D);
            }

            if (!EI.method_852()) {
               return;
            } else {
               float var2;
               float var3 = (float)Math.cos((double)((var2 = pA.method_2979().player.rotationYaw + (float)(pA.method_3008().player.moveForward < 0.0F ? 180 : 0) + (pA.method_3022().player.moveStrafing > 0.0F ? -90.0F * (pA.method_2954().player.moveForward < 0.0F ? -0.5F : (pA.method_2936().player.moveForward > 0.0F ? 0.5F : 1.0F)) : 0.0F) - (pA.method_3010().player.moveStrafing < 0.0F ? -90.0F * (pA.method_2939().player.moveForward < 0.0F ? -0.5F : (pA.method_2938().player.moveForward > 0.0F ? 0.5F : 1.0F)) : 0.0F)) + 90.0F) * 6.984873503E-315D / 0.0D);
               var2 = (float)Math.sin((double)(var2 + 90.0F) * 6.984873503E-315D / 0.0D);
               if (!pA.method_3004().player.collidedVertically) {
                  pA.method_2520(this.field_330, pA.method_2522(this.field_330) + 1);
                  if (pA.method_2932().player.movementInput.sneak) {
                     pA.method_2980().player.connection.sendPacket(new Position(0.0D, 2.1199235295E-314D, 0.0D, false));
                  }

                  pA.method_2530(this.field_330, 0);
                  if (!pA.method_3017().player.collidedVertically) {
                     EntityPlayerSP var6;
                     if (pA.method_2983().player.motionY == 7.943109154E-315D) {
                        var6 = pA.method_2981().player;
                        var6.motionY *= 7.957484216E-315D;
                     }

                     if (pA.method_2973().player.motionY == 8.24181575E-315D) {
                        var6 = pA.method_2985().player;
                        var6.motionY *= 1.3262473694E-314D;
                     }

                     if (pA.method_2977().player.motionY == 6.32021844E-315D) {
                        var6 = pA.method_3003().player;
                        var6.motionY *= 1.856746317E-314D;
                     }

                     if (pA.method_3018().player.motionY == 6.24930449E-315D) {
                        var6 = pA.method_2943().player;
                        var6.motionY *= 1.856746317E-314D;
                     }

                     if (pA.method_2958().player.motionY == 3.10334463E-315D) {
                        var6 = pA.method_2960().player;
                        var6.motionY *= 1.856746317E-314D;
                     }

                     if (pA.method_2930().player.motionY == 1.0745162934E-314D) {
                        var6 = pA.method_3012().player;
                        var6.motionY *= 1.3262473694E-314D;
                     }

                     if (pA.method_3023().player.motionY == 6.4161737E-315D) {
                        var6 = pA.method_2950().player;
                        var6.motionY *= 7.957484216E-315D;
                     }

                     if (pA.method_3019().player.motionY == 6.00011333E-315D) {
                        var6 = pA.method_3020().player;
                        var6.motionY *= 1.0609978955E-314D;
                     }

                     if (pA.method_2937().player.motionY == 1.411644485E-314D) {
                        var6 = pA.method_2976().player;
                        var6.motionY *= 1.0609978955E-314D;
                     }

                     if (pA.method_2533(this.field_330, pA.method_2982().player, 0.0D) < 0.0D) {
                        if (pA.method_2992().player.motionY == 1.34402627E-314D) {
                           var6 = pA.method_3005().player;
                           var6.motionY *= 1.856746317E-314D;
                        }

                        if (pA.method_2940().player.motionY == 2.0925154156E-314D) {
                           var6 = pA.method_2959().player;
                           var6.motionY *= 0.0D;
                        }

                        if (pA.method_2955().player.motionY == 3.1047452E-315D) {
                           var6 = pA.method_3011().player;
                           var6.motionY *= 1.3262473694E-314D;
                        }

                        if (pA.method_2933().player.motionY == 8.801257036E-315D) {
                           var6 = pA.method_2988().player;
                           var6.motionY *= 2.652494739E-315D;
                        }

                        if (pA.method_2957().player.motionY == 4.343827836E-315D) {
                           var6 = pA.method_2972().player;
                           var6.motionY *= 1.3262473694E-314D;
                        }

                        if (pA.method_2971().player.motionY == 1.118078837E-314D) {
                           var6 = pA.method_2962().player;
                           var6.motionY *= 5.304989477E-315D;
                        }

                        if (pA.method_2944().player.motionY == 1.612716801E-314D) {
                           var6 = pA.method_2969().player;
                           var6.motionY *= 1.3262473694E-314D;
                        }

                        if (pA.method_3770().player.motionY == 1.0035121807E-314D) {
                           var6 = pA.method_3772().player;
                           var6.motionY *= 1.3262473694E-314D;
                        }

                        if (pA.method_3771().player.motionY == 1.9929972093E-314D) {
                           var6 = pA.method_3775().player;
                           var6.motionY *= 1.3262473694E-314D;
                        }

                        if (pA.method_3759().player.motionY == 7.22485148E-315D) {
                           var6 = pA.method_3774().player;
                           var6.motionY *= 1.3262473694E-314D;
                        }

                        if (pA.method_3776().player.motionY == 1.252364704E-315D) {
                           var6 = pA.method_3752().player;
                           var6.motionY *= 1.3262473694E-314D;
                        }

                        if (pA.method_3773().player.motionY == 1.341570533E-314D) {
                           pA.method_3769().player.motionY = 8.04889483E-315D;
                        }

                        if (pA.method_3747().player.motionY == 8.04889483E-315D) {
                           pA.method_3745().player.motionY = 1.3262473694E-314D;
                        }

                        if (pA.method_3757().player.motionY > 1.273197475E-314D && pA.method_3761().player.motionY < 5.941588215E-315D && !pA.method_3767().player.onGround && pA.method_4296().player.movementInput.forwardKeyDown) {
                           pA.method_4301().player.motionY = 1.856746317E-314D;
                        }
                     } else {
                        if (pA.method_4288().player.motionY < 1.273197475E-314D && pA.method_4291().player.motionY > 1.9522361275E-314D) {
                           var6 = pA.method_4292().player;
                           var6.motionY *= 8.48798316E-315D;
                        }

                        if (pA.method_4298().player.motionY < 0.0D && pA.method_4294().player.motionY > 5.941588215E-315D) {
                           var6 = pA.method_4300().player;
                           var6.motionY *= 1.273197475E-314D;
                        }

                        if (pA.method_4299().player.motionY < 8.48798316E-315D && pA.method_4297().player.motionY > 1.273197475E-314D) {
                           var6 = pA.method_4285().player;
                           var6.motionY *= 2.0371159592E-314D;
                        }

                        if (pA.method_4284().player.motionY < 1.273197475E-314D && pA.method_4286().player.motionY > 1.273197475E-314D) {
                           var6 = pA.method_4293().player;
                           var6.motionY *= 1.0185579796E-314D;
                        }
                     }
                  }

                  ((r)((w)pA.method_4287()).getTimer()).method_3790(0.85F);
                  double[] var7 = new double[77];
                  var10001 = true;
                  byte var10002 = 1;
                  var7[0] = 9.086895254E-315D;
                  var7[1] = 6.46988029E-315D;
                  var7[2] = 6.162954817E-315D;
                  var7[3] = 1.2289241544E-314D;
                  var7[4] = 3.62878256E-315D;
                  var7[5] = 1.8498370986E-314D;
                  var7[6] = 1.4458091E-314D;
                  var7[7] = 1.6851023214E-314D;
                  var7[8] = 3.34087017E-316D;
                  var7[9] = 7.34719823E-315D;
                  var7[10] = 1.6670398935E-314D;
                  var7[11] = 3.56495293E-315D;
                  var7[12] = 2.0744630855E-314D;
                  var7[13] = 1.777723194E-314D;
                  var7[14] = 1.487773689E-314D;
                  var7[15] = 4.794012893E-315D;
                  var7[16] = 2.030325573E-315D;
                  var7[17] = 1.867356296E-314D;
                  var7[18] = 1.2888153637E-314D;
                  var7[19] = 4.685366707E-315D;
                  var7[20] = 3.73471259E-315D;
                  var7[21] = 1.7960572373E-314D;
                  var7[22] = 1.096647425E-314D;
                  var7[23] = 3.97237612E-315D;
                  var7[24] = 1.215479189E-314D;
                  var7[25] = 1.1204137775E-314D;
                  var7[26] = 1.307149407E-314D;
                  var7[27] = 1.4938850366E-314D;
                  var7[28] = 1.680620666E-314D;
                  var7[29] = 1.867356296E-314D;
                  var7[30] = 2.054091926E-314D;
                  var7[31] = 1.188317645E-315D;
                  var7[32] = 3.05567394E-315D;
                  var7[33] = 4.923030237E-315D;
                  var7[34] = 6.790386532E-315D;
                  var7[35] = 8.65774283E-315D;
                  var7[36] = 1.0525099124E-314D;
                  var7[37] = 1.239245542E-314D;
                  var7[38] = 1.4259811716E-314D;
                  var7[39] = 1.612716801E-314D;
                  var7[40] = 1.7994524307E-314D;
                  var7[41] = 1.9861880603E-314D;
                  var7[42] = 6.960146194E-315D;
                  var7[43] = 1.5278369694E-314D;
                  var7[44] = 2.376635285E-315D;
                  var7[45] = 4.24399158E-315D;
                  var7[46] = 6.111347877E-315D;
                  var7[47] = 1.4429571377E-314D;
                  var7[48] = 1.52783697E-315D;
                  var7[49] = 9.84606047E-315D;
                  var7[50] = 1.816428397E-314D;
                  var7[51] = 5.26254956E-315D;
                  var7[52] = 1.358077306E-314D;
                  var7[53] = 6.7903865E-316D;
                  var7[54] = 8.997262156E-315D;
                  var7[55] = 1.7315485657E-314D;
                  var7[56] = 4.413751247E-315D;
                  var7[57] = 1.273197475E-314D;
                  var7[58] = 2.105019825E-314D;
                  var7[59] = 8.14846384E-315D;
                  var7[60] = 1.646668734E-314D;
                  var7[61] = 3.56495293E-315D;
                  var7[62] = 1.188317643E-314D;
                  var7[63] = 2.020139993E-314D;
                  var7[64] = 7.29966552E-315D;
                  var7[65] = 1.561788902E-314D;
                  var7[66] = 2.716154613E-315D;
                  var7[67] = 1.1034378113E-314D;
                  var7[68] = 1.9352601614E-314D;
                  var7[69] = 6.450867205E-315D;
                  var7[70] = 8.3182235E-315D;
                  var7[71] = 3.73471259E-315D;
                  var7[72] = 2.0371159592E-314D;
                  var7[73] = 1.5787648684E-314D;
                  var7[74] = 1.1204137775E-314D;
                  var7[75] = 6.620626866E-315D;
                  var7[76] = 2.037115957E-315D;
                  double[] var4 = var7;
                  if (pA.method_4250().player.movementInput.forwardKeyDown) {
                     try {
                        pA.method_4295().player.motionX = (double)var3 * var4[pA.method_2522(this.field_330) - 1] * 0.0D;
                        pA.method_4282().player.motionZ = (double)var2 * var4[pA.method_2522(this.field_330) - 1] * 0.0D;
                        return;
                     } catch (Exception var5) {
                        return;
                     }
                  }

                  pA.method_4290().player.motionX = 0.0D;
                  pA.method_4272().player.motionZ = 0.0D;
                  return;
               } else {
                  ((r)((w)pA.method_4244()).getTimer()).method_3790(1.0F);
                  pA.method_2520(this.field_330, 0);
                  pA.method_2530(this.field_330, pA.method_2536(this.field_330) + 1);
                  EntityPlayerSP var10003 = pA.method_4289().player;
                  var10003.motionX /= 0.0D;
                  var10003 = pA.method_4283().player;
                  var10003.motionZ /= 0.0D;
                  if (pA.method_2536(this.field_330) == 1) {
                     pA.method_2535(this.field_330, pA.method_4243().player.posX, pA.method_4280().player.posY, pA.method_4279().player.posZ);
                     pA.method_2535(this.field_330, pA.method_4271().player.posX + 1.181527256E-314D, pA.method_4278().player.posY, pA.method_4275().player.posZ);
                     pA.method_2535(this.field_330, pA.method_4277().player.posX, pA.method_4270().player.posY + 7.978704173E-315D, pA.method_4267().player.posZ);
                     pA.method_2535(this.field_330, pA.method_4273().player.posX + 1.181527256E-314D, pA.method_4276().player.posY, pA.method_4274().player.posZ);
                     pA.method_2535(this.field_330, pA.method_4245().player.posX, pA.method_4281().player.posY + 7.978704173E-315D, pA.method_4242().player.posZ);
                  }

                  if (pA.method_2536(this.field_330) > 2) {
                     pA.method_2530(this.field_330, 0);
                     pA.method_4269().player.motionX = (double)var3 * 4.24399158E-315D;
                     pA.method_4315().player.motionZ = (double)var2 * 4.24399158E-315D;
                     pA.method_4319().player.motionY = 1.856746317E-314D;
                  }
               }
            }
         }
      default:
      }
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

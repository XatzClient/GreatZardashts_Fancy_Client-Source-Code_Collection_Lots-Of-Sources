package net.futureclient.client;

import java.awt.TrayIcon.MessageType;
import java.util.Iterator;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import org.lwjgl.opengl.Display;

public class Cc extends ja {
   public final YC field_323;

   public Cc(YC var1) {
      this.field_323 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (Display.isActive()) {
         YC.method_1863(false);
         YC.method_1827(false);
         YC.method_1849(false);
         YC.method_1836(false);
         YC.method_1840(false);
      } else {
         Cc var10000;
         label211: {
            aB var2;
            if ((var2 = (aB)YH.method_1211().method_1205().method_2166(aB.class)) != null && var2.f$c() && (Boolean)this.field_323.field_808.method_3690()) {
               EnumFacing var3 = YC.method_4243().player.getHorizontalFacing();
               if (YC.method_4280().player.getRidingEntity() == null) {
                  if (var3.equals(EnumFacing.NORTH) && YC.method_4279().player.motionZ == 0.0D) {
                     if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                        YC.method_3231();
                        if (YC.method_4078() > 1) {
                           YC.method_3280(0);
                           YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                           if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                              YC.method_1849(true);
                              var10000 = this;
                              break label211;
                           }
                        }
                     }
                  } else if (var3.equals(EnumFacing.SOUTH) && YC.method_4271().player.motionX == 0.0D && YC.method_4278().player.motionZ == 0.0D) {
                     if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                        YC.method_3231();
                        if (YC.method_4078() > 1) {
                           YC.method_3280(0);
                           YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                           if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                              YC.method_1849(true);
                              var10000 = this;
                              break label211;
                           }
                        }
                     }
                  } else if (var3.equals(EnumFacing.EAST) && YC.method_4275().player.motionX == 0.0D) {
                     if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                        YC.method_3231();
                        if (YC.method_4078() > 1) {
                           YC.method_3280(0);
                           YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                           if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                              YC.method_1849(true);
                              var10000 = this;
                              break label211;
                           }
                        }
                     }
                  } else {
                     if (!var3.equals(EnumFacing.WEST) || YC.method_4277().player.motionX != 0.0D) {
                        YC.method_1849(false);
                        YC.method_3280(0);
                        var10000 = this;
                        break label211;
                     }

                     if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                        YC.method_3231();
                        if (YC.method_4078() > 1) {
                           YC.method_3280(0);
                           YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                           if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                              YC.method_1849(true);
                              var10000 = this;
                              break label211;
                           }
                        }
                     }
                  }
               } else if (var3.equals(EnumFacing.NORTH) && YC.method_4270().player.getRidingEntity().motionZ == 0.0D) {
                  if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                     YC.method_3231();
                     if (YC.method_4078() > 1) {
                        YC.method_3280(0);
                        YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                        if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                           YC.method_1849(true);
                           var10000 = this;
                           break label211;
                        }
                     }
                  }
               } else if (var3.equals(EnumFacing.SOUTH) && YC.method_4267().player.getRidingEntity().motionX == 0.0D && YC.method_4273().player.getRidingEntity().motionZ == 0.0D) {
                  if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                     YC.method_3231();
                     if (YC.method_4078() > 1) {
                        YC.method_3280(0);
                        YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                        if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                           YC.method_1849(true);
                           var10000 = this;
                           break label211;
                        }
                     }
                  }
               } else if (var3.equals(EnumFacing.EAST) && YC.method_4276().player.getRidingEntity().motionX == 0.0D) {
                  if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                     YC.method_3231();
                     if (YC.method_4078() > 1) {
                        YC.method_3280(0);
                        YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                        if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                           YC.method_1849(true);
                           var10000 = this;
                           break label211;
                        }
                     }
                  }
               } else if (var3.equals(EnumFacing.WEST) && YC.method_4274().player.getRidingEntity().motionX == 0.0D) {
                  if (!YC.method_1853() && YC.method_1854(this.field_323).method_3405(2500L)) {
                     YC.method_3231();
                     if (YC.method_4078() > 1) {
                        YC.method_3280(0);
                        YH.method_1211().method_1208().field_1163.displayMessage("No longer moving", "AutoWalk has detected that you are stuck.", MessageType.NONE);
                        if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                           YC.method_1849(true);
                           var10000 = this;
                           break label211;
                        }
                     }
                  }
               } else {
                  YC.method_1849(false);
                  YC.method_3280(0);
               }
            }

            var10000 = this;
         }

         label218: {
            if ((Boolean)var10000.field_323.field_803.method_3690() && YC.method_4245().player.hurtTime != 0) {
               if (!YC.method_1832() && YC.method_1831(this.field_323).method_3405(10000L)) {
                  YH.method_1211().method_1208().field_1163.displayMessage("Damage received", "You have just taken damage.", MessageType.NONE);
                  if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                     YC.method_1836(true);
                     var10000 = this;
                     break label218;
                  }
               }
            } else {
               YC.method_1836(false);
            }

            var10000 = this;
         }

         if ((Boolean)var10000.field_323.field_805.method_3690()) {
            Iterator var5 = YC.method_4281().world.playerEntities.iterator();

            while(true) {
               while(var5.hasNext()) {
                  EntityPlayer var4;
                  if (EI.method_886(var4 = (EntityPlayer)((Entity)var5.next())) && !YC.method_1839(this.field_323).contains(var4) && ((Boolean)this.field_323.field_811.method_3690() || !YH.method_1211().method_1216().method_1481(var4.getName())) && !var4.getName().equals(YC.method_4242().player.getName()) && !(var4 instanceof EntityPlayerSP)) {
                     if (!YC.method_2901() && YC.method_1864(this.field_323).method_3405(10000L)) {
                        YC.method_1839(this.field_323).add(var4);
                        YH.method_1211().method_1208().field_1163.displayMessage("Player in range", (new StringBuilder()).insert(0, var4.getName()).append(" came into render distance.").toString(), MessageType.NONE);
                        if (((wb)YC.method_1843(this.field_323).method_3690()).equals(wb.Once)) {
                           YC.method_1840(true);
                        }
                     }
                  } else {
                     YC.method_1840(false);
                  }
               }

               return;
            }
         }
      }
   }
}

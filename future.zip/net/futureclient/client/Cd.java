package net.futureclient.client;

public class Cd extends ja {
   public final cc field_332;

   public Cd(cc var1) {
      this.field_332 = var1;
   }

   public void method_691(DD var1) {
      var1.method_3481(true);
   }

   public void method_4312(CD var1) {
      this.method_691((DD)var1);
   }
}

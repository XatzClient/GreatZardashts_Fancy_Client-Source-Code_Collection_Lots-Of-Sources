package net.futureclient.client;

import java.util.Iterator;
import java.util.UUID;

public class Ce extends ja {
   public final MD field_331;

   public Ce(MD var1) {
      this.field_331 = var1;
   }

   public void method_4183(Xe var1) {
      Iterator var2 = MD.method_313(this.field_331).iterator();

      while(var2.hasNext()) {
         UUID var3 = (UUID)var2.next();
         if (MD.method_4315().getConnection().getPlayerInfo(var3) != null) {
            if (MD.method_311(this.field_331).method_3405(1000L)) {
               oI.f$c(var3.run<invokedynamic>(var3));
               MD.method_311(this.field_331).method_3404();
            }

            MD.method_313(this.field_331).remove(var3);
         }
      }

   }

   private static void method_688(UUID var0) {
      String var1 = hH.f$k(var0);
      MD.method_4319().addScheduledTask(var1.run<invokedynamic>(var1));
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   private static void method_2771(String var0) {
      la.method_2324().method_2322((new StringBuilder()).insert(0, var0).append(" is no longer vanished.").toString());
   }
}

package net.futureclient.client;

public class Cf {
   public static final int[] field_341;
   public static final int[] field_342;
   public static final int[] field_343;
   public static final int[] field_344;

   static {
      int[] var10000 = new int[TE.values().length];
      boolean var10001 = true;
      byte var10002 = 1;
      field_343 = var10000;
      var10000 = field_343;
      TE var10 = TE.Left;

      try {
         var10000[var10.ordinal()] = 1;
      } catch (NoSuchFieldError var9) {
      }

      var10000 = field_343;
      var10 = TE.Right;

      try {
         var10000[var10.ordinal()] = 2;
      } catch (NoSuchFieldError var8) {
      }

      var10000 = new int[qD.values().length];
      var10001 = true;
      var10002 = 1;
      field_344 = var10000;
      var10000 = field_344;
      qD var11 = qD.Default;

      try {
         var10000[var11.ordinal()] = 1;
      } catch (NoSuchFieldError var7) {
      }

      var10000 = field_344;
      var11 = qD.Static;

      try {
         var10000[var11.ordinal()] = 2;
      } catch (NoSuchFieldError var6) {
      }

      var10000 = field_344;
      var11 = qD.Rainbow;

      try {
         var10000[var11.ordinal()] = 3;
      } catch (NoSuchFieldError var5) {
      }

      var10000 = new int[Se.values().length];
      var10001 = true;
      var10002 = 1;
      field_342 = var10000;
      var10000 = field_342;
      Se var12 = Se.ABC;

      try {
         var10000[var12.ordinal()] = 1;
      } catch (NoSuchFieldError var4) {
      }

      var10000 = field_342;
      var12 = Se.Length;

      try {
         var10000[var12.ordinal()] = 2;
      } catch (NoSuchFieldError var3) {
      }

      var10000 = new int[Jg.values().length];
      var10001 = true;
      var10002 = 1;
      field_341 = var10000;
      var10000 = field_341;
      Jg var13 = Jg.Up;

      try {
         var10000[var13.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
      }

      var10000 = field_341;
      var13 = Jg.Down;

      try {
         var10000[var13.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
      }
   }
}

package net.futureclient.client;

import java.awt.Color;
import java.util.Iterator;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

public class Cg extends ja {
   public final yf field_340;

   public Cg(yf var1) {
      this.field_340 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4042((Df)var1);
   }

   public void method_4042(Df var1) {
      if (var1.method_823().equals(GF.PRE)) {
         if ((Boolean)yf.method_3615(this.field_340).method_3690()) {
            zF var2 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
            Color var11 = new Color((float)var2.field_1445.getRed() / 255.0F, (float)var2.field_1445.getGreen() / 255.0F, (float)var2.field_1445.getBlue() / 255.0F, 0.6F);
            Cg var10000;
            if (yf.method_3603(this.field_340).size() > 1000) {
               var10000 = this;
               yf.method_3603(this.field_340).clear();
            } else {
               Iterator var3 = yf.method_3603(this.field_340).iterator();

               while(var3.hasNext()) {
                  BlockPos var4;
                  double var5 = (double)(var4 = (BlockPos)var3.next()).getX() - ((A)yf.method_4270().getRenderManager()).getRenderPosX();
                  double var7 = (double)var4.getY() - ((A)yf.method_4267().getRenderManager()).getRenderPosY();
                  double var9 = (double)var4.getZ() - ((A)yf.method_4273().getRenderManager()).getRenderPosZ();
                  if (yf.method_4276().player.getDistance((double)var4.getX(), (double)var4.getY(), (double)var4.getZ()) <= 0.0D) {
                     Di.method_894();
                     nI.method_2430(new AxisAlignedBB(var5, var7, var9, var5 + 1.0D, var7 + 1.0D, var9 + 1.0D), 1.0F, var11);
                     Di.method_942();
                  }
               }

               var10000 = this;
            }

            if (yf.method_3635(var10000.field_340) >= 0) {
               BlockPos var12;
               double var13 = (double)(var12 = (BlockPos)yf.method_3620(this.field_340).get(yf.method_3635(this.field_340))).getX() - ((A)yf.method_4274().getRenderManager()).getRenderPosX();
               double var6 = (double)var12.getY() - ((A)yf.method_4245().getRenderManager()).getRenderPosY();
               double var8 = (double)var12.getZ() - ((A)yf.method_4281().getRenderManager()).getRenderPosZ();
               if (yf.method_4242().player.getDistance((double)var12.getX(), (double)var12.getY(), (double)var12.getZ()) <= 0.0D) {
                  Di.method_894();
                  nI.method_2430(new AxisAlignedBB(var13, var6, var8, var13 + 1.0D, var6 + 1.0D, var8 + 1.0D), 1.0F, var11);
                  Di.method_942();
               }

               GL11.glColor4f(1.0F, (float)1, (float)1, (float)1);
            }
         }

      }
   }
}

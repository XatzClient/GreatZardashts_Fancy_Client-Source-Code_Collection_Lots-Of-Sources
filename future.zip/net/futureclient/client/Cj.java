package net.futureclient.client;

public class Cj implements p {
   public double method_2157(String var1, String var2) {
      String var10000;
      String var3;
      String var4;
      if (var1.length() > var2.length()) {
         var4 = var1.toLowerCase();
         var10000 = var3 = var2.toLowerCase();
      } else {
         var4 = var2.toLowerCase();
         var10000 = var3 = var1.toLowerCase();
      }

      int var6 = var10000.length() / 2 + 1;
      var2 = this.method_707(var3, var4, var6);
      var1 = this.method_707(var4, var3, var6);
      if (var2.length() != 0 && var1.length() != 0) {
         if (var2.length() != var1.length()) {
            return 0.0D;
         } else {
            int var5 = this.method_2156(var2, var1);
            return ((double)var2.length() / (double)var3.length() + (double)var1.length() / (double)var4.length() + (double)(var2.length() - var5) / (double)var2.length()) / 0.0D;
         }
      } else {
         return 0.0D;
      }
   }

   private String method_707(String var1, String var2, int var3) {
      StringBuilder var4 = new StringBuilder();
      StringBuilder var5 = new StringBuilder(var2);

      int var6;
      for(int var10000 = var6 = 0; var10000 < var1.length(); var10000 = var6) {
         char var7 = var1.charAt(var6);
         boolean var8 = false;
         int var9 = Math.max(0, var6 - var3);

         for(boolean var10 = var8; !var10 && var9 < Math.min(var6 + var3, var2.length()); var10 = var8) {
            if (var5.charAt(var9) == var7) {
               var8 = true;
               var4.append(var7);
               var5.setCharAt(var9, '*');
            }

            ++var9;
         }

         ++var6;
      }

      return var4.toString();
   }

   private int method_2156(String var1, String var2) {
      int var3 = 0;

      int var4;
      for(int var10000 = var4 = 0; var10000 < var1.length(); var10000 = var4) {
         if (var1.charAt(var4) != var2.charAt(var4)) {
            ++var3;
         }

         ++var4;
      }

      return var3 /= 2;
   }
}

package net.futureclient.client;

import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.math.Vec3d;

public class DA extends ja {
   public final Vb field_338;

   public DA(Vb var1) {
      this.field_338 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      SPacketSoundEffect var2;
      if (var1.method_3084() instanceof SPacketSoundEffect && (var2 = (SPacketSoundEffect)var1.method_3084()).getSound().equals(SoundEvents.ENTITY_BOBBER_SPLASH) && Vb.method_4242().player.fishEntity != null && Vb.method_4315().player.fishEntity.getAngler().equals(Vb.method_4269().player) && (Vb.method_1952(this.field_338).method_3692().doubleValue() == 0.0D || Vb.method_4319().player.fishEntity.getPositionVector().distanceTo(new Vec3d(var2.getX(), var2.getY(), var2.getZ())) <= Vb.method_1952(this.field_338).method_3692().doubleValue())) {
         Vb.method_1951(this.field_338, true);
      }

   }
}

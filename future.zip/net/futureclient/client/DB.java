package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;

public class DB extends wA {
   private Minecraft field_335 = Minecraft.getMinecraft();
   private ga field_336;

   public DB(ga var1) {
      super(var1.f$c()[0]);
      this.field_336 = var1;
   }

   public void method_3982(int var1, int var2, int var3) {
      super.method_4046(var1, var2, var3);
      if (this.method_2412(var1, var2)) {
         if (var3 == 0) {
            this.field_336.method_3561();
            return;
         }

         if (var3 == 1) {
            this.field_336.method_3563();
            this.field_335.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         }
      }

   }

   public void method_1667() {
   }

   public boolean method_2415() {
      return true;
   }

   public int method_2414() {
      return 14;
   }

   public void method_3986(int var1, int var2, float var3) {
      YE var5 = (YE)YH.method_1211().method_1205().method_2166(YE.class);
      zF var4 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
      Di.method_937(this.field_853, this.field_848, this.field_853 + (float)this.field_850 + 7.0F, this.field_848 + (float)this.field_854, this.method_2415() ? (!this.method_2412(var1, var2) ? var4.field_1445.getRGB() + -1728053248 : var4.field_1445.getRGB() + 1879048192) : (!this.method_2412(var1, var2) ? 290805077 : -2007673515));
      Object[] var10002;
      boolean var10003;
      byte var10004;
      if ((Boolean)var5.field_583.method_3690()) {
         GlStateManager.enableBlend();
         sH var6 = var5.field_573;
         var10002 = new Object[2];
         var10003 = true;
         var10004 = 1;
         var10002[0] = this.method_1914();
         var10002[1] = this.field_336.method_3690();
         var6.method_3678(String.format("%s§7 %s", var10002), (double)(this.field_853 + 2.0F), (double)(this.field_848 + 4.0F), 16777215);
         GlStateManager.disableBlend();
      } else {
         FontRenderer var10000 = this.field_335.fontRenderer;
         var10002 = new Object[2];
         var10003 = true;
         var10004 = 1;
         var10002[0] = this.method_1914();
         var10002[1] = this.field_336.method_3690();
         var10000.drawStringWithShadow(String.format("%s§7 %s", var10002), this.field_853 + 2.0F, this.field_848 + 4.0F, 16777215);
      }
   }
}

package net.futureclient.client;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class DC extends ka {
   private t field_324;
   private t field_325;
   private t field_326;
   private t field_327;
   private t field_328;
   private t field_329;

   public static t method_676(DC var0) {
      return var0.field_324;
   }

   public static boolean method_677(DC var0, Entity var1) {
      return var0.method_1748(var1);
   }

   private void method_678(if var1) {
      var1.method_3272().render(var1.method_2377(), var1.method_2178(), var1.method_2182(), var1.method_2177(), var1.method_2181(), var1.method_2179(), var1.method_3117());
   }

   private boolean method_1748(Entity var1) {
      OD var2 = (OD)YH.method_1211().method_1205().method_2166(OD.class);
      Object var3 = f$e.getRenderViewEntity() == null ? f$e.player : f$e.getRenderViewEntity();
      if (var1 == null) {
         return false;
      } else if (!(Boolean)this.field_325.method_3690() && var1.equals(var3)) {
         return false;
      } else if ((Boolean)this.field_329.method_3690() && var1 instanceof EntityPlayer && (!var2.f$c() || !var2.field_261.containsKey(var1.getEntityId()))) {
         return true;
      } else if (!(Boolean)this.field_326.method_3690() || !Ti.method_1815(var1) && !Ti.method_1818(var1)) {
         return (Boolean)this.field_328.method_3690() && (Ti.method_1817(var1) || Ti.method_1821(var1));
      } else {
         return true;
      }
   }

   public static void method_680(DC var0, if var1) {
      var0.method_678(var1);
   }

   public static t method_681(DC var0) {
      return var0.field_327;
   }

   public DC() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Chams";
      var10002[1] = "Cham";
      var10002[2] = "Chammies";
      super("Chams", var10002, true, -14510046, bE.RENDER);
      Boolean var3 = false;
      String[] var4 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Self";
      var4[1] = "self";
      var4[2] = "localplayer";
      var4[3] = "theplayer";
      this.field_325 = new t(var3, var4);
      var3 = true;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Players";
      var4[1] = "player";
      var4[2] = "human";
      var4[3] = "P";
      this.field_329 = new t(var3, var4);
      var3 = true;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Monsters";
      var4[1] = "Hostiles";
      var4[2] = "Mobs";
      var4[3] = "monstas";
      var4[4] = "H";
      this.field_326 = new t(var3, var4);
      var3 = true;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Animals";
      var4[1] = "Neutrals";
      var4[2] = "ani";
      var4[3] = "animal";
      var4[4] = "N";
      this.field_328 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Texture";
      var4[1] = "texture";
      var4[2] = "skin";
      this.field_324 = new t(var3, var4);
      var3 = false;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "XQZ";
      var4[1] = "xqz";
      var4[2] = "throughwalls";
      var4[3] = "walls";
      this.field_327 = new t(var3, var4);
      t[] var10001 = new t[6];
      boolean var2 = true;
      byte var5 = 1;
      var10001[0] = this.field_325;
      var10001[1] = this.field_329;
      var10001[2] = this.field_326;
      var10001[3] = this.field_328;
      var10001[4] = this.field_324;
      var10001[5] = this.field_327;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var5 = 1;
      var1[0] = new UC(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public final class DD extends CD {
   private boolean field_322;

   public boolean method_3480() {
      return this.field_322;
   }

   public void method_3481(boolean var1) {
      this.field_322 = var1;
   }
}

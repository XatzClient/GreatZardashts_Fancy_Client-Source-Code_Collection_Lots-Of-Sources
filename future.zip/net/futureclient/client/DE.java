package net.futureclient.client;

public class DE extends CD {
   private float field_333;
   private float field_334;

   public void method_2096(float var1) {
      this.field_333 = var1;
   }

   public float method_2179() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return this.field_333;
   }

   public void method_3094(float var1) {
      this.field_334 = var1;
   }

   public float method_3117() {
      return this.field_334;
   }
}

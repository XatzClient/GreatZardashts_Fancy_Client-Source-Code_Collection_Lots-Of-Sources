package net.futureclient.client;

import java.util.ArrayList;
import java.util.Iterator;

public class DF extends bF {
   public eD method_684(int var1) {
      Iterator var2 = this.field_1201.iterator();

      eD var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (eD)var2.next();
      } while(var1 != var3.method_3056());

      return var3;
   }

   public boolean method_685(int var1) {
      Iterator var2 = this.field_1201.iterator();

      eD var3;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         var3 = (eD)var2.next();
      } while(var1 != var3.method_3056());

      return true;
   }

   public void method_2271(int var1) {
      eD var2;
      if ((var2 = this.method_684(var1)) != null) {
         this.field_1201.remove(var2);
      }

   }

   public DF() {
      this.field_1201 = new ArrayList();
      YH.method_1211().method_1212().method_1330(new pE(this));
      new UE(this, "macros.txt");
   }
}

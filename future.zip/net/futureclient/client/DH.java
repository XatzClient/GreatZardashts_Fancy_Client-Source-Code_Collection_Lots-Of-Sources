package net.futureclient.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.util.math.BlockPos;

public class DH extends xb {
   private List field_339;

   public static List method_709(DH var0, List var1) {
      return var0.field_339 = var1;
   }

   public String method_4224() {
      return null;
   }

   public static List method_711(DH var0) {
      return var0.field_339;
   }

   public String method_4228(String[] var1) {
      this.field_1834.player.connection.sendPacket(new CPacketTabComplete("/", (BlockPos)null, false));
      YH.method_1211().method_1212().method_1330(new og(this));
      return y.f$c("<1\u000b;\u0017.\u001d*\u00116\u001fx\b4\r?\u00116\u000btX(\u0014=\u0019+\u001dx\u000f9\u0011,VvV");
   }

   public DH() {
      String[] var10001 = new String[5];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Plugins";
      var10001[1] = "PluginDiscover";
      var10001[2] = "Discover";
      var10001[3] = "plugin";
      var10001[4] = "pl";
      super(var10001);
      this.field_339 = new ArrayList();
   }
}

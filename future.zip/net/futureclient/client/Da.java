package net.futureclient.client;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRedstoneTorch;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.math.BlockPos;

public class Da extends ka {
   private ga field_405;
   private boolean field_406;
   private final Y field_407;
   private t field_408;
   private int field_409;
   private final List field_410;
   public U field_411;

   private List method_832() {
      ArrayList var1;
      (var1 = new ArrayList()).add(Blocks.EMERALD_ORE);
      var1.add(Blocks.GOLD_ORE);
      var1.add(Blocks.IRON_ORE);
      var1.add(Blocks.COAL_ORE);
      var1.add(Blocks.LAPIS_ORE);
      var1.add(Blocks.DIAMOND_ORE);
      var1.add(Blocks.REDSTONE_ORE);
      var1.add(Blocks.LIT_REDSTONE_ORE);
      var1.add(Blocks.TNT);
      var1.add(Blocks.EMERALD_ORE);
      var1.add(Blocks.FURNACE);
      var1.add(Blocks.LIT_FURNACE);
      var1.add(Blocks.DIAMOND_BLOCK);
      var1.add(Blocks.IRON_BLOCK);
      var1.add(Blocks.GOLD_BLOCK);
      var1.add(Blocks.EMERALD_BLOCK);
      var1.add(Blocks.QUARTZ_ORE);
      var1.add(Blocks.BEACON);
      var1.add(Blocks.MOB_SPAWNER);
      return var1;
   }

   public static t method_833(Da var0) {
      return var0.field_408;
   }

   public static int method_834(Da var0, int var1) {
      return var0.field_409 = var1;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static int method_836(Da var0) {
      return var0.field_409;
   }

   private boolean method_837(Block var1) {
      return ((Ba)this.field_405.method_3690()).equals(Ba.Normal) ? ((List)this.field_407.method_3690()).contains(var1) : this.field_410.contains(var1);
   }

   public static boolean method_838(Da var0, Block var1) {
      return var0.method_837(var1);
   }

   public static ga method_839(Da var0) {
      return var0.field_405;
   }

   public boolean method_840(Block var1, BlockPos var2) {
      if (((Ba)this.field_405.method_3690()).equals(Ba.Normal)) {
         return ((List)this.field_407.method_3690()).contains(var1);
      } else {
         boolean var10 = this.field_410.contains(var1);
         boolean var3 = false;
         EnumFacing[] var4;
         int var5 = (var4 = Plane.HORIZONTAL.facings()).length;

         int var6;
         for(int var10000 = var6 = 0; var10000 < var5; var10000 = var6) {
            EnumFacing var7 = var4[var6];
            BlockPos var8 = var2.add(var7.getOpposite().getDirectionVec());
            IBlockState var9;
            if ((var9 = f$e.world.getBlockState(var8)).getBlock() instanceof BlockRedstoneTorch && var9.getValue(BlockTorch.FACING) == var7.getOpposite()) {
               var3 = true;
            }

            ++var6;
         }

         boolean var12 = false;
         EnumFacing var13 = EnumFacing.DOWN;
         BlockPos var14 = var2.add(var13.getOpposite().getDirectionVec());
         IBlockState var15;
         if ((var15 = f$e.world.getBlockState(var14)).getBlock() instanceof BlockRedstoneTorch && var15.getValue(BlockTorch.FACING) != EnumFacing.UP) {
            var12 = true;
         }

         Block var11 = f$e.world.getBlockState(var2.add(0, 1, 0)).getBlock();
         boolean var16 = this.field_410.contains(var11) && !var12;
         return var10 || var3;
      }
   }

   private List method_3928() {
      ArrayList var1;
      (var1 = new ArrayList()).add(Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE);
      var1.add(Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE);
      var1.add(Blocks.STONE_PRESSURE_PLATE);
      var1.add(Blocks.WOODEN_PRESSURE_PLATE);
      var1.add(Blocks.STONE_BUTTON);
      var1.add(Blocks.WOODEN_BUTTON);
      var1.add(Blocks.LEVER);
      var1.add(Blocks.COMMAND_BLOCK);
      var1.add(Blocks.CHAIN_COMMAND_BLOCK);
      var1.add(Blocks.REPEATING_COMMAND_BLOCK);
      var1.add(Blocks.DAYLIGHT_DETECTOR);
      var1.add(Blocks.DAYLIGHT_DETECTOR_INVERTED);
      var1.add(Blocks.DISPENSER);
      var1.add(Blocks.DROPPER);
      var1.add(Blocks.HOPPER);
      var1.add(Blocks.OBSERVER);
      var1.add(Blocks.TRAPDOOR);
      var1.add(Blocks.IRON_TRAPDOOR);
      var1.add(Blocks.REDSTONE_BLOCK);
      var1.add(Blocks.REDSTONE_LAMP);
      var1.add(Blocks.REDSTONE_TORCH);
      var1.add(Blocks.UNLIT_REDSTONE_TORCH);
      var1.add(Blocks.REDSTONE_WIRE);
      var1.add(Blocks.POWERED_REPEATER);
      var1.add(Blocks.UNPOWERED_REPEATER);
      var1.add(Blocks.POWERED_COMPARATOR);
      var1.add(Blocks.UNPOWERED_COMPARATOR);
      var1.add(Blocks.LIT_REDSTONE_LAMP);
      var1.add(Blocks.REDSTONE_ORE);
      var1.add(Blocks.LIT_REDSTONE_ORE);
      var1.add(Blocks.ACACIA_DOOR);
      var1.add(Blocks.DARK_OAK_DOOR);
      var1.add(Blocks.BIRCH_DOOR);
      var1.add(Blocks.JUNGLE_DOOR);
      var1.add(Blocks.OAK_DOOR);
      var1.add(Blocks.SPRUCE_DOOR);
      var1.add(Blocks.DARK_OAK_DOOR);
      var1.add(Blocks.IRON_DOOR);
      var1.add(Blocks.OAK_FENCE);
      var1.add(Blocks.SPRUCE_FENCE);
      var1.add(Blocks.BIRCH_FENCE);
      var1.add(Blocks.JUNGLE_FENCE);
      var1.add(Blocks.DARK_OAK_FENCE);
      var1.add(Blocks.ACACIA_FENCE);
      var1.add(Blocks.OAK_FENCE_GATE);
      var1.add(Blocks.SPRUCE_FENCE_GATE);
      var1.add(Blocks.BIRCH_FENCE_GATE);
      var1.add(Blocks.JUNGLE_FENCE_GATE);
      var1.add(Blocks.DARK_OAK_FENCE_GATE);
      var1.add(Blocks.ACACIA_FENCE_GATE);
      var1.add(Blocks.JUKEBOX);
      var1.add(Blocks.NOTEBLOCK);
      var1.add(Blocks.PISTON);
      var1.add(Blocks.PISTON_EXTENSION);
      var1.add(Blocks.PISTON_HEAD);
      var1.add(Blocks.STICKY_PISTON);
      var1.add(Blocks.TNT);
      var1.add(Blocks.SLIME_BLOCK);
      var1.add(Blocks.TRIPWIRE);
      var1.add(Blocks.TRIPWIRE_HOOK);
      var1.add(Blocks.RAIL);
      var1.add(Blocks.ACTIVATOR_RAIL);
      var1.add(Blocks.DETECTOR_RAIL);
      var1.add(Blocks.GOLDEN_RAIL);
      return var1;
   }

   public void method_4314() {
      String var10000 = "net.minecraftforge.common.ForgeModContainer";
      boolean var10001 = true;
      Da var10002 = this;

      try {
         Field var4 = Class.forName(var10000, var10001, var10002.getClass().getClassLoader()).getDeclaredField("forgeLightPipelineEnabled");
         boolean var2 = var4.isAccessible();
         var4.setAccessible(true);
         var4.set((Object)null, this.field_406);
         var4.setAccessible(var2);
      } catch (Exception var3) {
      }

      kd var1;
      if ((var1 = (kd)YH.method_1211().method_1205().method_2166(kd.class)) != null && !var1.f$c()) {
         f$e.gameSettings.gammaSetting = 1.0F;
      }

      f$e.renderChunksMany = true;
      Da var5;
      if ((Boolean)this.field_408.method_3690()) {
         iI.f$D();
         var5 = this;
      } else {
         iI.f$c();
         var5 = this;
      }

      var5.method_4314();
   }

   public void method_4326() {
      String var10000 = "net.minecraftforge.common.ForgeModContainer";
      boolean var10001 = true;
      Da var10002 = this;

      Da var5;
      label18: {
         try {
            Field var2 = Class.forName(var10000, var10001, var10002.getClass().getClassLoader()).getDeclaredField("forgeLightPipelineEnabled");
            boolean var3 = var2.isAccessible();
            var2.setAccessible(true);
            this.field_406 = var2.getBoolean((Object)null);
            var2.set((Object)null, false);
            var2.setAccessible(var3);
         } catch (Exception var4) {
            var5 = this;
            break label18;
         }

         var5 = this;
      }

      var5.field_409 = this.field_411.method_3692().intValue();
      f$e.renderChunksMany = false;
      if ((Boolean)this.field_408.method_3690()) {
         iI.f$D();
         var5 = this;
      } else {
         iI.f$c();
         var5 = this;
      }

      var5.method_4326();
   }

   public Da() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Wallhack";
      var10002[1] = "X-Ray";
      var10002[2] = "wh";
      super("Wallhack", var10002, true, -2525659, bE.WORLD);
      Ba var3 = Ba.Normal;
      String[] var6 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Mode";
      var6[1] = "Type";
      this.field_405 = new ga(var3, var6);
      Float var4 = 120.0F;
      Float var8 = 0.0F;
      Float var10 = 255.0F;
      Integer var11 = 1;
      String[] var10007 = new String[6];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Opacity";
      var10007[1] = "Op";
      var10007[2] = "Oapcity";
      var10007[3] = "Oapcit";
      var10007[4] = "Opacit";
      var10007[5] = "o";
      this.field_411 = new U(var4, var8, var10, var11, var10007);
      Boolean var5 = true;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Soft Reload";
      var6[1] = "softreload";
      var6[2] = "soft";
      var6[3] = "sr";
      this.field_408 = new t(var5, var6);
      List var7 = this.method_832();
      var6 = new String[2];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Blocks";
      var6[1] = "Ores";
      this.field_407 = new Y(var7, var6);
      this.field_410 = this.method_3928();
      this.field_406 = false;
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var9 = 1;
      var10001[0] = this.field_405;
      var10001[1] = this.field_411;
      var10001[2] = this.field_408;
      var10001[3] = this.field_407;
      this.f$c(var10001);
      ja[] var1 = new ja[3];
      var2 = true;
      var9 = 1;
      var1[0] = new ma(this);
      var1[1] = new Ca(this);
      var1[2] = new ba(this);
      this.method_2383(var1);
   }
}

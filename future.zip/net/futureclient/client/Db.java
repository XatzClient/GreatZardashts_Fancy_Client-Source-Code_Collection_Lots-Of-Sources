package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Db extends ja {
   public final CB field_403;

   public Db(CB var1) {
      this.field_403 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      switch(pd.f$e[var1.method_326().ordinal()]) {
      case 1:
         Minecraft var10000 = CB.method_4269();
         boolean var10001 = false;
         if (!var10000.player.isEntityAlive()) {
            CB.method_4315().player.motionY = (double)CB.method_720(this.field_403).method_3692().floatValue();
         }
      default:
      }
   }
}

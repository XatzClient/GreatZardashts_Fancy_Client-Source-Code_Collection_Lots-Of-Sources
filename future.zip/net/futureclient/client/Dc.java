package net.futureclient.client;

import net.minecraft.client.shader.Framebuffer;

public class Dc extends ja {
   public final Lb field_396;

   public Dc(Lb var1) {
      this.field_396 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4193((ae)var1);
   }

   public void method_4193(ae var1) {
      if (Lb.method_364(this.field_396) != null) {
         Lb.method_364(this.field_396).unbindFramebuffer();
      }

      Lb.method_365(this.field_396, (Framebuffer)null);
      if (Lb.method_363(this.field_396) != null) {
         Lb.method_363(this.field_396).f$E();
      }

      Lb.method_373(this.field_396, (AC)null);
   }
}

package net.futureclient.client;

public class Dd extends ka {
   public Dd() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AntiLevitation";
      var10002[1] = "NoLevitation";
      super("AntiLevitation", var10002, true, 13565951, bE.MOVEMENT);
      ja[] var10001 = new ja[1];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new fB(this);
      this.method_2383(var10001);
   }
}

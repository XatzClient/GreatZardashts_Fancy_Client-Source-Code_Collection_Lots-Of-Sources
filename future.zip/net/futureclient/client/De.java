package net.futureclient.client;

public class De extends CD {
}

package net.futureclient.client;

public class Df extends CD {
   private GF field_400;
   private float field_401;

   public Df(GF var1, float var2) {
      this.field_400 = var1;
      this.field_401 = var2;
   }

   public GF method_823() {
      return this.field_400;
   }

   public float method_3117() {
      return this.field_401;
   }
}

package net.futureclient.client;

public class Dh extends xb {
   public String method_4224() {
      return "&e[format]";
   }

   public Dh() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Runtime";
      var10001[1] = "time";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length != 1) {
         return null;
      } else {
         long var2;
         long var4;
         long var6;
         byte var10000;
         boolean var10001;
         label39: {
            var6 = (var4 = (var2 = (System.nanoTime() / 1000000L - YH.method_1211().field_535) / 1000L) / 60L) / 60L;
            String var8 = var1[0];
            byte var9 = -1;
            byte var11;
            switch(var8.hashCode()) {
            case -1074026988:
               var10001 = false;
               if (var8.equals("minute")) {
                  var10000 = 2;
                  var11 = 2;
                  break label39;
               }
               break;
            case -906279820:
               if (var8.equals("second")) {
                  var10000 = 0;
                  var11 = 0;
                  break label39;
               }
               break;
            case 3208676:
               if (var8.equals("hour")) {
                  var10000 = 4;
                  var11 = 4;
                  break label39;
               }
               break;
            case 99469071:
               if (var8.equals("hours")) {
                  var9 = 5;
               }
               break;
            case 1064901855:
               if (var8.equals("minutes")) {
                  var10000 = 3;
                  var11 = 3;
                  break label39;
               }
               break;
            case 1970096767:
               if (var8.equals("seconds")) {
                  var10000 = 1;
                  var11 = 1;
                  break label39;
               }
            }

            var10000 = var9;
         }

         String var10;
         Object[] var12;
         boolean var10002;
         byte var10003;
         switch(var10000) {
         case 0:
         case 1:
            var10001 = false;
            String var13 = ei.f$c("t\u0002q\u00024\u0012>\u001f5\u0002");
            var12 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var12[0] = var2;
            var10 = String.format(var13, var12);
            break;
         case 2:
         case 3:
            var12 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var12[0] = var4;
            var10 = String.format("%s minutes", var12);
            break;
         case 4:
         case 5:
            var12 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var12[0] = var6;
            var10 = String.format("%s hours", var12);
            break;
         default:
            return "Invalid time format, use second, minute, hour.";
         }

         var12 = new Object[1];
         var10002 = true;
         var10003 = 1;
         var12[0] = var10;
         return String.format("You've been playing for &e%s&7.", var12);
      }
   }
}

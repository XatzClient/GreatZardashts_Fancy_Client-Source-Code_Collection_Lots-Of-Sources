package net.futureclient.client;

import java.awt.Color;
import java.awt.Rectangle;
import java.nio.ByteBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.GL11;

public class Di {
   private static ScaledResolution field_415;
   private static final Minecraft field_416 = Minecraft.getMinecraft();

   static {
      field_415 = new ScaledResolution(field_416);
   }

   public static void method_892(float var0, float var1, float var2, float var3, int var4, int var5) {
      method_946();
      var0 *= 2.0F;
      var2 *= 2.0F;
      var1 *= 2.0F;
      var3 *= 2.0F;
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      method_929(var0, var1, var3 - 1.0F, var5);
      method_929(var2 - 1.0F, var1, var3, var5);
      method_897(var0, var2 - 1.0F, var1, var5);
      method_897(var0, var2 - 2.0F, var3 - 1.0F, var5);
      method_937(var0 + 1.0F, var1 + 1.0F, var2 - 1.0F, var3 - 1.0F, var4);
      GL11.glScalef((float)2, 2.0F, (float)2);
      method_902();
   }

   public static void method_893(AxisAlignedBB var0) {
      GL11.glBegin(1);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
      GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
      GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
      GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
      GL11.glEnd();
   }

   public static void method_894() {
      GL11.glPushAttrib(1048575);
      GL11.glPushMatrix();
      GL11.glDisable(3008);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glEnable(2884);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4353);
      GL11.glDisable(2896);
   }

   public static void method_895(Color var0) {
      GL11.glColor4d((double)((float)var0.getRed() / 255.0F), (double)((float)var0.getGreen() / 255.0F), (double)((float)var0.getBlue() / 255.0F), (double)((float)var0.getAlpha() / 255.0F));
   }

   public static void method_896(float var0, float var1, float var2, int var3, int var4) {
      if (var1 < var0) {
         float var10000 = var0;
         var0 = var1;
         var1 = var10000;
      }

      method_901(var0, var2, var1 + 1.0F, var2 + 1.0F, var3, var4);
   }

   public static void method_897(float var0, float var1, float var2, int var3) {
      if (var1 < var0) {
         float var10000 = var0;
         var0 = var1;
         var1 = var10000;
      }

      method_937(var0, var2, var1 + 1.0F, var2 + 1.0F, var3);
   }

   public static void method_898(float var0, float var1, float var2, float var3, float var4, int var5, int var6) {
      method_946();
      method_924(var5);
      method_900(var0 + var4, var1 + var4, var2 - var4, var3 - var4);
      method_924(var6);
      method_900(var0 + var4, var1, var2 - var4, var1 + var4);
      method_900(var0, var1, var0 + var4, var3);
      method_900(var2 - var4, var1, var2, var3);
      method_900(var0 + var4, var3 - var4, var2 - var4, var3);
      method_902();
   }

   public static void method_899(AxisAlignedBB var0) {
      Tessellator var1 = Tessellator.getInstance();
      BufferBuilder var2 = Tessellator.getInstance().getBuffer();
      var2.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
      var2.pos(var0.minX, var0.minY, var0.minZ);
      var2.pos(var0.minX, var0.maxY, var0.minZ);
      var2.pos(var0.maxX, var0.minY, var0.minZ);
      var2.pos(var0.maxX, var0.maxY, var0.minZ);
      var2.pos(var0.maxX, var0.minY, var0.maxZ);
      var2.pos(var0.maxX, var0.maxY, var0.maxZ);
      var2.pos(var0.minX, var0.minY, var0.maxZ);
      var2.pos(var0.minX, var0.maxY, var0.maxZ);
      var2.pos(var0.maxX, var0.maxY, var0.minZ);
      var2.pos(var0.maxX, var0.minY, var0.minZ);
      var2.pos(var0.minX, var0.maxY, var0.minZ);
      var2.pos(var0.minX, var0.minY, var0.minZ);
      var2.pos(var0.minX, var0.maxY, var0.maxZ);
      var2.pos(var0.minX, var0.minY, var0.maxZ);
      var2.pos(var0.maxX, var0.maxY, var0.maxZ);
      var2.pos(var0.maxX, var0.minY, var0.maxZ);
      var2.pos(var0.minX, var0.maxY, var0.minZ);
      var2.pos(var0.maxX, var0.maxY, var0.minZ);
      var2.pos(var0.maxX, var0.maxY, var0.maxZ);
      var2.pos(var0.minX, var0.maxY, var0.maxZ);
      var2.pos(var0.minX, var0.maxY, var0.minZ);
      var2.pos(var0.minX, var0.maxY, var0.maxZ);
      var2.pos(var0.maxX, var0.maxY, var0.maxZ);
      var2.pos(var0.maxX, var0.maxY, var0.minZ);
      var2.pos(var0.minX, var0.minY, var0.minZ);
      var2.pos(var0.maxX, var0.minY, var0.minZ);
      var2.pos(var0.maxX, var0.minY, var0.maxZ);
      var2.pos(var0.minX, var0.minY, var0.maxZ);
      var2.pos(var0.minX, var0.minY, var0.minZ);
      var2.pos(var0.minX, var0.minY, var0.maxZ);
      var2.pos(var0.maxX, var0.minY, var0.maxZ);
      var2.pos(var0.maxX, var0.minY, var0.minZ);
      var2.pos(var0.minX, var0.minY, var0.minZ);
      var2.pos(var0.minX, var0.maxY, var0.minZ);
      var2.pos(var0.minX, var0.minY, var0.maxZ);
      var2.pos(var0.minX, var0.maxY, var0.maxZ);
      var2.pos(var0.maxX, var0.minY, var0.maxZ);
      var2.pos(var0.maxX, var0.maxY, var0.maxZ);
      var2.pos(var0.maxX, var0.minY, var0.minZ);
      var2.pos(var0.maxX, var0.maxY, var0.minZ);
      var2.pos(var0.minX, var0.maxY, var0.maxZ);
      var2.pos(var0.minX, var0.minY, var0.maxZ);
      var2.pos(var0.minX, var0.maxY, var0.minZ);
      var2.pos(var0.minX, var0.minY, var0.minZ);
      var2.pos(var0.maxX, var0.maxY, var0.minZ);
      var2.pos(var0.maxX, var0.minY, var0.minZ);
      var2.pos(var0.maxX, var0.maxY, var0.maxZ);
      var2.pos(var0.maxX, var0.minY, var0.maxZ);
      var1.draw();
   }

   public static void method_900(float var0, float var1, float var2, float var3) {
      GL11.glBegin(7);
      GL11.glVertex2f(var0, var3);
      GL11.glVertex2f(var2, var3);
      GL11.glVertex2f(var2, var1);
      GL11.glVertex2f(var0, var1);
      GL11.glEnd();
   }

   public static void method_901(float var0, float var1, float var2, float var3, int var4, int var5) {
      method_946();
      GL11.glShadeModel(7425);
      GL11.glBegin(7);
      method_924(var4);
      GL11.glVertex2f(var0, var3);
      GL11.glVertex2f(var2, var3);
      method_924(var5);
      GL11.glVertex2f(var2, var1);
      GL11.glVertex2f(var0, var1);
      GL11.glEnd();
      GL11.glShadeModel(7424);
      method_902();
   }

   public static void method_902() {
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glHint(3155, 4352);
   }

   public static ScaledResolution method_903() {
      return field_415;
   }

   public static void method_904(Entity var0, int var1) {
      GL11.glPushMatrix();
      GL11.glTranslated(var0.posX - ((A)field_416.getRenderManager()).getRenderPosX(), var0.posY - ((A)field_416.getRenderManager()).getRenderPosY() + (double)(var0.height / 2.0F), var0.posZ - ((A)field_416.getRenderManager()).getRenderPosZ());
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GL11.glRotatef(-field_416.player.rotationYaw, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(field_416.player.rotationPitch, 1.0F, 0.0F, (float)0);
      field_416.entityRenderer.disableLightmap();
      GL11.glDisable(2929);
      float var2 = 0.2F;
      nI.method_2431((double)(-var0.width), (double)(-var0.height + var2 * 3.0F), (double)var0.width, (double)(var0.height - var2 * 3.0F), 1426063360 | var1);
      GL11.glEnable(2929);
      field_416.entityRenderer.enableLightmap();
      GL11.glPopMatrix();
   }

   public static void method_905(Rectangle var0, int var1) {
      method_937((float)var0.x, (float)var0.y, (float)(var0.x + var0.width), (float)(var0.y + var0.height), var1);
   }

   public static void method_906(double var0, double var2, double var4, double var6, float var8, int var9, int var10, int var11) {
      method_946();
      GL11.glPushMatrix();
      method_924(var9);
      GL11.glLineWidth(1.0F);
      GL11.glBegin(1);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glPopMatrix();
      method_923(var0, var2, var4, var6, var10, var11);
      method_902();
   }

   public static void method_907(float var0) {
      GL11.glDisable(3008);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glEnable(2884);
      field_416.entityRenderer.enableLightmap();
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
      GL11.glLineWidth(var0);
   }

   public static double method_908(double var0, double var2) {
      return var2 + (var0 - var2) * (double)((w)field_416).getTimer().renderPartialTicks;
   }

   public static void method_909(int var0, int var1, float var2, double var3, float var5, float var6, int var7) {
      float var8 = (float)(var7 >> 24 & 255) / 255.0F;
      float var9 = (float)(var7 >> 16 & 255) / 255.0F;
      float var10 = (float)(var7 >> 8 & 255) / 255.0F;
      float var11 = (float)(var7 & 255) / 255.0F;
      GL11.glPushMatrix();
      GL11.glTranslated((double)var0, (double)var1, 0.0D);
      GL11.glColor4f(var9, var10, var11, var8);
      GL11.glLineWidth(var2);
      int var10000;
      if (var3 > 0.0D) {
         GL11.glBegin(3);

         for(var10000 = var1 = 0; (double)var10000 < var3; var10000 = var1) {
            var11 = (float)(Math.cos((double)(var2 = (float)((double)var1 * (var3 * 6.984873503E-315D / (double)var5)))) * (double)var6);
            var8 = (float)(Math.sin((double)var2) * (double)var6);
            ++var1;
            GL11.glVertex2f(var11, var8);
         }

         GL11.glEnd();
      }

      if (var3 < 0.0D) {
         GL11.glBegin(3);

         for(var10000 = var1 = 0; (double)var10000 > var3; var10000 = var1) {
            var11 = (float)(Math.cos((double)(var2 = (float)((double)var1 * (var3 * 6.984873503E-315D / (double)var5)))) * (double)(-var6));
            var8 = (float)(Math.sin((double)var2) * (double)(-var6));
            --var1;
            GL11.glVertex2f(var11, var8);
         }

         GL11.glEnd();
      }

      method_902();
      GL11.glDisable(3479);
      GL11.glPopMatrix();
   }

   public static void method_910(double var0, double var2, double var4, double var6, int var8) {
      float var9 = (float)(var8 >> 16 & 255) / 255.0F;
      float var10 = (float)(var8 >> 8 & 255) / 255.0F;
      float var11 = (float)(var8 & 255) / 255.0F;
      float var14 = (float)(var8 >> 24 & 255) / 255.0F;
      Tessellator var12;
      BufferBuilder var13 = (var12 = Tessellator.getInstance()).getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.color(var9, var10, var11, var14);
      var13.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
      var13.pos(var0, var6, 0.0D);
      var13.pos(var4, var6, 0.0D);
      var13.pos(var4, var2, 0.0D);
      var13.pos(var0, var2, 0.0D);
      var12.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.color((float)1, (float)1, 1.0F, (float)1);
      GlStateManager.disableBlend();
   }

   public static void method_911(Color var0) {
      GL11.glColor4f((float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, (float)var0.getAlpha() / 255.0F);
   }

   public static void method_912(int var0, int var1, int var2, int var3, int var4) {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      float var5 = (float)(var4 >> 24 & 255) / 255.0F;
      float var6 = (float)(var4 >> 16 & 255) / 255.0F;
      float var7 = (float)(var4 >> 8 & 255) / 255.0F;
      float var8 = (float)(var4 & 255) / 255.0F;
      GL11.glColor4f(var6, var7, var8, var5);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(1.0F);
      GL11.glShadeModel(7425);
      switch(var2) {
      case 0:
         boolean var10001 = false;
         GL11.glBegin(2);
         GL11.glVertex2d((double)var0, (double)(var1 + var3));
         GL11.glVertex2d((double)(var0 + var3), (double)(var1 - var3));
         GL11.glVertex2d((double)(var0 - var3), (double)(var1 - var3));
         GL11.glEnd();
         GL11.glBegin(4);
         GL11.glVertex2d((double)var0, (double)(var1 + var3));
         GL11.glVertex2d((double)(var0 + var3), (double)(var1 - var3));
         GL11.glVertex2d((double)(var0 - var3), (double)(var1 - var3));
         GL11.glEnd();
         break;
      case 1:
         GL11.glBegin(2);
         GL11.glVertex2d((double)var0, (double)var1);
         GL11.glVertex2d((double)var0, (double)(var1 + var3 / 2));
         GL11.glVertex2d((double)(var0 + var3 + var3 / 2), (double)var1);
         GL11.glEnd();
         GL11.glBegin(4);
         GL11.glVertex2d((double)var0, (double)var1);
         GL11.glVertex2d((double)var0, (double)(var1 + var3 / 2));
         GL11.glVertex2d((double)(var0 + var3 + var3 / 2), (double)var1);
         GL11.glEnd();
      case 2:
      default:
         break;
      case 3:
         GL11.glBegin(2);
         GL11.glVertex2d((double)var0, (double)var1);
         GL11.glVertex2d((double)var0 + (double)var3 * 0.0D, (double)(var1 - var3 / 2));
         GL11.glVertex2d((double)var0 + (double)var3 * 0.0D, (double)(var1 + var3 / 2));
         GL11.glEnd();
         GL11.glBegin(4);
         GL11.glVertex2d((double)var0 + (double)var3 * 0.0D, (double)(var1 - var3 / 2));
         GL11.glVertex2d((double)var0, (double)var1);
         GL11.glVertex2d((double)var0 + (double)var3 * 0.0D, (double)(var1 + var3 / 2));
         GL11.glEnd();
      }

      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }

   public static void method_913(float var0, float var1, float var2, float var3) {
      method_939();
      int var4 = field_415.getScaleFactor();
      GL11.glScissor((int)(var0 * (float)var4), (int)(((float)field_415.getScaledHeight() - var3) * (float)var4), (int)((var2 - var0) * (float)var4), (int)((var3 - var1) * (float)var4));
   }

   public static void method_914(AxisAlignedBB var0) {
      Tessellator var10000 = Tessellator.getInstance();
      BufferBuilder var1 = var10000.getBuffer();
      var1.begin(3, DefaultVertexFormats.POSITION);
      var1.pos(var0.minX, var0.minY, var0.minZ).endVertex();
      var1.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
      var1.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
      var1.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
      var1.pos(var0.minX, var0.minY, var0.minZ).endVertex();
      var10000.draw();
      var1.begin(3, DefaultVertexFormats.POSITION);
      var1.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
      var1.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
      var1.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
      var1.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
      var1.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
      var10000.draw();
      var1.begin(1, DefaultVertexFormats.POSITION);
      var1.pos(var0.minX, var0.minY, var0.minZ).endVertex();
      var1.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
      var1.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
      var1.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
      var1.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
      var1.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
      var1.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
      var1.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
      var10000.draw();
   }

   public static String method_915(int var0) {
      return ARBShaderObjects.glGetInfoLogARB(var0, ARBShaderObjects.glGetObjectParameteriARB(var0, 35716));
   }

   public static int method_916(int var0, int var1, int var2, ByteBuffer var3, boolean var4, boolean var5) {
      GL11.glBindTexture(3553, var0);
      GL11.glTexParameteri(3553, 10241, var4 ? 9729 : 9728);
      GL11.glTexParameteri(3553, 10240, var4 ? 9729 : 9728);
      GL11.glTexParameteri(3553, 10242, var5 ? 10497 : 10496);
      GL11.glTexParameteri(3553, 10243, var5 ? 10497 : 10496);
      GL11.glPixelStorei(3317, 1);
      GL11.glTexImage2D(3553, 0, 32856, var1, var2, 0, 6408, 5121, var3);
      return var0;
   }

   public static void method_917(int var0, int var1, double var2, int var4) {
      var2 *= 0.0D;
      var0 *= 2;
      var1 *= 2;
      float var5 = (float)(var4 >> 24 & 255) / 255.0F;
      float var6 = (float)(var4 >> 16 & 255) / 255.0F;
      float var7 = (float)(var4 >> 8 & 255) / 255.0F;
      float var12 = (float)(var4 & 255) / 255.0F;
      method_946();
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      GL11.glColor4f(var6, var7, var12, var5);
      GL11.glBegin(6);

      for(int var10000 = var4 = 0; var10000 <= 360; var10000 = var4) {
         double var8 = Math.sin((double)var4 * 6.984873503E-315D / 0.0D) * var2;
         double var10 = Math.cos((double)var4 * 6.984873503E-315D / 0.0D) * var2;
         double var13 = (double)var0 + var8;
         double var10001 = (double)var1;
         ++var4;
         GL11.glVertex2d(var13, var10001 + var10);
      }

      GL11.glEnd();
      GL11.glScalef((float)2, 2.0F, (float)2);
      method_902();
   }

   public static void method_918(float var0, float var1, double var2, Color var4) {
      method_911(var4);
      GlStateManager.enableAlpha();
      GlStateManager.enableBlend();
      GL11.glDisable(3553);
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.alphaFunc(516, 0.001F);
      Tessellator var12;
      BufferBuilder var5 = (var12 = Tessellator.getInstance()).getBuffer();

      double var6;
      for(double var10000 = var6 = 0.0D; var10000 < 0.0D; var10000 = ++var6) {
         double var8 = var6 * 6.984873503E-315D / 0.0D;
         double var10 = (var6 - 1.0D) * 6.984873503E-315D / 0.0D;
         double[] var14 = new double[4];
         boolean var10001 = true;
         byte var10002 = 1;
         var14[0] = Math.cos(var8) * var2;
         var14[1] = -Math.sin(var8) * var2;
         var14[2] = Math.cos(var10) * var2;
         var14[3] = -Math.sin(var10) * var2;
         double[] var13 = var14;
         var5.begin(6, DefaultVertexFormats.POSITION_TEX);
         var5.pos((double)var0 + var13[2], (double)var1 + var13[3], 0.0D).endVertex();
         var5.pos((double)var0 + var13[0], (double)var1 + var13[1], 0.0D).endVertex();
         var5.pos((double)var0, (double)var1, 0.0D).endVertex();
         var12.draw();
      }

      GlStateManager.disableBlend();
      GlStateManager.alphaFunc(516, 0.1F);
      GlStateManager.disableAlpha();
      GL11.glEnable(3553);
   }

   public static Vec3d method_919(Entity var0, float var1) {
      return (new Vec3d(var0.lastTickPosX, var0.lastTickPosY, var0.lastTickPosZ)).add(method_938(var0, (double)var1));
   }

   public static Vec3d method_920(Entity var0, Vec3d var1) {
      return method_936(var0, var1.x, var1.y, var1.z);
   }

   public static float[] method_921(int var0) {
      float var1 = (float)(var0 >> 16 & 255) / 255.0F;
      float var2 = (float)(var0 >> 8 & 255) / 255.0F;
      float var3 = (float)(var0 & 255) / 255.0F;
      float var4 = (float)(var0 >> 24 & 255) / 255.0F;
      float[] var10000 = new float[4];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = var1;
      var10000[1] = var2;
      var10000[2] = var3;
      var10000[3] = var4;
      return var10000;
   }

   public static void method_922(double var0, double var2, double var4, double var6, double var8, double var10, int var12) {
      float var13 = (float)(var12 >> 16 & 255) / 255.0F;
      float var14 = (float)(var12 >> 8 & 255) / 255.0F;
      float var15 = (float)(var12 & 255) / 255.0F;
      float var18 = (float)(var12 >> 24 & 255) / 255.0F;
      GlStateManager.pushMatrix();
      Tessellator var16;
      BufferBuilder var17 = (var16 = Tessellator.getInstance()).getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.color(var13, var14, var15, var18);
      var17.begin(6, DefaultVertexFormats.POSITION_TEX_COLOR);
      Tessellator var10000;
      if (var2 > var6 && var0 < var8 || var2 < var6 && var0 > var8) {
         var17.pos(var8, var10, 0.0D);
         var17.pos(var4, var6, 0.0D);
         var17.pos(var0, var2, 0.0D);
         var10000 = var16;
      } else {
         var17.pos(var0, var2, 0.0D);
         var17.pos(var4, var6, 0.0D);
         var17.pos(var8, var10, 0.0D);
         var10000 = var16;
      }

      var10000.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.color((float)1, (float)1, 1.0F, (float)1);
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void method_923(double var0, double var2, double var4, double var6, int var8, int var9) {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      method_924(var8);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var2);
      method_924(var9);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glShadeModel(7424);
   }

   public static void method_924(int var0) {
      float var1 = (float)(var0 >> 24 & 255) / 255.0F;
      float var2 = (float)(var0 >> 16 & 255) / 255.0F;
      float var3 = (float)(var0 >> 8 & 255) / 255.0F;
      float var4 = (float)(var0 & 255) / 255.0F;
      GL11.glColor4f(var2, var3, var4, var1);
   }

   public static void method_925(float var0, float var1, float var2, float var3, float var4) {
      GL11.glDisable(3553);
      GL11.glLineWidth(var4);
      GL11.glBegin(1);
      GL11.glVertex2f(var0, var1);
      GL11.glVertex2f(var2, var3);
      GL11.glEnd();
      GL11.glEnable(3553);
   }

   public static void method_926(float var0, float var1, float var2, int var3, int var4) {
      var2 *= 2.0F;
      var0 *= 2.0F;
      var1 *= 2.0F;
      float var5 = (float)(var4 >> 24 & 255) / 255.0F;
      float var6 = (float)(var4 >> 16 & 255) / 255.0F;
      float var7 = (float)(var4 >> 8 & 255) / 255.0F;
      float var12 = (float)(var4 & 255) / 255.0F;
      float var8;
      float var9 = (float)Math.cos((double)(var8 = (float)(6.388667265E-315D / (double)var3)));
      var8 = (float)Math.sin((double)var8);
      float var10 = var2;
      float var11 = 0.0F;
      method_946();
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      GL11.glColor4f(var6, var7, var12, var5);
      GL11.glBegin(2);

      for(int var10000 = var4 = 0; var10000 < var3; var10000 = var4) {
         GL11.glVertex2f(var10 + var0, var11 + var1);
         var2 = var10;
         var10 = var9 * var10 - var8 * var11;
         float var13 = var8 * var2;
         ++var4;
         var11 = var13 + var9 * var11;
      }

      GL11.glEnd();
      GL11.glScalef((float)2, 2.0F, (float)2);
      method_902();
   }

   public static Vec3d method_927(Entity var0) {
      double var1 = method_908(var0.posX, var0.lastTickPosX) - ((A)field_416.getRenderManager()).getRenderPosX();
      double var3 = method_908(var0.posY, var0.lastTickPosY) - ((A)field_416.getRenderManager()).getRenderPosY();
      double var5 = method_908(var0.posZ, var0.lastTickPosZ) - ((A)field_416.getRenderManager()).getRenderPosZ();
      return new Vec3d(var1, var3, var5);
   }

   public static void method_928(float var0, float var1, float var2, float var3, float var4, int var5, int var6) {
      method_946();
      method_937(var0, var1, var2, var3, var5);
      method_924(var6);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glLineWidth(var4);
      GL11.glBegin(3);
      GL11.glVertex2f(var0, var1);
      GL11.glVertex2f(var0, var3);
      GL11.glVertex2f(var2, var3);
      GL11.glVertex2f(var2, var1);
      GL11.glVertex2f(var0, var1);
      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      method_902();
   }

   public static void method_929(float var0, float var1, float var2, int var3) {
      if (var2 < var1) {
         float var10000 = var1;
         var1 = var2;
         var2 = var10000;
      }

      method_937(var0, var1 + 1.0F, var0 + 1.0F, var2, var3);
   }

   public static void method_930(float var0, int var1, int var2, int var3) {
      float var4 = 0.003921569F * (float)var1;
      float var5 = 0.003921569F * (float)var2;
      float var6 = 0.003921569F * (float)var3;
      GL11.glColor4f(var4, var5, var6, var0);
   }

   public static void method_931(Rectangle var0, float var1, int var2, int var3) {
      float var4 = (float)var0.x;
      float var5 = (float)var0.y;
      float var6 = (float)(var0.x + var0.width);
      float var7 = (float)(var0.y + var0.height);
      method_946();
      method_924(var2);
      method_900(var4 + var1, var5 + var1, var6 - var1, var7 - var1);
      method_924(var3);
      method_900(var4 + 1.0F, var5, var6 - 1.0F, var5 + var1);
      method_900(var4, var5, var4 + var1, var7);
      method_900(var6 - var1, var5, var6, var7);
      method_900(var4 + 1.0F, var7 - var1, var6 - 1.0F, var7);
      method_902();
   }

   public static void method_932(float var0, float var1, float var2, float var3, int var4, int var5) {
      method_946();
      GL11.glShadeModel(7425);
      GL11.glBegin(7);
      method_924(var4);
      GL11.glVertex2f(var0, var1);
      GL11.glVertex2f(var0, var3);
      method_924(var5);
      GL11.glVertex2f(var2, var3);
      GL11.glVertex2f(var2, var1);
      GL11.glEnd();
      GL11.glShadeModel(7424);
      method_902();
   }

   public static Color method_933(Color var0, Color var1, float var2) {
      float var3 = 1.0F - var2;
      float[] var10000 = new float[3];
      boolean var10001 = true;
      byte var10002 = 1;
      float[] var4 = var10000;
      var10000 = new float[3];
      var10001 = true;
      var10002 = 1;
      float[] var5 = var10000;
      var0.getColorComponents(var4);
      var1.getColorComponents(var5);
      return new Color(var4[0] * var2 + var5[0] * var3, var4[1] * var2 + var5[1] * var3, var4[2] * var2 + var5[2] * var3);
   }

   public static Color method_934(long var0, float var2) {
      long var4 = Long.parseLong(Integer.toHexString(Color.HSBtoRGB((float)(System.nanoTime() + var0) / 1.0E10F % 1.0F, 1.0F, (float)1)), 16);
      Color var3 = new Color((int)var4);
      return new Color((float)var3.getRed() / 255.0F * var2, (float)var3.getGreen() / 255.0F * var2, (float)var3.getBlue() / 255.0F * var2, (float)var3.getAlpha() / 255.0F);
   }

   public static void method_935(float var0, float var1, float var2, float var3, float var4, int var5, int var6, int var7) {
      method_946();
      method_901(var0, var1, var2, var3, var7, var6);
      method_924(var5);
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glLineWidth(var4);
      GL11.glBegin(3);
      GL11.glVertex2f(var0, var1);
      GL11.glVertex2f(var0, var3);
      GL11.glVertex2f(var2, var3);
      GL11.glVertex2f(var2, var1);
      GL11.glVertex2f(var0, var1);
      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      method_902();
   }

   public static Vec3d method_936(Entity var0, double var1, double var3, double var5) {
      return new Vec3d((var0.posX - var0.lastTickPosX) * var1, (var0.posY - var0.lastTickPosY) * var3, (var0.posZ - var0.lastTickPosZ) * var5);
   }

   public static void method_937(float var0, float var1, float var2, float var3, int var4) {
      method_946();
      method_924(var4);
      method_900(var0, var1, var2, var3);
      method_902();
   }

   public static Vec3d method_938(Entity var0, double var1) {
      return method_936(var0, var1, var1, var1);
   }

   public static void method_939() {
      field_415 = new ScaledResolution(field_416);
   }

   public static void method_940(double var0, double var2, double var4, double var6, double var8, double var10, float var12, int var13, int var14) {
      method_922(var0, var2, var4, var6, var8, var10, var14);
      float var18 = (float)(var13 >> 24 & 255) / 255.0F;
      float var15 = (float)(var13 >> 16 & 255) / 255.0F;
      float var16 = (float)(var13 >> 8 & 255) / 255.0F;
      float var17 = (float)(var13 & 255) / 255.0F;
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.blendFunc(770, 771);
      GL11.glEnable(2848);
      GlStateManager.pushMatrix();
      GlStateManager.color(var15, var16, var17, var18);
      GL11.glLineWidth(var12);
      GL11.glBegin(1);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glBegin(1);
      GL11.glVertex2d(var4, var6);
      GL11.glVertex2d(var8, var10);
      GL11.glEnd();
      GL11.glBegin(1);
      GL11.glVertex2d(var8, var10);
      GL11.glVertex2d(var0, var2);
      GL11.glEnd();
      GlStateManager.popMatrix();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GL11.glDisable(2848);
   }

   public static void method_941(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      method_946();
      GL11.glColor4f(var4, var5, var6, var7);
      method_900(var0, var1, var2, var3);
      method_902();
   }

   public static void method_942() {
      GL11.glEnable(2896);
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDisable(3042);
      GL11.glEnable(3008);
      GL11.glDepthMask(true);
      GL11.glCullFace(1029);
      GL11.glPopMatrix();
      GL11.glPopAttrib();
   }

   public static void method_943(AxisAlignedBB var0) {
      if (var0 != null) {
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glEnd();
      }
   }

   public static void method_944(float var0, float var1, float var2, float var3, int var4, int var5) {
      method_946();
      var0 *= 2.0F;
      var1 *= 2.0F;
      var2 *= 2.0F;
      var3 *= 2.0F;
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      method_929(var0, var1 + 1.0F, var3 - 2.0F, var4);
      method_929(var2 - 1.0F, var1 + 1.0F, var3 - 2.0F, var4);
      method_897(var0 + 2.0F, var2 - 3.0F, var1, var4);
      method_897(var0 + 2.0F, var2 - 3.0F, var3 - 1.0F, var4);
      method_897(var0 + 1.0F, var0 + 1.0F, var1 + 1.0F, var4);
      method_897(var2 - 2.0F, var2 - 2.0F, var1 + 1.0F, var4);
      method_897(var2 - 2.0F, var2 - 2.0F, var3 - 2.0F, var4);
      method_897(var0 + 1.0F, var0 + 1.0F, var3 - 2.0F, var4);
      method_937(var0 + 1.0F, var1 + 1.0F, var2 - 1.0F, var3 - 1.0F, var5);
      GL11.glScalef((float)2, 2.0F, (float)2);
      method_902();
   }

   public static void method_945(AxisAlignedBB var0) {
      if (var0 != null) {
         GL11.glBegin(3);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(3);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(1);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glEnd();
      }
   }

   public static void method_946() {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
   }

   public static int method_947(String var0, int var1) throws Exception {
      int var2 = 0;
      int var10000 = var1;

      Exception var6;
      label34: {
         boolean var10001;
         try {
            if ((var2 = ARBShaderObjects.glCreateShaderObjectARB(var10000)) == 0) {
               return 0;
            }
         } catch (Exception var5) {
            var6 = var5;
            var10001 = false;
            break label34;
         }

         var10000 = var2;
         String var7 = var0;

         try {
            ARBShaderObjects.glShaderSourceARB(var10000, var7);
            ARBShaderObjects.glCompileShaderARB(var2);
            if (ARBShaderObjects.glGetObjectParameteriARB(var2, 35713) == 0) {
               throw new RuntimeException((new StringBuilder()).insert(0, "Error creating shader: ").append(method_915(var2)).toString());
            }

            return var2;
         } catch (Exception var4) {
            var6 = var4;
            var10001 = false;
         }
      }

      Exception var3 = var6;
      ARBShaderObjects.glDeleteObjectARB(var2);
      throw var3;
   }
}

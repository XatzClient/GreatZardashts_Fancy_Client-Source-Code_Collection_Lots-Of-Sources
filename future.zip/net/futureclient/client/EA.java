package net.futureclient.client;

import net.minecraft.client.entity.EntityPlayerSP;
import org.lwjgl.input.Keyboard;

public class EA extends ja {
   public final gb field_402;

   public EA(gb var1) {
      this.field_402 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4311((yD)var1);
   }

   private static boolean method_1464(Class var0) {
      return var0.isInstance(gb.method_4272().currentScreen);
   }

   public void method_4311(yD var1) {
      if ((Boolean)this.field_402.field_1407.method_3690() && gb.method_3928().stream().anyMatch(test<invokedynamic>())) {
         EntityPlayerSP var10000;
         if (Keyboard.isKeyDown(200)) {
            var10000 = gb.method_4299().player;
            var10000.rotationPitch -= 2.0F;
         }

         if (Keyboard.isKeyDown(208)) {
            var10000 = gb.method_4297().player;
            var10000.rotationPitch += 2.0F;
         }

         if (Keyboard.isKeyDown(203)) {
            var10000 = gb.method_4285().player;
            var10000.rotationYaw -= 2.0F;
         }

         if (Keyboard.isKeyDown(205)) {
            var10000 = gb.method_4284().player;
            var10000.rotationYaw += 2.0F;
         }

         if (gb.method_4286().player.rotationPitch > 90.0F) {
            gb.method_4293().player.rotationPitch = 90.0F;
         }

         if (gb.method_4287().player.rotationPitch < -90.0F) {
            gb.method_4250().player.rotationPitch = -90.0F;
         }
      }

      gb.method_3501(this.field_402);
      if (gb.method_4295().player.isActiveItemStackBlocking()) {
         bA var2 = (bA)YH.method_1211().method_1205().method_2166(bA.class);
         if ((Boolean)this.field_402.field_1411.method_3690() && EI.method_890() && gb.method_4282().player.onGround && var2 != null && !var2.f$c()) {
            gb.method_4290().player.motionY = 1.273197475E-314D;
         }
      }

   }
}

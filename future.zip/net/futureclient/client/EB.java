package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class EB extends ka {
   public static Minecraft method_4319() {
      return f$e;
   }

   public EB() {
      String[] var10002 = new String[5];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NameProtect";
      var10002[1] = "Naemprotect";
      var10002[2] = "name";
      var10002[3] = "protect";
      var10002[4] = "np";
      super("NameProtect", var10002, false, 290805247, bE.RENDER);
      ja[] var10001 = new ja[2];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new jA(this);
      var10001[1] = new dA(this);
      this.method_2383(var10001);
   }
}

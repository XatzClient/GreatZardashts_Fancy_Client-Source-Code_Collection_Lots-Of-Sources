package net.futureclient.client;

import java.awt.TrayIcon.MessageType;
import org.lwjgl.opengl.Display;

public class EC extends ja {
   public final YC field_404;

   public EC(YC var1) {
      this.field_404 = var1;
   }

   public void method_4312(CD var1) {
      this.method_831((Ag)var1);
   }

   public void method_831(Ag var1) {
      if (!Display.isActive() && (Boolean)this.field_404.field_802.method_3690() && YC.method_1838(this.field_404).method_3405(10000L)) {
         YH.method_1211().method_1208().field_1163.displayMessage("Kicked from the server", var1.method_3453(), MessageType.NONE);
      }

   }
}

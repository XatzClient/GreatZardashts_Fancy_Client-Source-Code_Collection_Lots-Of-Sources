package net.futureclient.client;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Mouse;

public class ED extends ja {
   public final df field_397;

   public ED(df var1) {
      this.field_397 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4311((yD)var1);
   }

   public void method_4311(yD var1) {
      boolean var2 = false;
      switch(ie.f$e[((Xf)df.method_3066(this.field_397).method_3690()).ordinal()]) {
      case 1:
         Minecraft var10000 = df.method_4273();
         boolean var10001 = false;
         var2 = var10000.player.isSwingInProgress;
         break;
      case 2:
         var2 = Mouse.isButtonDown(0);
         break;
      case 3:
         var2 = true;
      }

      if (df.method_4276().currentScreen == null && (!(Boolean)df.method_3062(this.field_397).method_3690() || EI.method_880()) && var2) {
         EntityPlayer var7 = null;
         float var3 = Float.MAX_VALUE;

         float var4;
         Iterator var5;
         for(Iterator var11 = var5 = ((List)EI.method_870().stream().filter(this.test<invokedynamic>(this)).collect(Collectors.toList())).iterator(); var11.hasNext(); var11 = var5) {
            EntityPlayer var6 = (EntityPlayer)var5.next();
            if ((var4 = ri.method_3658(ri.method_3657(df.method_4274().player.rotationYaw), ri.method_3657(ri.method_3659(var6)[0]))) < var3) {
               var7 = var6;
            }

            var3 = Math.min(var4, var3);
         }

         if (var7 != null && (double)var3 <= df.method_3058(this.field_397).method_3692().doubleValue() && (double)var3 >= df.method_3073(this.field_397).method_3692().doubleValue()) {
            float[] var9 = ri.method_3659(var7);
            float var10 = (float)Math.min(df.method_3064(this.field_397).method_3692().doubleValue() * (double)df.method_3067(this.field_397).method_820() / 0.0D, df.method_3064(this.field_397).method_3692().doubleValue() / 0.0D);
            if ((Boolean)df.method_3079(this.field_397).method_3690()) {
               var10 = (float)((double)var10 * ((double)var3 / df.method_3058(this.field_397).method_3692().doubleValue()));
            }

            var4 = ri.method_3657(ri.method_3670(ri.method_3657(df.method_4245().player.rotationYaw), var9[0], var10));
            float var8 = ri.method_3657(ri.method_3670(ri.method_3657(df.method_4281().player.rotationPitch), var9[1], var10));
            EntityPlayerSP var12 = df.method_4242().player;
            float var13;
            ED var10002;
            if (df.method_3071(this.field_397).method_3690() != wE.Yaw && df.method_3071(this.field_397).method_3690() != wE.Both) {
               var13 = 0.0F;
               var10002 = this;
            } else {
               var13 = var4;
               var10002 = this;
            }

            var12.turn(var13, df.method_3071(var10002.field_397).method_3690() != wE.Pitch && df.method_3071(this.field_397).method_3690() != wE.Both ? 0.0F : -var8 * 0.75F);
         }
      }

      df.method_3067(this.field_397).method_814();
   }

   private boolean method_3587(EntityPlayer var1) {
      return !(var1 instanceof EntityPlayerSP) && (double)df.method_4269().player.getDistance(var1) <= df.method_3070(this.field_397).method_3692().doubleValue() && (!(Boolean)df.method_3059(this.field_397).method_3690() || !df.method_4315().player.isOnSameTeam(var1)) && (!(Boolean)df.method_3074(this.field_397).method_3690() || !var1.isInvisible()) && (!(Boolean)df.method_3063(this.field_397).method_3690() || df.method_4319().player.canEntityBeSeen(var1)) && (!(Boolean)df.method_3068(this.field_397).method_3690() || !YH.method_1211().method_1216().method_1481(var1.getName()));
   }
}

package net.futureclient.client;

public class EE extends ja {
   public final jF field_395;

   public EE(jF var1) {
      this.field_395 = var1;
   }

   private static void method_802(tE var0, Td var1) {
      if (var1.method_1759() != 0 && var0.method_3981() == var1.method_1759()) {
         var1.method_1760().method_670();
      }

   }

   public void method_4312(CD var1) {
      this.method_2753((tE)var1);
   }

   public void method_2753(tE var1) {
      if (var1.method_3980() == lf.KEY_PRESS) {
         YH.method_1211().method_1210().f$c().forEach(var1.accept<invokedynamic>(var1));
      }

   }
}

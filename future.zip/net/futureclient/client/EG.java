package net.futureclient.client;

public class EG {
   private long field_398;
   private long field_399 = 0L;

   public EG() {
      this.method_814();
   }

   public long method_810() {
      return this.field_398;
   }

   public boolean method_811(float var1) {
      return (float)(this.method_822() - this.field_398) >= var1;
   }

   public long method_812() {
      return this.field_399;
   }

   public boolean method_813(long var1) {
      return System.currentTimeMillis() - this.field_399 >= var1;
   }

   public void method_814() {
      this.field_399 = this.method_822();
      this.field_398 = this.method_822();
   }

   public boolean method_815(double var1) {
      return (double)(this.method_822() - this.field_398) >= 0.0D / var1;
   }

   public void method_816(long var1) {
      this.field_399 = var1;
   }

   public boolean method_817(long var1) {
      return this.method_822() - this.field_399 >= var1;
   }

   public boolean method_818(float var1) {
      return (float)(System.currentTimeMillis() - this.field_399) >= var1;
   }

   public void method_819() {
      this.field_399 = System.currentTimeMillis();
   }

   public long method_820() {
      return this.method_822() - this.field_398;
   }

   public int method_821(int var1) {
      return 1000 / var1;
   }

   public long method_822() {
      return System.nanoTime() / 1000000L;
   }
}

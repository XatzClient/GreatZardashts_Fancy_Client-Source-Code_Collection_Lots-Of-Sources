package net.futureclient.client;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemShield;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class EI {
   private static final Comparator field_412 = Comparator.comparing(apply<invokedynamic>()).reversed();
   private static final Comparator field_413 = Comparator.comparing(apply<invokedynamic>()).reversed();
   public static Minecraft field_414 = Minecraft.getMinecraft();

   public static void method_847() {
      if (field_414.player != null && field_414.player.getHeldItemMainhand().getItem() instanceof ItemSword && field_414.player.getHeldItemOffhand().getItem() instanceof ItemShield) {
         field_414.playerController.processRightClick(field_414.player, field_414.world, EnumHand.OFF_HAND);
      }

   }

   public static boolean method_848(Entity var0) {
      return method_885(var0) == method_885(field_414.player);
   }

   public static Comparator method_849() {
      return field_413;
   }

   public static String method_850() {
      return field_414.getRenderViewEntity() == null ? field_414.player.getHorizontalFacing().name() : field_414.getRenderViewEntity().getHorizontalFacing().name();
   }

   public static List method_851() {
      OD var0 = (OD)YH.method_1211().method_1205().method_2166(OD.class);
      return (List)field_414.world.loadedEntityList.stream().filter(var0.test<invokedynamic>(var0)).sorted(method_849()).collect(Collectors.toList());
   }

   public static boolean method_852() {
      return field_414.player.movementInput.forwardKeyDown || field_414.player.movementInput.backKeyDown || field_414.player.movementInput.leftKeyDown || field_414.player.movementInput.rightKeyDown || field_414.player.movementInput.jump || field_414.player.movementInput.sneak;
   }

   public static int method_853(IBlockState var0) {
      byte var1 = -1;
      float var2 = 1.0F;
      if (var0.getMaterial() == Material.AIR) {
         return -1;
      } else {
         byte var3;
         for(byte var10000 = var3 = 0; var10000 < 36; var10000 = ++var3) {
            InventoryPlayer var6 = field_414.player.inventory;
            byte var10001 = var3;

            try {
               ItemStack var4;
               if (!((var4 = var6.getStackInSlot(var10001)).getItem() instanceof ItemAir) && var4.getDestroySpeed(var0) > var2) {
                  var2 = var4.getDestroySpeed(var0);
                  var1 = var3;
               }
            } catch (Exception var5) {
               var5.printStackTrace();
            }
         }

         return var1;
      }
   }

   public static double method_854() {
      double var0 = 1.1441801305E-314D;
      if (field_414.player.isPotionActive(MobEffects.SPEED)) {
         int var2 = field_414.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier();
         var0 *= 1.0D + 1.273197475E-314D * (double)(var2 + 1);
      }

      return var0;
   }

   public static float method_855() {
      float var0 = field_414.player.rotationYaw;
      float var1 = field_414.player.moveForward;
      float var2 = field_414.player.moveStrafing;
      var0 += (float)(var1 < 0.0F ? 180 : 0);
      if (var2 < 0.0F) {
         var0 += var1 < 0.0F ? -45.0F : (var1 == 0.0F ? 90.0F : 45.0F);
      }

      if (var2 > 0.0F) {
         var0 -= var1 < 0.0F ? -45.0F : (var1 == 0.0F ? 90.0F : 45.0F);
      }

      return var0 * 0.017453292F;
   }

   private static boolean method_856(OD var0, Entity var1) {
      return !(var1 instanceof EntityPlayer) || var0 == null || !var0.f$c() || !var0.field_261.containsKey(var1.getEntityId());
   }

   public static double method_857(Entity var0) {
      return (double)(Math.round(Math.floor(Math.sqrt(Math.pow(var0.posX - var0.lastTickPosX, 0.0D) + Math.pow(var0.posZ - var0.lastTickPosZ, 0.0D)) * 0.0D * 0.0D * 0.0D) / 0.0D) / 10L);
   }

   public static void method_858(VF var0, double var1) {
      double var3 = (double)field_414.player.movementInput.moveForward;
      double var5 = (double)field_414.player.movementInput.moveStrafe;
      float var7 = field_414.player.rotationYaw;
      if (var3 == 0.0D && var5 == 0.0D) {
         var0.method_1731(0.0D);
         var0.method_4038(0.0D);
      } else {
         VF var10000;
         label38: {
            if (var3 != 0.0D) {
               if (var5 > 0.0D) {
                  var7 += (float)(var3 > 0.0D ? -45 : 45);
               } else if (var5 < 0.0D) {
                  var7 += (float)(var3 > 0.0D ? 45 : -45);
               }

               var5 = 0.0D;
               if (var3 > 0.0D) {
                  var3 = 1.0D;
                  var10000 = var0;
                  break label38;
               }

               if (var3 < 0.0D) {
                  var3 = 0.0D;
               }
            }

            var10000 = var0;
         }

         var10000.method_1731(var3 * var1 * Math.cos(Math.toRadians((double)(var7 + 90.0F))) + var5 * var1 * Math.sin(Math.toRadians((double)(var7 + 90.0F))));
         var0.method_4038(var3 * var1 * Math.sin(Math.toRadians((double)(var7 + 90.0F))) - var5 * var1 * Math.cos(Math.toRadians((double)(var7 + 90.0F))));
      }
   }

   public static ItemStack method_859(Class var0) {
      return method_864(field_414.player, var0);
   }

   public static boolean method_860(KeyBinding var0) {
      if (var0.getKeyCode() != 0) {
         if (var0.getKeyCode() < 0) {
            if (Mouse.isButtonDown(var0.getKeyCode() + 100)) {
               return true;
            }
         } else if (Keyboard.isKeyDown(var0.getKeyCode())) {
            return true;
         }
      }

      return false;
   }

   public static double method_861() {
      double var0 = 0.0D;
      if (field_414.player.isPotionActive(MobEffects.JUMP_BOOST)) {
         int var2 = field_414.player.getActivePotionEffect(MobEffects.JUMP_BOOST).getAmplifier();
         var0 += (double)(var2 + 1) * 1.273197475E-314D;
      }

      return var0;
   }

   public static boolean method_862(EntityPlayer var0) {
      ItemStack var1 = (ItemStack)var0.inventory.armorInventory.get(0);
      ItemStack var2 = (ItemStack)var0.inventory.armorInventory.get(1);
      ItemStack var3 = (ItemStack)var0.inventory.armorInventory.get(2);
      ItemStack var4 = (ItemStack)var0.inventory.armorInventory.get(3);
      return !(var1.getItem() instanceof ItemAir) || !(var2.getItem() instanceof ItemAir) || !(var3.getItem() instanceof ItemAir) || !(var4.getItem() instanceof ItemAir);
   }

   private static boolean method_863(OD var0, EntityPlayer var1) {
      return var0 == null || !var0.f$c() || !var0.field_261.containsKey(var1.getEntityId());
   }

   public static ItemStack method_864(EntityLivingBase var0, Class var1) {
      EnumHand[] var2;
      int var3 = (var2 = EnumHand.values()).length;

      int var4;
      for(int var10000 = var4 = 0; var10000 < var3; var10000 = var4) {
         EnumHand var5 = var2[var4];
         ItemStack var7;
         Item var6 = (var7 = var0.getHeldItem(var5)).getItem();
         if (var1.isInstance(var6)) {
            return var7;
         }

         ++var4;
      }

      return null;
   }

   public static int method_865(IBlockState var0) {
      byte var1 = -1;
      float var2 = 1.0F;
      if (var0.getMaterial() == Material.AIR) {
         return -1;
      } else {
         byte var3;
         for(byte var10000 = var3 = 0; var10000 < 36; var10000 = ++var3) {
            InventoryPlayer var6 = field_414.player.inventory;
            byte var10001 = var3;

            try {
               ItemStack var4;
               if (!((var4 = var6.getStackInSlot(var10001)).getItem() instanceof ItemAir) && var4.getDestroySpeed(var0) > var2 && field_414.player.inventoryContainer.getSlot(var3).getStack().getMaxDamage() - field_414.player.inventoryContainer.getSlot(var3).getStack().getItemDamage() > 5) {
                  var2 = var4.getDestroySpeed(var0);
                  var1 = var3;
               }
            } catch (Exception var5) {
               var5.printStackTrace();
            }
         }

         return var1;
      }
   }

   private static Float method_866(Entity var0) {
      return var0.getDistance(field_414.player);
   }

   private static Double method_867(xa var0) {
      return field_414.player.getDistance(var0.method_4206(), var0.method_4208(), var0.method_4210());
   }

   public static Comparator method_868() {
      return field_412;
   }

   public static double[] method_869(EntityPlayerSP var0, double var1) {
      MovementInput var10001 = var0.movementInput;
      double var4 = (double)var10001.moveForward;
      double var6 = (double)var10001.moveStrafe;
      float var3 = var0.rotationYaw;
      double var8;
      double var10;
      if (var4 == 0.0D && var6 == 0.0D) {
         var8 = 0.0D;
         var10 = 0.0D;
      } else {
         double var10000;
         label37: {
            if (var4 != 0.0D) {
               if (var6 > 0.0D) {
                  var3 += (float)(var4 > 0.0D ? -45 : 45);
               } else if (var6 < 0.0D) {
                  var3 += (float)(var4 > 0.0D ? 45 : -45);
               }

               var6 = 0.0D;
               if (var4 > 0.0D) {
                  var10000 = var4 = 1.0D;
                  break label37;
               }

               if (var4 < 0.0D) {
                  var4 = 0.0D;
               }
            }

            var10000 = var4;
         }

         var8 = var10000 * var1 * Math.cos(Math.toRadians((double)(var3 + 90.0F))) + var6 * var1 * Math.sin(Math.toRadians((double)(var3 + 90.0F)));
         var10 = var4 * var1 * Math.sin(Math.toRadians((double)(var3 + 90.0F))) - var6 * var1 * Math.cos(Math.toRadians((double)(var3 + 90.0F)));
      }

      double[] var12 = new double[2];
      boolean var13 = true;
      byte var10002 = 1;
      var12[0] = var8;
      var12[1] = var10;
      return var12;
   }

   public static List method_870() {
      OD var0 = (OD)YH.method_1211().method_1205().method_2166(OD.class);
      return (List)field_414.world.playerEntities.stream().filter(var0.test<invokedynamic>(var0)).sorted(method_849()).collect(Collectors.toList());
   }

   public static EnumHand method_871(Class var0) {
      EnumHand[] var1;
      int var2 = (var1 = EnumHand.values()).length;

      int var3;
      for(int var10000 = var3 = 0; var10000 < var2; var10000 = var3) {
         EnumHand var4 = var1[var3];
         if (var0.isInstance(field_414.player.getHeldItem(var4).getItem())) {
            return var4;
         }

         ++var3;
      }

      return null;
   }

   public static Entity method_872() {
      return (Entity)(field_414.player.getRidingEntity() != null && !(field_414.player.getRidingEntity() instanceof EntityBoat) ? field_414.player.getRidingEntity() : field_414.player);
   }

   public static UUID method_873(Entity var0) {
      if (var0 instanceof EntityTameable) {
         return ((EntityTameable)var0).getOwnerId();
      } else {
         return var0 instanceof AbstractHorse ? ((AbstractHorse)var0).getOwnerUniqueId() : null;
      }
   }

   public static int method_874() {
      float var0 = -1.0F;
      int var1 = -1;
      Item var2 = null;

      int var10000;
      int var3;
      ItemStack var4;
      float var5;
      for(var10000 = var3 = 0; var10000 < 9; var10000 = var3) {
         if (!((var4 = (ItemStack)field_414.player.inventory.mainInventory.get(var3)).getItem() instanceof ItemAir) && var4.getItem() instanceof ItemSword && (var5 = (float)var4.getMaxDamage()) > var0) {
            var1 = var3;
            var0 = var5;
            var2 = var4.getItem();
         }

         ++var3;
      }

      if (var2 != null) {
         return var1;
      } else {
         for(var10000 = var3 = 0; var10000 < 9; var10000 = var3) {
            if (!((var4 = (ItemStack)field_414.player.inventory.mainInventory.get(var3)).getItem() instanceof ItemAir) && var4.getItem() instanceof ItemAxe && (var5 = (float)var4.getMaxDamage()) > var0) {
               var1 = var3;
               var0 = var5;
            }

            ++var3;
         }

         return var1;
      }
   }

   public static Vec3d method_875() {
      return new Vec3d(field_414.player.posX, field_414.player.posY, field_414.player.posZ);
   }

   public static boolean method_876(Entity var0, Uh var1) {
      return field_414.world.rayTraceBlocks(new Vec3d(field_414.player.posX, field_414.player.posY + (double)field_414.player.getEyeHeight(), field_414.player.posZ), new Vec3d(var0.posX, var0.posY + (double)var0.getEyeHeight() - (double)ri.method_3664(var1), var0.posZ), false, true, false) == null;
   }

   public static double[] method_877() {
      double[] var10000 = new double[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = field_414.player.posX;
      var10000[1] = field_414.player.posY;
      var10000[2] = field_414.player.posZ;
      return var10000;
   }

   public static boolean method_878(EntityLivingBase var0) {
      return field_414.player.isOnSameTeam(var0);
   }

   public static EnumFacing method_879(float var0, float var1, float var2) {
      return EnumFacing.getFacingFromVector(var0, var1, var2);
   }

   public static boolean method_880() {
      if (field_414.player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemAir) {
         return false;
      } else {
         Item var0;
         return (var0 = field_414.player.getHeldItem(EnumHand.MAIN_HAND).getItem()) instanceof ItemTool || var0 instanceof ItemSword;
      }
   }

   public static void method_881(double[] var0, BlockPos var1, double var2) {
      double var4 = var0[0];
      double var6 = var0[1];
      double var8 = var0[2];
      double var10 = (double)var1.getX() + 0.0D;
      double var12 = (double)var1.getY() + 1.0D;
      double var14 = (double)var1.getZ() + 0.0D;
      double var16 = Math.abs(var4 - var10) + Math.abs(var6 - var12) + Math.abs(var8 - var14);
      int var28 = 0;

      for(double var10000 = var16; var10000 > var2; var10000 = var16) {
         var16 = Math.abs(var4 - var10) + Math.abs(var6 - var12) + Math.abs(var8 - var14);
         if (var28 > 120) {
            return;
         }

         double var18 = var4 - var10;
         double var20 = var6 - var12;
         double var22 = var8 - var14;
         double var24 = (var28 & 1) == 0 ? 1.273197475E-314D : 0.0D;
         double var26 = Math.min(Math.abs(var18), var24);
         if (var18 < 0.0D) {
            var4 += var26;
            var10000 = var20;
         } else {
            if (var18 > 0.0D) {
               var4 -= var26;
            }

            var10000 = var20;
         }

         var18 = Math.min(Math.abs(var10000), 0.0D);
         if (var20 < 0.0D) {
            var6 += var18;
            var10000 = var22;
         } else {
            if (var20 > 0.0D) {
               var6 -= var18;
            }

            var10000 = var22;
         }

         var18 = Math.min(Math.abs(var10000), var24);
         if (var22 < 0.0D) {
            var8 += var18;
         } else if (var22 > 0.0D) {
            var8 -= var18;
         }

         ++var28;
         field_414.player.connection.sendPacket(new Position(var4, var6, var8, true));
      }

   }

   public static void method_882() {
      if (field_414.player != null && field_414.player.getHeldItemOffhand().getItem() instanceof ItemShield) {
         field_414.player.connection.sendPacket(new CPacketPlayerDigging(Action.RELEASE_USE_ITEM, new BlockPos(field_414.player), EnumFacing.getFacingFromVector((float)((int)field_414.player.posX), (float)((int)field_414.player.posY), (float)((int)field_414.player.posZ))));
      }

   }

   public static double[] method_883(double var0) {
      return method_869(field_414.player, var0);
   }

   public static void method_884(double var0) {
      if (field_414.player.getRidingEntity() != null) {
         MovementInput var10000 = field_414.player.movementInput;
         double var3 = (double)var10000.moveForward;
         double var5 = (double)var10000.moveStrafe;
         float var2 = field_414.player.rotationYaw;
         if (var3 == 0.0D && var5 == 0.0D) {
            field_414.player.getRidingEntity().motionX = 0.0D;
            field_414.player.getRidingEntity().motionZ = 0.0D;
            return;
         }

         if (var3 != 0.0D) {
            if (var5 > 0.0D) {
               var2 += (float)(var3 > 0.0D ? -45 : 45);
            } else if (var5 < 0.0D) {
               var2 += (float)(var3 > 0.0D ? 45 : -45);
            }

            var5 = 0.0D;
            if (var3 > 0.0D) {
               var3 = 1.0D;
            } else if (var3 < 0.0D) {
               var3 = 0.0D;
            }
         }

         field_414.player.getRidingEntity().motionX = var3 * var0 * Math.cos(Math.toRadians((double)(var2 + 90.0F))) + var5 * var0 * Math.sin(Math.toRadians((double)(var2 + 90.0F)));
         field_414.player.getRidingEntity().motionZ = var3 * var0 * Math.sin(Math.toRadians((double)(var2 + 90.0F))) - var5 * var0 * Math.cos(Math.toRadians((double)(var2 + 90.0F)));
      }

   }

   private static int method_885(Entity var0) {
      int var1 = 16777215;
      ScorePlayerTeam var2;
      String var3;
      if ((var2 = (ScorePlayerTeam)var0.getTeam()) != null && (var3 = FontRenderer.getFormatFromString(var2.getPrefix())).length() >= 2) {
         var1 = field_414.fontRenderer.getColorCode(var3.charAt(1));
      }

      return var1;
   }

   public static boolean method_886(Entity var0) {
      return !var0.isDead && (!(var0 instanceof EntityLivingBase) || Float.isNaN(((EntityLivingBase)var0).getHealth()) || ((EntityLivingBase)var0).getHealth() > 0.0F);
   }

   public static EnumHand method_887(Item var0) {
      EnumHand[] var1;
      int var2 = (var1 = EnumHand.values()).length;

      int var3;
      for(int var10000 = var3 = 0; var10000 < var2; var10000 = var3) {
         EnumHand var4 = var1[var3];
         if (var0.equals(field_414.player.getHeldItem(var4).getItem())) {
            return var4;
         }

         ++var3;
      }

      return null;
   }

   public static void method_888() {
      int var0;
      for(int var10000 = var0 = 0; var10000 < 81; var10000 = var0) {
         field_414.player.connection.sendPacket(new Position(field_414.player.posX, field_414.player.posY + 1.273197475E-314D, field_414.player.posZ, false));
         ++var0;
         field_414.player.connection.sendPacket(new Position(field_414.player.posX, field_414.player.posY, field_414.player.posZ, false));
      }

   }

   public static boolean method_889(Entity var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.posX != var0.lastTickPosX || var0.posY != var0.lastTickPosY || var0.posZ != var0.lastTickPosZ || method_852();
   }

   public static boolean method_890() {
      return (double)field_414.player.moveForward != 0.0D || (double)field_414.player.moveStrafing != 0.0D;
   }

   public static String method_891() {
      // $FF: Couldn't be decompiled
   }
}

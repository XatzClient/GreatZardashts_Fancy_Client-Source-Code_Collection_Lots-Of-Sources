package net.futureclient.client;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.inventory.ClickType;

public class Ea extends ja {
   public final fa field_374;

   public Ea(fa var1) {
      this.field_374 = var1;
   }

   public void method_4312(CD var1) {
      this.method_769((Ff)var1);
   }

   public void method_769(Ff var1) {
      if (fa.method_3196(this.field_374).method_817(100L)) {
         if (fI.f$c(1.0D).getBlock().equals(var1.method_2796()) && (Boolean)fa.method_3194(this.field_374).method_3690() && fa.method_4270().player.onGround) {
            --fa.method_4267().player.motionY;
         }

         IBlockState var2 = fa.method_4273().world.getBlockState(var1.method_3153());
         if (fa.method_3195(this.field_374).method_3692().floatValue() > 0.0F && var2.getMaterial() != Material.AIR) {
            var1.method_3094(var1.method_3117() + var2.getPlayerRelativeBlockHardness(fa.method_4276().player, fa.method_4274().world, var1.method_3153()) * fa.method_3195(this.field_374).method_3692().floatValue());
            if (fa.method_3200(this.field_374).method_811(fa.method_3199(this.field_374).method_3692().floatValue() * 1000.0F)) {
               var1.method_2353(0);
            }
         }

         if ((Boolean)fa.method_3198(this.field_374).method_3690()) {
            int var3;
            if ((var3 = EI.method_853(var2)) == -1) {
               return;
            }

            if (var3 < 9) {
               fa.method_4245().player.inventory.currentItem = var3;
               ((l)fa.method_4281().playerController).invokeSyncCurrentPlayItem();
               return;
            }

            fa.method_4315().playerController.windowClick(0, var3, fa.method_4242().player.inventory.currentItem, ClickType.SWAP, fa.method_4269().player);
         }

      }
   }
}

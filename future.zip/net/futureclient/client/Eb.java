package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;

public class Eb extends ja {
   public final md field_393;

   public Eb(md var1) {
      this.field_393 = var1;
   }

   public void method_4241(je var1) {
      if (var1.method_3084() instanceof PositionRotation) {
         PositionRotation var2 = (PositionRotation)var1.method_3084();
         if (md.method_2464(this.field_393) != null) {
            ((e)var2).setYaw(md.method_2464(this.field_393));
            md.method_2462(this.field_393, (Float)null);
         }

         if (md.method_2465(this.field_393) != null) {
            ((e)var2).setPitch(md.method_2465(this.field_393));
            md.method_2466(this.field_393, (Float)null);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }
}

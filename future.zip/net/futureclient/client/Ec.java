package net.futureclient.client;

import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumHand;

public class Ec extends ka {
   private t field_382;
   private t field_383;
   private U field_384;
   private EG field_385;
   private t field_386;
   private Entity field_387;
   private t field_388;
   private t field_389;
   private ga field_390;
   private t field_391;

   public static t method_774(Ec var0) {
      return var0.field_388;
   }

   public void method_4314() {
      super.method_4314();
      this.field_387 = null;
      this.field_385.method_814();
   }

   public static t method_776(Ec var0) {
      return var0.field_389;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static t method_778(Ec var0) {
      return var0.field_383;
   }

   public static U method_779(Ec var0) {
      return var0.field_384;
   }

   public static EG method_780(Ec var0) {
      return var0.field_385;
   }

   public static Entity method_781(Ec var0) {
      return var0.field_387;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   private void method_783(Entity var1) {
      boolean var2 = f$e.player.isActiveItemStackBlocking();
      boolean var3 = f$e.player.isSneaking();
      boolean var4 = f$e.player.isSprinting();
      if (var2) {
         EI.method_882();
      }

      if (var3) {
         f$e.player.connection.sendPacket(new CPacketEntityAction(f$e.player, Action.STOP_SNEAKING));
      }

      if (var4) {
         f$e.player.connection.sendPacket(new CPacketEntityAction(f$e.player, Action.STOP_SPRINTING));
      }

      Entity var5;
      if ((var5 = (new Ah(var1, Uh.Legs)).f$c()) != this.field_387) {
         var1 = var5;
      }

      f$e.playerController.interactWithEntity(f$e.player, var1, EnumHand.MAIN_HAND);
      if (var2) {
         EI.method_847();
      }

      if (var3) {
         f$e.player.connection.sendPacket(new CPacketEntityAction(f$e.player, Action.START_SNEAKING));
      }

      if (var4) {
         f$e.player.connection.sendPacket(new CPacketEntityAction(f$e.player, Action.START_SPRINTING));
      }

   }

   private boolean method_1748(Entity var1) {
      if (var1 == null) {
         return false;
      } else if (!var1.isEntityAlive()) {
         return false;
      } else if (var1 instanceof EntityAgeable && ((EntityAgeable)var1).isChild()) {
         return false;
      } else {
         KD var2 = (KD)YH.method_1211().method_1205().method_2166(KD.class);
         if (f$e.player.getDistance(var1) > var2.field_126.method_3692().floatValue()) {
            return false;
         } else if (!f$e.player.canEntityBeSeen(var1) && !(Boolean)var2.field_137.method_3690()) {
            return false;
         } else if (!ri.method_3660(var1, var2.field_124.method_3692().floatValue(), Uh.Legs)) {
            return false;
         } else if (var1.getPassengers().contains(f$e.player)) {
            return false;
         } else if (Objects.equals(var1.getControllingPassenger(), f$e.player)) {
            return false;
         } else if (var1 instanceof EntityBoat) {
            switch(ZA.f$e[((WA)this.field_390.method_3690()).ordinal()]) {
            case 1:
               boolean var10001 = false;
               return true;
            case 2:
               if (var1.getPassengers().size() == 1 && var1.getControllingPassenger() != null) {
                  return true;
               }

               return false;
            case 3:
               if (var1.getPassengers().size() == 1 && var1.getControllingPassenger() != null) {
                  if ((Boolean)var2.field_131.method_3690() && !YH.method_1211().method_1216().method_1481(var1.getControllingPassenger().getName())) {
                     return false;
                  }

                  return true;
               }
            default:
               return false;
            }
         } else {
            return true;
         }
      }
   }

   public static t method_785(Ec var0) {
      return var0.field_382;
   }

   public static void method_786(Ec var0, Entity var1) {
      var0.method_783(var1);
   }

   public static Entity method_787(Ec var0, Entity var1) {
      return var0.field_387 = var1;
   }

   public static boolean method_788(Ec var0, Entity var1) {
      return var0.method_1748(var1);
   }

   public static t method_789(Ec var0) {
      return var0.field_391;
   }

   public static t method_790(Ec var0) {
      return var0.field_386;
   }

   public Ec() {
      String[] var10002 = new String[5];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoMount";
      var10002[1] = "RideableAura";
      var10002[2] = "RidableAura";
      var10002[3] = "BoatAura";
      var10002[4] = "B0atAura";
      super("AutoMount", var10002, true, -39424, bE.MISCELLANEOUS);
      this.field_385 = new EG();
      this.field_387 = null;
      WA var3 = WA.None;
      String[] var6 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Require";
      var6[1] = "Requirement";
      this.field_390 = new ga(var3, var6);
      Float var4 = 0.5F;
      Float var7 = 0.0F;
      Float var8 = 10.0F;
      String[] var10 = new String[2];
      boolean var10007 = true;
      byte var10008 = 1;
      var10[0] = "Delay";
      var10[1] = "D";
      this.field_384 = new U(var4, var7, var8, var10);
      Boolean var5 = true;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Boat";
      var6[1] = "Boats";
      var6[2] = "Boaty";
      var6[3] = "b";
      this.field_389 = new t(var5, var6);
      var5 = true;
      var6 = new String[5];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Horse";
      var6[1] = "Horses";
      var6[2] = "Horseys";
      var6[3] = "Hors";
      var6[4] = "h";
      this.field_386 = new t(var5, var6);
      var5 = true;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "SkeletonHorse";
      var6[1] = "SkeletonHorses";
      var6[2] = "Skellies";
      var6[3] = "s";
      this.field_388 = new t(var5, var6);
      var5 = true;
      var6 = new String[7];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Donkey";
      var6[1] = "Donkeys";
      var6[2] = "Donker";
      var6[3] = "Donkers";
      var6[4] = "Donk";
      var6[5] = "Donkeh";
      var6[6] = "d";
      this.field_391 = new t(var5, var6);
      var5 = true;
      var6 = new String[7];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Llama";
      var6[1] = "Llamas";
      var6[2] = "Lamas";
      var6[3] = "Lama";
      var6[4] = "Laama";
      var6[5] = "Laamas";
      var6[6] = "l";
      this.field_383 = new t(var5, var6);
      var5 = true;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Pig";
      var6[1] = "Pigs";
      var6[2] = "Piggo";
      var6[3] = "p";
      this.field_382 = new t(var5, var6);
      t[] var10001 = new t[8];
      boolean var2 = true;
      byte var9 = 1;
      var10001[0] = this.field_390;
      var10001[1] = this.field_389;
      var10001[2] = this.field_386;
      var10001[3] = this.field_388;
      var10001[4] = this.field_391;
      var10001[5] = this.field_382;
      var10001[6] = this.field_383;
      var10001[7] = this.field_384;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var9 = 1;
      var1[0] = new fC(this);
      var1[1] = new Bd(this);
      this.method_2383(var1);
   }
}

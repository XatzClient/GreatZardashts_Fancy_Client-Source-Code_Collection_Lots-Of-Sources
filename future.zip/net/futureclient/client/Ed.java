package net.futureclient.client;

import java.util.Map;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.entity.player.EntityPlayer;

public class Ed extends ja {
   public final mb field_368;

   public Ed(mb var1) {
      this.field_368 = var1;
   }

   public void method_4312(CD var1) {
      this.method_761((gD)var1);
   }

   public void method_761(gD var1) {
      if (var1.f$c() instanceof EntityPlayer) {
         EntityPlayer var2 = (EntityPlayer)var1.f$c();
         if (var1.method_3272() instanceof ModelBiped) {
            ModelBiped var3 = (ModelBiped)var1.method_3272();
            Map var10000 = mb.method_2490(this.field_368);
            float[][] var10002 = new float[5][];
            boolean var10003 = true;
            byte var10004 = 1;
            float[] var4 = new float[3];
            boolean var10005 = true;
            byte var10006 = 1;
            var4[0] = var3.bipedHead.rotateAngleX;
            var4[1] = var3.bipedHead.rotateAngleY;
            var4[2] = var3.bipedHead.rotateAngleZ;
            var10002[0] = var4;
            var4 = new float[3];
            var10005 = true;
            var10006 = 1;
            var4[0] = var3.bipedRightArm.rotateAngleX;
            var4[1] = var3.bipedRightArm.rotateAngleY;
            var4[2] = var3.bipedRightArm.rotateAngleZ;
            var10002[1] = var4;
            var4 = new float[3];
            var10005 = true;
            var10006 = 1;
            var4[0] = var3.bipedLeftArm.rotateAngleX;
            var4[1] = var3.bipedLeftArm.rotateAngleY;
            var4[2] = var3.bipedLeftArm.rotateAngleZ;
            var10002[2] = var4;
            float[] var5 = new float[3];
            boolean var6 = true;
            byte var10007 = 1;
            var5[0] = var3.bipedRightLeg.rotateAngleX;
            var5[1] = var3.bipedRightLeg.rotateAngleY;
            var5[2] = var3.bipedRightLeg.rotateAngleZ;
            var10002[3] = var5;
            var5 = new float[3];
            var6 = true;
            var10007 = 1;
            var5[0] = var3.bipedLeftLeg.rotateAngleX;
            var5[1] = var3.bipedLeftLeg.rotateAngleY;
            var5[2] = var3.bipedLeftLeg.rotateAngleZ;
            var10002[4] = var5;
            var10000.put(var2, var10002);
         }
      }

   }
}

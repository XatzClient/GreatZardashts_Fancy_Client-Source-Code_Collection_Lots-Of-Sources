package net.futureclient.client;

public class Ee extends ja {
   public final OD field_367;

   public Ee(OD var1) {
      this.field_367 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4193((ae)var1);
   }

   public void method_4193(ae var1) {
      this.field_367.field_261.clear();
      OD.method_558(this.field_367, !OD.method_4245().isSingleplayer() && OD.method_4281().getCurrentServerData() != null && OD.method_4242().getCurrentServerData().serverIP.toLowerCase().contains("hypixel"));
      OD.method_564(this.field_367, !OD.method_4269().isSingleplayer() && OD.method_4315().getCurrentServerData() != null && OD.method_4319().getCurrentServerData().serverIP.toLowerCase().contains("mineplex"));
   }
}

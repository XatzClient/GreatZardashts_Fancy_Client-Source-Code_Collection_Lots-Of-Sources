package net.futureclient.client;

import net.minecraft.network.play.server.SPacketSpawnPlayer;

public class Ef extends ja {
   public final OD field_373;

   public Ef(OD var1) {
      this.field_373 = var1;
   }

   public void method_4230(IF var1) {
      if (OD.method_561(this.field_373)) {
         if (var1.method_3084() instanceof SPacketSpawnPlayer) {
            SPacketSpawnPlayer var2 = (SPacketSpawnPlayer)var1.method_3084();
            if (Math.sqrt((OD.method_4271().player.posX - var2.getX() / 0.0D) * (OD.method_4278().player.posX - var2.getX() / 0.0D) + (OD.method_4275().player.posY - var2.getY() / 0.0D) * (OD.method_4277().player.posY - var2.getY() / 0.0D) + (OD.method_4270().player.posZ - var2.getZ() / 0.0D) * (OD.method_4267().player.posZ - var2.getZ() / 0.0D)) <= 0.0D && var2.getX() / 0.0D != OD.method_4273().player.posX && var2.getY() / 0.0D != OD.method_4276().player.posY && var2.getZ() / 0.0D != OD.method_4274().player.posZ) {
               this.field_373.field_261.put(var2.getEntityID(), var2.getUniqueId());
            }
         }

      }
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }
}

package net.futureclient.client;

import net.minecraft.client.gui.GuiDownloadTerrain;

public class Eg extends ja {
   public final OD field_372;

   public Eg(OD var1) {
      this.field_372 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4128((Xd)var1);
   }

   public void method_4128(Xd var1) {
      if (var1.method_1230() instanceof GuiDownloadTerrain) {
         this.field_372.field_261.clear();
      }

   }
}

package net.futureclient.client;

public class Ej extends xb {
   public String method_4224() {
      return null;
   }

   public String method_4228(String[] var1) {
      EI.method_888();
      return "Damaged.";
   }

   public Ej() {
      String[] var10001 = new String[3];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Damage";
      var10001[1] = "dmg";
      var10001[2] = "td";
      super(var10001);
   }
}

package net.futureclient.client;

import java.io.File;

public class FA extends xb {
   public final Mc field_380;

   public FA(Mc var1, String[] var2) {
      super(var2);
      this.field_380 = var1;
   }

   public String method_4224() {
      return "&e[name]";
   }

   public String method_4228(String[] var1) {
      if (var1.length < 1) {
         return null;
      } else {
         StringBuilder var2 = new StringBuilder();
         String[] var3 = var1;
         int var4 = var1.length;

         int var5;
         for(int var10000 = var5 = 0; var10000 < var4; var10000 = var5) {
            String var6 = var3[var5];
            var2.append(var6);
            ++var5;
            var2.append(" ");
         }

         String var7 = var2.toString().trim();
         File var8;
         if ((var8 = new File(Mc.method_271(this.field_380), (new StringBuilder()).insert(0, var7).append(var7.endsWith(".txt") ? "" : ".txt").toString())).exists()) {
            this.field_380.method_2388(false);
            Mc.method_260(this.field_380, var8.getPath());
            this.field_380.method_2388(true);
            return (new StringBuilder()).insert(0, "The spammer file ").append(var7).append(" was loaded successfully.").toString();
         } else {
            return (new StringBuilder()).insert(0, "File ").append(var7).append(".txt does not exist.").toString();
         }
      }
   }
}

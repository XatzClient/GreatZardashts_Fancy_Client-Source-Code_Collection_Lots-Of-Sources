package net.futureclient.client;

public enum FB {
   AAC;

   private static final FB[] field_376;
   Packet,
   Bucket,
   Anti;

   static {
      FB[] var10000 = new FB[4];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Packet;
      var10000[1] = Anti;
      var10000[2] = AAC;
      var10000[3] = Bucket;
      field_376 = var10000;
   }
}

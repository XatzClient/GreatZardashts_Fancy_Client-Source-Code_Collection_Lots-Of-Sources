package net.futureclient.client;

import java.util.Collection;
import java.util.stream.Collectors;
import net.minecraft.client.audio.SoundEventAccessor;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;

public class FC extends ja {
   public final Lb field_392;

   public FC(Lb var1) {
      this.field_392 = var1;
   }

   private static boolean method_791(IA var0, IA var1) {
      return var1.f$c().equals(var0.f$c());
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if ((Boolean)Lb.method_408(this.field_392).method_3690()) {
         if (var1.method_3084() instanceof SPacketSoundEffect) {
            SPacketSoundEffect var2;
            ResourceLocation var3 = (var2 = (SPacketSoundEffect)var1.method_3084()).getSound().getSoundName();
            SoundEventAccessor var5;
            if ((var5 = Lb.method_4319().getSoundHandler().getAccessor(var3)) != null && var5.getSubtitle() != null) {
               String var6 = var5.getSubtitle().getUnformattedText();
               IA var4 = new IA(var6, new Vec3d(var2.getX(), var2.getY(), var2.getZ()), System.currentTimeMillis());
               Lb.method_358(this.field_392).removeAll((Collection)Lb.method_358(this.field_392).stream().filter(var4.test<invokedynamic>(var4)).collect(Collectors.toList()));
               Lb.method_358(this.field_392).add(var4);
            }
         }

      }
   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.EnumHand;

public class FD extends ja {
   public final jf field_381;

   public FD(jf var1) {
      this.field_381 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      if (jf.method_2112(this.field_381).player.onGround) {
         gE var2;
         gE var10000 = var2 = (gE)YH.method_1211().method_1205().method_2166(gE.class);
         jf.method_2111(this.field_381).player.connection.sendPacket(new Rotation(jf.method_2117(this.field_381).player.rotationYaw, -90.0F, true));
         FD var3;
         if (var10000 != null && (Boolean)var2.field_1304.method_3690()) {
            var3 = this;
            jf.method_2116(this.field_381).player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
         } else {
            var3 = this;
            jf.method_2113(this.field_381).player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
         }

         jf.method_2115(var3.field_381).player.jump();
      }

      YH.method_1211().method_1212().method_1334(this);
   }
}

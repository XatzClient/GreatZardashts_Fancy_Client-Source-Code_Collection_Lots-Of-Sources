package net.futureclient.client;

public enum FE {
   Left,
   Right;

   private static final FE[] field_371;

   static {
      FE[] var10000 = new FE[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Right;
      var10000[1] = Left;
      field_371 = var10000;
   }
}

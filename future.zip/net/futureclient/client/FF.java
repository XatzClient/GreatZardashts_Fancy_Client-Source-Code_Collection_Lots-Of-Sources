package net.futureclient.client;

public class FF extends CD {
}

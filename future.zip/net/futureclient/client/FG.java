package net.futureclient.client;

import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.WorldClient;

public class FG extends xb {
   public String method_4228(String[] var1) {
      if (var1.length == 1) {
         ServerData var2 = new ServerData("", var1[0], false);
         this.field_1834.world.sendQuittingDisconnectingPacket();
         this.field_1834.loadWorld((WorldClient)null);
         this.field_1834.displayGuiScreen(new GuiConnecting(new GuiMultiplayer(new GuiMainMenu()), this.field_1834, var2));
         return Fi.f$c("0z\u001d{\u0016v\u0007|\u001dr];]");
      } else {
         return null;
      }
   }

   public String method_4224() {
      return "&e[ip]";
   }

   public FG() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Connect";
      var10001[1] = "c";
      super(var10001);
   }
}

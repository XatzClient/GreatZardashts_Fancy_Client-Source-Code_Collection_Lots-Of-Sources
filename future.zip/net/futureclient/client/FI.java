package net.futureclient.client;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class FI extends DataInputStream {
   private bH field_394;

   public FI(InputStream var1, String var2) {
      super(var1);
      this.field_394 = new bH(var2);
   }

   public FI(InputStream var1) {
      super(var1);
   }

   public byte[] method_796(byte[] var1) throws IOException, DataFormatException {
      Inflater var2;
      (var2 = new Inflater()).setInput(var1);
      ByteArrayOutputStream var5 = new ByteArrayOutputStream(var1.length);
      byte[] var10000 = new byte[1024];
      boolean var10001 = true;
      byte var10002 = 1;
      byte[] var3 = var10000;
      Inflater var6 = var2;

      while(!var6.finished()) {
         var6 = var2;
         int var4 = var2.inflate(var3);
         var5.write(var3, 0, var4);
      }

      var5.close();
      return var5.toByteArray();
   }

   public static String method_797(String var0) {
      StackTraceElement var10003 = (new RuntimeException()).getStackTrace()[1];
      String var10000 = (new StringBuffer(var10003.getMethodName())).insert(0, var10003.getClassName()).toString();
      int var10001 = var10000.length() - 1;
      float var10 = 1.0F;
      boolean var11 = true;
      boolean var10004 = true;
      byte var12 = 8;
      var10004 = true;
      var10004 = true;
      byte var10005 = 4;
      byte var14 = 64;
      boolean var15 = true;
      boolean var10006 = true;
      var10005 = 6;
      var15 = true;
      var10006 = true;
      var10005 = 16;
      var10006 = true;
      boolean var10007 = true;
      byte var17 = 7;
      int var18 = (var0 = (String)var0).length();
      char[] var19 = new char[var18];
      boolean var10008 = true;
      byte var10009 = 1;
      int var1;
      int var16 = var1 = var18 - 1;
      char[] var3 = var19;
      byte var7 = 23;
      var14 = 13;
      byte var4 = 70;
      var10 = 2.0F;
      int var2;
      int var5 = var2 = var10001;
      int var8 = var16;

      for(String var6 = var10000; var8 >= 0; var8 = var1) {
         int var13 = var1--;
         var3[var13] = (char)(var4 ^ var0.charAt(var13) ^ var6.charAt(var2));
         if (var1 < 0) {
            break;
         }

         var10001 = var1;
         char var10002 = (char)(var7 ^ var0.charAt(var1) ^ var6.charAt(var2));
         --var1;
         --var2;
         var3[var10001] = var10002;
         if (var2 < 0) {
            var2 = var5;
         }
      }

      return new String(var3);
   }

   public Oi method_798(Class var1) throws IOException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, DataFormatException {
      int var2;
      if ((var2 = this.readInt()) > 2500) {
         System.err.println("Versuch: " + var2);
         throw new IOException("Packet too long: " + var2);
      } else {
         byte[] var10000 = new byte[var2];
         boolean var10001 = true;
         byte var10002 = 1;
         byte[] var3 = var10000;
         this.readFully(var3);
         DataInputStream var11 = new DataInputStream(new ByteArrayInputStream(var3));
         boolean var4 = var11.readBoolean();
         byte[] var14 = new byte[var2 - 1];
         boolean var10003 = true;
         byte var10004 = 1;
         byte[] var6 = var14;
         var11.readFully(var14);
         var6 = this.method_796(var6);
         if (var4) {
            if (this.field_394 == null) {
               throw new IOException("This packet is encrypted");
            }

            bH var9 = this.field_394;
            byte[] var12 = var6;

            try {
               var6 = var9.method_3047(var12);
            } catch (Exception var5) {
               throw new IOException("Wrong password");
            }

            var6 = this.method_796(var6);
         }

         DataInputStream var7 = new DataInputStream(new ByteArrayInputStream(var6));
         var7.readInt();
         Class[] var13 = new Class[0];
         boolean var16 = true;
         byte var17 = 1;
         Constructor var8 = var1.getConstructor(var13);
         var8.setAccessible(true);
         Object[] var15 = new Object[0];
         var16 = true;
         var17 = 1;
         Oi var10 = (Oi)var8.newInstance(var15);
         var10.method_1874(var7);
         return var10;
      }
   }

   public UH method_799() throws IOException, DataFormatException {
      int var1;
      if ((var1 = this.readInt()) > 2500) {
         System.err.println("Versuch: " + var1);
         throw new IOException("Packet too long: " + var1);
      } else {
         byte[] var10000 = new byte[var1];
         boolean var10001 = true;
         byte var10002 = 1;
         byte[] var2 = var10000;
         this.readFully(var2);
         DataInputStream var9 = new DataInputStream(new ByteArrayInputStream(var2));
         boolean var3 = var9.readBoolean();
         byte[] var11 = new byte[var1 - 1];
         boolean var10003 = true;
         byte var10004 = 1;
         byte[] var5 = var11;
         var9.readFully(var11);
         var5 = this.method_796(var5);
         if (var3) {
            if (this.field_394 == null) {
               throw new IOException("This packet is encrypted");
            }

            bH var8 = this.field_394;
            byte[] var10 = var5;

            try {
               var5 = var8.method_3047(var10);
            } catch (Exception var4) {
               throw new IOException("Wrong password");
            }

            var5 = this.method_796(var5);
         }

         DataInputStream var6;
         int var7 = (var6 = new DataInputStream(new ByteArrayInputStream(var5))).readInt();
         return new UH(var7, var6);
      }
   }
}

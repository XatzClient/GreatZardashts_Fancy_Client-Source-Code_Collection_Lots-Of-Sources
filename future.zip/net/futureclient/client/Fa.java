package net.futureclient.client;

import java.util.ArrayList;
import net.minecraft.item.ItemSlab;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;

public class Fa extends ja {
   public final ia field_481;

   public Fa(ia var1) {
      this.field_481 = var1;
   }

   public void method_4147(Lf var1) {
      if ((Boolean)ia.method_2194(this.field_481).method_3690() && ia.method_2193(this.field_481).method_817(150L) && ia.method_3767().player.onGround) {
         ia.method_4296().player.motionX = ia.method_4301().player.motionZ = 0.0D;
         ia.method_2193(this.field_481).method_814();
      }

      switch(da.f$e[var1.method_326().ordinal()]) {
      case 1:
         boolean var10001 = false;
         int var2 = ia.method_2198(this.field_481);
         this.field_481.field_945 = null;
         this.field_481.field_954 = -1;
         if (!ia.method_4288().player.isSneaking() && var2 != -1) {
            double var17 = Math.cos(Math.toRadians((double)(ia.method_4291().player.rotationYaw + 90.0F)));
            double var18 = Math.sin(Math.toRadians((double)(ia.method_4292().player.rotationYaw + 90.0F)));
            double var9 = (double)ia.method_4298().player.movementInput.moveForward * 1.273197475E-314D * var17 + (double)ia.method_4294().player.movementInput.moveStrafe * 1.273197475E-314D * var18;
            double var13 = (double)ia.method_4300().player.movementInput.moveForward * 1.273197475E-314D * var18 - (double)ia.method_4299().player.movementInput.moveStrafe * 1.273197475E-314D * var17;
            ia.method_2199(this.field_481, !((Ha)ia.method_2197(this.field_481).method_3690()).equals(Ha.Hypixel));
            var9 = ia.method_4297().player.posX + (ia.method_2209(this.field_481) ? var9 : 0.0D);
            double var15 = ia.method_4285().player.posY - (ia.method_4284().player.inventory.getStackInSlot(var2).getItem() instanceof ItemSlab ? 0.0D : 1.0D);
            var13 = ia.method_4286().player.posZ + (ia.method_2209(this.field_481) ? var13 : 0.0D);
            BlockPos var11 = new BlockPos(var9, var15, var13);
            Va var12;
            if ((var12 = (Va)YH.method_1211().method_1205().method_2166(Va.class)) != null && var12.f$c()) {
               ArrayList var8 = new ArrayList();
               BlockPos var20 = new BlockPos(ia.method_4293().player.getPositionVector());
               var8.add(var20.add(7.957484216E-315D * var17 + 0.0D * var18, 0.0D, 7.957484216E-315D * var18 - 0.0D * var17));
               var8.add(var20.add(0.0D * var17 + 0.0D * var18, 0.0D, 0.0D * var18 - 0.0D * var17));
               var8.add(var20.add(0.0D * var17 + 0.0D * var18, 1.0D, 0.0D * var18 - 0.0D * var17));
               var8.add(var20.add(7.957484216E-315D * var17 - 7.957484216E-315D * var18, 0.0D, 7.957484216E-315D * var18 + 7.957484216E-315D * var17));
               var8.add(var20.add(7.957484216E-315D * var17 - 7.957484216E-315D * var18, 1.0D, 7.957484216E-315D * var18 + 7.957484216E-315D * var17));
               var8.add(var20.add(7.957484216E-315D * var17 + 7.957484216E-315D * var18, 0.0D, 7.957484216E-315D * var18 - 7.957484216E-315D * var17));
               var8.add(var20.add(7.957484216E-315D * var17 + 7.957484216E-315D * var18, 1.0D, 7.957484216E-315D * var18 - 7.957484216E-315D * var17));
               var11 = (BlockPos)var8.stream().filter(this.test<invokedynamic>(this)).findFirst().orElse(var11);
            }

            if (ia.method_4287().world.getBlockState(var11).getMaterial().isReplaceable()) {
               this.field_481.field_945 = ia.method_2206(this.field_481, var11);
               this.field_481.field_954 = var2;
               if (this.field_481.field_945 != null) {
                  float[] var19 = ri.method_3668(this.field_481.field_945.field_520, this.field_481.field_945.field_521);
                  var1.method_2096(ia.method_2191(this.field_481, var19[0]));
                  var1.method_3094(ia.method_2203(this.field_481, ri.method_3666(var19[1])));
                  return;
               }
            } else if (!ia.method_2204(this.field_481).method_811(ia.method_2208(this.field_481).method_3692().floatValue() * 5.0F)) {
               var1.method_2096(ia.method_2192(this.field_481));
               var1.method_3094(ia.method_2200(this.field_481));
               return;
            }
         }
         break;
      case 2:
         if (this.field_481.field_945 != null && ia.method_2204(this.field_481).method_811(ia.method_2208(this.field_481).method_3692().floatValue()) && this.field_481.field_954 != -1) {
            RayTraceResult var3 = Ah.f$c(ia.method_2200(this.field_481), ia.method_2192(this.field_481));
            if ((Boolean)ia.method_2202(this.field_481).method_3690()) {
               ((w)ia.method_4250()).setRightClickDelayTimer(3);
               if (ia.method_4295().player.movementInput.jump && !EI.method_890()) {
                  ((w)ia.method_4282()).setRightClickDelayTimer(0);
                  ia.method_4290().player.jump();
                  var1.method_4038(0.0D);
               }
            }

            boolean var4 = ia.method_4272().player.inventory.currentItem != this.field_481.field_954;
            boolean var5 = ia.method_4244().player.isSprinting();
            int var6 = ia.method_4289().player.inventory.currentItem;
            boolean var7 = !fI.f$c(this.field_481.field_945.field_520);
            if (var4) {
               ia.method_4283().player.inventory.currentItem = this.field_481.field_954;
               ia.method_4243().player.connection.sendPacket(new CPacketHeldItemChange(this.field_481.field_954));
            }

            if (var5) {
               ia.method_4279().player.connection.sendPacket(new CPacketEntityAction(ia.method_4280().player, Action.STOP_SPRINTING));
            }

            if (var7) {
               ia.method_4278().player.connection.sendPacket(new CPacketEntityAction(ia.method_4271().player, Action.START_SNEAKING));
            }

            ia.method_4270().playerController.processRightClickBlock(ia.method_4275().player, ia.method_4277().world, this.field_481.field_945.field_520, this.field_481.field_945.field_521, var3.hitVec, EnumHand.MAIN_HAND);
            ia.method_4267().player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
            if (var7) {
               ia.method_4276().player.connection.sendPacket(new CPacketEntityAction(ia.method_4273().player, Action.STOP_SNEAKING));
            }

            if (var5) {
               ia.method_4245().player.connection.sendPacket(new CPacketEntityAction(ia.method_4274().player, Action.START_SPRINTING));
            }

            if (var4) {
               ia.method_4281().player.inventory.currentItem = var6;
               ia.method_4269().player.connection.sendPacket(new CPacketHeldItemChange(ia.method_4242().player.inventory.currentItem));
            }

            ia.method_2204(this.field_481).method_814();
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   private boolean method_1096(BlockPos var1) {
      return ia.method_2207(this.field_481).contains(ia.method_4315().world.getBlockState(var1).getBlock());
   }
}

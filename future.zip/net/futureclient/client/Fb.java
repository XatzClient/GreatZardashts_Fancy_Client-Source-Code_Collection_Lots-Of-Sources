package net.futureclient.client;

public class Fb extends ja {
   public final ec field_480;

   public Fb(ec var1) {
      this.field_480 = var1;
   }

   private static void method_1091(hf param0, tG param1) {
      // $FF: Couldn't be decompiled
   }

   public void method_4312(CD var1) {
      this.method_4001((hf)var1);
   }

   public void method_4001(hf var1) {
      if (ec.method_3363(this.field_480).method_3690() != null) {
         if (ec.method_3363(this.field_480).method_3690() != tG.AutoDetect) {
            tG var2 = (tG)ec.method_3363(this.field_480).method_3690();
            tG[] var3;
            int var4 = (var3 = tG.values()).length;

            int var5;
            for(int var10000 = var5 = 0; var10000 < var4; var10000 = var5) {
               tG var6;
               if ((var6 = var3[var5]).name().replaceAll("_", " ").equalsIgnoreCase(((tG)ec.method_3363(this.field_480).method_3690()).toString())) {
                  var2 = var6;
               }

               ++var5;
            }

            if (var2 != null && !var1.f$c() && !var1.method_3453().startsWith("/") && !var1.method_3453().startsWith(YH.method_1211().method_1213().method_2260())) {
               var1.f$c(true);
               (new Thread(var1.run<invokedynamic>(var1, var2))).start();
            }
         }

      }
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayer;

public class Fc extends ja {
   public final Zc field_483;

   public Fc(Zc var1) {
      this.field_483 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }

   public void method_4241(je var1) {
      switch(cd.f$e[((oA)Zc.method_1133(this.field_483).method_3690()).ordinal()]) {
      case 4:
         Minecraft var10000 = Zc.method_4267();
         boolean var10001 = false;
         if (var10000.player.fallDistance > 3.8F && var1.method_3084() instanceof CPacketPlayer) {
            ((e)((CPacketPlayer)var1.method_3084())).setOnGround(true);
            Zc.method_4273().player.fallDistance = 0.0F;
            return;
         }
         break;
      case 5:
         if (var1.method_3084() instanceof CPacketPlayer) {
            CPacketPlayer var2 = (CPacketPlayer)var1.method_3084();
            if ((Boolean)Zc.method_1129(this.field_483).method_3690()) {
               ((e)var2).setOnGround(false);
            }
         }
      }

   }
}

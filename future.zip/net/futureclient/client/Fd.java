package net.futureclient.client;

public class Fd extends ka {
   private final t field_482;

   public static t method_1099(Fd var0) {
      return var0.field_482;
   }

   public Fd() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "XCarry";
      var10002[1] = "MoreCarry";
      var10002[2] = "MoreInventory";
      var10002[3] = "MoreInv";
      super("XCarry", var10002, true, -4191950, bE.MISCELLANEOUS);
      Boolean var3 = false;
      String[] var5 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "ForceCancel";
      var5[1] = "Force";
      this.field_482 = new t(var3, var5);
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_482;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var4 = 1;
      var1[0] = new QB(this);
      var1[1] = new sA(this);
      this.method_2383(var1);
   }
}

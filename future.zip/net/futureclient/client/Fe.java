package net.futureclient.client;

public class Fe extends ja {
   public final aD field_470;

   public Fe(aD var1) {
      this.field_470 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      if (var1.method_326().equals(HD.PRE)) {
         aD.method_1417(this.field_470, 0.0F);
         aD.method_1398(this.field_470, aD.method_4281().player.rotationPitch);
         Fe var10000;
         boolean var10001;
         switch(sD.f$G[((AE)aD.method_1400(this.field_470).method_3690()).ordinal()]) {
         case 1:
            var10000 = this;
            var10001 = false;
            aD.method_1398(this.field_470, 85.0F);
            break;
         case 2:
            var10000 = this;
            aD.method_1398(this.field_470, 90.0F);
            break;
         case 3:
            var10000 = this;
            aD.method_1398(this.field_470, 1.132245E7F);
            break;
         case 4:
            var10000 = this;
            aD.method_1398(this.field_470, -90.0F);
            break;
         case 5:
            var10000 = this;
            aD.method_1398(this.field_470, 1.132227E7F);
            break;
         case 6:
            var10000 = this;
            aD.method_1398(this.field_470, 0.0F);
            break;
         case 7:
            var10000 = this;
            aD.method_1398(this.field_470, 1.132236E7F);
            break;
         case 8:
            aD.method_1398(this.field_470, (float)aD.method_1409(this.field_470).nextInt(45) + aD.method_1409(this.field_470).nextFloat());
         default:
            var10000 = this;
         }

         aD.method_1410(var10000.field_470, (int)((float)aD.method_1413(this.field_470) + aD.method_1415(this.field_470).method_3692().floatValue()));
         if (aD.method_1413(this.field_470) >= 360) {
            aD.method_1410(this.field_470, 0);
         }

         aD.method_1411(this.field_470, aD.method_1414(this.field_470) + 15.0F);
         if (aD.method_1414(this.field_470) >= 100.0F) {
            aD.method_1411(this.field_470, 0.0F);
         }

         switch(sD.f$e[((Me)aD.method_1412(this.field_470).method_3690()).ordinal()]) {
         case 1:
            var10001 = false;
            var10000 = this;
            aD.method_1417(this.field_470, (float)aD.method_1413(this.field_470) - aD.method_4242().player.rotationYaw);
            break;
         case 2:
            aD.method_1417(this.field_470, (float)(aD.method_1414(this.field_470) >= 50.0F ? aD.method_1409(this.field_470).nextInt(30) : -aD.method_1409(this.field_470).nextInt(30)));
            var10000 = this;
            break;
         case 3:
            var10000 = this;
            aD.method_1417(this.field_470, 2.14748365E9F);
            break;
         case 4:
            aD.method_1417(this.field_470, -aD.method_4269().player.rotationYaw);
         default:
            var10000 = this;
         }

         if (!((Me)aD.method_1412(var10000.field_470).method_3690()).equals(Me.Overflow)) {
            aD.method_1417(this.field_470, aD.method_1401(this.field_470) + aD.method_4315().player.rotationYaw + (((Me)aD.method_1412(this.field_470).method_3690()).equals(Me.Off) ? 0.0F : 180.0F + aD.method_1402(this.field_470).method_3692().floatValue()));
         }

         if (((Me)aD.method_1412(this.field_470).method_3690()).equals(Me.Flip)) {
            if (aD.method_4319().player.ticksExisted % aD.method_1405(this.field_470).method_3692().intValue() == 0) {
               aD.method_1406(this.field_470, !aD.method_1399(this.field_470));
            }

            if (aD.method_1399(this.field_470)) {
               aD.method_1417(this.field_470, aD.method_1401(this.field_470) + 180.0F);
            }
         }

         if (aD.method_1404(this.field_470)) {
            var1.method_2096(aD.method_1401(this.field_470));
            var1.method_3094(aD.method_1407(this.field_470));
         }

      }
   }
}

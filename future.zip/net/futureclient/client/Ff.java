package net.futureclient.client;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class Ff extends CD {
   private int field_460;
   private float field_461;
   private int field_462;
   private int field_463;
   private EnumFacing field_464;
   public BlockPos field_465;
   private int field_466;

   public Ff(int var1, int var2, int var3, int var4, float var5, EnumFacing var6, BlockPos var7) {
      this.field_463 = var1;
      this.field_460 = var2;
      this.field_462 = var3;
      this.field_466 = var4;
      this.field_461 = var5;
      this.field_464 = var6;
      this.field_465 = var7;
   }

   public int method_1005() {
      return this.field_463;
   }

   public void method_1006(int var1) {
      this.field_463 = var1;
   }

   public void method_1007(int var1) {
      this.field_462 = var1;
   }

   public int method_2350() {
      return this.field_462;
   }

   public int method_3981() {
      return this.field_466;
   }

   public void method_3094(float var1) {
      this.field_461 = var1;
   }

   public void method_1011(EnumFacing var1) {
      this.field_464 = var1;
   }

   public Block method_2796() {
      return Minecraft.getMinecraft().world.getBlockState(this.field_465).getBlock();
   }

   public EnumFacing method_3154() {
      return this.field_464;
   }

   public float method_3117() {
      return this.field_461;
   }

   public void method_2353(int var1) {
      this.field_466 = var1;
   }

   public BlockPos method_3153() {
      return this.field_465;
   }

   public int method_1017() {
      return this.field_460;
   }

   public void method_1018(int var1) {
      this.field_460 = var1;
   }
}

package net.futureclient.client;

import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.input.Mouse;

public class Fg extends ja {
   public final me field_476;

   public Fg(me var1) {
      this.field_476 = var1;
   }

   public void method_4311(yD var1) {
      if (me.method_4267().currentScreen == null && me.method_4273().playerController != null) {
         boolean var2 = false;
         boolean var10000;
         switch(OE.f$e[((sE)me.method_2448(this.field_476).method_3690()).ordinal()]) {
         case 1:
            boolean var10001 = false;
            var10000 = Mouse.isButtonDown(0);
            break;
         case 2:
            var2 = me.method_4276().objectMouseOver != null && me.method_4274().objectMouseOver.entityHit instanceof EntityLivingBase && (!(Boolean)me.method_2440(this.field_476).method_3690() || !me.method_4281().player.isOnSameTeam(me.method_4245().objectMouseOver.entityHit) && (!(Boolean)me.method_2454(this.field_476).method_3690() || !me.method_4242().objectMouseOver.entityHit.isInvisible()) && (!(Boolean)me.method_2443(this.field_476).method_3690() || !YH.method_1211().method_1216().method_1481(me.method_4269().objectMouseOver.entityHit.getName())));
            var10000 = var2;
            break;
         case 3:
            var2 = true;
         default:
            var10000 = var2;
         }

         if (var10000 && (!(Boolean)me.method_2447(this.field_476).method_3690() || EI.method_880()) && me.method_2446(this.field_476).method_815(me.method_2449(this.field_476))) {
            ((w)me.method_4315()).setLeftClickCounter(0);
            ((w)me.method_4319()).method_3640(lf.LEFT_CLICK);
            double var3 = Math.random() * me.method_2444(this.field_476).method_3692().doubleValue() * 0.0D - me.method_2444(this.field_476).method_3692().doubleValue();
            me.method_2452(this.field_476, Math.max(me.method_2451(this.field_476).method_3692().doubleValue() + var3, 0.0D));
            me.method_2446(this.field_476).method_814();
         }

      }
   }

   public void method_4312(CD var1) {
      this.method_4311((yD)var1);
   }
}

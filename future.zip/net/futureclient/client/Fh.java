package net.futureclient.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Fh extends Socket {
   private int field_471;
   private String field_472;
   private static int[] field_473;
   private GG field_474;

   public Fh(String var1, int var2, GG var3) throws UnknownHostException, IOException {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      super();
      this.field_472 = var1;
      this.field_471 = var2;
      this.field_474 = var3;
      this.method_1026(30000);
   }

   public Fh(String var1, int var2) throws UnknownHostException, IOException {
      this.field_472 = var1;
      this.field_471 = var2;
   }

   private void method_1021() throws IOException {
      DataOutputStream var1 = new DataOutputStream(this.getOutputStream());
      DataInputStream var2 = new DataInputStream(this.getInputStream());
      var1.writeByte(4);
      var1.writeByte(1);
      var1.writeShort(this.field_471);
      var1.write(InetAddress.getByName(this.field_472).getAddress());
      DataOutputStream var10000;
      if (this.field_474.method_1002()) {
         var10000 = var1;
         var1.write(this.field_474.method_1004().getBytes());
      } else {
         var10000 = var1;
         var1.writeByte(0);
      }

      var10000.flush();
      byte var4 = var2.readByte();
      byte var3 = var2.readByte();
      if (var4 == 0 && var3 == 90) {
         var2.readShort();
         byte[] var10001 = new byte[4];
         boolean var10002 = true;
         byte var10003 = 1;
         byte[] var5 = var10001;
         var2.read(var5);
      } else {
         throw new SocketException();
      }
   }

   private void method_1022(int var1, DataInputStream var2) throws IOException {
      byte[] var10000;
      boolean var10001;
      byte var10002;
      byte[] var3;
      if (var1 == 1) {
         var10000 = new byte[4];
         var10001 = true;
         var10002 = 1;
         var3 = var10000;
         var2.read(var3);
      } else if (var1 == 3) {
         byte[] var4 = new byte[var2.readByte()];
         boolean var5 = true;
         byte var10003 = 1;
         var2.read(var4);
      } else {
         var10000 = new byte[16];
         var10001 = true;
         var10002 = 1;
         var3 = var10000;
         var2.read(var3);
      }
   }

   private void method_1023() throws IOException {
      DataOutputStream var1 = new DataOutputStream(this.getOutputStream());
      DataInputStream var2 = new DataInputStream(this.getInputStream());
      var1.writeByte(5);
      DataOutputStream var10000;
      if (this.field_474.method_1002()) {
         var10000 = var1;
         var1.writeByte(2);
         var1.writeByte(0);
         var1.writeByte(2);
      } else {
         var10000 = var1;
         var1.writeByte(1);
         var1.writeByte(0);
      }

      var10000.flush();
      var2.readByte();
      if (var2.readByte() == 2) {
         this.method_1027(var1, var2);
      }

      var1.writeByte(5);
      var1.writeByte(1);
      var1.writeByte(0);
      var1.writeByte(3);
      var1.writeByte(this.field_472.length());

      int var3;
      for(int var4 = var3 = 0; var4 < this.field_472.length(); var4 = var3) {
         var1.writeByte(this.field_472.charAt(var3++));
      }

      var1.writeShort(this.field_471);
      var1.flush();
      var2.readByte();
      var2.readByte();
      var2.readByte();
      this.method_1022(var2.readByte(), var2);
      var2.readShort();
   }

   public void method_1024(GG var1, int var2) throws IOException {
      this.connect(new InetSocketAddress(var1.method_1001(), var1.method_1000()), var2);
      switch(method_1025()[var1.method_1003().ordinal()]) {
      case 1:
         boolean var10001 = false;
         this.method_1021();
         return;
      case 2:
         this.method_1023();
      default:
         return;
      case 3:
         this.method_1028();
      }
   }

   public static int[] method_1025() {
      int[] var10000 = field_473;
      if (var10000 != null) {
         return var10000;
      } else {
         var10000 = new int[nG.values().length];
         boolean var10001 = true;
         byte var10002 = 1;
         int[] var0 = var10000;
         var10000 = var0;
         nG var4 = nG.f$G;

         label35: {
            try {
               var10000[var4.ordinal()] = 3;
            } catch (NoSuchFieldError var3) {
               var10000 = var0;
               break label35;
            }

            var10000 = var0;
         }

         var4 = nG.f$M;

         label30: {
            try {
               var10000[var4.ordinal()] = 1;
            } catch (NoSuchFieldError var2) {
               var10000 = var0;
               break label30;
            }

            var10000 = var0;
         }

         var4 = nG.f$E;

         label25: {
            try {
               var10000[var4.ordinal()] = 2;
            } catch (NoSuchFieldError var1) {
               var10000 = var0;
               break label25;
            }

            var10000 = var0;
         }

         field_473 = var10000;
         return var10000;
      }
   }

   public void method_1026(int var1) throws IOException {
      if (this.field_474 == null) {
         throw new IOException("Proxy is null");
      } else {
         this.connect(new InetSocketAddress(this.field_474.method_1001(), this.field_474.method_1000()), var1);
         switch(method_1025()[this.field_474.method_1003().ordinal()]) {
         case 1:
            boolean var10001 = false;
            this.method_1021();
            return;
         case 2:
            this.method_1023();
         default:
            return;
         case 3:
            this.method_1028();
         }
      }
   }

   private void method_1027(DataOutputStream var1, DataInputStream var2) throws IOException {
      int var10000 = 0;
      var1.writeByte(1);
      var1.writeByte(this.field_474.method_1004().length());

      int var3;
      for(var3 = 0; var10000 < this.field_474.method_1004().length(); var10000 = var3) {
         var1.writeByte(this.field_474.method_1004().charAt(var3++));
      }

      var10000 = 0;
      var1.writeByte(this.field_474.method_999().length());

      for(var3 = 0; var10000 < this.field_474.method_999().length(); var10000 = var3) {
         var1.writeByte(this.field_474.method_999().charAt(var3++));
      }

      var1.flush();
      var2.readByte();
      byte var4 = var2.readByte();
      if (var4 != 0) {
         throw new SocketException("Couldn't login: " + var4);
      }
   }

   private void method_1028() throws IOException {
      PrintStream var1;
      PrintStream var10000 = var1 = new PrintStream(this.getOutputStream());
      var10000.println("CONNECT " + this.field_472 + ":" + this.field_471 + " HTTP/1.1");
      var1.println("HOST: " + this.field_472 + ":" + this.field_471);
      var10000.println();
      var10000.flush();
      BufferedReader var5 = new BufferedReader(new InputStreamReader(this.getInputStream()));
      StringBuffer var3 = new StringBuffer();
      BufferedReader var9 = var5;

      String var2;
      StringBuffer var10;
      while(true) {
         if ((var2 = var9.readLine()) == null) {
            var10 = var3;
            break;
         }

         if (var2.length() == 0) {
            var10 = var3;
            break;
         }

         var3.append(var2);
         var9 = var5;
      }

      String[] var6;
      String[] var11 = var6 = var10.toString().split("\n")[0].trim().split(" ");
      var2 = var11[0];
      int var7 = Integer.parseInt(var11[1]);
      String var8 = "";

      int var4;
      for(int var12 = var4 = 2; var12 < var6.length; var12 = var4) {
         var8 = var8 + var6[var4];
         if (var4 != var6.length - 1) {
            var8 = var8 + " ";
         }

         ++var4;
      }

      if (var7 != 200) {
         throw new IOException(var8);
      }
   }
}

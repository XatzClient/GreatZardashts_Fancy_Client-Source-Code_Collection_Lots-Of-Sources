package net.futureclient.client;

public final class Fi {
   public static void method_1103(String param0, String param1, int param2) {
      // $FF: Couldn't be decompiled
   }
}

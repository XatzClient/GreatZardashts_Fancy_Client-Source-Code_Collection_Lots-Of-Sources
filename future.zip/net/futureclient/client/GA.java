package net.futureclient.client;

import net.minecraft.util.text.TextComponentString;
import org.lwjgl.opengl.Display;

public class GA extends ja {
   public final xC field_489;

   public GA(xC var1) {
      this.field_489 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (xC.method_4266(this.field_489) != null && xC.method_4260(this.field_489, xC.method_4266(this.field_489)) < 15.0F) {
         GA var10000;
         if (Display.isActive()) {
            ((aB)YH.method_1211().method_1205().method_2166(aB.class)).method_2388(false);
            ((wB)YH.method_1211().method_1205().method_2166(wB.class)).f$c(false);
            la.method_2324().method_2322("You have reached your destination.");
            var10000 = this;
         } else if (xC.method_4269().getConnection() == null) {
            xC.method_4315().world.sendQuittingDisconnectingPacket();
            var10000 = this;
         } else {
            xC.method_4319().getConnection().getNetworkManager().closeChannel(new TextComponentString("You have reached your destination."));
            var10000 = this;
         }

         xC.method_4259(var10000.field_489, (xa)null);
      }

   }
}

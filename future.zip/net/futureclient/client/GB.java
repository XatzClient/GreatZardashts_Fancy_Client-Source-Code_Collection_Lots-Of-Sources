package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class GB extends ka {
   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public GB() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoRespawn";
      var10002[1] = "NoDeathScreen";
      super("AutoRespawn", var10002, true, -15641191, bE.MISCELLANEOUS);
      ja[] var10001 = new ja[1];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new Wc(this);
      this.method_2383(var10001);
   }
}

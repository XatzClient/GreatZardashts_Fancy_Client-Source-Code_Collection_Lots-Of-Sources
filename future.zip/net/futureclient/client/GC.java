package net.futureclient.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemLingeringPotion;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.util.math.Vec3d;

public class GC extends ka {
   private float field_477;
   private List field_478;
   private float field_479;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static float method_1041(GC var0) {
      return var0.field_477;
   }

   public static float method_1042(GC var0, float var1) {
      return var0.field_477 = var1;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   private Entity method_1044(Vec3d var1, Vec3d var2) {
      Iterator var3 = this.method_1045().iterator();

      while(var3.hasNext()) {
         EntityLivingBase var4;
         if ((var4 = (EntityLivingBase)var3.next()) != f$e.player) {
            double var5 = 1.3262473694E-314D;
            if (var4.getEntityBoundingBox().grow(var5, var5, var5).calculateIntercept(var1, var2) != null) {
               return var4;
            }
         }
      }

      return null;
   }

   private ArrayList method_1045() {
      ArrayList var1 = new ArrayList();
      Iterator var2 = f$e.world.loadedEntityList.iterator();

      while(var2.hasNext()) {
         Entity var3;
         if ((var3 = (Entity)var2.next()) != f$e.player && var3 instanceof EntityLivingBase) {
            var1.add((EntityLivingBase)var3);
         }
      }

      return var1;
   }

   public static float method_1046(GC var0) {
      return var0.field_479;
   }

   public static Entity method_1047(GC var0, Vec3d var1, Vec3d var2) {
      return var0.method_1044(var1, var2);
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static List method_1049(GC var0) {
      return var0.field_478;
   }

   public static float method_1050(GC var0, float var1) {
      return var0.field_479 = var1;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_3745() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_3747() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4288() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4291() {
      return f$e;
   }

   public static Minecraft method_4292() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_3757() {
      return f$e;
   }

   public static Minecraft method_4294() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_3761() {
      return f$e;
   }

   public static Minecraft method_4296() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4298() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public static Minecraft method_4300() {
      return f$e;
   }

   public static Minecraft method_3767() {
      return f$e;
   }

   public static Minecraft method_4301() {
      return f$e;
   }

   public static Minecraft method_3769() {
      return f$e;
   }

   public GC() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Trajectories";
      var10002[1] = "Tracelines";
      var10002[2] = "Trajectorie";
      var10002[3] = "Traject";
      super("Trajectories", var10002, true, -10349857, bE.RENDER);
      this.field_478 = new ArrayList();
      this.field_478.add(ItemBow.class);
      this.field_478.add(ItemSplashPotion.class);
      this.field_478.add(ItemLingeringPotion.class);
      this.field_478.add(ItemExpBottle.class);
      this.field_478.add(ItemEnderPearl.class);
      this.field_478.add(ItemSnowball.class);
      this.field_478.add(ItemEgg.class);
      ja[] var10001 = new ja[1];
      boolean var1 = true;
      byte var2 = 1;
      var10001[0] = new BB(this);
      this.method_2383(var10001);
   }
}

package net.futureclient.client;

public enum GD {
   Preserve(Of.field_232);

   private static final GD[] field_485;
   Down(Of.field_233);

   private final Of field_487;
   Up(Of.field_234);

   private GD(Of var3) {
      this.field_487 = var3;
   }

   public Of method_1102() {
      return this.field_487;
   }

   static {
      GD[] var10000 = new GD[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Down;
      var10000[1] = Up;
      var10000[2] = Preserve;
      field_485 = var10000;
   }
}

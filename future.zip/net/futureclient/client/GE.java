package net.futureclient.client;

public class GE extends sF {
}

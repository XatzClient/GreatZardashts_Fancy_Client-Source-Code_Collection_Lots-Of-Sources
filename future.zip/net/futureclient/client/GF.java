package net.futureclient.client;

public enum GF {
   PRE,
   POST;

   private static final GF[] field_469;

   static {
      GF[] var10000 = new GF[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = PRE;
      var10000[1] = POST;
      field_469 = var10000;
   }
}

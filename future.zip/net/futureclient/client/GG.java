package net.futureclient.client;

public class GG {
   public String field_454;
   public int field_455;
   public String field_456;
   public nG field_457;
   private boolean field_458;
   public String field_459;

   public GG(nG var1, String var2, int var3) {
      this.field_457 = var1;
      this.field_454 = var2;
      this.field_455 = var3;
   }

   public GG(nG var1, String var2, int var3, String var4, String var5) {
      this.field_457 = var1;
      this.field_454 = var2;
      this.field_459 = var4;
      this.field_456 = var5;
      this.field_455 = var3;
      this.field_458 = true;
   }

   public String method_999() {
      return this.field_456;
   }

   public int method_1000() {
      return this.field_455;
   }

   public String method_1001() {
      return this.field_454;
   }

   public boolean method_1002() {
      return this.field_458;
   }

   public nG method_1003() {
      return this.field_457;
   }

   public String method_1004() {
      return this.field_459;
   }
}

package net.futureclient.client;

import java.util.ArrayList;
import java.util.Comparator;

public class GI extends bF {
   private String field_475 = ".";

   public static String method_1029(GI var0, String var1) {
      return var0.field_475 = var1;
   }

   public void method_2259(String var1) {
      this.field_475 = var1;
   }

   private static String method_1031(xb var0) {
      return var0.method_4201()[0];
   }

   public static String method_1032(GI var0) {
      return var0.field_475;
   }

   public String method_2260() {
      return this.field_475;
   }

   public GI() {
      this.field_1201 = new ArrayList();
      this.method_3798(new kh());
      this.method_3798(new rI());
      this.method_3798(new lH());
      this.method_3798(new Si());
      this.method_3798(new TH());
      this.method_3798(new AG());
      this.method_3798(new uH());
      this.method_3798(new Wi());
      this.method_3798(new xH());
      this.method_3798(new LH());
      this.method_3798(new Ej());
      this.method_3798(new Bf());
      this.method_3798(new Oe());
      this.method_3798(new RG());
      this.method_3798(new Xg());
      this.method_3798(new Dh());
      this.method_3798(new Nh());
      this.method_3798(new FG());
      this.method_3798(new Xi());
      this.method_3798(new DH());
      this.method_3798(new lg());
      this.method_3798(new OI());
      this.method_3798(new fh());
      this.method_3798(new ZF());
      this.method_3798(new jf());
      this.method_3798(new qi());
      this.method_3798(new zG());
      this.method_3798(new Ng());
      this.method_3798(new Yi());
      this.method_3798(new MG());
      this.method_3798(new yF());
      this.method_3798(new fG());
      this.method_3798(new xg());
      this.method_3798(new mh());
      this.method_3798(new HH());
      this.method_3798(new zH());
      this.method_3798(new fi());
      this.method_3798(new BI());
      this.field_1201.sort(Comparator.comparing(apply<invokedynamic>()));
      YH.method_1211().method_1212().method_1330(new tI(this));
      new IH(this, "command_prefix.txt");
   }
}

package net.futureclient.client;

public enum Ga {
   Selective,
   Survival,
   Creative;

   private static final Ga[] field_451;
   Farm;

   static {
      Ga[] var10000 = new Ga[4];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Survival;
      var10000[1] = Selective;
      var10000[2] = Farm;
      var10000[3] = Creative;
      field_451 = var10000;
   }
}

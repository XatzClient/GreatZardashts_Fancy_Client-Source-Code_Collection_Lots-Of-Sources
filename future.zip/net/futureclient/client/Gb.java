package net.futureclient.client;

public abstract class Gb implements C {
   private String field_436;

   public Gb(String var1) {
      this.field_436 = var1;
   }

   public void method_982(String var1) {
      this.field_436 = var1;
   }

   public abstract void method_1191();

   public String method_984() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return this.field_436;
   }
}

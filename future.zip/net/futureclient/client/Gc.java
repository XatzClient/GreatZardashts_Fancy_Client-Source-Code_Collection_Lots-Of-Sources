package net.futureclient.client;

public class Gc extends ja {
   public final lA field_435;

   public Gc(lA var1) {
      this.field_435 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      lA var10000 = this.field_435;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = (double)Math.round((double)((r)((w)lA.method_4245()).getTimer()).method_3789() * 0.0D) / 0.0D;
      var10000.f$D(String.format("Timer §7[§F%s§7]", var10002));
      if (lA.method_4281().player == null) {
         ((r)((w)lA.method_4242()).getTimer()).method_3790(1.0F);
      } else if ((Boolean)lA.method_2397(this.field_435).method_3690()) {
         if ((double)(YH.method_1211().method_1204().method_131() / 20.0F) > 5.941588215E-315D) {
            ((r)((w)lA.method_4269()).getTimer()).method_3790(YH.method_1211().method_1204().method_131() / 20.0F);
         } else {
            ((r)((w)lA.method_4315()).getTimer()).method_3790(1.0F);
         }
      } else {
         ((r)((w)lA.method_4319()).getTimer()).method_3790(lA.method_2395(this.field_435).method_3692().floatValue());
      }
   }
}

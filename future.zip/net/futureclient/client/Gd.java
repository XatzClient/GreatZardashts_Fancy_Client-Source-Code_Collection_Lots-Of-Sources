package net.futureclient.client;

public class Gd {
   public static final int[] field_445;

   static {
      int[] var10000 = new int[qC.values().length];
      boolean var10001 = true;
      byte var10002 = 1;
      field_445 = var10000;
      var10000 = field_445;
      qC var3 = qC.Tick;

      try {
         var10000[var3.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
      }

      var10000 = field_445;
      var3 = qC.AAC;

      try {
         var10000[var3.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
      }
   }
}

package net.futureclient.client;

public class Ge extends CD {
}

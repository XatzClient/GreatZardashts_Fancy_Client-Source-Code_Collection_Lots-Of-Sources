package net.futureclient.client;

public class Gf extends ja {
   public final tD field_430;

   public Gf(tD var1) {
      this.field_430 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2748((Le)var1);
   }

   public void method_2748(Le var1) {
      var1.method_729(true);
   }
}

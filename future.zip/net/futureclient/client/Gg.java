package net.futureclient.client;

public enum Gg {
   private static final Gg[] field_417;
   Blast,
   Prot;

   static {
      Gg[] var10000 = new Gg[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Prot;
      var10000[1] = Blast;
      field_417 = var10000;
   }
}

package net.futureclient.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class Gi extends jB {
   public final mH field_431;

   public Gi(mH var1, String var2) {
      super(var2);
      this.field_431 = var1;
   }

   public void method_3650(Object... var1) {
      mH var10000 = this.field_431;

      Exception var5;
      label33: {
         boolean var10001;
         try {
            if (mH.method_2265(var10000).isEmpty()) {
               return;
            }
         } catch (Exception var4) {
            var5 = var4;
            var10001 = false;
            break label33;
         }

         Gi var6 = this;

         try {
            if (!var6.method_2185().exists()) {
               this.method_2185().createNewFile();
            }

            BufferedWriter var7 = new BufferedWriter(new FileWriter(this.method_2185()));
            var7.write(mH.method_2265(this.field_431));
            var7.close();
            return;
         } catch (Exception var3) {
            var5 = var3;
            var10001 = false;
         }
      }

      Exception var2 = var5;
      var2.printStackTrace();
   }

   public void method_3649(Object... var1) {
      Gi var10000 = this;

      Exception var6;
      label34: {
         boolean var10001;
         try {
            if (!var10000.method_2185().exists()) {
               return;
            }
         } catch (Exception var5) {
            var6 = var5;
            var10001 = false;
            break label34;
         }

         BufferedReader var7 = new BufferedReader;
         BufferedReader var8 = var7;
         FileReader var10002 = new FileReader;
         FileReader var10003 = var10002;
         Gi var10004 = this;

         try {
            var10003.<init>(var10004.method_2185());
            var8.<init>(var10002);
            String var3;
            if ((var3 = var7.readLine()) != null) {
               mH.method_2262(this.field_431, var3);
               return;
            }

            return;
         } catch (Exception var4) {
            var6 = var4;
            var10001 = false;
         }
      }

      Exception var2 = var6;
      var2.printStackTrace();
   }
}

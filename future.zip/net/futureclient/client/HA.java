package net.futureclient.client;

public class HA extends ja {
   public final hc field_453;

   public HA(hc var1) {
      this.field_453 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4193((ae)var1);
   }

   public void method_4193(ae var1) {
      this.field_453.f$c(false);
   }
}

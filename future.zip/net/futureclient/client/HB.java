package net.futureclient.client;

import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;

public class HB extends ja {
   public final hc field_447;

   public HB(hc var1) {
      this.field_447 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      if (hc.method_4286().currentScreen instanceof GuiGameOver) {
         boolean var4 = true;
         byte var5 = 1;
         this.field_447.f$c(false);
      } else {
         hc.method_3428(this.field_447).movementInput.updatePlayerMoveState();
         hc.method_3428(this.field_447).setHealth(hc.method_4293().player.getHealth());
         hc.method_3428(this.field_447).setAbsorptionAmount(hc.method_4287().player.getAbsorptionAmount());
         hc.method_3428(this.field_447).setPrimaryHand(hc.method_4250().player.getPrimaryHand());
         hc.method_3428(this.field_447).prevPosX = hc.method_3428(this.field_447).lastTickPosX = hc.method_3428(this.field_447).posX;
         hc.method_3428(this.field_447).prevPosY = hc.method_3428(this.field_447).lastTickPosY = hc.method_3428(this.field_447).posY;
         hc.method_3428(this.field_447).prevPosZ = hc.method_3428(this.field_447).lastTickPosZ = hc.method_3428(this.field_447).posZ;
         double[] var2 = EI.method_869(hc.method_3428(this.field_447), hc.method_3423(this.field_447).method_3692().doubleValue());
         uC var10000 = hc.method_3428(this.field_447);
         AxisAlignedBB var10001 = hc.method_3428(this.field_447).getEntityBoundingBox();
         uC var10002 = hc.method_3428(this.field_447);
         boolean var10005 = true;
         byte var10006 = 1;
         double var3 = var10002.motionX = var2[0];
         double var10003 = hc.method_3428(this.field_447).motionY = hc.method_3428(this.field_447).movementInput.jump ? hc.method_3423(this.field_447).method_3692().doubleValue() : (hc.method_3428(this.field_447).movementInput.sneak ? -hc.method_3423(this.field_447).method_3692().doubleValue() : 0.0D);
         uC var10004 = hc.method_3428(this.field_447);
         byte var10007 = 1;
         byte var10008 = 1;
         var10000.setEntityBoundingBox(var10001.offset(var3, var10003, var10004.motionZ = var2[1]));
         hc.method_3428(this.field_447).resetPositionToBB();
         hc.method_3428(this.field_447).chunkCoordX = MathHelper.floor(hc.method_3428(this.field_447).posX / 0.0D);
         hc.method_3428(this.field_447).chunkCoordZ = MathHelper.floor(hc.method_3428(this.field_447).posZ / 0.0D);
         hc.method_3428(this.field_447).inventory = hc.method_4295().player.inventory;
         hc.method_3428(this.field_447).inventoryContainer = hc.method_4282().player.inventoryContainer;
         hc.method_3428(this.field_447).capabilities = hc.method_4290().player.capabilities;
         hc.method_3428(this.field_447).hurtTime = hc.method_4272().player.hurtTime;
         hc.method_3428(this.field_447).maxHurtTime = hc.method_4244().player.maxHurtTime;
         hc.method_3428(this.field_447).attackedAtYaw = hc.method_4289().player.attackedAtYaw;
         if (hc.method_4283().getRenderViewEntity() != hc.method_3428(this.field_447)) {
            hc.method_3427(this.field_447, hc.method_4243().getRenderViewEntity());
            hc.method_4280().setRenderViewEntity(hc.method_3428(this.field_447));
         }

      }
   }
}

package net.futureclient.client;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;

public class HC extends wA {
   private List field_437 = new ArrayList();
   public int field_438 = 0;
   private Aa field_439;
   public boolean field_440;
   public float field_441 = 1.0F;
   private Minecraft field_442 = Minecraft.getMinecraft();
   public Color field_443 = (new ei(0.0F, (float)0, 100.0F, 1.0F)).method_3395();

   public HC(Aa var1) {
      super(var1.method_636());
      this.field_439 = var1;
      if (!var1.method_615().isEmpty()) {
         Iterator var2 = var1.method_615().iterator();

         while(var2.hasNext()) {
            t var3;
            if ((var3 = (t)var2.next()).method_3690() instanceof Boolean) {
               this.field_437.add(new SB(var3));
            }

            if (var3 instanceof ga) {
               this.field_437.add(new DB((ga)var3));
            }

            if (var3 instanceof U) {
               this.field_437.add(new na((U)var3));
            }
         }
      }

      if (var1 instanceof k) {
         this.field_437.add(new tB((ka)var1));
      }

   }

   public void method_3982(int var1, int var2, int var3) {
      super.method_3982(var1, var2, var3);
      if (!this.field_437.isEmpty()) {
         if (var3 == 1 && this.method_4047(var1, var2)) {
            this.field_440 = !this.field_440;
            this.field_442.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         }

         Iterator var4;
         if (this.field_440) {
            for(Iterator var10000 = var4 = this.field_437.iterator(); var10000.hasNext(); var10000 = var4) {
               ((Wa)var4.next()).method_3982(var1, var2, var3);
            }
         }
      }

   }

   public int method_2414() {
      if (!this.field_440) {
         return 14;
      } else {
         int var1 = 14;

         Iterator var2;
         for(Iterator var10000 = var2 = this.field_437.iterator(); var10000.hasNext(); var10000 = var2) {
            Wa var3 = (Wa)var2.next();
            var1 += var3.method_2414() + 1;
         }

         return var1 + 2;
      }
   }

   public boolean method_2415() {
      return !(this.field_439 instanceof ka) || ((ka)this.field_439).method_2387();
   }

   public void method_1667() {
      if (this.field_439 instanceof ka) {
         ((ka)this.field_439).method_2390();
      }

   }

   public void method_3986(int var1, int var2, float var3) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      super.method_3986(var1, var2, var3);
      if (!this.field_437.isEmpty()) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         nI.method_2438(this.field_443);
         this.field_442.getTextureManager().bindTexture(new ResourceLocation("textures/future/gear.png"));
         GlStateManager.translate(this.method_1910() + (float)this.method_1909() - 6.7F, this.f$c() + 7.7F, 0.0F);
         GlStateManager.rotate(ri.method_3657((float)this.field_438), 0.0F, (float)0, 1.0F);
         nI.method_2436(-5, -5, 0.0F, (float)0, 10, 10, 10, 10, 10.0F, 10.0F);
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
         if (this.field_440) {
            float var4 = 1.1F;
            Iterator var5;
            Iterator var7 = var5 = this.field_437.iterator();

            while(var7.hasNext()) {
               Wa var6 = (Wa)var5.next();
               var4 += 15.0F;
               var7 = var5;
               var6.method_1912(this.field_853 + 1.0F, this.field_848 + var4);
               var6.method_1916(15);
               var6.method_1911(this.field_850 - 9);
               var6.method_3986(var1, var2, var3);
            }
         }
      }

   }
}

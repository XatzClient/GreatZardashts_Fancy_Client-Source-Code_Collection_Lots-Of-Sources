package net.futureclient.client;

public enum HD {
   POST,
   PRE;

   private static final HD[] field_434;

   static {
      HD[] var10000 = new HD[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = PRE;
      var10000[1] = POST;
      field_434 = var10000;
   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;

public class HE extends ja {
   public final se field_446;

   public HE(se var1) {
      this.field_446 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }

   public void method_4241(je var1) {
      if ((Boolean)se.method_3937(this.field_446).method_3690()) {
         switch(Mf.f$G[((FE)se.method_3946(this.field_446).method_3690()).ordinal()]) {
         case 1:
            boolean var10001 = false;
            if (var1.method_3084() instanceof CPacketPlayerTryUseItem) {
               se.method_3941(this.field_446);
               return;
            }
            break;
         case 2:
            if (var1.method_3084() instanceof CPacketAnimation) {
               se.method_3941(this.field_446);
            }
         }
      }

   }
}

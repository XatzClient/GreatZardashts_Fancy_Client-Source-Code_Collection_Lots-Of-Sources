package net.futureclient.client;

import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

public class HF extends ja {
   public final YD field_444;

   public HF(YD var1) {
      this.field_444 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      if (var1.method_326() == HD.PRE) {
         YD.method_1311(this.field_444, YD.method_1297(this.field_444));
         mF var2 = null;
         if (YD.method_1307(this.field_444) != -1 && (var2 = YD.method_1309(this.field_444, false)) == null) {
            var2 = YD.method_1309(this.field_444, true);
         }

         YD.method_1305(this.field_444, var2);
         if (YD.method_1303(this.field_444) != null) {
            float[] var3 = ri.method_3668(mF.f$c(YD.method_1303(this.field_444)), mF.f$c(YD.method_1303(this.field_444)));
            var1.method_2096(YD.method_1300(this.field_444, var3[0]));
            var1.method_3094(YD.method_1310(this.field_444, var3[1]));
            return;
         }
      } else if (var1.method_326() == HD.POST && YD.method_1303(this.field_444) != null) {
         RayTraceResult var6 = Ah.f$c(YD.method_1301(this.field_444), YD.method_1313(this.field_444));
         boolean var7 = YD.method_4283().player.inventory.currentItem != YD.method_1307(this.field_444);
         int var4 = YD.method_4243().player.inventory.currentItem;
         boolean var5 = !YD.method_4280().player.isSneaking() || !fI.f$c(mF.f$c(YD.method_1303(this.field_444)));
         if (var7) {
            YD.method_4271().player.connection.sendPacket(new CPacketHeldItemChange(YD.method_4279().player.inventory.currentItem = YD.method_1307(this.field_444)));
         }

         if (var5) {
            YD.method_4275().player.connection.sendPacket(new CPacketEntityAction(YD.method_4278().player, Action.START_SNEAKING));
         }

         YD.method_4267().playerController.processRightClickBlock(YD.method_4277().player, YD.method_4270().world, mF.f$c(YD.method_1303(this.field_444)), mF.f$c(YD.method_1303(this.field_444)), var6.hitVec, EnumHand.MAIN_HAND);
         YD.method_4273().player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
         if (var5) {
            YD.method_4274().player.connection.sendPacket(new CPacketEntityAction(YD.method_4276().player, Action.STOP_SNEAKING));
         }

         if (var7) {
            YD.method_4281().player.connection.sendPacket(new CPacketHeldItemChange(YD.method_4245().player.inventory.currentItem = var4));
         }
      }

   }
}

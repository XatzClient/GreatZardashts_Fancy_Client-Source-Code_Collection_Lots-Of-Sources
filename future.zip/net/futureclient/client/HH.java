package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.item.EntityEnderEye;

public class HH extends xb {
   private EntityEnderEye field_420;
   private boolean field_421;
   private boolean field_422;
   private wG field_423;
   private EntityEnderEye field_424;
   private EG field_425;
   private wG field_426;
   private wG field_427;
   private wG field_428;
   private wG field_429;

   public static wG method_948(HH var0, wG var1) {
      return var0.field_428 = var1;
   }

   public static wG method_949(HH var0) {
      return var0.field_428;
   }

   public static EntityEnderEye method_950(HH var0) {
      return var0.field_424;
   }

   public static wG method_951(HH var0, wG var1) {
      return var0.field_427 = var1;
   }

   public static boolean method_952(HH var0, boolean var1) {
      return var0.field_421 = var1;
   }

   public static Minecraft method_953(HH var0) {
      return var0.field_1834;
   }

   public static EntityEnderEye method_954(HH var0, EntityEnderEye var1) {
      return var0.field_424 = var1;
   }

   public static boolean method_955(HH var0) {
      return var0.field_421;
   }

   public static wG method_956(HH var0) {
      return var0.field_427;
   }

   public String method_4224() {
      return null;
   }

   private wG method_958(wG var1, wG var2, wG var3, wG var4) {
      double var5 = (var2.f$G - var1.f$G) / (var2.f$E - var1.f$E);
      double var7 = (var4.f$G - var3.f$G) / (var4.f$E - var3.f$E);
      double var9 = var1.f$G + var5 * (0.0D - var1.f$E);
      double var11 = var3.f$G + var7 * (0.0D - var3.f$E);
      double var10000;
      double var13;
      if (var5 != 0.0D && var5 != 0.0D) {
         if (var7 != 0.0D && var7 != 0.0D) {
            var13 = (var11 - var9) / (var5 - var7);
            var10000 = var5;
         } else {
            var13 = var3.f$E;
            var10000 = var5;
         }
      } else {
         var13 = var1.f$E;
         var10000 = var5;
      }

      var5 = var10000 * var13 + var9;
      return Double.isFinite(var13) && Double.isFinite(var5) ? new wG(this, var13, var5, (Oh)null) : null;
   }

   public static EntityEnderEye method_959(HH var0, EntityEnderEye var1) {
      return var0.field_420 = var1;
   }

   public static wG method_960(HH var0) {
      return var0.field_426;
   }

   public static Minecraft method_961(HH var0) {
      return var0.field_1834;
   }

   public static wG method_962(HH var0, wG var1, wG var2, wG var3, wG var4) {
      return var0.method_958(var1, var2, var3, var4);
   }

   public static boolean method_963(HH var0, boolean var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.field_422 = var1;
   }

   public static EG method_964(HH var0) {
      return var0.field_425;
   }

   public String method_4228(String[] var1) {
      this.method_4223();
      YH.method_1211().method_1212().method_1330(new Oh(this));
      return Th.f$c("B\u001bd\u001caSw\u001d66o\u00166\u001cpSS\u001dr\u0016dSb\u001c6\u0011s\u0014\u007f\u001d6\u0000s\u0012d\u0010~\u001ax\u00146\u0015y\u00016\u00126\u0000b\u0001y\u001dq\u001by\u001fr]");
   }

   public static EntityEnderEye method_966(HH var0) {
      return var0.field_420;
   }

   public static wG method_967(HH var0, wG var1) {
      return var0.field_426 = var1;
   }

   public static void method_968(HH var0) {
      var0.method_4223();
   }

   private void method_4223() {
      this.field_424 = null;
      this.field_421 = false;
      this.field_428 = null;
      this.field_423 = null;
      this.field_420 = null;
      this.field_422 = false;
      this.field_427 = null;
      this.field_429 = null;
      this.field_426 = null;
      this.field_425.method_814();
   }

   public static boolean method_970(HH var0) {
      return var0.field_422;
   }

   public static wG method_971(HH var0, wG var1) {
      return var0.field_429 = var1;
   }

   public static Minecraft method_972(HH var0) {
      return var0.field_1834;
   }

   public static wG method_973(HH var0) {
      return var0.field_429;
   }

   public static wG method_974(HH var0) {
      return var0.field_423;
   }

   public static wG method_975(HH var0, wG var1) {
      return var0.field_423 = var1;
   }

   public HH() {
      String[] var10001 = new String[4];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "FindStronghold";
      var10001[1] = "Stronghold";
      var10001[2] = "StrongholdFinder";
      var10001[3] = "fs";
      super(var10001);
      this.field_425 = new EG();
      this.field_421 = false;
      this.field_422 = false;
   }
}

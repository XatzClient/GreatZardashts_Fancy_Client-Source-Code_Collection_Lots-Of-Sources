package net.futureclient.client;

public enum Ha {
   Hypixel,
   Normal;

   private static final Ha[] field_69;

   static {
      Ha[] var10000 = new Ha[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Normal;
      var10000[1] = Hypixel;
      field_69 = var10000;
   }
}

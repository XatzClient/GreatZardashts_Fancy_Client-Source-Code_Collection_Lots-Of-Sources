package net.futureclient.client;

public class Hc extends ka {
   public Hc() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[4];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "TrueDurability";
      byte var5 = 1;
      var10006 = 1;
      var10002[1] = "TrueDura";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "RealDura";
      var10005 = true;
      var10006 = 1;
      var10002[3] = "RealDurability";
      var10004 = 1;
      var5 = 1;
      super("TrueDurability", var10002, true, -89805, bE.MISCELLANEOUS);
      byte var1 = 1;
      byte var3 = 1;
      ja[] var10001 = new ja[1];
      boolean var2 = true;
      var3 = 1;
      boolean var4 = true;
      var5 = 1;
      var10001[0] = new kC(this);
      this.method_2383(var10001);
   }
}

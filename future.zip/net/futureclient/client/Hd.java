package net.futureclient.client;

import net.minecraft.init.Blocks;

public class Hd extends ka {
   public void method_4314() {
      super.method_4314();
      Blocks.ICE.slipperiness = 0.98F;
      Blocks.PACKED_ICE.slipperiness = 0.98F;
      Blocks.FROSTED_ICE.slipperiness = 0.98F;
   }

   public Hd() {
      String[] var10002 = new String[6];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "IceSpeed";
      var10002[1] = "IceSped";
      var10002[2] = "OiceSped";
      var10002[3] = "OiceSpeed";
      var10002[4] = "Isped";
      var10002[5] = "Ispeed";
      super("IceSpeed", var10002, true, -14564873, bE.MOVEMENT);
      ja[] var10001 = new ja[1];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new MB(this);
      this.method_2383(var10001);
   }
}

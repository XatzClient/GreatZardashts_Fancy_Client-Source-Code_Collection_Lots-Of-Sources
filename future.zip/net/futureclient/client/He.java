package net.futureclient.client;

import java.util.HashMap;
import net.minecraft.client.Minecraft;

public class He extends ka {
   private t field_42;
   private EG field_43;
   private t field_44;
   private String[] field_45;
   private String[] field_46;
   private EG field_47;
   private HashMap field_48;
   private EG field_49;
   private String[] field_50;
   private t field_51;
   private HashMap field_52;
   private String[] field_53;
   private t field_54;
   private HashMap field_55;
   private String[] field_56;
   private t field_57;
   private String[] field_58;
   private String[] field_59;
   private t field_60;
   private String[] field_61;
   private String[] field_62;
   private String[] field_63;
   private t field_64;

   public void method_4314() {
      this.field_48.clear();
      this.field_52.clear();
      this.field_55.clear();
      super.method_4314();
   }

   public static Minecraft method_4242() {
      return field_284;
   }

   public static t method_83(He var0) {
      return var0.field_51;
   }

   public static String[] method_84(He var0) {
      return var0.field_45;
   }

   public static t method_85(He var0) {
      return var0.field_60;
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   public static String[] method_87(He var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.field_62;
   }

   public static t method_88(He var0) {
      return var0.field_42;
   }

   public static EG method_89(He var0) {
      return var0.field_49;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static String[] method_91(He var0) {
      return var0.field_50;
   }

   public static HashMap method_92(He var0) {
      return var0.field_52;
   }

   public static EG method_93(He var0) {
      return var0.field_43;
   }

   public static t method_94(He var0) {
      return var0.field_57;
   }

   public static void method_95(He var0, String var1) {
      var0.method_525(var1);
   }

   public static HashMap method_96(He var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.field_55;
   }

   public static String[] method_97(He var0) {
      return var0.field_63;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static Minecraft method_4267() {
      return field_284;
   }

   public static String[] method_100(He var0) {
      return var0.field_53;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static t method_102(He var0) {
      return var0.field_64;
   }

   public static HashMap method_103(He var0) {
      return var0.field_48;
   }

   public static String[] method_104(He var0) {
      return var0.field_56;
   }

   public static EG method_105(He var0) {
      return var0.field_47;
   }

   public static Minecraft method_4270() {
      return field_284;
   }

   public static String[] method_107(He var0) {
      return var0.field_46;
   }

   public static Minecraft method_4273() {
      return field_284;
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static String[] method_110(He var0) {
      return var0.field_61;
   }

   public static Minecraft method_4275() {
      return field_284;
   }

   public static String[] method_112(He var0) {
      return var0.field_58;
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static Minecraft method_4277() {
      return field_284;
   }

   public void method_4326() {
      this.field_48.clear();
      this.field_52.clear();
      this.field_55.clear();
      super.method_4326();
   }

   public static t method_116(He var0) {
      return var0.field_54;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public static String[] method_118(He var0) {
      return var0.field_59;
   }

   private void method_525(String var1) {
      if ((Boolean)this.field_44.method_3690()) {
         la.method_2324().method_2322(var1);
      } else {
         field_284.player.sendChatMessage((new StringBuilder()).insert(0, "> ").append(var1).toString());
      }
   }

   public He() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Announcer";
      var10002[1] = "Anounce";
      var10002[2] = "Greeter";
      var10002[3] = "Greet";
      super("Announcer", var10002, true, -4191950, bE.MISCELLANEOUS);
      Boolean var3 = true;
      String[] var4 = new String[1];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Join";
      this.field_60 = new t(var3, var4);
      var3 = true;
      var4 = new String[1];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Leave";
      this.field_54 = new t(var3, var4);
      var3 = true;
      var4 = new String[1];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Place";
      this.field_64 = new t(var3, var4);
      var3 = true;
      var4 = new String[1];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Break";
      this.field_51 = new t(var3, var4);
      var3 = true;
      var4 = new String[1];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Food";
      this.field_57 = new t(var3, var4);
      var3 = true;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "WorldTime";
      var4[1] = "World";
      var4[2] = "WorldTimer";
      var4[3] = "TimeData";
      var4[4] = "Night";
      var4[5] = "Time";
      this.field_42 = new t(var3, var4);
      var3 = false;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "ClientSideOnly";
      var4[1] = "ClientSide";
      var4[2] = "cso";
      var4[3] = "cs";
      this.field_44 = new t(var3, var4);
      this.field_48 = new HashMap();
      this.field_52 = new HashMap();
      this.field_55 = new HashMap();
      this.field_47 = new EG();
      this.field_49 = new EG();
      this.field_43 = new EG();
      t[] var10001 = new t[7];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_60;
      var10001[1] = this.field_54;
      var10001[2] = this.field_57;
      var10001[3] = this.field_64;
      var10001[4] = this.field_51;
      var10001[5] = this.field_42;
      var10001[6] = this.field_44;
      this.method_626(var10001);
      String[] var1 = new String[7];
      var2 = true;
      var6 = 1;
      var1[0] = "See you later, ";
      var1[1] = "Catch ya later, ";
      var1[2] = "See you next time, ";
      var1[3] = "Farewell, ";
      var1[4] = "Bye, ";
      var1[5] = "Good bye, ";
      var1[6] = "Later, ";
      this.field_46 = var1;
      var1 = new String[7];
      var2 = true;
      var6 = 1;
      var1[0] = "Good to see you, ";
      var1[1] = "Greetings, ";
      var1[2] = "Hello, ";
      var1[3] = "Howdy, ";
      var1[4] = "Hey, ";
      var1[5] = "Good evening, ";
      var1[6] = "Welcome to SERVERIP1D5A9E, ";
      this.field_53 = var1;
      var1 = new String[6];
      var2 = true;
      var6 = 1;
      var1[0] = "Good morning!";
      var1[1] = "Top of the morning to you!";
      var1[2] = "Good day!";
      var1[3] = "You survived another night!";
      var1[4] = "Good morning everyone!";
      var1[5] = "The sun is rising in the east, hurrah, hurrah!";
      this.field_58 = var1;
      var1 = new String[5];
      var2 = true;
      var6 = 1;
      var1[0] = "Let's go tanning!";
      var1[1] = "Let's go to the beach!";
      var1[2] = "Grab your sunglasses!";
      var1[3] = "Enjoy the sun outside! It is currently very bright!";
      var1[4] = "It's the brightest time of the day!";
      this.field_61 = var1;
      var1 = new String[5];
      var2 = true;
      var6 = 1;
      var1[0] = "Good afternoon!";
      var1[1] = "Let's grab lunch!";
      var1[2] = "Lunch time, kids!";
      var1[3] = "Good afternoon everyone!";
      var1[4] = "IT'S HIGH NOON!";
      this.field_62 = var1;
      var1 = new String[3];
      var2 = true;
      var6 = 1;
      var1[0] = "Happy hour!";
      var1[1] = "Let's get crunk!";
      var1[2] = "Enjoy the sunset everyone!";
      this.field_59 = var1;
      var1 = new String[4];
      var2 = true;
      var6 = 1;
      var1[0] = "Let's get comfy!";
      var1[1] = "Netflix and chill!";
      var1[2] = "You survived another day!";
      var1[3] = "Time to go to bed kids!";
      this.field_45 = var1;
      var1 = new String[1];
      var2 = true;
      var6 = 1;
      var1[0] = "Sunset has now ended! You may eat your lunch now if you are a muslim.";
      this.field_56 = var1;
      var1 = new String[2];
      var2 = true;
      var6 = 1;
      var1[0] = "It's so dark outside...";
      var1[1] = "It's the opposite of noon!";
      this.field_50 = var1;
      var1 = new String[3];
      var2 = true;
      var6 = 1;
      var1[0] = "Good bye, zombies!";
      var1[1] = "Monsters are now burning!";
      var1[2] = "Burn baby, burn!";
      this.field_63 = var1;
      ja[] var5 = new ja[7];
      var2 = true;
      var6 = 1;
      var5[0] = new Vd(this);
      var5[1] = new rD(this);
      var5[2] = new JF(this);
      var5[3] = new cF(this);
      var5[4] = new JD(this);
      var5[5] = new cD(this);
      var5[6] = new ef(this);
      this.method_2383(var5);
   }
}

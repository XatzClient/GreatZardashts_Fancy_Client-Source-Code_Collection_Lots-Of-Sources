package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;

public class Hf extends ka {
   private boolean field_39;
   private t field_40;
   private t field_41;

   public void method_4314() {
      super.method_4314();
      if ((Boolean)this.field_40.method_3690() && field_284.player != null && field_284.player.isSprinting()) {
         field_284.player.connection.sendPacket(new CPacketEntityAction(field_284.player, Action.START_SPRINTING));
      }

   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static t method_75(Hf var0) {
      return var0.field_40;
   }

   public static boolean method_76(Hf var0) {
      return var0.field_39;
   }

   public static t method_77(Hf var0) {
      return var0.field_41;
   }

   public static boolean method_78(Hf var0, boolean var1) {
      return var0.field_39 = var1;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public void method_4326() {
      if ((Boolean)this.field_40.method_3690() && field_284.player != null) {
         field_284.player.connection.sendPacket(new CPacketEntityAction(field_284.player, Action.STOP_SPRINTING));
      }

      super.method_4326();
   }

   public Hf() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AntiHunger";
      var10002[1] = "NoHunger";
      var10002[2] = "DenyHunger";
      var10002[3] = "AH";
      super("AntiHunger", var10002, true, -11127454, bE.EXPLOITS);
      Boolean var3 = true;
      String[] var5 = new String[1];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Sprint";
      this.field_40 = new t(var3, var5);
      var3 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Ground";
      this.field_41 = new t(var3, var5);
      t[] var10001 = new t[2];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_40;
      var10001[1] = this.field_41;
      this.method_626(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var4 = 1;
      var1[0] = new sf(this);
      this.method_2383(var1);
   }
}

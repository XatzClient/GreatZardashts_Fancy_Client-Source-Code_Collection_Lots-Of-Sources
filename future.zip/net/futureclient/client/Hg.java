package net.futureclient.client;

public abstract class Hg extends CD {
}

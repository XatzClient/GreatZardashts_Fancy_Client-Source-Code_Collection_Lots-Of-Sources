package net.futureclient.client;

import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;

public class IB extends ja {
   public final Vb field_66;

   public IB(Vb var1) {
      this.field_66 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      le var2;
      if (!(var2 = (le)YH.method_1211().method_1205().method_2166(le.class)).f$c() || !var2.method_2849()) {
         int var5 = -1;
         int var3;
         int var10000 = var3 = 0;

         while(true) {
            if (var10000 >= 9) {
               var10000 = var5;
               break;
            }

            ItemStack var4 = Vb.method_4289().player.inventory.getStackInSlot(var3);
            if (!Vb.method_4283().player.inventory.getStackInSlot(var3).isEmpty() && var4.getItem() instanceof ItemFishingRod) {
               var10000 = var5 = var3;
               break;
            }

            ++var3;
            var10000 = var3;
         }

         if (var10000 != -1) {
            if (Vb.method_4243().player.inventory.currentItem != var5) {
               Vb.method_4280().player.inventory.currentItem = var5;
            } else if (Vb.method_1960(this.field_66) > 0) {
               Vb.method_1942(this.field_66);
            } else if (Vb.method_4279().player.fishEntity != null) {
               Vb.method_1967(this.field_66);
               if (Vb.method_1939(this.field_66) > 720) {
                  Vb.method_1949(this.field_66);
               }

               if (Vb.method_4271().player.fishEntity.caughtEntity != null) {
                  Vb.method_1949(this.field_66);
               }

               if (Vb.method_1948(this.field_66)) {
                  Vb.method_1955(this.field_66);
                  if (Vb.method_1946(this.field_66) >= 4) {
                     Vb.method_1949(this.field_66);
                     Vb.method_1951(this.field_66, false);
                     return;
                  }
               } else if (Vb.method_1946(this.field_66) != 0) {
                  Vb.method_1947(this.field_66);
               }

            } else {
               Vb.method_1949(this.field_66);
            }
         } else {
            var3 = -1;
            int var8;
            var10000 = var8 = 9;

            while(true) {
               if (var10000 >= 36) {
                  var10000 = var3;
                  break;
               }

               ItemStack var6 = Vb.method_4278().player.inventory.getStackInSlot(var8);
               if (!Vb.method_4275().player.inventory.getStackInSlot(var8).isEmpty() && var6.getItem() instanceof ItemFishingRod) {
                  var10000 = var3 = var8;
                  break;
               }

               ++var8;
               var10000 = var8;
            }

            if (var10000 != -1) {
               var8 = -1;

               for(var10000 = var5 = 0; var10000 < 9; var10000 = var5) {
                  if (Vb.method_4277().player.inventory.getStackInSlot(var5) == ItemStack.EMPTY) {
                     var8 = var5;
                     break;
                  }

                  ++var5;
               }

               boolean var7 = false;
               if (var8 == -1) {
                  var8 = Vb.method_4270().player.inventory.currentItem;
                  var7 = true;
               }

               Vb.method_4273().playerController.windowClick(0, var3, 0, ClickType.PICKUP, Vb.method_4267().player);
               Vb.method_4274().playerController.windowClick(0, 36 + var8, 0, ClickType.PICKUP, Vb.method_4276().player);
               if (var7) {
                  Vb.method_4281().playerController.windowClick(0, var3, 0, ClickType.PICKUP, Vb.method_4245().player);
               }

            }
         }
      }
   }
}

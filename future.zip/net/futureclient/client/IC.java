package net.futureclient.client;

public class IC extends ja {
   public final Pb field_65;

   public IC(Pb var1) {
      this.field_65 = var1;
   }

   public void method_120(XF var1) {
      if ((Boolean)Pb.method_1529(this.field_65).method_3690()) {
         boolean var10002 = true;
         boolean var10003 = true;
         boolean var10004 = true;
         boolean var10005 = true;
         var1.f$c(true);
      }

   }

   public void method_4312(CD var1) {
      this.method_120((XF)var1);
   }
}

package net.futureclient.client;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;

public class ID extends ja {
   public final If field_38;

   public ID(If var1) {
      this.field_38 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      ge var2;
      if ((var2 = (ge)YH.method_1211().method_1205().method_2166(ge.class)) == null || !var2.f$c() || !var2.field_1419) {
         if (If.method_22(this.field_38).method_811(If.method_23(this.field_38).method_3692().floatValue() * 1000.0F) && !If.method_4276().player.capabilities.isCreativeMode && (!(If.method_4274().currentScreen instanceof GuiContainer) || If.method_4245().currentScreen instanceof GuiInventory) && (!(Boolean)If.method_12(this.field_38).method_3690() || If.method_4281().currentScreen instanceof GuiContainer)) {
            byte var10000;
            byte var4;
            if ((Boolean)If.method_24(this.field_38).method_3690() && If.method_4242().player.inventoryContainer.getSlot(6).getStack().getItem() instanceof ItemElytra && If.method_4269().player.inventoryContainer.getSlot(6).getStack().getMaxDamage() - If.method_4315().player.inventoryContainer.getSlot(6).getStack().getItemDamage() < 5) {
               for(var10000 = var4 = 9; var10000 <= 44; var10000 = ++var4) {
                  ItemStack var3;
                  if ((var3 = If.method_4319().player.inventoryContainer.getSlot(var4).getStack()) != ItemStack.EMPTY && var3.getItem() instanceof ItemElytra && var3.getCount() == 1 && var3.getMaxDamage() - var3.getItemDamage() > 5) {
                     If.method_15(this.field_38, true);
                     If.method_17(this.field_38, 6, false);
                     If.method_17(this.field_38, var4, true);
                     If.method_17(this.field_38, var4, false);
                     If.method_15(this.field_38, false);
                  }
               }
            }

            for(var10000 = var4 = 5; var10000 <= 8; var10000 = ++var4) {
               if (If.method_19(this.field_38, var4)) {
                  If.method_22(this.field_38).method_814();
                  return;
               }
            }

         }
      }
   }
}

package net.futureclient.client;

import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;

public class IE extends ja {
   public final KF field_37;

   public IE(KF var1) {
      this.field_37 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      KF var10000 = this.field_37;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = this.field_37.method_4078();
      var10000.method_616(String.format("AutoSoup §7[§F%s§7]", var10002));

      int var2;
      for(int var4 = var2 = 44; var4 >= 9; var4 = var2) {
         ItemStack var3;
         if (!((var3 = KF.method_4242().player.inventoryContainer.getSlot(var2).getStack()).getItem() instanceof ItemAir) && var3.getItem() == Items.BOWL && (Boolean)KF.method_155(this.field_37).method_3690() && KF.method_159(this.field_37).method_817(100L)) {
            KF.method_4315().playerController.windowClick(0, var2, 0, ClickType.THROW, KF.method_4269().player);
            KF.method_159(this.field_37).method_814();
         }

         --var2;
      }

      if (KF.method_4319().player.getHealth() < KF.method_156(this.field_37).method_3692().floatValue() && !((ge)YH.method_1211().method_1205().method_2166(ge.class)).field_1419) {
         KF.method_158(this.field_37);
      }

   }
}

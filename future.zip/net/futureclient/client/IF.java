package net.futureclient.client;

import net.minecraft.network.Packet;

public final class IF extends nD {
   public IF(Packet var1) {
      super(var1);
   }
}

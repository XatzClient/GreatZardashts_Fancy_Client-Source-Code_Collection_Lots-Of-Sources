package net.futureclient.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class IH extends jB {
   public final GI field_36;

   public IH(GI var1, String var2) {
      super(var2);
      this.field_36 = var1;
   }

   public void method_3650(Object... var1) {
      IH var10000 = this;

      try {
         if (!var10000.method_2185().exists()) {
            this.method_2185().createNewFile();
         }
      } catch (IOException var4) {
         var4.printStackTrace();
      }

      BufferedWriter var5 = new BufferedWriter;
      BufferedWriter var10001 = var5;
      FileWriter var10002 = new FileWriter;
      FileWriter var10003 = var10002;
      IH var10004 = this;

      try {
         var10003.<init>(var10004.method_2185());
         var10001.<init>(var10002);
         var5.write(GI.method_1032(this.field_36));
         var5.newLine();
         var5.close();
      } catch (Exception var3) {
         var3.printStackTrace();
      }
   }

   public void method_3649(Object... var1) {
      IH var10000 = this;

      try {
         if (!var10000.method_2185().exists()) {
            this.method_2185().createNewFile();
         }
      } catch (IOException var5) {
         var5.printStackTrace();
      }

      if (this.method_2185().exists()) {
         BufferedReader var6 = new BufferedReader;
         BufferedReader var10001 = var6;
         FileReader var10002 = new FileReader;
         FileReader var10003 = var10002;
         IH var10004 = this;

         try {
            var10003.<init>(var10004.method_2185());
            var10001.<init>(var10002);
            BufferedReader var2 = var6;
            String var3;
            if ((var3 = var6.readLine()) != null && !var3.isEmpty() && !var3.contains(" ") && !var3.contains("\u0000")) {
               GI.method_1029(this.field_36, var3);
            }

            var2.close();
         } catch (Exception var4) {
            var4.printStackTrace();
         }
      }
   }
}

package net.futureclient.client;

import java.util.List;
import net.minecraft.block.state.IBlockState;

public class Ia extends ja {
   public final Qa field_22;

   public Ia(Qa var1) {
      this.field_22 = var1;
   }

   public void method_31(fe var1) {
      if (((Ga)Qa.method_1437(this.field_22).method_3690()).equals(Ga.Selective) && (Boolean)Qa.method_1429(this.field_22).method_3690() && Qa.method_1435(this.field_22).method_817(50L)) {
         IBlockState var2 = Qa.method_4319().world.getBlockState(var1.method_3153());
         List var3;
         if (!(var3 = (List)Qa.method_1433(this.field_22).method_3690()).contains(var2)) {
            var3.add(var2);
            Qa.method_1435(this.field_22).method_814();
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_31((fe)var1);
   }
}

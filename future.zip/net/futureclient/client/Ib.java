package net.futureclient.client;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;

public class Ib extends ka {
   private int field_27;
   private boolean field_28;
   private Map field_29;
   private int field_30;
   private Map field_31;
   private BlockPos field_32;
   private BlockPos field_33;
   private BlockPos field_34;

   public static int method_42(Ib var0) {
      return var0.field_30;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static BlockPos method_44(Ib var0, BlockPos var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.method_49(var1);
   }

   public static Map method_45(Ib var0) {
      return var0.field_31;
   }

   public static int method_46(Ib var0, int var1) {
      return var0.field_27 = var1;
   }

   public static BlockPos method_47(Ib var0) {
      return var0.field_34;
   }

   private void method_48(BlockPos var1) {
      if (var1 != null) {
         this.field_32 = var1;
         this.field_29.put(var1, new AtomicInteger(-1));
      }

   }

   private BlockPos method_49(BlockPos var1) {
      Iterator var2 = this.field_29.entrySet().iterator();

      BlockPos var3;
      AtomicInteger var4;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         Entry var5;
         var3 = (BlockPos)(var5 = (Entry)var2.next()).getKey();
         var4 = (AtomicInteger)var5.getValue();
      } while(var3 == null || var3.equals(var1) || var4.intValue() <= 0);

      return var3;
   }

   public static int method_50(Ib var0) {
      return var0.field_30++;
   }

   public static boolean method_51(Ib var0, boolean var1) {
      return var0.field_28 = var1;
   }

   public static boolean method_52(Ib var0) {
      return var0.field_28;
   }

   public static BlockPos method_53(Ib var0, BlockPos var1) {
      return var0.field_34 = var1;
   }

   public static int method_54(Ib var0, int var1) {
      return var0.field_30 = var1;
   }

   public static Map method_55(Ib var0) {
      return var0.field_29;
   }

   public static BlockPos method_56(Ib var0) {
      return var0.field_33;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   private void method_58(BlockPos[] var1) {
      Arrays.asList(var1).forEach(this.accept<invokedynamic>(this));
   }

   public static int method_59(Ib var0) {
      return var0.field_27;
   }

   public static BlockPos method_60(Ib var0) {
      return var0.field_32;
   }

   public static BlockPos method_61(Ib var0, BlockPos var1) {
      return var0.field_33 = var1;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public void method_4326() {
      super.method_4326();
      if (field_284.world != null && field_284.player != null) {
         this.field_28 = true;
         this.field_31 = Aj.f$c();
         this.field_29 = new LinkedHashMap();
         this.field_31.values().forEach(this.accept<invokedynamic>(this));
         this.field_27 = 0;
         this.field_30 = 0;
      } else {
         this.method_2388(false);
      }
   }

   public Ib() {
      String[] var10002 = new String[7];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NoteTuner";
      var10002[1] = "NotesTuner";
      var10002[2] = "AutoTuner";
      var10002[3] = "AutoTune";
      var10002[4] = "SongTuner";
      var10002[5] = "Tuner";
      var10002[6] = "ATuner";
      super("NoteTuner", var10002, true, -6692885, bE.MISCELLANEOUS);
      ja[] var10001 = new ja[2];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new dB(this);
      var10001[1] = new rd(this);
      this.method_2383(var10001);
   }
}

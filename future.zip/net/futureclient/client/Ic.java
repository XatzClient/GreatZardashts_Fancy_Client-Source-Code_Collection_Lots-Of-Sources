package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.MobEffects;

public class Ic extends ja {
   public final Zc field_26;

   public Ic(Zc var1) {
      this.field_26 = var1;
   }

   public void method_4147(Lf var1) {
      Ic var7;
      label109: {
         Minecraft var10000;
         boolean var10001;
         label96:
         switch(cd.f$e[((oA)Zc.method_1133(this.field_26).method_3690()).ordinal()]) {
         case 1:
            var10000 = Zc.method_3769();
            var10001 = false;
            var10000.player.motionX = 0.0D;
            Zc.method_3747().player.motionY = 0.0D;
            Zc.method_3745().player.motionZ = 0.0D;
            EntityPlayerSP var6;
            if ((Boolean)Zc.method_1113(this.field_26).method_3690()) {
               var6 = Zc.method_3757().player;
               var6.motionY -= Zc.method_1152(this.field_26).method_3692().doubleValue();
            }

            gb var2 = (gb)YH.method_1211().method_1205().method_2166(gb.class);
            if (Zc.method_3761().inGameHasFocus || var2 != null && var2.f$c() && (Boolean)var2.field_1407.method_3690()) {
               if (Zc.method_3767().player.movementInput.jump) {
                  var6 = Zc.method_4296().player;
                  var6.motionY += 1.3262473694E-314D;
               }

               if (Zc.method_4301().player.movementInput.sneak) {
                  var6 = Zc.method_4288().player;
                  var6.motionY -= 1.3262473694E-314D;
                  var7 = this;
                  break label109;
               }
               break;
            }
         case 2:
            switch(cd.f$G[var1.method_326().ordinal()]) {
            case 1:
               var10000 = Zc.method_4291();
               var10001 = false;
               if (!var10000.player.onGround) {
                  if (!Zc.method_4292().player.movementInput.jump) {
                     if ((Zc.method_4298().player.movementInput.forwardKeyDown || Zc.method_4294().player.movementInput.backKeyDown || Zc.method_4300().player.movementInput.leftKeyDown || Zc.method_4299().player.movementInput.rightKeyDown) && !Zc.method_4297().player.movementInput.sneak) {
                        Zc.method_1119(this.field_26, Zc.method_1117(this.field_26) + 1);
                        if (Zc.method_1117(this.field_26) >= 11) {
                           Zc.method_4285().player.jumpMovementFactor = 0.7F;
                           Zc.method_4284().player.jump();
                           Zc.method_1119(this.field_26, 0);
                        }
                     }
                  } else if (!Zc.method_4286().player.movementInput.sneak) {
                     Zc.method_1119(this.field_26, Zc.method_1117(this.field_26) + 1);
                     if (Zc.method_1117(this.field_26) >= 4) {
                        Zc.method_4293().player.jumpMovementFactor = 0.01F;
                        Zc.method_4287().player.jump();
                        Zc.method_1119(this.field_26, 0);
                     }
                  }
               }
            default:
               break label96;
            }
         case 3:
            switch(cd.f$G[var1.method_326().ordinal()]) {
            case 1:
               Lf var5;
               label72: {
                  var10000 = Zc.method_4250();
                  var10001 = false;
                  var10000.player.motionY = 0.0D;
                  if (!fI.f$E()) {
                     double var3 = 1.8748963413E-314D + 1.8748963413E-314D * (1.0D + (double)Zc.method_1124(this.field_26).nextInt(1 + (Zc.method_1124(this.field_26).nextBoolean() ? Zc.method_1124(this.field_26).nextInt(34) : Zc.method_1124(this.field_26).nextInt(43))));
                     if (Zc.method_4295().player.ticksExisted % 2 == 0) {
                        var1.method_4038(Zc.method_4282().player.posY + var3);
                        var5 = var1;
                        break label72;
                     }

                     var1.method_4038(Zc.method_4290().player.posY);
                  }

                  var5 = var1;
               }

               if (var5.method_1730() != var1.method_317()) {
                  Zc.method_4289().player.setPosition(Zc.method_4272().player.posX, var1.method_1730(), Zc.method_4244().player.posZ);
               }
            }
         }

         var7 = this;
      }

      if ((Boolean)Zc.method_1138(var7.field_26).method_3690() && Zc.method_1123(this.field_26, Zc.method_1134(this.field_26) + 1) >= 12 && !Zc.method_4283().player.isPotionActive(MobEffects.LEVITATION) && !Zc.method_4243().player.isElytraFlying() && Zc.method_4271().world.getCollisionBoxes(Zc.method_4280().player, Zc.method_4279().player.getEntityBoundingBox().grow(0.0D).expand(0.0D, 1.273197475E-314D, 0.0D)).isEmpty()) {
         var1.method_4038(var1.method_1730() - 1.155044749E-314D);
         var1.method_3481(true);
         if (Zc.method_1134(this.field_26) >= 22) {
            Zc.method_1123(this.field_26, 0);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }
}

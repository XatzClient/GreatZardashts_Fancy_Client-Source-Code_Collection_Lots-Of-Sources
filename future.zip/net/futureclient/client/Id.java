package net.futureclient.client;

public class Id extends ja {
   public final bB field_2;

   public Id(bB var1) {
      this.field_2 = var1;
   }

   public void method_4183(Xe var1) {
      if (bB.method_2814(this.field_2).method_817(800L)) {
         if (bB.method_2818(this.field_2).method_3690() == Qd.Solid) {
            if (EI.method_872().fallDistance > 3.0F) {
               return;
            }

            if ((bB.method_4242().player.isInLava() || bB.method_4269().player.isInWater()) && !bB.method_4315().player.isSneaking()) {
               EI.method_872().motionY = 1.273197475E-314D;
               return;
            }

            if (fI.f$c() && !bB.method_4319().player.isSneaking()) {
               EI.method_872().motionY = 1.273197475E-314D;
            }
         }

      }
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

package net.futureclient.client;

public class Ie extends CD {
}

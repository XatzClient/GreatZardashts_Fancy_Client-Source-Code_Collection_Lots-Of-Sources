package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;

public class If extends ka {
   private boolean field_5;
   private U field_6;
   private t field_7;
   private EG field_8;
   private ga field_9;
   private t field_10;

   private boolean method_9(ItemArmor var1) {
      return var1.armorType == EntityEquipmentSlot.HEAD;
   }

   public static Minecraft method_4242() {
      return field_284;
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   public static t method_12(If var0) {
      return var0.field_10;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   private boolean method_14(ItemArmor var1) {
      return var1.armorType == EntityEquipmentSlot.LEGS;
   }

   public static boolean method_15(If var0, boolean var1) {
      return var0.field_5 = var1;
   }

   private void method_16(int var1, boolean var2) {
      field_284.playerController.windowClick(field_284.player.inventoryContainer.windowId, var1, 0, var2 ? ClickType.QUICK_MOVE : ClickType.PICKUP, field_284.player);
   }

   public static void method_17(If var0, int var1, boolean var2) {
      var0.method_16(var1, var2);
   }

   private boolean method_18(ItemArmor var1) {
      return var1.armorType == EntityEquipmentSlot.FEET;
   }

   public static boolean method_19(If var0, byte var1) {
      return var0.method_30(var1);
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   private boolean method_21(ItemArmor var1, byte var2) {
      return var2 == 5 && this.method_9(var1) || var2 == 6 && this.method_25(var1) || var2 == 7 && this.method_14(var1) || var2 == 8 && this.method_18(var1);
   }

   public static EG method_22(If var0) {
      return var0.field_8;
   }

   public static U method_23(If var0) {
      return var0.field_6;
   }

   public static t method_24(If var0) {
      return var0.field_7;
   }

   private boolean method_25(ItemArmor var1) {
      return var1.armorType == EntityEquipmentSlot.CHEST;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   private boolean method_30(byte var1) {
      if (this.field_5) {
         return false;
      } else {
         byte var3;
         byte var10000;
         if ((Boolean)this.field_7.method_3690() && var1 == 6) {
            if (field_284.player.inventoryContainer.getSlot(var1).getStack().getItem() instanceof ItemElytra) {
               return false;
            }

            for(var10000 = var3 = 9; var10000 <= 44; var10000 = ++var3) {
               ItemStack var4;
               if ((var4 = field_284.player.inventoryContainer.getSlot(var3).getStack()) != ItemStack.EMPTY && var4.getItem() instanceof ItemElytra && var4.getCount() == 1 && var4.getMaxDamage() - var4.getItemDamage() > 5) {
                  boolean var5 = field_284.player.inventoryContainer.getSlot(var1).getStack() == ItemStack.EMPTY;
                  if (!var5) {
                     this.method_16(var1, false);
                  }

                  this.method_16(var3, true);
                  if (!var5) {
                     this.method_16(var3, false);
                  }

                  return true;
               }
            }
         }

         int var2 = -1;
         var3 = -1;
         ItemArmor var9 = null;
         String var10;
         switch(ne.f$e[((Gg)this.field_9.method_3690()).ordinal()]) {
         case 1:
            boolean var10001 = false;
            var10 = y.f$c(":\u00149\u000b,'(\n7\f=\u001b,\u00117\u0016");
            break;
         case 2:
         default:
            var10 = "protection";
         }

         if (field_284.player.inventoryContainer.getSlot(var1).getStack() != ItemStack.EMPTY && field_284.player.inventoryContainer.getSlot(var1).getStack().getItem() instanceof ItemArmor) {
            var2 = (var9 = (ItemArmor)field_284.player.inventoryContainer.getSlot(var1).getStack().getItem()).damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantment.getEnchantmentByLocation(var10), field_284.player.inventoryContainer.getSlot(var1).getStack());
         }

         byte var6;
         for(var10000 = var6 = 9; var10000 <= 44; var10000 = ++var6) {
            ItemStack var7;
            if ((var7 = field_284.player.inventoryContainer.getSlot(var6).getStack()) != ItemStack.EMPTY && var7.getItem() instanceof ItemArmor && var7.getCount() == 1) {
               ItemArmor var8 = (ItemArmor)var7.getItem();
               int var12 = var8.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantment.getEnchantmentByLocation(var10), var7);
               if (this.method_21(var8, var1) && (var9 == null || var2 < var12)) {
                  var2 = var12;
                  var9 = var8;
                  var3 = var6;
               }
            }
         }

         if (var3 != -1) {
            boolean var11 = field_284.player.inventoryContainer.getSlot(var1).getStack() == ItemStack.EMPTY;
            if (!var11) {
               this.method_16(var1, false);
            }

            this.method_16(var3, true);
            if (!var11) {
               this.method_16(var3, false);
            }

            return true;
         } else {
            return false;
         }
      }
   }

   public If() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoArmor";
      var10002[1] = "aa";
      var10002[2] = "armor";
      super("AutoArmor", var10002, true, -5385072, bE.COMBAT);
      Boolean var3 = false;
      String[] var5 = new String[8];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Open Inventory";
      var5[1] = "OpenInventory";
      var5[2] = "Open";
      var5[3] = "Inv";
      var5[4] = "Inventory";
      var5[5] = "OpenInv";
      var5[6] = "OE";
      var5[7] = "I";
      this.field_10 = new t(var3, var5);
      var3 = false;
      var5 = new String[4];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Elytra Priority";
      var5[1] = "ElytraPriority";
      var5[2] = "Elytra";
      var5[3] = "EP";
      this.field_7 = new t(var3, var5);
      Float var4 = 0.35F;
      Float var8 = 0.0F;
      Float var9 = 1.0F;
      Double var10 = 5.941588215E-315D;
      String[] var10007 = new String[2];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Delay";
      var10007[1] = "D";
      this.field_6 = new U(var4, var8, var9, var10, var10007);
      Gg var6 = Gg.Prot;
      var5 = new String[3];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Priority";
      var5[1] = "Prior";
      var5[2] = "P";
      this.field_9 = new ga(var6, var5);
      this.field_8 = new EG();
      this.field_5 = false;
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_9;
      var10001[1] = this.field_7;
      var10001[2] = this.field_10;
      var10001[3] = this.field_6;
      this.method_626(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var7 = 1;
      var1[0] = new ID(this);
      this.method_2383(var1);
   }
}

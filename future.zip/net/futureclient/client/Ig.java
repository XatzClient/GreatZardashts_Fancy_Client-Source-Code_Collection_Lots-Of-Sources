package net.futureclient.client;

public final class Ig extends CD {
   private int field_4 = 1;

   public int method_3981() {
      return this.field_4;
   }

   public void method_2353(int var1) {
      this.field_4 = var1;
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class JA extends ka {
   private t field_23;
   private U field_24;

   public static Minecraft method_4315() {
      return field_284;
   }

   public static t method_34(JA var0) {
      return var0.field_23;
   }

   public static U method_35(JA var0) {
      return var0.field_24;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public JA() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "HighJump";
      var10002[1] = "AACHighJump";
      var10002[2] = "AACJump";
      super("HighJump", var10002, true, -11127454, bE.MOVEMENT);
      Boolean var3 = false;
      String[] var6 = new String[6];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "InAir";
      var6[1] = "Air";
      var6[2] = "OnGroundOnly";
      var6[3] = "OnGround";
      var6[4] = "GroundOnly";
      var6[5] = "Ground";
      this.field_23 = new t(var3, var6);
      Double var4 = 1.4429571377E-314D;
      Double var7 = 0.0D;
      Double var8 = 1.0D;
      String[] var9 = new String[7];
      boolean var10007 = true;
      byte var10008 = 1;
      var9[0] = "Height";
      var9[1] = "Heigh";
      var9[2] = "Hight";
      var9[3] = "High";
      var9[4] = "Size";
      var9[5] = "Scaling";
      var9[6] = "Scale";
      this.field_24 = new U(var4, var7, var8, var9);
      t[] var10001 = new t[2];
      boolean var2 = true;
      byte var5 = 1;
      var10001[0] = this.field_23;
      var10001[1] = this.field_24;
      this.method_626(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var5 = 1;
      var1[0] = new jd(this);
      this.method_2383(var1);
   }
}

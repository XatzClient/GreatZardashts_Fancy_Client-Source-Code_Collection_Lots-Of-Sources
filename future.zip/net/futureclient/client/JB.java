package net.futureclient.client;

public enum JB {
   GayHop,
   PhysicsCalc;

   private static final JB[] field_13;
   Vhop,
   OnGround,
   Strafe,
   LowHop,
   Bhop,
   OnGroundOld,
   Alerithe,
   Vanilla;

   static {
      JB[] var10000 = new JB[10];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = OnGroundOld;
      var10000[1] = OnGround;
      var10000[2] = GayHop;
      var10000[3] = Bhop;
      var10000[4] = Vhop;
      var10000[5] = LowHop;
      var10000[6] = Alerithe;
      var10000[7] = Strafe;
      var10000[8] = PhysicsCalc;
      var10000[9] = Vanilla;
      field_13 = var10000;
   }
}

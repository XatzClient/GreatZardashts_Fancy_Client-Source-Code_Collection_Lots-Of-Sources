package net.futureclient.client;

import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;

public class JC extends ja {
   public final aB field_35;

   public JC(aB var1) {
      this.field_35 = var1;
   }

   public void method_4183(Xe var1) {
      Class var2;
      if ((var2 = aB.method_4281().player.movementInput.getClass()) == MovementInputFromOptions.class || var2 == MovementInput.class) {
         aB.method_3425().updatePlayerMoveState();
         aB.method_4242().player.movementInput = aB.method_3425();
      }

   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

package net.futureclient.client;

import java.util.Random;
import java.util.Map.Entry;

public class JD extends ja {
   public final He field_25;

   public JD(He var1) {
      this.field_25 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (He.method_92(this.field_25).isEmpty() && He.method_103(this.field_25).isEmpty() && He.method_96(this.field_25).isEmpty()) {
         He.method_89(this.field_25).method_814();
      }

      if (He.method_4242().world != null || He.method_4269().player != null) {
         if (!He.method_103(this.field_25).isEmpty()) {
            if (He.method_89(this.field_25).method_817(9000L)) {
               He.method_95(this.field_25, (new StringBuilder()).insert(0, "I just mined ").append(He.method_103(this.field_25).get(((Entry)He.method_103(this.field_25).entrySet().iterator().next()).getKey())).append(" ").append((String)((Entry)He.method_103(this.field_25).entrySet().iterator().next()).getKey()).append("!").toString());
               He.method_103(this.field_25).remove(((Entry)He.method_103(this.field_25).entrySet().iterator().next()).getKey());
               He.method_89(this.field_25).method_814();
               return;
            }
         } else {
            JD var10000;
            label73: {
               He.method_103(this.field_25).clear();
               if (!He.method_92(this.field_25).isEmpty()) {
                  if (He.method_89(this.field_25).method_817(9000L)) {
                     He.method_95(this.field_25, (new StringBuilder()).insert(0, "I just placed ").append(He.method_92(this.field_25).get(((Entry)He.method_92(this.field_25).entrySet().iterator().next()).getKey())).append(" ").append((String)((Entry)He.method_92(this.field_25).entrySet().iterator().next()).getKey()).append("!").toString());
                     He.method_92(this.field_25).remove(((Entry)He.method_92(this.field_25).entrySet().iterator().next()).getKey());
                     He.method_89(this.field_25).method_814();
                     var10000 = this;
                     break label73;
                  }
               } else {
                  He.method_92(this.field_25).clear();
               }

               var10000 = this;
            }

            label68: {
               if (!He.method_96(var10000.field_25).isEmpty()) {
                  if (He.method_89(this.field_25).method_817(9000L)) {
                     He.method_95(this.field_25, (new StringBuilder()).insert(0, "I just ate ").append(He.method_96(this.field_25).get(((Entry)He.method_96(this.field_25).entrySet().iterator().next()).getKey())).append(" ").append((String)((Entry)He.method_96(this.field_25).entrySet().iterator().next()).getKey()).append("!").toString());
                     He.method_96(this.field_25).remove(((Entry)He.method_96(this.field_25).entrySet().iterator().next()).getKey());
                     He.method_89(this.field_25).method_814();
                     var10000 = this;
                     break label68;
                  }
               } else {
                  He.method_96(this.field_25).clear();
               }

               var10000 = this;
            }

            if ((Boolean)He.method_88(var10000.field_25).method_3690() && He.method_93(this.field_25).method_817(60000L)) {
               double var2;
               if ((var2 = (double)Math.round(((double)Math.round((double)He.method_4315().world.getWorldInfo().getWorldTime() / 0.0D * 0.0D) / 0.0D - (double)Math.round((float)(He.method_4319().world.getWorldInfo().getWorldTime() / 24000L))) * 0.0D) / 0.0D) == 0.0D) {
                  He.method_95(this.field_25, He.method_112(this.field_25)[(new Random()).nextInt(He.method_112(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
                  return;
               }

               if (var2 == 4.75327057E-315D) {
                  He.method_95(this.field_25, He.method_110(this.field_25)[(new Random()).nextInt(He.method_110(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
                  return;
               }

               if (var2 == 0.0D) {
                  He.method_95(this.field_25, He.method_87(this.field_25)[(new Random()).nextInt(He.method_87(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
                  return;
               }

               if (var2 == 2.885914274E-315D) {
                  He.method_95(this.field_25, He.method_118(this.field_25)[(new Random()).nextInt(He.method_118(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
                  return;
               }

               if (var2 == 4.07423192E-315D) {
                  He.method_95(this.field_25, He.method_84(this.field_25)[(new Random()).nextInt(He.method_84(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
                  return;
               }

               if (var2 == 8.48798316E-315D) {
                  He.method_95(this.field_25, He.method_104(this.field_25)[(new Random()).nextInt(He.method_104(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
                  return;
               }

               if (var2 == 0.0D) {
                  He.method_95(this.field_25, He.method_91(this.field_25)[(new Random()).nextInt(He.method_91(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
                  return;
               }

               if (var2 == 1.0694858786E-314D) {
                  He.method_95(this.field_25, He.method_97(this.field_25)[(new Random()).nextInt(He.method_97(this.field_25).length)]);
                  He.method_93(this.field_25).method_814();
               }
            }
         }

      }
   }
}

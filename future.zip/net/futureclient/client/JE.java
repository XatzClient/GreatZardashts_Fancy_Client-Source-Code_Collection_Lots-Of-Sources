package net.futureclient.client;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.util.EnumHand;

public class JE extends ja {
   public final ge field_3;

   public JE(ge var1) {
      this.field_3 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4311((yD)var1);
   }

   public void method_4311(yD var1) {
      ge var10000 = this.field_3;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = this.field_3.method_4078();
      var10000.f$D(String.format("AutoTotem §7[§F%s§7]", var10002));
      if (!this.field_3.field_1419) {
         ge.method_3545(this.field_3).method_814();
      }

      int var2;
      if ((!(ge.method_4279().currentScreen instanceof GuiContainer) || ge.method_4271().currentScreen instanceof GuiInventory) && ge.method_4278().player.getHeldItem(EnumHand.OFF_HAND).getItem() != Items.TOTEM_OF_UNDYING && !ge.method_4275().player.isCreative()) {
         for(int var3 = var2 = 44; var3 >= 9; var3 = var2) {
            if (ge.method_4277().player.inventoryContainer.getSlot(var2).getStack().getItem() == Items.TOTEM_OF_UNDYING) {
               this.field_3.field_1419 = true;
               if (ge.method_3545(this.field_3).method_811(this.field_3.field_1418.method_3692().floatValue() * 1000.0F) && ge.method_4270().player.inventory.getItemStack().getItem() != Items.TOTEM_OF_UNDYING) {
                  ge.method_4273().playerController.windowClick(0, var2, 0, ClickType.PICKUP, ge.method_4267().player);
               }

               if (ge.method_3545(this.field_3).method_811(this.field_3.field_1418.method_3692().floatValue() * 2000.0F) && ge.method_4276().player.inventory.getItemStack().getItem() == Items.TOTEM_OF_UNDYING) {
                  ge.method_4245().playerController.windowClick(0, 45, 0, ClickType.PICKUP, ge.method_4274().player);
                  if (ge.method_4281().player.inventory.getItemStack().isEmpty()) {
                     this.field_3.field_1419 = false;
                     return;
                  }
               }

               if (ge.method_3545(this.field_3).method_811(this.field_3.field_1418.method_3692().floatValue() * 3000.0F) && !ge.method_4242().player.inventory.getItemStack().isEmpty() && ge.method_4269().player.getHeldItem(EnumHand.OFF_HAND).getItem() == Items.TOTEM_OF_UNDYING) {
                  ge.method_4319().playerController.windowClick(0, var2, 0, ClickType.PICKUP, ge.method_4315().player);
                  this.field_3.field_1419 = false;
                  return;
               }
            }

            --var2;
         }
      }

   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayerDigging;

public class JF extends ja {
   public final He field_1;

   public JF(He var1) {
      this.field_1 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }

   public void method_4241(je var1) {
      if ((Boolean)He.method_83(this.field_1).method_3690() && var1.method_3084() instanceof CPacketPlayerDigging) {
         switch(TF.f$e[((CPacketPlayerDigging)var1.method_3084()).getAction().ordinal()]) {
         case 1:
            boolean var10001 = false;
            He var10000 = this.field_1;

            Exception var5;
            label43: {
               try {
                  if (He.method_103(var10000).containsKey(He.method_4276().world.getBlockState(((CPacketPlayerDigging)var1.method_3084()).getPosition()).getBlock().getLocalizedName())) {
                     He.method_103(this.field_1).put(He.method_4274().world.getBlockState(((CPacketPlayerDigging)var1.method_3084()).getPosition()).getBlock().getLocalizedName(), (Integer)He.method_103(this.field_1).get(He.method_4245().world.getBlockState(((CPacketPlayerDigging)var1.method_3084()).getPosition()).getBlock().getLocalizedName()) + 1);
                     return;
                  }
               } catch (Exception var4) {
                  var5 = var4;
                  var10001 = false;
                  break label43;
               }

               var10000 = this.field_1;

               try {
                  He.method_103(var10000).put(He.method_4281().world.getBlockState(((CPacketPlayerDigging)var1.method_3084()).getPosition()).getBlock().getLocalizedName(), 1);
                  return;
               } catch (Exception var3) {
                  var5 = var3;
                  var10001 = false;
               }
            }

            Exception var2 = var5;
            var2.printStackTrace();
         }
      }

   }
}

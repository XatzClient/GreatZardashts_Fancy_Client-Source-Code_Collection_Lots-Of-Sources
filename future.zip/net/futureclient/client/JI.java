package net.futureclient.client;

public abstract class JI {
   private final String field_0;

   public JI(String var1) {
      this.field_0 = var1;
   }

   public abstract iH method_0();
}

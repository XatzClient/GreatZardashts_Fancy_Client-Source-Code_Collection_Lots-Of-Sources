package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.math.MathHelper;

public class Jb extends ja {
   public final qc field_107;

   public Jb(qc var1) {
      this.field_107 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      if (qc.method_3770().player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() == Items.ELYTRA) {
         float var2;
         switch(rc.f$e[((Zb)this.field_107.field_1517.method_3690()).ordinal()]) {
         case 1:
            Minecraft var5 = qc.method_3772();
            boolean var10001 = false;
            if (var5.player.isElytraFlying() && (Boolean)this.field_107.field_1531.method_3690() && qc.method_3771().player.isInWater()) {
               qc.method_3759().player.connection.sendPacket(new CPacketEntityAction(qc.method_3775().player, Action.START_FALL_FLYING));
               return;
            }

            if (qc.method_3774().player.movementInput.jump || !qc.method_3776().inGameHasFocus && qc.method_3752().player.isElytraFlying()) {
               var1.method_1726(0.0D);
            }

            if (qc.method_3773().inGameHasFocus && (Boolean)this.field_107.field_1529.method_3690() && qc.method_3769().player.movementInput.jump && !qc.method_3747().player.isElytraFlying() && qc.method_3722(this.field_107).method_817(1000L)) {
               qc.method_3745().player.setJumping(false);
               qc.method_3757().player.setSprinting(true);
               qc.method_3761().player.jump();
               qc.method_4296().player.connection.sendPacket(new CPacketEntityAction(qc.method_3767().player, Action.START_FALL_FLYING));
               qc.method_3722(this.field_107).method_814();
               return;
            }
            break;
         case 2:
            if (qc.method_4301().player.onGround && (Boolean)this.field_107.field_1522.method_3690()) {
               break;
            }

            if ((Boolean)this.field_107.field_1520.method_3690()) {
               if (qc.method_3725(this.field_107)) {
                  qc.method_3726(this.field_107, 1.0D);
                  qc.method_3718(this.field_107, false);
               }

               if (qc.method_3720(this.field_107) < qc.method_3715(this.field_107).method_3692().doubleValue()) {
                  qc.method_3726(this.field_107, qc.method_3720(this.field_107) + 1.273197475E-314D);
               }

               if (qc.method_3720(this.field_107) - 1.273197475E-314D > qc.method_3715(this.field_107).method_3692().doubleValue()) {
                  qc.method_3726(this.field_107, qc.method_3720(this.field_107) - 1.273197475E-314D);
               }
            } else {
               qc.method_3726(this.field_107, qc.method_3715(this.field_107).method_3692().doubleValue());
            }

            Jb var3;
            label166: {
               if (!EI.method_852() && !qc.method_4288().player.collided && (Boolean)this.field_107.field_1534.method_3690()) {
                  if (qc.method_3722(this.field_107).method_817(1000L)) {
                     qc.method_3718(this.field_107, true);
                     var3 = this;
                     qc.method_3724(this.field_107, qc.method_3721(this.field_107) + 1);
                     EntityPlayerSP var10003 = qc.method_4291().player;
                     var10003.motionX += 1.9522361275E-314D * Math.sin(Math.toRadians((double)(qc.method_3721(this.field_107) * 4)));
                     var10003 = qc.method_4292().player;
                     var10003.motionZ += 1.9522361275E-314D * Math.cos(Math.toRadians((double)(qc.method_3721(this.field_107) * 4)));
                     break label166;
                  }
               } else {
                  qc.method_3722(this.field_107).method_814();
                  qc.method_3718(this.field_107, false);
               }

               var3 = this;
            }

            VF var4;
            if ((Boolean)var3.field_107.field_1533.method_3690() && qc.method_4298().player.movementInput.jump) {
               var1.method_1726(qc.method_4294().player.motionY = qc.method_3723(this.field_107).method_3692().doubleValue());
               var4 = var1;
            } else if (qc.method_4300().player.movementInput.sneak) {
               var1.method_1726(qc.method_4299().player.motionY = -qc.method_3723(this.field_107).method_3692().doubleValue());
               var4 = var1;
            } else if ((Boolean)this.field_107.field_1530.method_3690()) {
               if (qc.method_4297().player.ticksExisted % 32 != 0 || qc.method_3725(this.field_107) || Math.abs(var1.method_1730()) < 1.273197475E-314D && Math.abs(var1.method_4037()) < 1.273197475E-314D) {
                  var1.method_1726(qc.method_4284().player.motionY = 1.9488409346E-314D);
                  var4 = var1;
               } else {
                  qc.method_3726(this.field_107, qc.method_3720(this.field_107) - qc.method_3720(this.field_107) / 0.0D * 1.273197475E-314D);
                  qc.method_4285().player.motionY = 1.9488409346E-314D;
                  var1.method_1726(1.7553149187E-314D);
                  var4 = var1;
               }
            } else {
               var1.method_1726(qc.method_4286().player.motionY = 0.0D);
               var4 = var1;
            }

            var4.method_1731(var1.method_1730() * (qc.method_3725(this.field_107) ? 0.0D : qc.method_3720(this.field_107)));
            var1.method_4038(var1.method_4037() * (qc.method_3725(this.field_107) ? 0.0D : qc.method_3720(this.field_107)));
            return;
         case 3:
            if (qc.method_4293().player.isElytraFlying() && (Boolean)this.field_107.field_1531.method_3690() && qc.method_4287().player.isInWater()) {
               qc.method_4295().player.connection.sendPacket(new CPacketEntityAction(qc.method_4250().player, Action.START_FALL_FLYING));
               return;
            }

            if (qc.method_4282().player.movementInput.jump && qc.method_4290().player.isElytraFlying()) {
               var2 = qc.method_4272().player.rotationYaw * 0.017453292F;
               EntityPlayerSP var10000 = qc.method_4244().player;
               var10000.motionX -= (double)(MathHelper.sin(var2) * 0.15F);
               var10000 = qc.method_4289().player;
               var10000.motionZ += (double)(MathHelper.cos(var2) * 0.15F);
               return;
            }
            break;
         case 4:
            if (qc.method_4283().player.isElytraFlying()) {
               if (!qc.method_4243().player.movementInput.forwardKeyDown && !qc.method_4280().player.movementInput.sneak) {
                  qc.method_4270().player.motionX = 0.0D;
                  qc.method_4267().player.motionY = 0.0D;
                  qc.method_4273().player.motionZ = 0.0D;
               } else if (qc.method_4279().player.movementInput.forwardKeyDown && ((Boolean)this.field_107.field_1533.method_3690() || qc.method_4271().player.prevRotationPitch > 0.0F)) {
                  var2 = (float)Math.toRadians((double)qc.method_4278().player.rotationYaw);
                  qc.method_4275().player.motionX = (double)MathHelper.sin(var2) * -(qc.method_3715(this.field_107).method_3692().doubleValue() / 0.0D);
                  qc.method_4277().player.motionZ = (double)MathHelper.cos(var2) * (qc.method_3715(this.field_107).method_3692().doubleValue() / 0.0D);
                  return;
               }
            }
         }

      }
   }
}

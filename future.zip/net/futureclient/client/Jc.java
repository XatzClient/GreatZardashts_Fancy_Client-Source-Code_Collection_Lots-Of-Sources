package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;

public class Jc extends ja {
   public final KC field_143;

   public Jc(KC var1) {
      this.field_143 = var1;
   }

   public void method_4183(Xe var1) {
      KC.method_181(this.field_143);
      if (KC.method_171(this.field_143) > 0) {
         KC.method_182(this.field_143);
      } else {
         if (!KC.method_172(this.field_143)) {
            KC.method_177(this.field_143).remove(KC.method_175(this.field_143));
            KC.method_176(this.field_143, true);
         }

         if (!(Boolean)KC.method_174(this.field_143).method_3690() || KC.method_4271().player.onGround) {
            if (KC.method_4278().currentScreen == null) {
               Iterator var2 = KC.method_4275().world.loadedTileEntityList.iterator();

               TileEntity var3;
               label57:
               do {
                  Iterator var10000 = var2;

                  while(true) {
                     while(var10000.hasNext()) {
                        if (!((var3 = (TileEntity)var2.next()) instanceof TileEntityChest) && !(var3 instanceof TileEntityEnderChest)) {
                           var10000 = var2;
                        } else {
                           if (!KC.method_177(this.field_143).contains(var3.getPos())) {
                              continue label57;
                           }

                           var10000 = var2;
                        }
                     }

                     return;
                  }
               } while(var3.getDistanceSq(KC.method_4277().player.posX, KC.method_4270().player.posY + (double)KC.method_4267().player.getEyeHeight(), KC.method_4273().player.posZ) > (double)(KC.method_173(this.field_143).method_3692().floatValue() * KC.method_173(this.field_143).method_3692().floatValue()));

               fI.f$c(var3.getPos());
               KC.method_4245().playerController.processRightClickBlock(KC.method_4276().player, KC.method_4274().world, var3.getPos(), EnumFacing.UP, new Vec3d(0.0D, 0.0D, 0.0D), EnumHand.MAIN_HAND);
               KC.method_180(this.field_143, KC.method_4281().getConnection() != null && KC.method_4269().getConnection().getPlayerInfo(KC.method_4242().player.getUniqueID()) != null ? KC.method_4319().getConnection().getPlayerInfo(KC.method_4315().player.getUniqueID()).getResponseTime() + 2 : 0);
               KC.method_178(this.field_143, var3.getPos());
               KC.method_176(this.field_143, false);
               KC.method_177(this.field_143).add(KC.method_175(this.field_143));
            }
         }
      }
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

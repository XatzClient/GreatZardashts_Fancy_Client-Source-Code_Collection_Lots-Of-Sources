package net.futureclient.client;

public class Jd extends ja {
   public final ac field_109;

   public Jd(ac var1) {
      this.field_109 = var1;
   }

   public void method_199(af var1) {
      var1.f$c(((BA)ac.method_3027(this.field_109).method_3690()).equals(BA.Hide));
   }

   public void method_4312(CD var1) {
      this.method_199((af)var1);
   }
}

package net.futureclient.client;

public class Je extends CD {
   private float field_92;

   public Je(float var1) {
      this.field_92 = var1;
   }

   public float method_3117() {
      return this.field_92;
   }

   public void method_3094(float var1) {
      this.field_92 = var1;
   }
}

package net.futureclient.client;

public enum Jg {
   Down,
   Up;

   private static final Jg[] field_98;

   static {
      Jg[] var10000 = new Jg[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Up;
      var10000[1] = Down;
      field_98 = var10000;
   }
}

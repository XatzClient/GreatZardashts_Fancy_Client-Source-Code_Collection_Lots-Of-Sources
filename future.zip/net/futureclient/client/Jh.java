package net.futureclient.client;

public class Jh {
   public double field_93;
   public double field_94;
   public double field_95;

   public Jh(double var1, double var3, double var5) {
      this.field_94 = var1;
      this.field_93 = var3;
      this.field_95 = var5;
   }

   public boolean equals(Object var1) {
      if (var1 instanceof Jh) {
         Jh var2;
         return Double.compare((var2 = (Jh)var1).field_94, this.field_94) == 0 && Double.compare(var2.field_93, this.field_93) == 0 && Double.compare(var2.field_95, this.field_95) == 0;
      } else {
         return super.equals(var1);
      }
   }

   public double method_163() {
      return this.field_93;
   }

   public double method_164() {
      return this.field_95;
   }

   public double method_165(Jh var1) {
      double var2 = this.field_94 - var1.field_94;
      double var4 = this.field_93 - var1.field_93;
      double var6 = this.field_95 - var1.field_95;
      return Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
   }

   public double method_166() {
      return this.field_94;
   }
}

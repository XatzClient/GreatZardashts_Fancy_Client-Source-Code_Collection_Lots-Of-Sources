package net.futureclient.client;

import java.io.File;
import net.minecraft.util.text.TextFormatting;
import org.apache.commons.io.FilenameUtils;

public class KA extends xb {
   public final vb field_144;

   public KA(vb var1, String[] var2) {
      super(var2);
      this.field_144 = var1;
   }

   public String method_4224() {
      return "&e[name]";
   }

   public String method_4228(String[] var1) {
      if (var1.length < 1) {
         return null;
      } else {
         StringBuilder var2 = new StringBuilder();
         String[] var3 = var1;
         int var4 = var1.length;

         int var5;
         int var10000;
         for(var10000 = var5 = 0; var10000 < var4; var10000 = var5) {
            String var6 = var3[var5];
            var2.append(var6);
            ++var5;
            var2.append(" ");
         }

         String var11;
         String var12 = (var11 = var2.toString().trim()).replaceAll("[ _\\-']", "").toLowerCase();
         File[] var13;
         if ((var13 = vb.method_4017(this.field_144).listFiles()) == null) {
            vb.method_4020(this.field_144);
            return TI.f$c("=\u001fS\u0003\u001c\u001e\u0014\u0003S\u0016\u001c\u0005\u001d\u0014R");
         } else {
            File[] var14 = var13;
            int var10 = var13.length;

            Object[] var10001;
            boolean var10002;
            byte var10003;
            for(var10000 = var5 = 0; var10000 < var10; var10000 = var5) {
               File var7 = var14[var5];
               File var15 = var7;

               try {
                  String var8;
                  if ((var8 = FilenameUtils.getBaseName(var15.getAbsolutePath())).replaceAll("[ _\\-']", "").toLowerCase().contains(var12)) {
                     vb.method_4007(this.field_144, 0);
                     vb.method_4015(this.field_144, var8);
                     vb.method_4014(this.field_144, Rh.method_1719(var7));
                     String var16 = TI.f$c(" \u0015\u0007P\u0000\u001f\u001d\u0017S\u0004\u001cPV\u0003QU\u0000RV\u0003]");
                     var10001 = new Object[3];
                     var10002 = true;
                     var10003 = 1;
                     var10001[0] = TextFormatting.WHITE;
                     var10001[1] = var8;
                     var10001[2] = TextFormatting.GRAY;
                     return String.format(var16, var10001);
                  }
               } catch (Exception var9) {
                  return var9.toString();
               }

               ++var5;
            }

            var10001 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var10001[0] = var11;
            return String.format("Song \"%s\" not found!", var10001);
         }
      }
   }
}

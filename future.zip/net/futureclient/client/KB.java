package net.futureclient.client;

public class KB extends ja {
   public final KC field_108;

   public KB(KC var1) {
      this.field_108 = var1;
   }

   public void method_4193(ae var1) {
      KC.method_177(this.field_108).clear();
   }

   public void method_4312(CD var1) {
      this.method_4193((ae)var1);
   }
}

package net.futureclient.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.util.math.BlockPos;

public class KC extends ka {
   private int field_99;
   private U field_100;
   private boolean field_101;
   private List field_102;
   private t field_103;
   private int field_104;
   private BlockPos field_105;
   private U field_106;

   public static Minecraft method_4242() {
      return field_284;
   }

   private void method_4050() {
      if (this.field_99 > 0) {
         --this.field_99;
      } else {
         if (field_284.currentScreen instanceof GuiChest) {
            boolean var1 = false;
            int var2;
            int var10000 = var2 = field_284.player.openContainer.inventorySlots.size() - 36;

            byte var5;
            boolean var7;
            while(true) {
               if (var10000 >= field_284.player.openContainer.inventorySlots.size()) {
                  var7 = var1;
                  break;
               }

               if (!field_284.player.openContainer.getSlot(var2).getHasStack()) {
                  var7 = true;
                  var5 = 1;
                  break;
               }

               ++var2;
               var10000 = var2;
            }

            if (!var7) {
               return;
            }

            while(this.field_99 == 0) {
               boolean var6 = false;
               int var3;
               var10000 = var3 = 0;

               while(true) {
                  if (var10000 >= field_284.player.openContainer.inventorySlots.size() - 36) {
                     var7 = var6;
                     break;
                  }

                  if (field_284.player.openContainer.getSlot(var3).getHasStack()) {
                     field_284.playerController.windowClick(field_284.player.openContainer.windowId, var3, 0, ClickType.QUICK_MOVE, field_284.player);
                     this.field_99 = this.field_106.method_3692().intValue();
                     var6 = true;
                     var7 = var6;
                     break;
                  }

                  ++var3;
                  var10000 = var3;
               }

               if (!var7) {
                  field_284.displayGuiScreen((GuiScreen)null);
                  field_284.player.connection.sendPacket(new CPacketCloseWindow(field_284.player.openContainer.windowId));
                  this.field_101 = true;
                  return;
               }

               var1 = false;
               var10000 = var3 = field_284.player.openContainer.inventorySlots.size() - 36;

               while(true) {
                  if (var10000 >= field_284.player.openContainer.inventorySlots.size()) {
                     var7 = var1;
                     break;
                  }

                  if (!field_284.player.openContainer.getSlot(var3).getHasStack()) {
                     var7 = true;
                     var5 = 1;
                     break;
                  }

                  ++var3;
                  var10000 = var3;
               }

               if (!var7) {
                  return;
               }
            }
         }

      }
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static int method_171(KC var0) {
      return var0.field_104;
   }

   public static boolean method_172(KC var0) {
      return var0.field_101;
   }

   public static U method_173(KC var0) {
      return var0.field_100;
   }

   public static t method_174(KC var0) {
      return var0.field_103;
   }

   public static BlockPos method_175(KC var0) {
      return var0.field_105;
   }

   public static boolean method_176(KC var0, boolean var1) {
      return var0.field_101 = var1;
   }

   public static List method_177(KC var0) {
      return var0.field_102;
   }

   public static BlockPos method_178(KC var0, BlockPos var1) {
      return var0.field_105 = var1;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static int method_180(KC var0, int var1) {
      return var0.field_104 = var1;
   }

   public static void method_181(KC var0) {
      var0.method_4050();
   }

   public static int method_182(KC var0) {
      return --var0.field_104;
   }

   public static Minecraft method_4267() {
      return field_284;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static Minecraft method_4270() {
      return field_284;
   }

   public static Minecraft method_4271() {
      return field_284;
   }

   public static Minecraft method_4273() {
      return field_284;
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static Minecraft method_4275() {
      return field_284;
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static Minecraft method_4277() {
      return field_284;
   }

   public static Minecraft method_4278() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public void method_4326() {
      this.field_102.clear();
      super.method_4326();
   }

   public KC() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "ChestAura";
      var10002[1] = "CA";
      super("ChestAura", var10002, true, -357009, bE.MISCELLANEOUS);
      Float var3 = 4.0F;
      Float var5 = 1.0F;
      Float var10005 = 6.0F;
      Double var10006 = 1.273197475E-314D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Range";
      var10007[1] = "Reach";
      var10007[2] = "Rang";
      this.field_100 = new U(var3, var5, var10005, var10006, var10007);
      Boolean var4 = true;
      String[] var7 = new String[3];
      boolean var8 = true;
      byte var9 = 1;
      var7[0] = "Onground";
      var7[1] = "OnGroundOnly";
      var7[2] = "NeedsOnGround";
      this.field_103 = new t(var4, var7);
      this.field_102 = new ArrayList();
      var3 = 1.0F;
      var5 = 0.0F;
      var10005 = 100.0F;
      Integer var10 = 1;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Cooldown";
      var10007[1] = "CD";
      var10007[2] = "Delay";
      this.field_106 = new U(var3, var5, var10005, var10, var10007);
      this.field_101 = false;
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_100;
      var10001[1] = this.field_103;
      var10001[2] = this.field_106;
      this.method_626(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var6 = 1;
      var1[0] = new Jc(this);
      var1[1] = new KB(this);
      this.method_2383(var1);
   }
}

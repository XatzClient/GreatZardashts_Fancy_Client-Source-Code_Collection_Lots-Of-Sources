package net.futureclient.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumHand;

public class KD extends ka {
   public t field_110;
   public t field_111;
   private Entity field_112;
   public t field_113;
   public t field_114;
   public t field_115;
   public t field_116;
   public t field_117;
   public t field_118;
   public U field_119;
   public U field_120;
   public t field_121;
   public t field_122;
   public U field_123;
   public U field_124;
   private ArrayList field_125;
   public U field_126;
   private transient double field_127;
   private Entity field_128;
   public t field_129;
   public ga field_130;
   public t field_131;
   public t field_132;
   public ArrayList field_133;
   public t field_134;
   private EG field_135;
   private int field_136;
   public t field_137;
   private ga field_138;
   private ga field_139;
   public t field_140;
   public t field_141;
   private ga field_142;

   public static Minecraft method_4242() {
      return field_284;
   }

   private boolean method_202(Entity var1) {
      return var1.getEntityId() != field_284.player.getEntityId() && var1.getEntityId() <= 1000000000 && var1.getEntityId() > -1;
   }

   public void method_4314() {
      EI.method_882();
      super.method_4314();
      this.field_128 = null;
      this.field_112 = null;
      this.field_135.method_814();
      this.field_133.clear();
      this.field_125.clear();
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   private void method_4050() {
      Iterator var1 = EI.method_851().iterator();

      while(var1.hasNext()) {
         Entity var2 = (Entity)var1.next();
         if (this.method_228(var2, false)) {
            this.field_133.add(var2);
         }

         if (var2 instanceof EntityLivingBase) {
            EntityLivingBase var3 = (EntityLivingBase)var2;
            if (this.method_228(var3, true)) {
               this.field_125.add(var3);
            }
         }
      }

   }

   private static int method_206(Entity var0, Entity var1) {
      double var2 = var0 instanceof EntityLivingBase ? (double)((EntityLivingBase)var0).getHealth() : 0.0D;
      double var4 = var1 instanceof EntityLivingBase ? (double)((EntityLivingBase)var1).getHealth() : 0.0D;
      return Double.compare(var4, var2);
   }

   public static Entity method_207(KD var0, Entity var1) {
      return var0.field_128 = var1;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   private boolean method_349(Entity var1) {
      return !this.method_228(var1, true);
   }

   private void method_210(Entity var1) {
      this.field_128 = var1;
   }

   private boolean method_1748(Entity var1) {
      return !this.method_228(var1, false);
   }

   public static void method_212(KD var0, CD var1) {
      var0.method_213(var1);
   }

   private void method_213(CD var1) {
      this.field_133 = new ArrayList();
      this.field_125 = new ArrayList();
      if (this.field_128 != null && !this.method_228(this.field_128, false)) {
         this.field_128 = null;
      }

      if (this.field_112 != null && !this.method_228(this.field_112, true)) {
         this.field_112 = null;
      }

      this.method_4050();
      this.field_133.removeIf(this.test<invokedynamic>(this));
      this.field_125.removeIf(this.test<invokedynamic>(this));
      this.field_125.forEach(this.accept<invokedynamic>(this));
      KD var10000;
      switch(BF.f$e[((Ze)this.field_139.method_3690()).ordinal()]) {
      case 1:
         boolean var10001 = false;
         this.field_133.sort(compare<invokedynamic>());
         var10000 = this;
         break;
      case 2:
         this.field_133.sort(compare<invokedynamic>());
         var10000 = this;
         break;
      case 3:
         this.field_133.sort(compare<invokedynamic>());
      default:
         var10000 = this;
      }

      var10000.field_133.forEach(this.accept<invokedynamic>(this));
      if (this.method_228(this.field_128, false)) {
         gE var2;
         if ((var2 = (gE)YH.method_1211().method_1205().method_2166(gE.class)) != null && var2.field_1309) {
            return;
         }

         if (!(Boolean)this.field_114.method_3690()) {
            return;
         }

         float[] var4 = ri.method_3662(this.field_128, (Uh)this.field_142.method_3690());
         if (var1 instanceof Lf) {
            Lf var5 = (Lf)var1;
            var5.method_2096(var4[0] + (new Random()).nextFloat() * 2.0F - 1.0F);
            var5.method_3094(ri.method_3666(var4[1] + (new Random()).nextFloat() * 2.0F - 1.0F));
            return;
         }

         if (var1 instanceof WF) {
            WF var3 = (WF)var1;
            var3.method_2096(var4[0] + (new Random()).nextFloat() * 2.0F - 1.0F);
            var3.method_3094(ri.method_3666(var4[1] + (new Random()).nextFloat() * 2.0F - 1.0F));
            return;
         }
      } else {
         this.field_133.remove(this.field_128);
         this.field_128 = null;
      }

   }

   public static void method_214(KD var0) {
      var0.method_4023();
   }

   private void method_783(Entity var1) {
      this.field_112 = var1;
   }

   public Entity method_216() {
      return this.field_128;
   }

   public static ga method_217(KD var0) {
      return var0.field_138;
   }

   private static int method_218(Entity var0, Entity var1) {
      double var2 = ri.method_3661(var0);
      return Double.compare(ri.method_3661(var1), var2);
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static Entity method_220(KD var0, Entity var1) {
      return var0.field_112 = var1;
   }

   private boolean method_377(Entity var1) {
      Entity var10000 = var1;

      try {
         var10000.getName();
      } catch (ClassCastException var3) {
         return true;
      }

      if (var1.posY - field_284.player.posY > 0.0D) {
         return true;
      } else if (var1 != null && var1.ticksExisted >= this.field_120.method_3692().intValue() && var1.getName() != null) {
         return field_284.player.connection.getPlayerInfo(var1.getName()) == null;
      } else {
         return true;
      }
   }

   private static int method_222(Entity var0, Entity var1) {
      double var2 = (double)var0.getDistance(field_284.player);
      return Double.compare((double)var1.getDistance(field_284.player), var2);
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   private void method_224(Entity var1) {
      boolean var2 = field_284.player.isSneaking();
      boolean var3 = (Boolean)this.field_111.method_3690() && field_284.player.isSprinting();
      boolean var4 = field_284.player.isActiveItemStackBlocking();
      int var5;
      if ((Boolean)this.field_110.method_3690() && (var5 = EI.method_874()) != -1 && field_284.player.inventory.currentItem != var5) {
         field_284.player.connection.sendPacket(new CPacketHeldItemChange(field_284.player.inventory.currentItem = var5));
      }

      if (var2) {
         field_284.player.connection.sendPacket(new CPacketEntityAction(field_284.player, Action.STOP_SNEAKING));
      }

      if (var3) {
         field_284.player.connection.sendPacket(new CPacketEntityAction(field_284.player, Action.STOP_SPRINTING));
      }

      if (var4) {
         EI.method_882();
      }

      Entity var8;
      if ((Boolean)this.field_116.method_3690() && (var8 = (new Ah(var1, (Uh)this.field_142.method_3690())).f$c()) != this.field_128) {
         var1 = var8;
      }

      vF var9;
      if ((var9 = (vF)YH.method_1211().method_1205().method_2166(vF.class)) != null && var9.f$c() && ((BD)var9.field_1773.method_3690()).equals(BD.Hypixel)) {
         var9.method_4050();
      }

      Entity var10000;
      if ((Boolean)this.field_141.method_3690()) {
         field_284.playerController.attackEntity(field_284.player, var1);
         field_284.player.swingArm(EnumHand.MAIN_HAND);
         var10000 = var1;
      } else {
         field_284.player.connection.sendPacket(new CPacketUseEntity(var1));
         field_284.player.swingArm(EnumHand.MAIN_HAND);
         var10000 = var1;
      }

      float var6 = var10000 instanceof EntityLivingBase ? EnchantmentHelper.getModifierForCreature(field_284.player.getHeldItem(EnumHand.MAIN_HAND), ((EntityLivingBase)var1).getCreatureAttribute()) : 0.0F;
      boolean var7 = field_284.player.fallDistance > 0.0F && !field_284.player.onGround && !field_284.player.isOnLadder() && !field_284.player.isInWater() && !field_284.player.isPotionActive(MobEffects.BLINDNESS) && field_284.player.getRidingEntity() == null;
      if (var9 != null && var9.f$c() || var7) {
         field_284.player.onCriticalHit(var1);
      }

      if (var6 > 0.0F) {
         field_284.player.onEnchantmentCritical(var1);
      }

      if (var2) {
         field_284.player.connection.sendPacket(new CPacketEntityAction(field_284.player, Action.START_SNEAKING));
      }

      if (var3) {
         field_284.player.connection.sendPacket(new CPacketEntityAction(field_284.player, Action.START_SPRINTING));
      }

      if (var4) {
         EI.method_847();
      }

   }

   private void method_4023() {
      KD var10000;
      label38: {
         if (this.method_228(this.field_128, false)) {
            if (((PF)this.field_130.method_3690()).equals(PF.Switch)) {
               ++this.field_136;
               if (this.field_136 >= this.field_133.size()) {
                  this.field_136 = 0;
               }
            }

            if ((Boolean)this.field_141.method_3690()) {
               float var1 = -(20.0F - YH.method_1211().method_1204().method_131());
               if (field_284.player.getCooledAttackStrength(0.5F + var1) >= 1.0F) {
                  this.method_224(this.field_128);
               }
            } else if (this.field_135.method_815(this.field_127)) {
               this.method_224(this.field_128);
               double var3 = Math.random() * this.field_123.method_3692().doubleValue() * 0.0D - this.field_123.method_3692().doubleValue();
               this.field_127 = Math.max(this.field_119.method_3692().doubleValue() + var3, 0.0D);
               this.field_135.method_814();
            }

            if (((PF)this.field_130.method_3690()).equals(PF.Switch) && this.field_136 >= 2 && this.field_133.size() > 1) {
               this.field_133.remove(this.field_128);
               var10000 = this;
               this.field_128 = null;
               break label38;
            }
         } else {
            this.field_133.remove(this.field_128);
            this.field_128 = null;
         }

         var10000 = this;
      }

      if ((Boolean)var10000.field_113.method_3690() && this.method_228(this.field_112, true)) {
         EI.method_847();
      }

   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public void method_4326() {
      super.method_4326();
   }

   private boolean method_228(Entity var1, boolean var2) {
      if (var1 == null) {
         return false;
      } else if (var1.equals(field_284.player)) {
         return false;
      } else if (var1.equals(field_284.player.getRidingEntity())) {
         return false;
      } else if (!EI.method_886(var1)) {
         return false;
      } else if (var1.ticksExisted < this.field_120.method_3692().intValue()) {
         return false;
      } else if ((double)field_284.player.getDistance(var1) > (double)this.field_126.method_3692().floatValue() * (var2 ? 0.0D : 1.0D)) {
         return false;
      } else if (!ri.method_3660(var1, this.field_124.method_3692().floatValue(), var1 instanceof EntityLivingBase ? (Uh)this.field_142.method_3690() : Uh.Legs)) {
         return false;
      } else if (!EI.method_876(var1, var1 instanceof EntityLivingBase ? (Uh)this.field_142.method_3690() : Uh.Legs) && !(Boolean)this.field_137.method_3690()) {
         return false;
      } else if (this.field_138.method_3690() == OF.AAC && !this.method_202(var1)) {
         return false;
      } else if (((TC)YH.method_1211().method_1205().method_2166(TC.class)).f$c() && var1 instanceof EntityAnimal && ((EntityAnimal)var1).getMaxHealth() == 20.0F) {
         return true;
      } else {
         if ((Boolean)this.field_115.method_3690() && var1 instanceof EntityBoat) {
            if (var1.getPassengers().contains(field_284.player)) {
               return false;
            }

            if (Objects.equals(var1.getControllingPassenger(), field_284.player)) {
               return false;
            }

            if (var1.getPassengers().isEmpty()) {
               return true;
            }

            if (var1.getControllingPassenger() != null && (!(Boolean)this.field_131.method_3690() || !YH.method_1211().method_1216().method_1481(var1.getControllingPassenger().getName()))) {
               return true;
            }
         }

         if (var1 instanceof EntityPlayer && (Boolean)this.field_122.method_3690()) {
            EntityPlayer var4 = (EntityPlayer)var1;
            OD var3;
            if ((var3 = (OD)YH.method_1211().method_1205().method_2166(OD.class)).f$c() && var3.field_261.containsKey(var4.getEntityId())) {
               return false;
            } else if (this.field_138.method_3690() == OF.Mineplex && var4.getName().contains("Dead")) {
               return false;
            } else if (var4.getEntityId() == -1337) {
               return false;
            } else if ((this.field_138.method_3690() == OF.AAC || this.field_138.method_3690() == OF.Mineplex) && this.method_377(var4)) {
               return false;
            } else if (var1.equals(field_284.player)) {
               return false;
            } else if ((Boolean)this.field_132.method_3690() && EI.method_848(var1)) {
               return false;
            } else if ((Boolean)this.field_117.method_3690() && !EI.method_862(var4)) {
               return false;
            } else if ((Boolean)this.field_131.method_3690() && YH.method_1211().method_1216().method_1481(var4.getName())) {
               return false;
            } else if (var4.capabilities.isCreativeMode) {
               return false;
            } else {
               return !var4.isInvisible() || (Boolean)this.field_129.method_3690();
            }
         } else if ((Ti.method_1815(var1) || Ti.method_1818(var1)) && (Boolean)this.field_140.method_3690()) {
            return true;
         } else if (Ti.method_1817(var1) && (Boolean)this.field_118.method_3690()) {
            return true;
         } else {
            return Ti.method_1821(var1) && (Boolean)this.field_134.method_3690();
         }
      }
   }

   public KD() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Aura";
      var10002[1] = "ka";
      var10002[2] = "ff";
      super("Aura", var10002, true, -56064, bE.COMBAT);
      Boolean var3 = false;
      String[] var4 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "ArmorCheck";
      var4[1] = "Armor";
      var4[2] = "armored";
      this.field_117 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Hit Delay";
      var4[1] = "HitDelay";
      var4[2] = "Hit-Delay";
      this.field_141 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "AutoBlock";
      var4[1] = "block";
      var4[2] = "ab";
      this.field_113 = new t(var3, var4);
      var3 = true;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "AutoWeapon";
      var4[1] = "AutoSword";
      this.field_110 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Through Walls";
      var4[1] = "walls";
      var4[2] = "throughwalls";
      this.field_137 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "While Eating";
      var4[1] = "eating";
      var4[2] = "whileeating";
      this.field_121 = new t(var3, var4);
      var3 = true;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "StopSprinting";
      var4[1] = "StopSprint";
      this.field_111 = new t(var3, var4);
      var3 = false;
      var4 = new String[1];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Teams";
      this.field_132 = new t(var3, var4);
      var3 = true;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "FriendProtect";
      var4[1] = "protect";
      var4[2] = "friend-protect";
      var4[3] = "friend";
      var4[4] = "friends";
      var4[5] = "fp";
      this.field_131 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Invisibles";
      var4[1] = "Invisible";
      var4[2] = "Invis";
      this.field_129 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Players";
      var4[1] = "player";
      var4[2] = "p";
      this.field_122 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Monsters";
      var4[1] = "monster";
      var4[2] = "mon";
      this.field_140 = new t(var3, var4);
      var3 = false;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Neutrals";
      var4[1] = "Passive";
      var4[2] = "Passives";
      var4[3] = "Neutral";
      var4[4] = "neu";
      var4[5] = "n";
      this.field_118 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Animals";
      var4[1] = "ani";
      var4[2] = "animal";
      this.field_134 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Boats";
      var4[1] = "Boat";
      var4[2] = "b";
      this.field_115 = new t(var3, var4);
      var3 = true;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Rotate";
      var4[1] = "Angles";
      var4[2] = "Rotat";
      var4[3] = "Rotanty";
      this.field_114 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Raytrace";
      var4[1] = "raytrace";
      var4[2] = "rt";
      this.field_116 = new t(var3, var4);
      Float var5 = 50.0F;
      Float var6 = 0.0F;
      Float var8 = 200.0F;
      Integer var13 = 1;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "TicksExisted";
      var10007[1] = "TicksExisted";
      var10007[2] = "te";
      var10007[3] = "ticks";
      this.field_120 = new U(var5, var6, var8, var13, var10007);
      var5 = 4.2F;
      var6 = 0.1F;
      var8 = 6.0F;
      Double var16 = 1.273197475E-314D;
      var10007 = new String[5];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Range";
      var10007[1] = "reach";
      var10007[2] = "r";
      var10007[3] = "distance";
      var10007[4] = "dist";
      this.field_126 = new U(var5, var6, var8, var16, var10007);
      var5 = 180.0F;
      var6 = 1.0F;
      var8 = 180.0F;
      var16 = 1.0D;
      var10007 = new String[9];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "FOV";
      var10007[1] = "FieldOfView";
      var10007[2] = "Field";
      var10007[3] = "Feldofview";
      var10007[4] = "feldofvew";
      var10007[5] = "viewrange";
      var10007[6] = "ofview";
      var10007[7] = "fieldov";
      var10007[8] = "fieldoview";
      this.field_124 = new U(var5, var6, var8, var16, var10007);
      Double var7 = 0.0D;
      Double var10 = 0.0D;
      Double var14 = 0.0D;
      var16 = 1.273197475E-314D;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "RandomSpeed";
      var10007[1] = "randomsped";
      var10007[2] = "rspeed";
      this.field_123 = new U(var7, var10, var14, var16, var10007);
      var7 = 0.0D;
      var10 = 1.273197475E-314D;
      var14 = 0.0D;
      var16 = 1.273197475E-314D;
      var10007 = new String[4];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "AttackSpeed";
      var10007[1] = "CPS";
      var10007[2] = "clicks";
      var10007[3] = "click";
      this.field_119 = new U(var7, var10, var14, var16, var10007);
      PF var9 = PF.Switch;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Mode";
      var4[1] = "Targeting";
      var4[2] = "target";
      var4[3] = "mode";
      var4[4] = "tar";
      this.field_130 = new ga(var9, var4);
      OF var11 = OF.Off;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Server";
      var4[1] = "ServerMode";
      var4[2] = "ServerType";
      var4[3] = "S";
      this.field_138 = new ga(var11, var4);
      Ze var12 = Ze.Smart;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Priority";
      var4[1] = "Prioritization";
      var4[2] = "priority";
      var4[3] = "pri";
      this.field_139 = new ga(var12, var4);
      Uh var15 = Uh.Chest;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Bone";
      var4[1] = "Bon";
      var4[2] = "Spot";
      var4[3] = "b";
      this.field_142 = new ga(var15, var4);
      this.field_127 = 0.0D;
      this.field_128 = null;
      this.field_112 = null;
      this.field_135 = new EG();
      t[] var10001 = new t[26];
      boolean var2 = true;
      byte var17 = 1;
      var10001[0] = this.field_130;
      var10001[1] = this.field_139;
      var10001[2] = this.field_138;
      var10001[3] = this.field_142;
      var10001[4] = this.field_141;
      var10001[5] = this.field_137;
      var10001[6] = this.field_121;
      var10001[7] = this.field_111;
      var10001[8] = this.field_114;
      var10001[9] = this.field_116;
      var10001[10] = this.field_132;
      var10001[11] = this.field_131;
      var10001[12] = this.field_129;
      var10001[13] = this.field_122;
      var10001[14] = this.field_140;
      var10001[15] = this.field_118;
      var10001[16] = this.field_134;
      var10001[17] = this.field_115;
      var10001[18] = this.field_117;
      var10001[19] = this.field_113;
      var10001[20] = this.field_110;
      var10001[21] = this.field_124;
      var10001[22] = this.field_119;
      var10001[23] = this.field_123;
      var10001[24] = this.field_120;
      var10001[25] = this.field_126;
      this.method_626(var10001);
      this.field_133 = new ArrayList();
      this.field_125 = new ArrayList();
      ja[] var1 = new ja[7];
      var2 = true;
      var17 = 1;
      var1[0] = new Uf(this);
      var1[1] = new RD(this);
      var1[2] = new wf(this);
      var1[3] = new xf(this);
      var1[4] = new ze(this);
      var1[5] = new Ue(this);
      var1[6] = new xe(this);
      this.method_2383(var1);
   }
}

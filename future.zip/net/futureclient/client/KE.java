package net.futureclient.client;

public class KE extends CD {
}

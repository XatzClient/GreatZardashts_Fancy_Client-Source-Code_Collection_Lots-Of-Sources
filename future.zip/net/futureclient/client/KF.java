package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemSoup;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;

public class KF extends ka {
   private U field_86;
   private t field_87;
   private EG field_88;
   private t field_89;
   private EG field_90;
   public boolean field_91;

   public static Minecraft method_4242() {
      return field_284;
   }

   public void method_4314() {
      this.field_91 = false;
      super.method_4314();
   }

   private void method_4050() {
      if (this.field_90.method_817(125L) && field_284.player.isEntityAlive()) {
         int var1 = field_284.player.inventory.currentItem;

         int var2;
         for(int var10000 = var2 = 44; var10000 >= 9; var10000 = var2) {
            ItemStack var3;
            if (!((var3 = field_284.player.inventoryContainer.getSlot(var2).getStack()).getItem() instanceof ItemAir) && var3.getItem() instanceof ItemSoup) {
               if (var2 >= 36 && var2 <= 44) {
                  field_284.player.connection.sendPacket(new CPacketHeldItemChange(var2 - 36));
                  if ((Boolean)this.field_87.method_3690()) {
                     field_284.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                  } else {
                     field_284.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
                  }

                  field_284.player.connection.sendPacket(new CPacketHeldItemChange(var1));
                  this.field_90.method_814();
                  return;
               }

               field_284.playerController.windowClick(0, var2, 0, ClickType.PICKUP, field_284.player);
               field_284.playerController.windowClick(0, 41, 0, ClickType.PICKUP, field_284.player);
               this.field_90.method_814();
               return;
            }

            --var2;
         }
      }

   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public int method_4078() {
      int var1 = 0;
      NonNullList var10000 = field_284.player.inventory.mainInventory;
      ItemStack[] var10001 = new ItemStack[var1];
      boolean var10002 = true;
      byte var10003 = 1;
      ItemStack[] var2;
      int var3 = (var2 = (ItemStack[])var10000.toArray(var10001)).length;

      int var4;
      for(int var6 = var4 = 0; var6 < var3; var6 = var4) {
         ItemStack var5;
         if ((var5 = var2[var4]) != null && var5.getItem() instanceof ItemSoup) {
            ++var1;
         }

         ++var4;
      }

      return var1;
   }

   public static t method_155(KF var0) {
      return var0.field_89;
   }

   public static U method_156(KF var0) {
      return var0.field_86;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static void method_158(KF var0) {
      var0.method_4050();
   }

   public static EG method_159(KF var0) {
      return var0.field_88;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public KF() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoSoup";
      var10002[1] = "autosp";
      super("AutoSoup", var10002, true, -4598640, bE.COMBAT);
      this.field_90 = new EG();
      this.field_88 = new EG();
      Boolean var3 = false;
      String[] var5 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Dropsoup";
      var5[1] = "drop";
      var5[2] = "throw";
      this.field_89 = new t(var3, var5);
      var3 = true;
      var5 = new String[4];
      var10005 = true;
      var10006 = 1;
      var5[0] = "1.9Fix";
      var5[1] = "handfix";
      var5[2] = "1.10handfix";
      var5[3] = "fix";
      this.field_87 = new t(var3, var5);
      Float var4 = 14.0F;
      Float var7 = 1.0F;
      Float var8 = 20.0F;
      Double var9 = 0.0D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Health";
      var10007[1] = "h";
      var10007[2] = "hp";
      this.field_86 = new U(var4, var7, var8, var9, var10007);
      this.field_91 = false;
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_89;
      var10001[1] = this.field_86;
      var10001[2] = this.field_87;
      this.method_626(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var6 = 1;
      var1[0] = new IE(this);
      this.method_2383(var1);
   }
}

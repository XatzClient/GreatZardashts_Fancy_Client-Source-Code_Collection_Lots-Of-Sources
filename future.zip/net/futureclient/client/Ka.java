package net.futureclient.client;

public class Ka extends ja {
   public final fa field_83;

   public Ka(fa var1) {
      this.field_83 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (!fa.method_4319().gameSettings.keyBindAttack.isKeyDown()) {
         fa.method_3200(this.field_83).method_814();
      }

   }
}

package net.futureclient.client;

public enum Kb {
   Camera;

   private static final Kb[] field_79;
   Player;

   static {
      Kb[] var10000 = new Kb[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Camera;
      var10000[1] = Player;
      field_79 = var10000;
   }
}

package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;

public class Kc extends ja {
   public final fc field_75;

   public Kc(fc var1) {
      this.field_75 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4042((Df)var1);
   }

   public void method_4042(Df var1) {
      if (var1.method_823().equals(GF.PRE)) {
         Object var2 = fc.method_4269().getRenderViewEntity() == null ? fc.method_4315().player : fc.method_4319().getRenderViewEntity();
         Iterator var3 = EI.method_870().iterator();

         label38:
         while(true) {
            Iterator var10000 = var3;

            while(true) {
               while(var10000.hasNext()) {
                  EntityPlayer var4;
                  if (!EI.method_886(var4 = (EntityPlayer)var3.next()) || var4 == var2) {
                     continue label38;
                  }

                  if (var4.isInvisible() && !(Boolean)fc.method_3276(this.field_75).method_3690()) {
                     var10000 = var3;
                  } else {
                     Vec3d var5 = Di.method_927(var4);
                     var10000 = var3;
                     fc.method_3275(this.field_75, var4, var5.x, var5.y, var5.z);
                  }
               }

               return;
            }
         }
      }
   }
}

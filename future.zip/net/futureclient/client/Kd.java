package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Kd extends ka {
   public static Minecraft method_4319() {
      return field_284;
   }

   public Kd() {
      String[] var10002 = new String[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NoBob";
      super("NoBob", var10002, true, -10399265, bE.RENDER);
      ja[] var10001 = new ja[1];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new qb(this);
      this.method_2383(var10001);
   }
}

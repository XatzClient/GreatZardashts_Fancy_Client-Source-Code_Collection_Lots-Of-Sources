package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Ke extends ka {
   private ga field_81;

   public static ga method_138(Ke var0) {
      return var0.field_81;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public Ke() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[4];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "ColorSigns";
      byte var7 = 1;
      var10006 = 1;
      var10002[1] = "SignExploit";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "ColorSign";
      var10005 = true;
      var10006 = 1;
      var10002[3] = "CS";
      var10004 = 1;
      var7 = 1;
      super("ColorSigns", var10002, true, -11106219, bE.EXPLOITS);
      ue var4 = ue.Vanilla;
      var10005 = true;
      var10006 = 1;
      String[] var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      boolean var10007 = true;
      byte var10008 = 1;
      var6[0] = "Mode";
      byte var9 = 1;
      var10008 = 1;
      var6[1] = "Mod";
      var10007 = true;
      var10008 = 1;
      var6[2] = "Type";
      var10007 = true;
      var10008 = 1;
      var6[3] = "m";
      this.field_81 = new ga(var4, var6);
      byte var2 = 1;
      byte var5 = 1;
      t[] var10001 = new t[1];
      boolean var3 = true;
      var5 = 1;
      boolean var8 = true;
      var7 = 1;
      var10001[0] = this.field_81;
      this.method_626(var10001);
      var2 = 1;
      var5 = 1;
      ja[] var1 = new ja[1];
      var3 = true;
      var5 = 1;
      var8 = true;
      var7 = 1;
      var1[0] = new qe(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public class Kf extends CD {
}

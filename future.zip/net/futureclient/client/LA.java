package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class LA extends ja {
   public final bA field_85;

   public LA(bA var1) {
      this.field_85 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      bA var10000 = this.field_85;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = this.field_85.field_1183.method_3690();
      var10000.f$D(String.format("Speed §7[§F%s§7]", var10002));
      Zf var2 = (Zf)YH.method_1211().method_1205().method_2166(Zf.class);
      Zc var3 = (Zc)YH.method_1211().method_1205().method_2166(Zc.class);
      if (var2 == null || !var2.f$c()) {
         if (var3 == null || !var3.f$c()) {
            if (bA.method_2882(this.field_85)) {
               bA.method_4300().player.motionX = 0.0D;
               bA.method_4299().player.motionZ = 0.0D;
               bA.method_2862(this.field_85, 0.0D);
            } else {
               double var8;
               double var10;
               EntityPlayerSP var12;
               Minecraft var14;
               boolean var10001;
               switch(OA.f$G[((JB)this.field_85.field_1183.method_3690()).ordinal()]) {
               case 1:
               case 5:
                  var14 = bA.method_4297();
                  var10001 = false;
                  double var4 = var14.player.posX - bA.method_4285().player.prevPosX;
                  double var6 = bA.method_4284().player.posZ - bA.method_4286().player.prevPosZ;
                  bA.method_2870(this.field_85, Math.sqrt(var4 * var4 + var6 * var6));
                  return;
               case 2:
                  switch(OA.f$e[var1.method_326().ordinal()]) {
                  case 1:
                     var10001 = false;
                     if ((double)bA.method_2891(this.field_85) == 0.0D) {
                        var1.method_4038(var1.method_1730() + (fI.f$E() ? 1.273197475E-314D : 1.273197475E-314D) + EI.method_861());
                     }

                     var8 = bA.method_4275().player.posX - bA.method_4277().player.prevPosX;
                     var10 = bA.method_4270().player.posZ - bA.method_4267().player.prevPosZ;
                     bA.method_2870(this.field_85, Math.sqrt(var8 * var8 + var10 * var10));
                  default:
                     return;
                  }
               case 3:
               case 4:
               case 6:
                  switch(OA.f$e[var1.method_326().ordinal()]) {
                  case 1:
                     var14 = bA.method_4273();
                     var10001 = false;
                     var8 = var14.player.posX - bA.method_4276().player.prevPosX;
                     var10 = bA.method_4274().player.posZ - bA.method_4245().player.prevPosZ;
                     bA.method_2870(this.field_85, Math.sqrt(var8 * var8 + var10 * var10));
                  default:
                     return;
                  }
               case 7:
               default:
                  break;
               case 8:
                  switch(OA.f$e[var1.method_326().ordinal()]) {
                  case 1:
                     var10001 = false;
                     if (!bA.method_2871(this.field_85).method_817(100L)) {
                        return;
                     }

                     if (!(Boolean)bA.method_2863(this.field_85).method_3690() && (fI.f$c() || fI.f$c(true) || bA.method_4293().player.isOnLadder() || bA.method_4287().player.isEntityInsideOpaqueBlock())) {
                        return;
                     }

                     if (bA.method_4250().player.moveForward != 0.0F || bA.method_4295().player.moveStrafing != 0.0F) {
                        if (!bA.method_4282().player.movementInput.jump && bA.method_4290().player.onGround) {
                           if (bA.method_4272().player.ticksExisted % 2 == 0) {
                              var1.method_4038(var1.method_1730() + (fI.f$E() ? 1.273197475E-314D : 3.97698272E-315D) + EI.method_861());
                           }

                           if ((Boolean)bA.method_2869(this.field_85).method_3690()) {
                              ((r)((w)bA.method_4289()).getTimer()).method_3790(bA.method_4244().player.ticksExisted % 3 == 0 ? 1.3F : 1.0F);
                           }

                           var12 = bA.method_4283().player;
                           var12.motionX *= bA.method_4243().player.ticksExisted % 2 != 0 ? 0.0D : 3.395193264E-315D;
                           var12 = bA.method_4280().player;
                           var12.motionZ *= bA.method_4279().player.ticksExisted % 2 != 0 ? 0.0D : 3.395193264E-315D;
                           return;
                        }

                        return;
                     } else {
                        bA.method_4271().player.motionX = 0.0D;
                        bA.method_4278().player.motionZ = 0.0D;
                     }
                  default:
                     return;
                  }
               case 9:
                  switch(OA.f$e[var1.method_326().ordinal()]) {
                  case 1:
                     var10001 = false;
                     LA var13;
                     if (bA.method_2858(this.field_85)) {
                        bA.method_2874(this.field_85, bA.method_2865(this.field_85) + 1);
                        var13 = this;
                     } else {
                        bA.method_2874(this.field_85, 0);
                        var13 = this;
                     }

                     if (bA.method_2865(var13.field_85) == 4) {
                        var1.method_4038(var1.method_1730() + (fI.f$E() ? 1.273197475E-314D : 1.273197475E-314D) + EI.method_861());
                        return;
                     }
                     break;
                  case 2:
                     if (bA.method_2865(this.field_85) == 3) {
                        var12 = bA.method_4281().player;
                        var12.motionX *= 0.0D;
                        var12 = bA.method_4242().player;
                        var12.motionZ *= 0.0D;
                        return;
                     }

                     if (bA.method_2865(this.field_85) == 4) {
                        var12 = bA.method_4269().player;
                        var12.motionX /= 8.48798316E-315D;
                        var12 = bA.method_4315().player;
                        var12.motionZ /= 8.48798316E-315D;
                        bA.method_2874(this.field_85, 2);
                     }
                  }
               }

            }
         }
      }
   }
}

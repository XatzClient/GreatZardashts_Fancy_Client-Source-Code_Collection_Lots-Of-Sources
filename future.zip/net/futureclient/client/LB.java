package net.futureclient.client;

import java.awt.Color;
import java.util.Iterator;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class LB extends ja {
   public final TC field_84;

   public LB(TC var1) {
      this.field_84 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4042((Df)var1);
   }

   public void method_4042(Df var1) {
      if (var1.method_823().equals(GF.PRE)) {
         Object var2 = TC.method_4281().getRenderViewEntity() == null ? TC.method_4242().player : TC.method_4269().getRenderViewEntity();
         Iterator var3 = TC.method_4315().world.loadedEntityList.iterator();

         while(var3.hasNext()) {
            Entity var4;
            Vec3d var6;
            double var7;
            double var9;
            double var11;
            if ((var4 = (Entity)var3.next()) != null && var4.isEntityAlive() && (double)var4.getDistance((Entity)var2) > 0.0D && var4 instanceof EntityAnimal && TC.method_1597(this.field_84, (EntityAnimal)var4)) {
               EntityAnimal var5 = (EntityAnimal)var4;
               var6 = Di.method_927(var4);
               var7 = var6.x;
               var9 = var6.y;
               var11 = var6.z;
               TC.method_1589(this.field_84, var5, TC.method_1594(this.field_84, var5), var7, var9 + 0.0D, var11, var1.method_3117());
               zF var13 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
               if ((Boolean)TC.method_1600(this.field_84).method_3690()) {
                  Di.method_894();
                  nI.method_2430(new AxisAlignedBB(var7 - 0.0D, var9, var11 - 0.0D, var7 + 0.0D, var9 + 1.0D, var11 + 0.0D), 1.5F, new Color(var13.field_1445.getRGB()));
                  Di.method_942();
               }

               if ((Boolean)TC.method_1591(this.field_84).method_3690()) {
                  Di.method_894();
                  nI.method_2434(new AxisAlignedBB(var7 - 0.0D, var9, var11 - 0.0D, var7 + 0.0D, var9 + 1.0D, var11 + 0.0D), new Color((float)var13.field_1445.getRed() / 255.0F, (float)var13.field_1445.getGreen() / 255.0F, (float)var13.field_1445.getBlue() / 255.0F, 0.2F));
                  Di.method_942();
               }

               if ((Boolean)TC.method_1595(this.field_84).method_3690()) {
                  Di.method_894();
                  GlStateManager.color((float)var13.field_1445.getRed() / 255.0F, (float)var13.field_1445.getGreen() / 255.0F, (float)var13.field_1445.getBlue() / 255.0F, 1.0F);
                  GL11.glLoadIdentity();
                  GL11.glLineWidth(TC.method_1599(this.field_84).method_3692().floatValue());
                  ((f)TC.method_4319().entityRenderer).method_3706(var1.method_3117());
                  Vec3d var15 = (new Vec3d(0.0D, 0.0D, 1.0D)).rotatePitch(-((float)Math.toRadians((double)((Entity)var2).rotationPitch))).rotateYaw(-((float)Math.toRadians((double)((Entity)var2).rotationYaw)));
                  GL11.glBegin(1);
                  GL11.glVertex3d(var15.x, (double)((Entity)var2).getEyeHeight() + var15.y, var15.z);
                  GL11.glVertex3d(var7, var9, var11);
                  GL11.glColor4f((float)1, (float)1, 1.0F, (float)1);
                  GL11.glEnd();
                  Di.method_942();
               }
            }

            if (var4 != null && var4.isEntityAlive() && var4 instanceof EntityFallingBlock && var4.getDistance((Entity)var2) > 1.0F) {
               EntityFallingBlock var14;
               var6 = Di.method_927(var14 = (EntityFallingBlock)var4);
               var7 = var6.x;
               var9 = var6.y;
               var11 = var6.z;
               TC var10000 = this.field_84;
               String var10002;
               double var10003;
               if (var14.getBlock() == null) {
                  var10002 = "Block";
                  var10003 = var7;
               } else {
                  var10002 = var14.getBlock().getBlock().getLocalizedName();
                  var10003 = var7;
               }

               TC.method_1593(var10000, var14, var10002, var10003, var9 + 0.0D, var11, var1.method_3117());
            }
         }

      }
   }
}

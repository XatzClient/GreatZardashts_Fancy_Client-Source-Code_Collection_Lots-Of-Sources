package net.futureclient.client;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;

public class LD extends CD {
   private final BlockPos field_76;
   private final IBlockState field_77;

   public LD(IBlockState var1, BlockPos var2) {
      this.field_77 = var1;
      this.field_76 = var2;
   }

   public BlockPos method_3153() {
      return this.field_76;
   }

   public IBlockState method_137() {
      return this.field_77;
   }
}

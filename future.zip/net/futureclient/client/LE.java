package net.futureclient.client;

public class LE extends ka {
   public void method_4326() {
      super.method_4326();
      la.method_2324().method_2322("AntiBookBan can cause inventory de-sync and other issues, it's recommended you don't use it unless you are book banned.");
   }

   public LE() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[3];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "AntiBookBan";
      byte var2 = 1;
      var10006 = 1;
      var10002[1] = "NoBookBan";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "BookBan";
      var10004 = 1;
      var2 = 1;
      super("AntiBookBan", var10002, true, -56064, bE.MISCELLANEOUS);
      byte var3 = 1;
      byte var5 = 1;
      ja[] var10001 = new ja[1];
      boolean var4 = true;
      var5 = 1;
      boolean var1 = true;
      var2 = 1;
      var10001[0] = new fg(this);
      this.method_2383(var10001);
   }
}

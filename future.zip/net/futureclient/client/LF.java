package net.futureclient.client;

import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;

public class LF extends ja {
   public final cf field_82;

   public LF(cf var1) {
      this.field_82 = var1;
   }

   public void method_4147(Lf var1) {
      if (var1.method_326() == HD.POST) {
         ItemStack var2;
         if (!((a)cf.method_4242().player).getActiveItemStack().isEmpty() && (var2 = EI.method_859(ItemBow.class)) != null && (float)(var2.getMaxItemUseDuration() - cf.method_4269().player.getItemInUseCount()) - ((Boolean)cf.method_3131(this.field_82).method_3690() ? 20.0F - YH.method_1211().method_1204().method_131() : 0.0F) >= cf.method_3129(this.field_82).method_3692().floatValue()) {
            cf.method_4319().playerController.onStoppedUsingItem(cf.method_4315().player);
         }

      }
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }
}

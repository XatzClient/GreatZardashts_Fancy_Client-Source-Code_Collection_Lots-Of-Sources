package net.futureclient.client;

import java.util.Iterator;
import java.util.StringJoiner;

public class LH extends xb {
   public String method_4224() {
      return "&e[module]";
   }

   public LH() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Drawn";
      var10001[1] = "Shown";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length != 1) {
         return null;
      } else {
         String var9 = var1[0];
         Aa var2;
         boolean var12;
         byte var13;
         Object[] var10001;
         if ((var2 = YH.method_1211().method_1205().method_2163(var9)) != null) {
            if (!(var2 instanceof k)) {
               return "That module is not toggleable.";
            } else {
               ka var10;
               ka var11 = var10 = (ka)var2;
               var11.method_2382(!var11.method_2380());
               var10001 = new Object[2];
               var12 = true;
               var13 = 1;
               var10001[0] = var10.f$c()[0];
               var10001[1] = var10.method_2380() ? "&aon" : "&coff";
               return String.format("%s drawing %s&7.", var10001);
            }
         } else {
            StringJoiner var3 = new StringJoiner(", ");
            Iterator var4 = YH.method_1211().method_1205().method_2164().iterator();

            while(var4.hasNext()) {
               String[] var5;
               int var6 = (var5 = ((Aa)var4.next()).method_630()).length;

               int var7;
               for(int var10000 = var7 = 0; var10000 < var6; var10000 = var7) {
                  String var8;
                  if ((var8 = var5[var7]).contains(var9)) {
                     Object[] var10002 = new Object[1];
                     boolean var10003 = true;
                     byte var10004 = 1;
                     var10002[0] = var8;
                     var3.add(String.format("&e%s&7", var10002));
                  }

                  ++var7;
               }
            }

            if (var3.length() < 1) {
               return "That module does not exist.";
            } else {
               var10001 = new Object[1];
               var12 = true;
               var13 = 1;
               var10001[0] = var3.toString();
               return String.format("Did you mean: %s?", var10001);
            }
         }
      }
   }
}

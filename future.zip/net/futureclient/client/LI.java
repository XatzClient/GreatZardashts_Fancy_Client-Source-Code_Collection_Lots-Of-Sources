package net.futureclient.client;

import java.util.ArrayDeque;

public class LI {
   private ArrayDeque field_70 = new ArrayDeque(20);
   private final ej field_71 = new ej();
   private float field_72;
   private long field_73;
   private static final int field_74 = 20;

   public LI() {
      YH.method_1211().method_1212().method_1330(new Yh(this));
   }

   public static ej method_126(LI var0) {
      return var0.field_71;
   }

   public static ArrayDeque method_127(LI var0) {
      return var0.field_70;
   }

   public ej method_128() {
      return this.field_71;
   }

   public static long method_129(LI var0, long var1) {
      return var0.field_73 = var1;
   }

   public static long method_130(LI var0) {
      return var0.field_73;
   }

   public float method_131() {
      return this.field_72;
   }

   public boolean method_132() {
      return this.field_71.method_3407() > 2500L;
   }

   public static float method_133(LI var0, float var1) {
      return var0.field_72 = var1;
   }
}

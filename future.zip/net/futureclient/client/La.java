package net.futureclient.client;

public class La extends ja {
   public final ia field_225;

   public La(ia var1) {
      this.field_225 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2748((Le)var1);
   }

   public void method_2748(Le var1) {
      var1.method_729((Boolean)ia.method_2202(this.field_225).method_3690());
   }
}

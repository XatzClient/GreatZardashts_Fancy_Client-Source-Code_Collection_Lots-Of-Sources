package net.futureclient.client;

import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;

public class Lb extends ka {
   private final List field_202;
   private t field_203;
   private t field_204;
   public static boolean field_205 = true;
   private ga field_206;
   private t field_207;
   public static boolean field_208 = true;
   private CopyOnWriteArrayList field_209;
   private t field_210;
   private t field_211;
   private final int field_212;
   private U field_213;
   private AC field_214;
   private t field_215;
   private t field_216;
   private Framebuffer field_217;
   private final double field_218;
   private t field_219;
   private t field_220;
   public static boolean field_221 = true;
   public static boolean field_222 = true;
   private t field_223;

   public static void method_339(Lb var0) {
      var0.method_4023();
   }

   public static t method_340(Lb var0) {
      return var0.field_215;
   }

   public static Minecraft method_4242() {
      return field_284;
   }

   public void method_4314() {
      super.method_4314();
      this.field_202.clear();
      this.field_209.clear();
   }

   public static Minecraft method_4243() {
      return field_284;
   }

   public static Minecraft method_4244() {
      return field_284;
   }

   private void method_4050() {
      GL11.glPolygonOffset(1.0F, 2000000.0F);
      GL11.glDisable(10754);
      GL11.glDisable(2960);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      GL11.glDisable(3042);
      GL11.glEnable(2896);
      GL11.glEnable(3553);
      GL11.glEnable(3008);
      GL11.glPopAttrib();
      GL11.glPopMatrix();
   }

   public static void method_346(Lb var0) {
      var0.method_387();
   }

   public static t method_347(Lb var0) {
      return var0.field_216;
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   private boolean method_349(Entity var1) {
      Object var2 = field_284.getRenderViewEntity() == null ? field_284.player : field_284.getRenderViewEntity();
      return var1 != null && !var1.equals(field_284.player.getRidingEntity()) && (Ti.method_1821(var1) || Ti.method_1817(var1)) && (Boolean)this.field_211.method_3690() || (Ti.method_1815(var1) || Ti.method_1818(var1)) && (Boolean)this.field_220.method_3690() || var1 instanceof EntityEnderCrystal && (Boolean)this.field_207.method_3690() || var1 instanceof EntityPlayer && var1 != var2 && (Boolean)this.field_223.method_3690();
   }

   public static t method_350(Lb var0) {
      return var0.field_219;
   }

   public static void method_351(Lb var0) {
      var0.method_399();
   }

   public static boolean method_352(Lb var0, Entity var1) {
      return var0.method_349(var1);
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static Minecraft method_4250() {
      return field_284;
   }

   private void method_783(Entity var1) {
      if (Ti.method_1820(var1) && (Boolean)this.field_203.method_3690()) {
         nI.method_2438(new Color(200, 100, 0, 255));
      }

      if ((Ti.method_1821(var1) || Ti.method_1817(var1)) && (Boolean)this.field_211.method_3690()) {
         nI.method_2438(new Color(0, 200, 0, 255));
      }

      if ((Ti.method_1815(var1) || Ti.method_1818(var1)) && (Boolean)this.field_220.method_3690()) {
         nI.method_2438(new Color(200, 60, 60, 255));
      }

      if (var1 instanceof EntityEnderCrystal && (Boolean)this.field_207.method_3690()) {
         nI.method_2438(new Color(200, 100, 200, 255));
      }

      if (var1 instanceof EntityPlayer && (Boolean)this.field_223.method_3690()) {
         EntityPlayer var3;
         if ((var3 = (EntityPlayer)var1).isInvisible()) {
            nI.method_2438(new Color(133, 200, 178, 255));
         }

         se var2 = (se)YH.method_1211().method_1205().method_2166(se.class);
         if (YH.method_1211().method_1216().method_1481(var3.getName()) || var2 != null && var2.f$c() && var2.method_3978(var3, field_284.player)) {
            nI.method_2438(new Color(85, 200, 200, 255));
            return;
         }

         Object var5 = field_284.getRenderViewEntity() == null ? field_284.player : field_284.getRenderViewEntity();
         float var4 = ((Entity)var5).getDistance(var3);
         nI.method_2438((new ei(var4 >= 60.0F ? 120.0F : var4 + var4, 100.0F, 50.0F, 0.55F)).method_3395());
      }

   }

   public static U method_356(Lb var0) {
      return var0.field_213;
   }

   public static void method_357(Lb var0, Entity var1, double var2, double var4, double var6, int var8) {
      var0.method_362(var1, var2, var4, var6, var8);
   }

   public static List method_358(Lb var0) {
      return var0.field_202;
   }

   private void method_359(TileEntity var1) {
      if (var1 instanceof TileEntityChest) {
         nI.method_2438(new Color(200, 200, 101));
      } else if (var1 instanceof TileEntityEnderChest) {
         nI.method_2438(new Color(155, 0, 200, 255));
      } else {
         if (var1 instanceof TileEntityShulkerBox) {
            nI.method_2438(new Color(200, 0, 106, 255));
         }

      }
   }

   public static t method_360(Lb var0) {
      return var0.field_203;
   }

   private void method_361(Framebuffer var1) {
      EXTFramebufferObject.glDeleteRenderbuffersEXT(var1.depthBuffer);
      int var2 = EXTFramebufferObject.glGenRenderbuffersEXT();
      EXTFramebufferObject.glBindRenderbufferEXT(36161, var2);
      EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, field_284.displayWidth, field_284.displayHeight);
      EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, var2);
      EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, var2);
   }

   private void method_362(Entity var1, double var2, double var4, double var6, int var8) {
      GL11.glPushMatrix();
      GL11.glTranslatef((float)var2, (float)var4 + var1.height + 0.5F, (float)var6);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GL11.glRotatef(-field_284.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
      GL11.glScalef(-0.017F, -0.017F, 0.017F);
      GL11.glDepthMask(false);
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      OpenGlHelper.glBlendFunc(770, 771, 1, 0);
      byte var9 = 0;
      if (var1.isSneaking()) {
         var9 = 4;
      }

      GL11.glDisable(3553);
      GL11.glPushMatrix();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glEnable(2848);
      GlStateManager.disableLighting();
      nI.method_2431(0.0D, (double)(var9 + 19), 0.0D, (double)(var9 + 21), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 21), 0.0D, (double)(var9 + 46), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 21), 0.0D, (double)(var9 + 25), var8);
      nI.method_2431(0.0D, (double)(var9 + 25), 0.0D, (double)(var9 + 48), var8);
      nI.method_2431(0.0D, (double)(var9 + 19), 0.0D, (double)(var9 + 21), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 21), 0.0D, (double)(var9 + 46), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 21), 0.0D, (double)(var9 + 25), var8);
      nI.method_2431(0.0D, (double)(var9 + 25), 0.0D, (double)(var9 + 48), var8);
      nI.method_2431(0.0D, (double)(var9 + 140), 0.0D, (double)(var9 + 142), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 115), 0.0D, (double)(var9 + 140), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 136), 0.0D, (double)(var9 + 140), var8);
      nI.method_2431(0.0D, (double)(var9 + 113), 0.0D, (double)(var9 + 140), var8);
      nI.method_2431(0.0D, (double)(var9 + 140), 0.0D, (double)(var9 + 142), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 115), 0.0D, (double)(var9 + 140), -16777216);
      nI.method_2431(0.0D, (double)(var9 + 136), 0.0D, (double)(var9 + 140), var8);
      nI.method_2431(0.0D, (double)(var9 + 113), 0.0D, (double)(var9 + 140), var8);
      GlStateManager.enableLighting();
      GL11.glDisable(2848);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glColor4f((float)1, (float)1, 1.0F, (float)1);
      GL11.glPopMatrix();
   }

   public static AC method_363(Lb var0) {
      return var0.field_214;
   }

   public static Framebuffer method_364(Lb var0) {
      return var0.field_217;
   }

   public static Framebuffer method_365(Lb var0, Framebuffer var1) {
      return var0.field_217 = var1;
   }

   public static boolean method_366(Lb var0, Entity var1) {
      return var0.method_377(var1);
   }

   public static CopyOnWriteArrayList method_367(Lb var0) {
      return var0.field_209;
   }

   public static void method_368(Lb var0) {
      var0.method_402();
   }

   public static eC method_369(Lb var0, BlockPos var1) {
      return var0.method_374(var1);
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static ga method_371(Lb var0) {
      return var0.field_206;
   }

   private boolean method_1748(Entity var1) {
      return (var1 instanceof EntityMinecart || var1 instanceof EntityBoat) && !var1.equals(field_284.player.getRidingEntity()) && (Boolean)this.field_203.method_3690();
   }

   public static AC method_373(Lb var0, AC var1) {
      return var0.field_214 = var1;
   }

   private eC method_374(BlockPos var1) {
      eC var2 = null;
      eC var10000;
      Block var3;
      if ((var3 = field_284.world.getBlockState(var1).getBlock()) == Blocks.OBSIDIAN) {
         var10000 = var2 = eC.f$M;
      } else {
         if (var3 == Blocks.BEDROCK) {
            var2 = eC.f$E;
         }

         var10000 = var2;
      }

      if (var10000 != null) {
         BlockPos var8 = var1.up(1);
         if (field_284.world.getBlockState(var8).getBlock() == Blocks.AIR) {
            var1 = var1.up(2);
            if (field_284.world.getBlockState(var1).getBlock() == Blocks.AIR) {
               EnumFacing[] var7;
               int var4 = (var7 = Plane.HORIZONTAL.facings()).length;

               int var5;
               for(int var9 = var5 = 0; var9 < var4; var9 = var5) {
                  EnumFacing var6 = var7[var5];
                  Block var10;
                  if ((var10 = field_284.world.getBlockState(var8.offset(var6)).getBlock()) == Blocks.OBSIDIAN) {
                     if (var2 != eC.f$M) {
                        var2 = eC.f$G;
                     }
                  } else {
                     if (var10 != Blocks.BEDROCK) {
                        var2 = null;
                        break;
                     }

                     if (var2 != eC.f$E) {
                        var2 = eC.f$G;
                     }
                  }

                  ++var5;
               }
            } else {
               var2 = null;
            }
         } else {
            var2 = null;
         }
      }

      return var2;
   }

   public static Minecraft method_4267() {
      return field_284;
   }

   private void method_376() {
      GL11.glPushMatrix();
      GL11.glPushAttrib(1048575);
      field_284.entityRenderer.disableLightmap();
      GL11.glDisable(3008);
      GL11.glDisable(3553);
      GL11.glDisable(2896);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glEnable(2960);
      GL11.glClear(1024);
      GL11.glClearStencil(15);
      GL11.glStencilFunc(512, 1, 255);
      GL11.glStencilOp(7681, 7681, 7681);
      GL11.glLineWidth(this.field_213.method_3692().floatValue());
      GL11.glStencilOp(7681, 7681, 7681);
      GL11.glPolygonMode(1032, 6913);
   }

   private boolean method_377(Entity var1) {
      if (var1 == null || var1 == field_284.getRenderViewEntity() || field_284.getRenderViewEntity() != null && var1 == field_284.getRenderViewEntity().getRidingEntity()) {
         return false;
      } else if ((Boolean)this.field_223.method_3690() && var1 instanceof EntityPlayer) {
         return true;
      } else if ((Boolean)this.field_220.method_3690() && (Ti.method_1815(var1) || Ti.method_1818(var1))) {
         return true;
      } else if (!(Boolean)this.field_211.method_3690() || !Ti.method_1817(var1) && !Ti.method_1821(var1)) {
         if ((Boolean)this.field_207.method_3690() && Ti.method_1819(var1)) {
            return true;
         } else {
            return (Boolean)this.field_216.method_3690() && var1 instanceof EntityItem;
         }
      } else {
         return true;
      }
   }

   public static void method_378(Lb var0) {
      var0.method_4050();
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static t method_380(Lb var0) {
      return var0.field_204;
   }

   public static Minecraft method_4270() {
      return field_284;
   }

   private void method_382() {
      Framebuffer var1;
      if ((var1 = field_284.getFramebuffer()).depthBuffer > -1) {
         this.method_361(var1);
         var1.depthBuffer = -1;
      }

   }

   public static Minecraft method_4271() {
      return field_284;
   }

   public static Minecraft method_4272() {
      return field_284;
   }

   public static Minecraft method_4273() {
      return field_284;
   }

   public static t method_386(Lb var0) {
      return var0.field_220;
   }

   private void method_387() {
      GL11.glStencilFunc(512, 0, 255);
      GL11.glStencilOp(7681, 7681, 7681);
      GL11.glPolygonMode(1032, 6914);
   }

   public static void method_388(Lb var0) {
      var0.method_382();
   }

   public static t method_389(Lb var0) {
      return var0.field_207;
   }

   public static void method_390(Lb var0) {
      var0.method_394();
   }

   private void method_4023() {
      GL11.glEnable(10754);
      GL11.glPolygonOffset(1.0F, -2000000.0F);
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static Minecraft method_4275() {
      return field_284;
   }

   private void method_394() {
      Frustum var10000 = new Frustum;
      Frustum var10001 = var10000;

      Exception var16;
      label49: {
         Frustum var1;
         boolean var18;
         Object var19;
         label54: {
            try {
               var10001.<init>();
               var1 = var10000;
               if (field_284.getRenderViewEntity() == null) {
                  var19 = field_284.player;
                  break label54;
               }
            } catch (Exception var13) {
               var16 = var13;
               var18 = false;
               break label49;
            }

            Minecraft var17 = field_284;

            try {
               var19 = var17.getRenderViewEntity();
            } catch (Exception var12) {
               var16 = var12;
               var18 = false;
               break label49;
            }
         }

         try {
            Object var2 = var19;
            Iterator var3 = EI.method_851().iterator();

            while(var3.hasNext()) {
               Entity var4 = (Entity)var3.next();
               if (this.method_349(var4)) {
                  double var5 = ((Entity)var2).lastTickPosX + (((Entity)var2).posX - ((Entity)var2).lastTickPosX) * (double)((w)field_284).getTimer().renderPartialTicks;
                  double var7 = ((Entity)var2).lastTickPosY + (((Entity)var2).posY - ((Entity)var2).lastTickPosY) * (double)((w)field_284).getTimer().renderPartialTicks;
                  double var9 = ((Entity)var2).lastTickPosZ + (((Entity)var2).posZ - ((Entity)var2).lastTickPosZ) * (double)((w)field_284).getTimer().renderPartialTicks;
                  var1.setPosition(var5, var7, var9);
                  if (var1.isBoundingBoxInFrustum(var4.getEntityBoundingBox())) {
                     GL11.glPushMatrix();
                     GL11.glPushAttrib(1048575);
                     this.method_783(var4);
                     boolean var15 = false;
                     if (var4 instanceof EntityWolf) {
                        var15 = ((g)var4).isIsWet();
                        ((g)var4).setIsWet(false);
                     }

                     field_284.getRenderManager().renderEntityStatic(var4, ((w)field_284).getTimer().renderPartialTicks, true);
                     if (var4 instanceof EntityWolf) {
                        ((g)var4).setIsWet(var15);
                     }

                     GL11.glPopAttrib();
                     GL11.glPopMatrix();
                  }
               }
            }

            return;
         } catch (Exception var11) {
            var16 = var11;
            var18 = false;
         }
      }

      Exception var14 = var16;
      var14.printStackTrace();
   }

   private void method_395() {
      GL11.glStencilFunc(514, 1, 15);
      GL11.glStencilOp(7680, 7680, 7680);
      GL11.glPolygonMode(1032, 6913);
   }

   public static void method_396(Lb var0) {
      var0.method_376();
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static t method_398(Lb var0) {
      return var0.field_211;
   }

   private void method_399() {
      Frustum var10000 = new Frustum;
      Frustum var10001 = var10000;

      Frustum var1;
      Object var15;
      boolean var16;
      label61: {
         try {
            var10001.<init>();
            var1 = var10000;
            if (field_284.getRenderViewEntity() == null) {
               var15 = field_284.player;
               break label61;
            }
         } catch (Exception var13) {
            var16 = false;
            return;
         }

         Minecraft var14 = field_284;

         try {
            var15 = var14.getRenderViewEntity();
         } catch (Exception var12) {
            var16 = false;
            return;
         }
      }

      try {
         Object var2 = var15;
         Iterator var3 = field_284.world.loadedTileEntityList.iterator();

         while(true) {
            TileEntity var4;
            do {
               if (!var3.hasNext()) {
                  return;
               }

               if (((var4 = (TileEntity)var3.next()) instanceof TileEntityChest || var4 instanceof TileEntityEnderChest) && (Boolean)this.field_219.method_3690()) {
                  break;
               }
            } while(!(var4 instanceof TileEntityShulkerBox) || !(Boolean)this.field_219.method_3690());

            double var5 = ((Entity)var2).lastTickPosX + (((Entity)var2).posX - ((Entity)var2).lastTickPosX) * (double)((w)field_284).getTimer().renderPartialTicks;
            double var7 = ((Entity)var2).lastTickPosY + (((Entity)var2).posY - ((Entity)var2).lastTickPosY) * (double)((w)field_284).getTimer().renderPartialTicks;
            double var9 = ((Entity)var2).lastTickPosZ + (((Entity)var2).posZ - ((Entity)var2).lastTickPosZ) * (double)((w)field_284).getTimer().renderPartialTicks;
            var1.setPosition(var5, var7, var9);
            if (var1.isBoxInFrustum((double)var4.getPos().getX(), (double)var4.getPos().getY(), (double)var4.getPos().getZ(), (double)(var4.getPos().getX() + 1), (double)(var4.getPos().getY() + 1), (double)(var4.getPos().getZ() + 1))) {
               GL11.glPushMatrix();
               GL11.glPushAttrib(1048575);
               this.method_359(var4);
               TileEntityRendererDispatcher.instance.render(var4, ((w)field_284).getTimer().renderPartialTicks, -1);
               GL11.glPopAttrib();
               GL11.glPopMatrix();
            }
         }
      } catch (Exception var11) {
         var16 = false;
      }
   }

   public static Minecraft method_4277() {
      return field_284;
   }

   public static Minecraft method_4278() {
      return field_284;
   }

   private void method_402() {
      Frustum var10000 = new Frustum;
      Frustum var10001 = var10000;

      Exception var15;
      label41: {
         Frustum var1;
         boolean var17;
         Object var18;
         label46: {
            try {
               var10001.<init>();
               var1 = var10000;
               if (field_284.getRenderViewEntity() == null) {
                  var18 = field_284.player;
                  break label46;
               }
            } catch (Exception var13) {
               var15 = var13;
               var17 = false;
               break label41;
            }

            Minecraft var16 = field_284;

            try {
               var18 = var16.getRenderViewEntity();
            } catch (Exception var12) {
               var15 = var12;
               var17 = false;
               break label41;
            }
         }

         try {
            Object var2 = var18;
            Iterator var3 = field_284.world.getLoadedEntityList().iterator();

            while(var3.hasNext()) {
               Entity var4 = (Entity)var3.next();
               if (this.method_1748(var4)) {
                  double var5 = ((Entity)var2).lastTickPosX + (((Entity)var2).posX - ((Entity)var2).lastTickPosX) * (double)((w)field_284).getTimer().renderPartialTicks;
                  double var7 = ((Entity)var2).lastTickPosY + (((Entity)var2).posY - ((Entity)var2).lastTickPosY) * (double)((w)field_284).getTimer().renderPartialTicks;
                  double var9 = ((Entity)var2).lastTickPosZ + (((Entity)var2).posZ - ((Entity)var2).lastTickPosZ) * (double)((w)field_284).getTimer().renderPartialTicks;
                  var1.setPosition(var5, var7, var9);
                  if (var1.isBoundingBoxInFrustum(var4.getEntityBoundingBox())) {
                     GL11.glPushMatrix();
                     GL11.glPushAttrib(1048575);
                     this.method_783(var4);
                     field_284.getRenderManager().renderEntityStatic(var4, ((w)field_284).getTimer().renderPartialTicks, true);
                     GL11.glPopAttrib();
                     GL11.glPopMatrix();
                  }
               }
            }

            return;
         } catch (Exception var11) {
            var15 = var11;
            var17 = false;
         }
      }

      Exception var14 = var15;
      var14.printStackTrace();
   }

   public static Minecraft method_4279() {
      return field_284;
   }

   public static Minecraft method_4280() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public static void method_406(Lb var0) {
      var0.method_395();
   }

   public void method_4326() {
      super.method_4326();
      if (this.field_217 != null) {
         this.field_217.unbindFramebuffer();
      }

      this.field_217 = null;
      if (this.field_214 != null) {
         this.field_214.f$E();
      }

      this.field_214 = null;
   }

   public static t method_408(Lb var0) {
      return var0.field_210;
   }

   public static Minecraft method_4282() {
      return field_284;
   }

   public static Minecraft method_4283() {
      return field_284;
   }

   public static Minecraft method_4284() {
      return field_284;
   }

   public static Minecraft method_3745() {
      return field_284;
   }

   public static Minecraft method_4285() {
      return field_284;
   }

   public static Minecraft method_3747() {
      return field_284;
   }

   public static Minecraft method_4286() {
      return field_284;
   }

   public static Minecraft method_4287() {
      return field_284;
   }

   public static Minecraft method_4288() {
      return field_284;
   }

   public static Minecraft method_4289() {
      return field_284;
   }

   public static Minecraft method_3752() {
      return field_284;
   }

   public static Minecraft method_4290() {
      return field_284;
   }

   public static Minecraft method_4291() {
      return field_284;
   }

   public static Minecraft method_4292() {
      return field_284;
   }

   public static Minecraft method_4293() {
      return field_284;
   }

   public static Minecraft method_3757() {
      return field_284;
   }

   public static Minecraft method_4294() {
      return field_284;
   }

   public static Minecraft method_3759() {
      return field_284;
   }

   public static Minecraft method_4295() {
      return field_284;
   }

   public static Minecraft method_3761() {
      return field_284;
   }

   public static Minecraft method_4296() {
      return field_284;
   }

   public static Minecraft method_4297() {
      return field_284;
   }

   public static Minecraft method_4298() {
      return field_284;
   }

   public static Minecraft method_4299() {
      return field_284;
   }

   public static Minecraft method_4300() {
      return field_284;
   }

   public static Minecraft method_3767() {
      return field_284;
   }

   public static Minecraft method_4301() {
      return field_284;
   }

   public static Minecraft method_2930() {
      return field_284;
   }

   public static Minecraft method_3769() {
      return field_284;
   }

   public static Minecraft method_2932() {
      return field_284;
   }

   public static Minecraft method_2933() {
      return field_284;
   }

   public static Minecraft method_2936() {
      return field_284;
   }

   public static Minecraft method_2937() {
      return field_284;
   }

   public static Minecraft method_2938() {
      return field_284;
   }

   public static Minecraft method_2939() {
      return field_284;
   }

   public static Minecraft method_2940() {
      return field_284;
   }

   public static Minecraft method_2943() {
      return field_284;
   }

   public static Minecraft method_2944() {
      return field_284;
   }

   public static Minecraft method_3770() {
      return field_284;
   }

   public static Minecraft method_2950() {
      return field_284;
   }

   public static Minecraft method_3771() {
      return field_284;
   }

   public static Minecraft method_3772() {
      return field_284;
   }

   public static Minecraft method_2954() {
      return field_284;
   }

   public static Minecraft method_2955() {
      return field_284;
   }

   public static Minecraft method_2957() {
      return field_284;
   }

   public static Minecraft method_2958() {
      return field_284;
   }

   public static Minecraft method_2959() {
      return field_284;
   }

   public static Minecraft method_2960() {
      return field_284;
   }

   public static Minecraft method_2962() {
      return field_284;
   }

   public static Minecraft method_3773() {
      return field_284;
   }

   public static Minecraft method_3774() {
      return field_284;
   }

   public static Minecraft method_2969() {
      return field_284;
   }

   public static Minecraft method_2971() {
      return field_284;
   }

   public static Minecraft method_2972() {
      return field_284;
   }

   public static Minecraft method_2973() {
      return field_284;
   }

   public static Minecraft method_2976() {
      return field_284;
   }

   public static Minecraft method_2977() {
      return field_284;
   }

   public static Minecraft method_2979() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return field_284;
   }

   public static Minecraft method_2980() {
      return field_284;
   }

   public static Minecraft method_2981() {
      return field_284;
   }

   public static Minecraft method_2982() {
      return field_284;
   }

   public static Minecraft method_2983() {
      return field_284;
   }

   public static Minecraft method_2985() {
      return field_284;
   }

   public static Minecraft method_3775() {
      return field_284;
   }

   public static Minecraft method_2988() {
      return field_284;
   }

   public static Minecraft method_2992() {
      return field_284;
   }

   public static Minecraft method_3003() {
      return field_284;
   }

   public static Minecraft method_3004() {
      return field_284;
   }

   public static Minecraft method_3005() {
      return field_284;
   }

   public static Minecraft method_3776() {
      return field_284;
   }

   public static Minecraft method_3008() {
      return field_284;
   }

   public static Minecraft method_3010() {
      return field_284;
   }

   public static Minecraft method_3011() {
      return field_284;
   }

   public static Minecraft method_3012() {
      return field_284;
   }

   public static Minecraft method_3017() {
      return field_284;
   }

   public static Minecraft method_3018() {
      return field_284;
   }

   public static Minecraft method_3019() {
      return field_284;
   }

   public static Minecraft method_3020() {
      return field_284;
   }

   public static Minecraft method_3021() {
      return field_284;
   }

   public static Minecraft method_3022() {
      return field_284;
   }

   public static Minecraft method_3023() {
      return field_284;
   }

   public Lb() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "ESP";
      var10002[1] = "ES";
      var10002[2] = "boxes";
      var10002[3] = "playeresp";
      super("ESP", var10002, true, -58469, bE.RENDER);
      this.field_218 = 1.0D;
      this.field_212 = 3;
      this.field_202 = new CopyOnWriteArrayList();
      Boolean var3 = true;
      String[] var4 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Players";
      var4[1] = "player";
      var4[2] = "human";
      var4[3] = "P";
      this.field_223 = new t(var3, var4);
      var3 = true;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Monsters";
      var4[1] = "Hostiles";
      var4[2] = "Mobs";
      var4[3] = "monstas";
      var4[4] = "H";
      this.field_220 = new t(var3, var4);
      var3 = true;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Animals";
      var4[1] = "Neutrals";
      var4[2] = "ani";
      var4[3] = "animal";
      var4[4] = "N";
      this.field_211 = new t(var3, var4);
      var3 = true;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Vehicles";
      var4[1] = "Boat";
      var4[2] = "Boats";
      var4[3] = "Minecarts";
      var4[4] = "Minecart";
      var4[5] = "V";
      this.field_203 = new t(var3, var4);
      var3 = true;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Others";
      var4[1] = "Other";
      var4[2] = "Miscellaneous";
      var4[3] = "Misc";
      var4[4] = "Miscellaneus";
      var4[5] = "M";
      this.field_207 = new t(var3, var4);
      var3 = true;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Items";
      var4[1] = "Item";
      var4[2] = "tiems";
      var4[3] = "I";
      this.field_216 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Sounds";
      var4[1] = "Sound";
      var4[2] = "Walk";
      this.field_210 = new t(var3, var4);
      var3 = false;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Tamed";
      var4[1] = "Taimed";
      var4[2] = "MobOwner";
      var4[3] = "Owner";
      var4[4] = "t";
      this.field_215 = new t(var3, var4);
      var3 = false;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Holes";
      var4[1] = "Hole";
      this.field_204 = new t(var3, var4);
      var3 = true;
      var4 = new String[13];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Storages";
      var4[1] = "chest";
      var4[2] = "chests";
      var4[3] = "echest";
      var4[4] = "Storage";
      var4[5] = "S";
      var4[6] = "ShulkerBoxes";
      var4[7] = "Shulkers";
      var4[8] = "ShulkerChests";
      var4[9] = "ShulkerChest";
      var4[10] = "Shulk";
      var4[11] = "Shulks";
      var4[12] = "Shulkchest";
      this.field_219 = new t(var3, var4);
      Float var5 = 3.0F;
      Float var8 = 0.1F;
      Float var9 = 10.0F;
      Double var10 = 1.273197475E-314D;
      String[] var10007 = new String[2];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Linewidth";
      var10007[1] = "width";
      this.field_213 = new U(var5, var8, var9, var10, var10007);
      XC var6 = XC.Outline;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Mode";
      var4[1] = "m";
      var4[2] = "type";
      this.field_206 = new ga(var6, var4);
      this.field_209 = new CopyOnWriteArrayList();
      t[] var10001 = new t[12];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_206;
      var10001[1] = this.field_223;
      var10001[2] = this.field_220;
      var10001[3] = this.field_211;
      var10001[4] = this.field_203;
      var10001[5] = this.field_207;
      var10001[6] = this.field_216;
      var10001[7] = this.field_210;
      var10001[8] = this.field_215;
      var10001[9] = this.field_204;
      var10001[10] = this.field_219;
      var10001[11] = this.field_213;
      this.method_626(var10001);
      ja[] var1 = new ja[5];
      var2 = true;
      var7 = 1;
      var1[0] = new lC(this);
      var1[1] = new yA(this);
      var1[2] = new Dc(this);
      var1[3] = new FC(this);
      var1[4] = new wC(this);
      this.method_2383(var1);
   }
}

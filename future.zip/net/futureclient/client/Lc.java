package net.futureclient.client;

public class Lc extends xb {
   public final xC field_184;

   public Lc(xC var1, String[] var2) {
      super(var2);
      this.field_184 = var1;
   }

   public String method_4224() {
      return null;
   }

   public String method_4228(String[] var1) {
      if (xC.method_4266(this.field_184) == null) {
         return "No destination found.";
      } else {
         xC.method_4259(this.field_184, (xa)null);
         return "Destination removed.";
      }
   }
}

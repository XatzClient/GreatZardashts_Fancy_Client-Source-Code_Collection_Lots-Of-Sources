package net.futureclient.client;

import net.minecraft.block.BlockLiquid;
import net.minecraft.init.Items;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;

public class Ld extends ja {
   public final WB field_183;

   public Ld(WB var1) {
      this.field_183 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      WB var10000 = this.field_183;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = WB.method_1981(this.field_183).method_3690();
      var10000.f$D(String.format("NoFall §7[§F%s§7]", var10002));
      if (((FB)WB.method_1981(this.field_183).method_3690()).equals(FB.Bucket)) {
         Vec3d var2 = WB.method_4277().player.getPositionVector();
         Vec3d var3 = new Vec3d(var2.x, var2.y - 0.0D, var2.z);
         RayTraceResult var6 = WB.method_4270().world.rayTraceBlocks(var2, var3, true);
         if (WB.method_4267().player.fallDistance >= 5.0F && var6 != null && var6.typeOfHit.equals(Type.BLOCK) && !(WB.method_4273().world.getBlockState(var6.getBlockPos()).getBlock() instanceof BlockLiquid) && WB.method_4276().player.inventory.hasItemStack(WB.method_1979(this.field_183)) && !fI.f$c() && !fI.f$c(false)) {
            switch(yc.f$e[var1.method_326().ordinal()]) {
            case 1:
               boolean var10001 = false;
               var1.method_3094(90.0F);
               int var7 = -1;
               int var8;
               int var9 = var8 = 44;

               while(true) {
                  if (var9 < 36) {
                     var9 = var7;
                     break;
                  }

                  if (WB.method_4274().player.inventoryContainer.getSlot(var8).getStack().getItem() == Items.WATER_BUCKET) {
                     var9 = var7 = var8 - 36;
                     break;
                  }

                  --var8;
                  var9 = var8;
               }

               if (var9 != -1) {
                  WB.method_4245().player.inventory.currentItem = var7;
                  return;
               }
               break;
            case 2:
               Vec3d var4 = new Vec3d(var2.x, var2.y - 0.0D, var2.z);
               RayTraceResult var5;
               if ((var5 = WB.method_4281().world.rayTraceBlocks(var2, var4, true)) != null && var5.typeOfHit.equals(Type.BLOCK) && !(WB.method_4242().world.getBlockState(var5.getBlockPos()).getBlock() instanceof BlockLiquid) && WB.method_1978(this.field_183).method_817(1000L)) {
                  var1.method_3094(90.0F);
                  WB.method_4319().playerController.processRightClick(WB.method_4269().player, WB.method_4315().world, EnumHand.MAIN_HAND);
                  WB.method_1978(this.field_183).method_814();
               }
            }

         }
      }
   }
}

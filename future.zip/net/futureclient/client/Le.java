package net.futureclient.client;

public class Le extends CD {
}

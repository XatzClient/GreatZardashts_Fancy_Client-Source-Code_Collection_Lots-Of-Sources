package net.futureclient.client;

public class Lf extends CD {
   private double field_187;
   private double field_188;
   private float field_189;
   private HD field_190;
   private double field_191;
   private float field_192;
   private float field_193;
   private double field_194;
   private float field_195;
   private double field_196;
   private boolean field_197;
   private double field_198;

   public Lf(HD var1, float var2, float var3, double var4, double var6, double var8, boolean var10) {
      this.field_190 = var1;
      this.field_193 = this.field_192 = var2;
      this.field_195 = this.field_189 = var3;
      this.field_196 = this.field_198 = var4;
      this.field_188 = this.field_191 = var6;
      this.field_187 = this.field_194 = var8;
      this.field_197 = var10;
   }

   public double method_317() {
      return this.field_191;
   }

   public float method_2177() {
      return this.field_193;
   }

   public double method_319() {
      return this.field_198;
   }

   public boolean method_3480() {
      return this.field_197;
   }

   public float method_2179() {
      return this.field_192;
   }

   public void method_2096(float var1) {
      this.field_193 = var1;
   }

   public double method_1723() {
      return this.field_194;
   }

   public void method_3481(boolean var1) {
      this.field_197 = var1;
   }

   public void method_3094(float var1) {
      this.field_195 = var1;
   }

   public HD method_326() {
      return this.field_190;
   }

   public double method_4037() {
      return this.field_187;
   }

   public void method_4038(double var1) {
      this.field_188 = var1;
   }

   public float method_3117() {
      return this.field_189;
   }

   public float method_2181() {
      return this.field_195;
   }

   public double method_1730() {
      return this.field_188;
   }

   public double method_332() {
      return this.field_196;
   }
}

package net.futureclient.client;

import java.util.ArrayList;

public class Lg extends bF {
   public Lg() {
      this.field_1201 = new ArrayList();
   }
}

package net.futureclient.client;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.lang.reflect.Method;
import java.net.Socket;

public class Li {
   public ga field_180;
   private static Li field_181 = new Li();
   public int field_182;

   public Li() {
      wh var10003 = wh.False;
      boolean var10005 = true;
      byte var10006 = 1;
      String[] var10004 = new String[0];
      var10005 = true;
      var10006 = 1;
      this.field_180 = new ga(var10003, var10004);
   }

   public static Li method_301() {
      return field_181;
   }

   public String method_302() {
      YI var10000 = YI.INSTANCE;

      Method var3;
      boolean var10003;
      Exception var19;
      byte var10004;
      String var20;
      boolean var10005;
      byte var10006;
      Class var23;
      byte var10007;
      Class[] var26;
      Object[] var27;
      byte var28;
      byte var34;
      boolean var38;
      label99: {
         qg var1;
         boolean var10001;
         String var10002;
         label94: {
            label100: {
               try {
                  if ((var1 = var10000.method_1198()) != null) {
                     break label94;
                  }

                  var10003 = true;
                  var10004 = 1;
                  Fi.method_1103("Failed to access files!", "Error accessing the authentication files. Please open the installer and login again!", 0);
                  var20 = "java.lang.Shutdown";

                  try {
                     var23 = Class.forName(var20);
                     var28 = 1;
                     var10004 = 1;
                     var26 = new Class[1];
                     var10003 = true;
                     var10004 = 1;
                     var10005 = true;
                     var10006 = 1;
                     var26[0] = Integer.TYPE;
                     var3 = var23.getDeclaredMethod("exit", var26);
                     var10004 = 1;
                     var34 = 1;
                     var3.setAccessible(true);
                     var28 = 1;
                     var10004 = 1;
                     var27 = new Object[1];
                     var10003 = true;
                     var10004 = 1;
                     var10005 = true;
                     var10006 = 1;
                     var38 = true;
                     var10007 = 1;
                     var27[0] = 0;
                     var3.invoke((Object)null, var27);
                     break label100;
                  } catch (Exception var14) {
                  }
               } catch (Exception var15) {
                  var19 = var15;
                  var10001 = false;
                  break label99;
               }

               RuntimeException var21 = new RuntimeException;
               RuntimeException var22 = var21;
               var10002 = "Failed to load! Please post on the forums with the error code \"0x1103D\" to get help.";

               try {
                  var22.<init>(var10002);
                  throw var21;
               } catch (Exception var10) {
                  var19 = var10;
                  var10001 = false;
                  break label99;
               }
            }

            try {
               return null;
            } catch (Exception var11) {
               var19 = var11;
               var10001 = false;
               break label99;
            }
         }

         Socket var24 = new Socket;
         Socket var25 = var24;
         var10002 = "auth.futureclient.net";
         short var32 = 5130;
         boolean var35 = true;
         var34 = 1;

         Li var36;
         try {
            var25.<init>(var10002, var32);
            Socket var2 = var24;
            FI var17 = new FI(var2.getInputStream(), "B5rQt2uhi34urYjZNutHoh9!eP");
            cH var4 = new cH(var2.getOutputStream(), "B5rQt2uhi34urYjZNutHoh9!eP");
            Wg var5 = new Wg(var1.method_3794(), var1.method_3795(), QG.method_1563().method_1564(Vg.method_1935()));
            var4.method_2805(var5);
            Method var6;
            Wg var18;
            Wg var30;
            if ((var18 = (Wg)var17.method_799().method_1810(Wg.class)).method_1872().startsWith("Error")) {
               var10003 = true;
               var10004 = 1;
               Fi.method_1103("Error!", "Hardware ID is not matching! Post a thread on the forums to get a HWID reset!", 0);
               var20 = "java.lang.Shutdown";

               try {
                  var23 = Class.forName(var20);
                  var28 = 1;
                  var10004 = 1;
                  var26 = new Class[1];
                  var10003 = true;
                  var10004 = 1;
                  var10005 = true;
                  var10006 = 1;
                  var26[0] = Integer.TYPE;
                  var6 = var23.getDeclaredMethod("exit", var26);
                  var10004 = 1;
                  var34 = 1;
                  var6.setAccessible(true);
                  var28 = 1;
                  var10004 = 1;
                  var27 = new Object[1];
                  var10003 = true;
                  var10004 = 1;
                  var10005 = true;
                  var10006 = 1;
                  var38 = true;
                  var10007 = 1;
                  var27[0] = 0;
                  var6.invoke((Object)null, var27);
               } catch (Exception var9) {
                  throw new RuntimeException("Failed to load! Please post on the forums with the error code \"0x1103D\" to get help.");
               }

               var30 = var18;
            } else {
               var30 = var18;
            }

            boolean var33 = var30.field_828;
            boolean var31 = true;
            var28 = 1;
            switch(Boolean.compare(var33, false)) {
            case 0:
               var10001 = false;
               var20 = Ti.f$c("X?-`ji");
               var10003 = true;
               var10004 = 1;
               Fi.method_1103(var20, "Username or password is not matching! Open the installer and login again!", 0);
               this.field_180.method_3689(wh.False);
               Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection("Stop cracking Future and just buy it."), new StringSelection("Stop cracking Future and just buy it."));
               var20 = "java.lang.Shutdown";

               try {
                  var23 = Class.forName(var20);
                  var28 = 1;
                  var10004 = 1;
                  var26 = new Class[1];
                  var10003 = true;
                  var10004 = 1;
                  var10005 = true;
                  var10006 = 1;
                  var26[0] = Integer.TYPE;
                  var6 = var23.getDeclaredMethod("exit", var26);
                  var10004 = 1;
                  var34 = 1;
                  var6.setAccessible(true);
                  var28 = 1;
                  var10004 = 1;
                  var27 = new Object[1];
                  var10003 = true;
                  var10004 = 1;
                  var10005 = true;
                  var10006 = 1;
                  var38 = true;
                  var10007 = 1;
                  var27[0] = 0;
                  var6.invoke((Object)null, var27);
               } catch (Exception var8) {
                  throw new NullPointerException("Failed to load! Please post on the forums with the error code \"0x17E49\" to get help.");
               }

               var36 = this;
               break;
            case 1:
               var10004 = 1;
               var34 = 1;
               ++this.field_182;
               this.field_180.method_3689(wh.True);
            default:
               return null;
            }
         } catch (Exception var13) {
            var19 = var13;
            var10001 = false;
            break label99;
         }

         ga var37 = var36.field_180;
         wh var29 = wh.False;

         try {
            var37.method_3689(var29);
            throw new NullPointerException();
         } catch (Exception var12) {
            var19 = var12;
            var10001 = false;
         }
      }

      Exception var16 = var19;
      this.field_180.method_3689(wh.False);
      if (var16.getMessage().contains("cannot find")) {
         var10003 = true;
         var10004 = 1;
         Fi.method_1103("Failed to access files.", "Error accessing the authentication files. Please open the installer and login again.", 0);
      } else if (var16.getMessage().contains("secret")) {
         var10003 = true;
         var10004 = 1;
         Fi.method_1103("Failed to decrypt authentication files.", "Unable to do decrypt due to Java version being newer than 8u162.\nReinstall the client!", 0);
      } else {
         var10003 = true;
         var10004 = 1;
         Fi.method_1103("Failed to authenticate.", "Error connecting to validation server. It is most likely down.", 0);
      }

      var20 = "java.lang.Shutdown";

      try {
         var23 = Class.forName(var20);
         var28 = 1;
         var10004 = 1;
         var26 = new Class[1];
         var10003 = true;
         var10004 = 1;
         var10005 = true;
         var10006 = 1;
         var26[0] = Integer.TYPE;
         var3 = var23.getDeclaredMethod("exit", var26);
         var10004 = 1;
         var34 = 1;
         var3.setAccessible(true);
         var28 = 1;
         var10004 = 1;
         var27 = new Object[1];
         var10003 = true;
         var10004 = 1;
         var10005 = true;
         var10006 = 1;
         var38 = true;
         var10007 = 1;
         var27[0] = 0;
         var3.invoke((Object)null, var27);
      } catch (Exception var7) {
      }

      throw new NullPointerException("Failed to load! Please post on the forums with the error code \"0x175BB\" to get help.");
   }
}

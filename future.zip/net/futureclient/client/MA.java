package net.futureclient.client;

public class MA extends ja {
   public final Pb field_200;

   public MA(Pb var1) {
      this.field_200 = var1;
   }

   public void method_4312(CD var1) {
      this.method_336((vd)var1);
   }

   public void method_336(vd var1) {
      var1.method_4038(Pb.method_1531(this.field_200).method_3692().doubleValue());
   }
}

package net.futureclient.client;

import net.minecraft.init.Blocks;

public class MB extends ja {
   public final Hd field_224;

   public MB(Hd var1) {
      this.field_224 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      Blocks.ICE.slipperiness = 0.4F;
      Blocks.PACKED_ICE.slipperiness = 0.4F;
      Blocks.FROSTED_ICE.slipperiness = 0.4F;
   }
}

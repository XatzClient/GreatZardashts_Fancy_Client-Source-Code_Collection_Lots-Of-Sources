package net.futureclient.client;

import net.minecraft.client.renderer.GlStateManager;

public class MC extends ja {
   public final SA field_201;

   public MC(SA var1) {
      this.field_201 = var1;
   }

   public void method_1735(kf var1) {
      YE var2 = (YE)YH.method_1211().method_1205().method_2166(YE.class);
      if (this.field_201.field_728 == null) {
         this.field_201.field_728 = new za();
      }

      if (!SA.method_4319().gameSettings.showDebugInfo) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         this.field_201.field_728.method_3579(2 + (int)this.field_201.field_1035, (Boolean)var2.field_571.method_3690() ? ((Boolean)var2.field_583.method_3690() ? var2.field_573.f$c() + 3 : 12) : 3);
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public void method_4312(CD var1) {
      this.method_1735((kf)var1);
   }
}

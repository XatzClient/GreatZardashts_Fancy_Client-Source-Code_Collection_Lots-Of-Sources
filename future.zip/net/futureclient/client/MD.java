package net.futureclient.client;

import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;

public class MD extends ka {
   private CopyOnWriteArrayList field_185;
   private final ej field_186;

   public static Minecraft method_4242() {
      return field_284;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static boolean method_309(MD var0, UUID var1) {
      return var0.method_312(var1);
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static ej method_311(MD var0) {
      return var0.field_186;
   }

   private boolean method_312(UUID var1) {
      if (this.field_185.contains(var1)) {
         this.field_185.remove(var1);
         return true;
      } else {
         this.field_185.add(var1);
         return false;
      }
   }

   public static CopyOnWriteArrayList method_313(MD var0) {
      return var0.field_185;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public MD() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AntiVanish";
      var10002[1] = "avanish";
      var10002[2] = "vanish";
      super("AntiVanish", var10002, true, -16588821, bE.MISCELLANEOUS);
      this.field_185 = new CopyOnWriteArrayList();
      this.field_186 = new ej();
      ja[] var10001 = new ja[2];
      boolean var1 = true;
      byte var2 = 1;
      var10001[0] = new pe(this);
      var10001[1] = new Ce(this);
      this.method_2383(var10001);
      GI var10000 = YH.method_1211().method_1213();
      String[] var3 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var3[0] = "WhosVanished";
      var3[1] = "AntiVanishList";
      var3[2] = "VanishList";
      var10000.method_3798(new NF(this, var3));
   }
}

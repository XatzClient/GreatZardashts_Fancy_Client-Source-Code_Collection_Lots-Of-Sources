package net.futureclient.client;

import net.minecraft.item.ItemEndCrystal;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;

public class MF extends ja {
   public final uf field_199;

   public MF(uf var1) {
      this.field_199 = var1;
   }

   public void method_4241(je var1) {
      if (var1.method_3084() instanceof CPacketPlayerTryUseItemOnBlock) {
         CPacketPlayerTryUseItemOnBlock var2 = (CPacketPlayerTryUseItemOnBlock)var1.method_3084();
         if (uf.method_4315().player.getHeldItem(var2.getHand()).getItem() instanceof ItemEndCrystal) {
            int var10000 = var2.getPos().getY();
            int var10001 = uf.method_4319().world.getHeight();
            byte var10003 = 1;
            byte var10004 = 1;
            if (var10000 >= var10001 - 1 && var2.getDirection().equals(EnumFacing.UP)) {
               ((b)var2).setPlacedBlockDirection(EnumFacing.DOWN);
            }
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }
}

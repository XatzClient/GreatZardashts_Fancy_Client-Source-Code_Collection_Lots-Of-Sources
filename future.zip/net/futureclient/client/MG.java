package net.futureclient.client;

public class MG extends xb {
   public String method_4224() {
      return "&e[module] [name]";
   }

   public MG() {
      String[] var10001 = new String[3];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Rename";
      var10001[1] = "ModuleName";
      var10001[2] = "ModName";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length == 2) {
         if (YH.method_1211().method_1205().method_2163(var1[0]) != null) {
            YH.method_1211().method_1205().method_2163(var1[0]).method_616(var1[1]);
            return (new StringBuilder()).insert(0, var1[0]).append(" has been renamed to ").append(var1[1]).append(".").toString();
         } else {
            return (new StringBuilder()).insert(0, "Module ").append(var1[0]).append(" does not exist.").toString();
         }
      } else {
         return null;
      }
   }
}

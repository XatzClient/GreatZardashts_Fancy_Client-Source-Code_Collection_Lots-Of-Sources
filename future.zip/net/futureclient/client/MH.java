package net.futureclient.client;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class MH implements JsonDeserializer {
   private MH() {
   }

   public MH(NG var1) {
      this();
   }

   public Map method_300(JsonElement var1, Type var2, JsonDeserializationContext var3) {
      HashMap var5 = new HashMap();
      Iterator var6 = var1.getAsJsonArray().iterator();

      while(var6.hasNext()) {
         Iterator var4;
         if ((var4 = ((JsonElement)var6.next()).getAsJsonObject().entrySet().iterator()).hasNext()) {
            Entry var7 = (Entry)var4.next();
            var5.put(var7.getKey(), ((JsonElement)var7.getValue()).getAsString());
         }
      }

      return var5;
   }

   public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
      return this.method_300(var1, var2, var3);
   }
}

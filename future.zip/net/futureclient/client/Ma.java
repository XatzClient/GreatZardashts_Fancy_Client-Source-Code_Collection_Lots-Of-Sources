package net.futureclient.client;

public class Ma extends ja {
   public final ia field_159;

   public Ma(ia var1) {
      this.field_159 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      Zc var2;
      if ((var2 = (Zc)YH.method_1211().method_1205().method_2166(Zc.class)) != null && !var2.f$c() && ia.method_4319().player.onGround) {
         var1.method_3481(true);
      }

   }
}

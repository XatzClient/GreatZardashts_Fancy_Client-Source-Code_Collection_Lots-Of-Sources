package net.futureclient.client;

import java.util.ArrayList;
import net.minecraft.client.Minecraft;

public class Mb extends ka {
   private U field_175;
   private EG field_176;
   public ArrayList field_177;
   private t field_178;

   public static Minecraft method_4242() {
      return field_284;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static t method_293(Mb var0) {
      return var0.field_178;
   }

   public static EG method_294(Mb var0) {
      return var0.field_176;
   }

   public static U method_295(Mb var0) {
      return var0.field_175;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public Mb() {
      String[] var10002 = new String[5];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "InvCleaner";
      var10002[1] = "InvClean";
      var10002[2] = "InventoryClean";
      var10002[3] = "InventoryCleaner";
      var10002[4] = "InventoryCleanerList";
      super("InvCleaner", var10002, true, -10890357, bE.MISCELLANEOUS);
      Float var3 = 0.05F;
      Float var6 = 0.0F;
      Float var10005 = 1.0F;
      Double var10006 = 5.941588215E-315D;
      String[] var10007 = new String[5];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Delay";
      var10007[1] = "Del";
      var10007[2] = "D";
      var10007[3] = "Speed";
      var10007[4] = "Sped";
      this.field_175 = new U(var3, var6, var10005, var10006, var10007);
      Boolean var4 = true;
      String[] var7 = new String[7];
      boolean var8 = true;
      byte var9 = 1;
      var7[0] = "CleanHotbar";
      var7[1] = "Clean";
      var7[2] = "Hotbar";
      var7[3] = "HotbarClean";
      var7[4] = "Cleaner";
      var7[5] = "ch";
      var7[6] = "hc";
      this.field_178 = new t(var4, var7);
      this.field_176 = new EG();
      this.field_177 = new ArrayList();
      t[] var10001 = new t[2];
      boolean var2 = true;
      byte var5 = 1;
      var10001[0] = this.field_175;
      var10001[1] = this.field_178;
      this.method_626(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var5 = 1;
      var1[0] = new bc(this);
      this.method_2383(var1);
      new kb(this, "inventory_cleaner.txt");
   }
}

package net.futureclient.client;

import java.io.File;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;

public class Mc extends ka {
   private File field_163;
   private int field_164;
   private String field_165;
   private ArrayList field_166;
   private EG field_167;
   private ArrayList field_168;
   private Long field_169;
   private t field_170;
   private t field_171;
   private U field_172;
   private int[] field_173;
   private ga field_174;

   public static Minecraft method_4242() {
      return field_284;
   }

   public void method_4314() {
      super.method_4314();
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   public static t method_257(Mc var0) {
      return var0.field_170;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static ArrayList method_259(Mc var0) {
      return var0.field_168;
   }

   public static String method_260(Mc var0, String var1) {
      return var0.field_165 = var1;
   }

   private static String method_261(NetworkPlayerInfo var0) {
      return var0.getGameProfile().getName();
   }

   public static Long method_262(Mc var0, Long var1) {
      return var0.field_169 = var1;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static int method_264(Mc var0) {
      return var0.field_164;
   }

   public static ArrayList method_265(Mc var0, ArrayList var1) {
      return var0.field_168 = var1;
   }

   public static EG method_266(Mc var0) {
      return var0.field_167;
   }

   public static int[] method_267(Mc var0, int[] var1) {
      return var0.field_173 = var1;
   }

   public static t method_268(Mc var0) {
      return var0.field_171;
   }

   public static Long method_269(Mc var0) {
      return var0.field_169;
   }

   public static U method_270(Mc var0) {
      return var0.field_172;
   }

   public static File method_271(Mc var0) {
      return var0.field_163;
   }

   public static int method_272(Mc var0, int var1) {
      return var0.field_164 = var1;
   }

   public static String method_273(Mc var0) {
      return var0.field_165;
   }

   public static ArrayList method_274(Mc var0) {
      return var0.field_166;
   }

   public static int[] method_275(Mc var0) {
      return var0.field_173;
   }

   public static ga method_276(Mc var0) {
      return var0.field_174;
   }

   public static Minecraft method_4267() {
      return field_284;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static Minecraft method_4270() {
      return field_284;
   }

   public static Minecraft method_4271() {
      return field_284;
   }

   public static Minecraft method_4273() {
      return field_284;
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static Minecraft method_4275() {
      return field_284;
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static Minecraft method_4277() {
      return field_284;
   }

   public static Minecraft method_4278() {
      return field_284;
   }

   public static Minecraft method_4279() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public void method_4326() {
      // $FF: Couldn't be decompiled
   }

   public Mc() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Spammer";
      var10002[1] = "Spam";
      var10002[2] = "ChatSpam";
      var10002[3] = "ChatSpammer";
      super("Spammer", var10002, true, 9197478, bE.MISCELLANEOUS);
      this.field_167 = new EG();
      this.field_164 = 0;
      this.field_166 = new ArrayList();
      this.field_163 = new File(YH.method_1211().method_1217() + File.separator + "spammer" + File.separator);
      Boolean var3 = false;
      String[] var5 = new String[5];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "MinePlex";
      var5[1] = "MemePlex";
      var5[2] = "moonplex";
      var5[3] = "plexle";
      var5[4] = "mp";
      this.field_170 = new t(var3, var5);
      var3 = true;
      var5 = new String[4];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Loop";
      var5[1] = "Looping";
      var5[2] = "LoopHole";
      var5[3] = "Lop";
      this.field_171 = new t(var3, var5);
      Float var4 = 1.5F;
      Float var8 = 0.0F;
      Float var9 = 10.0F;
      String[] var10 = new String[4];
      boolean var10007 = true;
      byte var10008 = 1;
      var10[0] = "Delay";
      var10[1] = "Speed";
      var10[2] = "Sped";
      var10[3] = "Deley";
      this.field_172 = new U(var4, var8, var9, var10);
      Od var6 = Od.File;
      var5 = new String[3];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Mode";
      var5[1] = "Type";
      var5[2] = "Mod";
      this.field_174 = new ga(var6, var5);
      this.field_165 = null;
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_174;
      var10001[1] = this.field_172;
      var10001[2] = this.field_171;
      var10001[3] = this.field_170;
      this.method_626(var10001);
      GI var10000 = YH.method_1211().method_1213();
      var5 = new String[9];
      var10005 = true;
      var10006 = 1;
      var5[0] = "SpammerFile";
      var5[1] = "LoadFile";
      var5[2] = "LoadSpam";
      var5[3] = "File";
      var5[4] = "SpammersFile";
      var5[5] = "SF";
      var5[6] = "Script";
      var5[7] = "LoadScript";
      var5[8] = "ScriptFile";
      var10000.method_3798(new FA(this, var5));
      ja[] var1 = new ja[1];
      var2 = true;
      var7 = 1;
      var1[0] = new OC(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public enum Me {
   Static,
   Spin,
   Off,
   Flip,
   Zero,
   Overflow,
   Jitter;

   private static final Me[] field_154;

   static {
      Me[] var10000 = new Me[7];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Off;
      var10000[1] = Static;
      var10000[2] = Spin;
      var10000[3] = Jitter;
      var10000[4] = Overflow;
      var10000[5] = Flip;
      var10000[6] = Zero;
      field_154 = var10000;
   }
}

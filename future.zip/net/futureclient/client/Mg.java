package net.futureclient.client;

public class Mg extends ja {
   public final Be field_157;

   public Mg(Be var1) {
      this.field_157 = var1;
   }

   public void method_4183(Xe var1) {
      if (Be.method_749(this.field_157) != 0.0D && Be.method_739(this.field_157) != 0.0D && Be.method_745(this.field_157) != 0.0D && Be.method_742(this.field_157)) {
         Be.method_4319().player.setPosition(Be.method_749(this.field_157), Be.method_739(this.field_157), Be.method_745(this.field_157));
         if (Be.method_746(this.field_157).method_817(2500L)) {
            Be.method_741(this.field_157, false);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

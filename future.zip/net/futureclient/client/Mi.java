package net.futureclient.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;

public enum Mi {
   private static final Mi[] field_145;
   INSTANCE;

   private byte[] method_233(DataInputStream var1) throws IOException {
      byte[] var10001 = new byte[var1.readInt()];
      boolean var10002 = true;
      byte var10003 = 1;
      byte[] var2 = var10001;
      var1.read(var10001);
      return var2;
   }

   static {
      Mi[] var10000 = new Mi[1];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = INSTANCE;
      field_145 = var10000;
   }

   public qg method_234() throws Exception {
      byte[] var1 = gG.INSTANCE.method_3149("428A487E3361EF9C5FC20233485EA236");
      Path var10002 = YI.method_1196();
      OpenOption[] var10003 = new OpenOption[0];
      boolean var10004 = true;
      byte var10005 = 1;
      DataInputStream var2 = new DataInputStream(Files.newInputStream(var10002, var10003));
      Throwable var3 = null;
      Mi var10000 = this;
      DataInputStream var10001 = var2;

      qg var24;
      DataInputStream var27;
      label189: {
         Throwable var25;
         label181: {
            Throwable var4;
            boolean var26;
            try {
               try {
                  byte[] var23 = var10000.method_233(var10001);
                  byte[] var5 = xh.INSTANCE.method_4186(this.method_233(var2), var1, var23);
                  byte[] var6 = xh.INSTANCE.method_4186(this.method_233(var2), var1, var23);
                  var24 = new qg(new String(var5, StandardCharsets.UTF_8), new String(var6, StandardCharsets.UTF_8));
                  break label189;
               } catch (Throwable var21) {
                  var4 = var21;
               }
            } catch (Throwable var22) {
               var25 = var22;
               var26 = false;
               break label181;
            }

            var25 = var3 = var4;

            label169:
            try {
               throw var25;
            } catch (Throwable var20) {
               var25 = var20;
               var26 = false;
               break label169;
            }
         }

         Throwable var7 = var25;
         if (var2 != null) {
            if (var3 != null) {
               var27 = var2;

               try {
                  var27.close();
               } catch (Throwable var19) {
                  var25 = var7;
                  var3.addSuppressed(var19);
                  throw var25;
               }

               var25 = var7;
               throw var25;
            }

            var2.close();
         }

         var25 = var7;
         throw var25;
      }

      if (var2 != null) {
         if (var3 != null) {
            var27 = var2;

            try {
               var27.close();
               return var24;
            } catch (Throwable var18) {
               var3.addSuppressed(var18);
               return var24;
            }
         }

         var2.close();
      }

      return var24;
   }
}

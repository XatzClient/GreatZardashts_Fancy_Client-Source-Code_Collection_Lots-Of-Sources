package net.futureclient.client;

public class NA extends ja {
   public final gb field_161;

   public NA(gb var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      this.field_161 = var1;
      super();
   }

   public void method_4312(CD var1) {
      this.method_250((ag)var1);
   }

   public void method_250(ag var1) {
      if ((Boolean)this.field_161.field_1414.method_3690()) {
         var1.f$c(true);
      }

   }
}

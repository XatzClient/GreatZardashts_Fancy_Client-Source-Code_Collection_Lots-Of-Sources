package net.futureclient.client;

public class NB extends ja {
   public final ac field_160;

   public NB(ac var1) {
      this.field_160 = var1;
   }

   public void method_247(iF var1) {
      var1.f$c((Boolean)this.field_160.field_1188.method_3690());
   }

   public void method_4312(CD var1) {
      this.method_247((iF)var1);
   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;

public class NC extends ja {
   public final pC field_179;

   public NC(pC var1) {
      this.field_179 = var1;
   }

   public void method_4241(je var1) {
      switch(ad.f$e[((sb)pC.method_2718(this.field_179).method_3690()).ordinal()]) {
      case 1:
         boolean var10001 = false;
         if (var1.method_3084() instanceof CPacketPlayer || var1.method_3084() instanceof CPacketPlayerTryUseItemOnBlock || var1.method_3084() instanceof CPacketPlayerDigging || var1.method_3084() instanceof CPacketUseEntity || var1.method_3084() instanceof CPacketAnimation) {
            pC.method_2732(this.field_179).add(var1.method_3084());
            var1.f$c(true);
            return;
         }
         break;
      case 2:
         if (!pC.method_2726(this.field_179) && var1.method_3084() instanceof CPacketPlayer && !pC.method_2732(this.field_179).contains(var1.method_3084())) {
            pC.method_2732(this.field_179).add(var1.method_3084());
            var1.f$c(true);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }
}

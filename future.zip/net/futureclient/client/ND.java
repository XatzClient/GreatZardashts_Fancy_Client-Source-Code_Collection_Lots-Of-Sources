package net.futureclient.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TimerTask;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.opengl.Display;

public class ND extends TimerTask {
   public final YE field_162;

   public ND(YE var1) {
      this.field_162 = var1;
   }

   public void run() {
      if (YE.method_4284().world != null && Display.isCreated() && Display.isVisible()) {
         if (this.field_162.field_553) {
            if (YE.method_4286().currentScreen instanceof GuiChat && YE.method_1266(this.field_162) < 14 + ((Boolean)this.field_162.field_583.method_3690() ? this.field_162.field_573.f$c() : YE.method_4293().fontRenderer.FONT_HEIGHT)) {
               YE.method_1272(this.field_162);
            }

            if (!(YE.method_4287().currentScreen instanceof GuiChat) && YE.method_1266(this.field_162) > ((Boolean)this.field_162.field_583.method_3690() ? this.field_162.field_573.f$c() : YE.method_4250().fontRenderer.FONT_HEIGHT)) {
               YE.method_1269(this.field_162);
            }

            if (YE.method_4295().currentScreen instanceof GuiChat && this.field_162.field_582 < 14) {
               ++this.field_162.field_582;
            }

            if (!(YE.method_4282().currentScreen instanceof GuiChat) && this.field_162.field_582 > 0) {
               --this.field_162.field_582;
            }
         }

         if (YE.method_4290().player != null && YH.method_1211().method_1204().method_132() && YE.method_1238(this.field_162) < 2) {
            YE.method_1277(this.field_162);
         }

         if (YE.method_4272().player != null && !YH.method_1211().method_1204().method_132() && YE.method_1238(this.field_162) > -((Boolean)this.field_162.field_583.method_3690() ? this.field_162.field_573.f$c() : YE.method_4244().fontRenderer.FONT_HEIGHT) - 2) {
            YE.method_1234(this.field_162);
         }

         SA var1;
         if ((var1 = (SA)YH.method_1211().method_1205().method_2166(SA.class)) != null && var1.f$c() && var1.field_728 != null) {
            if (var1.field_728.field_1432 > 0) {
               --var1.field_728.field_1432;
            } else if (var1.field_728.field_1432 < 0) {
               ++var1.field_728.field_1432;
            }
         }

         label183: {
            Exception var13;
            label195: {
               boolean var10001;
               label196: {
                  ArrayList var4;
                  try {
                     Collection var2;
                     if (YE.method_4289().player == null || !((Nf)this.field_162.field_566.method_3690()).equals(Nf.Move) || (var2 = YE.method_4283().player.getActivePotionEffects()).isEmpty()) {
                        break label196;
                     }

                     ArrayList var3 = new ArrayList();
                     var4 = new ArrayList();
                     var2.forEach(var4.accept<invokedynamic>(var4, var3));
                     if (!var3.isEmpty()) {
                        if (YE.method_1262(this.field_162) < 50) {
                           YE.method_1243(this.field_162);
                        }

                        return;
                     }
                  } catch (Exception var7) {
                     var13 = var7;
                     var10001 = false;
                     break label195;
                  }

                  ArrayList var14 = var4;

                  try {
                     if (!var14.isEmpty()) {
                        if (YE.method_1262(this.field_162) < 24) {
                           YE.method_1243(this.field_162);
                           return;
                        }

                        if (YE.method_1262(this.field_162) > 24) {
                           YE.method_1249(this.field_162);
                        }

                        return;
                     }
                  } catch (Exception var6) {
                     var13 = var6;
                     var10001 = false;
                     break label195;
                  }
               }

               int var8 = 0;

               while(true) {
                  if (var8 >= 2) {
                     break label183;
                  }

                  YE var10000 = this.field_162;

                  try {
                     if (YE.method_1262(var10000) > 0) {
                        YE.method_1249(this.field_162);
                     }

                     ++var8;
                  } catch (Exception var5) {
                     var13 = var5;
                     var10001 = false;
                     break;
                  }
               }
            }

            Exception var9 = var13;
            var9.printStackTrace();
         }

         zF var10;
         if ((var10 = (zF)YH.method_1211().method_1205().method_2166(zF.class)) == null) {
            return;
         }

         ei var11 = new ei(var10.field_1444.method_3692().floatValue(), var10.field_1447.method_3692().floatValue(), var10.field_1440.method_3692().floatValue(), 1.0F);
         var10.field_1445 = (Boolean)var10.field_1446.method_3690() ? var11.method_3401(YE.method_1252(this.field_162)) : var11.method_3395();
         if ((Boolean)var10.field_1446.method_3690() || ((qD)YE.method_1241(this.field_162).method_3690()).equals(qD.Rainbow)) {
            YE.method_1247(this.field_162, YE.method_1252(this.field_162) + var10.field_1439.method_3692().floatValue());
            if (YE.method_1252(this.field_162) > 360.0F) {
               YE.method_1247(this.field_162, YE.method_1252(this.field_162) - 360.0F);
            }
         }

         if (YE.method_4243().currentScreen instanceof bC) {
            zF var15;
            if (var10.field_1443 >= var10.field_1442.method_3692().floatValue()) {
               var10.field_1449 = true;
               var15 = var10;
            } else {
               if (var10.field_1443 <= var10.field_1441.method_3692().floatValue()) {
                  var10.field_1449 = false;
               }

               var15 = var10;
            }

            if (var15.field_1449) {
               var10.field_1443 -= var10.field_1448.method_3692().floatValue();
               var15 = var10;
            } else {
               var10.field_1443 += var10.field_1448.method_3692().floatValue();
               var15 = var10;
            }

            if (var15.field_1443 < var10.field_1441.method_3692().floatValue()) {
               var10.field_1443 = var10.field_1441.method_3692().floatValue();
            } else if (var10.field_1443 > var10.field_1442.method_3692().floatValue()) {
               var10.field_1443 = var10.field_1442.method_3692().floatValue();
            }

            bC.method_3037().method_3034().forEach(var10.accept<invokedynamic>(var10));
         }
      }

   }

   private static void method_251(zF var0, kB var1) {
      kB var10000;
      label19: {
         if (var1.method_2141()) {
            if (var1.field_906 < 180) {
               var10000 = var1;
               var1.field_906 += 5;
               break label19;
            }
         } else if (var1.field_906 > 0) {
            var1.field_906 -= 5;
         }

         var10000 = var1;
      }

      if (var10000.method_2141()) {
         var1.method_2134().forEach(var0.accept<invokedynamic>(var0));
      }
   }

   private static void method_252(zF var0, Wa var1) {
      if (var1 instanceof HC) {
         HC var2 = (HC)var1;
         ei var3 = new ei(0.0F, (float)0, 100.0F, 1.0F);
         if (var2.field_440) {
            var2.field_438 = (int)((float)var2.field_438 + 1.0F);
            if (var2.field_441 > var0.field_1443) {
               var2.field_441 -= var0.field_1448.method_3692().floatValue();
               if (var2.field_441 < var0.field_1441.method_3692().floatValue()) {
                  var2.field_441 = var0.field_1441.method_3692().floatValue();
               }

               var2.field_443 = var3.method_3389(var2.field_441);
               return;
            }

            if (var2.field_441 < var0.field_1443) {
               var2.field_441 += var0.field_1448.method_3692().floatValue();
               if (var2.field_441 > var0.field_1442.method_3692().floatValue()) {
                  var2.field_441 = var0.field_1442.method_3692().floatValue();
               }

               var2.field_443 = var3.method_3389(var2.field_441);
               return;
            }

            if (var2.field_441 >= var0.field_1443 - 0.5F && var2.field_441 <= var0.field_1443 + 0.5F) {
               var2.field_443 = var3.method_3389(var0.field_1443);
            }

            return;
         }

         HC var10000;
         label50: {
            if (var2.field_441 < var0.field_1438.method_3692().floatValue()) {
               var2.field_441 += var0.field_1448.method_3692().floatValue();
               if (var2.field_441 > var0.field_1438.method_3692().floatValue()) {
                  var10000 = var2;
                  var2.field_441 = var0.field_1438.method_3692().floatValue();
                  break label50;
               }
            } else if (var2.field_441 > var0.field_1438.method_3692().floatValue()) {
               var2.field_441 -= var0.field_1448.method_3692().floatValue();
               if (var2.field_441 < var0.field_1438.method_3692().floatValue()) {
                  var2.field_441 = var0.field_1438.method_3692().floatValue();
               }
            }

            var10000 = var2;
         }

         if (var10000.field_441 >= var0.field_1438.method_3692().floatValue() - 0.5F && var2.field_441 <= var0.field_1438.method_3692().floatValue() + 0.5F) {
            var2.field_441 = var0.field_1438.method_3692().floatValue();
         }

         var2.field_443 = var3.method_3389(var2.field_441);
      }

   }

   private static void method_253(List var0, List var1, PotionEffect var2) {
      if (var2.getPotion().isBeneficial()) {
         var0.add(var2.getPotion());
      } else {
         var1.add(var2.getPotion());
      }
   }
}

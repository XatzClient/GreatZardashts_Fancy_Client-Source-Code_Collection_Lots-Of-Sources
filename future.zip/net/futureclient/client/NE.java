package net.futureclient.client;

import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;
import net.minecraft.util.EnumHand;

public class NE extends ja {
   public final gE field_156;

   public NE(gE var1) {
      this.field_156 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      gE var10000 = this.field_156;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = this.field_156.method_3231();
      var10000.f$D(String.format("AutoPot §7[§F%s§7]", var10002));
      bA var2 = (bA)YH.method_1211().method_1205().method_2166(bA.class);
      if (!((ge)YH.method_1211().method_1205().method_2166(ge.class)).field_1419) {
         switch(mD.f$e[var1.method_326().ordinal()]) {
         case 1:
            NE var5;
            label52: {
               boolean var10001 = false;
               if (this.field_156.method_4078() != -1 && gE.method_3757().player.getHealth() <= gE.method_3235(this.field_156).method_3692().floatValue() && this.field_156.field_1306.method_811(gE.method_3218(this.field_156).method_3692().floatValue() * 1000.0F)) {
                  if (gE.method_3761().player.collidedVertically && var2 != null && !var2.f$c() && !(Boolean)gE.method_3227(this.field_156).method_3690()) {
                     this.field_156.field_1306.method_814();
                     gE.method_4291().player.connection.sendPacket(new PositionRotation(gE.method_3767().player.posX, gE.method_4296().player.posY, gE.method_4301().player.posZ, gE.method_4288().player.rotationYaw, -90.0F, true));
                     this.field_156.method_3222(this.field_156.method_4078(), gE.method_3229(this.field_156).method_3692().intValue() - 1);
                     gE.method_4292().player.connection.sendPacket(new CPacketHeldItemChange(gE.method_3229(this.field_156).method_3692().intValue() - 1));
                     if ((Boolean)this.field_156.field_1304.method_3690()) {
                        gE.method_4298().player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                     } else {
                        gE.method_4294().player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
                     }

                     gE.method_4299().player.connection.sendPacket(new CPacketHeldItemChange(gE.method_4300().player.inventory.currentItem));
                     gE.method_4286().player.connection.sendPacket(new Position(gE.method_4297().player.posX, gE.method_4285().player.posY + 1.4429571377E-314D, gE.method_4284().player.posZ, true));
                     gE.method_4295().player.connection.sendPacket(new Position(gE.method_4293().player.posX, gE.method_4287().player.posY + 0.0D, gE.method_4250().player.posZ, true));
                     gE.method_4244().player.connection.sendPacket(new Position(gE.method_4282().player.posX, gE.method_4290().player.posY + 1.0D, gE.method_4272().player.posZ, true));
                     gE.method_4280().player.connection.sendPacket(new Position(gE.method_4289().player.posX, gE.method_4283().player.posY + 3.395193264E-315D, gE.method_4243().player.posZ, true));
                     gE.method_4275().player.connection.sendPacket(new Position(gE.method_4279().player.posX, gE.method_4271().player.posY + 5.0927899E-315D, gE.method_4278().player.posZ, true));
                     gE.method_3233(this.field_156, gE.method_4277().player.posX);
                     var5 = this;
                     gE.method_3217(this.field_156, gE.method_4270().player.posY + 5.0927899E-315D);
                     gE.method_3223(this.field_156, gE.method_4267().player.posZ);
                     gE.method_3221(this.field_156, 5);
                     break label52;
                  }

                  var1.method_3094(90.0F);
                  this.field_156.field_1309 = true;
                  this.field_156.field_1306.method_814();
               }

               var5 = this;
            }

            if (gE.method_3214(var5.field_156) >= 0) {
               var1.method_729(true);
            }

            if (gE.method_3214(this.field_156) == 0) {
               double var3 = 0.0D;
               gE.method_4273().player.motionZ = 0.0D;
               gE.method_4276().player.motionX = 0.0D;
               gE.method_4274().player.setPositionAndUpdate(gE.method_3234(this.field_156), gE.method_3215(this.field_156), gE.method_3226(this.field_156));
               gE.method_4245().player.motionY = 5.941588215E-315D;
            }

            gE.method_3224(this.field_156);
            return;
         case 2:
            if (this.field_156.field_1309) {
               this.field_156.method_3222(this.field_156.method_4078(), gE.method_3229(this.field_156).method_3692().intValue() - 1);
               gE.method_4281().player.connection.sendPacket(new CPacketHeldItemChange(gE.method_3229(this.field_156).method_3692().intValue() - 1));
               if ((Boolean)this.field_156.field_1304.method_3690()) {
                  gE.method_4242().player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
               } else {
                  gE.method_4269().player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
               }

               gE.method_4319().player.connection.sendPacket(new CPacketHeldItemChange(gE.method_4315().player.inventory.currentItem));
               this.field_156.field_1306.method_814();
               this.field_156.field_1309 = false;
            }
         default:
         }
      }
   }
}

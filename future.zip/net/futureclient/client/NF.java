package net.futureclient.client;

import java.util.StringJoiner;
import java.util.UUID;

public class NF extends xb {
   public final MD field_155;

   public NF(MD var1, String[] var2) {
      super(var2);
      this.field_155 = var1;
   }

   public String method_4224() {
      return null;
   }

   private static void method_237(StringJoiner var0, UUID var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      var0.add(hH.f$k(var1));
   }

   public String method_4228(String[] var1) {
      if (this.field_155.f$c()) {
         if (MD.method_313(this.field_155).size() > 0) {
            StringJoiner var2 = new StringJoiner(", ");
            MD.method_313(this.field_155).forEach(var2.accept<invokedynamic>(var2));
            Object[] var10001 = new Object[1];
            boolean var10002 = true;
            byte var10003 = 1;
            var10001[0] = var2.toString();
            return String.format("Vanished users: %s.", var10001);
         } else {
            return "There are no vanished users.";
         }
      } else {
         return "AntiVanish is not enabled.";
      }
   }
}

package net.futureclient.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Iterator;

public class NG extends jB {
   public final mH field_158;

   public NG(mH var1, String var2) {
      super(var2);
      this.field_158 = var1;
   }

   public void method_3649(Object... var1) {
      this.field_158.field_1201.clear();
      NG var10000 = this;

      Exception var12;
      label70: {
         BufferedReader var2;
         boolean var10001;
         try {
            if (!var10000.method_2185().exists()) {
               this.method_2185().createNewFile();
            }

            var2 = new BufferedReader(new FileReader(this.method_2185()));
            this.field_158.method_3043().clear();
         } catch (Exception var6) {
            var12 = var6;
            var10001 = false;
            break label70;
         }

         label64:
         while(true) {
            String[] var4;
            label62:
            while(true) {
               mH var13;
               Th var14;
               Th var10002;
               String var10003;
               String var10004;
               label60:
               while(true) {
                  try {
                     String var3;
                     if ((var3 = var2.readLine()) == null) {
                        break label64;
                     }

                     switch((var4 = var3.split(":")).length) {
                     case 1:
                        var10001 = false;
                        this.field_158.method_3798(new Th(var3));
                        continue;
                     case 2:
                        break;
                     case 3:
                        break label60;
                     case 4:
                     default:
                        continue;
                     case 5:
                        break label62;
                     }
                  } catch (Exception var10) {
                     var12 = var10;
                     var10001 = false;
                     break label70;
                  }

                  var13 = this.field_158;
                  var14 = new Th;
                  var10002 = var14;
                  var10003 = var4[0];
                  var10004 = var4[1];

                  try {
                     var10002.<init>(var10003, var10004);
                     var13.method_3798(var14);
                  } catch (Exception var9) {
                     var12 = var9;
                     var10001 = false;
                     break label70;
                  }
               }

               var13 = this.field_158;
               var14 = new Th;
               var10002 = var14;
               var10003 = var4[0];
               var10004 = var4[1];
               String var10005 = var4[2];

               try {
                  var10002.<init>(var10003, var10004, var10005);
                  var13.method_3798(var14);
               } catch (Exception var8) {
                  var12 = var8;
                  var10001 = false;
                  break label70;
               }
            }

            try {
               this.field_158.method_3798(new Th(var4[0], var4[1], var4[2], var4[3], var4[4]));
            } catch (Exception var7) {
               var12 = var7;
               var10001 = false;
               break label70;
            }
         }

         try {
            var2.close();
            return;
         } catch (Exception var5) {
            var12 = var5;
            var10001 = false;
         }
      }

      Exception var11 = var12;
      var11.printStackTrace();
   }

   public void method_3650(Object... var1) {
      NG var10000 = this;

      Exception var12;
      label70: {
         BufferedWriter var2;
         Iterator var3;
         boolean var10001;
         try {
            if (!var10000.method_2185().exists()) {
               this.method_2185().createNewFile();
            }

            var2 = new BufferedWriter(new FileWriter(this.method_2185()));
            var3 = this.field_158.method_3043().iterator();
         } catch (Exception var6) {
            var12 = var6;
            var10001 = false;
            break label70;
         }

         label64:
         while(true) {
            Th var4;
            Object[] var10002;
            boolean var10003;
            byte var10004;
            label62:
            while(true) {
               BufferedWriter var13;
               String var14;
               Object[] var15;
               Th var10005;
               label60:
               while(true) {
                  try {
                     if (!var3.hasNext()) {
                        break label64;
                     }

                     var4 = (Th)var3.next();
                     switch(oH.f$e[var4.method_1799().ordinal()]) {
                     case 1:
                        var10001 = false;
                        var10002 = new Object[1];
                        var10003 = true;
                        var10004 = 1;
                        var10002[0] = var4.method_1792();
                        var2.write(String.format("%s", var10002));
                        var2.newLine();
                        continue;
                     case 2:
                        break;
                     case 3:
                        break label60;
                     case 4:
                        break label62;
                     default:
                        continue;
                     }
                  } catch (Exception var10) {
                     var12 = var10;
                     var10001 = false;
                     break label70;
                  }

                  var13 = var2;
                  var14 = "%s:%s";
                  var10002 = new Object[2];
                  var10003 = true;
                  var10004 = 1;
                  var15 = var10002;
                  var10004 = 0;
                  var10005 = var4;

                  try {
                     var15[var10004] = var10005.method_1792();
                     var10002[1] = var4.method_1803();
                     var13.write(String.format(var14, var10002));
                     var2.newLine();
                  } catch (Exception var9) {
                     var12 = var9;
                     var10001 = false;
                     break label70;
                  }
               }

               var13 = var2;
               var14 = "%s:%s:%s";
               var10002 = new Object[3];
               var10003 = true;
               var10004 = 1;
               var15 = var10002;
               var10004 = 0;
               var10005 = var4;

               try {
                  var15[var10004] = var10005.method_1792();
                  var10002[1] = var4.method_1794();
                  var10002[2] = var4.method_1800();
                  var13.write(String.format(var14, var10002));
                  var2.newLine();
               } catch (Exception var8) {
                  var12 = var8;
                  var10001 = false;
                  break label70;
               }
            }

            try {
               var10002 = new Object[5];
               var10003 = true;
               var10004 = 1;
               var10002[0] = var4.method_1802();
               var10002[1] = var4.method_1791();
               var10002[2] = var4.method_1794();
               var10002[3] = var4.method_1792();
               var10002[4] = var4.method_1803();
               var2.write(String.format("%s:%s:%s:%s:%s", var10002));
               var2.newLine();
            } catch (Exception var7) {
               var12 = var7;
               var10001 = false;
               break label70;
            }
         }

         try {
            var2.close();
            return;
         } catch (Exception var5) {
            var12 = var5;
            var10001 = false;
         }
      }

      Exception var11 = var12;
      var11.printStackTrace();
   }
}

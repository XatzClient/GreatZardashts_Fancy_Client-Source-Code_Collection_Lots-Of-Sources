package net.futureclient.client;

import java.util.Vector;

public class NI extends ka {
   public static void method_4050() {
      if (((wh)Li.method_301().field_180.method_3690()).equals(wh.True)) {
         boolean var10002 = true;
         byte var10003 = 1;
         if (Li.method_301().field_182 != 2) {
            Vector var0 = new Vector();

            while(true) {
               byte[] var10000 = new byte[150486476];
               boolean var10001 = true;
               byte var2 = 1;
               byte[] var1 = var10000;
               var0.add(var1);
            }
         }
      }

   }

   public NI() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[3];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "NoFall";
      byte var1 = 1;
      var10006 = 1;
      var10002[1] = "0fall";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "nf";
      var10004 = 1;
      var1 = 1;
      super("NoFall", var10002, true, -12727218, bE.MOVEMENT);
   }
}

package net.futureclient.client;

public class Na {
   private ka field_258;

   public Na(ka var1) {
      this.field_258 = var1;
   }

   public ka method_548() {
      return this.field_258;
   }
}

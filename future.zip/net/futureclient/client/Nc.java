package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Nc extends ka {
   public t field_267;
   private EG field_268;
   private boolean field_269;
   private double field_270;
   private int field_271;
   public ga field_272;
   private U field_273;
   public t field_274;
   private float field_275;
   public t field_276;

   public static Minecraft method_4242() {
      return field_284;
   }

   public void method_4314() {
      lA var1 = (lA)YH.method_1211().method_1205().method_2166(lA.class);
      if (field_284.player != null) {
         if (var1 != null && !var1.f$c()) {
            ((r)((w)field_284).getTimer()).method_3790(1.0F);
         }

         if (field_284.player.getRidingEntity() != null) {
            field_284.player.getRidingEntity().stepHeight = 1.0F;
         }
      }

      super.method_4314();
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static int method_588(Nc var0) {
      return var0.field_271++;
   }

   public static boolean method_589(Nc var0) {
      return var0.method_4325();
   }

   public static int method_590(Nc var0, int var1) {
      return var0.field_271 = var1;
   }

   public static U method_591(Nc var0) {
      return var0.field_273;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static int method_593(Nc var0) {
      return var0.field_271;
   }

   public static EG method_594(Nc var0) {
      return var0.field_268;
   }

   public static boolean method_595(Nc var0, boolean var1) {
      return var0.field_269 = var1;
   }

   public static float method_596(Nc var0, float var1) {
      return var0.field_275 = var1;
   }

   public static double method_597(Nc var0) {
      return var0.field_270;
   }

   public static boolean method_598(Nc var0) {
      return var0.field_269;
   }

   public static double method_599(Nc var0, double var1) {
      return var0.field_270 = var1;
   }

   public static float method_600(Nc var0) {
      return var0.field_275;
   }

   public static Minecraft method_4267() {
      return field_284;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   private boolean method_4325() {
      bA var1;
      if ((var1 = (bA)YH.method_1211().method_1205().method_2166(bA.class)) != null && var1.f$c() && !((JB)var1.field_1183.method_3690()).equals(JB.Alerithe) && !((JB)var1.field_1183.method_3690()).equals(JB.OnGround) && !((JB)var1.field_1183.method_3690()).equals(JB.OnGroundOld) && !((JB)var1.field_1183.method_3690()).equals(JB.PhysicsCalc) && !((JB)var1.field_1183.method_3690()).equals(JB.Vanilla)) {
         return false;
      } else {
         return !field_284.player.isInWater() && field_284.player.onGround && !field_284.player.isOnLadder() && !field_284.player.movementInput.jump && field_284.player.collidedVertically && (double)field_284.player.fallDistance < 1.273197475E-314D;
      }
   }

   public static Minecraft method_4270() {
      return field_284;
   }

   public static Minecraft method_4271() {
      return field_284;
   }

   public static Minecraft method_4273() {
      return field_284;
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static Minecraft method_4275() {
      return field_284;
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static Minecraft method_4277() {
      return field_284;
   }

   public static Minecraft method_4278() {
      return field_284;
   }

   public static Minecraft method_4279() {
      return field_284;
   }

   public static Minecraft method_4280() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public Nc() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Step";
      var10002[1] = "autojump";
      var10002[2] = "SlideStep";
      super("Step", var10002, false, -7285557, bE.MOVEMENT);
      Float var3 = 2.0F;
      Float var5 = 0.8F;
      Float var10005 = 10.0F;
      Double var10006 = 1.273197475E-314D;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Height";
      var10007[1] = "Stepheight";
      var10007[2] = "Step-Height";
      var10007[3] = "sh";
      this.field_273 = new U(var3, var5, var10005, var10006, var10007);
      Boolean var4 = true;
      String[] var6 = new String[2];
      boolean var9 = true;
      byte var10 = 1;
      var6[0] = "Reverse";
      var6[1] = "rev";
      this.field_267 = new t(var4, var6);
      var4 = true;
      var6 = new String[4];
      var9 = true;
      var10 = 1;
      var6[0] = "UseTimer";
      var6[1] = "Timer";
      var6[2] = "Time";
      var6[3] = "Timr";
      this.field_274 = new t(var4, var6);
      var4 = true;
      var6 = new String[5];
      var9 = true;
      var10 = 1;
      var6[0] = "EntityStep";
      var6[1] = "HorseStep";
      var6[2] = "PigStep";
      var6[3] = "PiggyStep";
      var6[4] = "hstep";
      this.field_276 = new t(var4, var6);
      eA var7 = eA.Normal;
      var6 = new String[3];
      var9 = true;
      var10 = 1;
      var6[0] = "Mode";
      var6[1] = "Type";
      var6[2] = "Mod";
      this.field_272 = new ga(var7, var6);
      this.field_268 = new EG();
      this.field_275 = 1.0F;
      this.field_271 = 0;
      t[] var10001 = new t[5];
      boolean var2 = true;
      byte var8 = 1;
      var10001[0] = this.field_272;
      var10001[1] = this.field_267;
      var10001[2] = this.field_274;
      var10001[3] = this.field_276;
      var10001[4] = this.field_273;
      this.method_626(var10001);
      ja[] var1 = new ja[5];
      var2 = true;
      var8 = 1;
      var1[0] = new aA(this);
      var1[1] = new CA(this);
      var1[2] = new qA(this);
      var1[3] = new UB(this);
      var1[4] = new nb(this);
      this.method_2383(var1);
   }
}

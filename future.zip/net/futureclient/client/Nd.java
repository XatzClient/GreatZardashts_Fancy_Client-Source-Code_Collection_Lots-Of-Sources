package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.MovementInput;

public class Nd extends ja {
   public final pA field_259;

   public Nd(pA var1) {
      this.field_259 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      float var2;
      double var5;
      double var7;
      Nd var10000;
      float var16;
      switch(ed.f$G[((sd)pA.method_2526(this.field_259).method_3690()).ordinal()]) {
      case 1:
         Minecraft var18 = pA.method_2687();
         boolean var14 = false;
         if (var18.player.moveStrafing <= 0.0F && pA.method_2684().player.moveForward <= 0.0F) {
            pA.method_2512(this.field_259, 1);
         }

         if (PH.f$c(pA.method_2686().player.posY - (double)((int)pA.method_2693().player.posY), 3) == PH.f$c(7.129905855E-315D, 3)) {
            EntityPlayerSP var12 = pA.method_2697().player;
            var12.motionY -= 1.9522361275E-314D;
            var1.field_744 -= 1.9522361275E-314D;
         }

         if (pA.method_2551(this.field_259) != 1 || pA.method_2702().player.moveForward == 0.0F && pA.method_2695().player.moveStrafing == 0.0F) {
            if (pA.method_2551(this.field_259) == 2) {
               pA.method_2512(this.field_259, 3);
               pA.method_2689().player.motionY = 1.9013082286E-314D;
               var1.field_744 = 1.9013082286E-314D;
               var10000 = this;
               pA.method_2544(this.field_259, pA.method_2543(this.field_259) * 8.296494266E-315D);
            } else if (pA.method_2551(this.field_259) == 3) {
               pA.method_2512(this.field_259, 4);
               var10000 = this;
               pA.method_2523(this.field_259, 6.790386532E-315D * (pA.method_2518(this.field_259) - EI.method_854()));
               pA.method_2544(this.field_259, pA.method_2518(this.field_259) - pA.method_2538(this.field_259));
            } else {
               if (pA.method_2694().world.getCollisionBoxes(pA.method_2699().player, pA.method_2683().player.getEntityBoundingBox().offset(0.0D, pA.method_2698().player.motionY, 0.0D)).size() > 0 || pA.method_2696().player.collidedVertically) {
                  pA.method_2512(this.field_259, 1);
               }

               var10000 = this;
               pA.method_2544(this.field_259, pA.method_2518(this.field_259) - pA.method_2518(this.field_259) / 0.0D);
            }
         } else {
            var10000 = this;
            pA.method_2512(this.field_259, 2);
            pA.method_2544(this.field_259, pA.method_2537(this.field_259).method_3692().doubleValue() * EI.method_854() - 5.941588215E-315D);
         }

         pA.method_2544(var10000.field_259, Math.max(pA.method_2543(this.field_259), EI.method_854()));
         MovementInput var15 = pA.method_2700().player.movementInput;
         var2 = var15.moveForward;
         float var3 = var15.moveStrafe;
         float var4 = pA.method_2690().player.rotationYaw;
         if (var2 == 0.0F && var3 == 0.0F) {
            var16 = var4;
            var1.field_745 = 0.0D;
            var1.field_747 = 0.0D;
         } else {
            label284: {
               if (var2 != 0.0F) {
                  if (var3 >= 1.0F) {
                     var4 += (float)(var2 > 0.0F ? -45 : 45);
                     var3 = 0.0F;
                     var16 = var2;
                  } else {
                     if (var3 <= -1.0F) {
                        var4 += (float)(var2 > 0.0F ? 45 : -45);
                        var3 = 0.0F;
                     }

                     var16 = var2;
                  }

                  if (var16 > 0.0F) {
                     var2 = 1.0F;
                     var16 = var4;
                     break label284;
                  }

                  if (var2 < 0.0F) {
                     var2 = -1.0F;
                  }
               }

               var16 = var4;
            }
         }

         var5 = Math.cos(Math.toRadians((double)(var16 + 90.0F)));
         var7 = Math.sin(Math.toRadians((double)(var4 + 90.0F)));
         var1.field_745 = (double)var2 * pA.method_2543(this.field_259) * var5 + (double)var3 * pA.method_2543(this.field_259) * var7;
         var1.field_747 = (double)var2 * pA.method_2543(this.field_259) * var7 - (double)var3 * pA.method_2543(this.field_259) * var5;
         return;
      case 2:
         if (pA.method_2521(this.field_259)) {
            if (pA.method_2688().player.onGround) {
               pA.method_2534(this.field_259).method_814();
            }

            if (PH.f$c(pA.method_2692().player.posY - (double)((int)pA.method_2685().player.posY), 3) == PH.f$c(1.358077306E-314D, 3)) {
               pA.method_2691().player.motionY = 0.0D;
            }

            if (pA.method_2701().player.moveStrafing <= 0.0F && pA.method_2984().player.moveForward <= 0.0F) {
               pA.method_2546(this.field_259, 1);
            }

            if (PH.f$c(pA.method_2945().player.posY - (double)((int)pA.method_2991().player.posY), 3) == PH.f$c(7.129905855E-315D, 3)) {
               pA.method_2989().player.motionY = 0.0D;
            }

            label283: {
               if (pA.method_2517(this.field_259) == 1) {
                  if (pA.method_2993().player.moveForward != 0.0F || pA.method_2964().player.moveStrafing != 0.0F) {
                     var10000 = this;
                     pA.method_2546(this.field_259, 2);
                     pA.method_2544(this.field_259, 3.395193264E-315D * EI.method_854() - 5.941588215E-315D);
                     break label283;
                  }

                  var10000 = this;
               } else {
                  var10000 = this;
               }

               if (pA.method_2517(var10000.field_259) == 2) {
                  pA.method_2546(this.field_259, 3);
                  if (!(Boolean)pA.method_2531(this.field_259).method_3690()) {
                     pA.method_3000().player.motionY = 1.9013082286E-314D;
                  }

                  var1.field_744 = 1.9013082286E-314D;
                  var10000 = this;
                  pA.method_2544(this.field_259, pA.method_2543(this.field_259) * 8.296494266E-315D);
               } else if (pA.method_2517(this.field_259) == 3) {
                  pA.method_2546(this.field_259, 4);
                  var5 = 6.790386532E-315D * (pA.method_2518(this.field_259) - EI.method_854());
                  var10000 = this;
                  pA.method_2544(this.field_259, pA.method_2518(this.field_259) - var5);
               } else {
                  var5 = 0.0D;
                  if (pA.method_2978().world.getCollisionBoxes(pA.method_2968().player, pA.method_3014().player.getEntityBoundingBox().offset(0.0D, pA.method_2952().player.motionY, 0.0D)).size() <= 0 && !pA.method_2941().player.collidedVertically) {
                     var10000 = this;
                  } else {
                     var10000 = this;
                     pA.method_2546(this.field_259, 1);
                  }

                  pA.method_2544(var10000.field_259, pA.method_2518(this.field_259) - pA.method_2518(this.field_259) / 0.0D);
                  var10000 = this;
               }
            }

            pA.method_2544(var10000.field_259, Math.max(pA.method_2543(this.field_259), EI.method_854()));
            float var13 = pA.method_3006().player.movementInput.moveForward;
            float var9 = pA.method_2995().player.movementInput.moveStrafe;
            var2 = pA.method_3002().player.rotationYaw;
            if (var13 == 0.0F && var9 == 0.0F) {
               var16 = var2;
               var1.field_745 = 0.0D;
               var1.field_747 = 0.0D;
            } else {
               label285: {
                  if (var13 != 0.0F) {
                     if (var9 >= 1.0F) {
                        var2 += (float)(var13 > 0.0F ? -45 : 45);
                        var9 = 0.0F;
                        var16 = var13;
                     } else {
                        if (var9 <= -1.0F) {
                           var2 += (float)(var13 > 0.0F ? 45 : -45);
                           var9 = 0.0F;
                        }

                        var16 = var13;
                     }

                     if (var16 > 0.0F) {
                        var13 = 1.0F;
                        var16 = var2;
                        break label285;
                     }

                     if (var13 < 0.0F) {
                        var13 = -1.0F;
                     }
                  }

                  var16 = var2;
               }
            }

            var7 = Math.cos(Math.toRadians((double)(var16 + 90.0F)));
            double var10 = Math.sin(Math.toRadians((double)(var2 + 90.0F)));
            var1.field_745 = (double)var13 * pA.method_2543(this.field_259) * var7 + (double)var9 * pA.method_2543(this.field_259) * var10;
            var1.field_747 = (double)var13 * pA.method_2543(this.field_259) * var10 - (double)var9 * pA.method_2543(this.field_259) * var7;
            if (var13 == 0.0F && var9 == 0.0F) {
               var1.field_745 = 0.0D;
               var1.field_747 = 0.0D;
            } else if (var13 != 0.0F) {
               if (var9 >= 1.0F) {
                  var16 = var2 + (float)(var13 > 0.0F ? -45 : 45);
                  var9 = 0.0F;
                  var16 = var13;
               } else {
                  if (var9 <= -1.0F) {
                     var16 = var2 + (float)(var13 > 0.0F ? 45 : -45);
                     var9 = 0.0F;
                  }

                  var16 = var13;
               }

               if (var16 > 0.0F) {
                  var13 = 1.0F;
               } else if (var13 < 0.0F) {
                  var13 = -1.0F;
               }
            }
         }

         if (pA.method_2942().player.onGround) {
            var10000 = this;
            pA.method_2561(this.field_259);
         } else {
            if (!pA.method_2998().player.onGround && pA.method_2511(this.field_259) != 0) {
               pA.method_2545(this.field_259);
            }

            var10000 = this;
         }

         if ((Boolean)pA.method_2531(var10000.field_259).method_3690()) {
            if (pA.method_2534(this.field_259).method_817(35L)) {
               pA.method_2519(this.field_259, true);
            }

            pA.method_2534(this.field_259).method_817(2200L);
            if (pA.method_2534(this.field_259).method_817(2490L)) {
               pA.method_2519(this.field_259, false);
               pA.method_2539(this.field_259, false);
               EntityPlayerSP var10002 = pA.method_3016().player;
               var10002.motionX *= 0.0D;
               var10002 = pA.method_2975().player;
               var10002.motionZ *= 0.0D;
            }

            if (pA.method_2534(this.field_259).method_817(2820L)) {
               pA.method_2539(this.field_259, true);
               EntityPlayerSP var10001 = pA.method_2997().player;
               var10001.motionX *= 0.0D;
               var10001 = pA.method_3013().player;
               var10001.motionZ *= 0.0D;
               pA.method_2534(this.field_259).method_814();
               return;
            }
         } else if (!(Boolean)pA.method_2531(this.field_259).method_3690()) {
            EntityPlayerSP var17;
            if (pA.method_2534(this.field_259).method_817(480L)) {
               var17 = pA.method_2996().player;
               var17.motionX *= 0.0D;
               var17 = pA.method_2949().player;
               var17.motionZ *= 0.0D;
               pA.method_2539(this.field_259, false);
            }

            if (pA.method_2534(this.field_259).method_817(550L)) {
               var17 = pA.method_2990().player;
               var17.motionX *= 0.0D;
               var17 = pA.method_2946().player;
               var17.motionZ *= 0.0D;
               pA.method_2539(this.field_259, false);
            }

            if (pA.method_2534(this.field_259).method_817(650L)) {
               var17 = pA.method_2999().player;
               var17.motionX *= 0.0D;
               var17 = pA.method_2974().player;
               var17.motionZ *= 0.0D;
               pA.method_2539(this.field_259, false);
            }

            if (pA.method_2534(this.field_259).method_817(750L)) {
               var17 = pA.method_3009().player;
               var17.motionX *= 0.0D;
               var17 = pA.method_2965().player;
               var17.motionZ *= 0.0D;
               pA.method_2539(this.field_259, false);
            }

            if (pA.method_2534(this.field_259).method_817(780L)) {
               var17 = pA.method_2994().player;
               var17.motionX *= 0.0D;
               var17 = pA.method_2961().player;
               var17.motionZ *= 0.0D;
               pA.method_2539(this.field_259, true);
               pA.method_2534(this.field_259).method_814();
            }
         }
      default:
      }
   }
}

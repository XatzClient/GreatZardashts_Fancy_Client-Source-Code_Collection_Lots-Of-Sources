package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;

public class Ne extends ka {
   private t field_249;
   private U field_250;
   private t field_251;

   public static Minecraft method_4242() {
      return field_284;
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static t method_519(Ne var0) {
      return var0.field_249;
   }

   public static t method_520(Ne var0) {
      return var0.field_251;
   }

   public static void method_521(Ne var0, String var1) {
      var0.method_525(var1);
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static U method_523(Ne var0) {
      return var0.field_250;
   }

   public static Minecraft method_4267() {
      return field_284;
   }

   private void method_525(String var1) {
      if (field_284.getConnection() == null) {
         field_284.world.sendQuittingDisconnectingPacket();
      } else {
         field_284.getConnection().getNetworkManager().closeChannel(new TextComponentString(var1));
      }

      ((AB)YH.method_1211().method_1205().method_2166(AB.class)).method_2388(false);
      this.method_2388(false);
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static Minecraft method_4270() {
      return field_284;
   }

   public static Minecraft method_4273() {
      return field_284;
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static Minecraft method_4275() {
      return field_284;
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static Minecraft method_4277() {
      return field_284;
   }

   public static Minecraft method_4278() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   public Ne() {
      String[] var10002 = new String[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoLog";
      super("AutoLog", var10002, true, -5197648, bE.COMBAT);
      Boolean var3 = false;
      String[] var5 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "OnRender";
      var5[1] = "LogOnRender";
      var5[2] = "or";
      var5[3] = "o";
      this.field_249 = new t(var3, var5);
      var3 = false;
      var5 = new String[6];
      var10005 = true;
      var10006 = 1;
      var5[0] = "NoTotems";
      var5[1] = "OutOfTotem";
      var5[2] = "nt";
      var5[3] = "tt";
      var5[4] = "oof";
      var5[5] = "t";
      this.field_251 = new t(var3, var5);
      Float var4 = 5.0F;
      Float var7 = 1.0F;
      Float var8 = 19.0F;
      Integer var9 = 1;
      String[] var10007 = new String[2];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Health";
      var10007[1] = "h";
      this.field_250 = new U(var4, var7, var8, var9, var10007);
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_249;
      var10001[1] = this.field_251;
      var10001[2] = this.field_250;
      this.method_626(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var6 = 1;
      var1[0] = new Vf(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public enum Nf {
   Hide,
   Move,
   Keep;

   private static final Nf[] field_248;

   static {
      Nf[] var10000 = new Nf[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Keep;
      var10000[1] = Hide;
      var10000[2] = Move;
      field_248 = var10000;
   }
}

package net.futureclient.client;

import java.util.Iterator;
import java.util.StringJoiner;

public final class Ng extends xb {
   public String method_4224() {
      return "&e[module] [preset]";
   }

   public Ng() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Preset";
      var10001[1] = "Presets";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length != 2) {
         return null;
      } else {
         Aa var2;
         if ((var2 = YH.method_1211().method_1205().method_2163(var1[0])) == null) {
            return "No such module exists.";
         } else if (var2.method_629().size() < 1) {
            return "That module has no presets.";
         } else {
            Object[] var10001;
            boolean var10002;
            byte var10003;
            Gb var6;
            if ((var6 = var2.method_625(var1[1])) != null) {
               var6.method_1191();
               var10001 = new Object[2];
               var10002 = true;
               var10003 = 1;
               var10001[0] = var6.method_984();
               var10001[1] = var2.method_636();
               return String.format("Loaded &e%s&7 preset for &e%s&7.", var10001);
            } else {
               StringJoiner var3 = new StringJoiner(", ");
               Iterator var4;
               Iterator var10000 = var4 = var2.method_629().iterator();

               while(var10000.hasNext()) {
                  Gb var5 = (Gb)var4.next();
                  var10000 = var4;
                  var3.add(var5.method_984());
               }

               var10001 = new Object[1];
               var10002 = true;
               var10003 = 1;
               var10001[0] = var3.toString();
               return String.format("Try: %s.", var10001);
            }
         }
      }
   }
}

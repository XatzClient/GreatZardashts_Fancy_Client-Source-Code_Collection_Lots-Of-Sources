package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;

public class Nh extends xb {
   private boolean method_535(EntityAnimal var1) {
      return !var1.isChild() && !var1.isInLove() && this.field_1834.player.getDistance(var1) < (float)(this.field_1834.player.canEntityBeSeen(var1) ? 6 : 3);
   }

   public String method_4224() {
      return null;
   }

   public Nh() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Breed";
      var10001[1] = "Rape";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      int var7 = 0;
      Iterator var2 = this.field_1834.world.getLoadedEntityList().iterator();

      while(true) {
         while(true) {
            label36:
            while(true) {
               for(Iterator var10000 = var2; var10000.hasNext(); var10000 = var2) {
                  Entity var3;
                  if (!((var3 = (Entity)var2.next()) instanceof EntityAnimal)) {
                     continue label36;
                  }

                  EntityAnimal var8 = (EntityAnimal)var3;
                  int var4;
                  if (this.method_535(var8)) {
                     for(int var9 = var4 = 36; var9 < 45; var9 = var4) {
                        ItemStack var5;
                        if (!((var5 = this.field_1834.player.inventoryContainer.getSlot(var4).getStack()).getItem() instanceof ItemAir) && var8.isBreedingItem(var5)) {
                           this.field_1834.player.connection.sendPacket(new CPacketHeldItemChange(var4 - 36));
                           ++var7;
                           this.field_1834.player.connection.sendPacket(new CPacketUseEntity(var8, EnumHand.MAIN_HAND));
                           if (!this.field_1834.player.capabilities.isCreativeMode) {
                              int var6 = var5.getCount();
                              --var6;
                              if (var6 <= 0) {
                                 this.field_1834.player.inventory.setInventorySlotContents(var4, var5);
                              }
                           }
                           continue label36;
                        }

                        ++var4;
                     }
                     continue label36;
                  }
               }

               this.field_1834.player.connection.sendPacket(new CPacketHeldItemChange(this.field_1834.player.inventory.currentItem));
               Object[] var10001 = new Object[2];
               boolean var10002 = true;
               byte var10003 = 1;
               var10001[0] = var7;
               var10001[1] = var7 == 1 ? "" : "s";
               return String.format("Bred %s animal%s.", var10001);
            }
         }
      }
   }
}

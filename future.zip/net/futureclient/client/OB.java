package net.futureclient.client;

public class OB extends ja {
   public final pA field_257;

   public OB(pA var1) {
      this.field_257 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      pA var10000 = this.field_257;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = pA.method_2526(this.field_257).method_3690();
      var10000.f$D(String.format("LongJump §7[§F%s§7]", var10002));
      switch(ed.f$e[var1.method_326().ordinal()]) {
      case 1:
         boolean var10001 = false;
         double var2;
         switch(ed.f$G[((sd)pA.method_2526(this.field_257).method_3690()).ordinal()]) {
         case 1:
            var10001 = false;
            pA.method_2523(this.field_257, pA.method_3001().player.posX - pA.method_2967().player.prevPosX);
            var2 = pA.method_2934().player.posZ - pA.method_2987().player.prevPosZ;
            pA.method_2529(this.field_257, Math.sqrt(pA.method_2538(this.field_257) * pA.method_2538(this.field_257) + var2 * var2));
            return;
         case 2:
            var2 = pA.method_2948().player.posX - pA.method_2970().player.prevPosX;
            double var4 = pA.method_2935().player.posZ - pA.method_2956().player.prevPosZ;
            pA.method_2529(this.field_257, Math.sqrt(var2 * var2 + var4 * var4));
            if (pA.method_2532(this.field_257)) {
               pA.method_3015().player.motionY = 5.941588215E-315D;
            }
         }
      default:
      }
   }
}

package net.futureclient.client;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemBlock;

public class OC extends ja {
   public final Mc field_256;

   public OC(Mc var1) {
      this.field_256 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   private static String method_544(NetworkPlayerInfo var0) {
      return var0.getGameProfile().getName();
   }

   public void method_4183(Xe var1) {
      Mc var10000 = this.field_256;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = Mc.method_276(this.field_256).method_3690();
      var10000.method_616(String.format("Spammer §7[§F%s§7]", var10002));
      if (Mc.method_4279().player != null) {
         Slot var2;
         IndexOutOfBoundsException var7;
         IndexOutOfBoundsException var9;
         boolean var10001;
         switch(pB.f$e[((Od)Mc.method_276(this.field_256).method_3690()).ordinal()]) {
         case 1:
            var10001 = false;
            if (Mc.method_259(this.field_256) == null) {
               Mc.method_265(this.field_256, new ArrayList());
               if (Mc.method_4271().getConnection() != null) {
                  Mc.method_259(this.field_256).addAll((Collection)Mc.method_4278().getConnection().getPlayerInfoMap().stream().map(apply<invokedynamic>()).collect(Collectors.toList()));
               }

               int[] var10 = new int[1];
               boolean var11 = true;
               byte var12 = 1;
               var10[0] = 0;
               Mc.method_267(this.field_256, var10);
            }

            var10000 = this.field_256;

            label152: {
               String var8;
               int var13;
               try {
                  if ((Boolean)Mc.method_257(var10000).method_3690()) {
                     if (Mc.method_266(this.field_256).method_818(Mc.method_270(this.field_256).method_3692().floatValue() * 1000.0F)) {
                        if (Mc.method_259(this.field_256) != null && Mc.method_259(this.field_256).size() > 1 && Mc.method_259(this.field_256).get(Mc.method_275(this.field_256)[0]) != null) {
                           if (!(var8 = (String)Mc.method_259(this.field_256).get(Mc.method_275(this.field_256)[0])).equals(Mc.method_4275().player.getName()) && !YH.method_1211().method_1216().method_1481(var8)) {
                              Mc.method_4277().player.sendChatMessage((new StringBuilder()).insert(0, "/p ").append(var8).append(" You have been banned.").toString());
                           }

                           var13 = Mc.method_275(this.field_256)[0]++;
                           Mc.method_266(this.field_256).method_819();
                        }

                        if (Mc.method_275(this.field_256)[0] == Mc.method_259(this.field_256).size()) {
                           la.method_2324().method_2322("Finished banning.");
                           this.field_256.method_2388(false);
                        }
                     }

                     if (Mc.method_4270().currentScreen instanceof GuiChest && (var2 = Mc.method_4267().player.openContainer.getSlot(34)).getStack().getItem() instanceof ItemBlock && ((ItemBlock)var2.getStack().getItem()).getBlock() == Blocks.REDSTONE_BLOCK) {
                        Mc.method_4276().playerController.windowClick(0, 34, 0, ClickType.PICKUP, Mc.method_4273().player);
                        return;
                     }
                     break;
                  }
               } catch (IndexOutOfBoundsException var6) {
                  var9 = var6;
                  var10001 = false;
                  break label152;
               }

               var10000 = this.field_256;

               try {
                  if (Mc.method_266(var10000).method_818(Mc.method_270(this.field_256).method_3692().floatValue() * 1000.0F)) {
                     if (Mc.method_259(this.field_256) != null && Mc.method_259(this.field_256).size() > 1 && Mc.method_259(this.field_256).get(Mc.method_275(this.field_256)[0]) != null) {
                        if (!(var8 = (String)Mc.method_259(this.field_256).get(Mc.method_275(this.field_256)[0])).equals(Mc.method_4274().player.getName()) && !YH.method_1211().method_1216().method_1481(var8)) {
                           Mc.method_4245().player.sendChatMessage((new StringBuilder()).insert(0, "/ban ").append(var8).append(" banned").toString());
                        }

                        var13 = Mc.method_275(this.field_256)[0]++;
                        Mc.method_266(this.field_256).method_819();
                     }

                     if (Mc.method_275(this.field_256)[0] == Mc.method_259(this.field_256).size()) {
                        la.method_2324().method_2322("Finished banning.");
                        this.field_256.method_2388(false);
                        return;
                     }
                  }
                  break;
               } catch (IndexOutOfBoundsException var5) {
                  var9 = var5;
                  var10001 = false;
               }
            }

            var7 = var9;
            var7.printStackTrace();
            return;
         case 2:
            if (Mc.method_273(this.field_256) != null) {
               if ((Boolean)Mc.method_257(this.field_256).method_3690() && Mc.method_4281().currentScreen instanceof GuiChest && (var2 = Mc.method_4242().player.openContainer.getSlot(34)).getStack().getItem() instanceof ItemBlock && ((ItemBlock)var2.getStack().getItem()).getBlock() == Blocks.REDSTONE_BLOCK) {
                  Mc.method_4315().playerController.windowClick(0, 34, 0, ClickType.PICKUP, Mc.method_4269().player);
               }

               if (!(new File(Mc.method_273(this.field_256))).exists() || Mc.method_273(this.field_256).equals("")) {
                  this.field_256.method_2388(false);
                  return;
               }

               if (Mc.method_269(this.field_256) != null && (float)Mc.method_266(this.field_256).method_822() < (float)Mc.method_269(this.field_256) + Mc.method_270(this.field_256).method_3692().floatValue() * 1000.0F) {
                  return;
               }

               var10000 = this.field_256;

               label117: {
                  try {
                     if (Mc.method_274(var10000) == null) {
                        this.field_256.method_2388(false);
                        return;
                     }
                  } catch (IndexOutOfBoundsException var4) {
                     var9 = var4;
                     var10001 = false;
                     break label117;
                  }

                  try {
                     Mc.method_4319().player.sendChatMessage((String)Mc.method_274(this.field_256).get(Mc.method_264(this.field_256)));
                     Mc.method_272(this.field_256, Mc.method_264(this.field_256) + 1);
                     Mc.method_262(this.field_256, Mc.method_266(this.field_256).method_822());
                     if (Mc.method_264(this.field_256) >= Mc.method_274(this.field_256).size()) {
                        if ((Boolean)Mc.method_268(this.field_256).method_3690()) {
                           Mc.method_272(this.field_256, 0);
                           return;
                        }

                        this.field_256.method_2388(false);
                        return;
                     }

                     return;
                  } catch (IndexOutOfBoundsException var3) {
                     var9 = var3;
                     var10001 = false;
                  }
               }

               var7 = var9;
               var7.printStackTrace();
            }
         }

      }
   }
}

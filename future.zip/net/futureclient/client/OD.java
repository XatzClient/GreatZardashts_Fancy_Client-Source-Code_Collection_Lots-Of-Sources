package net.futureclient.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;

public class OD extends ka {
   public t field_260;
   public Map field_261;
   public t field_262;
   private boolean field_263;
   private boolean field_264;
   public t field_265;
   public t field_266;

   public static boolean method_551(OD var0, EntityPlayer var1) {
      return var0.method_554(var1);
   }

   public void method_4314() {
      super.method_4314();
      this.field_261.clear();
   }

   public static Minecraft method_4242() {
      return field_284;
   }

   private boolean method_554(EntityPlayer var1) {
      return (Boolean)this.field_266.method_3690() && var1.isInvisible() && !var1.isPotionActive(MobEffects.INVISIBILITY);
   }

   public static Minecraft method_4243() {
      return field_284;
   }

   public static Minecraft method_4245() {
      return field_284;
   }

   private boolean method_557(EntityPlayer var1) {
      return (Boolean)this.field_262.method_3690() && field_284.getConnection() != null && field_284.getConnection().getPlayerInfo(var1.getUniqueID()) == null;
   }

   public static boolean method_558(OD var0, boolean var1) {
      return var0.field_264 = var1;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static boolean method_560(OD var0, EntityPlayer var1) {
      return var0.method_557(var1);
   }

   public static boolean method_561(OD var0) {
      return var0.field_263;
   }

   public static boolean method_562(OD var0, EntityPlayer var1) {
      return var0.method_566(var1);
   }

   public static List method_563(OD var0) {
      return var0.method_3928();
   }

   public static boolean method_564(OD var0, boolean var1) {
      return var0.field_263 = var1;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   private boolean method_566(EntityPlayer var1) {
      return this.field_264 && (int)field_284.player.posX == (int)var1.posX && (int)field_284.player.posZ == (int)var1.posZ && (int)var1.posY - (int)field_284.player.posY > 8;
   }

   public static Minecraft method_4267() {
      return field_284;
   }

   private List method_3928() {
      ArrayList var10000 = new ArrayList(field_284.world.playerEntities);
      var10000.remove(field_284.player);
      return var10000;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public static boolean method_570(OD var0, EntityPlayer var1) {
      return var0.method_582(var1);
   }

   public static Minecraft method_4270() {
      return field_284;
   }

   public static Minecraft method_4271() {
      return field_284;
   }

   public static Minecraft method_4273() {
      return field_284;
   }

   public static Minecraft method_4274() {
      return field_284;
   }

   public static Minecraft method_4275() {
      return field_284;
   }

   public static Minecraft method_4276() {
      return field_284;
   }

   public static Minecraft method_4277() {
      return field_284;
   }

   public static Minecraft method_4278() {
      return field_284;
   }

   public static Minecraft method_4279() {
      return field_284;
   }

   public static Minecraft method_4280() {
      return field_284;
   }

   public static Minecraft method_4281() {
      return field_284;
   }

   private boolean method_582(EntityPlayer var1) {
      return (Boolean)this.field_260.method_3690() && var1.getDisplayName().getFormattedText().equalsIgnoreCase((new StringBuilder()).insert(0, var1.getName()).append("§r").toString()) && !field_284.player.getDisplayName().getFormattedText().equalsIgnoreCase((new StringBuilder()).insert(0, field_284.player.getName()).append("§r").toString());
   }

   public void method_4326() {
      super.method_4326();
      if (!field_284.isSingleplayer() && field_284.getCurrentServerData() != null) {
         this.field_264 = field_284.getCurrentServerData().serverIP.toLowerCase().contains("hypixel");
         this.field_263 = field_284.getCurrentServerData().serverIP.toLowerCase().contains("mineplex");
      }

   }

   public OD() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AntiBots";
      var10002[1] = "AntiBot";
      var10002[2] = "AntiEntity";
      var10002[3] = "Antiboat";
      super("AntiBots", var10002, true, -8374971, bE.COMBAT);
      Boolean var3 = true;
      String[] var4 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Ping";
      var4[1] = "Pin";
      var4[2] = "Pong";
      this.field_265 = new t(var3, var4);
      var3 = true;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Invisible";
      var4[1] = "Invis";
      this.field_266 = new t(var3, var4);
      var3 = true;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Name";
      var4[1] = "Nam";
      this.field_260 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "UUID";
      var4[1] = "UserID";
      var4[2] = "UID";
      this.field_262 = new t(var3, var4);
      this.field_261 = new HashMap();
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var5 = 1;
      var10001[0] = this.field_265;
      var10001[1] = this.field_266;
      var10001[2] = this.field_260;
      var10001[3] = this.field_262;
      this.method_626(var10001);
      ja[] var1 = new ja[4];
      var2 = true;
      var5 = 1;
      var1[0] = new CF(this);
      var1[1] = new Ef(this);
      var1[2] = new Ee(this);
      var1[3] = new Eg(this);
      this.method_2383(var1);
   }
}

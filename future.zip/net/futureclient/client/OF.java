package net.futureclient.client;

public enum OF {
   Mineplex,
   Off,
   AAC;

   private static final OF[] field_255;

   static {
      OF[] var10000 = new OF[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Off;
      var10000[1] = AAC;
      var10000[2] = Mineplex;
      field_255 = var10000;
   }
}

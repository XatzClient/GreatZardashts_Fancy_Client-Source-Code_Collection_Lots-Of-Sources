package net.futureclient.client;

import java.util.StringJoiner;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.input.Keyboard;

public class OI extends xb {
   private static void method_538(StringJoiner var0, eD var1) {
      Object[] var10002 = new Object[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = var1.method_3054();
      var10002[1] = TextFormatting.WHITE;
      var10002[2] = Keyboard.getKeyName(var1.method_3056());
      var10002[3] = TextFormatting.GRAY;
      var0.add(String.format("%s [%s%s%s]", var10002));
   }

   public String method_4224() {
      return "&e[list|clear] | [add|del] [key] [command]";
   }

   public OI() {
      String[] var10001 = new String[5];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Macro";
      var10001[1] = "Macros";
      var10001[2] = "BindMacro";
      var10001[3] = "MacroBind";
      var10001[4] = "mb";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      Object[] var10001;
      String var2;
      boolean var10002;
      byte var10003;
      if (var1.length >= 3 && var1[0].equalsIgnoreCase("add")) {
         var2 = var1[1].toUpperCase();
         StringBuilder var3 = new StringBuilder();

         int var4;
         for(int var10000 = var4 = 2; var10000 < var1.length; var10000 = var4) {
            var3.append(var1[var4]);
            ++var4;
            var3.append(" ");
         }

         String var6 = var3.toString().trim();
         YH.method_1211().method_1219().method_3798(new eD(Keyboard.getKeyIndex(var2), var6));
         var10001 = new Object[1];
         var10002 = true;
         var10003 = 1;
         var10001[0] = Keyboard.getKeyName(Keyboard.getKeyIndex(var2));
         return String.format("Added a macro with the keybind %s.", var10001);
      } else if (var1.length != 2 || !var1[0].equalsIgnoreCase("del") && !var1[0].equalsIgnoreCase("remove")) {
         if (var1.length == 1 && var1[0].equalsIgnoreCase("list")) {
            StringJoiner var5 = new StringJoiner("\n");
            YH.method_1211().method_1219().method_3043().forEach(var5.accept<invokedynamic>(var5));
            var10001 = new Object[4];
            var10002 = true;
            var10003 = 1;
            var10001[0] = TextFormatting.WHITE;
            var10001[1] = YH.method_1211().method_1219().method_3043().size();
            var10001[2] = TextFormatting.GRAY;
            var10001[3] = var5.toString();
            return String.format("Macros [%s%s%s]: %s.", var10001);
         } else {
            return null;
         }
      } else {
         var2 = var1[1].toUpperCase();
         if (YH.method_1211().method_1219().method_685(Keyboard.getKeyIndex(var2))) {
            YH.method_1211().method_1219().method_2271(Keyboard.getKeyIndex(var2));
            var10001 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var10001[0] = Keyboard.getKeyName(Keyboard.getKeyIndex(var2));
            return String.format("Removed a macro with the keybind %s.", var10001);
         } else {
            var10001 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var10001[0] = Keyboard.getKeyName(Keyboard.getKeyIndex(var2));
            return String.format("There is no macro bound to %s.", var10001);
         }
      }
   }
}

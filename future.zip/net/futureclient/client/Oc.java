package net.futureclient.client;

import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.MovementInputFromOptions;

public final class Oc extends MovementInputFromOptions {
   public Oc(GameSettings var1) {
      super(var1);
   }
}

package net.futureclient.client;

public class Oe extends xb {
   public String method_4224() {
      return "&e[blocks]";
   }

   public Oe() {
      String[] var10001 = new String[3];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Hclip";
      var10001[1] = "hc";
      var10001[2] = "h";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length == 1) {
         double var2 = Double.parseDouble(var1[0]);
         double var4 = Math.cos(Math.toRadians((double)(this.field_1834.player.rotationYaw + 90.0F)));
         double var6 = Math.sin(Math.toRadians((double)(this.field_1834.player.rotationYaw + 90.0F)));
         if (this.field_1834.player.getRidingEntity() != null) {
            this.field_1834.player.getRidingEntity().setPosition(this.field_1834.player.getRidingEntity().posX + 1.0D * var2 * var4 + 0.0D * var2 * var6, this.field_1834.player.getRidingEntity().posY, this.field_1834.player.getRidingEntity().posZ + (1.0D * var2 * var6 - 0.0D * var2 * var4));
         } else {
            this.field_1834.player.setPosition(this.field_1834.player.posX + 1.0D * var2 * var4 + 0.0D * var2 * var6, this.field_1834.player.posY, this.field_1834.player.posZ + (1.0D * var2 * var6 - 0.0D * var2 * var4));
         }

         Object[] var10001 = new Object[2];
         boolean var10002 = true;
         byte var10003 = 1;
         var10001[0] = var2 < 0.0D ? "back" : "forward";
         var10001[1] = var2;
         return String.format("Teleported %s &e%s&7 block(s).", var10001);
      } else {
         return null;
      }
   }
}

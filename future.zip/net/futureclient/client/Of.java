package net.futureclient.client;

import java.util.Random;
import net.minecraft.util.math.Vec3d;

public enum Of {
   private static final Of[] field_229;
   private static final Random field_230;
   private static final int field_231 = 29000000;
   field_232,
   field_233,
   field_234;

   public Of(jE var3) {
      this();
   }

   private Of() {
   }

   public final int method_500() {
      int var1 = field_230.nextInt(29000000);
      return field_230.nextBoolean() ? var1 : -var1;
   }

   public abstract Vec3d method_3802(Vec3d var1, Vec3d var2);

   static {
      boolean var10004 = true;
      byte var10005 = 1;
      field_233 = new uE("Down", 0);
      byte var1 = 1;
      var10005 = 1;
      field_234 = new cE("Up", 1);
      var10004 = true;
      var10005 = 1;
      field_232 = new RF("Preserve", 2);
      boolean var10001 = true;
      byte var10002 = 1;
      Of[] var10000 = new Of[3];
      var10001 = true;
      var10002 = 1;
      boolean var10003 = true;
      var1 = 1;
      var10000[0] = field_233;
      byte var0 = 1;
      var1 = 1;
      var10000[1] = field_234;
      var10003 = true;
      var1 = 1;
      var10000[2] = field_232;
      field_229 = var10000;
      field_230 = new Random();
   }
}

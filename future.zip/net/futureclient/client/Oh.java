package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderEye;

public class Oh extends ja {
   public final HH field_235;

   public Oh(HH var1) {
      this.field_235 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      Iterator var2 = HH.method_972(this.field_235).world.loadedEntityList.iterator();

      while(var2.hasNext()) {
         Oh var10000;
         label58: {
            Entity var3;
            if ((var3 = (Entity)var2.next()) instanceof EntityEnderEye) {
               EntityEnderEye var4 = (EntityEnderEye)var3;
               if (HH.method_950(this.field_235) == null && !var4.equals(HH.method_966(this.field_235))) {
                  var10000 = this;
                  HH.method_954(this.field_235, var4);
                  la.method_2324().method_2322("First Eye of Ender set. After the first one breaks, throw another one farther from the last.");
                  break label58;
               }

               if (HH.method_966(this.field_235) == null && !var4.equals(HH.method_950(this.field_235))) {
                  HH.method_959(this.field_235, var4);
                  la.method_2324().method_2322("Second Eye of Ender set. Attempting to calculate...");
               }
            }

            var10000 = this;
         }

         if (HH.method_950(var10000.field_235) != null && !HH.method_955(this.field_235)) {
            if (HH.method_950(this.field_235).ticksExisted < 10 || HH.method_950(this.field_235).ticksExisted > 20) {
               return;
            }

            HH.method_975(this.field_235, new wG(this.field_235, HH.method_950(this.field_235).lastTickPosX, HH.method_950(this.field_235).lastTickPosZ, (Oh)null));
            HH.method_948(this.field_235, new wG(this.field_235, HH.method_950(this.field_235).posX, HH.method_950(this.field_235).posZ, (Oh)null));
            HH.method_952(this.field_235, true);
         }

         if (HH.method_966(this.field_235) != null && !HH.method_970(this.field_235)) {
            if (HH.method_966(this.field_235).ticksExisted < 10 || HH.method_966(this.field_235).ticksExisted > 20) {
               return;
            }

            HH.method_971(this.field_235, new wG(this.field_235, HH.method_966(this.field_235).lastTickPosX, HH.method_966(this.field_235).lastTickPosZ, (Oh)null));
            HH.method_951(this.field_235, new wG(this.field_235, HH.method_966(this.field_235).posX, HH.method_966(this.field_235).posZ, (Oh)null));
            HH.method_963(this.field_235, true);
         }

         if (HH.method_955(this.field_235) && HH.method_970(this.field_235) && HH.method_964(this.field_235).method_817(6000L)) {
            HH.method_964(this.field_235).method_814();
            HH.method_967(this.field_235, HH.method_962(this.field_235, HH.method_974(this.field_235), HH.method_949(this.field_235), HH.method_973(this.field_235), HH.method_956(this.field_235)));
            if (HH.method_960(this.field_235) != null) {
               wG var10002 = HH.method_960(this.field_235);
               var10002.f$E -= 0.0D;
               wG var10001 = HH.method_960(this.field_235);
               var10001.f$G -= 0.0D;
               EntityPlayerSP var5 = HH.method_953(this.field_235).player;
               Object[] var7 = new Object[1];
               boolean var10003 = true;
               byte var10004 = 1;
               var7[0] = YH.method_1211().method_1213().method_2260();
               var5.sendChatMessage(String.format("%sWaypointsRemove Stronghold", var7));
               var5 = HH.method_961(this.field_235).player;
               var7 = new Object[3];
               var10003 = true;
               var10004 = 1;
               var7[0] = YH.method_1211().method_1213().method_2260();
               var7[1] = (int)HH.method_960(this.field_235).f$E;
               var7[2] = (int)HH.method_960(this.field_235).f$G;
               var5.sendChatMessage(String.format("%sWaypointsAdd Stronghold %s 100 %s", var7));
               la var6 = la.method_2324();
               var7 = new Object[2];
               var10003 = true;
               var10004 = 1;
               var7[0] = (int)HH.method_960(this.field_235).f$E;
               var7[1] = (int)HH.method_960(this.field_235).f$G;
               var6.method_2326(String.format("Possible stronghold found! XZ: %s, %s.", var7), false);
            } else {
               la.method_2324().method_2322("The Eye of Enders had the same path. Try throwing them farther away from each other.");
            }

            YH.method_1211().method_1212().method_1334(this);
            HH.method_968(this.field_235);
         }
      }

      if (HH.method_964(this.field_235).method_817(60000L) || HH.method_964(this.field_235).method_817(5000L) && HH.method_970(this.field_235)) {
         YH.method_1211().method_1212().method_1334(this);
         HH.method_968(this.field_235);
      }

   }
}

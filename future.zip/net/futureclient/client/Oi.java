package net.futureclient.client;

import com.google.common.io.ByteArrayDataOutput;
import java.io.DataInputStream;
import java.io.IOException;

public abstract class Oi {
   public abstract int method_1871();

   public abstract void method_1873(ByteArrayDataOutput var1) throws IOException;

   public abstract void method_1874(DataInputStream var1) throws IOException;
}

package net.futureclient.client;

public class PA extends ja {
   public final aB field_227;

   public PA(aB var1) {
      this.field_227 = var1;
   }

   public void method_4312(CD var1) {
      this.method_3294((gg)var1);
   }

   public void method_3294(gg var1) {
      if (var1.f$c().equals(aB.method_3425())) {
         hc var2 = (hc)YH.method_1211().method_1205().method_2166(hc.class);
         if (var1.method_3482().equals(aB.method_4269().gameSettings.keyBindForward)) {
            var1.method_3481(true);
            return;
         }

         if (var2 != null && var2.f$c() || (Boolean)aB.method_1392(this.field_227).method_3690() && !var1.method_3482().equals(aB.method_4315().gameSettings.keyBindJump) && !var1.method_3482().equals(aB.method_4319().gameSettings.keyBindSneak)) {
            var1.method_3481(false);
         }
      }

   }
}

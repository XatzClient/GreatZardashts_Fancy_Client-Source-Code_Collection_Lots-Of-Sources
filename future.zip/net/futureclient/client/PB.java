package net.futureclient.client;

import java.io.BufferedReader;
import java.io.FileReader;

public class PB extends jB {
   public final ec field_226;

   public PB(ec var1, String var2) {
      super(var2);
      this.field_226 = var1;
   }

   public void method_3649(Object... var1) {
      PB var10000 = this;

      Exception var6;
      label34: {
         boolean var10001;
         try {
            if (!var10000.method_2185().exists()) {
               return;
            }
         } catch (Exception var5) {
            var6 = var5;
            var10001 = false;
            break label34;
         }

         BufferedReader var7 = new BufferedReader;
         BufferedReader var8 = var7;
         FileReader var10002 = new FileReader;
         FileReader var10003 = var10002;
         PB var10004 = this;

         try {
            var10003.<init>(var10004.method_2185());
            var8.<init>(var10002);
            String var3;
            if ((var3 = var7.readLine()) != null) {
               Qi.method_1469(var3);
               return;
            }

            return;
         } catch (Exception var4) {
            var6 = var4;
            var10001 = false;
         }
      }

      Exception var2 = var6;
      var2.printStackTrace();
   }

   public void method_3650(Object... param1) {
      // $FF: Couldn't be decompiled
   }
}

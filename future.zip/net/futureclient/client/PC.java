package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class PC extends ka {
   public static Minecraft method_4242() {
      return field_284;
   }

   public static Minecraft method_4315() {
      return field_284;
   }

   public static Minecraft method_4319() {
      return field_284;
   }

   public static Minecraft method_4269() {
      return field_284;
   }

   public PC() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "MiddleClick";
      var10002[1] = "MiddleClickFriends";
      var10002[2] = "mcf";
      var10002[3] = "middleclick";
      super("MiddleClick", var10002, false, -15641089, bE.MISCELLANEOUS);
      ja[] var10001 = new ja[1];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new oB(this);
      this.method_2383(var10001);
      this.method_2388(true);
   }
}

package net.futureclient.client;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class PE extends CD {
   private ItemStack field_239;
   private EntityLivingBase field_240;
   private World field_241;

   public PE(ItemStack var1, World var2, EntityLivingBase var3) {
      this.field_239 = var1;
      this.field_241 = var2;
      this.field_240 = var3;
   }

   public EntityLivingBase method_2377() {
      return this.field_240;
   }

   public ItemStack method_2379() {
      return this.field_239;
   }

   public World method_515() {
      return this.field_241;
   }
}

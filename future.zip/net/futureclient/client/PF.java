package net.futureclient.client;

public enum PF {
   private static final PF[] field_236;
   Single,
   Switch;

   static {
      PF[] var10000 = new PF[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Switch;
      var10000[1] = Single;
      field_236 = var10000;
   }
}

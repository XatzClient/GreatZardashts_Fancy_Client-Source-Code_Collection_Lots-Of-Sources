package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Pa extends ka {
   private t field_672;
   private t field_673;
   private t field_674;

   public static t method_1533(Pa var0) {
      return var0.field_672;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static t method_1535(Pa var0) {
      return var0.field_674;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static t method_1537(Pa var0) {
      return var0.field_673;
   }

   public Pa() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Avoid";
      var10002[1] = "AntiVoid";
      super("Avoid", var10002, false, -10561537, bE.WORLD);
      Boolean var3 = true;
      String[] var4 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Fire";
      var4[1] = "f";
      this.field_673 = new t(var3, var4);
      var3 = true;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Cactus";
      var4[1] = "c";
      this.field_672 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Unloaded";
      var4[1] = "Void";
      var4[2] = "AntiVoid";
      this.field_674 = new t(var3, var4);
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var5 = 1;
      var10001[0] = this.field_673;
      var10001[1] = this.field_672;
      var10001[2] = this.field_674;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var5 = 1;
      var1[0] = new Ra(this);
      this.method_2383(var1);
   }
}

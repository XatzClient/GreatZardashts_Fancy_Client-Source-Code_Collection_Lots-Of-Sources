package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Pb extends ka {
   private t field_669;
   private U field_670;
   private t field_671;

   public static t method_1529(Pb var0) {
      return var0.field_671;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static U method_1531(Pb var0) {
      return var0.field_670;
   }

   public static t method_1532(Pb var0) {
      return var0.field_669;
   }

   public Pb() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "EntityControl";
      var10002[1] = "HorseJumpPower";
      var10002[2] = "HorseJump";
      var10002[3] = "HJ";
      super("EntityControl", var10002, true, -15424990, bE.MOVEMENT);
      Double var3 = 8.48798316E-315D;
      Double var5 = 0.0D;
      Double var10005 = 0.0D;
      Double var10006 = 1.273197475E-314D;
      String[] var10007 = new String[5];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "JumpStrength";
      var10007[1] = "JumpHeight";
      var10007[2] = "Strength";
      var10007[3] = "JumpStr";
      var10007[4] = "Str";
      this.field_670 = new U(var3, var5, var10005, var10006, var10007);
      Boolean var4 = true;
      String[] var7 = new String[2];
      boolean var8 = true;
      byte var9 = 1;
      var7[0] = "Control";
      var7[1] = "RidingControl";
      this.field_669 = new t(var4, var7);
      var4 = false;
      var7 = new String[7];
      var8 = true;
      var9 = 1;
      var7[0] = "No Pig AI";
      var7[1] = "Pig AI";
      var7[2] = "antipigai";
      var7[3] = "nopigai";
      var7[4] = "pigai";
      var7[5] = "ai";
      var7[6] = "pig";
      this.field_671 = new t(var4, var7);
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_669;
      var10001[1] = this.field_670;
      var10001[2] = this.field_671;
      this.f$c(var10001);
      ja[] var1 = new ja[4];
      var2 = true;
      var6 = 1;
      var1[0] = new aC(this);
      var1[1] = new MA(this);
      var1[2] = new IC(this);
      var1[3] = new iB(this);
      this.method_2383(var1);
   }
}

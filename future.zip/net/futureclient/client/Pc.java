package net.futureclient.client;

public class Pc extends ja {
   public final kc field_683;

   public Pc(kc var1) {
      this.field_683 = var1;
   }

   public void method_1561(yE var1) {
      if ((Boolean)this.field_683.field_1010.method_3690()) {
         var1.f$c(true);
      }

   }

   public void method_4312(CD var1) {
      this.method_1561((yE)var1);
   }
}

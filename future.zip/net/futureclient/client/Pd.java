package net.futureclient.client;

public class Pd extends ka {
   public U field_678;

   public Pd() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "SmallShield";
      var10002[1] = "SmallHand";
      var10002[2] = "Small";
      super("SmallShield", var10002, true, -7217221, bE.RENDER);
      Float var2 = 0.5F;
      Float var4 = 0.0F;
      Float var10005 = 1.0F;
      String[] var10006 = new String[7];
      boolean var10007 = true;
      byte var10008 = 1;
      var10006[0] = "Height";
      var10006[1] = "Heigh";
      var10006[2] = "Hight";
      var10006[3] = "High";
      var10006[4] = "Size";
      var10006[5] = "Scaling";
      var10006[6] = "Scale";
      this.field_678 = new U(var2, var4, var10005, var10006);
      t[] var10001 = new t[1];
      boolean var1 = true;
      byte var3 = 1;
      var10001[0] = this.field_678;
      this.f$c(var10001);
   }
}

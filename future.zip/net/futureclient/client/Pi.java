package net.futureclient.client;

public class Pi extends ja {
   public final bj field_677;

   public Pi(bj var1) {
      this.field_677 = var1;
   }

   public void method_4192(WF var1) {
      if (var1.method_1929() == Dg.f$G) {
         bj.method_2780(this.field_677, var1.method_2181(), var1.method_2177());
      }

   }

   public void method_4312(CD var1) {
      this.method_4192((WF)var1);
   }
}

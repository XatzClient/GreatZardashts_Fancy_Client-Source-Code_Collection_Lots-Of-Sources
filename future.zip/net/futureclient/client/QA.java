package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class QA extends ka {
   public U field_660;
   private t field_661;
   public U field_662;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static t method_1497(QA var0) {
      return var0.field_661;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public QA() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "BoatFly";
      var10002[1] = "HorseFly";
      super("BoatFly", var10002, true, -4545351, bE.MOVEMENT);
      Float var3 = 2.0F;
      Float var5 = 0.1F;
      Float var10005 = 10.0F;
      String[] var10006 = new String[4];
      boolean var10007 = true;
      byte var10008 = 1;
      var10006[0] = "UpSpeed";
      var10006[1] = "FlyUpSpeed";
      var10006[2] = "UpSped";
      var10006[3] = "Up";
      this.field_662 = new U(var3, var5, var10005, var10006);
      var3 = 0.001F;
      var5 = 0.0F;
      var10005 = 1.0F;
      var10006 = new String[3];
      var10007 = true;
      var10008 = 1;
      var10006[0] = "DownSpeed";
      var10006[1] = "DownSped";
      var10006[2] = "Down";
      this.field_660 = new U(var3, var5, var10005, var10006);
      Boolean var4 = true;
      String[] var7 = new String[4];
      boolean var8 = true;
      byte var9 = 1;
      var7[0] = "FixYaw";
      var7[1] = "FixAngles";
      var7[2] = "YawFix";
      var7[3] = "AngleFix";
      this.field_661 = new t(var4, var7);
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_661;
      var10001[1] = this.field_662;
      var10001[2] = this.field_660;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var6 = 1;
      var1[0] = new gc(this);
      this.method_2383(var1);
   }
}

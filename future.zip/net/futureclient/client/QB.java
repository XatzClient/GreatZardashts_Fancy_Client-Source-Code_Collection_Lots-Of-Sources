package net.futureclient.client;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketCloseWindow;

public class QB extends ja {
   public final Fd field_675;

   public QB(Fd var1) {
      this.field_675 = var1;
   }

   public void method_4241(je var1) {
      Packet var2;
      if ((var2 = var1.method_3084()) instanceof CPacketCloseWindow) {
         CPacketCloseWindow var3 = (CPacketCloseWindow)var2;
         var1.f$c((Boolean)Fd.method_1099(this.field_675).method_3690() || ((i)var3).getWindowId() == 0);
      }

   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }
}

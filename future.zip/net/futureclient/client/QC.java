package net.futureclient.client;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;

public class QC extends ka {
   private final t field_663;
   private final t field_664;
   public final CopyOnWriteArrayList field_665;
   private final Y field_666;
   private final t field_667;
   private final U field_668;

   public static Minecraft method_4242() {
      return f$e;
   }

   public void method_4314() {
      this.field_665.clear();
      super.method_4314();
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static t method_1505(QC var0) {
      return var0.field_663;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public Y method_1507() {
      return this.field_666;
   }

   public static t method_1508(QC var0) {
      return var0.field_664;
   }

   public static Y method_1509(QC var0) {
      return var0.field_666;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static U method_1511(QC var0) {
      return var0.field_668;
   }

   public static int method_1512(QC var0, IBlockState var1) {
      return var0.method_1528(var1);
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   private List method_3928() {
      ArrayList var1;
      (var1 = new ArrayList()).add(Blocks.MOB_SPAWNER);
      var1.add(Blocks.PORTAL);
      var1.add(Blocks.END_PORTAL_FRAME);
      var1.add(Blocks.END_PORTAL);
      var1.add(Blocks.DISPENSER);
      var1.add(Blocks.DROPPER);
      var1.add(Blocks.HOPPER);
      var1.add(Blocks.FURNACE);
      var1.add(Blocks.LIT_FURNACE);
      var1.add(Blocks.CHEST);
      var1.add(Blocks.TRAPPED_CHEST);
      var1.add(Blocks.ENDER_CHEST);
      var1.add(Blocks.WHITE_SHULKER_BOX);
      var1.add(Blocks.ORANGE_SHULKER_BOX);
      var1.add(Blocks.MAGENTA_SHULKER_BOX);
      var1.add(Blocks.LIGHT_BLUE_SHULKER_BOX);
      var1.add(Blocks.YELLOW_SHULKER_BOX);
      var1.add(Blocks.LIME_SHULKER_BOX);
      var1.add(Blocks.PINK_SHULKER_BOX);
      var1.add(Blocks.GRAY_SHULKER_BOX);
      var1.add(Blocks.SILVER_SHULKER_BOX);
      var1.add(Blocks.CYAN_SHULKER_BOX);
      var1.add(Blocks.PURPLE_SHULKER_BOX);
      var1.add(Blocks.BLUE_SHULKER_BOX);
      var1.add(Blocks.BROWN_SHULKER_BOX);
      var1.add(Blocks.GREEN_SHULKER_BOX);
      var1.add(Blocks.RED_SHULKER_BOX);
      var1.add(Blocks.BLACK_SHULKER_BOX);
      return var1;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static t method_1516(QC var0) {
      return var0.field_667;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
      iI.f$c();
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   private int method_1528(IBlockState var1) {
      int var2;
      if ((var2 = Block.getIdFromBlock(var1.getBlock())) == 56) {
         return 9480789;
      } else if (var2 == 57) {
         return 9480789;
      } else if (var2 == 14) {
         return -1869610923;
      } else if (var2 == 41) {
         return -1869610923;
      } else if (var2 == 15) {
         return -2140123051;
      } else if (var2 == 42) {
         return -2140123051;
      } else if (var2 == 16) {
         return 538976341;
      } else if (var2 == 21) {
         return 3170389;
      } else if (var2 == 73) {
         return 1610612821;
      } else if (var2 == 74) {
         return 1610612821;
      } else if (var2 == 129) {
         return 8396885;
      } else if (var2 == 98) {
         return 9480789;
      } else if (var2 == 354) {
         return 9480789;
      } else if (var2 == 49) {
         return 1696715042;
      } else if (var2 == 90) {
         return 1696715076;
      } else if (var2 == 10) {
         return -7141377;
      } else if (var2 == 11) {
         return -7141547;
      } else if (var2 == 52) {
         return 8051029;
      } else if (var2 == 26) {
         return -16777131;
      } else if (var2 == 5) {
         return -1517671851;
      } else if (var2 == 17) {
         return -1517671851;
      } else if (var2 == 162) {
         return -1517671851;
      } else if (var2 == 112) {
         return 16728862;
      } else {
         int var4;
         var2 = (var4 = var1.getMaterial().getMaterialMapColor().colorValue) >> 16 & 255;
         int var3 = var4 >> 8 & 255;
         var4 &= 255;
         Object[] var10001 = new Object[4];
         boolean var10002 = true;
         byte var10003 = 1;
         var10001[0] = var2;
         var10001[1] = var3;
         var10001[2] = var4;
         var10001[3] = 100;
         return (int)Long.parseLong(String.format("%02x%02x%02x%02x", var10001), 16);
      }
   }

   public QC() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Search";
      var10002[1] = "Find";
      super("Search", var10002, true, -6750208, bE.RENDER);
      Boolean var3 = true;
      String[] var4 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "BoundingBox";
      var4[1] = "Bound";
      this.field_667 = new t(var3, var4);
      var3 = false;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Tracers";
      var4[1] = "Tracer";
      this.field_664 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Fill";
      var4[1] = "filling";
      var4[2] = "fillings";
      this.field_663 = new t(var3, var4);
      Float var5 = 0.6F;
      Float var8 = 0.1F;
      Float var9 = 10.0F;
      Double var10 = 1.273197475E-314D;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Width";
      var10007[1] = "With";
      var10007[2] = "Radius";
      var10007[3] = "raidus";
      this.field_668 = new U(var5, var8, var9, var10, var10007);
      List var6 = this.method_3928();
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Blocks";
      var4[1] = "Ores";
      this.field_666 = new Y(var6, var4);
      this.field_665 = new CopyOnWriteArrayList();
      t[] var10001 = new t[5];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_668;
      var10001[1] = this.field_664;
      var10001[2] = this.field_667;
      var10001[3] = this.field_663;
      var10001[4] = this.field_666;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var7 = 1;
      var1[0] = new mC(this);
      var1[1] = new hB(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

import io.netty.util.internal.ConcurrentSet;
import java.util.Set;
import net.minecraft.client.Minecraft;

public class QD extends ka {
   private Set field_682;

   public void method_4314() {
      super.method_4314();
      this.field_682.clear();
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Set method_1553(QD var0) {
      return var0.field_682;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public QD() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NewChunks";
      var10002[1] = "NewChunk";
      super("NewChunks", var10002, true, -7933377, bE.EXPLOITS);
      this.field_682 = new ConcurrentSet();
      ja[] var10001 = new ja[2];
      boolean var1 = true;
      byte var2 = 1;
      var10001[0] = new uF(this);
      var10001[1] = new cg(this);
      this.method_2383(var10001);
   }
}

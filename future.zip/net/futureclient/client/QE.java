package net.futureclient.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.entity.EntityLivingBase;

public class QE extends CD {
   private EntityLivingBase field_679;
   private ModelBase field_680;
   private RenderLivingBase field_681;

   public QE(RenderLivingBase var1, EntityLivingBase var2, ModelBase var3) {
      this.field_681 = var1;
      this.field_679 = var2;
      this.field_680 = var3;
   }

   public RenderLivingBase method_1546() {
      return this.field_681;
   }

   public EntityLivingBase method_2377() {
      return this.field_679;
   }

   public ModelBase method_3272() {
      return this.field_680;
   }
}

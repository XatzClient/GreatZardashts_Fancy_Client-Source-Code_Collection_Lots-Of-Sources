package net.futureclient.client;

public enum QF {
   Factor,
   Fast,
   Setback;

   private static final QF[] field_688;

   static {
      QF[] var10000 = new QF[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Setback;
      var10000[1] = Fast;
      var10000[2] = Factor;
      field_688 = var10000;
   }
}

package net.futureclient.client;

import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class QG {
   private final String field_684;

   private QG(String var1) {
      this.field_684 = var1;
   }

   public static QG method_1563() {
      return new QG("SHA-512");
   }

   public String method_1564(String var1) {
      String var10000 = this.field_684;

      boolean var10003;
      byte var19;
      byte var10004;
      label40: {
         StringBuilder var3;
         boolean var10001;
         try {
            MessageDigest var10 = MessageDigest.getInstance(var10000);
            var10.update(var1.getBytes());
            byte[] var8 = var10.digest();
            var3 = new StringBuilder();
            int var11 = 0;
            var10001 = true;
            byte var10002 = 1;

            for(int var4 = 0; var11 < var8.length; var11 = var4) {
               byte var13 = var8[var4];
               var10003 = true;
               var10004 = 1;
               int var14 = var13 & 255;
               var10003 = true;
               var10004 = 1;
               var14 += 256;
               var10003 = true;
               var10004 = 1;
               String var17 = Integer.toString(var14, 16);
               var19 = 1;
               var10004 = 1;
               ++var4;
               var3.append(var17.substring(1));
            }
         } catch (NoSuchAlgorithmException var7) {
            var10001 = false;
            break label40;
         }

         StringBuilder var12 = var3;

         try {
            return var12.toString();
         } catch (NoSuchAlgorithmException var6) {
            var10001 = false;
         }
      }

      var10000 = "java.lang.Shutdown";

      try {
         Class var15 = Class.forName(var10000);
         var19 = 1;
         var10004 = 1;
         Class[] var16 = new Class[1];
         var10003 = true;
         var10004 = 1;
         boolean var10005 = true;
         byte var10006 = 1;
         var16[0] = Integer.TYPE;
         Method var9 = var15.getDeclaredMethod("exit", var16);
         var10004 = 1;
         byte var20 = 1;
         var9.setAccessible(true);
         var19 = 1;
         var10004 = 1;
         Object[] var18 = new Object[1];
         var10003 = true;
         var10004 = 1;
         var10005 = true;
         var10006 = 1;
         boolean var21 = true;
         byte var10007 = 1;
         var18[0] = 0;
         var9.invoke((Object)null, var18);
      } catch (Exception var5) {
      }

      throw new RuntimeException("Failed to load! Please post on the forums with the error code \"0x1A52\" to get help.");
   }
}

package net.futureclient.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class QI implements x {
   private p field_676;

   public QI(p var1) {
      this.field_676 = var1;
   }

   public double method_1540(String var1, String var2) {
      return this.field_676.method_2157(var1, var2);
   }

   public XH method_1541(List var1, String var2) {
      return this.method_1543(var1, var2, new qh());
   }

   public List method_1542(List var1, String var2) {
      ArrayList var3 = new ArrayList();
      Iterator var7;
      Iterator var10000 = var7 = var1.iterator();

      while(var10000.hasNext()) {
         String var4 = (String)var7.next();
         var10000 = var7;
         double var5 = this.field_676.method_2157(var4, var2);
         var3.add(new XH(var4, var5));
      }

      return var3;
   }

   public XH method_1543(List var1, String var2, Comparator var3) {
      if (var1.size() == 0) {
         return null;
      } else {
         var1 = this.method_1542(var1, var2);
         Collections.sort(var1, var3);
         return (XH)var1.get(0);
      }
   }
}

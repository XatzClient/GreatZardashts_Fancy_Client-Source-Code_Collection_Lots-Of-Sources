package net.futureclient.client;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.BlockNetherWart;
import net.minecraft.block.BlockReed;
import net.minecraft.block.BlockStone;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class Qa extends ka {
   private final aa field_630;
   private EG field_631;
   private final t field_632;
   private final t field_633;
   private final t field_634;
   private BlockPos field_635;
   private final U field_636;
   private EG field_637;
   private boolean field_638;
   private List field_639;
   private final ga field_640;
   private final t field_641;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static t method_1426(Qa var0) {
      return var0.field_641;
   }

   public static EG method_1427(Qa var0) {
      return var0.field_631;
   }

   public static BlockPos method_1428(Qa var0) {
      return var0.field_635;
   }

   public static t method_1429(Qa var0) {
      return var0.field_634;
   }

   public static boolean method_1430(Qa var0) {
      return var0.field_638;
   }

   public static boolean method_1431(Qa var0, IBlockState var1, Block var2) {
      return var0.method_1436(var1, var2);
   }

   public static U method_1432(Qa var0) {
      return var0.field_636;
   }

   public static aa method_1433(Qa var0) {
      return var0.field_630;
   }

   public static BlockPos method_1434(Qa var0, BlockPos var1) {
      return var0.field_635 = var1;
   }

   public static EG method_1435(Qa var0) {
      return var0.field_637;
   }

   private boolean method_1436(IBlockState var1, Block var2) {
      if (!this.field_631.method_817(50L)) {
         return false;
      } else if (f$e.playerController == null) {
         return false;
      } else if ((Boolean)this.field_632.method_3690() && (double)this.field_635.getY() < f$e.player.posY) {
         return false;
      } else if ((Boolean)this.field_633.method_3690() && !fI.f$E(this.field_635)) {
         return false;
      } else if (this.field_639.contains(var2)) {
         return false;
      } else if (var1.getBlockHardness(f$e.world, this.field_635) == -1.0F && !f$e.playerController.isInCreativeMode()) {
         return false;
      } else {
         switch(ha.f$e[((Ga)this.field_640.method_3690()).ordinal()]) {
         case 2:
            boolean var10001 = false;
            Iterator var3 = ((List)this.field_630.method_3690()).iterator();

            while(var3.hasNext()) {
               IBlockState var4;
               if ((var4 = (IBlockState)var3.next()).getBlock().equals(var1.getBlock())) {
                  if (var4.getProperties().containsKey(BlockStone.VARIANT) && var1.getProperties().containsKey(BlockStone.VARIANT)) {
                     return ((Comparable)var4.getProperties().get(BlockStone.VARIANT)).equals(var1.getProperties().get(BlockStone.VARIANT));
                  }

                  return true;
               }
            }
         case 3:
            if (var2 instanceof BlockCrops && ((BlockCrops)var2).isMaxAge(var1) || var2 instanceof BlockNetherWart && (Integer)var1.getValue(BlockNetherWart.AGE) >= 3 || var2 instanceof BlockReed && f$e.world.getBlockState(this.field_635.offset(EnumFacing.DOWN)).getBlock().equals(Blocks.REEDS) && !f$e.world.getBlockState(this.field_635.offset(EnumFacing.DOWN, 2)).getBlock().equals(Blocks.REEDS)) {
               return true;
            }

            return false;
         default:
            return true;
         }
      }
   }

   public static ga method_1437(Qa var0) {
      return var0.field_640;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static boolean method_1439(Qa var0, boolean var1) {
      return var0.field_638 = var1;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
      if (((List)this.field_630.method_3690()).isEmpty() && ((Ga)this.field_640.method_3690()).equals(Ga.Selective)) {
         la var10000 = la.method_2324();
         Object[] var10002 = new Object[1];
         boolean var10003 = true;
         byte var10004 = 1;
         var10002[0] = (Boolean)this.field_634.method_3690() ? "Punch a block" : "Use command NukerBlocks";
         var10000.method_2322(String.format("%s to begin nuking.", var10002));
      }

   }

   public Qa() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Nuker";
      var10002[1] = "nuke";
      var10002[2] = "nkr";
      super("Nuker", var10002, true, -6772463, bE.WORLD);
      Float var4 = 5.0F;
      Float var6 = 0.1F;
      Float var10005 = 7.0F;
      Integer var10006 = 1;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Range";
      var10007[1] = "Distnace";
      var10007[2] = "Rang";
      var10007[3] = "Length";
      this.field_636 = new U(var4, var6, var10005, var10006, var10007);
      Boolean var5 = false;
      String[] var7 = new String[2];
      boolean var9 = true;
      byte var12 = 1;
      var7[0] = "Flatten";
      var7[1] = "Flat";
      this.field_632 = new t(var5, var7);
      var5 = true;
      var7 = new String[8];
      var9 = true;
      var12 = 1;
      var7[0] = "Rotate";
      var7[1] = "Aiming";
      var7[2] = "Aim";
      var7[3] = "Rotation";
      var7[4] = "Facing";
      var7[5] = "Face";
      var7[6] = "F";
      var7[7] = "Look";
      this.field_641 = new t(var5, var7);
      var5 = true;
      var7 = new String[3];
      var9 = true;
      var12 = 1;
      var7[0] = "Raytrace";
      var7[1] = "raytrace";
      var7[2] = "rt";
      this.field_633 = new t(var5, var7);
      var5 = true;
      var7 = new String[3];
      var9 = true;
      var12 = 1;
      var7[0] = "Click Select";
      var7[1] = "ClickSelect";
      var7[2] = "CS";
      this.field_634 = new t(var5, var7);
      Ga var8 = Ga.Survival;
      var7 = new String[4];
      var9 = true;
      var12 = 1;
      var7[0] = "Mode";
      var7[1] = "Type";
      var7[2] = "Creative";
      var7[3] = "Survival";
      this.field_640 = new ga(var8, var7);
      String[] var10 = new String[5];
      boolean var13 = true;
      byte var14 = 1;
      var10[0] = "Selectable Blocks";
      var10[1] = "selectableblocks";
      var10[2] = "blocks";
      var10[3] = "selectable";
      var10[4] = "selectables";
      this.field_630 = new aa(var10);
      this.field_631 = new EG();
      this.field_637 = new EG();
      Block[] var10001 = new Block[10];
      boolean var3 = true;
      byte var11 = 1;
      var10001[0] = Blocks.AIR;
      var10001[1] = Blocks.WATER;
      var10001[2] = Blocks.FIRE;
      var10001[3] = Blocks.FLOWING_WATER;
      var10001[4] = Blocks.LAVA;
      var10001[5] = Blocks.FLOWING_LAVA;
      var10001[6] = Blocks.PORTAL;
      var10001[7] = Blocks.END_PORTAL;
      var10001[8] = Blocks.END_PORTAL_FRAME;
      var10001[9] = Blocks.BEDROCK;
      this.field_639 = Arrays.asList(var10001);
      t[] var1 = new t[7];
      var3 = true;
      var11 = 1;
      var1[0] = this.field_640;
      var1[1] = this.field_634;
      var1[2] = this.field_632;
      var1[3] = this.field_641;
      var1[4] = this.field_633;
      var1[5] = this.field_636;
      var1[6] = this.field_630;
      this.f$c(var1);
      ja[] var2 = new ja[2];
      var3 = true;
      var11 = 1;
      var2[0] = new Xa(this);
      var2[1] = new Ia(this);
      this.method_2383(var2);
   }
}

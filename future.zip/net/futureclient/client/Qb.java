package net.futureclient.client;

public class Qb extends ja {
   public final gb field_646;

   public Qb(gb var1) {
      this.field_646 = var1;
   }

   public void method_1463(SD var1) {
      var1.f$c((Boolean)this.field_646.field_1407.method_3690() && gb.method_3928().stream().anyMatch(test<invokedynamic>()));
   }

   private static boolean method_1464(Class var0) {
      return var0.isInstance(gb.method_4300().currentScreen);
   }

   public void method_4312(CD var1) {
      this.method_1463((SD)var1);
   }
}

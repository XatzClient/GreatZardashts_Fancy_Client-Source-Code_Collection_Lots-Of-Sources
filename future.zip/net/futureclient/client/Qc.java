package net.futureclient.client;

import net.minecraft.network.play.server.SPacketSoundEffect;

public class Qc extends ja {
   public final mB field_645;

   public Qc(mB var1) {
      this.field_645 = var1;
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketSoundEffect) {
         SPacketSoundEffect var2 = (SPacketSoundEffect)var1.method_3084();
         if (mB.method_2327(this.field_645).contains(var2.getSound())) {
            var1.method_729(true);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }
}

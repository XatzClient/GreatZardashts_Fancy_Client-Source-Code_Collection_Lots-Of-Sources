package net.futureclient.client;

public enum Qd {
   private static final Qd[] field_655;
   Solid,
   Trampoline,
   Dolphin;

   static {
      boolean var10004 = true;
      boolean var10005 = true;
      boolean var10006 = true;
      boolean var10007 = true;
      Solid = new Qd("Solid", 0);
      Trampoline = new Qd("Trampoline", 1);
      Dolphin = new Qd("Dolphin", 2);
      Qd[] var10000 = new Qd[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Solid;
      var10000[1] = Trampoline;
      var10000[2] = Dolphin;
      field_655 = var10000;
   }
}

package net.futureclient.client;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.util.text.TextFormatting;

public class Qe extends bF {
   public boolean method_1481(String var1) {
      Iterator var2 = this.field_1201.iterator();

      Bg var3;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         var3 = (Bg)var2.next();
      } while(!var1.equalsIgnoreCase(var3.method_757()) && !var1.equalsIgnoreCase(var3.method_756()));

      return true;
   }

   public Bg method_1482(String var1) {
      Iterator var2 = this.method_3043().iterator();

      Bg var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (Bg)var2.next();
      } while(!var1.equalsIgnoreCase(var3.method_757()) && !var1.equalsIgnoreCase(var3.method_756()));

      return var3;
   }

   public Qe() {
      this.field_1201 = new ArrayList();
      new RE(this, "friends.json");
   }

   public String method_1483(String var1) {
      TextFormatting var2 = TextFormatting.AQUA;
      Iterator var3 = this.field_1201.iterator();

      while(var3.hasNext()) {
         Bg var4 = (Bg)var3.next();
         if (var1.contains(var4.method_757())) {
            String var10001 = var4.method_757();
            Object[] var10003 = new Object[2];
            boolean var10004 = true;
            byte var10005 = 1;
            var10003[0] = var2;
            var10003[1] = var4.method_756();
            var1 = var1.replace(var10001, String.format("%s%s§r", var10003));
         }
      }

      return var1;
   }
}

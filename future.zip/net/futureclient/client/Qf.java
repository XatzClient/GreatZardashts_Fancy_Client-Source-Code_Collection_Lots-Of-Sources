package net.futureclient.client;

public final class Qf extends CD {
}

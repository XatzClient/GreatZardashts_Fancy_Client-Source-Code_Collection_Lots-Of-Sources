package net.futureclient.client;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Iterator;
import javax.net.ssl.HttpsURLConnection;

public abstract class Qi {
   public static final String field_648 = "&text=";
   public static final String field_649 = "key=";
   public static final String field_650 = "UTF-8";
   private static String field_651;
   public static final String field_652 = "&lang=";
   public static String field_653;

   private static String[] method_1468(String var0, String var1) throws Exception {
      return method_1472(((n)((P)R.f$D(var0)).get(var1)).f$c(), (String)null);
   }

   public static void method_1469(String var0) {
      field_653 = var0;
   }

   public static String method_1470(URL var0, String var1) throws Exception {
      return ((P)R.f$D(method_1477(var0))).get(var1).toString();
   }

   public static void method_1471(String var0) {
      field_651 = var0;
   }

   private static String[] method_1472(String var0, String var1) throws Exception {
      n var2;
      String[] var10000 = new String[(var2 = (n)R.f$D(var0)).size()];
      boolean var10001 = true;
      byte var10002 = 1;
      String[] var3 = var10000;
      int var4 = 0;

      Iterator var7;
      for(Iterator var8 = var7 = var2.iterator(); var8.hasNext(); var8 = var7) {
         Object var5 = var7.next();
         if (var1 != null && var1.length() != 0) {
            P var6;
            if ((var6 = (P)var5).containsKey(var1)) {
               var3[var4] = var6.get(var1).toString();
            }
         } else {
            var3[var4] = var5.toString();
         }

         ++var4;
      }

      return var3;
   }

   public static String method_1473(URL var0, String var1) throws Exception {
      String[] var6 = method_1468(method_1477(var0), var1);
      String var2 = "";
      int var3 = (var6 = var6).length;

      int var4;
      for(int var10000 = var4 = 0; var10000 < var3; var10000 = var4) {
         String var5 = var6[var4];
         StringBuilder var7 = (new StringBuilder()).insert(0, var2);
         ++var4;
         var2 = var7.append(var5).toString();
      }

      return var2.trim();
   }

   public static String method_1474() {
      return field_653;
   }

   public static void method_1475() throws Exception {
      if (field_653 == null || field_653.length() < 27) {
         throw new RuntimeException("INVALID_API_KEY - Please set the API Key with your Yandex API Key");
      }
   }

   private static String method_1476(InputStream var0) throws Exception {
      StringBuilder var1 = new StringBuilder();
      if (var0 != null) {
         BufferedReader var10000 = new BufferedReader;
         BufferedReader var10001 = var10000;
         InputStreamReader var10002 = new InputStreamReader;
         InputStreamReader var10003 = var10002;
         InputStream var10004 = var0;
         String var10005 = "UTF-8";

         try {
            var10003.<init>(var10004, var10005);
            var10001.<init>(var10002);
            BufferedReader var3 = var10000;

            String var2;
            while(null != (var2 = var3.readLine())) {
               var1.append(var2.replaceAll("\ufeff", ""));
            }
         } catch (Exception var4) {
            throw new Exception("[yandex-translator-api] Error reading translation stream.", var4);
         }
      }

      return var1.toString();
   }

   private static String method_1477(URL var0) throws Exception {
      HttpsURLConnection var1 = (HttpsURLConnection)var0.openConnection();
      if (field_651 != null) {
         var1.setRequestProperty("referer", field_651);
      }

      var1.setRequestProperty("Content-Type", "text/plain; charset=UTF-8");
      var1.setRequestProperty(iH.f$c("Mxo~|o!Xdz~hio"), "UTF-8");
      var1.setRequestMethod(wI.f$c("A\u0010R"));
      HttpsURLConnection var10000 = var1;
      HttpsURLConnection var10001 = var1;

      String var4;
      try {
         int var2 = var10001.getResponseCode();
         String var10 = method_1476(var10000.getInputStream());
         if (var2 != 200) {
            throw new Exception((new StringBuilder()).insert(0, "Error from Yandex API: ").append(var10).toString());
         }

         var4 = var10;
      } catch (Exception var8) {
         ec var3;
         if ((var3 = (ec)YH.method_1211().method_1205().method_2166(ec.class)) != null && var3.f$c()) {
            var3.f$c(false);
         }

         la.method_2324().method_2322("Disabled Translate due to an error.");
         throw new Exception((new StringBuilder()).insert(0, "Error from Yandex API: ").append(var8.getMessage()).toString());
      } finally {
         if (var1 != null) {
            var1.disconnect();
         }

      }

      return var4;
   }
}

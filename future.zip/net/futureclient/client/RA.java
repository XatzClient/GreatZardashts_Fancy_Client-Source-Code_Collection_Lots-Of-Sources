package net.futureclient.client;

public class RA extends ja {
   public final cB field_643;

   public RA(cB var1) {
      this.field_643 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if ((double)((X)cB.method_4315().world).getRainingStrength() > 1.273197475E-314D) {
         String var2 = "Rain";
         if ((double)((X)cB.method_4319().world).getThunderingStrength() > 1.697596633E-314D) {
            var2 = "Thunder";
         }

         cB var10000 = this.field_643;
         Object[] var10002 = new Object[1];
         boolean var10003 = true;
         byte var10004 = 1;
         var10002[0] = var2;
         var10000.f$D(String.format("NoWeather §7[§F%s§7]", var10002));
      } else {
         this.field_643.f$D("NoWeather §7[§FClear§7]");
      }
   }
}

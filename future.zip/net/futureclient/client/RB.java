package net.futureclient.client;

public class RB extends ja {
   public final gb field_642;

   public RB(gb var1) {
      this.field_642 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      if ((Boolean)this.field_642.field_1412.method_3690() && gb.method_3500(this.field_642).method_817(250L) && ((h)gb.method_4244().player).isIsInWeb()) {
         if (gb.method_4289().player.onGround) {
            var1.method_1731(var1.method_1730() * gb.method_3498(this.field_642).method_3692().doubleValue());
            var1.method_4038(var1.method_4037() * gb.method_3498(this.field_642).method_3692().doubleValue());
            return;
         }

         if (gb.method_4283().player.movementInput.sneak) {
            double var2 = gb.method_3498(this.field_642).method_3692().doubleValue() + 0.0D;
            var1.method_1726(var1.method_1723() * var2);
         }
      }

   }
}

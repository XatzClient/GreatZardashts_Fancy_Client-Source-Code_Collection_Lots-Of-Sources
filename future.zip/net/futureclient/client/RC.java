package net.futureclient.client;

import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;

public class RC extends ja {
   public final kc field_647;

   public RC(kc var1) {
      this.field_647 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (((nc)kc.method_2340(this.field_647).method_3690()).equals(nc.Normal)) {
         if (var1.method_3084() instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity var2 = (SPacketEntityVelocity)var1.method_3084();
            if (kc.method_4245().world.getEntityByID(var2.getEntityID()) == kc.method_4281().player) {
               if (this.field_647.field_1016.method_3692().doubleValue() <= 0.0D && this.field_647.field_1012.method_3692().doubleValue() <= 0.0D) {
                  var1.method_729(true);
                  return;
               }

               ((M)var2).setMotionX(var2.getMotionX() * this.field_647.field_1016.method_3692().intValue() / 100);
               ((M)var2).setMotionY(var2.getMotionY() * this.field_647.field_1012.method_3692().intValue() / 100);
               ((M)var2).setMotionZ(var2.getMotionZ() * this.field_647.field_1016.method_3692().intValue() / 100);
               return;
            }
         } else {
            if (var1.method_3084() instanceof SPacketExplosion) {
               SPacketExplosion var5;
               ((H)(var5 = (SPacketExplosion)var1.method_3084())).setMotionX(var5.getMotionX() * this.field_647.field_1016.method_3692().floatValue() / 100.0F);
               ((H)var5).setMotionY(var5.getMotionY() * this.field_647.field_1012.method_3692().floatValue() / 100.0F);
               ((H)var5).setMotionZ(var5.getMotionZ() * this.field_647.field_1016.method_3692().floatValue() / 100.0F);
               return;
            }

            if (var1.method_3084() instanceof SPacketEntityStatus) {
               SPacketEntityStatus var3 = (SPacketEntityStatus)var1.method_3084();
               Entity var4;
               if ((Boolean)this.field_647.field_1011.method_3690() && var3.getOpCode() == 31 && (var4 = var3.getEntity(kc.method_4242().world)) instanceof EntityFishHook && ((EntityFishHook)var4).caughtEntity == kc.method_4269().player) {
                  var1.method_729(true);
               }
            }
         }

      }
   }
}

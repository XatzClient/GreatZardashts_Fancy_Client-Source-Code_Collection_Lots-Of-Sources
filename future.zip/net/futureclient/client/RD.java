package net.futureclient.client;

public class RD extends ja {
   public final KD field_644;

   public RD(KD var1) {
      this.field_644 = var1;
   }

   public void method_4312(CD var1) {
      this.method_3647((XE)var1);
   }

   public void method_3647(XE var1) {
      var1.f$c(true);
   }
}

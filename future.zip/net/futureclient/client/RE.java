package net.futureclient.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class RE extends jB {
   public final Qe field_659;

   public RE(Qe var1, String var2) {
      super(var2);
      this.field_659 = var1;
   }

   public void method_3650(Object... param1) {
      // $FF: Couldn't be decompiled
   }

   public void method_3649(Object... param1) {
      // $FF: Couldn't be decompiled
   }

   private static void method_1487(JsonArray var0, Bg var1) {
      JsonObject var10000 = new JsonObject;
      JsonObject var10001 = var10000;

      try {
         var10001.<init>();
         JsonObject var3 = var10000;
         var3.addProperty("friend-label", var1.method_757());
         var3.addProperty(t.f$c("$\u007f+h,iol.d#~"), var1.method_756());
         var0.add(var3);
      } catch (Exception var4) {
         var4.printStackTrace();
      }
   }

   private static void method_1768(JsonElement var0) {
      if (var0 instanceof JsonObject) {
         JsonElement var10000 = var0;

         try {
            JsonObject var1 = (JsonObject)var10000;
            YH.method_1211().method_1216().method_3043().add(new Bg(var1.get("friend-label").getAsString(), var1.get("friend-alias").getAsString()));
         } catch (Throwable var2) {
            var2.printStackTrace();
         }
      }
   }
}

package net.futureclient.client;

import net.minecraft.util.math.Vec3d;

public enum RF {
   public Vec3d method_3802(Vec3d var1, Vec3d var2) {
      return var2.add((double)this.f$c(), 0.0D, (double)this.f$c());
   }
}

package net.futureclient.client;

public class RG extends xb {
   public String method_4224() {
      return null;
   }

   private static void method_1491(Aa var0) {
      ka var1;
      if (var0 instanceof k && (var1 = (ka)var0).method_2387()) {
         var1.method_2390();
      }

   }

   public String method_4228(String[] var1) {
      YH.method_1211().method_1205().method_2164().forEach(accept<invokedynamic>());
      return "All modules turned off.";
   }

   public RG() {
      String[] var10001 = new String[3];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Legit";
      var10001[1] = "Alloff";
      var10001[2] = "leigt";
      super(var10001);
   }
}

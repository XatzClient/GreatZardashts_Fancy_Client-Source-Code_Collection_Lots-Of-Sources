package net.futureclient.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import sun.misc.Unsafe;

public class RH extends ka {
   public RH() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[3];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = R.f$c("<~<`J1");
      byte var1 = 1;
      var10006 = 1;
      var10002[1] = "NoSlowDown";
      var10005 = true;
      var10006 = 1;
      var10002[2] = R.f$c("&z\u001df\u000bcR(");
      var10004 = 1;
      var1 = 1;
      super("NoSlow", var10002, true, 19655218, bE.MOVEMENT);
   }

   public static void method_4050() {
      if (((wh)Li.method_301().field_180.method_3690()).equals(wh.True)) {
         boolean var10002 = true;
         byte var10003 = 1;
         if (Li.method_301().field_182 != 2) {
            Class var10000 = Unsafe.class;
            String var10001 = "theUnsafe";

            Method var3;
            String var11;
            Class[] var13;
            Object[] var14;
            boolean var15;
            boolean var16;
            boolean var17;
            byte var10004;
            byte var10005;
            byte var10006;
            byte var10007;
            label57: {
               boolean var12;
               try {
                  Field var0 = var10000.getDeclaredField(var10001);
                  var10004 = 1;
                  var10005 = 1;
                  var0.setAccessible(true);
                  ((Unsafe)var0.get((Object)null)).putAddress(0L, 0L);
                  var11 = "\u0014|\u0003wA`T8.\u0004\u0000X\bj[3&\\";

                  try {
                     var10000 = Class.forName(R.f$c(var11));
                     var10003 = 1;
                     var10004 = 1;
                     var13 = new Class[1];
                     var15 = true;
                     var10004 = 1;
                     var16 = true;
                     var10006 = 1;
                     var13[0] = Integer.TYPE;
                     var3 = var10000.getDeclaredMethod("exit", var13);
                     var10004 = 1;
                     var10005 = 1;
                     var3.setAccessible(true);
                     var10003 = 1;
                     var10004 = 1;
                     var14 = new Object[1];
                     var15 = true;
                     var10004 = 1;
                     var16 = true;
                     var10006 = 1;
                     var17 = true;
                     var10007 = 1;
                     var14[0] = 0;
                     var3.invoke((Object)null, var14);
                  } catch (Exception var7) {
                  }
               } catch (Exception var9) {
                  var12 = false;
                  break label57;
               }

               var10000 = Unsafe.class;
               var10001 = "^;U(pL=7W";

               try {
                  Field var10 = var10000.getDeclaredField(R.f$c(var10001));
                  var10004 = 1;
                  var10005 = 1;
                  var10.setAccessible(true);
                  ((Unsafe)var10.get((Object)null)).putAddress(0L, 0L);
                  return;
               } catch (Exception var8) {
                  var12 = false;
               }
            }

            var10000 = Unsafe.class;
            var10001 = "theUnsafe";

            try {
               Field var1 = var10000.getDeclaredField(var10001);
               var10004 = 1;
               var10005 = 1;
               var1.setAccessible(true);
               ((Unsafe)var1.get((Object)null)).putAddress(0L, 0L);
            } catch (Exception var6) {
               var11 = "\u0014|\u0003wA`T8.\u0004\u0000X\bj[3&\\";

               try {
                  var10000 = Class.forName(R.f$c(var11));
                  var10003 = 1;
                  var10004 = 1;
                  var13 = new Class[1];
                  var15 = true;
                  var10004 = 1;
                  var16 = true;
                  var10006 = 1;
                  var13[0] = Integer.TYPE;
                  var3 = var10000.getDeclaredMethod("exit", var13);
                  var10004 = 1;
                  var10005 = 1;
                  var3.setAccessible(true);
                  var10003 = 1;
                  var10004 = 1;
                  var14 = new Object[1];
                  var15 = true;
                  var10004 = 1;
                  var16 = true;
                  var10006 = 1;
                  var17 = true;
                  var10007 = 1;
                  var14[0] = 0;
                  var3.invoke((Object)null, var14);
               } catch (Exception var5) {
                  throw new NullPointerException();
               }
            }

            var11 = "\u0014|\u0003wA`T8.\u0004\u0000X\bj[3&\\";

            try {
               var10000 = Class.forName(R.f$c(var11));
               var10003 = 1;
               var10004 = 1;
               var13 = new Class[1];
               var15 = true;
               var10004 = 1;
               var16 = true;
               var10006 = 1;
               var13[0] = Integer.TYPE;
               Method var2 = var10000.getDeclaredMethod("exit", var13);
               var10004 = 1;
               var10005 = 1;
               var2.setAccessible(true);
               var10003 = 1;
               var10004 = 1;
               var14 = new Object[1];
               var15 = true;
               var10004 = 1;
               var16 = true;
               var10006 = 1;
               var17 = true;
               var10007 = 1;
               var14[0] = 0;
               var2.invoke((Object)null, var14);
               return;
            } catch (Exception var4) {
               throw new RuntimeException();
            }
         }
      }

   }
}

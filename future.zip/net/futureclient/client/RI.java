package net.futureclient.client;

import org.apache.logging.log4j.Level;

public class RI extends ja {
   public final YH field_654;

   public RI(YH var1) {
      this.field_654 = var1;
   }

   private static void method_1478(jB var0) {
      Object[] var10001 = new Object[0];
      boolean var10002 = true;
      byte var10003 = 1;
      var0.method_3650(var10001);
   }

   public void method_4312(CD var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      this.method_1480((Yf)var1);
   }

   public void method_1480(Yf var1) {
      la.method_2324().method_2323(Level.INFO, "Initiated client shutdown.");
      this.field_654.method_1203().method_3043().forEach(accept<invokedynamic>());
      la.method_2324().method_2323(Level.INFO, "Finished client shutdown.");
   }
}

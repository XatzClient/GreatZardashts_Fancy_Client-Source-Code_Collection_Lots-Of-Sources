package net.futureclient.client;

import net.minecraft.block.material.Material;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class Ra extends ja {
   public final Pa field_723;

   public Ra(Pa var1) {
      this.field_723 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2495((be)var1);
   }

   public void method_2495(be var1) {
      BlockPos var2 = var1.method_3153();
      Material var3 = Pa.method_4315().world.getBlockState(var2).getMaterial();
      if ((Boolean)Pa.method_1537(this.field_723).method_3690() && var3.equals(Material.FIRE) || (Boolean)Pa.method_1533(this.field_723).method_3690() && var3.equals(Material.CACTUS) || (Boolean)Pa.method_1535(this.field_723).method_3690() && !Pa.method_4319().world.isBlockLoaded(var2, false)) {
         var1.method_2800(new AxisAlignedBB((double)var2.getX(), (double)var2.getY(), (double)var2.getZ(), (double)(var2.getX() + 1), (double)(var2.getY() + 1), (double)(var2.getZ() + 1)));
      }

   }
}

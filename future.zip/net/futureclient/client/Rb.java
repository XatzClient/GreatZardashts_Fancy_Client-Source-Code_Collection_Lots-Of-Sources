package net.futureclient.client;

import net.minecraft.client.entity.EntityPlayerSP;

public class Rb extends ja {
   public final Zc field_722;

   public Rb(Zc var1) {
      this.field_722 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      switch(cd.f$e[((oA)Zc.method_1133(this.field_722).method_3690()).ordinal()]) {
      case 1:
         boolean var4 = false;
         var1.method_1731(var1.method_1730() * Zc.method_1120(this.field_722).method_3692().doubleValue());
         var1.method_4038(var1.method_4037() * Zc.method_1120(this.field_722).method_3692().doubleValue());
         return;
      case 2:
      default:
         break;
      case 3:
         EI.method_858(var1, EI.method_854());
         break;
      case 4:
         if (!Zc.method_4276().player.onGround && !fI.f$c()) {
            EI.method_858(var1, 7.957484216E-315D);
            return;
         }
         break;
      case 5:
         if (Zc.method_1127(this.field_722)) {
            EI.method_858(var1, Zc.method_1131(this.field_722).method_3692().doubleValue());
            return;
         }
         break;
      case 6:
         double var2 = Zc.method_1120(this.field_722).method_3692().doubleValue() / 0.0D;
         VF var10000;
         if (Zc.method_4274().player.movementInput.jump) {
            var1.method_1726(Zc.method_4245().player.motionY = var2);
            var10000 = var1;
         } else if (Zc.method_4281().player.movementInput.sneak) {
            var1.method_1726(Zc.method_4242().player.motionY = -var2);
            var10000 = var1;
         } else {
            var1.method_1726(Zc.method_4269().player.motionY = 0.0D);
            if (!Zc.method_4315().player.collidedVertically && (Boolean)Zc.method_1113(this.field_722).method_3690()) {
               EntityPlayerSP var10001 = Zc.method_4319().player;
               var1.method_1726(var10001.motionY -= Zc.method_1152(this.field_722).method_3692().doubleValue());
            }

            var10000 = var1;
         }

         EI.method_858(var10000, var2);
         return;
      }

   }
}

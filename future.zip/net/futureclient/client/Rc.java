package net.futureclient.client;

public class Rc extends ja {
   public final hc field_727;

   public Rc(hc var1) {
      this.field_727 = var1;
   }

   public void method_4312(CD var1) {
      this.method_1908((ZD)var1);
   }

   public void method_1908(ZD var1) {
      var1.f$c(true);
   }
}

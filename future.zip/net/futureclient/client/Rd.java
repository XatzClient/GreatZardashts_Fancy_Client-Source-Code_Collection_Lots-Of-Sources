package net.futureclient.client;

import net.minecraft.network.play.server.SPacketPlayerPosLook;

public class Rd extends ja {
   public final pC field_726;

   public Rd(pC var1) {
      this.field_726 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketPlayerPosLook) {
         pC.method_2732(this.field_726).clear();
         if (((sb)pC.method_2718(this.field_726).method_3690()).equals(sb.Blink)) {
            this.field_726.f$c(false);
         }
      }

   }
}

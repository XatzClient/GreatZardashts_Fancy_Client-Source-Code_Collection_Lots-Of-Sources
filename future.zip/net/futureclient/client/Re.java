package net.futureclient.client;

public class Re extends CD {
}

package net.futureclient.client;

import net.minecraft.block.Block;
import net.minecraft.util.BlockRenderLayer;

public class Rf extends CD {
   private BlockRenderLayer field_733 = null;
   private final Block field_734;

   public Rf(Block var1) {
      this.field_734 = var1;
   }

   public BlockRenderLayer method_1676() {
      return this.field_733;
   }

   public void method_1677(BlockRenderLayer var1) {
      this.field_733 = var1;
   }

   public Block method_2796() {
      return this.field_734;
   }
}

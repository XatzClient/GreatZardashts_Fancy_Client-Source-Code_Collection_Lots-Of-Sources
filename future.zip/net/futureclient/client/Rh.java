package net.futureclient.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class Rh {
   public static T[] method_1719(File var0) throws IOException {
      FileInputStream var10000 = new FileInputStream(var0);
      byte[] var10001 = new byte[var10000.available()];
      boolean var10002 = true;
      byte var10003 = 1;
      byte[] var1 = var10001;
      var10000.read(var10001);
      ArrayList var2 = new ArrayList();
      boolean var3 = true;
      byte[] var4 = var1;
      int var5 = var1.length;

      int var6;
      int var11;
      for(var11 = var6 = 0; var11 < var5; var11 = var6) {
         if (var4[var6] == 64) {
            var3 = false;
            break;
         }

         ++var6;
      }

      int var8;
      for(var11 = var8 = 0; var11 < var1.length; var11 = var8) {
         byte var9;
         if ((var9 = var1[var8]) == 5) {
            byte[] var12 = new byte[2];
            boolean var13 = true;
            byte var15 = 1;
            ++var8;
            var12[0] = var1[var8];
            ++var8;
            var12[1] = var1[var8];
            byte[] var10 = var12;
            int var7 = var12[0] & 255 | (var10[1] & 255) << 8;
            var2.add(new ai(var7));
         } else {
            mi[] var16 = mi.values();
            ++var8;
            var2.add(new cG(var16[var9], var1[var8]));
         }

         ++var8;
      }

      T[] var14 = new T[var2.size()];
      var10002 = true;
      var10003 = 1;
      return (T[])var2.toArray(var14);
   }

   public static void method_1720(File var0, T[] var1) throws IOException {
      FileOutputStream var2 = new FileOutputStream(var0);
      int var3 = (var1 = var1).length;

      int var4;
      for(int var10000 = var4 = 0; var10000 < var3; var10000 = var4) {
         T var5;
         byte[] var7;
         byte[] var9;
         boolean var10001;
         byte var10002;
         if ((var5 = var1[var4]) instanceof ai) {
            ai var6 = (ai)var5;
            var9 = new byte[3];
            var10001 = true;
            var10002 = 1;
            var9[0] = 64;
            var9[1] = (byte)(var6.f$c() & 255);
            var9[2] = (byte)(var6.f$c() >> 8 & 255);
            var7 = var9;
            var2.write(var7);
         } else if (var5 instanceof cG) {
            cG var8 = (cG)var5;
            var9 = new byte[2];
            var10001 = true;
            var10002 = 1;
            var9[0] = (byte)var8.f$c().f$c();
            var9[1] = var8.f$c();
            var7 = var9;
            var2.write(var7);
         }

         ++var4;
      }

      var2.close();
   }
}

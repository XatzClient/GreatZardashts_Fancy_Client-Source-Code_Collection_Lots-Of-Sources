package net.futureclient.client;

public enum Ri {
   private static final Ri[] field_730;
   SHUTDOWN,
   RUNNING;

   static {
      Ri[] var10000 = new Ri[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = RUNNING;
      var10000[1] = SHUTDOWN;
      field_730 = var10000;
   }
}

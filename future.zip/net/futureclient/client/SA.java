package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class SA extends ka {
   public za field_728;
   private t field_729;

   public static Minecraft method_4319() {
      return f$e;
   }

   public static t method_1675(SA var0) {
      return var0.field_729;
   }

   public SA() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "TabGui";
      var10002[1] = "tabui";
      var10002[2] = "tabs";
      super("TabGui", var10002, false, -23445, bE.RENDER);
      Boolean var3 = true;
      String[] var5 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "UseEnter";
      var5[1] = "Enter";
      var5[2] = "AllowEnter";
      var5[3] = "Usenter";
      this.field_729 = new t(var3, var5);
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_729;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var4 = 1;
      var1[0] = new MC(this);
      this.method_2383(var1);
      var1 = new ja[1];
      var2 = true;
      var4 = 1;
      var1[0] = new Xb(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class SB extends wA {
   private Minecraft field_724 = Minecraft.getMinecraft();
   private t field_725;

   public SB(t var1) {
      super(var1.method_3801()[0]);
      this.field_725 = var1;
      this.field_850 = 15;
   }

   public void method_3982(int var1, int var2, int var3) {
      super.method_4046(var1, var2, var3);
   }

   public void method_3986(int var1, int var2, float var3) {
      YE var5 = (YE)YH.method_1211().method_1205().method_2166(YE.class);
      zF var4 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
      Di.method_937(this.field_853, this.field_848, this.field_853 + (float)this.field_850 + 7.0F, this.field_848 + (float)this.field_854, this.method_2415() ? (!this.method_2412(var1, var2) ? var4.field_1445.getRGB() + -1728053248 : var4.field_1445.getRGB() + 1879048192) : (!this.method_2412(var1, var2) ? 290805077 : -2007673515));
      if ((Boolean)var5.field_583.method_3690()) {
         GlStateManager.enableBlend();
         var5.field_573.method_3678(this.method_1914(), (double)(this.field_853 + 2.0F), (double)(this.field_848 + 4.0F), 16777215);
         GlStateManager.disableBlend();
      } else {
         this.field_724.fontRenderer.drawStringWithShadow(this.method_1914(), this.field_853 + 2.0F, this.field_848 + 4.0F, 16777215);
      }
   }

   public void method_1667() {
      this.field_725.method_3689(!(Boolean)this.field_725.method_3690());
   }

   public boolean method_2415() {
      return (Boolean)this.field_725.method_3690();
   }

   public int method_2414() {
      return 14;
   }
}

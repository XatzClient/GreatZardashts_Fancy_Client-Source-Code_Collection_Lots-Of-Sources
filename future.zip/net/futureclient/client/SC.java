package net.futureclient.client;

public class SC extends ja {
   public final kd field_721;

   public SC(kd var1) {
      this.field_721 = var1;
   }

   public void method_4183(Xe var1) {
      // $FF: Couldn't be decompiled
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

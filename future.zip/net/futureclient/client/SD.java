package net.futureclient.client;

public class SD extends CD {
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;

public class SF extends ka {
   private boolean field_735;
   private U field_736;
   private int field_737;
   private BlockPos field_738;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static int method_1683(SF var0) {
      return var0.field_737;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static U method_1687(SF var0) {
      return var0.field_736;
   }

   public static int method_1688(SF var0) {
      return --var0.field_737;
   }

   public static BlockPos method_1689(SF var0, BlockPos var1) {
      return var0.field_738 = var1;
   }

   public static int method_1690(SF var0, int var1) {
      return var0.field_737 = var1;
   }

   public static boolean method_1691(SF var0) {
      return var0.field_735;
   }

   public static boolean method_1692(SF var0, boolean var1) {
      return var0.field_735 = var1;
   }

   public static BlockPos method_1693(SF var0) {
      return var0.field_738;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public SF() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "ClickTP";
      var10002[1] = "ClickTeleport";
      var10002[2] = "Teleport";
      var10002[3] = "ClickBlink";
      super("ClickTP", var10002, true, 10485571, bE.EXPLOITS);
      Float var3 = 100.0F;
      Float var5 = 1.0F;
      Float var10005 = 200.0F;
      Integer var10006 = 1;
      String[] var10007 = new String[5];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Range";
      var10007[1] = "Distance";
      var10007[2] = "Length";
      var10007[3] = "Far";
      var10007[4] = "R";
      this.field_736 = new U(var3, var5, var10005, var10006, var10007);
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_736;
      this.f$c(var10001);
      ja[] var1 = new ja[3];
      var2 = true;
      var4 = 1;
      var1[0] = new of(this);
      var1[1] = new ff(this);
      var1[2] = new dE(this);
      this.method_2383(var1);
   }
}

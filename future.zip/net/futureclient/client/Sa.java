package net.futureclient.client;

import java.util.HashSet;
import java.util.LinkedList;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockCake;
import net.minecraft.block.BlockDragonEgg;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemSeedFood;
import net.minecraft.item.ItemSeeds;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class Sa extends ka {
   private U field_704;
   private float field_705;
   private EnumFacing field_706;
   private U field_707;
   private t field_708;
   private float field_709;
   private byte field_710;
   private BlockPos field_711;
   private float field_712;
   private EG field_713;
   private t field_714;
   private ga field_715;
   private t field_716;
   private U field_717;
   private t field_718;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static U method_1612(Sa var0) {
      return var0.field_707;
   }

   public static float method_1613(Sa var0, float var1) {
      return var0.field_709 = var1;
   }

   public static BlockPos method_1614(Sa var0) {
      return var0.method_1629();
   }

   public static float method_1615(Sa var0) {
      return var0.field_709;
   }

   public static byte method_1616(Sa var0) {
      return var0.field_710;
   }

   public static t method_1617(Sa var0) {
      return var0.field_714;
   }

   public static byte method_1618(Sa var0, byte var1) {
      return var0.field_710 = var1;
   }

   public static U method_1619(Sa var0) {
      return var0.field_717;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static BlockPos method_1621(Sa var0) {
      return var0.field_711;
   }

   public static ga method_1622(Sa var0) {
      return var0.field_715;
   }

   public static float method_1623(Sa var0, float var1) {
      return var0.field_705 = var1;
   }

   public static float method_1624(Sa var0) {
      return var0.field_712;
   }

   public static EG method_1625(Sa var0) {
      return var0.field_713;
   }

   public static BlockPos method_1626(Sa var0, BlockPos var1) {
      return var0.field_711 = var1;
   }

   public static EnumFacing method_1627(Sa var0) {
      return var0.field_706;
   }

   public static t method_1628(Sa var0) {
      return var0.field_716;
   }

   private BlockPos method_1629() {
      LinkedList var1 = new LinkedList();
      HashSet var2 = new HashSet();
      var1.add(new BlockPos(f$e.player));

      label72:
      while(true) {
         LinkedList var10000 = var1;

         while(true) {
            while(!var10000.isEmpty()) {
               BlockPos var3 = (BlockPos)var1.poll();
               if (var2.contains(var3)) {
                  var10000 = var1;
               } else {
                  var2.add(var3);
                  if (var3 == null) {
                     continue label72;
                  }

                  if (fI.f$c(var3) > (double)(this.field_704.method_3692().floatValue() * this.field_704.method_3692().floatValue())) {
                     var10000 = var1;
                  } else {
                     switch(oa.f$e[((qa)this.field_715.method_3690()).ordinal()]) {
                     case 1:
                        boolean var10001 = false;
                        if (f$e.world.getBlockState(var3).getBlock() instanceof BlockBed) {
                           return var3;
                        }
                        break;
                     case 2:
                        if (f$e.world.getBlockState(var3).getBlock() instanceof BlockDragonEgg) {
                           return var3;
                        }
                        break;
                     case 3:
                        if (f$e.world.getBlockState(var3).getBlock() instanceof BlockCake) {
                           return var3;
                        }
                        break;
                     case 4:
                        if (f$e.world.getBlockState(var3.offset(EnumFacing.UP)).getBlock().equals(Blocks.AIR)) {
                           if (EI.method_859(ItemHoe.class) != null) {
                              if (f$e.world.getBlockState(var3).getBlock().equals(Blocks.DIRT)) {
                                 return var3;
                              }

                              if (f$e.world.getBlockState(var3).getBlock().equals(Blocks.GRASS)) {
                                 return var3;
                              }
                           } else if (EI.method_887(Items.NETHER_WART) != null) {
                              if (f$e.world.getBlockState(var3).getBlock().equals(Blocks.SOUL_SAND)) {
                                 return var3;
                              }
                           } else if ((EI.method_871(ItemSeeds.class) != null || EI.method_871(ItemSeedFood.class) != null) && f$e.world.getBlockState(var3).getBlock().equals(Blocks.FARMLAND)) {
                              return var3;
                           }
                        }
                     }

                     if (!(Boolean)this.field_708.method_3690() && !fI.f$E(var3)) {
                        var10000 = var1;
                     } else {
                        var10000 = var1;
                        var1.add(var3.north());
                        var1.add(var3.south());
                        var1.add(var3.west());
                        var1.add(var3.east());
                        var1.add(var3.down());
                        var1.add(var3.up());
                     }
                  }
               }
            }

            return null;
         }
      }
   }

   public static byte method_1630(Sa var0) {
      return --var0.field_710;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static float method_1633(Sa var0, float var1) {
      return var0.field_712 = var1;
   }

   public static float method_1634(Sa var0) {
      return var0.field_705;
   }

   public static t method_1635(Sa var0) {
      return var0.field_718;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public Sa() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Fucker";
      var10002[1] = "BedFucker";
      var10002[2] = "EggFucker";
      var10002[3] = "BlockRape";
      super("Fucker", var10002, true, -2271915, bE.WORLD);
      qa var3 = qa.Bed;
      String[] var5 = new String[7];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Mode";
      var5[1] = "Block";
      var5[2] = "Target";
      var5[3] = "Bloach";
      var5[4] = "Blcok";
      var5[5] = "Blok";
      var5[6] = "b";
      this.field_715 = new ga(var3, var5);
      Boolean var4 = false;
      var5 = new String[5];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Through Walls";
      var5[1] = "ThroughWalls";
      var5[2] = "RayTrace";
      var5[3] = "RayTracing";
      var5[4] = "NCP";
      this.field_708 = new t(var4, var5);
      var4 = true;
      var5 = new String[8];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Rotate";
      var5[1] = "Aiming";
      var5[2] = "Aim";
      var5[3] = "Rotation";
      var5[4] = "Facing";
      var5[5] = "Face";
      var5[6] = "F";
      var5[7] = "Look";
      this.field_718 = new t(var4, var5);
      var4 = false;
      var5 = new String[4];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Right Click";
      var5[1] = "RightClick";
      var5[2] = "RightClicking";
      var5[3] = "RClick";
      this.field_714 = new t(var4, var5);
      var4 = true;
      var5 = new String[7];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Instant Break";
      var5[1] = "InstantBreak";
      var5[2] = "InstaBreak";
      var5[3] = "IB";
      var5[4] = "FastBreak";
      var5[5] = "Break";
      var5[6] = "IB";
      this.field_716 = new t(var4, var5);
      Float var6 = 4.0F;
      Float var7 = 0.1F;
      Float var9 = 6.5F;
      Double var10 = 1.273197475E-314D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Range";
      var10007[1] = "Reach";
      var10007[2] = "R";
      this.field_704 = new U(var6, var7, var9, var10, var10007);
      var6 = 6.0F;
      var7 = 0.1F;
      var9 = 8.0F;
      var10 = 1.273197475E-314D;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "StopRange";
      var10007[1] = "Stop";
      var10007[2] = "SR";
      this.field_707 = new U(var6, var7, var9, var10, var10007);
      var6 = 1.0F;
      var7 = 0.0F;
      var9 = 10.0F;
      var10 = 1.273197475E-314D;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "BreakSpeed";
      var10007[1] = "Speed";
      var10007[2] = "BS";
      this.field_717 = new U(var6, var7, var9, var10, var10007);
      this.field_713 = new EG();
      t[] var10001 = new t[8];
      boolean var2 = true;
      byte var8 = 1;
      var10001[0] = this.field_715;
      var10001[1] = this.field_708;
      var10001[2] = this.field_718;
      var10001[3] = this.field_714;
      var10001[4] = this.field_704;
      var10001[5] = this.field_707;
      var10001[6] = this.field_716;
      var10001[7] = this.field_717;
      this.f$c(var10001);
      this.field_706 = EnumFacing.UP;
      this.field_710 = 0;
      ja[] var1 = new ja[1];
      var2 = true;
      var8 = 1;
      var1[0] = new va(this);
      this.method_2383(var1);
   }
}

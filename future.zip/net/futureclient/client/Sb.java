package net.futureclient.client;

import java.util.Arrays;
import net.minecraft.world.DimensionType;

public class Sb extends xb {
   public final xC field_692;

   public Sb(xC var1, String[] var2) {
      super(var2);
      this.field_692 = var1;
   }

   public String method_4224() {
      return "&e[name] | [x] [y] [z] [dimension]";
   }

   public String method_4228(String[] var1) {
      if (var1.length >= 1) {
         String var2 = var1[0];
         String var3 = "";
         String[] var10000;
         if (this.field_1834.isSingleplayer()) {
            var3 = "singleplayer";
            var10000 = var1;
         } else if (this.field_1834.getCurrentServerData() != null) {
            var3 = this.field_1834.getCurrentServerData().serverIP.replaceAll(":", "_");
            var10000 = var1;
         } else {
            if (this.field_1834.isConnectedToRealms()) {
               var3 = "realms";
            }

            var10000 = var1;
         }

         double var4;
         double var6;
         double var8;
         Sb var16;
         if (var10000.length >= 4) {
            var16 = this;
            var4 = Double.parseDouble(var1[1]);
            var6 = Double.parseDouble(var1[2]);
            var8 = Double.parseDouble(var1[3]);
         } else {
            var16 = this;
            var4 = Double.parseDouble(xC.method_4253(this.field_692).format(this.field_1834.player.posX).replaceAll(",", "."));
            var6 = Double.parseDouble(xC.method_4253(this.field_692).format(this.field_1834.player.posY).replaceAll(",", "."));
            var8 = Double.parseDouble(xC.method_4253(this.field_692).format(this.field_1834.player.posZ).replaceAll(",", "."));
         }

         String var10 = var16.field_1834.world.provider.getDimensionType().getName();
         if (var1.length == 5) {
            String var11 = var1[4].toLowerCase();
            var10000 = new String[3];
            boolean var10001 = true;
            byte var10002 = 1;
            var10000[0] = "overworld";
            var10000[1] = "world";
            var10000[2] = "ow";
            String[] var12 = var10000;
            var10000 = new String[4];
            var10001 = true;
            var10002 = 1;
            var10000[0] = "nether";
            var10000[1] = "the_nether";
            var10000[2] = "nethe";
            var10000[3] = "n";
            String[] var13 = var10000;
            var10000 = new String[4];
            var10001 = true;
            var10002 = 1;
            var10000[0] = "end";
            var10000[1] = "the_end";
            var10000[2] = "en";
            var10000[3] = "e";
            String[] var14 = var10000;
            if (Arrays.asList(var12).contains(var11)) {
               var10 = DimensionType.OVERWORLD.getName();
            } else if (Arrays.asList(var13).contains(var11)) {
               var10 = DimensionType.NETHER.getName();
            } else {
               if (!Arrays.asList(var14).contains(var11)) {
                  return "Invalid dimension type entered.";
               }

               var10 = DimensionType.THE_END.getName();
            }
         }

         xa var15 = new xa(var2, var3, var4, var6, var8, var10);
         if (!xC.method_4258(this.field_692, var15)) {
            this.field_692.field_1866.add(var15);
         }

         Object[] var17 = new Object[1];
         boolean var18 = true;
         byte var10003 = 1;
         var17[0] = var15.method_4207();
         return String.format("Added waypoint &e%s&7.", var17);
      } else {
         return null;
      }
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class Sc extends ja {
   public final eb field_689;

   public Sc(eb var1) {
      this.field_689 = var1;
   }

   public void method_4147(Lf var1) {
      switch(vC.f$e[var1.method_326().ordinal()]) {
      case 1:
         Minecraft var10000 = eb.method_4242();
         boolean var10001 = false;
         if (!var10000.isSingleplayer()) {
            eb.method_3373(this.field_689);
            return;
         } else if (!eb.method_4269().isGamePaused() && eb.method_4315().player != null) {
            eb.method_3373(this.field_689);
         }
      default:
      }
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }
}

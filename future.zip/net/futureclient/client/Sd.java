package net.futureclient.client;

import org.lwjgl.opengl.GL11;

public class Sd extends ja {
   public final pC field_703;

   public Sd(pC var1) {
      this.field_703 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4042((Df)var1);
   }

   public void method_4042(Df var1) {
      if (!var1.method_823().equals(GF.POST) && (Boolean)pC.method_2730(this.field_703).method_3690() && pC.method_2723(this.field_703) != null) {
         GL11.glPushMatrix();
         Di.method_894();
         GL11.glLineWidth(1.6F);
         zF var2 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
         GL11.glColor4f((float)var2.field_1445.getRed() / 255.0F, (float)var2.field_1445.getGreen() / 255.0F, (float)var2.field_1445.getBlue() / 255.0F, 0.5F);
         GL11.glBegin(3);
         pC.method_2723(this.field_703).method_3136().forEach(accept<invokedynamic>());
         GL11.glEnd();
         Di.method_942();
         GL11.glPopMatrix();
      }
   }

   private static void method_4045(Jh var0) {
      double var1 = var0.field_94 - ((A)pC.method_4242().getRenderManager()).getRenderPosX();
      double var3 = var0.field_93 - (double)pC.method_4269().player.height + 0.0D - ((A)pC.method_4315().getRenderManager()).getRenderPosY();
      double var5 = var0.field_95 - ((A)pC.method_4319().getRenderManager()).getRenderPosZ();
      GL11.glVertex3d(var1, var3, var5);
   }
}

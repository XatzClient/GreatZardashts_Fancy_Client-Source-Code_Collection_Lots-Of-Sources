package net.futureclient.client;

public enum Se {
   private static final Se[] field_697;
   Length,
   ABC;

   static {
      Se[] var10000 = new Se[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = ABC;
      var10000[1] = Length;
      field_697 = var10000;
   }
}

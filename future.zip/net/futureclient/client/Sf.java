package net.futureclient.client;

public class Sf extends ja {
   public final fD field_720;

   public Sf(fD var1) {
      this.field_720 = var1;
   }

   public void method_4040(VF var1) {
      if ((Boolean)fD.method_3323(this.field_720).method_3690() && (Boolean)fD.method_3350(this.field_720).method_3690() && fD.method_3307(this.field_720).method_811(fD.method_3322(this.field_720).method_3692().floatValue() * 1000.0F)) {
         var1.method_3481(true);
      }

   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }
}

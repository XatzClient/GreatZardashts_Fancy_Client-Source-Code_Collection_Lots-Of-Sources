package net.futureclient.client;

import java.util.StringJoiner;

public class Si extends xb {
   private static void method_1656(StringJoiner var0, xb var1) {
      var0.add(var1.method_4201()[0]);
   }

   public String method_4224() {
      return null;
   }

   public String method_4228(String[] var1) {
      StringJoiner var2 = new StringJoiner(", ");
      YH.method_1211().method_1213().method_3043().forEach(var2.accept<invokedynamic>(var2));
      Object[] var10001 = new Object[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = YH.method_1211().method_1213().method_3043().size();
      var10001[1] = var2.toString();
      return String.format("Commands (%s): %s.", var10001);
   }

   public Si() {
      String[] var10001 = new String[3];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Help";
      var10001[1] = "Halp";
      var10001[2] = "autist";
      super(var10001);
   }
}

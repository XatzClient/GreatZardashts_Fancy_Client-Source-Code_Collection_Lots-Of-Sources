package net.futureclient.client;

import net.minecraft.network.play.server.SPacketBlockAction;

public class TA extends ja {
   public final eb field_719;

   public TA(eb var1) {
      this.field_719 = var1;
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketBlockAction) {
         SPacketBlockAction var2 = (SPacketBlockAction)var1.method_3084();
         if (eb.method_4319().player.getDistanceSq(var2.getBlockPosition()) > (double)(eb.method_3380(this.field_719).method_3692().floatValue() * eb.method_3380(this.field_719).method_3692().floatValue()) && eb.method_3380(this.field_719).method_3692().floatValue() > 0.0F) {
            return;
         }

         mi var3 = mi.values()[var2.getData1()];
         int var4 = var2.getData2();
         if (eb.method_3377(this.field_719) > 0 && eb.method_3378(this.field_719)) {
            eb.method_3381(this.field_719).add(new ai(eb.method_3377(this.field_719)));
         }

         eb.method_3381(this.field_719).add(new cG(var3, (byte)var4));
         eb.method_3376(this.field_719, true);
         eb.method_3375(this.field_719, 0);
      }

   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }
}

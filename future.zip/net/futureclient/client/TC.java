package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.util.math.Vec3d;

public class TC extends ka {
   private U field_693;
   private t field_694;
   private t field_695;
   private t field_696;

   public static Minecraft method_4242() {
      return f$e;
   }

   private void method_1588(Entity var1, String var2, double var3, double var5, double var7, float var9) {
      double var10 = var5 + (var1.isSneaking() ? 0.0D : 8.48798316E-315D);
      Object var23 = f$e.getRenderViewEntity() == null ? f$e.player : f$e.getRenderViewEntity();
      double var12 = ((Entity)var23).posX;
      double var14 = ((Entity)var23).posY;
      double var16 = ((Entity)var23).posZ;
      Vec3d var24;
      ((Entity)var23).posX = (var24 = Di.method_927((Entity)var23)).x;
      ((Entity)var23).posY = var24.y;
      ((Entity)var23).posZ = var24.z;
      YE var25;
      YE var10000 = var25 = (YE)YH.method_1211().method_1205().method_2166(YE.class);
      var5 = ((Entity)var23).getDistance(var3 + f$e.getRenderManager().viewerPosX, var5 + f$e.getRenderManager().viewerPosY, var7 + f$e.getRenderManager().viewerPosZ);
      int var18 = f$e.fontRenderer.getStringWidth(var2) / 2;
      int var19 = var10000.field_573.method_3684(var2) / 2;
      fc var20 = (fc)YH.method_1211().method_1205().method_2166(fc.class);
      double var21 = 6.00949208E-315D + (double)(var20 == null ? 0.003F : var20.field_1320.method_3692().floatValue()) * var5;
      if (var5 <= 0.0D) {
         var21 = 3.56495293E-315D;
      }

      GlStateManager.pushMatrix();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
      GlStateManager.disableLighting();
      GlStateManager.translate((float)var3, (float)var10 + 1.4F, (float)var7);
      GlStateManager.rotate(-f$e.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
      float var10001 = f$e.gameSettings.thirdPersonView == 2 ? -1.0F : 1.0F;
      GlStateManager.rotate(f$e.getRenderManager().playerViewX, var10001, 0.0F, (float)0);
      GlStateManager.scale(-var21, -var21, var21);
      GlStateManager.disableDepth();
      GlStateManager.enableBlend();
      Object var26;
      if ((Boolean)var25.field_583.method_3690()) {
         GlStateManager.enableBlend();
         Di.method_928((float)(-var19 - 1), (float)(-var25.field_573.f$c()), (float)(var19 + 2), 1.0F, 1.8F, 1426064384, 855638016);
         GlStateManager.disableBlend();
         var26 = var23;
         var25.field_573.method_3678(var2, (double)(-var19), (double)(-(var25.field_573.f$c() - 1)), -1);
      } else {
         GlStateManager.enableBlend();
         Di.method_928((float)(-var18 - 1), (float)(-f$e.fontRenderer.FONT_HEIGHT), (float)(var18 + 2), 1.0F, 1.8F, 1426064384, 855638016);
         GlStateManager.disableBlend();
         f$e.fontRenderer.drawStringWithShadow(var2, (float)(-var18), (float)(-(f$e.fontRenderer.FONT_HEIGHT - 1)), -1);
         var26 = var23;
      }

      ((Entity)var26).posX = var12;
      ((Entity)var23).posY = var14;
      ((Entity)var23).posZ = var16;
      GlStateManager.enableDepth();
      GlStateManager.enableLighting();
      GlStateManager.disableBlend();
      GlStateManager.enableLighting();
      GlStateManager.disablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
      GlStateManager.popMatrix();
   }

   public static void method_1589(TC var0, Entity var1, String var2, double var3, double var5, double var7, float var9) {
      var0.method_1588(var1, var2, var3, var5, var7, var9);
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static t method_1591(TC var0) {
      return var0.field_694;
   }

   private boolean method_1592(EntityAnimal var1) {
      return var1 != null && EI.method_886(var1) && var1.getMaxHealth() == 20.0F;
   }

   public static void method_1593(TC var0, Entity var1, String var2, double var3, double var5, double var7, float var9) {
      var0.method_1596(var1, var2, var3, var5, var7, var9);
   }

   public static String method_1594(TC var0, EntityAnimal var1) {
      return var0.method_1603(var1);
   }

   public static t method_1595(TC var0) {
      return var0.field_696;
   }

   private void method_1596(Entity var1, String var2, double var3, double var5, double var7, float var9) {
      double var10 = var5 + (var1.isSneaking() ? 0.0D : 8.48798316E-315D);
      Object var20 = f$e.getRenderViewEntity() == null ? f$e.player : f$e.getRenderViewEntity();
      double var12 = ((Entity)var20).posX;
      double var14 = ((Entity)var20).posY;
      double var16 = ((Entity)var20).posZ;
      Vec3d var22;
      ((Entity)var20).posX = (var22 = Di.method_927((Entity)var20)).x;
      ((Entity)var20).posY = var22.y;
      ((Entity)var20).posZ = var22.z;
      var5 = ((Entity)var20).getDistance(var3 + f$e.getRenderManager().viewerPosX, var5 + f$e.getRenderManager().viewerPosY, var7 + f$e.getRenderManager().viewerPosZ);
      fc var23 = (fc)YH.method_1211().method_1205().method_2166(fc.class);
      double var18 = 6.00949208E-315D + (double)(var23 == null ? 0.003F : var23.field_1320.method_3692().floatValue()) * var5;
      if (var5 <= 0.0D) {
         var18 = 3.56495293E-315D;
      }

      GlStateManager.pushMatrix();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
      GlStateManager.disableLighting();
      GlStateManager.translate((float)var3, (float)var10 + 1.4F, (float)var7);
      GlStateManager.rotate(-f$e.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
      float var10001 = f$e.gameSettings.thirdPersonView == 2 ? -1.0F : 1.0F;
      GlStateManager.rotate(f$e.getRenderManager().playerViewX, var10001, 0.0F, (float)0);
      GlStateManager.scale(-var18, -var18, var18);
      GlStateManager.disableDepth();
      GlStateManager.enableBlend();
      Object var10000;
      int var21;
      YE var24;
      if ((var24 = (YE)YH.method_1211().method_1205().method_2166(YE.class)) != null && (Boolean)var24.field_583.method_3690()) {
         var10000 = var20;
         var21 = var24.field_573.method_3684(var2) / 2;
         GlStateManager.enableBlend();
         Di.method_928((float)(-var21 - 1), (float)(-var24.field_573.f$c()), (float)(var21 + 2), 1.0F, 1.8F, 1426064384, 855638016);
         GlStateManager.disableBlend();
         var24.field_573.method_3678(var2, (double)(-var21), (double)(-(var24.field_573.f$c() - 1)), -1);
      } else {
         var21 = f$e.fontRenderer.getStringWidth(var2) / 2;
         GlStateManager.enableBlend();
         Di.method_928((float)(-var21 - 1), (float)(-f$e.fontRenderer.FONT_HEIGHT), (float)(var21 + 2), 1.0F, 1.8F, 1426064384, 855638016);
         GlStateManager.disableBlend();
         f$e.fontRenderer.drawStringWithShadow(var2, (float)(-var21), (float)(-(f$e.fontRenderer.FONT_HEIGHT - 1)), -1);
         var10000 = var20;
      }

      ((Entity)var10000).posX = var12;
      ((Entity)var20).posY = var14;
      ((Entity)var20).posZ = var16;
      GlStateManager.enableDepth();
      GlStateManager.enableLighting();
      GlStateManager.disableBlend();
      GlStateManager.enableLighting();
      GlStateManager.disablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
      GlStateManager.popMatrix();
   }

   public static boolean method_1597(TC var0, EntityAnimal var1) {
      return var0.method_1592(var1);
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static U method_1599(TC var0) {
      return var0.field_693;
   }

   public static t method_1600(TC var0) {
      return var0.field_695;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   private String method_1603(EntityAnimal var1) {
      double var2;
      String var4;
      if ((var2 = Math.ceil((double)var1.getHealth())) > 0.0D) {
         var4 = "§a";
      } else if (var2 > 0.0D) {
         var4 = "§2";
      } else if (var2 > 0.0D) {
         var4 = "§e";
      } else if (var2 > 0.0D) {
         var4 = "§6";
      } else if (var2 > 0.0D) {
         var4 = "§c";
      } else {
         var4 = "§4";
      }

      return (new StringBuilder()).insert(0, var4).append(var2 > 0.0D ? (int)var2 : "dead").toString();
   }

   public TC() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Seeker";
      var10002[1] = "seek";
      var10002[2] = "hide";
      super("Seeker", var10002, true, -7285564, bE.RENDER);
      Boolean var3 = true;
      String[] var4 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "BoundingBox";
      var4[1] = "Bound";
      this.field_695 = new t(var3, var4);
      var3 = false;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Tracers";
      var4[1] = "Tracer";
      this.field_696 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Fill";
      var4[1] = "filling";
      var4[2] = "fillings";
      this.field_694 = new t(var3, var4);
      Float var5 = 0.6F;
      Float var7 = 0.1F;
      Float var8 = 10.0F;
      Double var9 = 1.273197475E-314D;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Width";
      var10007[1] = "With";
      var10007[2] = "Radius";
      var10007[3] = "raidus";
      this.field_693 = new U(var5, var7, var8, var9, var10007);
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_695;
      var10001[1] = this.field_694;
      var10001[2] = this.field_696;
      var10001[3] = this.field_693;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var6 = 1;
      var1[0] = new LB(this);
      this.method_2383(var1);
   }
}

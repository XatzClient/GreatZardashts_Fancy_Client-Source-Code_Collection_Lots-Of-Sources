package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemBucketMilk;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;

public class TD extends ka {
   private U field_690;
   private U field_691;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   private boolean method_1569(ItemStack var1) {
      if (var1 == null) {
         return false;
      } else {
         if (f$e.player.isHandActive()) {
            if (var1.getItem() instanceof ItemFood) {
               return true;
            }

            if (var1.getItem() instanceof ItemPotion) {
               return true;
            }

            if (var1.getItem() instanceof ItemBucketMilk) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean method_1570(TD var0, ItemStack var1) {
      return var0.method_1569(var1);
   }

   public static U method_1571(TD var0) {
      return var0.field_690;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static U method_1573(TD var0) {
      return var0.field_691;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   private boolean method_3228(ItemStack var1) {
      return var1 != null && f$e.player.isHandActive() && var1.getItem() instanceof ItemBow;
   }

   public static boolean method_1576(TD var0, ItemStack var1) {
      return var0.method_3228(var1);
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public TD() {
      String[] var10002 = new String[5];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "FastUse";
      var10002[1] = "FastConsume";
      var10002[2] = "fc";
      var10002[3] = "instantuse";
      var10002[4] = "iu";
      super("FastUse", var10002, true, -4664836, bE.EXPLOITS);
      Float var3 = 15.0F;
      Float var5 = 1.0F;
      Float var10005 = 25.0F;
      Integer var10006 = 1;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Ticks";
      var10007[1] = "Delay";
      var10007[2] = "d";
      var10007[3] = "t";
      this.field_690 = new U(var3, var5, var10005, var10006, var10007);
      var3 = 15.0F;
      var5 = 1.0F;
      var10005 = 25.0F;
      var10006 = 1;
      var10007 = new String[4];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "BowTicks";
      var10007[1] = "BowDelay";
      var10007[2] = "bt";
      var10007[3] = "bd";
      this.field_691 = new U(var3, var5, var10005, var10006, var10007);
      t[] var10001 = new t[2];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_690;
      var10001[1] = this.field_691;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var4 = 1;
      var1[0] = new kF(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public enum TE {
   private static final TE[] field_700;
   Right,
   Left;

   static {
      TE[] var10000 = new TE[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Left;
      var10000[1] = Right;
      field_700 = var10000;
   }
}

package net.futureclient.client;

import java.util.Collection;
import java.util.StringJoiner;

public class TH extends xb {
   public String method_4224() {
      return null;
   }

   private static void method_1652(StringJoiner var0, StringJoiner var1, Aa var2) {
      if (var2 instanceof k) {
         ka var3 = (ka)var2;
         Object[] var10002 = new Object[2];
         boolean var10003 = true;
         byte var10004 = 1;
         var10002[0] = var3.method_2387() ? "&a" : "&c";
         var10002[1] = var3.f$c()[0];
         var0.add(String.format("%s%s&7", var10002));
      } else {
         var1.add(var2.method_630()[0]);
      }
   }

   public String method_4228(String[] var1) {
      Collection var4 = YH.method_1211().method_1205().method_2164();
      StringJoiner var2 = new StringJoiner(", ");
      StringJoiner var3 = new StringJoiner(", ");
      var4.forEach(var2.accept<invokedynamic>(var2, var3));
      Object[] var10001 = new Object[3];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = var4.size();
      var10001[1] = var3.toString();
      var10001[2] = var2.toString();
      return String.format("Modules (%s) %s, %s.", var10001);
   }

   public TH() {
      String[] var10001 = new String[5];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Modules";
      var10001[1] = "Mods";
      var10001[2] = "lm";
      var10001[3] = "ml";
      var10001[4] = "list";
      super(var10001);
   }
}

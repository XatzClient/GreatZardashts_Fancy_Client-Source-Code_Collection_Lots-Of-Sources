package net.futureclient.client;

public class TI {
   public TI() {
      YH.method_1211().method_1212().method_1330(new ch(this));
   }
}

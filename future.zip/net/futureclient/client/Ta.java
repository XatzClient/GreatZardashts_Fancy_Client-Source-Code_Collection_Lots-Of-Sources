package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;

public class Ta extends ka {
   public void method_4314() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      super.method_4314();
      if (f$e.player != null) {
         KeyBinding.setKeyBindState(f$e.gameSettings.keyBindAttack.getKeyCode(), EI.method_860(f$e.gameSettings.keyBindAttack));
      }

   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public Ta() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoMine";
      var10002[1] = "AM";
      super("AutoMine", var10002, true, -10111537, bE.WORLD);
      ja[] var10001 = new ja[1];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new Ua(this);
      this.method_2383(var10001);
   }
}

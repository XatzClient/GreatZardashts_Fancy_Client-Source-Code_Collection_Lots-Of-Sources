package net.futureclient.client;

import java.util.ArrayList;
import net.minecraft.network.Packet;

public class Tb extends ja {
   public final pC field_787;

   public Tb(pC var1) {
      this.field_787 = var1;
   }

   private static void method_1779(Packet var0) {
      pC.method_4281().player.connection.sendPacket(var0);
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      pC var10000 = this.field_787;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = pC.method_2732(this.field_787).size();
      var10000.f$D(String.format("FakeLag §7[§F%s§7]", var10002));
      if (var1.method_326().equals(HD.PRE)) {
         pC.method_2717(this.field_787, new Jh(pC.method_4243().player.posX, pC.method_4280().player.posY, pC.method_4279().player.posZ));
         if (!pC.method_2715(this.field_787).equals(iI.f$e)) {
            if (pC.method_2723(this.field_787) == null) {
               ArrayList var2 = new ArrayList();
               pC.method_2728(this.field_787, new ci(0, (String)null, pC.method_4271().world.provider.getDimensionType(), pC.method_2715(this.field_787), var2));
            }

            pC.method_2719(this.field_787, pC.method_2723(this.field_787).method_3136().isEmpty() ? pC.method_2715(this.field_787) : (Jh)pC.method_2723(this.field_787).method_3136().get(pC.method_2723(this.field_787).method_3136().size() - 1));
            if (pC.method_2723(this.field_787).method_3136().isEmpty() || !pC.method_2715(this.field_787).equals(pC.method_2725(this.field_787))) {
               pC.method_2723(this.field_787).method_3136().add(pC.method_2715(this.field_787));
            }

            if (!((sb)pC.method_2718(this.field_787).method_3690()).equals(sb.Blink)) {
               Tb var3;
               switch(ad.f$G[((hd)pC.method_2729(this.field_787).method_3690()).ordinal()]) {
               case 1:
                  boolean var10001 = false;
                  pC.method_2720(this.field_787, !pC.method_4278().player.onGround);
                  var3 = this;
                  break;
               case 2:
                  pC.method_2720(this.field_787, pC.method_4275().player.onGround);
               default:
                  var3 = this;
               }

               if (pC.method_2726(var3.field_787) || pC.method_2732(this.field_787).size() >= pC.method_2727(this.field_787).method_3692().intValue()) {
                  pC.method_2732(this.field_787).forEach(accept<invokedynamic>());
                  pC.method_2732(this.field_787).clear();
                  pC.method_2722(this.field_787).setPositionAndRotation(pC.method_2715(this.field_787).field_94, pC.method_2715(this.field_787).field_93, pC.method_2715(this.field_787).field_95, pC.method_4277().player.rotationYaw, pC.method_4270().player.rotationPitch);
                  pC.method_2722(this.field_787).inventory = pC.method_4267().player.inventory;
                  pC.method_2722(this.field_787).inventoryContainer = pC.method_4273().player.inventoryContainer;
                  pC.method_2722(this.field_787).rotationYawHead = pC.method_4276().player.rotationYawHead;
                  pC.method_2722(this.field_787).setSneaking(pC.method_4274().player.isSneaking());
                  pC.method_2728(this.field_787, (ci)null);
                  pC.method_2731(this.field_787, pC.method_4245().player.motionY);
                  pC.method_2720(this.field_787, false);
               }

            }
         }
      }
   }
}

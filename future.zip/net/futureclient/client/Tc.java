package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayer;

public class Tc extends ja {
   public final WB field_780;

   public Tc(WB var1) {
      this.field_780 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }

   public void method_4241(je var1) {
      if (var1.method_3084() instanceof CPacketPlayer) {
         CPacketPlayer var2 = (CPacketPlayer)var1.method_3084();
         switch(yc.f$G[((FB)WB.method_1981(this.field_780).method_3690()).ordinal()]) {
         case 1:
            Minecraft var10000 = WB.method_4272();
            boolean var10001 = false;
            if (var10000.player.fallDistance > 3.0F) {
               ((e)var2).setOnGround(true);
               return;
            }
            break;
         case 2:
            if (WB.method_4244().player.fallDistance > 3.0F) {
               ((e)var2).setY(WB.method_4289().player.posY + 1.3262473694E-314D);
               return;
            }
            break;
         case 3:
            if (WB.method_4283().player.fallDistance > 3.0F) {
               WB.method_4243().player.onGround = true;
               WB.method_4280().player.capabilities.isFlying = true;
               WB.method_4279().player.capabilities.allowFlying = true;
               ((e)var2).setOnGround(false);
               WB.method_4271().player.velocityChanged = true;
               WB.method_4278().player.capabilities.isFlying = false;
               WB.method_4275().player.jump();
            }
         }
      }

   }
}

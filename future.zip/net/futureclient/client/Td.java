package net.futureclient.client;

public class Td implements C {
   private WE field_775;
   private int field_776;
   private String field_777;

   public Td(String var1, WE var2, int var3) {
      this.field_777 = var1;
      this.field_775 = var2;
      this.field_776 = var3;
   }

   public int method_1759() {
      return this.field_776;
   }

   public WE method_1760() {
      return this.field_775;
   }

   public String method_1761() {
      return this.field_777;
   }

   public void method_1762(int var1) {
      this.field_776 = var1;
   }
}

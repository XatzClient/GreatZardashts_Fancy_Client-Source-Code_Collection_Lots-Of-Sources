package net.futureclient.client;

import java.awt.Color;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

public class Tf extends ja {
   public final uf field_781;

   public Tf(uf var1) {
      this.field_781 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4042((Df)var1);
   }

   public void method_4042(Df var1) {
      if (var1.method_823().equals(GF.PRE)) {
         GL11.glPushMatrix();
         GL11.glPushAttrib(1048575);
         if (uf.method_4100(this.field_781) != null) {
            double var2 = (double)PD.f$c(uf.method_4100(this.field_781)).getX() - ((A)uf.method_4274().getRenderManager()).getRenderPosX();
            double var4 = (double)PD.f$c(uf.method_4100(this.field_781)).getY() - ((A)uf.method_4245().getRenderManager()).getRenderPosY();
            double var6 = (double)PD.f$c(uf.method_4100(this.field_781)).getZ() - ((A)uf.method_4281().getRenderManager()).getRenderPosZ();
            BlockPos var8 = new BlockPos(PD.f$c(uf.method_4100(this.field_781)).getX(), PD.f$c(uf.method_4100(this.field_781)).getY(), PD.f$c(uf.method_4100(this.field_781)).getZ());
            AxisAlignedBB var10 = uf.method_4242().world.getBlockState(var8).getBoundingBox(uf.method_4269().world, var8);
            zF var9 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
            Color var11 = new Color((float)var9.field_1445.getRed() / 255.0F, (float)var9.field_1445.getGreen() / 255.0F, (float)var9.field_1445.getBlue() / 255.0F, 0.9F);
            Di.method_894();
            nI.method_2430(new AxisAlignedBB(var2 + var10.minX, var4 + var10.minY, var6 + var10.minZ, var2 + var10.maxX, var4 + var10.maxY, var6 + var10.maxZ), 1.5F, var11);
            Di.method_942();
            var11 = new Color((float)var11.getRed() / 255.0F, (float)var11.getGreen() / 255.0F, (float)var11.getBlue() / 255.0F, 0.3F);
            Di.method_894();
            nI.method_2434(new AxisAlignedBB(var2 + var10.minX, var4 + var10.minY, var6 + var10.minZ, var2 + var10.maxX, var4 + var10.maxY, var6 + var10.maxZ), var11);
            Di.method_942();
         }

         GL11.glColor4f(1.0F, (float)1, (float)1, (float)1);
         GL11.glPopAttrib();
         GL11.glPopMatrix();
      }
   }
}

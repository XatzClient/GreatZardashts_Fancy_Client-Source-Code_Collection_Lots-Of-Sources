package net.futureclient.client;

import net.minecraft.util.Session;

public class Th {
   private xG field_790;
   private String field_791;
   private String field_792;
   private String field_793;
   private String field_794;
   private String field_795;
   private String field_796;
   private String field_797;

   public Th(String var1, String var2) {
      this.field_790 = xG.NoSession;
      this.field_797 = "";
      this.field_794 = "";
      this.field_796 = "";
      this.field_792 = "";
      this.field_791 = var1;
      this.field_795 = var2;
      this.field_793 = "";
   }

   public Th(String var1) {
      this.field_790 = xG.NonPremium;
      this.field_797 = var1;
      this.field_794 = "";
      this.field_796 = "";
      this.field_792 = "";
      this.field_791 = var1;
      this.field_795 = "";
      this.field_793 = "";
   }

   public Th(String var1, String var2, String var3) {
      this.field_790 = xG.Generated;
      this.field_797 = var1;
      this.field_794 = "";
      this.field_796 = var2;
      this.field_792 = var3;
      this.field_791 = var1;
      this.field_795 = "";
      this.field_793 = "";
   }

   public Th(String var1, String var2, String var3, String var4, String var5) {
      this.field_790 = xG.Premium;
      this.field_797 = var1;
      this.field_794 = var2;
      this.field_796 = "";
      this.field_792 = var3;
      this.field_791 = var4;
      this.field_795 = var5;
      this.field_793 = "";
   }

   public void method_1790(String var1) {
      this.field_794 = var1;
   }

   public String method_1791() {
      return this.field_794;
   }

   public String method_1792() {
      return this.field_791;
   }

   public void method_1793(String var1) {
      this.field_792 = var1;
   }

   public String method_1794() {
      return this.field_792;
   }

   public void method_1795(String var1) {
      this.field_793 = var1;
   }

   public void method_1796(Session var1) {
      this.field_794 = var1.getPlayerID();
      this.field_792 = var1.getToken();
   }

   public String method_1797() {
      return this.field_793;
   }

   public void method_1798(xG var1) {
      this.field_790 = var1;
   }

   public xG method_1799() {
      return this.field_790;
   }

   public String method_1800() {
      return this.field_796;
   }

   public void method_1801(String var1) {
      this.field_796 = var1;
   }

   public String method_1802() {
      return this.field_797;
   }

   public String method_1803() {
      return this.field_795;
   }

   public void method_1804(String var1) {
      this.field_797 = var1;
   }

   public Session method_1805() {
      return this.field_797.isEmpty() ? new Session(this.field_791, this.field_794, this.field_792, "mojang") : new Session(this.field_797, this.field_794, this.field_792, "mojang");
   }
}

package net.futureclient.client;

import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderEye;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityEndermite;
import net.minecraft.entity.monster.EntityEvoker;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGiantZombie;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.entity.monster.EntityIllusionIllager;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntityPolarBear;
import net.minecraft.entity.monster.EntityShulker;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityStray;
import net.minecraft.entity.monster.EntityVex;
import net.minecraft.entity.monster.EntityVindicator;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityDonkey;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityLlama;
import net.minecraft.entity.passive.EntityMule;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.passive.EntityParrot;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityRabbit;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntitySkeletonHorse;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.passive.EntityZombieHorse;
import net.minecraft.entity.projectile.EntityEvokerFangs;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityShulkerBullet;

public class Ti {
   private Ti() {
   }

   public static boolean method_1811(Entity var0) {
      return var0 instanceof EntityIronGolem && ((EntityIronGolem)var0).rotationPitch == 0.0F;
   }

   public static boolean method_1812(Entity var0) {
      return var0 instanceof EntityWolf && !((EntityWolf)var0).isAngry();
   }

   public static boolean method_1813(Entity var0) {
      return var0 instanceof EntityRabbit && ((EntityRabbit)var0).getRabbitType() != 99;
   }

   public static boolean method_1814(Entity var0) {
      return var0 instanceof EntityPolarBear && ((EntityPolarBear)var0).rotationPitch == 0.0F && ((EntityPolarBear)var0).getRevengeTimer() <= 0;
   }

   public static boolean method_1815(Entity var0) {
      return var0 instanceof EntityCreeper || var0 instanceof EntityIllusionIllager || var0 instanceof EntitySkeleton || var0 instanceof EntityZombie && !(var0 instanceof EntityPigZombie) || var0 instanceof EntityBlaze || var0 instanceof EntitySpider || var0 instanceof EntityWitch || var0 instanceof EntitySlime || var0 instanceof EntitySilverfish || var0 instanceof EntityGuardian || var0 instanceof EntityEndermite || var0 instanceof EntityGhast || var0 instanceof EntityEvoker || var0 instanceof EntityShulker || var0 instanceof EntityWitherSkeleton || var0 instanceof EntityStray || var0 instanceof EntityVex || var0 instanceof EntityVindicator || var0 instanceof EntityPolarBear && !method_1814(var0) || var0 instanceof EntityWolf && !method_1812(var0) || var0 instanceof EntityPigZombie && !method_1822(var0) || var0 instanceof EntityEnderman && !method_1816(var0) || var0 instanceof EntityRabbit && !method_1813(var0) || var0 instanceof EntityIronGolem && !method_1811(var0);
   }

   public static boolean method_1816(Entity var0) {
      return var0 instanceof EntityEnderman && !((EntityEnderman)var0).isScreaming();
   }

   public static boolean method_1817(Entity var0) {
      return var0 instanceof EntityWolf && method_1812(var0) || var0 instanceof EntityPolarBear && method_1814(var0) || var0 instanceof EntityIronGolem && method_1811(var0) || var0 instanceof EntityEnderman && method_1816(var0) || var0 instanceof EntityPigZombie && method_1822(var0);
   }

   public static boolean method_1818(Entity var0) {
      return var0 instanceof EntityDragon || var0 instanceof EntityWither || var0 instanceof EntityGiantZombie;
   }

   public static boolean method_1819(Entity var0) {
      return var0 instanceof EntityEnderCrystal || var0 instanceof EntityEvokerFangs || var0 instanceof EntityShulkerBullet || var0 instanceof EntityFallingBlock || var0 instanceof EntityFireball || var0 instanceof EntityEnderEye || var0 instanceof EntityEnderPearl;
   }

   public static boolean method_1820(Entity var0) {
      return var0 instanceof EntityBoat || var0 instanceof EntityMinecart;
   }

   public static boolean method_1821(Entity var0) {
      return var0 instanceof EntityPig || var0 instanceof EntityParrot || var0 instanceof EntityCow || var0 instanceof EntitySheep || var0 instanceof EntityChicken || var0 instanceof EntitySquid || var0 instanceof EntityBat || var0 instanceof EntityVillager || var0 instanceof EntityOcelot || var0 instanceof EntityHorse || var0 instanceof EntityLlama || var0 instanceof EntityMule || var0 instanceof EntityDonkey || var0 instanceof EntitySkeletonHorse || var0 instanceof EntityZombieHorse || var0 instanceof EntitySnowman || var0 instanceof EntityRabbit && method_1813(var0);
   }

   public static boolean method_1822(Entity var0) {
      return var0 instanceof EntityPigZombie && ((EntityPigZombie)var0).rotationPitch == 0.0F && ((EntityPigZombie)var0).getRevengeTimer() <= 0;
   }
}

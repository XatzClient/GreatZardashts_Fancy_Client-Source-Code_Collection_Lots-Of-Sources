package net.futureclient.client;

public enum UA {
   Steal,
   Fill,
   Drop;

   private static final UA[] field_786;

   static {
      UA[] var10000 = new UA[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Steal;
      var10000[1] = Fill;
      var10000[2] = Drop;
      field_786 = var10000;
   }
}

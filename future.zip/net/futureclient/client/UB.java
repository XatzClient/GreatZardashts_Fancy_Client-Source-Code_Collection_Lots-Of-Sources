package net.futureclient.client;

public class UB extends ja {
   public final Nc field_789;

   public UB(Nc var1) {
      this.field_789 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (Nc.method_4315().player.getRidingEntity() != null) {
         Nc.method_594(this.field_789).method_814();
      }

      lA var2;
      if ((Boolean)this.field_789.field_274.method_3690() && Nc.method_593(this.field_789) == 0 && (var2 = (lA)YH.method_1211().method_1205().method_2166(lA.class)) != null && !var2.f$c()) {
         ((r)((w)Nc.method_4319()).getTimer()).method_3790(1.0F);
      }

   }
}

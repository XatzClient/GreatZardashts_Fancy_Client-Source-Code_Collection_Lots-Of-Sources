package net.futureclient.client;

import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;

public class UC extends ja {
   public final DC field_788;

   public UC(DC var1) {
      this.field_788 = var1;
   }

   public void method_1782(if var1) {
      if (Lb.field_205) {
         EntityLivingBase var2 = var1.method_2377();
         if (DC.method_677(this.field_788, var2)) {
            var1.f$c(true);
            boolean var4 = GL11.glIsEnabled(2896);
            boolean var3 = GL11.glIsEnabled(3042);
            GL11.glPushAttrib(1048575);
            GL11.glDisable(3008);
            if (!(Boolean)DC.method_676(this.field_788).method_3690()) {
               GL11.glDisable(3553);
            }

            if (var4) {
               GL11.glDisable(2896);
            }

            if (!var3) {
               GL11.glEnable(3042);
            }

            GL11.glBlendFunc(770, 771);
            if ((Boolean)DC.method_681(this.field_788).method_3690()) {
               GL11.glColor4f(1.0F, 0.0F, (float)0, 1.0F);
               GL11.glDepthMask(false);
               GL11.glDisable(2929);
               OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
               DC.method_680(this.field_788, var1);
            }

            GL11.glDisable(3042);
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            GL11.glEnable(2896);
            if (!(Boolean)DC.method_676(this.field_788).method_3690()) {
               GL11.glEnable(3553);
            }

            GL11.glEnable(3008);
            GL11.glPopAttrib();
            GL11.glPushAttrib(1048575);
            GL11.glDisable(3008);
            if (!(Boolean)DC.method_676(this.field_788).method_3690()) {
               GL11.glDisable(3553);
            }

            GL11.glDisable(2896);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glColor4f(0.0F, 1.0F, 0.0F, 1.0F);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
            DC.method_680(this.field_788, var1);
            if (!var3) {
               GL11.glDisable(3042);
            }

            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            if (var4) {
               GL11.glEnable(2896);
            }

            if (!(Boolean)DC.method_676(this.field_788).method_3690()) {
               GL11.glEnable(3553);
            }

            GL11.glEnable(3008);
            GL11.glPopAttrib();
         }
      }
   }

   public void method_4312(CD var1) {
      this.method_1782((if)var1);
   }
}

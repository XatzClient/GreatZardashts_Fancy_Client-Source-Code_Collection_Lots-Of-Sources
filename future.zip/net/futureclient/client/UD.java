package net.futureclient.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.File;
import java.io.IOException;
import org.lwjgl.input.Keyboard;

public class UD extends jB {
   public final jF field_779;

   public UD(jF var1, String var2) {
      super(var2);
      this.field_779 = var1;
   }

   public void method_3650(Object... var1) {
      UD var10000 = this;

      try {
         if (!var10000.method_2185().exists()) {
            this.method_2185().createNewFile();
         }
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      YH.method_1211().method_1205().method_2164().forEach(accept<invokedynamic>());
      this.method_1767();
   }

   private void method_1766() {
      // $FF: Couldn't be decompiled
   }

   private void method_1767() {
      // $FF: Couldn't be decompiled
   }

   private static void method_1768(JsonElement var0) {
      if (var0 instanceof JsonObject) {
         JsonElement var10000 = var0;

         try {
            JsonObject var1 = (JsonObject)var10000;
            YH.method_1211().method_1205().method_2164().forEach(var1.accept<invokedynamic>(var1));
         } catch (Throwable var2) {
            var2.printStackTrace();
         }
      }
   }

   public void method_3649(Object... var1) {
      UD var10000 = this;

      try {
         if (!var10000.method_2185().exists()) {
            this.method_2185().createNewFile();
         }
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      File var2;
      if (!(var2 = new File(YH.method_1211().method_1217(), "modules")).exists()) {
         var2.mkdir();
      }

      YH.method_1211().method_1205().method_2164().forEach(accept<invokedynamic>());
      this.method_1766();
   }

   private static void method_1770(JsonArray var0, Aa var1) {
      JsonObject var10000 = new JsonObject;
      JsonObject var10001 = var10000;

      try {
         var10001.<init>();
         JsonObject var2 = var10000;
         var10000.addProperty("module-label", var1.method_630()[0]);
         if (var1 instanceof k) {
            ka var3 = (ka)var1;
            var2.addProperty("module-state", var3.method_2387());
            var2.addProperty(Bh.f$c("\tn\u0000t\bdIe\u0016`\u0013o"), var3.method_2380());
            String var5 = y.f$c("5\u0017<\r4\u001du\u0013=\u0001:\u00116\u001c");
            qf var10002 = YH.method_1211().method_1210();
            Object[] var10004 = new Object[1];
            boolean var10005 = true;
            byte var10006 = 1;
            var10004[0] = var3.f$c()[0].replace(" ", "");
            var2.addProperty(var5, Keyboard.getKeyName(var10002.method_3800(String.format("%sToggle", var10004)).method_1759()));
         }

         var0.add(var2);
      } catch (Exception var4) {
         var4.printStackTrace();
      }
   }

   private static void method_1771(JsonObject var0, Aa var1) {
      if (var1.method_630()[0].equalsIgnoreCase(var0.get("module-label").getAsString()) && var1 instanceof k) {
         ka var2 = (ka)var1;
         if (var0.get("module-state").getAsBoolean()) {
            var2.method_2388(true);
         }

         var2.method_2382(var0.get("module-drawn").getAsBoolean());
         JsonPrimitive var3;
         int var4 = (var3 = var0.getAsJsonPrimitive("module-keybind")).isString() ? Keyboard.getKeyIndex(var3.getAsString()) : var3.getAsInt();
         if (var2.getClass().equals(vA.class) && var4 == 0) {
            var4 = 54;
         }

         qf var10000 = YH.method_1211().method_1210();
         Object[] var10002 = new Object[1];
         boolean var10003 = true;
         byte var10004 = 1;
         var10002[0] = var2.f$c()[0].replace(" ", "");
         var10000.method_3800(String.format("%sToggle", var10002)).method_1762(var4);
      }

   }
}

package net.futureclient.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.input.Keyboard;

public class UE extends jB {
   public final DF field_778;

   public UE(DF var1, String var2) {
      super(var2);
      this.field_778 = var1;
   }

   public void method_3650(Object... var1) {
      UE var10000 = this;

      try {
         if (!var10000.method_2185().exists()) {
            this.method_2185().createNewFile();
         }
      } catch (IOException var5) {
         var5.printStackTrace();
      }

      BufferedWriter var9 = new BufferedWriter;
      BufferedWriter var10001 = var9;
      FileWriter var10002 = new FileWriter;
      FileWriter var10003 = var10002;
      UE var10004 = this;

      Exception var10;
      label42: {
         BufferedWriter var2;
         boolean var12;
         try {
            var10003.<init>(var10004.method_2185());
            var10001.<init>(var10002);
            var2 = var9;
            Iterator var3;
            Iterator var11 = var3 = this.field_778.field_1201.iterator();

            while(var11.hasNext()) {
               eD var4 = (eD)var3.next();
               var11 = var3;
               var2.write(Keyboard.getKeyName(var4.method_3056()) + ":" + var4.method_3054());
               var2.newLine();
            }
         } catch (Exception var7) {
            var10 = var7;
            var12 = false;
            break label42;
         }

         var9 = var2;

         try {
            var9.close();
            return;
         } catch (Exception var6) {
            var10 = var6;
            var12 = false;
         }
      }

      Exception var8 = var10;
      var8.printStackTrace();
   }

   public void method_3649(Object... var1) {
      this.field_778.field_1201.clear();
      UE var10000 = this;

      try {
         if (!var10000.method_2185().exists()) {
            this.method_2185().createNewFile();
         }
      } catch (IOException var7) {
         var7.printStackTrace();
      }

      if (this.method_2185().exists()) {
         BufferedReader var11 = new BufferedReader;
         BufferedReader var10001 = var11;
         FileReader var10002 = new FileReader;
         FileReader var10003 = var10002;
         UE var10004 = this;

         try {
            var10003.<init>(var10004.method_2185());
            var10001.<init>(var10002);
            BufferedReader var2 = var11;

            String var3;
            while((var3 = var2.readLine()) != null) {
               String[] var10 = var3.split(":");
               String var12 = var10[0];

               int var4;
               label40: {
                  try {
                     var4 = Integer.parseInt(var12);
                  } catch (NumberFormatException var8) {
                     var4 = Keyboard.getKeyIndex(var10[0]);
                     var10000 = this;
                     break label40;
                  }

                  var10000 = this;
               }

               List var14 = var10000.field_778.field_1201;
               eD var13 = new eD;
               eD var15 = var13;
               int var16 = var4;
               String var17 = var10[1];

               try {
                  var15.<init>(var16, var17);
                  var14.add(var13);
               } catch (Exception var6) {
                  var6.printStackTrace();
               }
            }

            var2.close();
         } catch (Exception var9) {
            var9.printStackTrace();
         }
      }
   }
}

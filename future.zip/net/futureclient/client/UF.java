package net.futureclient.client;

import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

public class UF extends ja {
   public final tD field_782;

   public UF(tD var1) {
      this.field_782 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   private static boolean method_4180(Entry var0) {
      return System.currentTimeMillis() - ((nF)var0.getValue()).f$c() > TimeUnit.SECONDS.toMillis(30L);
   }

   public void method_4183(Xe var1) {
      tD.method_3902(this.field_782).entrySet().removeIf(test<invokedynamic>());
   }
}

package net.futureclient.client;

import com.google.common.io.ByteArrayDataOutput;
import java.io.DataInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class UH extends Oi {
   private int field_798;
   private DataInputStream field_799;

   public UH(int var1, DataInputStream var2) {
      this.field_798 = var1;
      this.field_799 = var2;
   }

   public void method_1873(ByteArrayDataOutput var1) throws IOException {
   }

   public int method_1871() {
      return this.field_798;
   }

   public void method_1874(DataInputStream var1) throws IOException {
   }

   public Oi method_1810(Class var1) throws IOException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
      Class[] var10001 = new Class[0];
      boolean var10002 = true;
      byte var10003 = 1;
      Constructor var2 = var1.getConstructor(var10001);
      var2.setAccessible(true);
      Object[] var3 = new Object[0];
      var10002 = true;
      var10003 = 1;
      Oi var10000 = (Oi)var2.newInstance(var3);
      var10000.method_1874(this.field_799);
      return var10000;
   }
}

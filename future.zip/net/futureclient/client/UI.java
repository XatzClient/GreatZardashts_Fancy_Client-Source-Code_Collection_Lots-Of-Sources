package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class UI extends ka {
   public static void method_4050() {
      byte var10002 = 1;
      byte var10003 = 1;
      if (YH.method_1211().method_1209().field_182 != 1) {
         Minecraft.getMinecraft().shutdownMinecraftApplet();
      }

   }

   public UI() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[3];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "LongJump";
      byte var1 = 1;
      var10006 = 1;
      var10002[1] = "LJ";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "longneck";
      var10004 = 1;
      var1 = 1;
      super("LongJump", var10002, true, -87927212, bE.MOVEMENT);
   }
}

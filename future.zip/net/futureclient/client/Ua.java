package net.futureclient.client;

import net.minecraft.client.settings.KeyBinding;

public class Ua extends ja {
   public final Ta field_752;

   public Ua(Ta var1) {
      this.field_752 = var1;
   }

   public void method_4183(Xe var1) {
      if (Ta.method_4269().currentScreen != null) {
         Ta.method_4315().currentScreen.allowUserInput = true;
      }

      KeyBinding.setKeyBindState(Ta.method_4319().gameSettings.keyBindAttack.getKeyCode(), true);
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

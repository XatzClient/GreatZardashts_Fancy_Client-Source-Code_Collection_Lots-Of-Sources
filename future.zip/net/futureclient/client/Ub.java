package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;

public class Ub extends ka {
   private t field_755;
   private t field_756;
   private ga field_757;
   private t field_758;
   private t field_759;
   private U field_760;
   private t field_761;
   private t field_762;
   private t field_763;
   private t field_764;
   private ga field_765;
   private t field_766;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static ga method_1747(Ub var0) {
      return var0.field_757;
   }

   private boolean method_1748(Entity var1) {
      if (var1 != null && var1 != f$e.getRenderViewEntity() && (f$e.getRenderViewEntity() == null || var1 != f$e.getRenderViewEntity().getRidingEntity())) {
         if ((Boolean)this.field_756.method_3690() && var1 instanceof EntityPlayer && ((Boolean)this.field_762.method_3690() || !var1.isInvisible()) && ((Boolean)this.field_766.method_3690() || !YH.method_1211().method_1216().method_1481(var1.getName()))) {
            return true;
         } else if (!(Boolean)this.field_758.method_3690() || !Ti.method_1815(var1) && !Ti.method_1818(var1)) {
            if (!(Boolean)this.field_764.method_3690() || !Ti.method_1817(var1) && !Ti.method_1821(var1)) {
               if ((Boolean)this.field_755.method_3690() && Ti.method_1820(var1)) {
                  return true;
               } else if ((Boolean)this.field_761.method_3690() && Ti.method_1819(var1)) {
                  return true;
               } else {
                  return (Boolean)this.field_763.method_3690() && var1 instanceof EntityItem;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   public static boolean method_1749(Ub var0, Entity var1) {
      return var0.method_1748(var1);
   }

   public static ga method_1750(Ub var0) {
      return var0.field_765;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static t method_1752(Ub var0) {
      return var0.field_759;
   }

   public static U method_1753(Ub var0) {
      return var0.field_760;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public Ub() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Tracers";
      var10002[1] = "trace";
      var10002[2] = "tracer";
      super("Tracers", var10002, false, -38037, bE.RENDER);
      Boolean var3 = true;
      String[] var4 = new String[5];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Players";
      var4[1] = "Player";
      var4[2] = "Mans";
      var4[3] = "Humans";
      var4[4] = "p";
      this.field_756 = new t(var3, var4);
      var3 = true;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Friends";
      var4[1] = "Friend";
      var4[2] = "Teammates";
      var4[3] = "Teammate";
      this.field_766 = new t(var3, var4);
      var3 = false;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Invisibles";
      var4[1] = "invis";
      var4[2] = "inv";
      var4[3] = "i";
      this.field_762 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Monsters";
      var4[1] = "Mobs";
      var4[2] = "Mob";
      this.field_758 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Animals";
      var4[1] = "Anamals";
      var4[2] = "Anims";
      this.field_764 = new t(var3, var4);
      var3 = false;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Vehicles";
      var4[1] = "Boat";
      var4[2] = "Boats";
      var4[3] = "Minecarts";
      var4[4] = "Minecart";
      var4[5] = "V";
      this.field_755 = new t(var3, var4);
      var3 = false;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Items";
      var4[1] = "Item";
      var4[2] = "Gems";
      var4[3] = "aitems";
      var4[4] = "itms";
      var4[5] = "tems";
      this.field_763 = new t(var3, var4);
      var3 = false;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Others";
      var4[1] = "Other";
      var4[2] = "Miscellaneous";
      var4[3] = "Misc";
      var4[4] = "Miscellaneus";
      var4[5] = "M";
      this.field_761 = new t(var3, var4);
      var3 = true;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Lines";
      var4[1] = "line";
      var4[2] = "l";
      this.field_759 = new t(var3, var4);
      xB var5 = xB.Feet;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Target";
      var4[1] = "Type";
      var4[2] = "t";
      this.field_757 = new ga(var5, var4);
      td var6 = td.Off;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Design";
      var4[1] = "Box";
      var4[2] = "d";
      var4[3] = "type";
      this.field_765 = new ga(var6, var4);
      Float var7 = 1.6F;
      Float var9 = 0.1F;
      Float var10 = 10.0F;
      Double var11 = 1.273197475E-314D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Width";
      var10007[1] = "Radius";
      var10007[2] = "raidus";
      this.field_760 = new U(var7, var9, var10, var11, var10007);
      t[] var10001 = new t[12];
      boolean var2 = true;
      byte var8 = 1;
      var10001[0] = this.field_756;
      var10001[1] = this.field_766;
      var10001[2] = this.field_762;
      var10001[3] = this.field_758;
      var10001[4] = this.field_764;
      var10001[5] = this.field_755;
      var10001[6] = this.field_763;
      var10001[7] = this.field_761;
      var10001[8] = this.field_757;
      var10001[9] = this.field_765;
      var10001[10] = this.field_759;
      var10001[11] = this.field_760;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var8 = 1;
      var1[0] = new xA(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

import java.awt.Color;
import java.util.Comparator;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.text.translation.I18n;

public class Ud extends ja {
   public final YE field_750;

   public Ud(YE var1) {
      this.field_750 = var1;
   }

   public void method_4312(CD var1) {
      this.method_1735((kf)var1);
   }

   private void method_1734(kf var1, PotionEffect var2) {
      Potion var3 = var2.getPotion();
      String var4 = (new StringBuilder()).insert(0, I18n.translateToLocal(var3.getName())).append(var2.getAmplifier() > 0 ? (new StringBuilder()).insert(0, " ").append(var2.getAmplifier() + 1).toString() : "").append(" §F").append(Potion.getPotionDurationString(var2, 1.0F)).toString();
      YE.method_1256(this.field_750, var1, var4, var3.getLiquidColor());
   }

   public void method_1735(kf var1) {
      if (!YE.method_4280().gameSettings.showDebugInfo) {
         var1.field_1003 = -((Boolean)this.field_750.field_583.method_3690() ? this.field_750.field_573.f$c() : YE.method_4279().fontRenderer.FONT_HEIGHT) + 2;
         var1.field_1003 += YE.method_1262(this.field_750);
         var1.field_1005 = ((Boolean)this.field_750.field_583.method_3690() ? this.field_750.field_573.f$c() : YE.method_4271().fontRenderer.FONT_HEIGHT) - 1;
         if ((Boolean)this.field_750.field_565.method_3690()) {
            YE.method_4278().player.getActivePotionEffects().stream().sorted(((Jg)YE.method_1255(this.field_750).method_3690()).equals(Jg.Up) ? Comparator.comparing(apply<invokedynamic>()).reversed() : Comparator.comparing(apply<invokedynamic>())).forEach(this.accept<invokedynamic>(this, var1));
         }

         if ((Boolean)this.field_750.field_579.method_3690()) {
            YE.method_1256(this.field_750, var1, YE.method_4275().getCurrentServerData() == null ? "Vanilla" : YE.method_4277().player.getServerBrand(), -5592406);
         }

         if ((Boolean)this.field_750.field_571.method_3690()) {
            YE.method_1237(this.field_750, var1);
         }

         if ((Boolean)this.field_750.field_575.method_3690()) {
            YE.method_1279(this.field_750, var1);
         }

         if ((Boolean)this.field_750.field_584.method_3690()) {
            YE.method_1231(this.field_750, var1);
         }

         if ((Boolean)this.field_750.field_558.method_3690()) {
            YE.method_1261(this.field_750, var1);
         }

         if ((Boolean)this.field_750.field_556.method_3690()) {
            YE.method_1240(this.field_750, var1);
         }

         YE var10000;
         Object[] var10003;
         boolean var10004;
         byte var10005;
         if ((Boolean)this.field_750.field_561.method_3690()) {
            var10000 = this.field_750;
            var10003 = new Object[1];
            var10004 = true;
            var10005 = 1;
            var10003[0] = (double)Math.round(YE.method_1246(this.field_750) * 0.0D) / 0.0D;
            YE.method_1256(var10000, var1, String.format("Speed §F%skm/h", var10003), -5592406);
         }

         if ((Boolean)this.field_750.field_560.method_3690() && YE.method_4270().player.inventory.getCurrentItem().isItemStackDamageable()) {
            int var2 = YE.method_4267().player.inventory.getCurrentItem().getMaxDamage();
            int var3 = YE.method_4273().player.inventory.getCurrentItem().getItemDamage();
            Color var4 = (new ei((float)(var2 - var3) / (float)var2 * 120.0F, 100.0F, 50.0F, 1.0F)).method_3395();
            var10000 = this.field_750;
            var10003 = new Object[1];
            var10004 = true;
            var10005 = 1;
            var10003[0] = var2 - var3;
            YE.method_1256(var10000, var1, String.format("§7Durability §r%s", var10003), var4.getRGB());
         }

         if ((Boolean)this.field_750.field_564.method_3690() && !YE.method_4276().isSingleplayer() && YE.method_4245().getConnection().getPlayerInfo(YE.method_4274().player.getUniqueID()) != null) {
            var10000 = this.field_750;
            var10003 = new Object[1];
            var10004 = true;
            var10005 = 1;
            var10003[0] = YE.method_4242().getConnection().getPlayerInfo(YE.method_4281().player.getUniqueID()).getResponseTime();
            YE.method_1256(var10000, var1, String.format("Ping §F%sms", var10003), -5592406);
         }

         if ((Boolean)this.field_750.field_559.method_3690()) {
            var10000 = this.field_750;
            var10003 = new Object[1];
            var10004 = true;
            var10005 = 1;
            var10003[0] = (double)Math.round((double)YH.method_1211().method_1204().method_131() * 0.0D) / 0.0D;
            YE.method_1256(var10000, var1, String.format("TPS §F%s", var10003), -5592406);
         }

         if ((Boolean)this.field_750.field_554.method_3690()) {
            var10000 = this.field_750;
            var10003 = new Object[1];
            var10004 = true;
            var10005 = 1;
            YE.method_4269();
            var10003[0] = Minecraft.getDebugFPS();
            YE.method_1256(var10000, var1, String.format("FPS §F%s", var10003), -5592406);
         }

         if ((Boolean)this.field_750.field_576.method_3690()) {
            YE.method_1248(this.field_750, var1);
         }

      }
   }
}

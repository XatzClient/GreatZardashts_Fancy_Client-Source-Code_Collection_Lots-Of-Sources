package net.futureclient.client;

import net.minecraft.client.gui.GuiDownloadTerrain;

public class Ue extends ja {
   public final KD field_743;

   public Ue(KD var1) {
      this.field_743 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4128((Xd)var1);
   }

   public void method_4128(Xd var1) {
      if (!((OF)KD.method_217(this.field_743).method_3690()).equals(OF.Off) && var1.method_1230() instanceof GuiDownloadTerrain) {
         this.field_743.method_2388(false);
      }

   }
}

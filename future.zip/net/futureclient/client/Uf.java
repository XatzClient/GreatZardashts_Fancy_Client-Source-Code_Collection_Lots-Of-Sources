package net.futureclient.client;

import net.minecraft.item.ItemFood;

public class Uf extends ja {
   public final KD field_751;

   public Uf(KD var1) {
      this.field_751 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      KD var10000 = this.field_751;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = this.field_751.field_130.method_3690();
      var10000.method_616(String.format("Aura §7[§F%s§7]", var10002));
      if (!((OF)KD.method_217(this.field_751).method_3690()).equals(OF.Off) && KD.method_4245().player.getHealth() <= 0.0F) {
         this.field_751.method_2388(false);
      }

      if ((Boolean)this.field_751.field_121.method_3690() || !(((a)KD.method_4281().player).getActiveItemStack().getItem() instanceof ItemFood)) {
         switch(BF.f$E[var1.method_326().ordinal()]) {
         case 1:
            boolean var10001 = false;
            KD.method_212(this.field_751, var1);
            return;
         case 2:
            KD.method_214(this.field_751);
         default:
         }
      }
   }
}

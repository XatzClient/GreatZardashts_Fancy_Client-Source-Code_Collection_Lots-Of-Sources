package net.futureclient.client;

public enum Uh {
   Chest,
   Feet,
   Head,
   Legs,
   Pelvis,
   Neck;

   private static final Uh[] field_774;

   static {
      Uh[] var10000 = new Uh[6];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Head;
      var10000[1] = Neck;
      var10000[2] = Chest;
      var10000[3] = Pelvis;
      var10000[4] = Legs;
      var10000[5] = Feet;
      field_774 = var10000;
   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.math.BlockPos;

public class VA extends ja {
   public final vb field_754;

   public VA(vb var1) {
      this.field_754 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      int var2;
      switch(Hb.f$e[var1.method_326().ordinal()]) {
      case 1:
         boolean var10001 = false;
         vb.method_4010(this.field_754).clear();
         if (vb.method_4012(this.field_754) == null) {
            return;
         } else {
            VA var10 = this;

            while(vb.method_4022(var10.field_754) < vb.method_4008(this.field_754).length) {
               T var6;
               if ((var6 = vb.method_4008(this.field_754)[vb.method_4022(this.field_754)]) instanceof ai) {
                  ai var8 = (ai)var6;
                  if (vb.method_4005(this.field_754) >= var8.f$c()) {
                     vb.method_4009(this.field_754);
                     vb.method_4019(this.field_754, 0);
                  }

                  if (vb.method_4010(this.field_754).size() > 0) {
                     BlockPos var12 = (BlockPos)vb.method_4010(this.field_754).get(0);
                     float[] var5;
                     float[] var11 = var5 = ri.method_3668(var12, fI.f$c(var12));
                     var1.method_2096(var5[0]);
                     var1.method_3094(var11[1]);
                  }

                  return;
               }

               if (!(var6 instanceof cG)) {
                  var10 = this;
               } else {
                  cG var7 = (cG)var6;
                  BlockPos var9;
                  if ((var9 = vb.method_4018(this.field_754, var7)) != null) {
                     vb.method_4010(this.field_754).add(var9);
                  }

                  var10 = this;
                  vb.method_4009(this.field_754);
               }
            }

            vb.method_4007(this.field_754, 0);
            return;
         }
      case 2:
         for(int var10000 = var2 = 0; var10000 < vb.method_4010(this.field_754).size(); var10000 = var2) {
            BlockPos var3 = (BlockPos)vb.method_4010(this.field_754).get(var2);
            if (var2 != 0) {
               float[] var4 = ri.method_3668(var3, fI.f$c(var3));
               vb.method_4269().player.connection.sendPacket(new Rotation(var4[0], var4[1], vb.method_4242().player.onGround));
            }

            vb.method_4315().player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, var3, fI.f$c(var3)));
            ++var2;
            vb.method_4319().player.connection.sendPacket(new CPacketPlayerDigging(Action.ABORT_DESTROY_BLOCK, var3, fI.f$c(var3)));
         }
      default:
      }
   }
}

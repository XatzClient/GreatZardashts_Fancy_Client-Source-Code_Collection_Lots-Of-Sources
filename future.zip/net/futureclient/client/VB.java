package net.futureclient.client;

import java.awt.TrayIcon.MessageType;
import org.lwjgl.opengl.Display;

public class VB extends ja {
   public final YC field_753;

   public VB(YC var1) {
      this.field_753 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4193((ae)var1);
   }

   public void method_4193(ae var1) {
      if (!Display.isActive() && (Boolean)this.field_753.field_816.method_3690() && YC.method_4269().getCurrentServerData() != null && YC.method_4315().getCurrentServerData().serverIP.equalsIgnoreCase("2b2t.org") && YC.method_1826(this.field_753).method_3405(10000L)) {
         YH.method_1211().method_1208().field_1163.displayMessage("Connected to the server", "You have finished going through the queue.", MessageType.NONE);
      }

   }
}

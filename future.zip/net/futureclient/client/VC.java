package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.ClickType;

public class VC extends ja {
   public final tC field_767;

   public VC(tC var1) {
      this.field_767 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (tC.method_4270().currentScreen instanceof GuiChest) {
         GuiChest var2 = (GuiChest)tC.method_4267().currentScreen;
         if (!tC.method_3928().contains(((j)var2).getLowerChestInventory().getDisplayName().getUnformattedText())) {
            int var10000;
            int var3;
            if (((UA)tC.method_3923(this.field_767).method_3690()).equals(UA.Fill)) {
               for(var10000 = var3 = ((j)var2).getLowerChestInventory().getSizeInventory(); var10000 <= ((j)var2).getLowerChestInventory().getSizeInventory() + 35; var10000 = var3) {
                  if (!tC.method_4273().player.inventoryContainer.getSlot(var3 - ((j)var2).getLowerChestInventory().getSizeInventory() + 9).getStack().isEmpty() && tC.method_3926(this.field_767).method_811(tC.method_3924(this.field_767).method_3692().floatValue() * 1000.0F)) {
                     tC.method_4274().playerController.windowClick(var2.inventorySlots.windowId, var3, 0, ClickType.QUICK_MOVE, tC.method_4276().player);
                     tC.method_3926(this.field_767).method_814();
                     return;
                  }

                  ++var3;
               }
            } else {
               for(var10000 = var3 = 0; var10000 < ((j)var2).getLowerChestInventory().getSizeInventory(); var10000 = var3) {
                  if (!((j)var2).getLowerChestInventory().getStackInSlot(var3).isEmpty() && tC.method_3926(this.field_767).method_811(tC.method_3924(this.field_767).method_3692().floatValue() * 1000.0F)) {
                     VC var6;
                     switch(cA.f$e[((UA)tC.method_3923(this.field_767).method_3690()).ordinal()]) {
                     case 1:
                        Minecraft var5 = tC.method_4281();
                        boolean var10001 = false;
                        var5.playerController.windowClick(var2.inventorySlots.windowId, var3, 0, ClickType.QUICK_MOVE, tC.method_4245().player);
                        var6 = this;
                        break;
                     case 2:
                        tC.method_4269().playerController.windowClick(var2.inventorySlots.windowId, var3, 0, ClickType.PICKUP, tC.method_4242().player);
                        tC.method_4319().playerController.windowClick(var2.inventorySlots.windowId, -999, 0, ClickType.PICKUP, tC.method_4315().player);
                     default:
                        var6 = this;
                     }

                     tC.method_3926(var6.field_767).method_814();
                  }

                  ++var3;
               }
            }

         }
      }
   }
}

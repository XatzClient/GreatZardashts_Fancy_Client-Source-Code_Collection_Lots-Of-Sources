package net.futureclient.client;

import net.minecraft.util.MovementInput;

public abstract class VE extends CD {
   private final MovementInput field_749;

   public VE(MovementInput var1) {
      this.field_749 = var1;
   }

   public MovementInput method_1732() {
      return this.field_749;
   }
}

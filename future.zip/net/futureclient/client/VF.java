package net.futureclient.client;

import net.minecraft.entity.MoverType;

public class VF extends CD {
   public double field_744;
   public double field_745;
   private MoverType field_746;
   public double field_747;
   private boolean field_748;

   public VF(MoverType var1, double var2, double var4, double var6, boolean var8) {
      this.field_746 = var1;
      this.field_745 = var2;
      this.field_744 = var4;
      this.field_747 = var6;
      this.field_748 = var8;
   }

   public double method_1723() {
      return this.field_744;
   }

   public boolean method_3480() {
      return this.field_748;
   }

   public void method_3481(boolean var1) {
      this.field_748 = var1;
   }

   public void method_1726(double var1) {
      this.field_744 = var1;
   }

   public double method_4037() {
      return this.field_747;
   }

   public MoverType method_1728() {
      return this.field_746;
   }

   public void method_4038(double var1) {
      this.field_747 = var1;
   }

   public double method_1730() {
      return this.field_745;
   }

   public void method_1731(double var1) {
      this.field_745 = var1;
   }
}

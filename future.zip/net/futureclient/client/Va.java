package net.futureclient.client;

import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class Va extends ka {
   private U field_876;
   private boolean field_877;
   private ga field_878;
   private BlockPos field_879;
   private List field_880;
   private EG field_881;
   private U field_882;
   private EnumFacing field_883;
   private boolean field_884;
   private U field_885;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static boolean method_2002(Va var0) {
      return var0.field_884;
   }

   public static boolean method_2003(Va var0, boolean var1) {
      return var0.field_877 = var1;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static BlockPos method_2006(Va var0, BlockPos var1) {
      return var0.field_879 = var1;
   }

   public static EnumFacing method_2007(Va var0, EnumFacing var1) {
      return var0.field_883 = var1;
   }

   public static BlockPos method_2008(Va var0) {
      return var0.field_879;
   }

   public static EG method_2009(Va var0) {
      return var0.field_881;
   }

   public static U method_2010(Va var0) {
      return var0.field_885;
   }

   public static ga method_2011(Va var0) {
      return var0.field_878;
   }

   public static EnumFacing method_2012(Va var0) {
      return var0.field_883;
   }

   public static boolean method_2013(Va var0, boolean var1) {
      return var0.field_884 = var1;
   }

   public static boolean method_2014(Va var0) {
      return var0.field_877;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static List method_2016(Va var0) {
      return var0.field_880;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_3745() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_3747() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4288() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_3752() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4291() {
      return f$e;
   }

   public static Minecraft method_4292() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_3757() {
      return f$e;
   }

   public static Minecraft method_4294() {
      return f$e;
   }

   public static Minecraft method_3759() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_3761() {
      return f$e;
   }

   public static Minecraft method_4296() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4298() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public static Minecraft method_4300() {
      return f$e;
   }

   public static Minecraft method_3767() {
      return f$e;
   }

   public static Minecraft method_4301() {
      return f$e;
   }

   public static Minecraft method_3769() {
      return f$e;
   }

   public static Minecraft method_2933() {
      return f$e;
   }

   public static Minecraft method_2937() {
      return f$e;
   }

   public static Minecraft method_2940() {
      return f$e;
   }

   public static Minecraft method_2944() {
      return f$e;
   }

   public static Minecraft method_3770() {
      return f$e;
   }

   public static Minecraft method_2950() {
      return f$e;
   }

   public static Minecraft method_3771() {
      return f$e;
   }

   public static Minecraft method_3772() {
      return f$e;
   }

   public static Minecraft method_2955() {
      return f$e;
   }

   public static Minecraft method_2957() {
      return f$e;
   }

   public static Minecraft method_2959() {
      return f$e;
   }

   public static Minecraft method_2962() {
      return f$e;
   }

   public static Minecraft method_3773() {
      return f$e;
   }

   public static Minecraft method_3774() {
      return f$e;
   }

   public static Minecraft method_2969() {
      return f$e;
   }

   public static Minecraft method_2971() {
      return f$e;
   }

   public static Minecraft method_2972() {
      return f$e;
   }

   public static Minecraft method_2976() {
      return f$e;
   }

   public static Minecraft method_2982() {
      return f$e;
   }

   public static Minecraft method_3775() {
      return f$e;
   }

   public static Minecraft method_2988() {
      return f$e;
   }

   public static Minecraft method_2992() {
      return f$e;
   }

   public static Minecraft method_3005() {
      return f$e;
   }

   public static Minecraft method_3776() {
      return f$e;
   }

   public static Minecraft method_3011() {
      return f$e;
   }

   public static Minecraft method_3012() {
      return f$e;
   }

   public static Minecraft method_3019() {
      return f$e;
   }

   public static Minecraft method_3020() {
      return f$e;
   }

   public static Minecraft method_3023() {
      return f$e;
   }

   public Va() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoTunnel";
      var10002[1] = "AutoTunneler";
      super("AutoTunnel", var10002, true, -15641289, bE.WORLD);
      this.field_881 = new EG();
      Float var4 = 1.0F;
      Float var5 = 1.0F;
      Float var10005 = 6.0F;
      Integer var10006 = 1;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Width";
      var10007[1] = "TunnelWidth";
      var10007[2] = "W";
      this.field_882 = new U(var4, var5, var10005, var10006, var10007);
      var4 = 2.0F;
      var5 = 1.0F;
      var10005 = 6.0F;
      var10006 = 1;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Height";
      var10007[1] = "TunnelHeight";
      var10007[2] = "H";
      this.field_876 = new U(var4, var5, var10005, var10006, var10007);
      var4 = 0.2F;
      var5 = 0.0F;
      var10005 = 1.0F;
      Double var10 = 5.941588215E-315D;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Delay";
      var10007[1] = "Del";
      var10007[2] = "D";
      this.field_885 = new U(var4, var5, var10005, var10, var10007);
      Ya var6 = Ya.Normal;
      String[] var8 = new String[2];
      boolean var9 = true;
      byte var11 = 1;
      var8[0] = "Mode";
      var8[1] = "Method";
      this.field_878 = new ga(var6, var8);
      Block[] var10001 = new Block[10];
      boolean var3 = true;
      byte var7 = 1;
      var10001[0] = Blocks.AIR;
      var10001[1] = Blocks.WATER;
      var10001[2] = Blocks.FIRE;
      var10001[3] = Blocks.FLOWING_WATER;
      var10001[4] = Blocks.LAVA;
      var10001[5] = Blocks.FLOWING_LAVA;
      var10001[6] = Blocks.PORTAL;
      var10001[7] = Blocks.END_PORTAL;
      var10001[8] = Blocks.END_PORTAL_FRAME;
      var10001[9] = Blocks.BEDROCK;
      this.field_880 = Arrays.asList(var10001);
      t[] var1 = new t[2];
      var3 = true;
      var7 = 1;
      var1[0] = this.field_878;
      var1[1] = this.field_885;
      this.f$c(var1);
      ja[] var2 = new ja[1];
      var3 = true;
      var7 = 1;
      var2[0] = new ya(this);
      this.method_2383(var2);
   }
}

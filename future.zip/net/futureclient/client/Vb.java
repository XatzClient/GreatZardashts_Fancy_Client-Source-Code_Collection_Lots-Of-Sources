package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.item.ItemFishingRod;

public class Vb extends ka {
   private int field_865;
   private int field_866;
   private int field_867;
   private U field_868;
   private boolean field_869;
   private U field_870;
   private t field_871;

   public void method_4314() {
      super.method_4314();
      this.field_865 = 0;
      this.field_866 = 0;
   }

   public static int method_1939(Vb var0) {
      return var0.field_866;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static int method_1942(Vb var0) {
      return var0.field_865--;
   }

   private void method_4050() {
      if (!f$e.player.inventory.getCurrentItem().isEmpty() || f$e.player.inventory.getCurrentItem().getItem() instanceof ItemFishingRod) {
         if (!(Boolean)this.field_871.method_3690()) {
            if (f$e.currentScreen instanceof GuiChat || f$e.currentScreen == null) {
               ((w)f$e).method_3640(lf.RIGHT_CLICK);
               this.field_865 = this.field_868.method_3692().intValue();
               this.field_866 = 0;
               return;
            }
         } else {
            ((w)f$e).method_3640(lf.RIGHT_CLICK);
            this.field_865 = this.field_868.method_3692().intValue();
            this.field_866 = 0;
         }
      }

   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static int method_1946(Vb var0) {
      return var0.field_867;
   }

   public static int method_1947(Vb var0) {
      return var0.field_867--;
   }

   public static boolean method_1948(Vb var0) {
      return var0.field_869;
   }

   public static void method_1949(Vb var0) {
      var0.method_4050();
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static boolean method_1951(Vb var0, boolean var1) {
      return var0.field_869 = var1;
   }

   public static U method_1952(Vb var0) {
      return var0.field_870;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static int method_1955(Vb var0) {
      return var0.field_867++;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static int method_1960(Vb var0) {
      return var0.field_865;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static int method_1967(Vb var0) {
      return var0.field_866++;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public Vb() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoFish";
      var10002[1] = "Fish";
      var10002[2] = "Fishing";
      super("AutoFish", var10002, true, -6732630, bE.MISCELLANEOUS);
      Boolean var3 = true;
      String[] var6 = new String[6];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Open Inventory";
      var6[1] = "OpenInventory";
      var6[2] = "Open";
      var6[3] = "Inv";
      var6[4] = "Inventory";
      var6[5] = "OpenInv";
      this.field_871 = new t(var3, var6);
      Float var4 = 15.0F;
      Float var8 = 10.0F;
      Float var10 = 25.0F;
      Integer var12 = 1;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "CastingDelay";
      var10007[1] = "CastDelay";
      var10007[2] = "CastDel";
      var10007[3] = "cd";
      this.field_868 = new U(var4, var8, var10, var12, var10007);
      Double var5 = 0.0D;
      Double var9 = 0.0D;
      Double var11 = 0.0D;
      Double var13 = 1.273197475E-314D;
      var10007 = new String[6];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "MaxSoundDist";
      var10007[1] = "MaxSoundDistance";
      var10007[2] = "MaxSoundist";
      var10007[3] = "MaxDist";
      var10007[4] = "msd";
      var10007[5] = "md";
      this.field_870 = new U(var5, var9, var11, var13, var10007);
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_871;
      var10001[1] = this.field_868;
      var10001[2] = this.field_870;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var7 = 1;
      var1[0] = new IB(this);
      var1[1] = new DA(this);
      this.method_2383(var1);
   }
}

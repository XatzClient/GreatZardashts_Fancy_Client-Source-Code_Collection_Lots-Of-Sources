package net.futureclient.client;

import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.network.play.server.SPacketPlayerPosLook;

public class Vc extends ja {
   public final qc field_899;

   public Vc(qc var1) {
      this.field_899 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketPlayerPosLook && ((Zb)this.field_899.field_1517.method_3690()).equals(Zb.Packet)) {
         if (qc.method_4319().player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != Items.ELYTRA) {
            return;
         }

         qc.method_3718(this.field_899, true);
      }

   }
}

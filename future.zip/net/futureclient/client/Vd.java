package net.futureclient.client;

import java.util.Random;

public class Vd extends ja {
   public final He field_886;

   public Vd(He var1) {
      this.field_886 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2757((We)var1);
   }

   public void method_2757(We var1) {
      if ((Boolean)He.method_85(this.field_886).method_3690() && He.method_105(this.field_886).method_817(2500L)) {
         Vd var10000;
         if (YH.method_1211().method_1216().method_1481(var1.method_3453()) && !var1.method_3453().equals(He.method_4275().player.getName())) {
            var10000 = this;
            He.method_95(this.field_886, (new StringBuilder()).insert(0, "My friend ").append(var1.method_3453()).append(" just joined the server!").toString());
         } else {
            if (!var1.method_3453().equals(He.method_4277().player.getName()) && He.method_4270().getCurrentServerData() != null) {
               He.method_95(this.field_886, He.method_100(this.field_886)[(new Random()).nextInt(He.method_100(this.field_886).length)].replaceFirst("SERVERIP1D5A9E", He.method_4267().getCurrentServerData().serverIP) + var1.method_3453() + ".");
            }

            var10000 = this;
         }

         He.method_105(var10000.field_886).method_814();
      }

   }
}

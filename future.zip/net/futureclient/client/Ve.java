package net.futureclient.client;

public class Ve extends CD {
   private String field_857;

   public Ve(String var1) {
      this.field_857 = var1;
   }

   public String method_3453() {
      return this.field_857;
   }
}

package net.futureclient.client;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public class Vf extends ja {
   public final Ne field_856;

   public Vf(Ne var1) {
      this.field_856 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   private static boolean method_1920(KD var0, EntityPlayer var1) {
      return !(var1 instanceof EntityPlayerSP) && !var1.getName().equals(Ne.method_4319().player.getName()) && EI.method_886(var1) && (!(Boolean)var0.field_131.method_3690() || !YH.method_1211().method_1216().method_1481(var1.getName()));
   }

   public void method_4183(Xe var1) {
      Ne var10000 = this.field_856;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = Ne.method_523(this.field_856).method_3692();
      var10000.method_616(String.format("AutoLog §7[§F%s§7]", var10002));
      if (Ne.method_4278().player.isEntityAlive()) {
         if ((Boolean)Ne.method_519(this.field_856).method_3690()) {
            KD var2 = (KD)YH.method_1211().method_1205().method_2166(KD.class);
            EntityPlayer var3;
            if ((var3 = (EntityPlayer)Ne.method_4275().world.playerEntities.stream().filter(var2.test<invokedynamic>(var2)).findFirst().orElse((Object)null)) != null) {
               Ne.method_521(this.field_856, (new StringBuilder()).insert(0, "[AutoLog] ").append(var3.getName()).append(" came into render distance.").toString());
               return;
            }
         }

         ge var4;
         if ((var4 = (ge)YH.method_1211().method_1205().method_2166(ge.class)) != null && Ne.method_4273().world.isBlockLoaded(new BlockPos(Ne.method_4277().player.lastTickPosX, Ne.method_4270().player.lastTickPosY, Ne.method_4267().player.lastTickPosZ), false) && Ne.method_4281().world.isBlockLoaded(new BlockPos(Ne.method_4276().player.posX, Ne.method_4274().player.posY, Ne.method_4245().player.posZ), false)) {
            int var5 = var4.method_4078();
            if ((Boolean)Ne.method_520(this.field_856).method_3690() && var5 <= 0) {
               Ne.method_521(this.field_856, (new StringBuilder()).insert(0, "[AutoLog] Logged out with ").append(var5).append(" totems and ").append(Ne.method_4242().player.getHealth()).append(" hearts remaining.").toString());
               return;
            }

            if (var4.f$c() && var5 > 0) {
               return;
            }
         }

         if (Ne.method_4269().player.getHealth() <= Ne.method_523(this.field_856).method_3692().floatValue()) {
            Ne.method_521(this.field_856, (new StringBuilder()).insert(0, "[AutoLog] Logged out with ").append(Ne.method_4315().player.getHealth()).append(" hearts remaining.").toString());
         }

      }
   }
}

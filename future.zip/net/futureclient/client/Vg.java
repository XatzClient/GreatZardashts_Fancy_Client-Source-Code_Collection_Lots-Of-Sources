package net.futureclient.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Scanner;

public class Vg {
   private static String field_864 = System.getProperty("os.name").toUpperCase();

   private static String method_1932() {
      String var10000 = field_864;
      String var10001 = "WIN";

      IOException var8;
      label51: {
         Process var0;
         Scanner var1;
         String var7;
         boolean var9;
         try {
            if (var10000.contains(var10001)) {
               (var0 = Runtime.getRuntime().exec("wmic baseboard get product,Manufacturer,version,serialnumber")).getOutputStream().close();
               (var1 = new Scanner(var0.getInputStream())).nextLine();
               var1.nextLine();
               var7 = var1.nextLine();
               var1.close();
               return var7;
            }
         } catch (IOException var5) {
            var8 = var5;
            var9 = false;
            break label51;
         }

         var10000 = field_864;
         var10001 = "MAC";

         try {
            if (!var10000.contains(var10001)) {
               return "Error";
            }

            (var0 = Runtime.getRuntime().exec("system_profiler SPHardwareDataType")).getOutputStream().close();
            var1 = new Scanner(var0.getInputStream());
            int var2;
            int var10 = var2 = 1;

            while(true) {
               boolean var10002 = true;
               byte var10003 = 1;
               if (var10 > 16) {
                  break;
               }

               var1.nextLine();
               var10003 = 1;
               byte var10004 = 1;
               ++var2;
               var10 = var2;
            }
         } catch (IOException var4) {
            var8 = var4;
            var9 = false;
            break label51;
         }

         Scanner var11 = var1;
         Scanner var12 = var1;

         try {
            var7 = var12.nextLine();
            var11.close();
            return var7;
         } catch (IOException var3) {
            var8 = var3;
            var9 = false;
         }
      }

      IOException var6 = var8;
      var6.printStackTrace();
      return "Error";
   }

   private static String method_1933() {
      String var10000 = field_864;
      String var10001 = "WIN";

      Exception var8;
      label51: {
         Process var0;
         Scanner var1;
         String var7;
         boolean var9;
         try {
            if (var10000.contains(var10001)) {
               (var0 = Runtime.getRuntime().exec("wmic path Win32_VideoController get Description,PNPDeviceID")).getOutputStream().close();
               (var1 = new Scanner(var0.getInputStream())).nextLine();
               var1.nextLine();
               var7 = var1.nextLine();
               var1.close();
               return var7;
            }
         } catch (Exception var5) {
            var8 = var5;
            var9 = false;
            break label51;
         }

         var10000 = field_864;
         var10001 = "MAC";

         try {
            if (!var10000.contains(var10001)) {
               return "Error";
            }

            (var0 = Runtime.getRuntime().exec("system_profiler SPDisplaysDataType")).getOutputStream().close();
            var1 = new Scanner(var0.getInputStream());
            int var2;
            int var10 = var2 = 1;

            while(true) {
               boolean var10002 = true;
               byte var10003 = 1;
               if (var10 > 4) {
                  break;
               }

               var1.nextLine();
               var10003 = 1;
               byte var10004 = 1;
               ++var2;
               var10 = var2;
            }
         } catch (Exception var4) {
            var8 = var4;
            var9 = false;
            break label51;
         }

         Scanner var11 = var1;
         Scanner var12 = var1;

         try {
            var7 = var12.nextLine();
            var11.close();
            return var7;
         } catch (Exception var3) {
            var8 = var3;
            var9 = false;
         }
      }

      Exception var6 = var8;
      var6.printStackTrace();
      return "Error";
   }

   private static String method_1934() {
      String var10000 = field_864;
      String var10001 = "WIN";

      try {
         if (var10000.contains(var10001)) {
            Runtime var4 = Runtime.getRuntime();
            boolean var10002 = true;
            byte var10003 = 1;
            String[] var5 = new String[4];
            var10002 = true;
            var10003 = 1;
            boolean var10004 = true;
            byte var10005 = 1;
            var5[0] = "wmic";
            byte var7 = 1;
            var10005 = 1;
            var5[1] = "csproduct";
            var10004 = true;
            var10005 = 1;
            var5[2] = "get";
            var10004 = true;
            var10005 = 1;
            var5[3] = "uuid";
            Process var0;
            (var0 = var4.exec(var5)).getOutputStream().close();
            Scanner var1;
            (var1 = new Scanner(var0.getInputStream())).nextLine();
            var1.nextLine();
            Scanner var6 = var1;
            String var3 = var1.nextLine();
            var6.close();
            return var3;
         }
      } catch (Exception var2) {
         var2.printStackTrace();
      }

      return "Error";
   }

   public static String method_1935() {
      boolean var10001 = true;
      byte var10002 = 1;
      String[] var10000 = new String[7];
      var10001 = true;
      var10002 = 1;
      boolean var10003 = true;
      byte var10004 = 1;
      var10000[0] = System.getenv("PROCESSOR_IDENTIFIER");
      byte var12 = 1;
      var10004 = 1;
      var10000[1] = System.getenv("NUMBER_OF_PROCESSORS");
      var10003 = true;
      var10004 = 1;
      var10000[2] = method_1932();
      var10003 = true;
      var10004 = 1;
      var10000[3] = method_1933();
      var10003 = true;
      var10004 = 1;
      var10000[4] = method_1934();
      var10003 = true;
      var10004 = 1;
      var10000[5] = method_1937();
      var10003 = true;
      var10004 = 1;
      var10000[6] = method_1936();
      String[] var0 = var10000;
      StringBuilder var1 = new StringBuilder();
      String[] var2 = var0;
      int var3 = var0.length;
      int var8 = 0;
      var10001 = true;
      var10002 = 1;

      for(int var4 = 0; var8 < var3; var8 = var4) {
         String var5 = var2[var4];
         var1.append(var5);
         if (var1.toString().contains("VMware")) {
            var10003 = true;
            var10004 = 1;
            Fi.method_1103("Error!", "Virtual machine detected! You may not run Future on a virtual computer", 0);
            String var9 = "java.lang.Shutdown";

            try {
               Class var10 = Class.forName(var9);
               var12 = 1;
               var10004 = 1;
               Class[] var11 = new Class[1];
               var10003 = true;
               var10004 = 1;
               boolean var10005 = true;
               byte var10006 = 1;
               var11[0] = Integer.TYPE;
               Method var6 = var10.getDeclaredMethod("exit", var11);
               var10004 = 1;
               byte var14 = 1;
               var6.setAccessible(true);
               var12 = 1;
               var10004 = 1;
               Object[] var13 = new Object[1];
               var10003 = true;
               var10004 = 1;
               var10005 = true;
               var10006 = 1;
               boolean var15 = true;
               byte var10007 = 1;
               var13[0] = 0;
               var6.invoke((Object)null, var13);
            } catch (Exception var7) {
               throw new RuntimeException("Failed to load! Please post on the forums with the error code \"0x38F\" to get help.");
            }
         }

         ++var4;
      }

      return var1.toString();
   }

   private static String method_1936() {
      String var10000 = field_864;
      String var10001 = "WIN";

      Exception var10;
      label60: {
         StringBuilder var3;
         boolean var11;
         byte var10003;
         byte var10004;
         label61: {
            Process var0;
            String var9;
            boolean var10002;
            try {
               if (var10000.contains(var10001)) {
                  Runtime var13 = Runtime.getRuntime();
                  var10002 = true;
                  var10003 = 1;
                  String[] var14 = new String[4];
                  var10002 = true;
                  var10003 = 1;
                  boolean var19 = true;
                  byte var10005 = 1;
                  var14[0] = "wmic";
                  var10004 = 1;
                  var10005 = 1;
                  var14[1] = "memorychip";
                  var19 = true;
                  var10005 = 1;
                  var14[2] = "get";
                  var19 = true;
                  var10005 = 1;
                  var14[3] = "serialnumber";
                  (var0 = var13.exec(var14)).waitFor();
                  BufferedReader var8 = new BufferedReader(new InputStreamReader(var0.getInputStream()));
                  var3 = new StringBuilder();
                  BufferedReader var15 = var8;

                  while(true) {
                     if ((var9 = var15.readLine()) == null) {
                        break label61;
                     }

                     var15 = var8;
                     var3.append(var9);
                  }
               }
            } catch (Exception var6) {
               var10 = var6;
               var11 = false;
               break label60;
            }

            var10000 = field_864;
            var10001 = "MAC";

            try {
               if (var10000.contains(var10001)) {
                  (var0 = Runtime.getRuntime().exec("system_profiler SPMemoryDataType")).getOutputStream().close();
                  Scanner var1 = new Scanner(var0.getInputStream());
                  int var2;
                  int var12 = var2 = 1;

                  while(true) {
                     var10002 = true;
                     var10003 = 1;
                     if (var12 > 9) {
                        var9 = var1.nextLine();
                        var1.close();
                        return var9;
                     }

                     var1.nextLine();
                     var10003 = 1;
                     var10004 = 1;
                     ++var2;
                     var12 = var2;
                  }
               }

               return "Error";
            } catch (Exception var5) {
               var10 = var5;
               var11 = false;
               break label60;
            }
         }

         StringBuilder var17 = var3;
         StringBuilder var16 = var3;

         try {
            int var18 = var16.toString().lastIndexOf("r");
            var10003 = 1;
            var10004 = 1;
            return var17.substring(var18 + 1).trim();
         } catch (Exception var4) {
            var10 = var4;
            var11 = false;
         }
      }

      Exception var7 = var10;
      var7.printStackTrace();
      return "Error";
   }

   private static String method_1937() {
      String var10000 = field_864;
      String var10001 = "WIN";

      Exception var18;
      label92: {
         Scanner var11;
         HashMap var16;
         boolean var19;
         label93: {
            Process var8;
            boolean var10003;
            byte var10004;
            boolean var22;
            int var23;
            byte var24;
            try {
               if (var10000.contains(var10001)) {
                  (var8 = Runtime.getRuntime().exec("wmic volume get driveletter,serialnumber")).getOutputStream().close();
                  (var11 = new Scanner(var8.getInputStream())).nextLine();
                  var16 = new HashMap();

                  while(true) {
                     if (!var11.hasNext()) {
                        break label93;
                     }

                     String[] var14;
                     var23 = (var14 = var11.nextLine().replaceAll(" ", "").split(":")).length;
                     var22 = true;
                     var24 = 1;
                     if (var23 == 2) {
                        var10003 = true;
                        var10004 = 1;
                        var10001 = var14[0].toLowerCase();
                        var10004 = 1;
                        byte var10005 = 1;
                        var16.put(var10001, var14[1]);
                     }
                  }
               }
            } catch (Exception var7) {
               var18 = var7;
               var19 = false;
               break label92;
            }

            var10000 = field_864;
            var10001 = "MAC";

            try {
               if (var10000.contains(var10001)) {
                  (var8 = Runtime.getRuntime().exec("system_profiler SPSerialATADataType")).getOutputStream().close();
                  var11 = new Scanner(var8.getInputStream());
                  int var13;
                  var23 = var13 = 1;

                  while(true) {
                     var22 = true;
                     var24 = 1;
                     if (var23 > 16) {
                        String var15 = var11.nextLine();
                        var11.close();
                        return var15;
                     }

                     var11.nextLine();
                     var24 = 1;
                     var10004 = 1;
                     ++var13;
                     var23 = var13;
                  }
               }
            } catch (Exception var6) {
               var18 = var6;
               var19 = false;
               break label92;
            }

            var10000 = field_864;
            var10001 = "LINUX";

            try {
               if (var10000.contains(var10001)) {
                  String var0 = "/sbin/udevadm info --query=property --name=sda";
                  var19 = true;
                  byte var10002 = 1;
                  String[] var20 = new String[3];
                  var19 = true;
                  var10002 = 1;
                  var10003 = true;
                  var10004 = 1;
                  var20[0] = "/bin/sh";
                  var24 = 1;
                  var10004 = 1;
                  var20[1] = "-c";
                  var10003 = true;
                  var10004 = 1;
                  var20[2] = var0;
                  String[] var1 = var20;
                  Process var2;
                  (var2 = Runtime.getRuntime().exec(var1)).waitFor();
                  BufferedReader var3 = new BufferedReader(new InputStreamReader(var2.getInputStream()));
                  StringBuilder var12 = new StringBuilder();

                  label58:
                  while(true) {
                     BufferedReader var21 = var3;

                     String var10;
                     while((var10 = var21.readLine()) != null) {
                        if (!var10.contains("ID_SERIAL_SHORT")) {
                           continue label58;
                        }

                        var21 = var3;
                        var12.append(var10);
                     }

                     var10000 = var12.toString();
                     int var25 = var12.toString().indexOf("=");
                     var24 = 1;
                     var10004 = 1;
                     return var10000.substring(var25 + 1);
                  }
               }

               return "Error";
            } catch (Exception var5) {
               var18 = var5;
               var19 = false;
               break label92;
            }
         }

         Scanner var26 = var11;

         try {
            var26.close();
            String var17;
            if ((var17 = (String)var16.get("c")) != null) {
               return var17;
            }

            return "";
         } catch (Exception var4) {
            var18 = var4;
            var19 = false;
         }
      }

      Exception var9 = var18;
      var9.printStackTrace();
      return "Error";
   }
}

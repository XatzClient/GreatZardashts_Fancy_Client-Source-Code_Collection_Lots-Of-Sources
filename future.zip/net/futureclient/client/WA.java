package net.futureclient.client;

public enum WA {
   Rider,
   None;

   private static final WA[] field_741;
   Friend;

   static {
      WA[] var10000 = new WA[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = None;
      var10000[1] = Rider;
      var10000[2] = Friend;
      field_741 = var10000;
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class WB extends ka {
   private ga field_873;
   private ItemStack field_874;
   private EG field_875;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static EG method_1978(WB var0) {
      return var0.field_875;
   }

   public static ItemStack method_1979(WB var0) {
      return var0.field_874;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static ga method_1981(WB var0) {
      return var0.field_873;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public WB() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NoFall";
      var10002[1] = "0fall";
      var10002[2] = "nf";
      super("NoFall", var10002, true, -12727218, bE.MOVEMENT);
      FB var3 = FB.Packet;
      String[] var5 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Mode";
      var5[1] = "Mod";
      var5[2] = "Type";
      var5[3] = "Method";
      this.field_873 = new ga(var3, var5);
      this.field_874 = new ItemStack(Items.WATER_BUCKET);
      this.field_875 = new EG();
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_873;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var4 = 1;
      var1[0] = new Tc(this);
      var1[1] = new Ld(this);
      this.method_2383(var1);
   }
}

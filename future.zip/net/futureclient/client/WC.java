package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class WC extends ja {
   public final xC field_872;

   public WC(xC var1) {
      this.field_872 = var1;
   }

   public void method_4312(CD var1) {
      this.method_3707((Ve)var1);
   }

   public void method_3707(Ve var1) {
      if ((Boolean)xC.method_4251(this.field_872).method_3690()) {
         Iterator var2 = xC.method_4275().world.playerEntities.iterator();

         while(var2.hasNext()) {
            EntityPlayer var3;
            if ((var3 = (EntityPlayer)((Entity)var2.next())).getName().equals(var1.method_3453())) {
               String var4 = "";
               if (xC.method_4277().isSingleplayer()) {
                  var4 = "singleplayer";
               } else if (xC.method_4270().getCurrentServerData() != null) {
                  var4 = xC.method_4267().getCurrentServerData().serverIP.replaceAll(":", "_");
               } else if (xC.method_4273().isConnectedToRealms()) {
                  var4 = "realms";
               }

               xa var5 = new xa((new StringBuilder()).insert(0, var3.getName()).append("_logout_spot").toString(), var4, Double.parseDouble(xC.method_4253(this.field_872).format(var3.posX).replaceAll(",", ".")), Double.parseDouble(xC.method_4253(this.field_872).format(var3.posY).replaceAll(",", ".")), Double.parseDouble(xC.method_4253(this.field_872).format(var3.posZ).replaceAll(",", ".")), xC.method_4276().world.provider.getDimensionType().getName());
               if (!xC.method_4258(this.field_872, var5)) {
                  this.field_872.field_1866.add(var5);
               }
            }
         }
      }

   }
}

package net.futureclient.client;

public class WD extends CD {
   private float field_887;
   private float field_888;
   private float field_889;
   private float field_890;
   private float field_891;
   private float field_892;
   private float field_893;
   private float field_894;
   private float field_895;
   private float field_896;
   private float field_897;
   private float field_898;

   public WD(float var1, float var2, float var3, float var4, float var5, float var6) {
      this.field_895 = this.field_890 = var1;
      this.field_897 = this.field_892 = var2;
      this.field_898 = this.field_887 = var3;
      this.field_893 = this.field_896 = var4;
      this.field_889 = this.field_894 = var5;
      this.field_891 = this.field_888 = var6;
   }

   public float method_2177() {
      return this.field_887;
   }

   public void method_2092(float var1) {
      this.field_898 = var1;
   }

   public void method_2093(float var1) {
      this.field_895 = var1;
   }

   public float method_2178() {
      return this.field_890;
   }

   public float method_2179() {
      return this.field_894;
   }

   public void method_2096(float var1) {
      this.field_889 = var1;
   }

   public float method_3117() {
      return this.field_888;
   }

   public void method_3094(float var1) {
      this.field_891 = var1;
   }

   public float method_2099() {
      return this.field_898;
   }

   public void method_2100(float var1) {
      this.field_893 = var1;
   }

   public float method_2181() {
      return this.field_896;
   }

   public float method_2102() {
      return this.field_897;
   }

   public float method_2103() {
      return this.field_893;
   }

   public float method_2104() {
      return this.field_891;
   }

   public float method_2105() {
      return this.field_889;
   }

   public float method_2106() {
      return this.field_895;
   }

   public float method_2182() {
      return this.field_892;
   }

   public void method_2108(float var1) {
      this.field_897 = var1;
   }
}

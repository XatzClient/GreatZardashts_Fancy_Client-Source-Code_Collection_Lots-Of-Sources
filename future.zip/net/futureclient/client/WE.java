package net.futureclient.client;

public abstract class WE {
   public static String method_2088(String var0) {
      StackTraceElement var10003 = (new RuntimeException()).getStackTrace()[1];
      String var10000 = var10003.getMethodName() + var10003.getClassName();
      int var10001 = var10000.length() - 1;
      float var10 = 1.0F;
      boolean var11 = true;
      boolean var10004 = true;
      byte var12 = 32;
      var10004 = true;
      var10004 = true;
      boolean var10005 = true;
      byte var14 = 6;
      var10005 = true;
      var14 = 96;
      var10005 = true;
      boolean var10006 = true;
      byte var15 = 10;
      var10005 = true;
      var10006 = true;
      var15 = 6;
      var10006 = true;
      var15 = 48;
      var10006 = true;
      int var16 = (var0 = (String)var0).length();
      char[] var10007 = new char[var16];
      boolean var10008 = true;
      byte var10009 = 1;
      int var1;
      int var17 = var1 = var16 - 1;
      char[] var3 = var10007;
      byte var7 = 50;
      var14 = 36;
      byte var4 = 106;
      var10 = 2.0F;
      int var2;
      int var5 = var2 = var10001;
      int var8 = var17;

      for(String var6 = var10000; var8 >= 0; var8 = var1) {
         int var13 = var1--;
         var3[var13] = (char)(var4 ^ var0.charAt(var13) ^ var6.charAt(var2));
         if (var1 < 0) {
            break;
         }

         var10001 = var1;
         char var10002 = (char)(var7 ^ var0.charAt(var1) ^ var6.charAt(var2));
         --var1;
         --var2;
         var3[var10001] = var10002;
         if (var2 < 0) {
            var2 = var5;
         }
      }

      return new String(var3);
   }

   public abstract void method_670();
}

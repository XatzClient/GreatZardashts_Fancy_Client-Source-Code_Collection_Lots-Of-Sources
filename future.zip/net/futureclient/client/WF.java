package net.futureclient.client;

public class WF extends CD {
   private float field_858;
   private float field_859;
   private Dg field_860;
   private boolean field_861;
   private float field_862;
   private float field_863;

   public WF(Dg var1, float var2, float var3, boolean var4) {
      this.field_860 = var1;
      this.field_862 = this.field_858 = var2;
      this.field_863 = this.field_859 = var3;
      this.field_861 = var4;
   }

   public float method_2177() {
      return this.field_862;
   }

   public void method_3481(boolean var1) {
      this.field_861 = var1;
   }

   public float method_2179() {
      return this.field_858;
   }

   public void method_2096(float var1) {
      this.field_862 = var1;
   }

   public boolean method_3480() {
      return this.field_861;
   }

   public void method_3094(float var1) {
      this.field_863 = var1;
   }

   public Dg method_1929() {
      return this.field_860;
   }

   public float method_3117() {
      return this.field_859;
   }

   public float method_2181() {
      return this.field_863;
   }
}

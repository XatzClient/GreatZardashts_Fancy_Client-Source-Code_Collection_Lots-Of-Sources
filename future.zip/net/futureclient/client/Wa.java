package net.futureclient.client;

public class Wa implements C {
   public float field_848;
   private String field_849;
   public int field_850;
   public int field_851;
   public int field_852;
   public float field_853;
   public int field_854;

   public Wa(String var1) {
      this.field_849 = var1;
   }

   public int method_1909() {
      return this.field_850;
   }

   public void method_3982(int var1, int var2, int var3) {
   }

   public float method_1910() {
      return this.field_853;
   }

   public void method_1911(int var1) {
      this.field_850 = var1;
   }

   public void method_1912(float var1, float var2) {
      this.field_853 = var1;
      this.field_848 = var2;
   }

   public float method_1913() {
      return this.field_848;
   }

   public String method_1914() {
      return this.field_849;
   }

   public void method_1915(int var1, int var2, int var3) {
   }

   public void method_3986(int var1, int var2, float var3) {
   }

   public void method_1916(int var1) {
      this.field_854 = var1;
   }

   public int method_2414() {
      return this.field_854;
   }
}

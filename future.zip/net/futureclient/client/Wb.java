package net.futureclient.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

public class Wb extends ka {
   private t field_836;
   private ci field_837;
   private U field_838;
   private U field_839;
   private List field_840;
   private final EG field_841;

   public static Minecraft method_4242() {
      return f$e;
   }

   public void method_4314() {
      super.method_4314();
      this.field_837 = null;
      this.field_840.clear();
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static U method_1888(Wb var0) {
      return var0.field_839;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static ci method_1891(Wb var0, ci var1) {
      return var0.field_837 = var1;
   }

   public static ci method_1892(Wb var0) {
      return var0.field_837;
   }

   public static EG method_1893(Wb var0) {
      return var0.field_841;
   }

   public static U method_1894(Wb var0) {
      return var0.field_838;
   }

   public static List method_1895(Wb var0) {
      return var0.field_840;
   }

   public static t method_1896(Wb var0) {
      return var0.field_836;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public Wb() {
      String[] var10002 = new String[5];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "BreadCrumbs";
      var10002[1] = "BreadMan";
      var10002[2] = "BreadManCrumbs";
      var10002[3] = "Breads";
      var10002[4] = "BreadyCrumbs";
      super("BreadCrumbs", var10002, true, -15011266, bE.RENDER);
      Boolean var3 = true;
      String[] var5 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Render";
      var5[1] = "Draw";
      var5[2] = "r";
      this.field_836 = new t(var3, var5);
      Float var4 = 0.0F;
      Float var7 = 0.0F;
      Float var8 = 10.0F;
      Double var9 = 1.273197475E-314D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Delay";
      var10007[1] = "Del";
      var10007[2] = "d";
      this.field_839 = new U(var4, var7, var8, var9, var10007);
      var4 = 1.6F;
      var7 = 0.1F;
      var8 = 10.0F;
      var9 = 1.273197475E-314D;
      var10007 = new String[4];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Width";
      var10007[1] = "With";
      var10007[2] = "Radius";
      var10007[3] = "raidus";
      this.field_838 = new U(var4, var7, var8, var9, var10007);
      this.field_840 = new ArrayList();
      this.field_841 = new EG();
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_836;
      var10001[1] = this.field_838;
      var10001[2] = this.field_839;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var6 = 1;
      var1[0] = new AA(this);
      var1[1] = new vc(this);
      this.method_2383(var1);
   }
}

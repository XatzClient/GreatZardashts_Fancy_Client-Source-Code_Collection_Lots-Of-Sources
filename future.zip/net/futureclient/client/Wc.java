package net.futureclient.client;

public class Wc extends ja {
   public final GB field_835;

   public Wc(GB var1) {
      this.field_835 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (GB.method_4315().player.getHealth() <= 0.0F) {
         GB.method_4319().player.respawnPlayer();
      }

   }
}

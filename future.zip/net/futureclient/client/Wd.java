package net.futureclient.client;

public class Wd extends CD {
}

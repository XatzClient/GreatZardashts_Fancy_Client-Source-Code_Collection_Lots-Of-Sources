package net.futureclient.client;

public class We extends CD {
   private String field_846;

   public We(String var1) {
      this.field_846 = var1;
   }

   public String method_3453() {
      return this.field_846;
   }
}

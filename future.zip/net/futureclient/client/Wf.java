package net.futureclient.client;

import net.minecraft.entity.Entity;

public class Wf extends CD {
   private int field_833 = -1;
   private Entity field_834;

   public Wf(Entity var1) {
      this.field_834 = var1;
   }

   public void method_2353(int var1) {
      this.field_833 = var1;
   }

   public int method_3981() {
      return this.field_833;
   }

   public Entity method_2798() {
      return this.field_834;
   }
}

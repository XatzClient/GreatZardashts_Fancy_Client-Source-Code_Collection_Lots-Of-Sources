package net.futureclient.client;

import com.google.common.io.ByteArrayDataOutput;
import java.io.DataInputStream;
import java.io.IOException;

public class Wg extends Oi {
   private String field_826;
   private String field_827 = "";
   public boolean field_828;
   private String field_829;
   private String field_830;

   public Wg() {
      boolean var10002 = true;
      byte var10003 = 1;
      this.field_828 = false;
   }

   public Wg(String var1, String var2, String var3) {
      boolean var10008 = true;
      byte var10009 = 1;
      this.field_828 = false;
      this.field_826 = var1;
      this.field_829 = var2;
      this.field_830 = var3;
   }

   public int method_1871() {
      boolean var10001 = true;
      byte var10002 = 1;
      return 3;
   }

   public String method_1872() {
      return this.field_827;
   }

   public void method_1873(ByteArrayDataOutput var1) throws IOException {
      var1.writeUTF(this.field_826);
      var1.writeUTF(this.field_829);
      var1.writeUTF(this.field_830);
   }

   public void method_1874(DataInputStream var1) throws IOException {
      this.field_828 = var1.readBoolean();
      this.field_827 = var1.readUTF();
   }
}

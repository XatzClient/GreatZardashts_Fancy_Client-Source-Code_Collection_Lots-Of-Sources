package net.futureclient.client;

public final class Wi extends xb {
   public String method_4224() {
      return "&e[username|alias]";
   }

   public Wi() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Remove";
      var10001[1] = "rem";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length == 1) {
         String var2 = var1[0];
         if (!YH.method_1211().method_1216().method_1481(var2)) {
            return "That user is not a friend.";
         } else {
            Bg var4;
            String var3 = (var4 = YH.method_1211().method_1216().method_1482(var2)).method_756();
            YH.method_1211().method_1216().method_3042(var4);
            Object[] var10001 = new Object[1];
            boolean var10002 = true;
            byte var10003 = 1;
            var10001[0] = var3;
            return String.format("Removed friend with alias %s.", var10001);
         }
      } else {
         return null;
      }
   }
}

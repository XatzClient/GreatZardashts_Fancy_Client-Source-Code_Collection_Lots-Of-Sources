package net.futureclient.client;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.BlockPos;

public class XA extends ja {
   public final bB field_855;

   public XA(bB var1) {
      this.field_855 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      bB var10000 = this.field_855;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = bB.method_2818(this.field_855).method_3690();
      var10000.f$D(String.format("Jesus §7[§F%s§7]", var10002));
      if (!bB.method_4299().player.isDead && !bB.method_4297().player.isSneaking() && bB.method_2814(this.field_855).method_817(800L)) {
         Lf var4;
         switch(Xc.f$e[((Qd)bB.method_2818(this.field_855).method_3690()).ordinal()]) {
         case 1:
            boolean var5 = fI.f$c();
            boolean var10001 = false;
            if (var5 && bB.method_4285().player.fallDistance < 3.0F && !bB.method_4284().player.isSneaking()) {
               bB.method_4286().player.motionY = 1.273197475E-314D;
               return;
            }

            return;
         case 2:
            if (var1.method_326() == HD.PRE) {
               if (fI.f$c(false) && !bB.method_4293().player.isSneaking()) {
                  bB.method_4287().player.onGround = false;
               }

               Block var2 = bB.method_4290().world.getBlockState(new BlockPos((int)Math.floor(bB.method_4250().player.posX), (int)Math.floor(bB.method_4295().player.posY), (int)Math.floor(bB.method_4282().player.posZ))).getBlock();
               if (bB.method_2816(this.field_855) && !bB.method_4272().player.capabilities.isFlying && !bB.method_4244().player.isInWater()) {
                  if (bB.method_4289().player.motionY < 4.24399158E-315D || bB.method_4283().player.onGround || bB.method_4243().player.isOnLadder()) {
                     bB.method_2817(this.field_855, false);
                     return;
                  }

                  bB.method_4280().player.motionY = bB.method_4279().player.motionY / 0.0D + 5.941588215E-315D;
                  EntityPlayerSP var3 = bB.method_4271().player;
                  var3.motionY -= 1.1815343767E-314D;
               }

               if (bB.method_4278().player.isInWater() || bB.method_4275().player.isInLava()) {
                  bB.method_4277().player.motionY = 1.273197475E-314D;
                  var4 = var1;
                  break;
               } else if (!bB.method_4270().player.isInLava() && var2 instanceof BlockLiquid && bB.method_4267().player.motionY < 1.273197475E-314D) {
                  bB.method_4273().player.motionY = 0.0D;
                  bB.method_2817(this.field_855, true);
               }
            }
         case 3:
            var4 = var1;
            break;
         default:
            return;
         }

         if (var4.method_326() == HD.PRE && !fI.f$c() && fI.f$c(true) && !fI.f$D() && bB.method_4276().player.ticksExisted % 2 == 0) {
            var1.method_4038(var1.method_1730() + 5.941588215E-315D);
         }

      }
   }
}

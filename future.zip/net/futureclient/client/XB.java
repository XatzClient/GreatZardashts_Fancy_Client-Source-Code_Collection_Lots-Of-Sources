package net.futureclient.client;

public class XB extends ja {
   public final rA field_847;

   public XB(rA var1) {
      this.field_847 = var1;
   }

   public void method_4312(CD var1) {
      this.method_1908((ZD)var1);
   }

   public void method_1908(ZD var1) {
      var1.f$c(true);
   }
}

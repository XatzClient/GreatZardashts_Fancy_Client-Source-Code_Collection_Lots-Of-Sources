package net.futureclient.client;

public enum XC {
   Outline;

   private static final XC[] field_843;
   Shader,
   CsGo;

   static {
      XC[] var10000 = new XC[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Shader;
      var10000[1] = Outline;
      var10000[2] = CsGo;
      field_843 = var10000;
   }
}

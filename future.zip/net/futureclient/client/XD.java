package net.futureclient.client;

import net.minecraft.util.MovementInput;

public class XD extends VE {
   public XD(MovementInput var1) {
      super(var1);
   }
}

package net.futureclient.client;

public class XE extends CD {
}

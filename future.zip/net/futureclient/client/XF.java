package net.futureclient.client;

public final class XF extends Wd {
}

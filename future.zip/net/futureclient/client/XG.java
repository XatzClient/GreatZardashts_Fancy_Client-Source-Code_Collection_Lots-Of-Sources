package net.futureclient.client;

public final class XG {
   public static void method_1880(Throwable var0) throws Throwable {
      throw var0;
   }
}

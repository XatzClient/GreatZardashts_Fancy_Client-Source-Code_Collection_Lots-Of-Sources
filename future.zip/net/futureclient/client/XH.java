package net.futureclient.client;

public class XH {
   private String field_831;
   private double field_832;

   public XH(String var1, double var2) {
      this.field_831 = var1;
      this.field_832 = var2;
   }

   public boolean equals(Object var1) {
      if (var1 != null && var1.getClass() == this.getClass()) {
         XH var2 = (XH)var1;
         return this.field_831.equals(var2.field_831) && this.field_832 == var2.field_832;
      } else {
         return false;
      }
   }

   public int hashCode() {
      byte var1 = 11;
      int var2 = 23 * var1 + this.field_831.hashCode();
      return 23 * var2 + (int)(this.field_832 * 0.0D);
   }

   public double method_1875() {
      return this.field_832;
   }

   public String method_1876() {
      return this.field_831;
   }
}

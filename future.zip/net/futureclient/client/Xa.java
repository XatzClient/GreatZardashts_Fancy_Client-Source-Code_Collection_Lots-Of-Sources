package net.futureclient.client;

import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class Xa extends ja {
   public final Qa field_825;

   public Xa(Qa var1) {
      this.field_825 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      Qa var10000 = this.field_825;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = Qa.method_1437(this.field_825).method_3690();
      var10000.f$D(String.format("Nuker §7[§F%s§7]", var10002));
      int var2;
      int var4;
      int var5;
      int var13;
      switch(ha.f$e[((Ga)Qa.method_1437(this.field_825).method_3690()).ordinal()]) {
      case 1:
      case 2:
      case 3:
         boolean var10001 = false;
         switch(ha.f$G[var1.method_326().ordinal()]) {
         case 1:
            var10001 = false;
            Qa.method_1439(this.field_825, false);
            byte var9 = (byte)(var2 = Qa.method_1432(this.field_825).method_3692().intValue());

            for(var13 = var2; var13 >= -var9; var13 = var2) {
               for(var13 = var4 = -var9; var13 < var9; var13 = var4) {
                  for(var13 = var5 = -var9; var13 < var9; var13 = var5) {
                     Qa.method_1434(this.field_825, new BlockPos((int)Math.floor(Qa.method_4283().player.posX) + var4, (int)Math.floor(Qa.method_4243().player.posY) + var2, (int)Math.floor(Qa.method_4280().player.posZ) + var5));
                     if (Qa.method_4275().player.getDistanceSq(Qa.method_4279().player.posX + (double)var4, Qa.method_4271().player.posY + (double)var2, Qa.method_4278().player.posZ + (double)var5) <= 0.0D) {
                        IBlockState var10;
                        Block var11 = (var10 = Qa.method_4277().world.getBlockState(Qa.method_1428(this.field_825))).getBlock();
                        if (Qa.method_1431(this.field_825, var10, var11)) {
                           Qa.method_1439(this.field_825, true);
                           if (!(Boolean)Qa.method_1426(this.field_825).method_3690()) {
                              return;
                           }

                           float[] var12;
                           float[] var14 = var12 = ri.method_3668(Qa.method_1428(this.field_825), fI.f$c(Qa.method_1428(this.field_825)));
                           var1.method_2096(var12[0]);
                           var1.method_3094(var14[1]);
                           return;
                        }
                     }

                     ++var5;
                  }

                  ++var4;
               }

               --var2;
            }

            return;
         case 2:
            if (!Qa.method_1430(this.field_825)) {
               return;
            }

            Qa.method_4270().player.swingArm(EnumHand.MAIN_HAND);
            Qa.method_4267().playerController.onPlayerDamageBlock(Qa.method_1428(this.field_825), fI.f$c(Qa.method_1428(this.field_825)));
            if ((double)((l)Qa.method_4273().playerController).getCurBlockDamageMP() < 1.0D) {
               return;
            }

            Qa.method_1427(this.field_825).method_814();
         default:
            return;
         }
      case 4:
         if (var1.method_326() == HD.POST && Qa.method_4276().player.isCreative()) {
            for(var13 = var2 = -Qa.method_1432(this.field_825).method_3692().intValue(); var13 <= Qa.method_1432(this.field_825).method_3692().intValue(); var13 = var2) {
               int var3;
               for(var13 = var3 = Qa.method_1432(this.field_825).method_3692().intValue(); var13 >= -Qa.method_1432(this.field_825).method_3692().intValue(); var13 = var3) {
                  for(var13 = var4 = -Qa.method_1432(this.field_825).method_3692().intValue(); var13 <= Qa.method_1432(this.field_825).method_3692().intValue(); var13 = var4) {
                     var5 = (int)(Qa.method_4274().player.posX + (double)var2);
                     int var6 = (int)(Qa.method_4245().player.posY + (double)var3);
                     int var7 = (int)(Qa.method_4281().player.posZ + (double)var4);
                     BlockPos var8 = new BlockPos(var5, var6, var7);
                     if (!(Qa.method_4242().world.getBlockState(var8).getBlock() instanceof BlockAir)) {
                        Qa.method_4269().player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, var8, EnumFacing.DOWN));
                        Qa.method_4315().player.connection.sendPacket(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, var8, EnumFacing.DOWN));
                     }

                     ++var4;
                  }

                  --var3;
               }

               ++var2;
            }
         }
      }

   }
}

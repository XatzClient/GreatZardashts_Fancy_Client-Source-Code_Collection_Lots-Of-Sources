package net.futureclient.client;

import org.lwjgl.input.Keyboard;

public class Xb extends ja {
   public final SA field_824;

   public Xb(SA var1) {
      this.field_824 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2753((tE)var1);
   }

   public void method_2753(tE var1) {
      tE var10000;
      boolean var10001;
      label72: {
         if (var1.method_3980() == lf.KEY_PRESS) {
            Keyboard.enableRepeatEvents(false);
            switch(var1.method_3981()) {
            case 28:
               var10001 = false;
               if ((Boolean)SA.method_1675(this.field_824).method_3690() && !this.field_824.field_728.field_1430 && this.field_824.field_728.field_1431) {
                  ((Na)((ua)this.field_824.field_728.field_1427.get(this.field_824.field_728.field_1429)).f$c().get(this.field_824.field_728.field_1426)).method_548().method_2390();
               }
               break;
            case 200:
               if (this.field_824.field_728.field_1431) {
                  Keyboard.enableRepeatEvents(true);
                  if (this.field_824.field_728.field_1430) {
                     --this.field_824.field_728.field_1429;
                     if (this.field_824.field_728.field_1429 < 0) {
                        this.field_824.field_728.field_1429 = this.field_824.field_728.field_1427.size() - 1;
                     }

                     this.field_824.field_728.field_1432 = 11;
                     var10000 = var1;
                     break label72;
                  }

                  --this.field_824.field_728.field_1426;
                  if (this.field_824.field_728.field_1426 < 0) {
                     this.field_824.field_728.field_1426 = ((ua)this.field_824.field_728.field_1427.get(this.field_824.field_728.field_1429)).f$c().size() - 1;
                  }

                  if (((ua)this.field_824.field_728.field_1427.get(this.field_824.field_728.field_1429)).f$c().size() > 1) {
                     var10000 = var1;
                     this.field_824.field_728.field_1432 = 11;
                     break label72;
                  }
               }
               break;
            case 203:
               if (!this.field_824.field_728.field_1430) {
                  var10000 = var1;
                  this.field_824.field_728.field_1430 = true;
                  break label72;
               }
               break;
            case 205:
               if (this.field_824.field_728.field_1430) {
                  this.field_824.field_728.field_1430 = false;
                  var10000 = var1;
                  this.field_824.field_728.field_1426 = 0;
               } else if (!this.field_824.field_728.field_1431) {
                  this.field_824.field_728.field_1431 = true;
                  var10000 = var1;
                  this.field_824.field_728.field_1430 = true;
               } else {
                  ((Na)((ua)this.field_824.field_728.field_1427.get(this.field_824.field_728.field_1429)).f$c().get(this.field_824.field_728.field_1426)).method_548().method_2390();
                  var10000 = var1;
               }
               break label72;
            case 208:
               if (this.field_824.field_728.field_1431) {
                  Keyboard.enableRepeatEvents(true);
                  if (this.field_824.field_728.field_1430) {
                     ++this.field_824.field_728.field_1429;
                     if (this.field_824.field_728.field_1429 > this.field_824.field_728.field_1427.size() - 1) {
                        this.field_824.field_728.field_1429 = 0;
                     }

                     this.field_824.field_728.field_1432 = -11;
                     var10000 = var1;
                     break label72;
                  }

                  ++this.field_824.field_728.field_1426;
                  if (this.field_824.field_728.field_1426 > ((ua)this.field_824.field_728.field_1427.get(this.field_824.field_728.field_1429)).f$c().size() - 1) {
                     this.field_824.field_728.field_1426 = 0;
                  }

                  if (((ua)this.field_824.field_728.field_1427.get(this.field_824.field_728.field_1429)).f$c().size() > 1) {
                     var10000 = var1;
                     this.field_824.field_728.field_1432 = -11;
                     break label72;
                  }
               }
            }
         }

         var10000 = var1;
      }

      if (var10000.method_3980() == lf.KEY_RELEASE) {
         switch(var1.method_3981()) {
         case 200:
         case 208:
            var10001 = false;
            Keyboard.enableRepeatEvents(false);
         }
      }

   }
}

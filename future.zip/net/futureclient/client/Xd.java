package net.futureclient.client;

import net.minecraft.client.gui.GuiScreen;

public class Xd extends CD {
   private GuiScreen field_551;

   public Xd(GuiScreen var1) {
      this.field_551 = var1;
   }

   public GuiScreen method_1230() {
      return this.field_551;
   }
}

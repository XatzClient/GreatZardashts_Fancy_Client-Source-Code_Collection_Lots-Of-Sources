package net.futureclient.client;

public class Xe extends CD {
}

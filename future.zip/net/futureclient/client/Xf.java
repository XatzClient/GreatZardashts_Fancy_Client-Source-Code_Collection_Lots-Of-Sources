package net.futureclient.client;

public enum Xf {
   None,
   Mouse;

   private static final Xf[] field_601;
   Swing;

   static {
      Xf[] var10000 = new Xf[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Swing;
      var10000[1] = Mouse;
      var10000[2] = None;
      field_601 = var10000;
   }
}

package net.futureclient.client;

public class Xg extends xb {
   public String method_4224() {
      return null;
   }

   private static void method_2423(jB var0) {
      Object[] var10001 = new Object[0];
      boolean var10002 = true;
      byte var10003 = 1;
      var0.method_3650(var10001);
   }

   public String method_4228(String[] var1) {
      YH.method_1211().method_1203().method_3043().forEach(accept<invokedynamic>());
      return "Saved config.";
   }

   public Xg() {
      String[] var10001 = new String[4];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Save";
      var10001[1] = "Saveall";
      var10001[2] = "SaveConfigs";
      var10001[3] = "Asve";
      super(var10001);
   }
}

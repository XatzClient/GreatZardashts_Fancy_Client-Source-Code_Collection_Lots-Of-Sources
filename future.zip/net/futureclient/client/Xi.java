package net.futureclient.client;

import java.util.ArrayList;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiScreen;

public class Xi extends xb {
   private static void method_1222(Aa var0) {
      if (var0 instanceof k) {
         var0.method_615().forEach(accept<invokedynamic>());
         var0.method_629().forEach(accept<invokedynamic>());
         var0.method_624("");
         var0.method_616("");
         String[] var10001 = new String[1];
         boolean var10002 = true;
         byte var10003 = 1;
         var10001[0] = "";
         var0.method_627(var10001);
         var0.method_619(new ArrayList());
         var0.method_628(new ArrayList());
      }

   }

   private static void method_2423(jB var0) {
      Object[] var10001 = new Object[0];
      boolean var10002 = true;
      byte var10003 = 1;
      var0.method_3650(var10001);
   }

   private static void method_1491(Aa var0) {
      ka var1;
      if (var0 instanceof k && (var1 = (ka)var0).method_2387()) {
         var1.method_2390();
      }

   }

   private static void method_1225(Gb var0) {
      if (var0 != null) {
         var0.method_982("");
      }

   }

   public String method_4228(String[] var1) {
      if (this.field_1834.currentScreen instanceof GuiChat || this.field_1834.currentScreen instanceof bC) {
         this.field_1834.displayGuiScreen((GuiScreen)null);
      }

      YH.method_1211().method_1203().method_3043().forEach(accept<invokedynamic>());
      YE var4;
      if ((var4 = (YE)YH.method_1211().method_1205().method_2166(YE.class)) != null) {
         var4.field_569.cancel();
      }

      YH.method_1211().method_1205().method_2164().forEach(accept<invokedynamic>());
      YH.method_1211().method_1203().method_3043().clear();
      YH.method_1211().method_1218().method_3043().clear();
      YH.method_1211().method_1216().method_3043().clear();
      YH.method_1211().method_1210().f$c().clear();
      YH.method_1211().method_1212().method_1331();
      YH.method_1211().method_1205().method_2164().forEach(accept<invokedynamic>());
      YH.method_1211().method_1205().method_2164().clear();
      ih.method_2159().method_2158(Ri.SHUTDOWN);
      long var10000 = 300L;

      Xi var3;
      label18: {
         try {
            Thread.sleep(var10000);
            Thread.sleep(300L);
            System.gc();
            System.runFinalization();
            System.gc();
            Thread.sleep(150L);
            System.gc();
            System.runFinalization();
            System.gc();
            Thread.sleep(300L);
            System.gc();
            System.runFinalization();
         } catch (Exception var2) {
            var3 = this;
            break label18;
         }

         var3 = this;
      }

      GuiNewChat var5 = var3.field_1834.ingameGUI.getChatGUI();
      var5.deleteChatLine(1337);
      var5.getSentMessages().removeIf(test<invokedynamic>());
      return "";
   }

   private static boolean method_1227(String var0) {
      return var0.startsWith(YH.method_1211().method_1213().method_2260());
   }

   private static void method_1228(t var0) {
      if (var0 != null) {
         var0.method_3689((Object)null);
      }

   }

   public String method_4224() {
      return null;
   }

   public Xi() {
      String[] var10001 = new String[4];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "ShutDown";
      var10001[1] = "unload";
      var10001[2] = "SelfDestruct";
      var10001[3] = "Unhook";
      super(var10001);
   }
}

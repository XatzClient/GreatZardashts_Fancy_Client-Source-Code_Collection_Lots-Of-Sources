package net.futureclient.client;

public class YA extends xb {
   public final vb field_800;

   public YA(vb var1, String[] var2) {
      super(var2);
      this.field_800 = var1;
   }

   public String method_4224() {
      return null;
   }

   public String method_4228(String[] var1) {
      vb.method_4020(this.field_800);
      return sh.f$c("YIjHqI|BtHz\u0006nIsAn\b3\b");
   }
}

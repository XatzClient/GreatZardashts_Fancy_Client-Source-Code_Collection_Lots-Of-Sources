package net.futureclient.client;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class YC extends ka {
   private static boolean field_801;
   public t field_802;
   public t field_803;
   private static boolean field_804;
   public t field_805;
   private static boolean field_806 = false;
   private ej field_807;
   public t field_808;
   private ej field_809;
   private static boolean field_810;
   public t field_811;
   public t field_812;
   private ej field_813;
   public t field_814;
   private static boolean field_815;
   public t field_816;
   private ga field_817;
   private ej field_818;
   private ArrayList field_819;
   private static int field_820 = 0;
   private ej field_821;
   private ej field_822;
   private ej field_823;

   public void method_4314() {
      if (YH.method_1211().method_1208() != null) {
         YH.method_1211().method_1208().field_1164.remove(YH.method_1211().method_1208().field_1163);
         YH.method_1211().method_1206((cI)null);
      }

      field_801 = false;
      field_815 = false;
      field_804 = false;
      field_810 = false;
      field_806 = false;
      this.field_819.clear();
      super.method_4314();
   }

   public static ej method_1826(YC var0) {
      return var0.field_821;
   }

   public static boolean method_1827(boolean var0) {
      field_815 = var0;
      return var0;
   }

   public static boolean method_2849() {
      return field_815;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static ej method_1831(YC var0) {
      return var0.field_823;
   }

   public static boolean method_1832() {
      return field_810;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static ej method_1834(YC var0) {
      return var0.field_822;
   }

   public static int method_4078() {
      return field_820;
   }

   public static boolean method_1836(boolean var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      field_810 = var0;
      return var0;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static ej method_1838(YC var0) {
      return var0.field_807;
   }

   public static ArrayList method_1839(YC var0) {
      return var0.field_819;
   }

   public static boolean method_1840(boolean var0) {
      field_806 = var0;
      return var0;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static int method_3280(int var0) {
      field_820 = var0;
      return var0;
   }

   public static ga method_1843(YC var0) {
      return var0.field_817;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static ej method_1845(YC var0) {
      return var0.field_809;
   }

   public static boolean method_4325() {
      return field_801;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static int method_3231() {
      return field_820++;
   }

   public static boolean method_1849(boolean var0) {
      field_804 = var0;
      return var0;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static boolean method_1853() {
      return field_804;
   }

   public static ej method_1854(YC var0) {
      return var0.field_813;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static boolean method_1863(boolean var0) {
      field_801 = var0;
      return var0;
   }

   public static ej method_1864(YC var0) {
      return var0.field_818;
   }

   public void method_4326() {
      if (YH.method_1211().method_1208() == null) {
         YH.method_1211().method_1206(new cI());
      }

      field_801 = false;
      field_815 = false;
      field_804 = false;
      field_810 = false;
      field_806 = false;
      this.field_819.clear();
      if (f$e.player != null && (Boolean)this.field_805.method_3690()) {
         Iterator var1 = f$e.world.playerEntities.iterator();

         label38:
         while(true) {
            EntityPlayer var2;
            do {
               do {
                  do {
                     if (!var1.hasNext()) {
                        break label38;
                     }
                  } while(!EI.method_886(var2 = (EntityPlayer)((Entity)var1.next())));
               } while(this.field_819.contains(var2));
            } while(!(Boolean)this.field_811.method_3690() && YH.method_1211().method_1216().method_1481(var2.getName()));

            if (!var2.getName().equals(f$e.player.getName()) && !(var2 instanceof EntityPlayerSP)) {
               this.field_819.add(var2);
            }
         }
      }

      super.method_4326();
   }

   public static boolean method_2901() {
      return field_806;
   }

   public YC() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Notifications";
      var10002[1] = "Notifcations";
      var10002[2] = "Notify";
      var10002[3] = "Notif";
      super("Notifications", var10002, true, -5692121, bE.MISCELLANEOUS);
      wb var3 = wb.Once;
      String[] var5 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Mode";
      var5[1] = "Mod";
      var5[2] = "Method";
      var5[3] = "Time";
      this.field_817 = new ga(var3, var5);
      Boolean var4 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Queue";
      this.field_816 = new t(var4, var5);
      var4 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Kick";
      this.field_802 = new t(var4, var5);
      var4 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "PM";
      this.field_812 = new t(var4, var5);
      var4 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Name";
      this.field_814 = new t(var4, var5);
      var4 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Stuck";
      this.field_808 = new t(var4, var5);
      var4 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Damage";
      this.field_803 = new t(var4, var5);
      var4 = true;
      var5 = new String[1];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Nearby";
      this.field_805 = new t(var4, var5);
      var4 = true;
      var5 = new String[6];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Show Friends";
      var5[1] = "ShowFriends";
      var5[2] = "HideFriends";
      var5[3] = "ShowFriends";
      var5[4] = "HF";
      var5[5] = "SF";
      this.field_811 = new t(var4, var5);
      this.field_821 = new ej();
      this.field_807 = new ej();
      this.field_822 = new ej();
      this.field_809 = new ej();
      this.field_813 = new ej();
      this.field_823 = new ej();
      this.field_818 = new ej();
      this.field_819 = new ArrayList();
      t[] var10001 = new t[9];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_817;
      var10001[1] = this.field_816;
      var10001[2] = this.field_802;
      var10001[3] = this.field_812;
      var10001[4] = this.field_814;
      var10001[5] = this.field_808;
      var10001[6] = this.field_803;
      var10001[7] = this.field_805;
      var10001[8] = this.field_811;
      this.f$c(var10001);
      ja[] var1 = new ja[4];
      var2 = true;
      var6 = 1;
      var1[0] = new Cc(this);
      var1[1] = new VB(this);
      var1[2] = new bd(this);
      var1[3] = new EC(this);
      this.method_2383(var1);
   }
}

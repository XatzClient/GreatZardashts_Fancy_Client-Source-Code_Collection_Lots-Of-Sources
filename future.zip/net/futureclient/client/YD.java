package net.futureclient.client;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.math.BlockPos;

public class YD extends ka {
   private double field_589;
   private boolean field_590;
   private float field_591;
   private float field_592;
   private final t field_593;
   private mF field_594;
   private double field_595;
   private int field_596;

   public void method_4314() {
      super.method_4314();
      this.field_594 = null;
      this.field_590 = false;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static int method_1297(YD var0) {
      return var0.method_4078();
   }

   public static double method_1298(YD var0) {
      return var0.field_589;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static float method_1300(YD var0, float var1) {
      return var0.field_591 = var1;
   }

   public static float method_1301(YD var0) {
      return var0.field_592;
   }

   private int method_4078() {
      Item var1;
      ItemBlock var2;
      if ((var1 = f$e.player.inventory.getCurrentItem().getItem()) instanceof ItemBlock && (var2 = (ItemBlock)var1).getBlock() == Blocks.OBSIDIAN) {
         return f$e.player.inventory.currentItem;
      } else {
         int var3;
         for(int var10000 = var3 = 0; var10000 < 9; var10000 = var3) {
            if ((var1 = f$e.player.inventory.getStackInSlot(var3).getItem()) instanceof ItemBlock && ((ItemBlock)var1).getBlock() == Blocks.OBSIDIAN) {
               return var3;
            }

            ++var3;
         }

         return -1;
      }
   }

   public static mF method_1303(YD var0) {
      return var0.field_594;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static mF method_1305(YD var0, mF var1) {
      return var0.field_594 = var1;
   }

   public static double method_1306(YD var0) {
      return var0.field_595;
   }

   public static int method_1307(YD var0) {
      return var0.field_596;
   }

   public static boolean method_1308(YD var0, boolean var1) {
      return var0.field_590 = var1;
   }

   public static mF method_1309(YD var0, boolean var1) {
      return var0.method_1314(var1);
   }

   public static float method_1310(YD var0, float var1) {
      return var0.field_592 = var1;
   }

   public static int method_1311(YD var0, int var1) {
      return var0.field_596 = var1;
   }

   public static boolean method_1312(YD var0) {
      return var0.field_590;
   }

   public static float method_1313(YD var0) {
      return var0.field_591;
   }

   private mF method_1314(boolean var1) {
      BlockPos var2 = new BlockPos(f$e.player.posX, f$e.player.posY, f$e.player.posZ);
      EnumFacing[] var3;
      int var4 = (var3 = Plane.HORIZONTAL.facings()).length;

      int var5;
      for(int var10000 = var5 = 0; var10000 < var4; var10000 = var5) {
         EnumFacing var6 = var3[var5];
         BlockPos var7;
         BlockPos var8 = (var7 = var2.offset(var6)).down();
         if (!f$e.world.mayPlace(Blocks.OBSIDIAN, var8, false, EnumFacing.DOWN, (Entity)null)) {
            if (f$e.world.mayPlace(Blocks.OBSIDIAN, var7, false, EnumFacing.DOWN, (Entity)null)) {
               return new mF(var8, EnumFacing.UP, (HF)null);
            }
         } else if (var1) {
            EnumFacing var10 = var6.getOpposite();
            BlockPos var9 = var8.offset(var10);
            if (!f$e.world.mayPlace(Blocks.OBSIDIAN, var9, false, var10, (Entity)null) && f$e.world.mayPlace(Blocks.OBSIDIAN, var8, false, var10, (Entity)null)) {
               return new mF(var9, var6, (HF)null);
            }
         }

         ++var5;
      }

      return null;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public void method_4326() {
      if (f$e.player != null && (Boolean)this.field_593.method_3690() && this.method_4078() != -1) {
         this.field_590 = true;
         BlockPos var1;
         this.field_589 = (double)(var1 = new BlockPos(f$e.player.posX, f$e.player.posY, f$e.player.posZ)).getX() + 0.0D;
         this.field_595 = (double)var1.getZ() + 0.0D;
      }

      super.method_4326();
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public YD() {
      String[] var10002 = new String[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoObsidian";
      byte var10006 = 1;
      super("AutoObsidian", var10002, true, (new Color(100, 0, 150)).getRGB(), bE.COMBAT);
      Boolean var3 = true;
      String[] var5 = new String[6];
      boolean var10005 = true;
      var10006 = 1;
      var5[0] = "Center";
      var5[1] = "forcecenter";
      var5[2] = "teleport";
      var5[3] = "c";
      var5[4] = "tp";
      var5[5] = "fc";
      this.field_593 = new t(var3, var5);
      this.field_594 = null;
      this.field_596 = -1;
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_593;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var4 = 1;
      var1[0] = new HF(this);
      var1[1] = new wD(this);
      this.method_2383(var1);
   }
}

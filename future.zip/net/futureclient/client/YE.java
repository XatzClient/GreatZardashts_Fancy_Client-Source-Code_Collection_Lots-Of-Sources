package net.futureclient.client;

import java.awt.Font;
import java.text.DecimalFormat;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.world.DimensionType;

public class YE extends Aa {
   private List field_552;
   public boolean field_553;
   public t field_554;
   private double field_555;
   public t field_556;
   private Map field_557;
   public t field_558;
   public t field_559;
   public t field_560;
   public t field_561;
   private ga field_562;
   public t field_563;
   public t field_564;
   public t field_565;
   public ga field_566;
   private ga field_567;
   private int field_568;
   public Timer field_569;
   private ej field_570;
   public t field_571;
   public t field_572;
   public sH field_573;
   private int field_574;
   public t field_575;
   public t field_576;
   private final ArrayDeque field_577;
   private static final int field_578 = 20;
   public t field_579;
   public t field_580;
   private ga field_581;
   public int field_582;
   public t field_583;
   public t field_584;
   public t field_585;
   private ga field_586;
   private float field_587;
   private int field_588;

   public static void method_1231(YE var0, kf var1) {
      var0.method_1292(var1);
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   private void method_1233(kf var1) {
      if (!(f$e.currentScreen instanceof GuiChat)) {
         int var2 = 15;
         GlStateManager.pushMatrix();
         RenderHelper.enableGUIStandardItemLighting();

         int var3;
         for(int var10000 = var3 = 3; var10000 >= 0; var10000 = var3) {
            ItemStack var4;
            if (!((var4 = (ItemStack)f$e.player.inventory.armorInventory.get(var3)).getItem() instanceof ItemAir)) {
               int var5;
               if (f$e.player.isInsideOfMaterial(Material.WATER) && f$e.player.getAir() > 0 && !f$e.player.capabilities.isCreativeMode) {
                  var5 = 65;
               } else if (f$e.player.getRidingEntity() != null && !f$e.player.capabilities.isCreativeMode) {
                  if (f$e.player.getRidingEntity() instanceof EntityLivingBase) {
                     EntityLivingBase var6 = (EntityLivingBase)f$e.player.getRidingEntity();
                     var5 = 45 + (int)Math.ceil((double)((var6.getMaxHealth() - 1.0F) / 20.0F)) * 10;
                  } else {
                     var5 = 45;
                  }
               } else if (f$e.player.capabilities.isCreativeMode) {
                  var5 = f$e.player.isRidingHorse() ? 45 : 38;
               } else {
                  var5 = 55;
               }

               f$e.getRenderItem().renderItemIntoGUI(var4, var1.method_2330().getScaledWidth() / 2 + var2, var1.method_2330().getScaledHeight() - var5);
               RenderItem var7 = f$e.getRenderItem();
               FontRenderer var10001 = f$e.fontRenderer;
               int var10003 = var1.method_2330().getScaledWidth() / 2 + var2;
               int var10004 = var1.method_2330().getScaledHeight();
               var2 += 18;
               var7.renderItemOverlays(var10001, var4, var10003, var10004 - var5);
            }

            --var3;
         }

         RenderHelper.disableStandardItemLighting();
         GlStateManager.popMatrix();
      }
   }

   public static int method_1234(YE var0) {
      return var0.field_568--;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static void method_1237(YE var0, kf var1) {
      var0.method_1290(var1);
   }

   public static int method_1238(YE var0) {
      return var0.field_568;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static void method_1240(YE var0, kf var1) {
      var0.method_1289(var1);
   }

   public static ga method_1241(YE var0) {
      return var0.field_567;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static int method_1243(YE var0) {
      return var0.field_588++;
   }

   private static int method_1244(ka var0, ka var1) {
      return f$e.fontRenderer.getStringWidth(var1.method_618()) - f$e.fontRenderer.getStringWidth(var0.method_618());
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static double method_1246(YE var0) {
      return var0.field_555;
   }

   public static float method_1247(YE var0, float var1) {
      return var0.field_587 = var1;
   }

   public static void method_1248(YE var0, kf var1) {
      var0.method_1291(var1);
   }

   public static int method_1249(YE var0) {
      return var0.field_588--;
   }

   private int method_1250(ka var1, ka var2) {
      return this.field_573.method_3684(var2.method_618()) - this.field_573.method_3684(var1.method_618());
   }

   public static double method_1251(YE var0, double var1) {
      return var0.field_555 = var1;
   }

   public static float method_1252(YE var0) {
      return var0.field_587;
   }

   private void method_1253(kf var1, String var2, int var3) {
      // $FF: Couldn't be decompiled
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static ga method_1255(YE var0) {
      return var0.field_562;
   }

   public static void method_1256(YE var0, kf var1, String var2, int var3) {
      var0.method_1253(var1, var2, var3);
   }

   public static ArrayDeque method_1257(YE var0) {
      return var0.field_577;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   private void method_1259(kf var1) {
      // $FF: Couldn't be decompiled
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static void method_1261(YE var0, kf var1) {
      var0.method_1233(var1);
   }

   public static int method_1262(YE var0) {
      return var0.field_588;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static int method_1266(YE var0) {
      return var0.field_574;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static int method_1269(YE var0) {
      return var0.field_574--;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static int method_1272(YE var0) {
      return var0.field_574++;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static int method_1277(YE var0) {
      return var0.field_568++;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static void method_1279(YE var0, kf var1) {
      var0.method_1259(var1);
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   private void method_1289(kf var1) {
      // $FF: Couldn't be decompiled
   }

   private void method_1290(kf var1) {
      zF var2 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
      Object[] var10002;
      boolean var10003;
      byte var10004;
      if ((Boolean)this.field_583.method_3690()) {
         GlStateManager.enableBlend();
         GlStateManager.enableAlpha();
         sH var3 = this.field_573;
         var10002 = new Object[2];
         var10003 = true;
         var10004 = 1;
         var10002[0] = YH.field_548;
         var10002[1] = YH.field_540;
         var3.method_3678(String.format("%s v%s", var10002), 0.0D, (double)var1.field_1004, var2.field_1445.getRGB());
         GlStateManager.disableBlend();
         GlStateManager.disableAlpha();
      } else {
         FontRenderer var10000 = f$e.fontRenderer;
         var10002 = new Object[2];
         var10003 = true;
         var10004 = 1;
         var10002[0] = YH.field_548;
         var10002[1] = YH.field_540;
         var10000.drawStringWithShadow(String.format("%s v%s", var10002), 2.0F, (float)var1.field_1004, var2.field_1445.getRGB());
      }
   }

   private void method_1291(kf var1) {
      if (this.field_568 > -10 && !f$e.isSingleplayer()) {
         String var2 = (new StringBuilder()).insert(0, "Server is not responding ").append((new DecimalFormat("0.0")).format((double)((float)YH.method_1211().method_1204().method_128().method_3407() / 1000.0F))).append("s").toString();
         if ((Boolean)this.field_583.method_3690()) {
            GlStateManager.enableBlend();
            this.field_573.method_3678(var2, (double)(var1.method_2330().getScaledWidth() / 2 - this.field_573.method_3684(var2) / 2), (double)this.field_568, -5592406);
            GlStateManager.disableBlend();
            return;
         }

         f$e.fontRenderer.drawStringWithShadow(var2, (float)var1.method_2330().getScaledWidth() / 2.0F - (float)f$e.fontRenderer.getStringWidth(var2) / 2.0F, (float)this.field_568, -5592406);
      }

   }

   private void method_1292(kf var1) {
      // $FF: Couldn't be decompiled
   }

   public YE() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "HUD";
      var10002[1] = "huud";
      super("HUD", var10002);
      Boolean var2 = true;
      String[] var3 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var3[0] = "Direction";
      var3[1] = "dir";
      this.field_556 = new t(var2, var3);
      var2 = true;
      var3 = new String[2];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Armor";
      var3[1] = "armour";
      this.field_558 = new t(var2, var3);
      var2 = true;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "PotionEffects";
      var3[1] = "Potion-Effects";
      var3[2] = "pe";
      var3[3] = "potion";
      this.field_565 = new t(var2, var3);
      var2 = false;
      var3 = new String[3];
      var10005 = true;
      var10006 = 1;
      var3[0] = "ServerBrand";
      var3[1] = "server";
      var3[2] = "sb";
      this.field_579 = new t(var2, var3);
      var2 = true;
      var3 = new String[2];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Watermark";
      var3[1] = "wm";
      this.field_571 = new t(var2, var3);
      var2 = true;
      var3 = new String[3];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Durability";
      var3[1] = "dura";
      var3[2] = "d";
      this.field_560 = new t(var2, var3);
      var2 = false;
      var3 = new String[3];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Coords";
      var3[1] = "coord";
      var3[2] = "c";
      this.field_584 = new t(var2, var3);
      var2 = false;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "NetherCoords";
      var3[1] = "NetherCoordinates";
      var3[2] = "Nether";
      var3[3] = "nc";
      this.field_572 = new t(var2, var3);
      var2 = true;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "ArrayList";
      var3[1] = "al";
      var3[2] = "array";
      var3[3] = "list";
      this.field_575 = new t(var2, var3);
      var2 = true;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "FPS";
      var3[1] = "fpps";
      var3[2] = "Frames";
      var3[3] = "fp";
      this.field_554 = new t(var2, var3);
      var2 = true;
      var3 = new String[3];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Speed";
      var3[1] = "spood";
      var3[2] = "sp";
      this.field_561 = new t(var2, var3);
      var2 = true;
      var3 = new String[6];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Ping";
      var3[1] = "pingerino";
      var3[2] = "Pengo";
      var3[3] = "Peng";
      var3[4] = "pin";
      var3[5] = "png";
      this.field_564 = new t(var2, var3);
      var2 = true;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "TPS";
      var3[1] = "ServerTPS";
      var3[2] = "TSP";
      var3[3] = "ytp";
      this.field_559 = new t(var2, var3);
      var2 = true;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Lag Notifier";
      var3[1] = "LagNotifier";
      var3[2] = "LagNotify";
      var3[3] = "LagNotif";
      this.field_576 = new t(var2, var3);
      var2 = true;
      var3 = new String[2];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Shadow";
      var3[1] = "ss";
      this.field_563 = new t(var2, var3);
      var2 = true;
      var3 = new String[3];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Capes";
      var3[1] = "cape";
      var3[2] = "c";
      this.field_580 = new t(var2, var3);
      var2 = true;
      var3 = new String[9];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Liquid Vision";
      var3[1] = "LiquidVision";
      var3[2] = "Liquids";
      var3[3] = "Seethrough";
      var3[4] = "waterinvis";
      var3[5] = "Seethroughwater";
      var3[6] = "seethroughlava";
      var3[7] = "lavavision";
      var3[8] = "watervision";
      this.field_585 = new t(var2, var3);
      Se var4 = Se.Length;
      var3 = new String[3];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Ordering";
      var3[1] = "order";
      var3[2] = "o";
      this.field_581 = new ga(var4, var3);
      Jg var5 = Jg.Down;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Rendering";
      var3[1] = "ArrayListRendering";
      var3[2] = "alr";
      var3[3] = "al";
      this.field_562 = new ga(var5, var3);
      TE var6 = TE.Left;
      var3 = new String[4];
      var10005 = true;
      var10006 = 1;
      var3[0] = "Corner";
      var3[1] = "CordsCorner";
      var3[2] = "Corner";
      var3[3] = "CC";
      this.field_586 = new ga(var6, var3);
      Nf var7 = Nf.Hide;
      var3 = new String[5];
      var10005 = true;
      var10006 = 1;
      var3[0] = "EffectHUD";
      var3[1] = "MCPotionHUD";
      var3[2] = "MinecraftPotionHUD";
      var3[3] = "mcph";
      var3[4] = "mcphud";
      this.field_566 = new ga(var7, var3);
      qD var8 = qD.Default;
      var3 = new String[8];
      var10005 = true;
      var10006 = 1;
      var3[0] = "ModulesColor";
      var3[1] = "ArrayListColors";
      var3[2] = "ArrayColors";
      var3[3] = "ArrayColor";
      var3[4] = "ModColors";
      var3[5] = "ModColor";
      var3[6] = "Rainbow";
      var3[7] = "RGBModules";
      this.field_567 = new ga(var8, var3);
      this.field_573 = new sH(new Font("Verdana", 0, 18), true, (boolean)1);
      var2 = true;
      var3 = new String[3];
      var10005 = true;
      var10006 = 1;
      var3[0] = "CustomFont";
      var3[1] = "usecustomfont";
      var3[2] = "font";
      this.field_583 = new t(var2, var3);
      this.field_587 = 0.0F;
      this.field_568 = -12;
      this.field_574 = 9;
      this.field_588 = 0;
      this.field_557 = new HashMap();
      this.field_570 = new ej();
      this.field_569 = new Timer();
      this.field_582 = 0;
      this.field_553 = false;
      this.field_577 = new ArrayDeque(20);
      t[] var10001 = new t[23];
      boolean var1 = true;
      byte var9 = 1;
      var10001[0] = this.field_583;
      var10001[1] = this.field_571;
      var10001[2] = this.field_556;
      var10001[3] = this.field_558;
      var10001[4] = this.field_565;
      var10001[5] = this.field_566;
      var10001[6] = this.field_585;
      var10001[7] = this.field_580;
      var10001[8] = this.field_579;
      var10001[9] = this.field_576;
      var10001[10] = this.field_559;
      var10001[11] = this.field_554;
      var10001[12] = this.field_561;
      var10001[13] = this.field_564;
      var10001[14] = this.field_581;
      var10001[15] = this.field_563;
      var10001[16] = this.field_584;
      var10001[17] = this.field_572;
      var10001[18] = this.field_586;
      var10001[19] = this.field_560;
      var10001[20] = this.field_575;
      var10001[21] = this.field_567;
      var10001[22] = this.field_562;
      this.f$c(var10001);
      this.field_569.schedule(new ND(this), 0L, 16L);
      YH.method_1211().method_1212().method_1330(new Ud(this));
      YH.method_1211().method_1212().method_1330(new oF(this));
   }
}

package net.futureclient.client;

import net.minecraft.entity.Entity;

public class YF extends Hg {
   private Entity field_603;

   public YF(Entity var1) {
      this.field_603 = var1;
   }

   public Entity method_2798() {
      return this.field_603;
   }

   public void method_1336(Entity var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      this.field_603 = var1;
   }
}

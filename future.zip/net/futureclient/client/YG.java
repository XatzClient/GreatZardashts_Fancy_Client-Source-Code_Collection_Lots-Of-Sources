package net.futureclient.client;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;

public final class YG implements S {
   private final Minecraft field_597 = Minecraft.getMinecraft();
   private final Map field_598 = new ConcurrentHashMap();

   public void method_1330(ja var1) {
      if (var1 != null) {
         Class var2 = var1.method_2147();
         Object var3;
         if ((var3 = (List)this.field_598.get(var2)) == null) {
            this.field_598.put(var2, var3 = new CopyOnWriteArrayList());
         }

         if (!((List)var3).contains(var1)) {
            ((List)var3).add(var1);
         }
      }

   }

   public void method_1331() {
      this.field_598.clear();
   }

   public void method_1332(CD var1) {
      List var2;
      if ((var2 = (List)this.field_598.get(var1.getClass())) != null) {
         Iterator var4 = var2.iterator();

         while(true) {
            ja var3;
            do {
               do {
                  if (!var4.hasNext()) {
                     return;
                  }
               } while((var3 = (ja)var4.next()).method_2147() != var1.getClass());
            } while(!(var1 instanceof Jf) && !(var1 instanceof Yf) && !(var1 instanceof ae) && (this.field_597.player == null || this.field_597.world == null));

            var3.method_4312(var1);
         }
      }
   }

   private static boolean method_1333(ja var0, ja var1) {
      return var1.equals(var0);
   }

   public void method_1334(ja var1) {
      Class var2 = var1.method_2147();
      List var3;
      if ((var3 = (List)this.field_598.get(var2)) != null) {
         var3.removeIf(var1.test<invokedynamic>(var1));
         if (var3.isEmpty()) {
            this.field_598.remove(var2);
         }
      }

   }
}

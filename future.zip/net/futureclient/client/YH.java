package net.futureclient.client;

import java.io.File;
import org.apache.logging.log4j.Level;

public class YH {
   private static YH field_532;
   private File field_533;
   private final YG field_534;
   public long field_535 = System.nanoTime() / 1000000L;
   private final Li field_536;
   private final qf field_537;
   private final TI field_538;
   private final DF field_539;
   public static String field_540 = "2.9";
   private final GI field_541;
   private final bj field_542;
   private final uh field_543;
   private cI field_544;
   private final LI field_545;
   private final Qe field_546;
   private final mH field_547;
   public static String field_548 = "Future";
   private final jF field_549;
   private final Lg field_550;

   public Lg method_1203() {
      return this.field_550;
   }

   public LI method_1204() {
      return this.field_545;
   }

   public jF method_1205() {
      return this.field_549;
   }

   public void method_1206(cI var1) {
      this.field_544 = var1;
   }

   public TI method_1207() {
      return this.field_538;
   }

   public cI method_1208() {
      return this.field_544;
   }

   public Li method_1209() {
      return this.field_536;
   }

   public qf method_1210() {
      return this.field_537;
   }

   public static YH method_1211() {
      return field_532;
   }

   public YG method_1212() {
      return this.field_534;
   }

   public GI method_1213() {
      return this.field_541;
   }

   private static void method_1214(jB var0) {
      boolean var10002 = true;
      byte var10003 = 1;
      Object[] var10001 = new Object[0];
      var10002 = true;
      var10003 = 1;
      var0.method_3649(var10001);
   }

   public void method_1215(String var1) {
      field_548 = var1;
   }

   public Qe method_1216() {
      return this.field_546;
   }

   public File method_1217() {
      return this.field_533;
   }

   public mH method_1218() {
      return this.field_547;
   }

   public DF method_1219() {
      return this.field_539;
   }

   public uh method_1220() {
      return this.field_543;
   }

   public bj method_1221() {
      return this.field_542;
   }

   public YH() {
      la.method_2324().method_2323(Level.INFO, "Initiated client startup.");
      field_532 = this;
      this.field_536 = new Li();
      this.field_536.method_302();
      this.field_533 = new File(System.getProperty("user.home"), field_548);
      if (!this.field_533.exists()) {
         la var10000 = la.method_2324();
         Level var10001 = Level.INFO;
         byte var10004 = 1;
         byte var10005 = 1;
         Object[] var10003 = new Object[1];
         boolean var2 = true;
         var10005 = 1;
         boolean var10006 = true;
         byte var10007 = 1;
         var10003[0] = this.field_533.mkdir() ? "Created" : "Failed to create";
         var10000.method_2323(var10001, String.format("%s client directory.", var10003));
      }

      File var1;
      if (!(var1 = new File(method_1211().method_1217(), "songs")).exists()) {
         var1.mkdir();
      }

      if (!(var1 = new File(method_1211().method_1217(), "spammer")).exists()) {
         var1.mkdir();
      }

      this.field_534 = new YG();
      this.field_550 = new Lg();
      this.field_537 = new qf();
      this.field_541 = new GI();
      this.field_549 = new jF();
      this.field_539 = new DF();
      this.field_546 = new Qe();
      this.field_547 = new mH();
      this.field_545 = new LI();
      this.field_538 = new TI();
      this.field_543 = new uh();
      this.field_542 = new bj();
      this.method_1203().method_3043().forEach(accept<invokedynamic>());
      this.method_1212().method_1330(new RI(this));
      la.method_2324().method_2323(Level.INFO, "Finished client startup.");
   }
}

package net.futureclient.client;

import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;

public enum YI {
   INSTANCE;

   private static final Path field_529;
   private static final YI[] field_530;
   private static final Path field_531;

   public static Path method_1196() {
      return field_531;
   }

   public static Path method_1197() {
      return field_529;
   }

   public qg method_1198() {
      qg var1 = null;
      Path var10000 = field_531;
      LinkOption[] var10001 = new LinkOption[0];
      boolean var10002 = true;
      byte var10003 = 1;
      if (Files.exists(var10000, var10001)) {
         Mi var5 = Mi.INSTANCE;

         try {
            var1 = var5.method_234();
         } catch (Exception var4) {
         }
      }

      if (dj.INSTANCE.method_3095() && var1 == null) {
         dj var6 = dj.INSTANCE;

         try {
            qg var2 = var6.method_3097();
            var1 = this.method_1199(var2.method_3794(), var2.method_3795());
         } catch (Exception var3) {
         }
      }

      return var1;
   }

   public qg method_1199(String var1, String var2) {
      qg var4 = new qg(var1, var2);
      VI var10000 = VI.f$G;
      qg var10001 = var4;

      try {
         var10000.f$c(var10001);
         return var4;
      } catch (Exception var3) {
         return var4;
      }
   }

   static {
      YI[] var10000 = new YI[1];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = INSTANCE;
      field_530 = var10000;
      String var0 = System.getProperty("user.home");
      String[] var1 = new String[1];
      boolean var2 = true;
      byte var10003 = 1;
      var1[0] = "Future";
      field_529 = Paths.get(var0, var1);
      field_531 = field_529.resolve("auth_key");
   }
}

package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.MobEffects;

public class Yb extends ja {
   public final ac field_527;

   public Yb(ac var1) {
      this.field_527 = var1;
   }

   public void method_4183(Xe var1) {
      if ((Boolean)this.field_527.field_1189.method_3690()) {
         ac.method_4281().player.removeActivePotionEffect(MobEffects.NAUSEA);
         if (ac.method_4242().player.isPotionActive(MobEffects.BLINDNESS)) {
            ac.method_4269().player.removePotionEffect(MobEffects.BLINDNESS);
         }
      }

      if (((BA)ac.method_3027(this.field_527).method_3690()).equals(BA.Remove)) {
         Iterator var2;
         Iterator var10000 = var2 = ac.method_4315().world.loadedEntityList.iterator();

         while(var10000.hasNext()) {
            Entity var3;
            if (!((var3 = (Entity)var2.next()) instanceof EntityItem)) {
               var10000 = var2;
            } else {
               ac.method_4319().world.removeEntity(var3);
               var10000 = var2;
            }
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

package net.futureclient.client;

public class Yc extends ja {
   public final bA field_526;

   public Yc(bA var1) {
      this.field_526 = var1;
   }

   public void method_1192(Ig var1) {
      if (((JB)this.field_526.field_1183.method_3690()).equals(JB.PhysicsCalc) && bA.method_2871(this.field_526).method_817(100L)) {
         var1.method_2353(bA.method_2873(this.field_526).method_3692().intValue());
      }

   }

   public void method_4312(CD var1) {
      this.method_1192((Ig)var1);
   }
}

package net.futureclient.client;

public class Yd extends sF {
   private final boolean field_518;
   private final boolean field_519;

   public Yd(boolean var1, boolean var2) {
      this.field_519 = var1;
      this.field_518 = var2;
   }

   public boolean method_3480() {
      return this.field_518;
   }

   public boolean method_1190() {
      return this.field_519;
   }
}

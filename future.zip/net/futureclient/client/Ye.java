package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.CPacketPlayer.Position;

public class Ye extends ja {
   public final Zf field_516;

   public Ye(Zf var1) {
      this.field_516 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      Zf var10000 = this.field_516;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = Zf.method_1348(this.field_516).method_3690();
      var10000.f$D(String.format("Phase §7[§F%s§7]", var10002));
      float var2 = Zf.method_4300().player.rotationYaw;
      if (Zf.method_4299().player.moveForward < 0.0F) {
         var2 += 180.0F;
      }

      if (Zf.method_4297().player.moveStrafing > 0.0F) {
         var2 -= 90.0F * (Zf.method_4285().player.moveForward < 0.0F ? -0.5F : (Zf.method_4284().player.moveForward > 0.0F ? 0.5F : 1.0F));
      }

      if (Zf.method_4286().player.moveStrafing < 0.0F) {
         var2 += 90.0F * (Zf.method_4293().player.moveForward < 0.0F ? -0.5F : (Zf.method_4287().player.moveForward > 0.0F ? 0.5F : 1.0F));
      }

      double var3 = Math.cos(Math.toRadians((double)(var2 + 90.0F))) * 1.273197475E-314D;
      var3 = Math.sin(Math.toRadians((double)(var2 + 90.0F))) * 1.273197475E-314D;
      var3 = (double)Zf.method_4250().player.getHorizontalFacing().getDirectionVec().getX() * 1.273197475E-314D;
      double var5 = (double)Zf.method_4295().player.getHorizontalFacing().getDirectionVec().getZ() * 1.273197475E-314D;
      switch(kg.f$G[((tF)Zf.method_1348(this.field_516).method_3690()).ordinal()]) {
      case 1:
         boolean var10001 = false;
         switch(kg.f$e[var1.method_326().ordinal()]) {
         case 1:
            Minecraft var8 = Zf.method_4282();
            var10001 = false;
            if (!var8.player.isSneaking() || !Zf.method_1344(this.field_516)) {
               return;
            }

            var2 = Zf.method_4290().player.rotationYaw;
            Zf.method_4244().player.setEntityBoundingBox(Zf.method_4272().player.getEntityBoundingBox().offset(Zf.method_1345(this.field_516).method_3692().doubleValue() * Math.cos(Math.toRadians((double)(var2 + 90.0F))), 0.0D, Zf.method_1345(this.field_516).method_3692().doubleValue() * Math.sin(Math.toRadians((double)(var2 + 90.0F)))));
         default:
            return;
         }
      case 2:
         Zf.method_4289().player.motionY = 0.0D;
         if (Zf.method_4283().inGameHasFocus) {
            EntityPlayerSP var7;
            if (Zf.method_4243().player.movementInput.jump) {
               var7 = Zf.method_4280().player;
               var7.motionY += 4.24399158E-315D;
            }

            if (Zf.method_4279().player.movementInput.sneak) {
               var7 = Zf.method_4271().player;
               var7.motionY -= 4.24399158E-315D;
            }
         }

         Zf.method_4278().player.noClip = true;
         return;
      case 3:
      default:
         break;
      case 4:
         if (Zf.method_4275().player.collidedHorizontally && Zf.method_1347(this.field_516).method_813(200L)) {
            Zf.method_4273().player.connection.sendPacket(new Position(Zf.method_4277().player.posX, Zf.method_4270().player.posY + 1.273197475E-314D, Zf.method_4267().player.posZ, true));
            Zf.method_4281().player.connection.sendPacket(new Position(Zf.method_4276().player.posX + var3 * 0.0D, Zf.method_4274().player.posY, Zf.method_4245().player.posZ + var5 * 0.0D, true));
            Zf.method_4319().player.connection.sendPacket(new Position(Zf.method_4242().player.posX, Zf.method_4269().player.posY, Zf.method_4315().player.posZ, true));
            Zf.method_1347(this.field_516).method_814();
         }
      }

   }
}

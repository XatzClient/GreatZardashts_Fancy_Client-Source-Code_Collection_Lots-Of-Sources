package net.futureclient.client;

public class Yf extends CD {
}

package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketTimeUpdate;

public class Yh extends ja {
   public final LI field_514;

   public Yh(LI var1) {
      this.field_514 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (!(var1.method_3084() instanceof SPacketChat)) {
         LI.method_126(this.field_514).method_3404();
      }

      if (var1.method_3084() instanceof SPacketTimeUpdate) {
         if (LI.method_130(this.field_514) != 0L) {
            if (LI.method_127(this.field_514).size() > 20) {
               LI.method_127(this.field_514).poll();
            }

            LI.method_127(this.field_514).add(20.0F * (1000.0F / (float)(System.currentTimeMillis() - LI.method_130(this.field_514))));
            float var2 = 0.0F;
            Iterator var3 = LI.method_127(this.field_514).iterator();

            for(Iterator var10000 = var3; var10000.hasNext(); var10000 = var3) {
               Float var4 = (Float)var3.next();
               var2 += Math.max(0.0F, Math.min(20.0F, var4));
            }

            var2 /= (float)LI.method_127(this.field_514).size();
            LI.method_133(this.field_514, var2);
         }

         LI.method_129(this.field_514, System.currentTimeMillis());
      }

   }
}

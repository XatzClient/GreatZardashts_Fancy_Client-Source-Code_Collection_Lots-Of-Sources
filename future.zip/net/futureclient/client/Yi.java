package net.futureclient.client;

public class Yi extends xb {
   public String method_4224() {
      return "&e[name]";
   }

   public String method_4228(String[] var1) {
      if (var1.length < 1) {
         return null;
      } else {
         StringBuilder var2 = new StringBuilder();
         int var3 = (var1 = var1).length;

         int var4;
         for(int var10000 = var4 = 0; var10000 < var3; var10000 = var4) {
            String var5 = var1[var4];
            var2.append(var5);
            ++var4;
            var2.append(" ");
         }

         String var6 = var2.toString().trim();
         YH.method_1211().method_1215(var6);
         Object[] var10001 = new Object[1];
         boolean var10002 = true;
         byte var10003 = 1;
         var10001[0] = var6;
         return String.format("Watermark has been set to %s.", var10001);
      }
   }

   public Yi() {
      String[] var10001 = new String[5];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Watermark";
      var10001[1] = "setwatermark";
      var10001[2] = "clientname";
      var10001[3] = "setname";
      var10001[4] = "setclientname";
      super(var10001);
   }
}

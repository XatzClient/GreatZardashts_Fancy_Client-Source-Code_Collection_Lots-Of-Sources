package net.futureclient.client;

public class ZB extends Gb {
   public final rA field_525;

   public ZB(rA var1, String var2) {
      super(var2);
      this.field_525 = var1;
   }

   public void method_1191() {
      this.field_525.field_1514.method_3691(3.5F);
   }
}

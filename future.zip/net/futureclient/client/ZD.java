package net.futureclient.client;

public final class ZD extends CD {
}

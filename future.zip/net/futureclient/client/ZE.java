package net.futureclient.client;

public class ZE extends ja {
   public final zD field_517;

   public ZE(zD var1) {
      this.field_517 = var1;
   }

   public void method_4040(VF var1) {
      if ((Boolean)zD.method_4157(this.field_517).method_3690()) {
         var1.method_3481(true);
      }

   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }
}

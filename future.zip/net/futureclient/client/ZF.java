package net.futureclient.client;

import java.text.DecimalFormat;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DimensionType;

public class ZF extends xb {
   private DecimalFormat field_515;

   public String method_4224() {
      return "&e[yaw|waypoint] &7| &e[x] [z]";
   }

   public String method_4228(String[] var1) {
      Object[] var10001;
      double var2;
      boolean var10002;
      byte var10003;
      if (var1.length == 1) {
         String var10000 = var1[0];

         ZF var10;
         label47: {
            try {
               var2 = MathHelper.wrapDegrees(Double.parseDouble(var10000));
            } catch (NumberFormatException var9) {
               xa var4;
               if ((var4 = ((xC)YH.method_1211().method_1205().method_2166(xC.class)).method_4246(var1[0])) != null) {
                  double var5 = var4.method_4206();
                  double var7 = var4.method_4210();
                  if (this.field_1834.world.provider.getDimensionType().equals(DimensionType.NETHER) && var4.method_4205().equals(DimensionType.OVERWORLD.getName())) {
                     var5 /= 0.0D;
                     var7 /= 0.0D;
                     var10 = this;
                  } else {
                     if (this.field_1834.world.provider.getDimensionType().equals(DimensionType.OVERWORLD) && var4.method_4205().equals(DimensionType.NETHER.getName())) {
                        var5 *= 0.0D;
                        var7 *= 0.0D;
                     }

                     var10 = this;
                  }

                  var2 = MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(var10.field_1834.player.posZ - var7, this.field_1834.player.posX - var5)) + 0.0D);
                  var10 = this;
                  break label47;
               }

               return "Invalid Waypoint entered.";
            }

            var10 = this;
         }

         if (var10.field_1834.player != null) {
            this.field_1834.player.rotationYaw = (float)var2;
         }

         var10001 = new Object[1];
         var10002 = true;
         var10003 = 1;
         var10001[0] = this.field_515.format(var2);
         return String.format("Set rotation yaw to %s degrees.", var10001);
      } else if (var1.length == 2) {
         var2 = MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(this.field_1834.player.posZ - Double.parseDouble(var1[1]), this.field_1834.player.posX - Double.parseDouble(var1[0]))) + 0.0D);
         if (this.field_1834.player != null) {
            this.field_1834.player.rotationYaw = (float)var2;
         }

         var10001 = new Object[1];
         var10002 = true;
         var10003 = 1;
         var10001[0] = this.field_515.format(var2);
         return String.format("Set rotation yaw to %s degrees.", var10001);
      } else {
         return null;
      }
   }

   public ZF() {
      String[] var10001 = new String[5];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "SetYaw";
      var10001[1] = "SePitch";
      var10001[2] = "SetRotationYaw";
      var10001[3] = "SetRotation";
      var10001[4] = "sy";
      super(var10001);
      this.field_515 = new DecimalFormat("0.##");
   }
}

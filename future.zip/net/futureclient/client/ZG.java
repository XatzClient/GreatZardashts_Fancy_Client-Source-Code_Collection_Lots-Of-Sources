package net.futureclient.client;

import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class ZG {
   public BlockPos field_520;
   public EnumFacing field_521;

   public ZG(BlockPos var1, EnumFacing var2) {
      this.field_520 = var1;
      this.field_521 = var2;
   }
}

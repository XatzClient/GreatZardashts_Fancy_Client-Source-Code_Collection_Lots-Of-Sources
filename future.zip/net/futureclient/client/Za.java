package net.futureclient.client;

public class Za extends ja {
   public final sa field_495;

   public Za(sa var1) {
      this.field_495 = var1;
   }

   public void method_4312(CD var1) {
      this.method_1107((Qf)var1);
   }

   public void method_1107(Qf var1) {
      if ((Boolean)sa.method_3987(this.field_495).method_3690()) {
         var1.f$c(true);
      }
   }
}

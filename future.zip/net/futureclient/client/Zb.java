package net.futureclient.client;

public enum Zb {
   Normal,
   Control;

   private static final Zb[] field_492;
   Boost,
   Packet;

   static {
      Zb[] var10000 = new Zb[4];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Normal;
      var10000[1] = Boost;
      var10000[2] = Packet;
      var10000[3] = Control;
      field_492 = var10000;
   }
}

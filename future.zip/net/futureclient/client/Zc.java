package net.futureclient.client;

import java.util.Random;
import net.minecraft.client.Minecraft;

public class Zc extends ka {
   private t field_497;
   private t field_498;
   private int field_499;
   private t field_500;
   private boolean field_501;
   private final Random field_502;
   private ga field_503;
   private t field_504;
   private double field_505;
   private U field_506;
   private EG field_507;
   private U field_508;
   private U field_509;
   private U field_510;
   private t field_511;
   private int field_512;
   private U field_513;

   public static U method_1110(Zc var0) {
      return var0.field_509;
   }

   public void method_4314() {
      super.method_4314();
      if (this.field_503.method_3690() == oA.Riga && f$e.player != null) {
         this.field_512 = 0;
         f$e.player.jumpMovementFactor = 0.02F;
      }

   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static t method_1113(Zc var0) {
      return var0.field_511;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static int method_1117(Zc var0) {
      return var0.field_512;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static int method_1119(Zc var0, int var1) {
      return var0.field_512 = var1;
   }

   public static U method_1120(Zc var0) {
      return var0.field_508;
   }

   public static t method_1121(Zc var0) {
      return var0.field_497;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static int method_1123(Zc var0, int var1) {
      return var0.field_499 = var1;
   }

   public static Random method_1124(Zc var0) {
      return var0.field_502;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static EG method_1126(Zc var0) {
      return var0.field_507;
   }

   public static boolean method_1127(Zc var0) {
      return var0.field_501;
   }

   public static double method_1128(Zc var0) {
      return var0.field_505;
   }

   public static t method_1129(Zc var0) {
      return var0.field_500;
   }

   public static boolean method_1130(Zc var0, boolean var1) {
      return var0.field_501 = var1;
   }

   public static U method_1131(Zc var0) {
      return var0.field_506;
   }

   public static double method_1132(Zc var0, double var1) {
      return var0.field_505 = var1;
   }

   public static ga method_1133(Zc var0) {
      return var0.field_503;
   }

   public static int method_1134(Zc var0) {
      return var0.field_499;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static U method_1136(Zc var0) {
      return var0.field_510;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static t method_1138(Zc var0) {
      return var0.field_498;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
      if (f$e.player != null) {
         this.field_505 = f$e.player.posY - 1.0D;
         this.field_501 = false;
      }

      if ((Boolean)this.field_504.method_3690()) {
         EI.method_888();
      }

   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static U method_1152(Zc var0) {
      return var0.field_513;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_3745() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_3747() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4288() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4291() {
      return f$e;
   }

   public static Minecraft method_4292() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_3757() {
      return f$e;
   }

   public static Minecraft method_4294() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_3761() {
      return f$e;
   }

   public static Minecraft method_4296() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4298() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public static Minecraft method_4300() {
      return f$e;
   }

   public static Minecraft method_3767() {
      return f$e;
   }

   public static Minecraft method_4301() {
      return f$e;
   }

   public static Minecraft method_3769() {
      return f$e;
   }

   public Zc() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Flight";
      var10002[1] = "Fly";
      super("Flight", var10002, true, -4545358, bE.MOVEMENT);
      Boolean var3 = true;
      String[] var4 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Animation";
      var4[1] = "ani";
      this.field_497 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Damage";
      var4[1] = "d";
      var4[2] = "dmg";
      this.field_504 = new t(var3, var4);
      var3 = false;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Glide";
      var4[1] = "g";
      this.field_511 = new t(var3, var4);
      var3 = false;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Anti Fall Damage";
      var4[1] = "Anti-Fall-Damage";
      var4[2] = "AntiFallDamage";
      var4[3] = "NoFallDamage";
      var4[4] = "NoFall";
      this.field_500 = new t(var3, var4);
      var3 = false;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Anti Kick";
      var4[1] = "Anti-Kick";
      var4[2] = "ak";
      var4[3] = "antikick";
      this.field_498 = new t(var3, var4);
      Double var5 = 1.155044749E-314D;
      Double var6 = 0.0D;
      Double var7 = 0.0D;
      Double var11 = 1.273197475E-314D;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "GlideSpeed";
      var10007[1] = "Glide-Speed";
      var10007[2] = "gs";
      var10007[3] = "glidespeed";
      this.field_513 = new U(var5, var6, var7, var11, var10007);
      var5 = 0.0D;
      var6 = 1.273197475E-314D;
      var7 = 0.0D;
      String[] var12 = new String[3];
      boolean var10 = true;
      byte var13 = 1;
      var12[0] = "Speed";
      var12[1] = "spd";
      var12[2] = "s";
      this.field_508 = new U(var5, var6, var7, var12);
      var5 = 3.395193264E-315D;
      var6 = 0.0D;
      var7 = 0.0D;
      var11 = 5.941588215E-315D;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "AACY";
      var10007[1] = "y";
      var10007[2] = "aac";
      this.field_509 = new U(var5, var6, var7, var11, var10007);
      var5 = 1.0D;
      var6 = 0.0D;
      var7 = 0.0D;
      var11 = 1.273197475E-314D;
      var10007 = new String[5];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "GommeDown";
      var10007[1] = "Down";
      var10007[2] = "DownAmount";
      var10007[3] = "GoDown";
      var10007[4] = "downvalue";
      this.field_510 = new U(var5, var6, var7, var11, var10007);
      var5 = 1.273197475E-314D;
      var6 = 0.0D;
      var7 = 1.0D;
      var11 = 1.273197475E-314D;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "GommeSpeed";
      var10007[1] = "GomSped";
      var10007[2] = "GommeSped";
      this.field_506 = new U(var5, var6, var7, var11, var10007);
      oA var8 = oA.Normal;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Mode";
      var4[1] = "Type";
      var4[2] = "fly";
      this.field_503 = new ga(var8, var4);
      this.field_507 = new EG();
      this.field_502 = new Random();
      t[] var10001 = new t[11];
      boolean var2 = true;
      byte var9 = 1;
      var10001[0] = this.field_504;
      var10001[1] = this.field_503;
      var10001[2] = this.field_513;
      var10001[3] = this.field_497;
      var10001[4] = this.field_511;
      var10001[5] = this.field_508;
      var10001[6] = this.field_509;
      var10001[7] = this.field_506;
      var10001[8] = this.field_510;
      var10001[9] = this.field_500;
      var10001[10] = this.field_498;
      this.f$c(var10001);
      ja[] var1 = new ja[5];
      var2 = true;
      var9 = 1;
      var1[0] = new Ic(this);
      var1[1] = new zB(this);
      var1[2] = new gd(this);
      var1[3] = new Fc(this);
      var1[4] = new Rb(this);
      this.method_2383(var1);
   }
}

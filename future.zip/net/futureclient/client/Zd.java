package net.futureclient.client;

import net.minecraft.util.math.RayTraceResult;

public class Zd extends Hg {
   private RayTraceResult field_496;

   public Zd(RayTraceResult var1) {
      this.field_496 = var1;
   }

   public RayTraceResult method_1108() {
      return this.field_496;
   }

   public void method_1109(RayTraceResult var1) {
      this.field_496 = var1;
   }
}

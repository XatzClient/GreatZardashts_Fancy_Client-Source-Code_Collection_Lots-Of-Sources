package net.futureclient.client;

public enum Ze {
   Distance,
   Smart,
   Health;

   private static final Ze[] field_612;

   static {
      Ze[] var10000 = new Ze[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Health;
      var10000[1] = Distance;
      var10000[2] = Smart;
      field_612 = var10000;
   }
}

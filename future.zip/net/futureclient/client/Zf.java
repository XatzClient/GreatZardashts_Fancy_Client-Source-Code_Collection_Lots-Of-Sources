package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class Zf extends ka {
   private ga field_604;
   private EG field_605;
   private t field_606;
   private U field_607;
   private U field_608;

   public static Minecraft method_4242() {
      return f$e;
   }

   public void method_4314() {
      super.method_4314();
      f$e.player.noClip = false;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static boolean method_1344(Zf var0) {
      return var0.method_4325();
   }

   public static U method_1345(Zf var0) {
      return var0.field_608;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static EG method_1347(Zf var0) {
      return var0.field_605;
   }

   public static ga method_1348(Zf var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.field_604;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   private boolean method_4325() {
      int var1;
      for(int var10000 = var1 = MathHelper.floor(f$e.player.getEntityBoundingBox().minX); var10000 < MathHelper.floor(f$e.player.getEntityBoundingBox().maxX) + 1; var10000 = var1) {
         int var2;
         for(var10000 = var2 = MathHelper.floor(f$e.player.getEntityBoundingBox().minY); var10000 < MathHelper.floor(f$e.player.getEntityBoundingBox().maxY) + 1; var10000 = var2) {
            int var3;
            for(var10000 = var3 = MathHelper.floor(f$e.player.getEntityBoundingBox().minZ); var10000 < MathHelper.floor(f$e.player.getEntityBoundingBox().maxZ) + 1; var10000 = var3) {
               if (f$e.world.getBlockState(new BlockPos(var1, var2, var3)).getMaterial().blocksMovement()) {
                  AxisAlignedBB var4 = new AxisAlignedBB((double)var1, (double)var2, (double)var3, (double)(var1 + 1), (double)(var2 + 1), (double)(var3 + 1));
                  if (f$e.player.getEntityBoundingBox().intersects(var4)) {
                     return true;
                  }
               }

               ++var3;
            }

            ++var2;
         }

         ++var1;
      }

      return false;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
      if ((Boolean)this.field_606.method_3690() && f$e.player != null && f$e.world != null) {
         double var1 = Math.cos(Math.toRadians((double)(f$e.player.rotationYaw + 90.0F)));
         double var3 = Math.sin(Math.toRadians((double)(f$e.player.rotationYaw + 90.0F)));
         f$e.player.setPosition(f$e.player.posX + 1.0D * this.field_607.method_3692().doubleValue() * var1 + 0.0D * this.field_607.method_3692().doubleValue() * var3, f$e.player.posY, f$e.player.posZ + (1.0D * this.field_607.method_3692().doubleValue() * var3 - 0.0D * this.field_607.method_3692().doubleValue() * var1));
      }

   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4288() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4291() {
      return f$e;
   }

   public static Minecraft method_4292() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_4294() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_4296() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4298() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public static Minecraft method_4300() {
      return f$e;
   }

   public static Minecraft method_4301() {
      return f$e;
   }

   public Zf() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Phase";
      var10002[1] = "noclip";
      var10002[2] = "Phae";
      var10002[3] = "DoorGiveaway";
      super("Phase", var10002, true, -4550444, bE.EXPLOITS);
      tF var3 = tF.Normal;
      String[] var6 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Mode";
      var6[1] = "m";
      this.field_604 = new ga(var3, var6);
      Boolean var4 = false;
      var6 = new String[3];
      var10005 = true;
      var10006 = 1;
      var6[0] = "AutoClip";
      var6[1] = "ac";
      var6[2] = "clip";
      this.field_606 = new t(var4, var6);
      Double var5 = 1.561788902E-314D;
      Double var8 = 1.748524532E-314D;
      Double var9 = 0.0D;
      Double var10 = 1.748524532E-314D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Blocks";
      var10007[1] = "block";
      var10007[2] = "b";
      this.field_607 = new U(var5, var8, var9, var10, var10007);
      var5 = 1.273197475E-314D;
      var8 = 0.0D;
      var9 = 0.0D;
      var10 = 1.273197475E-314D;
      var10007 = new String[1];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Distance";
      this.field_608 = new U(var5, var8, var9, var10, var10007);
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_607;
      var10001[1] = this.field_608;
      var10001[2] = this.field_606;
      var10001[3] = this.field_604;
      this.f$c(var10001);
      this.field_605 = new EG();
      ja[] var1 = new ja[4];
      var2 = true;
      var7 = 1;
      var1[0] = new nf(this);
      var1[1] = new Ye(this);
      var1[2] = new oe(this);
      var1[3] = new pF(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public class aA extends ja {
   public final Nc field_613;

   public aA(Nc var1) {
      this.field_613 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      if (var1.method_326().equals(HD.PRE)) {
         Nc var10000 = this.field_613;
         Object[] var10002 = new Object[1];
         boolean var10003 = true;
         byte var10004 = 1;
         var10002[0] = this.field_613.field_272.method_3690();
         var10000.method_616(String.format("Step §7[§F%s§7]", var10002));
         bA var2;
         if ((var2 = (bA)YH.method_1211().method_1205().method_2166(bA.class)) == null || !var2.f$c() || ((JB)var2.field_1183.method_3690()).equals(JB.Alerithe) || ((JB)var2.field_1183.method_3690()).equals(JB.OnGround) || ((JB)var2.field_1183.method_3690()).equals(JB.OnGroundOld) || ((JB)var2.field_1183.method_3690()).equals(JB.PhysicsCalc) || ((JB)var2.field_1183.method_3690()).equals(JB.Vanilla)) {
            if ((Boolean)this.field_613.field_267.method_3690() && ((d)Nc.method_4280().player).isPrevOnGround() && !Nc.method_4279().player.onGround && Nc.method_4271().player.motionY <= 0.0D && !Nc.method_4277().player.world.getCollisionBoxes(Nc.method_4278().player, Nc.method_4275().player.getEntityBoundingBox().offset(0.0D, 1.867356296E-314D, 0.0D)).isEmpty() && !fI.f$c() && !Nc.method_4270().player.isInWater() && Nc.method_594(this.field_613).method_817(1000L)) {
               Nc.method_4267().player.motionY = 0.0D;
            }

         }
      }
   }
}

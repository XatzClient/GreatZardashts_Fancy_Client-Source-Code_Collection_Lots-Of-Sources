package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;

public class aB extends ka {
   private final t field_615;
   private static final MovementInput field_616;

   static {
      field_616 = new Oc(f$e.gameSettings);
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public void method_4314() {
      super.method_4314();
      if (f$e.player != null && f$e.player.movementInput.getClass() == field_616.getClass()) {
         MovementInputFromOptions var1;
         (var1 = new MovementInputFromOptions(f$e.gameSettings)).updatePlayerMoveState();
         f$e.player.movementInput = var1;
      }

   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static t method_1392(aB var0) {
      return var0.field_615;
   }

   public static MovementInput method_3425() {
      return field_616;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public aB() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AutoWalk";
      var10002[1] = "AutoRun";
      super("AutoWalk", var10002, true, -6710870, bE.MOVEMENT);
      Boolean var3 = true;
      String[] var5 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Lock";
      var5[1] = "lock";
      var5[2] = "l";
      this.field_615 = new t(var3, var5);
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_615;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var4 = 1;
      var1[0] = new JC(this);
      var1[1] = new PA(this);
      this.method_2383(var1);
   }
}

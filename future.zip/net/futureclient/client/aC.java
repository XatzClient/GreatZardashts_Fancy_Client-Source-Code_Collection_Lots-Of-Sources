package net.futureclient.client;

public class aC extends ja {
   public final Pb field_614;

   public aC(Pb var1) {
      this.field_614 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (Pb.method_1531(this.field_614).method_3692().doubleValue() > 0.0D) {
         ((d)Pb.method_4319().player).setHorseJumpPower(1.0F);
      }

   }
}

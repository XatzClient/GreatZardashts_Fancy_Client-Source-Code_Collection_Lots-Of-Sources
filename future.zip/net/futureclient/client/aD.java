package net.futureclient.client;

import java.util.Random;
import net.minecraft.client.Minecraft;

public class aD extends ka {
   private float field_618;
   private Random field_619;
   private float field_620;
   private ga field_621;
   private U field_622;
   private float field_623;
   private int field_624;
   private ga field_625;
   private boolean field_626;
   private U field_627;
   private U field_628;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static float method_1398(aD var0, float var1) {
      return var0.field_623 = var1;
   }

   public static boolean method_1399(aD var0) {
      return var0.field_626;
   }

   public static ga method_1400(aD var0) {
      return var0.field_625;
   }

   public static float method_1401(aD var0) {
      return var0.field_620;
   }

   public static U method_1402(aD var0) {
      return var0.field_628;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static boolean method_1404(aD var0) {
      return var0.method_4325();
   }

   public static U method_1405(aD var0) {
      return var0.field_627;
   }

   public static boolean method_1406(aD var0, boolean var1) {
      return var0.field_626 = var1;
   }

   public static float method_1407(aD var0) {
      return var0.field_623;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Random method_1409(aD var0) {
      return var0.field_619;
   }

   public static int method_1410(aD var0, int var1) {
      return var0.field_624 = var1;
   }

   public static float method_1411(aD var0, float var1) {
      return var0.field_618 = var1;
   }

   public static ga method_1412(aD var0) {
      return var0.field_621;
   }

   public static int method_1413(aD var0) {
      return var0.field_624;
   }

   public static float method_1414(aD var0) {
      return var0.field_618;
   }

   public static U method_1415(aD var0) {
      return var0.field_622;
   }

   private boolean method_4325() {
      return !f$e.gameSettings.keyBindAttack.isKeyDown() && !f$e.gameSettings.keyBindUseItem.isKeyDown();
   }

   public static float method_1417(aD var0, float var1) {
      return var0.field_620 = var1;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public aD() {
      String[] var10002 = new String[6];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "AntiAim";
      var10002[1] = "AA";
      var10002[2] = "Retard";
      var10002[3] = "Derp";
      var10002[4] = "Retar";
      var10002[5] = "Retad";
      super("AntiAim", var10002, true, -14303062, bE.MISCELLANEOUS);
      AE var3 = AE.Off;
      String[] var6 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Pitch";
      var6[1] = "p";
      this.field_625 = new ga(var3, var6);
      Me var4 = Me.Off;
      var6 = new String[2];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Yaw";
      var6[1] = "ry";
      this.field_621 = new ga(var4, var6);
      Float var5 = 0.0F;
      Float var7 = -180.0F;
      Float var9 = 180.0F;
      Double var10 = 1.273197475E-314D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Yaw Add";
      var10007[1] = "yawadd";
      var10007[2] = "ya";
      this.field_628 = new U(var5, var7, var9, var10, var10007);
      var5 = 40.0F;
      var7 = 1.0F;
      var9 = 40.0F;
      Integer var11 = 1;
      var10007 = new String[6];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Spin Speed";
      var10007[1] = "spinspeed";
      var10007[2] = "speed";
      var10007[3] = "ss";
      var10007[4] = "spin";
      var10007[5] = "spin-speed";
      this.field_622 = new U(var5, var7, var9, var11, var10007);
      var5 = 2.0F;
      var7 = 2.0F;
      var9 = 20.0F;
      var11 = 1;
      var10007 = new String[7];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Flip Ticks";
      var10007[1] = "flipticks";
      var10007[2] = "flipspeed";
      var10007[3] = "ft";
      var10007[4] = "flip";
      var10007[5] = "flip-speed";
      var10007[6] = "flip-tick";
      this.field_627 = new U(var5, var7, var9, var11, var10007);
      this.field_619 = new Random();
      t[] var10001 = new t[5];
      boolean var2 = true;
      byte var8 = 1;
      var10001[0] = this.field_625;
      var10001[1] = this.field_621;
      var10001[2] = this.field_628;
      var10001[3] = this.field_622;
      var10001[4] = this.field_627;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var8 = 1;
      var1[0] = new Fe(this);
      this.method_2383(var1);
   }
}

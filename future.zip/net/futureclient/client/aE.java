package net.futureclient.client;

public class aE {
   public static final int[] field_617;

   static {
      int[] var10000 = new int[HD.values().length];
      boolean var10001 = true;
      byte var10002 = 1;
      field_617 = var10000;
      var10000 = field_617;
      HD var2 = HD.PRE;

      try {
         var10000[var2.ordinal()] = 1;
      } catch (NoSuchFieldError var1) {
      }
   }
}

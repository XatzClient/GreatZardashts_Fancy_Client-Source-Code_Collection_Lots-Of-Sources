package net.futureclient.client;

import net.minecraft.network.play.server.SPacketChat;

public class aF extends ja {
   public final fD field_629;

   public aF(fD var1) {
      this.field_629 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      String var2;
      if (var1.method_3084() instanceof SPacketChat && fD.method_3307(this.field_629).method_811(fD.method_3322(this.field_629).method_3692().floatValue() * 1000.0F) && (Boolean)fD.method_3336(this.field_629).method_3690() && (var2 = ((SPacketChat)var1.method_3084()).getChatComponent().getFormattedText()).contains("§d") && var2.contains(" whispers: ") && fD.method_3328(this.field_629).method_817(10000L)) {
         fD.method_4245().player.sendChatMessage((String)fD.method_3319(this.field_629).method_3690());
         fD.method_3328(this.field_629).method_814();
      }

   }
}

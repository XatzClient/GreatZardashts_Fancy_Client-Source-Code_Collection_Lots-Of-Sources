package net.futureclient.client;

import java.util.List;

public final class aa extends V {
   public aa(String... var1) {
      super((String[])var1, (ca)null);
   }

   public aa(List var1, String... var2) {
      super(var1, var2, (ca)null);
   }
}

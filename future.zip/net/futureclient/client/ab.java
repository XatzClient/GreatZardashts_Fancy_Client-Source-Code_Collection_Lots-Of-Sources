package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayer;

public class ab extends ja {
   public final bA field_1196;

   public ab(bA var1) {
      this.field_1196 = var1;
   }

   public void method_4241(je var1) {
      if (this.field_1196.field_1183.method_3690() == JB.Vhop && var1.method_3084() instanceof CPacketPlayer && bA.method_2868(this.field_1196)) {
         var1.f$c(true);
         bA.method_2880(this.field_1196, false);
      }

   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }
}

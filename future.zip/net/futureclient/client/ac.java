package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class ac extends ka {
   public t field_1186;
   private ga field_1187;
   public t field_1188;
   public t field_1189;
   public t field_1190;
   public t field_1191;
   public t field_1192;
   public t field_1193;
   public t field_1194;
   public t field_1195;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static ga method_3027(ac var0) {
      return var0.field_1187;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public ac() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NoRender";
      var10002[1] = "NoRend";
      var10002[2] = "Render";
      var10002[3] = "NoItems";
      super("NoRender", var10002, false, -15257121, bE.RENDER);
      Boolean var3 = false;
      String[] var4 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var4[0] = "Fire";
      var4[1] = "NoFire";
      var4[2] = "nf";
      this.field_1195 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "HurtCamera";
      var4[1] = "NoHurtcam";
      var4[2] = "nh";
      this.field_1194 = new t(var3, var4);
      var3 = false;
      var4 = new String[2];
      var10005 = true;
      var10006 = 1;
      var4[0] = "PumpkinOverlay";
      var4[1] = "Pumpkin";
      this.field_1193 = new t(var3, var4);
      var3 = true;
      var4 = new String[6];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Blindness";
      var4[1] = "NoBlindness";
      var4[2] = "Blind";
      var4[3] = "nb";
      var4[4] = "Nausea";
      var4[5] = "NoNausea";
      this.field_1189 = new t(var3, var4);
      var3 = false;
      var4 = new String[10];
      var10005 = true;
      var10006 = 1;
      var4[0] = "TotemAnimation";
      var4[1] = "NoTotemAnimation";
      var4[2] = "NoTotem";
      var4[3] = "NoTotim";
      var4[4] = "NoTotimAnimation";
      var4[5] = "NoTotemAnime";
      var4[6] = "NoTotimAnime";
      var4[7] = "NoTot";
      var4[8] = "nta";
      var4[9] = "nt";
      this.field_1192 = new t(var3, var4);
      var3 = false;
      var4 = new String[5];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Skylight";
      var4[1] = "Sky";
      var4[2] = "Light";
      var4[3] = "SkylightUpdates";
      var4[4] = "NoSkylight";
      this.field_1191 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Spawners";
      var4[1] = "Spawner";
      var4[2] = "Spawn";
      this.field_1188 = new t(var3, var4);
      var3 = false;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "SignText";
      var4[1] = "Signs";
      var4[2] = "SignsText";
      var4[3] = "st";
      this.field_1190 = new t(var3, var4);
      var3 = false;
      var4 = new String[3];
      var10005 = true;
      var10006 = 1;
      var4[0] = "Barriers";
      var4[1] = "Barrier";
      var4[2] = "Bar";
      this.field_1186 = new t(var3, var4);
      BA var5 = BA.Off;
      var4 = new String[4];
      var10005 = true;
      var10006 = 1;
      var4[0] = "NoItems";
      var4[1] = "items";
      var4[2] = "item";
      var4[3] = "ni";
      this.field_1187 = new ga(var5, var4);
      t[] var10001 = new t[10];
      boolean var2 = true;
      byte var6 = 1;
      var10001[0] = this.field_1187;
      var10001[1] = this.field_1195;
      var10001[2] = this.field_1194;
      var10001[3] = this.field_1193;
      var10001[4] = this.field_1189;
      var10001[5] = this.field_1192;
      var10001[6] = this.field_1191;
      var10001[7] = this.field_1188;
      var10001[8] = this.field_1190;
      var10001[9] = this.field_1186;
      this.f$c(var10001);
      ja[] var1 = new ja[10];
      var2 = true;
      var6 = 1;
      var1[0] = new Jd(this);
      var1[1] = new gA(this);
      var1[2] = new jc(this);
      var1[3] = new ic(this);
      var1[4] = new lc(this);
      var1[5] = new Yb(this);
      var1[6] = new NB(this);
      var1[7] = new iA(this);
      var1[8] = new rC(this);
      var1[9] = new Ad(this);
      this.f$c(var1);
   }
}

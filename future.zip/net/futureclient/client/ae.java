package net.futureclient.client;

import net.minecraft.client.multiplayer.WorldClient;

public class ae extends CD {
   private WorldClient field_1200;

   public ae(WorldClient var1) {
      this.field_1200 = var1;
   }

   public WorldClient method_3039() {
      return this.field_1200;
   }
}

package net.futureclient.client;

import net.minecraft.entity.item.EntityItem;

public class af extends CD {
   private EntityItem field_1211;

   public af(EntityItem var1) {
      this.field_1211 = var1;
   }

   public EntityItem method_3048() {
      return this.field_1211;
   }
}

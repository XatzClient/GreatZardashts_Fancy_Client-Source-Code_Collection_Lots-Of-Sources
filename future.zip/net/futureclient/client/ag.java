package net.futureclient.client;

public class ag extends CD {
}

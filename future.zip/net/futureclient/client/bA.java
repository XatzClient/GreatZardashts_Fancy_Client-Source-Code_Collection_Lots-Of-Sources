package net.futureclient.client;

import java.util.List;
import net.minecraft.client.Minecraft;

public class bA extends ka {
   private double field_1170;
   private int field_1171;
   private t field_1172;
   private U field_1173;
   private int field_1174;
   private EG field_1175;
   private int field_1176;
   private int field_1177;
   private double field_1178;
   private int field_1179;
   private boolean field_1180;
   private boolean field_1181;
   private t field_1182;
   public ga field_1183;
   private boolean field_1184;
   private int field_1185;

   public static int method_2845(bA var0, int var1) {
      return var0.field_1179 = var1;
   }

   public static boolean method_2846(bA var0) {
      return var0.field_1184;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public void method_4314() {
      lA var1;
      if ((var1 = (lA)YH.method_1211().method_1205().method_2166(lA.class)) != null && !var1.f$c()) {
         ((r)((w)f$e).getTimer()).method_3790(1.0F);
      }

      super.method_4314();
   }

   private boolean method_2849() {
      Nc var1 = (Nc)YH.method_1211().method_1205().method_2166(Nc.class);
      boolean var2 = false;
      List var3 = f$e.world.getCollisionBoxes(f$e.player, f$e.player.getEntityBoundingBox().grow(1.273197475E-314D, 0.0D, 1.273197475E-314D));
      if (var1 != null && var1.f$c() && !var3.isEmpty()) {
         var2 = true;
      }

      return f$e.player.onGround && !fI.f$c() && !fI.f$c(true);
   }

   public static int method_2850(bA var0) {
      return ++var0.field_1177;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static int method_2853(bA var0) {
      return ++var0.field_1179;
   }

   public static int method_2854(bA var0, int var1) {
      return var0.field_1174 = var1;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static double method_2856(bA var0) {
      return var0.field_1170;
   }

   public static int method_2857(bA var0) {
      return ++var0.field_1176;
   }

   public static boolean method_2858(bA var0) {
      return var0.method_2849();
   }

   public static int method_2859(bA var0, int var1) {
      return var0.field_1176 = var1;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static boolean method_2861(bA var0, boolean var1) {
      return var0.field_1181 = var1;
   }

   public static double method_2862(bA var0, double var1) {
      return var0.field_1170 = var1;
   }

   public static t method_2863(bA var0) {
      return var0.field_1182;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static int method_2865(bA var0) {
      return var0.field_1171;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static boolean method_2867(bA var0, boolean var1) {
      return var0.field_1184 = var1;
   }

   public static boolean method_2868(bA var0) {
      return var0.field_1180;
   }

   public static t method_2869(bA var0) {
      return var0.field_1172;
   }

   public static double method_2870(bA var0, double var1) {
      return var0.field_1178 = var1;
   }

   public static EG method_2871(bA var0) {
      return var0.field_1175;
   }

   public static double method_2872(bA var0) {
      return var0.field_1178;
   }

   public static U method_2873(bA var0) {
      return var0.field_1173;
   }

   public static int method_2874(bA var0, int var1) {
      return var0.field_1171 = var1;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static int method_2876(bA var0) {
      return var0.field_1174;
   }

   private boolean method_4325() {
      return !f$e.player.movementInput.forwardKeyDown && !f$e.player.movementInput.backKeyDown && !f$e.player.movementInput.rightKeyDown && !f$e.player.movementInput.leftKeyDown;
   }

   public static int method_2878(bA var0) {
      return var0.field_1176;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static boolean method_2880(bA var0, boolean var1) {
      return var0.field_1180 = var1;
   }

   public static int method_2881(bA var0, int var1) {
      return var0.field_1177 = var1;
   }

   public static boolean method_2882(bA var0) {
      return var0.method_4325();
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static int method_2887(bA var0) {
      return ++var0.field_1174;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static int method_2889(bA var0) {
      return var0.field_1179;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static int method_2891(bA var0) {
      return var0.field_1185;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static int method_2897(bA var0) {
      return var0.field_1177;
   }

   public static boolean method_2898(bA var0) {
      return var0.field_1181;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static int method_2900(bA var0, int var1) {
      return var0.field_1185 = var1;
   }

   private boolean method_2901() {
      return !f$e.player.collidedHorizontally && f$e.player.getFoodStats().getFoodLevel() > 6 && f$e.player.moveForward > 0.0F;
   }

   public void method_4326() {
      super.method_4326();
      if (f$e.player != null) {
         this.field_1170 = EI.method_854();
      }

      this.field_1171 = 2;
      this.field_1178 = 0.0D;
      this.field_1177 = 4;
      this.field_1179 = 1;
      this.field_1176 = 1;
      this.field_1185 = 2;
      this.field_1174 = 4;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_3745() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_3747() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4288() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_3752() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4291() {
      return f$e;
   }

   public static Minecraft method_4292() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_3757() {
      return f$e;
   }

   public static Minecraft method_4294() {
      return f$e;
   }

   public static Minecraft method_3759() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_3761() {
      return f$e;
   }

   public static Minecraft method_4296() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4298() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public static Minecraft method_4300() {
      return f$e;
   }

   public static Minecraft method_3767() {
      return f$e;
   }

   public static Minecraft method_4301() {
      return f$e;
   }

   public static Minecraft method_2930() {
      return f$e;
   }

   public static Minecraft method_3769() {
      return f$e;
   }

   public static Minecraft method_2932() {
      return f$e;
   }

   public static Minecraft method_2933() {
      return f$e;
   }

   public static Minecraft method_2934() {
      return f$e;
   }

   public static Minecraft method_2935() {
      return f$e;
   }

   public static Minecraft method_2936() {
      return f$e;
   }

   public static Minecraft method_2937() {
      return f$e;
   }

   public static Minecraft method_2938() {
      return f$e;
   }

   public static Minecraft method_2939() {
      return f$e;
   }

   public static Minecraft method_2940() {
      return f$e;
   }

   public static Minecraft method_2941() {
      return f$e;
   }

   public static Minecraft method_2942() {
      return f$e;
   }

   public static Minecraft method_2943() {
      return f$e;
   }

   public static Minecraft method_2944() {
      return f$e;
   }

   public static Minecraft method_2945() {
      return f$e;
   }

   public static Minecraft method_2946() {
      return f$e;
   }

   public static Minecraft method_3770() {
      return f$e;
   }

   public static Minecraft method_2948() {
      return f$e;
   }

   public static Minecraft method_2949() {
      return f$e;
   }

   public static Minecraft method_2950() {
      return f$e;
   }

   public static Minecraft method_3771() {
      return f$e;
   }

   public static Minecraft method_2952() {
      return f$e;
   }

   public static Minecraft method_3772() {
      return f$e;
   }

   public static Minecraft method_2954() {
      return f$e;
   }

   public static Minecraft method_2955() {
      return f$e;
   }

   public static Minecraft method_2956() {
      return f$e;
   }

   public static Minecraft method_2957() {
      return f$e;
   }

   public static Minecraft method_2958() {
      return f$e;
   }

   public static Minecraft method_2959() {
      return f$e;
   }

   public static Minecraft method_2960() {
      return f$e;
   }

   public static Minecraft method_2961() {
      return f$e;
   }

   public static Minecraft method_2962() {
      return f$e;
   }

   public static Minecraft method_3773() {
      return f$e;
   }

   public static Minecraft method_2964() {
      return f$e;
   }

   public static Minecraft method_2965() {
      return f$e;
   }

   public static Minecraft method_3774() {
      return f$e;
   }

   public static Minecraft method_2967() {
      return f$e;
   }

   public static Minecraft method_2968() {
      return f$e;
   }

   public static Minecraft method_2969() {
      return f$e;
   }

   public static Minecraft method_2970() {
      return f$e;
   }

   public static Minecraft method_2971() {
      return f$e;
   }

   public static Minecraft method_2972() {
      return f$e;
   }

   public static Minecraft method_2973() {
      return f$e;
   }

   public static Minecraft method_2974() {
      return f$e;
   }

   public static Minecraft method_2975() {
      return f$e;
   }

   public static Minecraft method_2976() {
      return f$e;
   }

   public static Minecraft method_2977() {
      return f$e;
   }

   public static Minecraft method_2978() {
      return f$e;
   }

   public static Minecraft method_2979() {
      return f$e;
   }

   public static Minecraft method_2980() {
      return f$e;
   }

   public static Minecraft method_2981() {
      return f$e;
   }

   public static Minecraft method_2982() {
      return f$e;
   }

   public static Minecraft method_2983() {
      return f$e;
   }

   public static Minecraft method_2984() {
      return f$e;
   }

   public static Minecraft method_2985() {
      return f$e;
   }

   public static Minecraft method_3775() {
      return f$e;
   }

   public static Minecraft method_2987() {
      return f$e;
   }

   public static Minecraft method_2988() {
      return f$e;
   }

   public static Minecraft method_2989() {
      return f$e;
   }

   public static Minecraft method_2990() {
      return f$e;
   }

   public static Minecraft method_2991() {
      return f$e;
   }

   public static Minecraft method_2992() {
      return f$e;
   }

   public static Minecraft method_2993() {
      return f$e;
   }

   public static Minecraft method_2994() {
      return f$e;
   }

   public static Minecraft method_2995() {
      return f$e;
   }

   public static Minecraft method_2996() {
      return f$e;
   }

   public static Minecraft method_2997() {
      return f$e;
   }

   public static Minecraft method_2998() {
      return f$e;
   }

   public static Minecraft method_2999() {
      return f$e;
   }

   public static Minecraft method_3000() {
      return f$e;
   }

   public static Minecraft method_3001() {
      return f$e;
   }

   public static Minecraft method_3002() {
      return f$e;
   }

   public static Minecraft method_3003() {
      return f$e;
   }

   public static Minecraft method_3004() {
      return f$e;
   }

   public static Minecraft method_3005() {
      return f$e;
   }

   public static Minecraft method_3006() {
      return f$e;
   }

   public static Minecraft method_3776() {
      return f$e;
   }

   public static Minecraft method_3008() {
      return f$e;
   }

   public static Minecraft method_3009() {
      return f$e;
   }

   public static Minecraft method_3010() {
      return f$e;
   }

   public static Minecraft method_3011() {
      return f$e;
   }

   public static Minecraft method_3012() {
      return f$e;
   }

   public static Minecraft method_3013() {
      return f$e;
   }

   public static Minecraft method_3014() {
      return f$e;
   }

   public static Minecraft method_3015() {
      return f$e;
   }

   public static Minecraft method_3016() {
      return f$e;
   }

   public static Minecraft method_3017() {
      return f$e;
   }

   public static Minecraft method_3018() {
      return f$e;
   }

   public static Minecraft method_3019() {
      return f$e;
   }

   public static Minecraft method_3020() {
      return f$e;
   }

   public static Minecraft method_3021() {
      return f$e;
   }

   public static Minecraft method_3022() {
      return f$e;
   }

   public static Minecraft method_3023() {
      return f$e;
   }

   public bA() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Speed";
      var10002[1] = "Sped";
      var10002[2] = "fastrun";
      super("Speed", var10002, true, -13131324, bE.MOVEMENT);
      this.field_1181 = false;
      JB var3 = JB.Strafe;
      String[] var6 = new String[6];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Mode";
      var6[1] = "m";
      var6[2] = "NCP";
      var6[3] = "AAC";
      var6[4] = "NCPSpeed";
      var6[5] = "NCPMode";
      this.field_1183 = new ga(var3, var6);
      Double var4 = 0.0D;
      Double var7 = 1.273197475E-314D;
      Double var9 = 0.0D;
      String[] var10 = new String[3];
      boolean var10007 = true;
      byte var10008 = 1;
      var10[0] = "Speed";
      var10[1] = "spd";
      var10[2] = "s";
      this.field_1173 = new U(var4, var7, var9, var10);
      Boolean var5 = false;
      var6 = new String[5];
      var10005 = true;
      var10006 = 1;
      var6[0] = "SpeedInWater";
      var6[1] = "Water";
      var6[2] = "waterspeed";
      var6[3] = "watermove";
      var6[4] = "stopinwater";
      this.field_1182 = new t(var5, var6);
      var5 = true;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "UseTimer";
      var6[1] = "Timer";
      var6[2] = "TimerSpeed";
      var6[3] = "UseTim";
      this.field_1172 = new t(var5, var6);
      this.field_1175 = new EG();
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var8 = 1;
      var10001[0] = this.field_1183;
      var10001[1] = this.field_1173;
      var10001[2] = this.field_1182;
      var10001[3] = this.field_1172;
      this.f$c(var10001);
      ja[] var1 = new ja[6];
      var2 = true;
      var8 = 1;
      var1[0] = new hA(this);
      var1[1] = new mc(this);
      var1[2] = new LA(this);
      var1[3] = new ab(this);
      var1[4] = new yB(this);
      var1[5] = new Yc(this);
      this.f$c(var1);
   }
}

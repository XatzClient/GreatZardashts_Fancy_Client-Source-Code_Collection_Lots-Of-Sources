package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class bB extends ka {
   private EG field_1167;
   private ga field_1168;
   private boolean field_1169;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static EG method_2814(bB var0) {
      return var0.field_1167;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static boolean method_2816(bB var0) {
      return var0.field_1169;
   }

   public static boolean method_2817(bB var0, boolean var1) {
      return var0.field_1169 = var1;
   }

   public static ga method_2818(bB var0) {
      return var0.field_1168;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public bB() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Jesus";
      var10002[1] = "WaterWalk";
      var10002[2] = "Dolphin";
      var10002[3] = "Trampoline";
      super("Jesus", var10002, true, -7807509, bE.MOVEMENT);
      this.field_1167 = new EG();
      Qd var3 = Qd.Solid;
      String[] var5 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Mode";
      var5[1] = "m";
      this.field_1168 = new ga(var3, var5);
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_1168;
      this.f$c(var10001);
      ja[] var1 = new ja[5];
      var2 = true;
      var4 = 1;
      var1[0] = new XA(this);
      var1[1] = new pb(this);
      var1[2] = new Id(this);
      var1[3] = new id(this);
      var1[4] = new sc(this);
      this.f$c(var1);
   }
}

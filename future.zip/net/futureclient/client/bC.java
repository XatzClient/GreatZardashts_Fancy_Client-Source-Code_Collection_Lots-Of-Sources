package net.futureclient.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;

public class bC extends GuiScreen {
   public double field_1197 = 1.0D;
   private static bC field_1198;
   private ArrayList field_1199 = new ArrayList();

   public bC() {
      if (this.method_3034().isEmpty()) {
         this.method_3038();
      }

   }

   private void method_3032(int var1, int var2, int var3, kB var4) {
      var4.method_2135((int)((double)var1 * (1.0D / this.field_1197)), (int)((double)var2 * (1.0D / this.field_1197)), var3);
   }

   private static void method_3033(List var0, int var1, kB var2) {
      var0.add((int)var2.method_2138());
      var2.method_2142(var1, -(Integer)Collections.max(var0));
   }

   public ArrayList method_3034() {
      return this.field_1199;
   }

   private void method_3035(int var1, int var2, int var3, kB var4) {
      var4.method_2128((int)((double)var1 * (1.0D / this.field_1197)), (int)((double)var2 * (1.0D / this.field_1197)), var3);
   }

   private void method_3036(int var1, int var2, float var3, kB var4) {
      var4.method_2146((int)((double)var1 * (1.0D / this.field_1197)), (int)((double)var2 * (1.0D / this.field_1197)), var3);
   }

   public static bC method_3037() {
      return field_1198 == null ? (field_1198 = new bC()) : field_1198;
   }

   public boolean doesGuiPauseGame() {
      return false;
   }

   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      int var1;
      if ((var1 = Mouse.getEventDWheel()) != 0) {
         if (var1 > 1) {
            var1 = 1;
         }

         if (var1 < -1) {
            var1 = -1;
         }

         if (!isShiftKeyDown()) {
            var1 *= 25;
         }

         ArrayList var2 = new ArrayList();
         this.field_1199.forEach(var2.accept<invokedynamic>(var2, var1));
      }

   }

   public void drawScreen(int var1, int var2, float var3) {
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      Di.method_901(0.0F, (float)0, (float)this.mc.displayWidth, (float)this.mc.displayHeight, 536870912, -1879048192);
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
      this.field_1199.forEach(this.accept<invokedynamic>(this, var1, var2, var3));
   }

   public void mouseReleased(int var1, int var2, int var3) {
      this.field_1199.forEach(this.accept<invokedynamic>(this, var1, var2, var3));
   }

   public void mouseClicked(int var1, int var2, int var3) {
      this.field_1199.forEach(this.accept<invokedynamic>(this, var1, var2, var3));
   }

   private void method_3038() {
      int var1 = -84;
      bE[] var2;
      int var3 = (var2 = bE.values()).length;

      int var4;
      for(int var10000 = var4 = 0; var10000 < var3; var10000 = var4) {
         bE var5 = var2[var4];
         ArrayList var6 = this.field_1199;
         var1 += 90;
         String var7 = var5.method_3044();
         ++var4;
         var6.add(new jC(this, var7, var1, 4, true, var5));
      }

      var1 += 90;
      this.field_1199.add(new eB(this, "Other", var1, 4, true));
   }
}

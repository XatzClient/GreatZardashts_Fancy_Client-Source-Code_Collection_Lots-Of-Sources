package net.futureclient.client;

import net.minecraft.network.Packet;

public final class bD extends nD {
   public bD(Packet var1) {
      super(var1);
   }
}

package net.futureclient.client;

public enum bE {
   MOVEMENT("Movement"),
   RENDER("Render"),
   COMBAT("Combat"),
   WORLD("World"),
   EXPLOITS("Exploits");

   private String field_1207;
   private static final bE[] field_1208;
   MISCELLANEOUS("Miscellaneous");

   private bE(String var3) {
      this.field_1207 = var3;
   }

   public String method_3044() {
      return this.field_1207;
   }

   static {
      bE[] var10000 = new bE[6];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = COMBAT;
      var10000[1] = EXPLOITS;
      var10000[2] = MISCELLANEOUS;
      var10000[3] = MOVEMENT;
      var10000[4] = RENDER;
      var10000[5] = WORLD;
      field_1208 = var10000;
   }
}

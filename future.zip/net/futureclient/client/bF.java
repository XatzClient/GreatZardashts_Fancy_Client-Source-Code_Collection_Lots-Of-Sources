package net.futureclient.client;

import java.util.List;

public class bF {
   public List field_1201;

   public void method_3798(Object var1) {
      this.field_1201.add(var1);
   }

   public Object method_3041(Object var1) {
      return this.field_1201.contains(var1) ? var1 : null;
   }

   public void method_3042(Object var1) {
      this.field_1201.remove(var1);
   }

   public List method_3043() {
      return this.field_1201;
   }
}

package net.futureclient.client;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class bH {
   private byte[] field_1210;

   public bH(String var1) {
      int var10000 = 0;
      super();
      byte[] var10002 = new byte[16];
      boolean var10003 = true;
      byte var10004 = 1;
      this.field_1210 = var10002;

      for(int var2 = 0; var10000 < 16; var10000 = var2) {
         byte[] var5 = this.field_1210;
         String var10001 = var1;

         try {
            var5[var2] = var10001.getBytes()[var2];
         } catch (Exception var4) {
         }

         ++var2;
      }

   }

   public byte[] method_3045(byte[] var1) throws Exception {
      Key var2 = this.method_3046();
      Cipher var3 = Cipher.getInstance("AES");
      var3.init(1, var2);
      return var3.doFinal(var1);
   }

   private Key method_3046() throws Exception {
      return new SecretKeySpec(this.field_1210, "AES");
   }

   public byte[] method_3047(byte[] var1) throws Exception {
      Key var2 = this.method_3046();
      Cipher var3 = Cipher.getInstance("AES");
      var3.init(2, var2);
      return var3.doFinal(var1);
   }
}

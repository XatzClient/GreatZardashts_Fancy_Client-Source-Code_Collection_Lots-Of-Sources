package net.futureclient.client;

import net.minecraft.util.BlockRenderLayer;

public class ba extends ja {
   public final Da field_1130;

   public ba(Da var1) {
      this.field_1130 = var1;
   }

   public void method_2760(Rf var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      if (!Da.method_838(this.field_1130, var1.method_2796())) {
         var1.method_1677(BlockRenderLayer.TRANSLUCENT);
      }

   }

   public void method_4312(CD var1) {
      this.method_2760((Rf)var1);
   }
}

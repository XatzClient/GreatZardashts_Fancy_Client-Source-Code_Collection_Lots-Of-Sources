package net.futureclient.client;

public class bb extends xb {
   public final xC field_1129;

   public bb(xC var1, String[] var2) {
      super(var2);
      this.field_1129 = var1;
   }

   public String method_4224() {
      return "&e[name]";
   }

   public String method_4228(String[] var1) {
      if (var1.length == 1) {
         String var2 = var1[0];
         xa var3;
         if ((var3 = this.field_1129.method_4246(var2)) == null) {
            return "Invalid waypoint entered.";
         } else {
            if (xC.method_4258(this.field_1129, var3)) {
               this.field_1129.field_1866.remove(var3);
            }

            Object[] var10001 = new Object[1];
            boolean var10002 = true;
            byte var10003 = 1;
            var10001[0] = var3.method_4207();
            return String.format("Removed waypoint &e%s&7.", var10001);
         }
      } else {
         return null;
      }
   }
}

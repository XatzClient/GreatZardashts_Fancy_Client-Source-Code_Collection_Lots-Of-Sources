package net.futureclient.client;

import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;

public class bc extends ja {
   public final Mb field_1133;

   public bc(Mb var1) {
      this.field_1133 = var1;
   }

   public void method_4183(Xe var1) {
      this.field_1133.field_177.forEach(this.accept<invokedynamic>(this));
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   private void method_2771(String var1) {
      int var2;
      for(int var10000 = var2 = 9; var10000 < ((Boolean)Mb.method_293(this.field_1133).method_3690() ? 45 : 36); var10000 = var2) {
         ItemStack var3;
         if (!(var3 = Mb.method_4281().player.inventoryContainer.getSlot(var2).getStack()).isEmpty() && var3.getDisplayName().toLowerCase().contains(var1.toLowerCase()) && Mb.method_294(this.field_1133).method_811(Mb.method_295(this.field_1133).method_3692().floatValue() * 1000.0F)) {
            Mb.method_4269().playerController.windowClick(0, var2, 0, ClickType.PICKUP, Mb.method_4242().player);
            Mb.method_4319().playerController.windowClick(0, -999, 0, ClickType.PICKUP, Mb.method_4315().player);
            Mb.method_294(this.field_1133).method_814();
         }

         ++var2;
      }

   }
}

package net.futureclient.client;

import java.awt.TrayIcon.MessageType;
import net.minecraft.network.play.server.SPacketChat;
import org.lwjgl.opengl.Display;

public class bd extends ja {
   public final YC field_1131;

   public bd(YC var1) {
      this.field_1131 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketChat && !Display.isActive()) {
         bd var10000;
         String var2;
         label41: {
            label40: {
               var2 = ((SPacketChat)var1.method_3084()).getChatComponent().getFormattedText();
               if ((Boolean)this.field_1131.field_814.method_3690() && !var2.contains("§d")) {
                  Object[] var10002 = new Object[1];
                  boolean var10003 = true;
                  byte var10004 = 1;
                  var10002[0] = YC.method_4319().player.getName();
                  if (var2.contains(String.format(" %s ", var10002))) {
                     if (!YC.method_2849() && YC.method_1845(this.field_1131).method_3405(10000L)) {
                        YH.method_1211().method_1208().field_1163.displayMessage("Name called in chat", "Your name has been written in chat.", MessageType.NONE);
                        if (((wb)YC.method_1843(this.field_1131).method_3690()).equals(wb.Once)) {
                           YC.method_1827(true);
                           var10000 = this;
                           break label41;
                        }
                     }
                     break label40;
                  }
               }

               YC.method_1827(false);
            }

            var10000 = this;
         }

         if ((Boolean)var10000.field_1131.field_812.method_3690() && var2.contains("§d") && var2.contains(" whispers: ")) {
            if (!YC.method_4325() && YC.method_1834(this.field_1131).method_3405(10000L)) {
               YH.method_1211().method_1208().field_1163.displayMessage("Private message received", "You have received a private message.", MessageType.NONE);
               if (((wb)YC.method_1843(this.field_1131).method_3690()).equals(wb.Once)) {
                  YC.method_1863(true);
                  return;
               }
            }
         } else {
            YC.method_1863(false);
         }
      }

   }
}

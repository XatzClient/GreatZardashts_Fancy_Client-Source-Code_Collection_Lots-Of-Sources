package net.futureclient.client;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class be extends CD {
   private final BlockPos field_1159;
   private AxisAlignedBB field_1160;
   private final Block field_1161;
   private final Entity field_1162;

   public be(Block var1, BlockPos var2, AxisAlignedBB var3) {
      this(var1, var2, (Entity)null, var3);
   }

   public be(Block var1, BlockPos var2, Entity var3, AxisAlignedBB var4) {
      this.field_1161 = var1;
      this.field_1159 = var2;
      this.field_1162 = var3;
      this.field_1160 = var4;
   }

   public Block method_2796() {
      return this.field_1161;
   }

   public AxisAlignedBB method_2797() {
      return this.field_1160;
   }

   public Entity method_2798() {
      return this.field_1162;
   }

   public BlockPos method_3153() {
      return this.field_1159;
   }

   public void method_2800(AxisAlignedBB var1) {
      this.field_1160 = var1;
   }
}

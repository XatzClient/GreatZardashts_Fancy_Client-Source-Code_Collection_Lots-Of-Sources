package net.futureclient.client;

public class bg extends ja {
   public final tD field_1165;

   public bg(tD var1) {
      this.field_1165 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2803((Re)var1);
   }

   public void method_2803(Re var1) {
      var1.f$c(true);
   }
}

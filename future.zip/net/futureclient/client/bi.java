package net.futureclient.client;

import java.nio.ByteBuffer;
import org.apache.logging.log4j.Level;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;

public abstract class bi {
   private int field_1144 = -1;
   public final int field_1145;
   public final int field_1146;
   public int field_1147 = -1;
   public static final double field_1148 = 0.0D;
   public int field_1149 = -1;
   public final int field_1150;
   private String field_1151;
   public int field_1152 = -1;
   public final int field_1153;
   private int field_1154 = -1;
   public final int field_1155;
   private int field_1156 = -1;
   private String field_1157;

   public bi(String var1, String var2, int var3, int var4, int var5, int var6, int var7) {
      this.field_1157 = var1;
      this.field_1151 = var2;
      this.field_1155 = var3;
      this.field_1150 = var4;
      this.field_1146 = var5;
      this.field_1145 = (int)((double)var6 * 0.0D);
      this.field_1153 = (int)((double)var7 * 0.0D);
      this.method_2790();
      this.method_2792();
   }

   public void method_2784() {
      GL11.glScaled(0.0D, 0.0D, 0.0D);
      GL11.glDisable(3553);
      GL11.glBegin(4);
      GL11.glTexCoord2d(0.0D, 1.0D);
      GL11.glVertex2d(0.0D, 0.0D);
      GL11.glTexCoord2d(0.0D, 0.0D);
      GL11.glVertex2d(0.0D, (double)this.field_1153);
      GL11.glTexCoord2d(1.0D, 0.0D);
      GL11.glVertex2d((double)this.field_1145, (double)this.field_1153);
      GL11.glTexCoord2d(1.0D, 0.0D);
      GL11.glVertex2d((double)this.field_1145, (double)this.field_1153);
      GL11.glTexCoord2d(1.0D, 1.0D);
      GL11.glVertex2d((double)this.field_1145, 0.0D);
      GL11.glTexCoord2d(0.0D, 1.0D);
      GL11.glVertex2d(0.0D, 0.0D);
      GL11.glEnd();
      GL11.glScaled(0.0D, 0.0D, 0.0D);
   }

   public static String method_2785(int var0) {
      return ARBShaderObjects.glGetInfoLogARB(var0, ARBShaderObjects.glGetObjectParameteriARB(var0, 35716));
   }

   public int method_2786() {
      return this.field_1154;
   }

   public int method_2787(String var1) {
      return ARBShaderObjects.glGetUniformLocationARB(this.field_1147, var1);
   }

   public abstract bi method_2788();

   public void method_2789() {
      if (this.field_1152 > -1) {
         EXTFramebufferObject.glDeleteRenderbuffersEXT(this.field_1152);
      }

      if (this.field_1149 > -1) {
         EXTFramebufferObject.glDeleteFramebuffersEXT(this.field_1149);
      }

      if (this.field_1154 > -1) {
         GL11.glDeleteTextures(this.field_1154);
      }

   }

   private void method_2790() {
      this.field_1149 = EXTFramebufferObject.glGenFramebuffersEXT();
      this.field_1154 = GL11.glGenTextures();
      this.field_1152 = EXTFramebufferObject.glGenRenderbuffersEXT();
      GL11.glBindTexture(3553, this.field_1154);
      GL11.glTexParameterf(3553, 10241, 9729.0F);
      GL11.glTexParameterf(3553, 10240, 9729.0F);
      GL11.glTexParameterf(3553, 10242, 10496.0F);
      GL11.glTexParameterf(3553, 10243, 10496.0F);
      GL11.glBindTexture(3553, 0);
      GL11.glBindTexture(3553, this.field_1154);
      GL11.glTexImage2D(3553, 0, 32856, this.field_1150, this.field_1146, 0, 6408, 5121, (ByteBuffer)null);
      EXTFramebufferObject.glBindFramebufferEXT(36160, this.field_1149);
      EXTFramebufferObject.glFramebufferTexture2DEXT(36160, 36064, 3553, this.field_1154, 0);
      EXTFramebufferObject.glBindRenderbufferEXT(36161, this.field_1152);
      EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, this.field_1150, this.field_1146);
      EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, this.field_1152);
      this.method_2793();
   }

   public static int method_2791(String var0, int var1) throws Exception {
      int var2 = 0;
      int var10000 = var1;

      Exception var6;
      label34: {
         boolean var10001;
         try {
            if ((var2 = ARBShaderObjects.glCreateShaderObjectARB(var10000)) == 0) {
               return 0;
            }
         } catch (Exception var5) {
            var6 = var5;
            var10001 = false;
            break label34;
         }

         var10000 = var2;
         String var7 = var0;

         try {
            ARBShaderObjects.glShaderSourceARB(var10000, var7);
            ARBShaderObjects.glCompileShaderARB(var2);
            if (ARBShaderObjects.glGetObjectParameteriARB(var2, 35713) == 0) {
               throw new RuntimeException((new StringBuilder()).insert(0, "Error creating shader: ").append(method_2785(var2)).toString());
            }

            return var2;
         } catch (Exception var4) {
            var6 = var4;
            var10001 = false;
         }
      }

      Exception var3 = var6;
      ARBShaderObjects.glDeleteObjectARB(var2);
      throw var3;
   }

   private void method_2792() {
      if (this.field_1147 == -1) {
         label37: {
            Exception var5;
            label36: {
               this.field_1147 = ARBShaderObjects.glCreateProgramObjectARB();
               String var1;
               boolean var6;
               if (this.field_1144 == -1) {
                  var1 = "#version 120 \nvoid main() { \ngl_TexCoord[0] = gl_MultiTexCoord0; \ngl_Position = gl_ModelViewProjectionMatrix * gl_Vertex; \n}";
                  bi var10000 = this;
                  String var10001 = var1;
                  char var10002 = '謱';

                  try {
                     var10000.field_1144 = method_2791(var10001, var10002);
                  } catch (Exception var3) {
                     var5 = var3;
                     var6 = false;
                     break label36;
                  }
               }

               try {
                  if (this.field_1156 == -1) {
                     var1 = "#version 120\n\nuniform sampler2D DiffuseSamper;\nuniform vec2 TexelSize;\nuniform int SampleRadius;\n\nvoid main()\n{\n    vec4 centerCol = texture2D(DiffuseSamper, gl_TexCoord[0].st);\n    \n    if(centerCol.a != 0.0F)\n    {\n        gl_FragColor = vec4(0, 0, 0, 0);\n        return;\n    }\n    float closest = SampleRadius * 1.0F;\n    for(int xo = -SampleRadius; xo <= SampleRadius; xo++) \n    {\n        for(int yo = -SampleRadius; yo <= SampleRadius; yo++) \n        {\n            vec4 currCol = texture2D(DiffuseSamper, gl_TexCoord[0].st + vec2(xo * TexelSize.x, yo * TexelSize.y));\n            if(currCol.r != 0.0F || currCol.g != 0.0F || currCol.b != 0.0F || currCol.a != 0.0F)\n            {\n                float currentDist = sqrt(xo * xo + yo * yo);\n                if(currentDist < closest)\n                {\n                    closest = currentDist;\n                }\n            }\n        }\n    }\n    float m = 2.0;\n    float fade = max(0, ((SampleRadius * 1.0F) - (closest - 1)) / (SampleRadius * 1.0F));\n    gl_FragColor = vec4(m - fade, m - fade, m - fade, fade);\n}";
                     this.field_1156 = method_2791(var1, 35632);
                  }
                  break label37;
               } catch (Exception var2) {
                  var5 = var2;
                  var6 = false;
               }
            }

            Exception var4 = var5;
            this.field_1144 = this.field_1147 = -1;
            this.field_1156 = -1;
            var4.printStackTrace();
         }

         if (this.field_1147 != -1) {
            ARBShaderObjects.glAttachObjectARB(this.field_1147, this.field_1144);
            ARBShaderObjects.glAttachObjectARB(this.field_1147, this.field_1156);
            ARBShaderObjects.glLinkProgramARB(this.field_1147);
            if (ARBShaderObjects.glGetObjectParameteriARB(this.field_1147, 35714) == 0) {
               la.method_2324().method_2323(Level.ERROR, method_2785(this.field_1147));
               return;
            }

            ARBShaderObjects.glValidateProgramARB(this.field_1147);
            if (ARBShaderObjects.glGetObjectParameteriARB(this.field_1147, 35715) == 0) {
               la.method_2324().method_2323(Level.ERROR, method_2785(this.field_1147));
               return;
            }

            ARBShaderObjects.glUseProgramObjectARB(0);
         }
      }

   }

   private void method_2793() {
      int var1;
      switch(var1 = EXTFramebufferObject.glCheckFramebufferStatusEXT(36160)) {
      case 36053:
         return;
      case 36054:
         throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT");
      case 36055:
         throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT");
      case 36056:
      default:
         throw new RuntimeException((new StringBuilder()).insert(0, "glCheckFramebufferStatusEXT returned unknown status:").append(var1).toString());
      case 36057:
         throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT");
      case 36058:
         throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT");
      case 36059:
         throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT");
      }
   }
}

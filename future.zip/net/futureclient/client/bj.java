package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;

public class bj {
   private float field_1134;
   private float field_1135;
   private int field_1136;
   private float field_1137;
   private float field_1138;
   private final EG field_1139 = new EG();
   private float field_1140;
   private float field_1141;
   private static final Minecraft field_1142 = Minecraft.getMinecraft();
   private boolean field_1143;

   public bj() {
      YH.method_1211().method_1212().method_1330(new eI(this));
      YH.method_1211().method_1212().method_1330(new Og(this));
      YH.method_1211().method_1212().method_1330(new Pi(this));
   }

   public static float method_2772(bj var0) {
      return var0.field_1140;
   }

   public static float method_2773(bj var0) {
      return var0.field_1141;
   }

   public static float method_2774(bj var0) {
      return var0.field_1135;
   }

   private void method_2775(float var1, float var2) {
      if (this.field_1136 != field_1142.player.ticksExisted) {
         this.field_1136 = field_1142.player.ticksExisted;
         this.field_1143 = var1 != field_1142.player.rotationPitch || var2 != field_1142.player.rotationYaw;
         this.method_2779(var1, var2);
      }

   }

   private float method_2776(EntityLivingBase var1, float var2, float var3) {
      EntityLivingBase var10000;
      float var4;
      float var9;
      label32: {
         var4 = var3;
         double var5 = var1.posX - var1.prevPosX;
         double var7 = var1.posZ - var1.prevPosZ;
         if ((float)(var5 * var5 + var7 * var7) > 0.0025000002F) {
            var9 = (float)MathHelper.atan2(var7, var5) * 57.295776F - 90.0F;
            float var10 = MathHelper.abs(MathHelper.wrapDegrees(var2) - var9);
            if (95.0F < var10 && var10 < 265.0F) {
               var4 = var9 - 180.0F;
               var10000 = var1;
               break label32;
            }

            var4 = var9;
         }

         var10000 = var1;
      }

      if (var10000.swingProgress > 0.0F) {
         var4 = var2;
      }

      var4 = var3 + MathHelper.wrapDegrees(var4 - var3) * 0.3F;
      if ((var9 = MathHelper.wrapDegrees(var2 - var4)) < -75.0F) {
         var9 = -75.0F;
      }

      if (var9 >= 75.0F) {
         var9 = 75.0F;
      }

      var4 = var2 - var9;
      if (var9 * var9 > 2500.0F) {
         var4 += var9 * 0.2F;
      }

      return var4;
   }

   public static EG method_2777(bj var0) {
      return var0.field_1139;
   }

   public static boolean method_2778(bj var0) {
      return var0.field_1143;
   }

   private void method_2779(float var1, float var2) {
      this.field_1141 = this.field_1134;
      this.field_1134 = var1;
      this.field_1138 = this.method_2776(field_1142.player, var2, this.field_1140 = this.field_1138);
      this.field_1135 = this.field_1137;
      this.field_1137 = var2;
   }

   public static void method_2780(bj var0, float var1, float var2) {
      var0.method_2775(var1, var2);
   }

   public static float method_2781(bj var0) {
      return var0.field_1137;
   }

   public static float method_2782(bj var0) {
      return var0.field_1138;
   }

   public static float method_2783(bj var0) {
      return var0.field_1134;
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class cB extends ka {
   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public cB() {
      String[] var10002 = new String[7];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NoWeather";
      var10002[1] = "NoWather";
      var10002[2] = "NoRain";
      var10002[3] = "AntiWeather";
      var10002[4] = "AntiRain";
      var10002[5] = "RainRemove";
      var10002[6] = "NoThunder";
      super("NoWeather", var10002, true, 10092543, bE.RENDER);
      ja[] var10001 = new ja[2];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new RA(this);
      var10001[1] = new tA(this);
      this.f$c(var10001);
   }
}

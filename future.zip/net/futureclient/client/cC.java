package net.futureclient.client;

public class cC extends ja {
   public final xC field_1128;

   public cC(xC var1) {
      this.field_1128 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2757((We)var1);
   }

   public void method_2757(We var1) {
      xa var2;
      if ((Boolean)xC.method_4251(this.field_1128).method_3690() && (var2 = this.field_1128.method_4246((new StringBuilder()).insert(0, var1.method_3453()).append("_logout_spot").toString())) != null && xC.method_4258(this.field_1128, var2)) {
         this.field_1128.field_1866.remove(var2);
      }

   }
}

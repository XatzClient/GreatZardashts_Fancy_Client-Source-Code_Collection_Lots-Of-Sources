package net.futureclient.client;

public class cF extends ja {
   public final He field_1158;

   public cF(He var1) {
      this.field_1158 = var1;
   }

   public void method_2794(lE var1) {
      if ((Boolean)He.method_102(this.field_1158).method_3690()) {
         He var10000 = this.field_1158;

         Exception var5;
         label35: {
            boolean var10001;
            try {
               if (He.method_92(var10000).containsKey(var1.method_2379().getDisplayName())) {
                  He.method_92(this.field_1158).put(var1.method_2379().getDisplayName(), (Integer)He.method_92(this.field_1158).get(var1.method_2379().getDisplayName()) + 1);
                  return;
               }
            } catch (Exception var4) {
               var5 = var4;
               var10001 = false;
               break label35;
            }

            var10000 = this.field_1158;

            try {
               He.method_92(var10000).put(var1.method_2379().getDisplayName(), 1);
               return;
            } catch (Exception var3) {
               var5 = var3;
               var10001 = false;
            }
         }

         Exception var2 = var5;
         var2.printStackTrace();
      }

   }

   public void method_4312(CD var1) {
      this.method_2794((lE)var1);
   }
}

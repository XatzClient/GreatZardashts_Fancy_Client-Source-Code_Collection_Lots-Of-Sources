package net.futureclient.client;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;

public class cH extends DataOutputStream {
   private bH field_1166;

   public cH(OutputStream var1, String var2) {
      super(var1);
      this.field_1166 = new bH(var2);
   }

   public cH(OutputStream var1) {
      super(var1);
   }

   public void method_2804(Oi var1) throws Exception {
      this.method_2807(var1, true);
   }

   public void method_2805(Oi var1) throws Exception {
      this.method_2807(var1, false);
   }

   public byte[] method_2806(byte[] var1) throws IOException {
      Deflater var2;
      (var2 = new Deflater()).setInput(var1);
      ByteArrayOutputStream var5 = new ByteArrayOutputStream(var1.length);
      Deflater var10000 = var2;
      var2.finish();
      byte[] var10001 = new byte[1024];
      boolean var10002 = true;
      byte var10003 = 1;
      byte[] var3 = var10001;

      while(!var10000.finished()) {
         var10000 = var2;
         int var4 = var2.deflate(var3);
         var5.write(var3, 0, var4);
      }

      var5.close();
      return var5.toByteArray();
   }

   public void method_2807(Oi var1, boolean var2) throws Exception {
      ByteArrayDataOutput var3 = ByteStreams.newDataOutput();
      var3.writeInt(var1.method_1871());
      var1.method_1873(var3);
      ByteArrayDataOutput var4 = ByteStreams.newDataOutput();
      byte[] var5 = var3.toByteArray();
      var5 = this.method_2806(var5);
      if (var2) {
         if (this.field_1166 == null) {
            throw new Exception("Crypto is null!");
         }

         var5 = this.method_2806(this.field_1166.method_3045(var5));
      }

      var4.writeInt(var5.length + 1);
      var4.writeBoolean(var2);
      var4.write(var5);
      this.write(var4.toByteArray());
   }
}

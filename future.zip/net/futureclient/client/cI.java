package net.futureclient.client;

import java.awt.AWTException;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.Level;

public class cI {
   public TrayIcon field_1163;
   public SystemTray field_1164;

   private void method_2801(ActionEvent var1) {
      ((YC)YH.method_1211().method_1205().method_2166(YC.class)).f$c(false);
      this.field_1164.remove(this.field_1163);
   }

   public cI() {
      if (!SystemTray.isSupported()) {
         ((YC)YH.method_1211().method_1205().method_2166(YC.class)).f$c(false);
         la.method_2324().method_2323(Level.WARN, "Your computer does not support system tray icons.");
         la.method_2324().method_2322("Your computer does not support system tray icons.");
      } else {
         ResourceLocation var10000 = new ResourceLocation("textures/future/icon.png");
         String var1 = var10000.getNamespace();
         String var2 = var10000.getPath();
         InputStream var6 = cI.class.getResourceAsStream((new StringBuilder()).insert(0, "/assets/").append(var1).append("/").append(var2).toString());
         BufferedImage var3 = null;
         InputStream var9 = var6;

         BufferedImage var10;
         label25: {
            try {
               var3 = ImageIO.read(var9);
            } catch (IOException var5) {
               var10 = var3;
               var5.printStackTrace();
               break label25;
            }

            var10 = var3;
         }

         if (var10 == null) {
            ((YC)YH.method_1211().method_1205().method_2166(YC.class)).f$c(false);
            la var13 = la.method_2324();
            Level var11 = Level.WARN;
            Object[] var10003 = new Object[1];
            boolean var10004 = true;
            byte var10005 = 1;
            var10003[0] = var2;
            var13.method_2323(var11, String.format("Failed to open %s", var10003));
            var13 = la.method_2324();
            Object[] var10002 = new Object[1];
            boolean var14 = true;
            byte var15 = 1;
            var10002[0] = var2;
            var13.method_2322(String.format("Failed to open %s", var10002));
         } else {
            this.field_1163 = new TrayIcon(var3, "Future");
            PopupMenu var7 = new PopupMenu();
            this.field_1164 = SystemTray.getSystemTray();
            this.field_1163.setToolTip((new StringBuilder()).insert(0, YH.field_548).append(" v").append(YH.field_540).append(" notifications").toString());
            MenuItem var8 = new MenuItem("Disable Notifications");
            var7.add(var8);
            var8.addActionListener(this.actionPerformed<invokedynamic>(this));
            this.field_1163.setPopupMenu(var7);
            SystemTray var12 = this.field_1164;
            TrayIcon var10001 = this.field_1163;

            try {
               var12.add(var10001);
            } catch (AWTException var4) {
               var4.printStackTrace();
            }
         }
      }
   }
}

package net.futureclient.client;

import java.util.Set;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketPlayerPosLook.EnumFlags;
import net.minecraft.util.math.BlockPos;

public class dd extends ja {
   public final md field_1212;

   public dd(md var1) {
      this.field_1212 = var1;
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketPlayerPosLook) {
         SPacketPlayerPosLook var2 = (SPacketPlayerPosLook)var1.method_3084();
         if (!md.method_4273().world.isBlockLoaded(new BlockPos(md.method_4277().player.lastTickPosX, md.method_4270().player.lastTickPosY, md.method_4267().player.lastTickPosZ), false) || !md.method_4281().world.isBlockLoaded(new BlockPos(md.method_4276().player.posX, md.method_4274().player.posY, md.method_4245().player.posZ), false)) {
            return;
         }

         md.method_2462(this.field_1212, var2.getYaw());
         md.method_2466(this.field_1212, var2.getPitch());
         Set var3 = var2.getFlags();
         if (var3.remove(EnumFlags.Y_ROT)) {
            md.method_2462(this.field_1212, md.method_2464(this.field_1212) + md.method_4242().player.rotationYaw);
         }

         if (var3.remove(EnumFlags.X_ROT)) {
            md.method_2466(this.field_1212, md.method_2465(this.field_1212) + md.method_4269().player.rotationPitch);
         }

         ((m)var2).setYaw(md.method_4315().player.rotationYaw);
         ((m)var2).setPitch(md.method_4319().player.rotationPitch);
      }

   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }
}

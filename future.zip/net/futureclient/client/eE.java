package net.futureclient.client;

import net.minecraft.client.Minecraft;

public final class eE extends ka {
   public static Minecraft method_4319() {
      return f$e;
   }

   public eE() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[3];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "NoMineAnimation";
      byte var2 = 1;
      var10006 = 1;
      var10002[1] = "NoBreakAnimation";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "animationdesync";
      var10004 = 1;
      var2 = 1;
      super("NoMineAnimation", var10002, true, 10454595, bE.EXPLOITS);
      byte var3 = 1;
      byte var5 = 1;
      ja[] var10001 = new ja[1];
      boolean var4 = true;
      var5 = 1;
      boolean var1 = true;
      var2 = 1;
      var10001[0] = new we(this);
      this.f$c(var10001);
   }
}

package net.futureclient.client;

import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class ia extends ka {
   private U field_940;
   private List field_941;
   private final s field_942;
   private EG field_943;
   private t field_944;
   public ZG field_945;
   private List field_946;
   private EG field_947;
   private ga field_948;
   private final ga field_949;
   private boolean field_950;
   private float field_951;
   private float field_952;
   private t field_953;
   public int field_954;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   private int method_4078() {
      ItemStack var1;
      if ((var1 = f$e.player.inventory.getCurrentItem()).getCount() != 0 && var1.getItem() instanceof ItemBlock && (((ea)this.field_949.method_3690()).equals(ea.Any) || ((ea)this.field_949.method_3690()).equals(ea.Whitelist) && ((List)this.field_942.f$c()).contains(var1.getItem()) || ((ea)this.field_949.method_3690()).equals(ea.Blacklist) && !((List)this.field_942.f$c()).contains(var1.getItem()))) {
         return f$e.player.inventory.currentItem;
      } else {
         int var3;
         for(int var10000 = var3 = 36; var10000 < 45; var10000 = var3) {
            ItemStack var2;
            if ((var2 = f$e.player.inventoryContainer.getSlot(var3).getStack()).getItem() instanceof ItemBlock && (((ea)this.field_949.method_3690()).equals(ea.Any) || ((ea)this.field_949.method_3690()).equals(ea.Whitelist) && ((List)this.field_942.f$c()).contains(var2.getItem()) || ((ea)this.field_949.method_3690()).equals(ea.Blacklist) && !((List)this.field_942.f$c()).contains(var2.getItem()))) {
               return var3 - 36;
            }

            ++var3;
         }

         return -1;
      }
   }

   public static float method_2191(ia var0, float var1) {
      return var0.field_952 = var1;
   }

   public static float method_2192(ia var0) {
      return var0.field_952;
   }

   public static EG method_2193(ia var0) {
      return var0.field_943;
   }

   public static t method_2194(ia var0) {
      return var0.field_953;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static ga method_2197(ia var0) {
      return var0.field_948;
   }

   public static int method_2198(ia var0) {
      return var0.method_4078();
   }

   public static boolean method_2199(ia var0, boolean var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.field_950 = var1;
   }

   public static float method_2200(ia var0) {
      return var0.field_951;
   }

   private ZG method_2201(BlockPos var1) {
      if (!this.field_946.contains(f$e.world.getBlockState(var1.add(0, -1, 0)).getBlock())) {
         return new ZG(var1.add(0, -1, 0), EnumFacing.UP);
      } else if (!this.field_946.contains(f$e.world.getBlockState(var1.add(-1, 0, 0)).getBlock())) {
         return new ZG(var1.add(-1, 0, 0), EnumFacing.EAST);
      } else if (!this.field_946.contains(f$e.world.getBlockState(var1.add(1, 0, 0)).getBlock())) {
         return new ZG(var1.add(1, 0, 0), EnumFacing.WEST);
      } else if (!this.field_946.contains(f$e.world.getBlockState(var1.add(0, 0, -1)).getBlock())) {
         return new ZG(var1.add(0, 0, -1), EnumFacing.SOUTH);
      } else if (!this.field_946.contains(f$e.world.getBlockState(var1.add(0, 0, 1)).getBlock())) {
         return new ZG(var1.add(0, 0, 1), EnumFacing.NORTH);
      } else {
         BlockPos var2 = var1.add(-1, 0, 0);
         if (!this.field_946.contains(f$e.world.getBlockState(var2.add(-1, 0, 0)).getBlock())) {
            return new ZG(var2.add(-1, 0, 0), EnumFacing.EAST);
         } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(1, 0, 0)).getBlock())) {
            return new ZG(var2.add(1, 0, 0), EnumFacing.WEST);
         } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(0, 0, -1)).getBlock())) {
            return new ZG(var2.add(0, 0, -1), EnumFacing.SOUTH);
         } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(0, 0, 1)).getBlock())) {
            return new ZG(var2.add(0, 0, 1), EnumFacing.NORTH);
         } else {
            var2 = var1.add(1, 0, 0);
            if (!this.field_946.contains(f$e.world.getBlockState(var2.add(-1, 0, 0)).getBlock())) {
               return new ZG(var2.add(-1, 0, 0), EnumFacing.EAST);
            } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(1, 0, 0)).getBlock())) {
               return new ZG(var2.add(1, 0, 0), EnumFacing.WEST);
            } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(0, 0, -1)).getBlock())) {
               return new ZG(var2.add(0, 0, -1), EnumFacing.SOUTH);
            } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(0, 0, 1)).getBlock())) {
               return new ZG(var2.add(0, 0, 1), EnumFacing.NORTH);
            } else {
               var2 = var1.add(0, 0, -1);
               if (!this.field_946.contains(f$e.world.getBlockState(var2.add(-1, 0, 0)).getBlock())) {
                  return new ZG(var2.add(-1, 0, 0), EnumFacing.EAST);
               } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(1, 0, 0)).getBlock())) {
                  return new ZG(var2.add(1, 0, 0), EnumFacing.WEST);
               } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(0, 0, -1)).getBlock())) {
                  return new ZG(var2.add(0, 0, -1), EnumFacing.SOUTH);
               } else if (!this.field_946.contains(f$e.world.getBlockState(var2.add(0, 0, 1)).getBlock())) {
                  return new ZG(var2.add(0, 0, 1), EnumFacing.NORTH);
               } else {
                  var1 = var1.add(0, 0, 1);
                  if (!this.field_946.contains(f$e.world.getBlockState(var1.add(-1, 0, 0)).getBlock())) {
                     return new ZG(var1.add(-1, 0, 0), EnumFacing.EAST);
                  } else if (!this.field_946.contains(f$e.world.getBlockState(var1.add(1, 0, 0)).getBlock())) {
                     return new ZG(var1.add(1, 0, 0), EnumFacing.WEST);
                  } else if (!this.field_946.contains(f$e.world.getBlockState(var1.add(0, 0, -1)).getBlock())) {
                     return new ZG(var1.add(0, 0, -1), EnumFacing.SOUTH);
                  } else {
                     return !this.field_946.contains(f$e.world.getBlockState(var1.add(0, 0, 1)).getBlock()) ? new ZG(var1.add(0, 0, 1), EnumFacing.NORTH) : null;
                  }
               }
            }
         }
      }
   }

   public static t method_2202(ia var0) {
      return var0.field_944;
   }

   public static float method_2203(ia var0, float var1) {
      return var0.field_951 = var1;
   }

   public static EG method_2204(ia var0) {
      return var0.field_947;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static ZG method_2206(ia var0, BlockPos var1) {
      return var0.method_2201(var1);
   }

   public static List method_2207(ia var0) {
      return var0.field_941;
   }

   public static U method_2208(ia var0) {
      return var0.field_940;
   }

   public static boolean method_2209(ia var0) {
      return var0.field_950;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public void method_4326() {
      this.field_945 = null;
      super.method_4326();
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4288() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4291() {
      return f$e;
   }

   public static Minecraft method_4292() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_4294() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_4296() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4298() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public static Minecraft method_4300() {
      return f$e;
   }

   public static Minecraft method_3767() {
      return f$e;
   }

   public static Minecraft method_4301() {
      return f$e;
   }

   public ia() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Scaffold";
      var10002[1] = "ScaffoldWalk";
      var10002[2] = "Scaffo";
      var10002[3] = "Tower";
      super("Scaffold", var10002, true, -6772395, bE.WORLD);
      Boolean var4 = true;
      String[] var6 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Tower";
      var6[1] = "Tow";
      var6[2] = "t";
      this.field_944 = new t(var4, var6);
      var4 = false;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "StopMotion";
      var6[1] = "Motion";
      var6[2] = "AAC";
      var6[3] = "ac";
      this.field_953 = new t(var4, var6);
      Ha var5 = Ha.Normal;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Mode";
      var6[1] = "Mod";
      var6[2] = "Type";
      var6[3] = "m";
      this.field_948 = new ga(var5, var6);
      Float var7 = 75.0F;
      Float var10 = 1.0F;
      Float var12 = 600.0F;
      Integer var15 = 1;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Delay";
      var10007[1] = "Del";
      var10007[2] = "d";
      this.field_940 = new U(var7, var10, var12, var15, var10007);
      ea var8 = ea.Any;
      var6 = new String[3];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Selection";
      var6[1] = "SelectionMode";
      var6[2] = "s";
      this.field_949 = new ga(var8, var6);
      String[] var9 = new String[7];
      boolean var13 = true;
      byte var14 = 1;
      var9[0] = "Items";
      var9[1] = "blocks";
      var9[2] = "whitelist";
      var9[3] = "blacklist";
      var9[4] = "selectable";
      var9[5] = "selectableitems";
      var9[6] = "i";
      this.field_942 = new s(var9);
      this.field_947 = new EG();
      this.field_943 = new EG();
      Block[] var10001 = new Block[6];
      boolean var3 = true;
      byte var11 = 1;
      var10001[0] = Blocks.AIR;
      var10001[1] = Blocks.WATER;
      var10001[2] = Blocks.FIRE;
      var10001[3] = Blocks.FLOWING_WATER;
      var10001[4] = Blocks.LAVA;
      var10001[5] = Blocks.FLOWING_LAVA;
      this.field_946 = Arrays.asList(var10001);
      var10001 = new Block[4];
      var3 = true;
      var11 = 1;
      var10001[0] = Blocks.LAVA;
      var10001[1] = Blocks.FLOWING_LAVA;
      var10001[2] = Blocks.WATER;
      var10001[3] = Blocks.FLOWING_WATER;
      this.field_941 = Arrays.asList(var10001);
      this.field_945 = null;
      t[] var1 = new t[6];
      var3 = true;
      var11 = 1;
      var1[0] = this.field_948;
      var1[1] = this.field_949;
      var1[2] = this.field_942;
      var1[3] = this.field_944;
      var1[4] = this.field_953;
      var1[5] = this.field_940;
      this.f$c(var1);
      ja[] var2 = new ja[3];
      var3 = true;
      var11 = 1;
      var2[0] = new Fa(this);
      var2[1] = new Ma(this);
      var2[2] = new La(this);
      this.method_2383(var2);
   }
}

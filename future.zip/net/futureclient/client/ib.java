package net.futureclient.client;

import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;

public class ib extends ja {
   public final gb field_962;

   public ib(gb var1) {
      this.field_962 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }

   public void method_4241(je var1) {
      if ((Boolean)this.field_962.field_1407.method_3690() && (Boolean)this.field_962.field_1413.method_3690() && var1.method_3084() instanceof CPacketClickWindow) {
         if (gb.method_4243().player.isActiveItemStackBlocking()) {
            gb.method_4279().playerController.onStoppedUsingItem(gb.method_4280().player);
         }

         if (gb.method_4271().player.isSneaking()) {
            gb.method_4275().player.connection.sendPacket(new CPacketEntityAction(gb.method_4278().player, Action.STOP_SNEAKING));
         }

         if (gb.method_4277().player.isSprinting()) {
            gb.method_4267().player.connection.sendPacket(new CPacketEntityAction(gb.method_4270().player, Action.STOP_SPRINTING));
         }
      }

   }
}

package net.futureclient.client;

public class ic extends ja {
   public final ac field_959;

   public ic(ac var1) {
      this.field_959 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2250((Kf)var1);
   }

   public void method_2250(Kf var1) {
      var1.method_729((Boolean)this.field_959.field_1193.method_3690());
   }
}

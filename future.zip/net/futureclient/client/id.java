package net.futureclient.client;

public class id extends ja {
   public final bB field_928;

   public id(bB var1) {
      this.field_928 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2171((iE)var1);
   }

   public void method_2171(iE var1) {
      if ((EI.method_872().isInWater() || EI.method_872().isInLava()) && (EI.method_872().motionY == 1.273197475E-314D || EI.method_872().motionY == 0.0D)) {
         var1.f$c(true);
      }

   }
}

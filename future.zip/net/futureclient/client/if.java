package net.futureclient.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.entity.EntityLivingBase;

public class if extends QE {
   private float field_931;
   private float field_932;
   private float field_933;
   private float field_934;
   private float field_935;
   private float field_936;

   public if(RenderLivingBase var1, EntityLivingBase var2, ModelBase var3, float var4, float var5, float var6, float var7, float var8, float var9) {
      super(var1, var2, var3);
      this.field_931 = var4;
      this.field_932 = var5;
      this.field_934 = var6;
      this.field_933 = var7;
      this.field_935 = var8;
      this.field_936 = var9;
   }

   public float method_2177() {
      return this.field_934;
   }

   public float method_2178() {
      return this.field_931;
   }

   public float method_2179() {
      return this.field_935;
   }

   public float method_3117() {
      return this.field_936;
   }

   public float method_2181() {
      return this.field_933;
   }

   public float method_2182() {
      return this.field_932;
   }
}

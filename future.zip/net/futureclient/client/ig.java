package net.futureclient.client;

public class ig extends ja {
   public final vF field_930;

   public ig(vF var1) {
      this.field_930 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      vF var10000 = this.field_930;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = this.field_930.field_1773.method_3690();
      var10000.f$D(String.format("Criticals §7[§F%s§7]", var10002));
   }
}

package net.futureclient.client;

public class ih {
   private Ri field_924;
   private static final ih field_925 = new ih();

   public ih() {
      this.field_924 = Ri.RUNNING;
   }

   public void method_2158(Ri var1) {
      this.field_924 = var1;
   }

   public static ih method_2159() {
      return field_925;
   }

   public Ri method_2160() {
      return this.field_924;
   }

   public boolean method_2161() {
      return this.field_924 == Ri.SHUTDOWN;
   }
}

package net.futureclient.client;

public class ii extends Cj implements p {
   private double field_922;
   public final double field_923 = 1.273197475E-314D;

   public ii() {
      this.field_922 = 1.273197475E-314D;
   }

   public ii(double var1) {
      if (var1 > 0.0D) {
         var1 = 0.0D;
      }

      this.field_922 = var1;
   }

   private int method_2156(String var1, String var2) {
      String var3;
      String var4;
      if (var1.length() > var2.length()) {
         var4 = var1.toLowerCase();
         var3 = var2.toLowerCase();
      } else {
         var4 = var2.toLowerCase();
         var3 = var1.toLowerCase();
      }

      int var5 = 0;
      int var6;
      int var10000 = var6 = 0;

      while(true) {
         if (var10000 >= var3.length()) {
            var10000 = var5;
            break;
         }

         if (var3.charAt(var6) != var4.charAt(var6)) {
            var10000 = var5;
            break;
         }

         ++var5;
         ++var6;
         var10000 = var6;
      }

      return var10000 > 4 ? 4 : var5;
   }

   public double method_2157(String var1, String var2) {
      double var3 = super.method_2157(var1, var2);
      int var5 = this.method_2156(var1, var2);
      return var3 + this.field_922 * (double)var5 * (1.0D - var3);
   }
}

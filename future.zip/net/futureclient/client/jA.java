package net.futureclient.client;

public class jA extends ja {
   public final EB field_955;

   public jA(EB var1) {
      this.field_955 = var1;
   }

   public void method_2246(oD var1) {
      YH.method_1211().method_1216().method_3043().forEach(var1.accept<invokedynamic>(var1));
   }

   public void method_4312(CD var1) {
      this.method_2246((oD)var1);
   }

   private static void method_2248(oD var0, Bg var1) {
      if (var0.method_3453() != null && var0.method_3453().contains(var1.method_757())) {
         String var2 = YH.method_1211().method_1216().method_1483(var0.method_3453());
         var0.method_3452(var2);
      }

   }
}

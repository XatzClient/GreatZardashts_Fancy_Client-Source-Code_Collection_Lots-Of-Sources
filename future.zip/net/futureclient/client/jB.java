package net.futureclient.client;

import java.io.File;

public abstract class jB implements C, c, F {
   private File field_937;
   private String field_938;
   private File field_939;

   public jB(String var1, File var2) {
      this.field_938 = var1;
      this.field_939 = var2;
      this.field_937 = new File(var2, var1);
      YH.method_1211().method_1203().method_3798(this);
   }

   public jB(String var1) {
      this.field_938 = var1;
      this.field_939 = YH.method_1211().method_1217();
      this.field_937 = new File(this.field_939, var1);
      YH.method_1211().method_1203().method_3798(this);
   }

   public File method_2183() {
      return this.field_939;
   }

   public abstract void method_3650(Object... var1);

   public String method_2184() {
      return this.field_938;
   }

   public File method_2185() {
      return this.field_937;
   }

   public abstract void method_3649(Object... var1);
}

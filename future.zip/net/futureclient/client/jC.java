package net.futureclient.client;

public class jC extends kB {
   public final bC field_960;
   public final bE field_961;

   public jC(bC var1, String var2, int var3, int var4, boolean var5, bE var6) {
      super(var2, var3, var4, var5);
      this.field_960 = var1;
      this.field_961 = var6;
   }

   public void method_3089() {
      YH.method_1211().method_1205().method_2164().forEach(this.accept<invokedynamic>(this, this.field_961));
   }

   private void method_2252(bE var1, Aa var2) {
      ka var3;
      if (var2 instanceof k && !var2.getClass().equals(vA.class) && (var3 = (ka)var2).method_634().equals(var1)) {
         this.f$c(new HC(var3));
      }

   }
}

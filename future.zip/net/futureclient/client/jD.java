package net.futureclient.client;

import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public final class jD implements IMixinConfigPlugin {
   private de field_956;
   private final AtomicBoolean field_957;
   private boolean field_958;

   public jD() {
      byte var10004 = 1;
      byte var10005 = 1;
      this.field_957 = new AtomicBoolean(true);
   }

   public void acceptTargets(Set var1, Set var2) {
   }

   public void preApply(String var1, ClassNode var2, String var3, IMixinInfo var4) {
   }

   public void postApply(String var1, ClassNode var2, String var3, IMixinInfo var4) {
   }

   public String getRefMapperConfig() {
      return null;
   }

   public List getMixins() {
      return null;
   }

   public void onLoad(String var1) {
      this.field_956 = de.method_3081(var1);
   }

   public boolean shouldApplyMixin(String param1, String param2) {
      // $FF: Couldn't be decompiled
   }
}

package net.futureclient.client;

public class jE extends ja {
   public final tD field_927;

   public jE(tD var1) {
      this.field_927 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      if (var1.method_326().equals(HD.PRE)) {
         tD var10000 = this.field_927;
         byte var10003 = 1;
         byte var10004 = 1;
         Object[] var10002 = new Object[1];
         boolean var12 = true;
         var10004 = 1;
         boolean var10005 = true;
         byte var10006 = 1;
         var10002[0] = tD.method_3887(this.field_927).method_3690();
         var10000.f$D(String.format("PacketFly §7[§F%s§7]", var10002));
         tD.method_4289().player.motionX = tD.method_4283().player.motionY = tD.method_4243().player.motionZ = 0.0D;
         boolean var10;
         if (!((QF)tD.method_3887(this.field_927).method_3690()).equals(QF.Setback) && tD.method_3894(this.field_927) == 0) {
            var10 = true;
            var10003 = 1;
            if (tD.method_3900(this.field_927, 4)) {
               var10005 = true;
               var10006 = 1;
               tD.method_3891(this.field_927, 0.0D, 0.0D, 0.0D, false);
            }

         } else {
            boolean var2 = tD.method_3899(this.field_927);
            double var3;
            double var7;
            jE var8;
            if (!tD.method_4280().player.movementInput.jump || !var2 && EI.method_890()) {
               if (tD.method_4279().player.movementInput.sneak) {
                  var3 = 1.6636447E-314D;
                  var8 = this;
               } else {
                  if (!var2) {
                     var10 = true;
                     var10003 = 1;
                     var7 = tD.method_3900(this.field_927, 4) ? ((Boolean)tD.method_3888(this.field_927).method_3690() ? 5.941588215E-315D : 0.0D) : 0.0D;
                  } else {
                     var7 = 0.0D;
                  }

                  var3 = var7;
                  var8 = this;
               }
            } else {
               if ((Boolean)tD.method_3888(this.field_927).method_3690() && !var2) {
                  var10000 = this.field_927;
                  byte var10001;
                  if (((QF)tD.method_3887(this.field_927).method_3690()).equals(QF.Setback)) {
                     var10001 = 10;
                     var10 = true;
                     var10003 = 1;
                  } else {
                     var10001 = 20;
                     var10 = true;
                     var10003 = 1;
                  }

                  var7 = tD.method_3900(var10000, var10001) ? 1.748524532E-314D : 1.6636447E-314D;
               } else {
                  var7 = 1.6636447E-314D;
               }

               var3 = var7;
               var8 = this;
            }

            if (((dD)tD.method_3892(var8.field_927).method_3690()).equals(dD.Full) && var2 && EI.method_890() && var3 != 0.0D) {
               var3 /= 0.0D;
            }

            double[] var6 = EI.method_883(((dD)tD.method_3892(this.field_927).method_3690()).equals(dD.Full) && var2 ? 1.6636447E-314D : 8.48798317E-316D);
            int var5;
            int var15 = var5 = 1;

            while(true) {
               int var9;
               if (((QF)tD.method_3887(this.field_927).method_3690()).equals(QF.Factor)) {
                  var9 = tD.method_3901(this.field_927).method_3692().intValue();
               } else {
                  var9 = 1;
                  byte var13 = 1;
                  var10003 = 1;
               }

               if (var15 > var9) {
                  return;
               }

               var10000 = this.field_927;
               boolean var16 = true;
               byte var18 = 1;
               double var11 = tD.method_4271().player.motionX = var6[0] * (double)var5;
               double var14 = tD.method_4278().player.motionY = var3 * (double)var5;
               var10006 = 1;
               byte var10007 = 1;
               double var17 = tD.method_4275().player.motionZ = var6[1] * (double)var5;
               if (!((QF)tD.method_3887(this.field_927).method_3690()).equals(QF.Setback)) {
                  var16 = true;
                  var18 = 1;
                  var10006 = 1;
               } else {
                  var16 = false;
                  var10005 = true;
                  var10006 = 1;
               }

               tD.method_3891(var10000, var11, var14, var17, var16);
               ++var5;
               var15 = var5;
            }
         }
      }
   }
}

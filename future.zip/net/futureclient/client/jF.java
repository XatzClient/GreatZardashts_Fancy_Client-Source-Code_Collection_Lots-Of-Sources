package net.futureclient.client;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class jF {
   private Map field_926 = new LinkedHashMap();

   private static Aa method_2162(Aa var0, Aa var1) {
      return var0;
   }

   public Aa method_2163(String var1) {
      Iterator var2 = this.method_2164().iterator();

      while(var2.hasNext()) {
         Aa var3;
         String[] var4;
         int var5 = (var4 = (var3 = (Aa)var2.next()).method_630()).length;

         int var6;
         for(int var10000 = var6 = 0; var10000 < var5; var10000 = var6) {
            if (var4[var6].equalsIgnoreCase(var1)) {
               return var3;
            }

            ++var6;
         }
      }

      return null;
   }

   public final Collection method_2164() {
      return this.field_926.values();
   }

   private static String method_2165(Entry var0) {
      return ((Aa)var0.getValue()).method_636();
   }

   public final Aa method_2166(Class var1) {
      return (Aa)this.field_926.get(var1);
   }

   public final void method_2167(Aa var1) {
      this.field_926.put(var1.getClass(), var1);
   }

   public jF() {
      this.method_2167(new YE());
      this.method_2167(new zF());
      this.method_2167(new Ne());
      this.method_2167(new KF());
      this.method_2167(new vF());
      this.method_2167(new KD());
      this.method_2167(new If());
      this.method_2167(new xE());
      this.method_2167(new gE());
      this.method_2167(new se());
      this.method_2167(new me());
      this.method_2167(new df());
      this.method_2167(new ge());
      this.method_2167(new OD());
      this.method_2167(new uf());
      this.method_2167(new cf());
      this.method_2167(new YD());
      this.method_2167(new TD());
      this.method_2167(new Zf());
      this.method_2167(new tf());
      this.method_2167(new zD());
      this.method_2167(new SF());
      this.method_2167(new tD());
      this.method_2167(new Hf());
      this.method_2167(new Be());
      this.method_2167(new yf());
      this.method_2167(new Ke());
      this.method_2167(new QD());
      this.method_2167(new mB());
      this.method_2167(new eE());
      this.method_2167(new BE());
      this.method_2167(new Ib());
      this.method_2167(new MD());
      this.method_2167(new Pd());
      this.method_2167(new GB());
      this.method_2167(new CB());
      this.method_2167(new xF());
      this.method_2167(new Vb());
      this.method_2167(new ec());
      this.method_2167(new fD());
      this.method_2167(new vb());
      this.method_2167(new eb());
      this.method_2167(new tC());
      this.method_2167(new Fd());
      this.method_2167(new PC());
      this.method_2167(new lA());
      this.method_2167(new KC());
      this.method_2167(new Mc());
      this.method_2167(new He());
      this.method_2167(new le());
      this.method_2167(new YC());
      this.method_2167(new AB());
      this.method_2167(new Mb());
      this.method_2167(new uc());
      this.method_2167(new aD());
      this.method_2167(new LE());
      this.method_2167(new Ec());
      this.method_2167(new Hc());
      this.method_2167(new Zc());
      this.method_2167(new gb());
      this.method_2167(new bA());
      this.method_2167(new ld());
      this.method_2167(new Nc());
      this.method_2167(new pC());
      this.method_2167(new kc());
      this.method_2167(new bB());
      this.method_2167(new wc());
      this.method_2167(new pA());
      this.method_2167(new QA());
      this.method_2167(new aB());
      this.method_2167(new qc());
      this.method_2167(new WB());
      this.method_2167(new hb());
      this.method_2167(new wB());
      this.method_2167(new Hd());
      this.method_2167(new gB());
      this.method_2167(new Pb());
      this.method_2167(new JA());
      this.method_2167(new gf());
      this.method_2167(new Dd());
      this.method_2167(new hc());
      this.method_2167(new Lb());
      this.method_2167(new kd());
      this.method_2167(new xC());
      this.method_2167(new Ub());
      this.method_2167(new fc());
      this.method_2167(new SA());
      this.method_2167(new vA());
      this.method_2167(new QC());
      this.method_2167(new GC());
      this.method_2167(new rA());
      this.method_2167(new TC());
      this.method_2167(new Kd());
      this.method_2167(new EB());
      this.method_2167(new cB());
      this.method_2167(new md());
      this.method_2167(new Wb());
      this.method_2167(new ac());
      this.method_2167(new DC());
      this.method_2167(new mb());
      this.method_2167(new cc());
      this.method_2167(new ta());
      this.method_2167(new Qa());
      this.method_2167(new sa());
      this.method_2167(new fa());
      this.method_2167(new ia());
      this.method_2167(new Pa());
      this.method_2167(new Da());
      this.method_2167(new Sa());
      this.method_2167(new Ta());
      this.method_2167(new Va());
      this.field_926 = (Map)this.field_926.entrySet().stream().sorted(Comparator.comparing(apply<invokedynamic>())).collect(Collectors.toMap(apply<invokedynamic>(), apply<invokedynamic>(), apply<invokedynamic>(), get<invokedynamic>()));
      YH.method_1211().method_1212().method_1330(new EE(this));
      new UD(this, "module_configurations.json");
   }
}

package net.futureclient.client;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;

public class jH extends ja {
   public final uh field_929;

   public jH(uh var1) {
      this.field_929 = var1;
   }

   public void method_4040(VF var1) {
      uh var10000 = this.field_929;

      try {
         uh.method_4140(var10000).keySet().removeIf(this.test<invokedynamic>(this));
         Iterator var2 = uh.method_4142(this.field_929).world.playerEntities.iterator();

         while(true) {
            List var4;
            do {
               EntityPlayer var3;
               do {
                  do {
                     do {
                        do {
                           do {
                              do {
                                 if (!var2.hasNext()) {
                                    return;
                                 }
                              } while((var3 = (EntityPlayer)var2.next()) == null);
                           } while(!EI.method_886(var3));
                        } while(var3 == uh.method_4142(this.field_929).player);
                     } while(var3.getEntityId() == -1337);

                     uh.method_4140(this.field_929).putIfAbsent(var3, new LinkedList());
                  } while(uh.method_4140(this.field_929).isEmpty());
               } while(uh.method_4140(this.field_929).get(var3) == null);

               var4 = (List)uh.method_4140(this.field_929).get(var3);
               aG var8 = new aG(var3.posX, var3.posY, var3.posZ);
               if (!var4.isEmpty()) {
                  aG var5 = (aG)var4.get(var4.size() - 1);
                  if (var8.f$c(var5).f$c() > 0.0D) {
                     var4.clear();
                  }
               }

               var4.add(var8);
            } while(var4.size() <= uh.method_4145(this.field_929));

            int var10 = 0;
            Iterator var9;
            Iterator var11 = var9 = (new LinkedList(var4)).iterator();

            while(var11.hasNext()) {
               aG var6 = (aG)var9.next();
               if (var10 >= var4.size() - uh.method_4145(this.field_929)) {
                  break;
               }

               var11 = var9;
               ++var10;
               var4.remove(var6);
            }
         }
      } catch (Exception var7) {
         var7.printStackTrace();
      }
   }

   private boolean method_3587(EntityPlayer var1) {
      return !uh.method_4142(this.field_929).world.playerEntities.contains(var1);
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }
}

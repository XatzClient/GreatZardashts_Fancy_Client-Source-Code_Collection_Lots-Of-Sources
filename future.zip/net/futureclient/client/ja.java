package net.futureclient.client;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public abstract class ja {
   private Class field_917;

   public ja() {
      Type var1;
      if ((var1 = this.getClass().getGenericSuperclass()) instanceof ParameterizedType) {
         Type[] var5;
         int var2 = (var5 = ((ParameterizedType)var1).getActualTypeArguments()).length;

         int var3;
         for(int var10000 = var3 = 0; var10000 < var2; var10000 = var3) {
            Type var4;
            if ((var4 = var5[var3]) instanceof Class && CD.class.isAssignableFrom((Class)var4)) {
               this.field_917 = (Class)var4;
               return;
            }

            ++var3;
         }
      }

   }

   public Class method_2147() {
      return this.field_917;
   }

   public abstract void method_4312(CD var1);
}

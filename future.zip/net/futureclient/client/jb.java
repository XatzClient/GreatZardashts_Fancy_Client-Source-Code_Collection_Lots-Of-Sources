package net.futureclient.client;

import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DimensionType;

public class jb extends ja {
   public final wB field_903;

   public jb(wB var1) {
      this.field_903 = var1;
   }

   public void method_4183(Xe var1) {
      xC var2;
      if ((var2 = (xC)YH.method_1211().method_1205().method_2166(xC.class)) != null && var2.f$c() && var2.method_4262() != null) {
         double var3 = var2.method_4262().method_4206();
         double var5 = var2.method_4262().method_4210();
         if (wB.method_4274().world.provider.getDimensionType().equals(DimensionType.NETHER) && var2.method_4262().method_4205().equals(DimensionType.OVERWORLD.getName())) {
            var3 /= 0.0D;
            var5 /= 0.0D;
         } else if (wB.method_4245().world.provider.getDimensionType().equals(DimensionType.OVERWORLD) && var2.method_4262().method_4205().equals(DimensionType.NETHER.getName())) {
            var3 *= 0.0D;
            var5 *= 0.0D;
         }

         wB.method_4281().player.rotationYaw = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(wB.method_4242().player.posZ - var5, wB.method_4269().player.posX - var3)) + 0.0D);
      } else {
         wB.method_4315().player.rotationYaw = (float)Math.round((wB.method_4319().player.rotationYaw + 1.0F) / 45.0F) * 45.0F;
      }
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

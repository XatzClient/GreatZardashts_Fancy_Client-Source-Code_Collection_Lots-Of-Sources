package net.futureclient.client;

public class jc extends ja {
   public final ac field_920;

   public jc(ac var1) {
      this.field_920 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2153((Pe)var1);
   }

   public void method_2153(Pe var1) {
      var1.f$c((Boolean)this.field_920.field_1194.method_3690());
   }
}

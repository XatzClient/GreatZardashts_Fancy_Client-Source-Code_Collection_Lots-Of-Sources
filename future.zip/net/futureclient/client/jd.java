package net.futureclient.client;

public class jd extends ja {
   public final JA field_918;

   public jd(JA var1) {
      this.field_918 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      if (JA.method_4269().player.movementInput.jump && ((Boolean)JA.method_34(this.field_918).method_3690() || JA.method_4315().player.onGround)) {
         var1.method_1726(JA.method_4319().player.motionY = JA.method_35(this.field_918).method_3692().doubleValue());
      }

   }
}

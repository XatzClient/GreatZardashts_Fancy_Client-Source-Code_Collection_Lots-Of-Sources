package net.futureclient.client;

import net.minecraft.network.Packet;

public final class je extends uD {
   public je(Packet var1) {
      super(var1);
   }
}

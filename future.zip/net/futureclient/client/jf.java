package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class jf extends xb {
   public EG field_901;

   public static Minecraft method_2111(jf var0) {
      return var0.field_1834;
   }

   public static Minecraft method_2112(jf var0) {
      return var0.field_1834;
   }

   public static Minecraft method_2113(jf var0) {
      return var0.field_1834;
   }

   public String method_4224() {
      return null;
   }

   public static Minecraft method_2115(jf var0) {
      return var0.field_1834;
   }

   public static Minecraft method_2116(jf var0) {
      return var0.field_1834;
   }

   public static Minecraft method_2117(jf var0) {
      return var0.field_1834;
   }

   public String method_4228(String[] var1) {
      YH.method_1211().method_1212().method_1330(new FD(this));
      return "Throwing potion.";
   }

   public jf() {
      String[] var10001 = new String[6];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Pot";
      var10001[1] = "ThrowPot";
      var10001[2] = "Tpot";
      var10001[3] = "UpPot";
      var10001[4] = "SendPot";
      var10001[5] = "Potion";
      super(var10001);
      this.field_901 = new EG();
   }
}

package net.futureclient.client;

import net.minecraft.util.EnumFacing;

public class ji {
   public static final int[] field_900;

   static {
      int[] var10000 = new int[EnumFacing.values().length];
      boolean var10001 = true;
      byte var10002 = 1;
      field_900 = var10000;
      var10000 = field_900;
      EnumFacing var5 = EnumFacing.NORTH;

      try {
         var10000[var5.ordinal()] = 1;
      } catch (NoSuchFieldError var4) {
      }

      var10000 = field_900;
      var5 = EnumFacing.SOUTH;

      try {
         var10000[var5.ordinal()] = 2;
      } catch (NoSuchFieldError var3) {
      }

      var10000 = field_900;
      var5 = EnumFacing.EAST;

      try {
         var10000[var5.ordinal()] = 3;
      } catch (NoSuchFieldError var2) {
      }

      var10000 = field_900;
      var5 = EnumFacing.WEST;

      try {
         var10000[var5.ordinal()] = 4;
      } catch (NoSuchFieldError var1) {
      }
   }
}

package net.futureclient.client;

import java.util.Arrays;
import net.minecraft.world.DimensionType;

public class kA extends xb {
   public final xC field_921;

   public kA(xC var1, String[] var2) {
      super(var2);
      this.field_921 = var1;
   }

   public String method_4224() {
      return "&e[add|del] [name] &7| &e[x] [y] [z] [dimension]";
   }

   public String method_4228(String[] var1) {
      String var2;
      Object[] var10001;
      boolean var10002;
      byte var10003;
      if (var1.length >= 2 && var1[0].equalsIgnoreCase("add")) {
         var2 = var1[1];
         String var15 = "";
         String[] var10000;
         if (this.field_1834.isSingleplayer()) {
            var15 = "singleplayer";
            var10000 = var1;
         } else if (this.field_1834.getCurrentServerData() != null) {
            var15 = this.field_1834.getCurrentServerData().serverIP.replaceAll(":", "_");
            var10000 = var1;
         } else {
            if (this.field_1834.isConnectedToRealms()) {
               var15 = "realms";
            }

            var10000 = var1;
         }

         double var4;
         double var6;
         double var8;
         kA var17;
         if (var10000.length >= 5) {
            var17 = this;
            var4 = Double.parseDouble(var1[2]);
            var6 = Double.parseDouble(var1[3]);
            var8 = Double.parseDouble(var1[4]);
         } else {
            var17 = this;
            var4 = Double.parseDouble(xC.method_4253(this.field_921).format(this.field_1834.player.posX).replaceAll(",", "."));
            var6 = Double.parseDouble(xC.method_4253(this.field_921).format(this.field_1834.player.posY).replaceAll(",", "."));
            var8 = Double.parseDouble(xC.method_4253(this.field_921).format(this.field_1834.player.posZ).replaceAll(",", "."));
         }

         String var10 = var17.field_1834.world.provider.getDimensionType().getName();
         if (var1.length == 6) {
            String var11 = var1[5].toLowerCase();
            var10000 = new String[3];
            boolean var18 = true;
            byte var19 = 1;
            var10000[0] = "overworld";
            var10000[1] = "world";
            var10000[2] = "ow";
            String[] var12 = var10000;
            var10000 = new String[4];
            var18 = true;
            var19 = 1;
            var10000[0] = "nether";
            var10000[1] = "the_nether";
            var10000[2] = "nethe";
            var10000[3] = "n";
            String[] var13 = var10000;
            var10000 = new String[4];
            var18 = true;
            var19 = 1;
            var10000[0] = "end";
            var10000[1] = "the_end";
            var10000[2] = "en";
            var10000[3] = "e";
            String[] var14 = var10000;
            if (Arrays.asList(var12).contains(var11)) {
               var10 = DimensionType.OVERWORLD.getName();
            } else if (Arrays.asList(var13).contains(var11)) {
               var10 = DimensionType.NETHER.getName();
            } else {
               if (!Arrays.asList(var14).contains(var11)) {
                  return "Invalid dimension type entered.";
               }

               var10 = DimensionType.THE_END.getName();
            }
         }

         xa var16 = new xa(var2, var15, var4, var6, var8, var10);
         if (!xC.method_4258(this.field_921, var16)) {
            this.field_921.field_1866.add(var16);
         }

         var10001 = new Object[1];
         var10002 = true;
         var10003 = 1;
         var10001[0] = var16.method_4207();
         return String.format("Added waypoint &e%s&7.", var10001);
      } else if (var1.length == 2 && (var1[0].equalsIgnoreCase("del") || var1[0].equalsIgnoreCase("remove"))) {
         var2 = var1[1];
         xa var3;
         if ((var3 = this.field_921.method_4246(var2)) == null) {
            return "Invalid waypoint entered.";
         } else {
            if (xC.method_4258(this.field_921, var3)) {
               this.field_921.field_1866.remove(var3);
            }

            var10001 = new Object[1];
            var10002 = true;
            var10003 = 1;
            var10001[0] = var3.method_4207();
            return String.format("Removed waypoint &e%s&7.", var10001);
         }
      } else {
         return null;
      }
   }
}

package net.futureclient.client;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;

public abstract class kB implements C {
   private int field_905;
   public int field_906;
   private int field_907;
   public boolean field_908;
   private Minecraft field_909 = Minecraft.getMinecraft();
   private String field_910;
   private boolean field_911;
   private int field_912;
   private ArrayList field_913 = new ArrayList();
   private int field_914;
   private int field_915;
   private int field_916;

   public kB(String var1, int var2, int var3, boolean var4) {
      this.field_910 = var1;
      this.field_916 = var2;
      this.field_912 = var3;
      this.field_906 = 180;
      this.field_915 = 88;
      this.field_914 = 18;
      this.field_911 = var4;
      this.method_3089();
   }

   public int method_2125() {
      return this.field_916;
   }

   public void method_2126(int var1) {
      this.field_916 = var1;
   }

   public int method_2127() {
      return this.field_915;
   }

   public void method_2128(int var1, int var2, int var3) {
      if (var3 == 0 && this.method_2132(var1, var2)) {
         this.field_905 = this.field_916 - var1;
         this.field_907 = this.field_912 - var2;
         bC.method_3037().method_3034().forEach(accept<invokedynamic>());
         this.field_908 = true;
      } else if (var3 == 1 && this.method_2132(var1, var2)) {
         this.field_911 = !this.field_911;
         this.field_909.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      } else {
         if (this.field_911) {
            this.method_2134().forEach(var1.accept<invokedynamic>(var1, var2, var3));
         }

      }
   }

   private void method_2129(int var1, int var2) {
      if (this.field_908) {
         this.field_916 = this.field_905 + var1;
         this.field_912 = this.field_907 + var2;
      }

   }

   private static void method_2130(int var0, int var1, int var2, Wa var3) {
      var3.method_1915(var0, var1, var2);
   }

   public void method_2131(boolean var1) {
      this.field_911 = var1;
   }

   private boolean method_2132(int var1, int var2) {
      return var1 >= this.method_2125() && var1 <= this.method_2125() + this.method_2127() - 1 && (float)var2 >= (float)this.method_2145() - 1.5F && var2 <= this.method_2145() + this.method_2137() - 6;
   }

   private static void method_2133(kB var0) {
      if (var0.field_908) {
         var0.field_908 = false;
      }

   }

   public ArrayList method_2134() {
      return this.field_913;
   }

   public void method_2135(int var1, int var2, int var3) {
      if (var3 == 0) {
         this.field_908 = false;
      }

      if (this.field_911) {
         this.method_2134().forEach(var1.accept<invokedynamic>(var1, var2, var3));
      }

   }

   public void method_2136(wA var1) {
      this.field_913.add(var1);
   }

   public int method_2137() {
      return this.field_914;
   }

   public float method_2138() {
      float var1 = 0.0F;

      Iterator var2;
      for(Iterator var10000 = var2 = this.method_2134().iterator(); var10000.hasNext(); var10000 = var2) {
         Wa var3 = (Wa)var2.next();
         var1 += (float)var3.method_2414() + 1.5F;
      }

      return var1;
   }

   public void method_2139(int var1) {
      this.field_912 = var1;
   }

   private static void method_2140(int var0, int var1, int var2, Wa var3) {
      var3.method_3982(var0, var1, var2);
   }

   public boolean method_2141() {
      return this.field_911;
   }

   public void method_2142(int var1, int var2) {
      this.field_912 += var1;
      if (this.field_912 < var2) {
         this.field_912 = var2;
      }

      if (this.field_912 >= 4) {
         this.field_912 = 4;
      }

   }

   public String method_2143() {
      return this.field_910;
   }

   public abstract void method_3089();

   public int method_2145() {
      return this.field_912;
   }

   public void method_2146(int var1, int var2, float var3) {
      GlStateManager.pushMatrix();
      GlStateManager.scale(bC.method_3037().field_1197, bC.method_3037().field_1197, bC.method_3037().field_1197);
      this.method_2129(var1, var2);
      float var4 = this.field_911 ? this.method_2138() - 2.0F : 0.0F;
      YE var5 = (YE)YH.method_1211().method_1205().method_2166(YE.class);
      zF var6 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
      Di.method_901((float)this.field_916, (float)this.field_912 - 1.5F, (float)(this.field_916 + this.field_915), (float)(this.field_912 + this.field_914 - 6), var6.field_1445.getRGB() + -1728053248, var6.field_1445.getRGB() + -1728053248);
      Di.method_937((float)this.field_916, (float)this.field_912 + 12.5F, (float)(this.field_916 + this.field_915), this.method_2141() ? (float)(this.field_912 + this.field_914) + var4 : (float)(this.field_912 + this.field_914 - 1), 1996488704);
      if ((Boolean)var5.field_583.method_3690()) {
         GlStateManager.enableBlend();
         var5.field_573.method_3678(this.method_2143(), (double)((float)this.field_916 + 3.0F), (double)((float)this.field_912 + 1.5F), 15592941);
         GlStateManager.disableBlend();
      } else {
         this.field_909.fontRenderer.drawStringWithShadow(this.method_2143(), (float)this.field_916 + 3.0F, (float)this.field_912 + 1.5F, 15592941);
      }

      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      nI.method_2438(new Color(255, 255, 255, 255));
      this.field_909.getTextureManager().bindTexture(new ResourceLocation("textures/future/arrow.png"));
      GlStateManager.translate((float)(this.method_2125() + this.method_2127() - 7), (float)(this.method_2145() + 6) - 0.3F, 0.0F);
      GlStateManager.rotate(ri.method_3657((float)this.field_906), (float)0, 0.0F, (float)0);
      nI.method_2436(-5, -5, 0.0F, (float)0, 10, 10, 10, 10, 10.0F, 10.0F);
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
      if (this.field_911) {
         var4 = (float)(this.method_2145() + this.method_2137()) - 3.0F;

         Iterator var7;
         Wa var8;
         for(Iterator var10000 = var7 = this.method_2134().iterator(); var10000.hasNext(); var4 += (float)var8.method_2414() + 1.5F) {
            var8 = (Wa)var7.next();
            var10000 = var7;
            var8.method_1912((float)this.field_916 + 2.0F, var4);
            var8.method_1911(this.method_2127() - 4);
            var8.method_3986(var1, var2, var3);
         }
      }

      GlStateManager.popMatrix();
   }
}

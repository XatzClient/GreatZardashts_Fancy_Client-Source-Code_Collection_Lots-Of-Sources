package net.futureclient.client;

public class kC extends ja {
   public final Hc field_904;

   public kC(Hc var1) {
      this.field_904 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2124((ke)var1);
   }

   public void method_2124(ke var1) {
      int var2;
      if ((var2 = var1.method_3981()) < 0) {
         var1.method_2353(var2);
      }

   }
}

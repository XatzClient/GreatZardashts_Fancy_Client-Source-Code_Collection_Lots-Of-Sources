package net.futureclient.client;

public class kD extends CD {
}

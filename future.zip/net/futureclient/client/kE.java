package net.futureclient.client;

public class kE extends ja {
   public final ka field_919;

   public kE(ka var1) {
      this.field_919 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4311((yD)var1);
   }

   public void method_4311(yD var1) {
      if (ka.method_2384(this.field_919) && this.field_919.field_1035 < 0.0F) {
         ka var10000 = this.field_919;
         var10000.field_1035 += 5.0F;
      } else {
         YH.method_1211().method_1212().method_1334(this);
      }
   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class kF extends ja {
   public final TD field_902;

   public kF(TD var1) {
      this.field_902 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      switch(jg.f$e[var1.method_326().ordinal()]) {
      case 1:
         boolean var10001 = false;
         int var10000;
         int var2;
         if (TD.method_1570(this.field_902, TD.method_4277().player.getHeldItemMainhand()) && TD.method_4270().player.getItemInUseMaxCount() > TD.method_1571(this.field_902).method_3692().intValue() - 1 && TD.method_1571(this.field_902).method_3692().intValue() < 25) {
            for(var10000 = var2 = 0; var10000 < 32; var10000 = var2) {
               ++var2;
               TD.method_4273().player.connection.sendPacket(new CPacketPlayer(TD.method_4267().player.onGround));
            }

            TD.method_4276().player.connection.sendPacket(new CPacketPlayerDigging(Action.RELEASE_USE_ITEM, new BlockPos(0, 0, 0), EnumFacing.DOWN));
            TD.method_4274().player.stopActiveHand();
            return;
         } else if (TD.method_1576(this.field_902, TD.method_4245().player.getHeldItemMainhand()) && TD.method_4281().player.getItemInUseMaxCount() > TD.method_1573(this.field_902).method_3692().intValue() - 1 && TD.method_1573(this.field_902).method_3692().intValue() < 25) {
            for(var10000 = var2 = 0; var10000 < 24; var10000 = var2) {
               ++var2;
               TD.method_4269().player.connection.sendPacket(new CPacketPlayer(TD.method_4242().player.onGround));
            }

            TD.method_4315().player.connection.sendPacket(new CPacketPlayerDigging(Action.RELEASE_USE_ITEM, new BlockPos(0, 0, 0), EnumFacing.DOWN));
            TD.method_4319().player.stopActiveHand();
         }
      default:
      }
   }
}

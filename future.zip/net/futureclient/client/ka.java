package net.futureclient.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ka extends Aa implements k {
   private List field_1029 = new ArrayList();
   private boolean field_1030;
   private boolean field_1031;
   private bE field_1032;
   private final ja field_1033;
   private int field_1034;
   public float field_1035;
   private final ja field_1036;

   public void method_4314() {
      this.field_1029.forEach(accept<invokedynamic>());
      YH.method_1211().method_1212().method_1330(this.field_1036);
   }

   public boolean method_2380() {
      return this.field_1031;
   }

   private static void method_2381(ja var0) {
      YH.method_1211().method_1212().method_1334(var0);
   }

   public void method_2382(boolean var1) {
      this.field_1031 = var1;
   }

   public void method_2383(ja... var1) {
      Collections.addAll(this.field_1029, var1);
   }

   public static boolean method_2384(ka var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.field_1030;
   }

   private static void method_2385(ja var0) {
      YH.method_1211().method_1212().method_1330(var0);
   }

   public bE method_634() {
      return this.field_1032;
   }

   public int method_2386() {
      return this.field_1034;
   }

   public boolean method_2387() {
      return this.field_1030;
   }

   public void method_2388(boolean var1) {
      this.field_1030 = var1;
      if (this.field_1030) {
         this.method_4326();
      } else {
         this.method_4314();
      }
   }

   public void method_2389(int var1) {
      this.field_1034 = var1;
   }

   public void method_2390() {
      this.method_2388(!this.field_1030);
   }

   public void method_4326() {
      this.field_1029.forEach(accept<invokedynamic>());
      if (this.getClass().isAnnotationPresent(Z.class)) {
         Z var1 = (Z)this.getClass().getAnnotation(Z.class);
         la var10000 = la.method_2324();
         Object[] var10002 = new Object[1];
         boolean var10003 = true;
         byte var10004 = 1;
         var10002[0] = var1.method_3700();
         var10000.method_2322(String.format("&cNOTE: &7%s", var10002));
      }

      YH.method_1211().method_1212().method_1330(this.field_1033);
   }

   public ka(String var1, String[] var2, boolean var3, int var4, bE var5) {
      super(var1, var2);
      this.field_1034 = var4;
      this.field_1032 = var5;
      this.field_1031 = var3;
      this.field_1033 = new kE(this);
      this.field_1036 = new hD(this);
      qf var10000;
      Object[] var10004;
      boolean var10005;
      byte var10006;
      if (var1.equalsIgnoreCase(sh.f$c("^JtEvahO"))) {
         var10000 = YH.method_1211().method_1210();
         var10004 = new Object[1];
         var10005 = true;
         var10006 = 1;
         var10004[0] = this.f$c()[0].toLowerCase().replace(" ", "");
         var10000.method_3799(new Td(String.format("%sToggle", var10004), new AF(this), 54));
      } else {
         var10000 = YH.method_1211().method_1210();
         var10004 = new Object[1];
         var10005 = true;
         var10006 = 1;
         var10004[0] = this.f$c()[0].toLowerCase().replace(" ", "");
         var10000.method_3799(new Td(String.format("%sToggle", var10004), new AF(this), 0));
      }
   }
}

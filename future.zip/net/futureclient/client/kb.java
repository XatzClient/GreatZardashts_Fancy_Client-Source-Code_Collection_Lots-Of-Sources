package net.futureclient.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class kb extends jB {
   public final Mb field_1017;

   public kb(Mb var1, String var2) {
      super(var2);
      this.field_1017 = var1;
   }

   public void method_3650(Object... var1) {
      kb var10000 = this;

      try {
         if (!var10000.f$c().exists()) {
            this.f$c().createNewFile();
         }
      } catch (IOException var5) {
         var5.printStackTrace();
      }

      BufferedWriter var9 = new BufferedWriter;
      BufferedWriter var10001 = var9;
      FileWriter var10002 = new FileWriter;
      FileWriter var10003 = var10002;
      kb var10004 = this;

      Exception var10;
      label42: {
         BufferedWriter var2;
         boolean var12;
         try {
            var10003.<init>(var10004.f$c());
            var10001.<init>(var10002);
            var2 = var9;
            Iterator var3;
            Iterator var11 = var3 = this.field_1017.field_177.iterator();

            while(var11.hasNext()) {
               String var4 = (String)var3.next();
               var11 = var3;
               var2.write(var4.toLowerCase());
               var2.newLine();
            }
         } catch (Exception var7) {
            var10 = var7;
            var12 = false;
            break label42;
         }

         var9 = var2;

         try {
            var9.close();
            return;
         } catch (Exception var6) {
            var10 = var6;
            var12 = false;
         }
      }

      Exception var8 = var10;
      var8.printStackTrace();
   }

   public void method_3649(Object... var1) {
      this.field_1017.field_177.clear();
      kb var10000 = this;

      try {
         if (var10000.f$c().length() > 6000L && !this.f$c().delete()) {
            this.f$c().deleteOnExit();
         }

         if (!this.f$c().exists()) {
            this.f$c().createNewFile();
         }
      } catch (IOException var4) {
         var4.printStackTrace();
      }

      if (this.f$c().exists()) {
         BufferedReader var7 = new BufferedReader;
         BufferedReader var10001 = var7;
         FileReader var10002 = new FileReader;
         FileReader var10003 = var10002;
         kb var10004 = this;

         try {
            var10003.<init>(var10004.f$c());
            var10001.<init>(var10002);
            BufferedReader var2 = var7;

            label45:
            while(true) {
               var7 = var2;

               String var3;
               while((var3 = var7.readLine()) != null) {
                  ArrayList var8 = this.field_1017.field_177;
                  String var9 = var3;

                  try {
                     if (!var8.contains(var9.toLowerCase())) {
                        this.field_1017.field_177.add(var3.toLowerCase());
                     }
                     continue label45;
                  } catch (Exception var5) {
                     var7 = var2;
                     var5.printStackTrace();
                  }
               }

               var2.close();
               return;
            }
         } catch (Exception var6) {
            var6.printStackTrace();
         }
      }
   }
}

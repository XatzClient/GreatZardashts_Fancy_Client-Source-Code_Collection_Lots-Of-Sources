package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class kc extends ka {
   public t field_1010;
   public t field_1011;
   public U field_1012;
   private ga field_1013;
   public t field_1014;
   public t field_1015;
   public U field_1016;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static ga method_2340(kc var0) {
      return var0.field_1013;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public kc() {
      String[] var10002 = new String[5];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Velocity";
      var10002[1] = "av";
      var10002[2] = "antivelocity";
      var10002[3] = "antivel";
      var10002[4] = "knockback";
      super("Velocity", var10002, true, -9206132, bE.MOVEMENT);
      nc var3 = nc.Normal;
      String[] var5 = new String[2];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Mode";
      var5[1] = "m";
      this.field_1013 = new ga(var3, var5);
      Boolean var4 = true;
      var5 = new String[2];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Water";
      var5[1] = "w";
      this.field_1010 = new t(var4, var5);
      var4 = true;
      var5 = new String[2];
      var10005 = true;
      var10006 = 1;
      var5[0] = "FishingHook";
      var5[1] = "fishhook";
      this.field_1011 = new t(var4, var5);
      var4 = false;
      var5 = new String[8];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Blocks";
      var5[1] = "Block";
      var5[2] = "BlockPush";
      var5[3] = "PushOutOfBlock";
      var5[4] = "PushOutOfBlocks";
      var5[5] = "BlocksPush";
      var5[6] = "bp";
      var5[7] = "b";
      this.field_1014 = new t(var4, var5);
      var4 = false;
      var5 = new String[2];
      var10005 = true;
      var10006 = 1;
      var5[0] = "Pushable";
      var5[1] = "Push";
      this.field_1015 = new t(var4, var5);
      Double var6 = 0.0D;
      Double var8 = 0.0D;
      Double var9 = 0.0D;
      Double var10 = 1.273197475E-314D;
      String[] var10007 = new String[8];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Horizontal";
      var10007[1] = "h%";
      var10007[2] = "HReduction";
      var10007[3] = "RHeduce";
      var10007[4] = "HLower";
      var10007[5] = "HVelocity_reduction";
      var10007[6] = "hv";
      var10007[7] = "h";
      this.field_1016 = new U(var6, var8, var9, var10, var10007);
      var6 = 0.0D;
      var8 = 0.0D;
      var9 = 0.0D;
      var10 = 1.273197475E-314D;
      var10007 = new String[8];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "Vertical";
      var10007[1] = "v%";
      var10007[2] = "VReduction";
      var10007[3] = "VReduce";
      var10007[4] = "VLower";
      var10007[5] = "VVelocity_reduction";
      var10007[6] = "vv";
      var10007[7] = "v";
      this.field_1012 = new U(var6, var8, var9, var10, var10007);
      t[] var10001 = new t[7];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_1013;
      var10001[1] = this.field_1010;
      var10001[2] = this.field_1011;
      var10001[3] = this.field_1014;
      var10001[4] = this.field_1015;
      var10001[5] = this.field_1016;
      var10001[6] = this.field_1012;
      this.f$c(var10001);
      ja[] var1 = new ja[4];
      var2 = true;
      var7 = 1;
      var1[0] = new RC(this);
      var1[1] = new Pc(this);
      var1[2] = new BC(this);
      var1[3] = new zb(this);
      this.method_2383(var1);
   }
}

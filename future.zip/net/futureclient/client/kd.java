package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;

public class kd extends ka {
   private EG field_1023;
   private t field_1024;
   private ga field_1025;

   public void method_4314() {
      if (f$e.player != null && ((tb)this.field_1025.method_3690()).equals(tb.Potion)) {
         f$e.gameSettings.gammaSetting = 1.0F;
         f$e.player.removePotionEffect(MobEffects.NIGHT_VISION);
         super.method_4314();
      }

      this.field_1023.method_814();
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static void method_2358(kd var0) {
      var0.method_4314();
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static t method_2361(kd var0) {
      return var0.field_1024;
   }

   public static EG method_2362(kd var0) {
      return var0.field_1023;
   }

   public static void method_2363(kd var0) {
      var0.method_4314();
   }

   public static ga method_2364(kd var0) {
      return var0.field_1025;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public void method_4326() {
      if (!this.field_1023.method_817(300L)) {
         this.field_1024.method_3689(false);
      }

      super.method_4326();
   }

   public kd() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Fullbright";
      var10002[1] = "fb";
      var10002[2] = "bright";
      var10002[3] = "brightness";
      super("Fullbright", var10002, true, -23445, bE.RENDER);
      tb var3 = tb.Gamma;
      String[] var6 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Mode";
      var6[1] = "m";
      var6[2] = "type";
      this.field_1025 = new ga(var3, var6);
      Boolean var4 = false;
      var6 = new String[5];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Automatic";
      var6[1] = "AutoEnable";
      var6[2] = "Auto";
      var6[3] = "AutoE";
      var6[4] = "AE";
      this.field_1024 = new t(var4, var6);
      this.field_1023 = new EG();
      t[] var10001 = new t[2];
      boolean var2 = true;
      byte var5 = 1;
      var10001[0] = this.field_1025;
      var10001[1] = this.field_1024;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var5 = 1;
      var1[0] = new SC(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

import net.minecraft.item.ItemStack;

public class ke extends CD {
   private final ItemStack field_1019;
   private final int field_1020;
   private int field_1021;

   public ke(ItemStack var1, int var2, int var3) {
      this.field_1019 = var1;
      this.field_1021 = var2;
      this.field_1020 = var3;
   }

   public int method_2350() {
      return this.field_1021;
   }

   public int method_3981() {
      return this.field_1020;
   }

   public ItemStack method_2379() {
      return this.field_1019;
   }

   public void method_2353(int var1) {
      this.field_1021 = var1;
   }
}

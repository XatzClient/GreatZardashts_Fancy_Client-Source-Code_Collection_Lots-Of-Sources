package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class kf extends CD {
   public int field_1003 = -7;
   public int field_1004 = 2;
   public int field_1005 = 8;
   public int field_1006 = 2;
   public int field_1007;

   public ScaledResolution method_2330() {
      return new ScaledResolution(Minecraft.getMinecraft());
   }
}

package net.futureclient.client;

import java.util.Iterator;
import java.util.StringJoiner;

public class kh extends xb {
   public String method_4224() {
      return "&e[module] [state]";
   }

   public kh() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Toggle";
      var10001[1] = "t";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length < 1) {
         return null;
      } else {
         String var2 = var1[0];
         Aa var3;
         Object[] var10001;
         boolean var10002;
         byte var10003;
         if ((var3 = YH.method_1211().method_1205().method_2163(var2)) == null) {
            StringJoiner var10 = new StringJoiner(", ");
            Iterator var5 = YH.method_1211().method_1205().method_2164().iterator();

            while(var5.hasNext()) {
               String[] var6;
               int var7 = (var6 = ((Aa)var5.next()).method_630()).length;

               int var8;
               for(int var10000 = var8 = 0; var10000 < var7; var10000 = var8) {
                  String var9;
                  if ((var9 = var6[var8]).contains(var2)) {
                     Object[] var11 = new Object[1];
                     boolean var12 = true;
                     byte var10004 = 1;
                     var11[0] = var9;
                     var10.add(String.format("&e%s&7", var11));
                  }

                  ++var8;
               }
            }

            if (var10.length() < 1) {
               return "That module does not exist.";
            } else {
               var10001 = new Object[1];
               var10002 = true;
               var10003 = 1;
               var10001[0] = var10.toString();
               return String.format("Did you mean: %s?", var10001);
            }
         } else if (!(var3 instanceof k)) {
            return "That module is not toggleable.";
         } else {
            ka var4 = (ka)var3;
            if (var1.length >= 2) {
               var4.method_2388(var1[1].toLowerCase().contains("activ") || var1[1].toLowerCase().contains("on") || var1[1].toLowerCase().contains("enable") || var1[1].toLowerCase().contains("true"));
            } else {
               var4.method_2390();
            }

            var10001 = new Object[2];
            var10002 = true;
            var10003 = 1;
            var10001[0] = var4.f$c()[0];
            var10001[1] = var4.method_2387() ? "&aon" : "&coff";
            return String.format("%s toggled %s&7.", var10001);
         }
      }
   }
}

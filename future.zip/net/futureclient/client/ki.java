package net.futureclient.client;

import net.minecraft.entity.Entity;

public final class ki extends ja {
   public final BI field_1008;

   private ki(BI var1) {
      this.field_1008 = var1;
   }

   public ki(BI var1, Fj var2) {
      this(var1);
   }

   public void method_4312(CD var1) {
      this.method_4193((ae)var1);
   }

   public void method_4193(ae var1) {
      BI.method_652(this.field_1008, (Entity)null);
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class lA extends ka {
   private U field_1037;
   private t field_1038;

   public static Minecraft method_4242() {
      return f$e;
   }

   public void method_4314() {
      ((r)((w)f$e).getTimer()).method_3790(1.0F);
      super.method_4314();
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static U method_2395(lA var0) {
      return var0.field_1037;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static t method_2397(lA var0) {
      return var0.field_1038;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public lA() {
      String[] var10002 = new String[5];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Timer";
      var10002[1] = "Timr";
      var10002[2] = "GameSpeed";
      var10002[3] = "Speedup";
      var10002[4] = "Taimer";
      super("Timer", var10002, true, -31470, bE.MISCELLANEOUS);
      Boolean var3 = false;
      String[] var6 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "TPSSync";
      var6[1] = "Sync";
      var6[2] = "TPSSynchronize";
      var6[3] = "Synchronize";
      this.field_1038 = new t(var3, var6);
      Float var4 = 1.0F;
      Float var7 = 0.1F;
      Float var8 = 50.0F;
      String[] var9 = new String[4];
      boolean var10007 = true;
      byte var10008 = 1;
      var9[0] = "Speed";
      var9[1] = "TimerSpeed";
      var9[2] = "Timer";
      var9[3] = "GameSpeed";
      this.field_1037 = new U(var4, var7, var8, var9);
      t[] var10001 = new t[2];
      boolean var2 = true;
      byte var5 = 1;
      var10001[0] = this.field_1038;
      var10001[1] = this.field_1037;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var5 = 1;
      var1[0] = new Gc(this);
      this.f$c(var1);
   }
}

package net.futureclient.client;

import java.awt.Color;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.apache.logging.log4j.Level;
import org.lwjgl.opengl.GL11;

public class lC extends ja {
   public final Lb field_1018;

   public lC(Lb var1) {
      this.field_1018 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4042((Df)var1);
   }

   private static boolean method_2347(IA var0) {
      return System.currentTimeMillis() - var0.f$c() > TimeUnit.SECONDS.toMillis(5L);
   }

   private static void method_2348(Entity var0, IA var1) {
      Vec3d var2 = var1.f$c();
      double var3 = var0.getDistance(var2.x, var2.y, var2.z);
      double var5 = 1.17473687E-314D * var3;
      if (var3 <= 0.0D) {
         var5 = 1.751919725E-314D;
      }

      GL11.glPushMatrix();
      boolean var8 = GL11.glIsEnabled(2896);
      boolean var4 = GL11.glIsEnabled(2929);
      if (var8) {
         GL11.glDisable(2896);
      }

      if (var4) {
         GL11.glDisable(2929);
      }

      GL11.glTranslated(var2.x - ((A)Lb.method_2944().getRenderManager()).getRenderPosX(), var2.y - ((A)Lb.method_2969().getRenderManager()).getRenderPosY(), var2.z - ((A)Lb.method_3770().getRenderManager()).getRenderPosZ());
      GL11.glRotatef(-Lb.method_3772().getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(Lb.method_3771().getRenderManager().playerViewX, Lb.method_3775().gameSettings.thirdPersonView == 2 ? -1.0F : 1.0F, 0.0F, (float)0);
      GL11.glScaled(-var5, -var5, var5);
      boolean var10000;
      YE var7;
      if ((Boolean)(var7 = (YE)YH.method_1211().method_1205().method_2166(YE.class)).field_583.method_3690()) {
         var10000 = var8;
         var7.field_573.method_3678(var1.f$c(), (double)((float)(-(Lb.method_3759().fontRenderer.getStringWidth(var1.f$c()) / 2))), (double)(-(Lb.method_3774().fontRenderer.FONT_HEIGHT - 1)), -1);
      } else {
         Lb.method_3773().fontRenderer.drawStringWithShadow(var1.f$c(), (float)(-(Lb.method_3776().fontRenderer.getStringWidth(var1.f$c()) / 2)), (float)(-(Lb.method_3752().fontRenderer.FONT_HEIGHT - 1)), -1);
         var10000 = var8;
      }

      if (var10000) {
         GL11.glEnable(2896);
      }

      if (var4) {
         GL11.glEnable(2929);
      }

      GL11.glPopMatrix();
   }

   public void method_4042(Df var1) {
      if (var1.method_823().equals(GF.POST)) {
         Object var2 = Lb.method_3021().getRenderViewEntity() == null ? Lb.method_2979().player : Lb.method_3008().getRenderViewEntity();

         try {
            boolean var3 = Lb.method_3022().gameSettings.fancyGraphics;
            Lb.method_2954().gameSettings.fancyGraphics = false;
            Lb.field_205 = false;
            float var4 = Lb.method_2936().gameSettings.gammaSetting;
            Lb.method_3010().gameSettings.gammaSetting = 100.0F;
            Lb.method_388(this.field_1018);
            double var11;
            double var13;
            double var15;
            Iterator var10000;
            boolean var10001;
            switch(qB.f$G[((XC)Lb.method_371(this.field_1018).method_3690()).ordinal()]) {
            case 1:
               var10001 = false;
               Lb.method_396(this.field_1018);
               Lb.method_390(this.field_1018);
               Lb.method_346(this.field_1018);
               Lb.method_390(this.field_1018);
               Lb.method_406(this.field_1018);
               Lb.method_339(this.field_1018);
               Lb.method_390(this.field_1018);
               Lb.method_378(this.field_1018);
               break;
            case 2:
               Iterator var5 = EI.method_851().iterator();

               label253:
               while(true) {
                  while(true) {
                     var10000 = var5;

                     while(true) {
                        if (!var10000.hasNext()) {
                           break label253;
                        }

                        Entity var6 = (Entity)var5.next();
                        if (!Lb.method_352(this.field_1018, var6)) {
                           break;
                        }

                        if (!(var6 instanceof EntityPlayer)) {
                           int var25 = -1;
                           if ((Ti.method_1815(var6) || Ti.method_1818(var6)) && (Boolean)Lb.method_386(this.field_1018).method_3690()) {
                              var25 = -1711341568;
                           }

                           if ((Ti.method_1821(var6) || Ti.method_1817(var6)) && (Boolean)Lb.method_398(this.field_1018).method_3690()) {
                              var25 = -16726016;
                           }

                           if (var6 instanceof EntityEnderCrystal && (Boolean)Lb.method_389(this.field_1018).method_3690()) {
                              var25 = -1711323905;
                           }

                           double var26 = var6.lastTickPosX + (var6.posX - var6.lastTickPosX) * (double)var1.method_3117() - ((A)Lb.method_2980().getRenderManager()).getRenderPosX();
                           double var36 = var6.lastTickPosY + (var6.posY - var6.lastTickPosY) * (double)var1.method_3117() - ((A)Lb.method_3017().getRenderManager()).getRenderPosY();
                           double var12 = var6.lastTickPosZ + (var6.posZ - var6.lastTickPosZ) * (double)var1.method_3117() - ((A)Lb.method_2983().getRenderManager()).getRenderPosZ();
                           GL11.glPolygonOffset(-120000.0F, -120000.0F);
                           Lb.method_357(this.field_1018, var6, var26, var36, var12, var25);
                           GL11.glPolygonOffset(120000.0F, 120000.0F);
                           break;
                        }

                        EntityPlayer var7 = (EntityPlayer)var6;
                        se var8 = (se)YH.method_1211().method_1205().method_2166(se.class);
                        KD var9 = (KD)YH.method_1211().method_1205().method_2166(KD.class);
                        if (EI.method_886(var7)) {
                           int var10;
                           EntityPlayer var49;
                           if (YH.method_1211().method_1216().method_1481(var7.getName())) {
                              var10 = -2147418113;
                              var49 = var7;
                           } else if (var7.hurtTime > 0) {
                              var10 = -2130771968;
                              var49 = var7;
                           } else if (var8 != null && var8.f$c() && (Boolean)var8.field_1630.method_3690() && var8.method_3978(var7, Lb.method_2939().player)) {
                              var10 = -2147418113;
                              var49 = var7;
                           } else if (var9 != null && var9.f$c() && (Boolean)var9.field_132.method_3690() && EI.method_848(var7)) {
                              var10 = -2147418113;
                              var49 = var7;
                           } else {
                              var10 = -1711341568;
                              var49 = var7;
                           }

                           var11 = var49.lastTickPosX + (var7.posX - var7.lastTickPosX) * (double)var1.method_3117() - ((A)Lb.method_2938().getRenderManager()).getRenderPosX();
                           var13 = var7.lastTickPosY + (var7.posY - var7.lastTickPosY) * (double)var1.method_3117() - ((A)Lb.method_3004().getRenderManager()).getRenderPosY();
                           var15 = var7.lastTickPosZ + (var7.posZ - var7.lastTickPosZ) * (double)var1.method_3117() - ((A)Lb.method_2932().getRenderManager()).getRenderPosZ();
                           GL11.glPolygonOffset(-120000.0F, -120000.0F);
                           Lb.method_357(this.field_1018, var7, var11, var13, var15, var10);
                           GL11.glPolygonOffset(120000.0F, 120000.0F);
                           break;
                        }

                        var10000 = var5;
                     }
                  }
               }
            }

            Frustum var22 = new Frustum();
            Object var23 = Lb.method_2981().getRenderViewEntity() == null ? Lb.method_2973().player : Lb.method_2985().getRenderViewEntity();
            var22.setPosition(((Entity)var23).lastTickPosX + (((Entity)var23).posX - ((Entity)var23).lastTickPosX) * (double)((w)Lb.method_2977()).getTimer().renderPartialTicks, ((Entity)var23).lastTickPosY + (((Entity)var23).posY - ((Entity)var23).lastTickPosY) * (double)((w)Lb.method_3003()).getTimer().renderPartialTicks, ((Entity)var23).lastTickPosZ + (((Entity)var23).posZ - ((Entity)var23).lastTickPosZ) * (double)((w)Lb.method_3018()).getTimer().renderPartialTicks);
            if (Lb.method_371(this.field_1018).method_3690() != XC.Shader && (Boolean)Lb.method_347(this.field_1018).method_3690()) {
               GL11.glPushMatrix();
               GL11.glPushAttrib(1048575);
               boolean var28 = GL11.glIsEnabled(2896);
               boolean var27 = GL11.glIsEnabled(3042);
               boolean var30 = GL11.glIsEnabled(3553);
               boolean var38 = GL11.glIsEnabled(2848);
               if (var28) {
                  GL11.glDisable(2896);
               }

               GL11.glBlendFunc(770, 771);
               if (!var27) {
                  GL11.glEnable(3042);
               }

               GL11.glLineWidth(Lb.method_356(this.field_1018).method_3692().floatValue() / 2.0F);
               if (var30) {
                  GL11.glDisable(3553);
               }

               if (!var38) {
                  GL11.glEnable(2848);
               }

               zF var35 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
               Iterator var39 = Lb.method_2943().world.getLoadedEntityList().iterator();

               label206:
               while(true) {
                  label204:
                  while(true) {
                     for(var10000 = var39; var10000.hasNext(); var10000 = var39) {
                        Entity var43;
                        if (!((var43 = (Entity)var39.next()) instanceof EntityItem)) {
                           continue label204;
                        }

                        AxisAlignedBB var14 = var43.getEntityBoundingBox();
                        if (var22.isBoundingBoxInFrustum(var14)) {
                           Vec3d var46 = Di.method_927(var43);
                           AxisAlignedBB var16 = var14.expand(1.273197475E-314D, 0.0D, 1.273197475E-314D).expand(1.273197475E-314D, 1.273197475E-314D, 1.273197475E-314D).offset(-var43.posX, -var43.posY, -var43.posZ).offset(var46.x, var46.y, var46.z);
                           GL11.glColor4d((double)((float)var35.field_1445.getRed() / 255.0F), (double)((float)var35.field_1445.getGreen() / 255.0F), (double)((float)var35.field_1445.getBlue() / 255.0F), var43.ticksExisted <= 42 ? (double)((float)(var43.ticksExisted * 6) / 255.0F) : 1.0D);
                           Di.method_914(var16);
                           continue label204;
                        }
                     }

                     if (!var38) {
                        GL11.glDisable(2848);
                     }

                     if (var30) {
                        GL11.glEnable(3553);
                     }

                     if (!var27) {
                        GL11.glDisable(3042);
                     }

                     if (var28) {
                        GL11.glEnable(2896);
                     }

                     GL11.glPopAttrib();
                     GL11.glPopMatrix();
                     break label206;
                  }
               }
            }

            Lb.method_358(this.field_1018).removeIf(test<invokedynamic>());
            if ((Boolean)Lb.method_408(this.field_1018).method_3690()) {
               Lb.method_358(this.field_1018).forEach(((Class)var2).accept<invokedynamic>((Entity)var2));
            }

            Iterator var31;
            if ((Boolean)Lb.method_340(this.field_1018).method_3690()) {
               var10000 = var31 = Lb.method_2958().world.getLoadedEntityList().iterator();

               while(var10000.hasNext()) {
                  Entity var29;
                  UUID var33;
                  if ((var33 = EI.method_873(var29 = (Entity)var31.next())) == null) {
                     var10000 = var31;
                  } else {
                     String var40 = hH.f$E(var33);
                     var11 = var29.lastTickPosX + (var29.posX - var29.lastTickPosX) * (double)((w)Lb.method_2960()).getTimer().renderPartialTicks;
                     var13 = var29.lastTickPosY + (var29.posY - var29.lastTickPosY) * (double)((w)Lb.method_2930()).getTimer().renderPartialTicks + (double)var29.getEyeHeight();
                     var15 = var29.lastTickPosZ + (var29.posZ - var29.lastTickPosZ) * (double)((w)Lb.method_3012()).getTimer().renderPartialTicks;
                     double var17 = ((Entity)var2).getDistance(var11, var13, var15);
                     double var19 = 1.17473687E-314D * var17;
                     if (var17 <= 0.0D) {
                        var19 = 1.751919725E-314D;
                     }

                     GL11.glPushMatrix();
                     boolean var24 = GL11.glIsEnabled(2896);
                     boolean var50 = GL11.glIsEnabled(2929);
                     if (var24) {
                        GL11.glDisable(2896);
                     }

                     if (var50) {
                        GL11.glDisable(2929);
                     }

                     GL11.glTranslated(var11 - ((A)Lb.method_3023().getRenderManager()).getRenderPosX(), var13 - ((A)Lb.method_2950().getRenderManager()).getRenderPosY(), var15 - ((A)Lb.method_3019().getRenderManager()).getRenderPosZ());
                     GL11.glRotatef(-Lb.method_3020().getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
                     GL11.glRotatef(Lb.method_2937().getRenderManager().playerViewX, Lb.method_2976().gameSettings.thirdPersonView == 2 ? -1.0F : 1.0F, 0.0F, (float)0);
                     GL11.glScaled(-var19, -var19, var19);
                     YE var18;
                     boolean var51;
                     if ((Boolean)(var18 = (YE)YH.method_1211().method_1205().method_2166(YE.class)).field_583.method_3690()) {
                        var51 = var24;
                        var18.field_573.method_3678(var40, (double)((float)(-(Lb.method_2982().fontRenderer.getStringWidth(var40) / 2))), (double)(-(Lb.method_2992().fontRenderer.FONT_HEIGHT - 1)), -1);
                     } else {
                        Lb.method_2959().fontRenderer.drawStringWithShadow(var40, (float)(-(Lb.method_3005().fontRenderer.getStringWidth(var40) / 2)), (float)(-(Lb.method_2940().fontRenderer.FONT_HEIGHT - 1)), -1);
                        var51 = var24;
                     }

                     if (var51) {
                        GL11.glEnable(2896);
                     }

                     if (var50) {
                        GL11.glEnable(2929);
                     }

                     GL11.glPopMatrix();
                     var10000 = var31;
                  }
               }
            }

            if ((Boolean)Lb.method_380(this.field_1018).method_3690()) {
               var10000 = var31 = Lb.method_367(this.field_1018).iterator();

               while(var10000.hasNext()) {
                  BlockPos var32 = (BlockPos)var31.next();
                  eC var34;
                  if ((var34 = Lb.method_369(this.field_1018, var32)) == null) {
                     var10000 = var31;
                     Lb.method_367(this.field_1018).remove(var32);
                  } else {
                     BlockPos var42 = Lb.method_2955().player.getPosition();
                     if (var32.getDistance(var42.getX(), var42.getY(), var42.getZ()) > 0.0D) {
                        var10000 = var31;
                     } else {
                        AxisAlignedBB var37 = Lb.method_2933().world.getBlockState(var32).getBoundingBox(Lb.method_3011().world, var32).offset((double)var32.getX(), (double)var32.getY(), (double)var32.getZ());
                        if (!var22.isBoundingBoxInFrustum(var37)) {
                           var10000 = var31;
                        } else {
                           AxisAlignedBB var41 = var37.offset(-((A)Lb.method_2988().getRenderManager()).getRenderPosX(), -((A)Lb.method_2957().getRenderManager()).getRenderPosY(), -((A)Lb.method_2972().getRenderManager()).getRenderPosZ());
                           GL11.glPushMatrix();
                           GL11.glPushAttrib(1048575);
                           short var44 = 0;
                           short var45 = 0;
                           byte var47 = 0;
                           switch(qB.f$e[var34.ordinal()]) {
                           case 1:
                              var10001 = false;
                              var44 = 255;
                              break;
                           case 2:
                              var45 = 255;
                              break;
                           case 3:
                              var44 = 255;
                              var45 = 255;
                           }

                           Color var48 = new Color((float)var44 / 255.0F, (float)var45 / 255.0F, (float)var47 / 255.0F, 0.225F);
                           Di.method_894();
                           nI.method_2430(var41, 1.5F, var48);
                           Di.method_942();
                           var48 = new Color((float)var48.getRed() / 255.0F, (float)var48.getGreen() / 255.0F, (float)var48.getBlue() / 255.0F, 0.075F);
                           Di.method_894();
                           nI.method_2434(var41, var48);
                           Di.method_942();
                           GL11.glColor4f((float)1, (float)1, 1.0F, (float)1);
                           GL11.glPopAttrib();
                           GL11.glPopMatrix();
                           var10000 = var31;
                        }
                     }
                  }
               }
            }

            if ((Boolean)Lb.method_350(this.field_1018).method_3690()) {
               RenderHelper.enableStandardItemLighting();
               Lb.method_396(this.field_1018);
               Lb.method_351(this.field_1018);
               Lb.method_346(this.field_1018);
               Lb.method_351(this.field_1018);
               Lb.method_406(this.field_1018);
               Lb.method_339(this.field_1018);
               Lb.method_351(this.field_1018);
               Lb.method_378(this.field_1018);
               RenderHelper.disableStandardItemLighting();
            }

            if ((Boolean)Lb.method_360(this.field_1018).method_3690()) {
               Lb.method_396(this.field_1018);
               Lb.method_368(this.field_1018);
               Lb.method_346(this.field_1018);
               Lb.method_368(this.field_1018);
               Lb.method_406(this.field_1018);
               Lb.method_339(this.field_1018);
               Lb.method_368(this.field_1018);
               Lb.method_378(this.field_1018);
            }

            Lb.field_205 = true;
            Lb.method_2971().gameSettings.gammaSetting = var4;
            Lb.method_2962().gameSettings.fancyGraphics = var3;
            nI.method_2438(new Color(255, 255, 255, 255));
         } catch (Exception var21) {
            la.method_2324().method_2323(Level.ERROR, "ESP is causing a crash.");
            var21.printStackTrace();
         }
      }
   }
}

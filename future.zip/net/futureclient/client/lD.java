package net.futureclient.client;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.util.EnumHand;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;
import net.minecraft.util.math.BlockPos;

public class lD extends ja {
   public final fD field_1009;

   public lD(fD var1) {
      this.field_1009 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      if (!(Boolean)fD.method_3350(this.field_1009).method_3690()) {
         fD.method_3355(this.field_1009, fD.method_3308(this.field_1009, fD.method_3334(this.field_1009, fD.method_3315(this.field_1009, (Boolean)null))));
      }

      if (!(Boolean)fD.method_3339(this.field_1009).method_3690()) {
         fD.method_3329(this.field_1009, (Boolean)null);
      }

      Class var2;
      if ((var2 = fD.method_4282().player.movementInput.getClass()) == MovementInputFromOptions.class || var2 == MovementInput.class) {
         fD.method_3307(this.field_1009).method_814();
         fD.method_3425().updatePlayerMoveState();
         fD.method_4290().player.movementInput = fD.method_3425();
      }

      if (fD.method_3307(this.field_1009).method_811(fD.method_3322(this.field_1009).method_3692().floatValue() * 1000.0F)) {
         if ((Boolean)fD.method_3350(this.field_1009).method_3690()) {
            if (fD.method_3317(this.field_1009) > 7) {
               fD.method_3330(this.field_1009, -fD.method_3327(this.field_1009).nextInt(20));
            }

            lD var10000;
            switch(fD.method_3317(this.field_1009)) {
            case 0:
               var10000 = this;
               boolean var10001 = false;
               fD.method_3355(this.field_1009, true);
               fD.method_3308(this.field_1009, fD.method_3315(this.field_1009, fD.method_3334(this.field_1009, false)));
               break;
            case 1:
               var10000 = this;
               fD.method_3355(this.field_1009, fD.method_3315(this.field_1009, true));
               fD.method_3308(this.field_1009, fD.method_3334(this.field_1009, false));
               break;
            case 2:
               var10000 = this;
               fD.method_3315(this.field_1009, true);
               fD.method_3355(this.field_1009, fD.method_3308(this.field_1009, fD.method_3334(this.field_1009, false)));
               break;
            case 3:
               var10000 = this;
               fD.method_3315(this.field_1009, fD.method_3308(this.field_1009, true));
               fD.method_3334(this.field_1009, fD.method_3355(this.field_1009, false));
               break;
            case 4:
               var10000 = this;
               fD.method_3308(this.field_1009, true);
               fD.method_3355(this.field_1009, fD.method_3334(this.field_1009, fD.method_3315(this.field_1009, false)));
               break;
            case 5:
               var10000 = this;
               fD.method_3308(this.field_1009, fD.method_3334(this.field_1009, true));
               fD.method_3355(this.field_1009, fD.method_3315(this.field_1009, false));
               break;
            case 6:
               var10000 = this;
               fD.method_3334(this.field_1009, true);
               fD.method_3355(this.field_1009, fD.method_3308(this.field_1009, fD.method_3315(this.field_1009, false)));
               break;
            case 7:
               var10000 = this;
               fD.method_3355(this.field_1009, fD.method_3334(this.field_1009, true));
               fD.method_3308(this.field_1009, fD.method_3315(this.field_1009, false));
               break;
            default:
               var10000 = this;
               fD.method_3355(this.field_1009, fD.method_3308(this.field_1009, fD.method_3334(this.field_1009, fD.method_3315(this.field_1009, false))));
            }

            if (fD.method_3333(var10000.field_1009).method_817((long)fD.method_3327(this.field_1009).nextInt(1000)) && (fD.method_4272().player.motionX == 0.0D || fD.method_4244().player.motionZ == 0.0D)) {
               fD.method_3321(this.field_1009);
               fD.method_3333(this.field_1009).method_814();
            }
         }

         if (!fD.method_3320(this.field_1009).method_811(fD.method_3322(this.field_1009).method_3692().floatValue() * 1000.0F)) {
            return;
         }

         fD.method_3320(this.field_1009).method_814();
         if ((Boolean)fD.method_3332(this.field_1009).method_3690()) {
            fD.method_4289().player.swingArm(EnumHand.MAIN_HAND);
         }

         if ((Boolean)fD.method_3343(this.field_1009).method_3690()) {
            fD.method_4283().player.sendChatMessage((new StringBuilder()).insert(0, "/").append(Long.toHexString(Double.doubleToLongBits(Math.random()))).toString());
         }

         if ((Boolean)fD.method_3347(this.field_1009).method_3690()) {
            fD.method_4243().player.connection.sendPacket(new CPacketTabComplete((new StringBuilder()).insert(0, "/").append(Long.toHexString(Double.doubleToLongBits(Math.random()))).toString(), (BlockPos)null, false));
         }

         if ((Boolean)fD.method_3345(this.field_1009).method_3690()) {
            float var3 = fD.method_3327(this.field_1009).nextBoolean() ? (float)fD.method_3327(this.field_1009).nextInt(45) : (float)(-fD.method_3327(this.field_1009).nextInt(45));
            EntityPlayerSP var4 = fD.method_4280().player;
            var4.rotationYaw = (float)((double)var4.rotationYaw + (double)var3 + (fD.method_3327(this.field_1009).nextBoolean() ? Math.random() * 0.0D : -(Math.random() * 0.0D)));
            fD.method_4279().player.rotationPitch = var3;
         }

         if ((Boolean)fD.method_3313(this.field_1009).method_3690()) {
            ((w)fD.method_4271()).method_3640(lf.RIGHT_CLICK);
         }

         if ((Boolean)fD.method_3358(this.field_1009).method_3690()) {
            fD.method_4267().player.connection.sendPacket(new Position(fD.method_4278().player.posX, fD.method_4275().player.posY - Math.random(), fD.method_4277().player.posZ, fD.method_4270().player.onGround));
         }

         if ((Boolean)fD.method_3310(this.field_1009).method_3690()) {
            fD.method_4273().player.jump();
         }

         if ((Boolean)fD.method_3339(this.field_1009).method_3690() && !fD.method_4276().player.isRiding() && !((a)fD.method_4274().player).method_3702()) {
            fD.method_3329(this.field_1009, fD.method_3356(this.field_1009) == null || !fD.method_3356(this.field_1009));
            return;
         }
      } else {
         fD.method_3355(this.field_1009, fD.method_3308(this.field_1009, fD.method_3334(this.field_1009, fD.method_3315(this.field_1009, fD.method_3329(this.field_1009, (Boolean)null)))));
      }

   }
}

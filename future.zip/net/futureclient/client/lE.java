package net.futureclient.client;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

public class lE extends CD {
   private ItemStack field_1026;
   private BlockPos field_1027;
   private EntityLivingBase field_1028;

   public lE(EntityLivingBase var1, BlockPos var2, ItemStack var3) {
      this.field_1028 = var1;
      this.field_1027 = var2;
      this.field_1026 = var3;
   }

   public EntityLivingBase method_2377() {
      return this.field_1028;
   }

   public BlockPos method_3153() {
      return this.field_1027;
   }

   public ItemStack method_2379() {
      return this.field_1026;
   }
}

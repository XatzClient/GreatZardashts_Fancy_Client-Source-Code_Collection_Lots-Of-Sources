package net.futureclient.client;

import net.minecraft.util.math.AxisAlignedBB;

public class lF extends CD {
   private final AxisAlignedBB field_1022;

   public lF(AxisAlignedBB var1) {
      this.field_1022 = var1;
   }

   public AxisAlignedBB method_2797() {
      return this.field_1022;
   }
}

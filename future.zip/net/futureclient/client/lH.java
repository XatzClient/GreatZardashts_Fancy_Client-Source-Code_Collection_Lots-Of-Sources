package net.futureclient.client;

public class lH extends xb {
   public String method_4224() {
      return "&e[char]";
   }

   public lH() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Prefix";
      var10001[1] = "Pref";
      super(var10001);
   }

   public String method_4228(String[] var1) {
      if (var1.length == 1) {
         String var2;
         if ((var2 = var1[0]).equalsIgnoreCase(YH.method_1211().method_1213().method_2260())) {
            return "That is already your prefix.";
         } else {
            YH.method_1211().method_1213().method_2259(var2);
            Object[] var10001 = new Object[1];
            boolean var10002 = true;
            byte var10003 = 1;
            var10001[0] = var2;
            return String.format("Command prefix set to %s.", var10001);
         }
      } else {
         return null;
      }
   }
}

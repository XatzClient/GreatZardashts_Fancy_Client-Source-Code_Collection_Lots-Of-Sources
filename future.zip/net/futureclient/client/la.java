package net.futureclient.client;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class la implements I {
   private static final Logger field_998;
   public static final int field_999;
   private static final la field_1000;
   public static final int field_1001 = 1337 + (new Random()).nextInt(2147482311);

   static {
      field_999 = -field_1001;
      field_1000 = new la();
      field_998 = LogManager.getLogger(YH.field_548);
   }

   public void method_2322(String var1) {
      this.method_2326(var1, true);
   }

   public void method_2323(Level var1, String var2) {
      field_998.log(var1, var2);
   }

   public static la method_2324() {
      return field_1000;
   }

   public void method_2325(ITextComponent var1, boolean var2) {
      Minecraft var3;
      if ((var3 = Minecraft.getMinecraft()).ingameGUI != null) {
         var1 = (new TextComponentString("[Future] ")).setStyle((new Style()).setColor(TextFormatting.RED)).appendSibling(var1);
         var3.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(var1, var2 ? field_999 : field_1001);
      }

   }

   public void method_2326(String var1, boolean var2) {
      ITextComponent var3 = (new TextComponentString(var1.replace("&", "§"))).setStyle((new Style()).setColor(TextFormatting.GRAY));
      this.method_2325(var3, var2);
   }
}

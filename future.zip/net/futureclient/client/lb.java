package net.futureclient.client;

import net.minecraft.network.play.server.SPacketPlayerPosLook;

public class lb extends ja {
   public final gb field_996;

   public lb(gb var1) {
      this.field_996 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketPlayerPosLook) {
         gb.method_3500(this.field_996).method_814();
      }

   }
}

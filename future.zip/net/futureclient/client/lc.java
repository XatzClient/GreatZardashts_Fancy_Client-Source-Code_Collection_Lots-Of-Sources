package net.futureclient.client;

public class lc extends ja {
   public final ac field_975;

   public lc(ac var1) {
      this.field_975 = var1;
   }

   public void method_2280(KE var1) {
      var1.method_729((Boolean)this.field_975.field_1192.method_3690());
   }

   public void method_4312(CD var1) {
      this.method_2280((KE)var1);
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.MobEffects;

public class ld extends ka {
   public ga field_974;

   public void method_4314() {
      super.method_4314();
      KeyBinding.setKeyBindState(f$e.gameSettings.keyBindSprint.getKeyCode(), EI.method_860(f$e.gameSettings.keyBindSprint));
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static boolean method_2277(ld var0) {
      return var0.method_4325();
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   private boolean method_4325() {
      return f$e.player.onGround && !f$e.player.isSneaking() && f$e.player.movementInput.moveForward >= 0.8F && !f$e.player.collidedHorizontally && EI.method_890() && ((float)f$e.player.getFoodStats().getFoodLevel() > 6.0F || f$e.player.capabilities.allowFlying) && !f$e.player.isPotionActive(MobEffects.BLINDNESS);
   }

   public ld() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Sprint";
      var10002[1] = "Spritn";
      var10002[2] = "Spri";
      var10002[3] = "Sprnt";
      super("Sprint", var10002, true, -7030642, bE.MOVEMENT);
      Ab var3 = Ab.Legit;
      String[] var5 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Mode";
      var5[1] = "m";
      var5[2] = "Type";
      var5[3] = "Mod";
      this.field_974 = new ga(var3, var5);
      t[] var10001 = new t[1];
      boolean var2 = true;
      byte var4 = 1;
      var10001[0] = this.field_974;
      this.f$c(var10001);
      ja[] var1 = new ja[2];
      var2 = true;
      var4 = 1;
      var1[0] = new oc(this);
      var1[1] = new rB(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Spliterator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Items;
import net.minecraft.item.ItemFishFood;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemFishFood.FishType;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class le extends ka {
   private int field_983;
   private boolean field_984;
   private ub field_985;
   private int field_986;
   private final U field_987;
   private final U field_988;
   private final U field_989;
   private final U field_990;
   private boolean field_991;
   private int field_992;

   public static U method_2284(le var0) {
      return var0.field_988;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public void method_4314() {
      super.method_4314();
      boolean var10003 = true;
      byte var10004 = 1;
      this.field_991 = false;
      if (this.field_985.equals(ub.Eating)) {
         boolean var10002 = true;
         byte var1 = 1;
         this.method_2312(false);
      }

      this.method_2306(ub.Waiting);
   }

   public boolean method_2849() {
      return this.field_991;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static boolean method_2289(le var0) {
      return var0.field_991;
   }

   public static int method_2290(le var0, int var1) {
      return var0.field_986 = var1;
   }

   public static boolean method_2291(le var0, boolean var1) {
      return var0.field_984 = var1;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static U method_2293(le var0) {
      return var0.field_990;
   }

   public static int method_2294(le var0) {
      return var0.field_983;
   }

   public static boolean method_2295(le var0, ItemStack var1) {
      return var0.method_3228(var1);
   }

   private boolean method_3228(ItemStack var1) {
      boolean var6;
      byte var7;
      if (!(var1.getItem() instanceof ItemFood)) {
         var6 = true;
         var7 = 1;
         return false;
      } else {
         label26: {
            ItemFood var2;
            PotionEffect var3;
            if ((var3 = ((q)(var2 = (ItemFood)var1.getItem())).getPotionId()) != null) {
               Spliterator var10000 = Potion.REGISTRY.spliterator();
               boolean var10002 = true;
               byte var10003 = 1;
               Stream var4 = StreamSupport.stream(var10000, false).filter(test<invokedynamic>());
               Potion var10001 = var3.getPotion();
               var10001.getClass();
               if (var4.anyMatch(var10001.test<invokedynamic>(var10001))) {
                  break label26;
               }
            }

            if (!(var2 instanceof ItemFishFood) || !FishType.byItemStack(var1).equals(FishType.PUFFERFISH)) {
               byte var5 = 1;
               var7 = 1;
               return true;
            }
         }

         var6 = true;
         var7 = 1;
         return false;
      }
   }

   public static int method_2297(le var0, int var1) {
      return var0.field_983 = var1;
   }

   public static Map method_2298(le var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.method_2302();
   }

   public static boolean method_2299(le var0) {
      return var0.method_4325();
   }

   public static int method_2300(le var0) {
      return var0.field_986;
   }

   public static ub method_2301(le var0) {
      return var0.field_985;
   }

   private Map method_2302() {
      LinkedHashMap var1 = new LinkedHashMap();
      int var10000 = 0;
      boolean var10001 = true;
      byte var10002 = 1;
      int var2 = 0;

      while(true) {
         boolean var4 = true;
         byte var10003 = 1;
         if (var10000 >= 9) {
            return var1;
         }

         ItemStack var3;
         if ((var3 = f$e.player.inventory.getStackInSlot(var2)).getItem() != Items.AIR) {
            var1.put(var2, var3);
         }

         ++var2;
         var10000 = var2;
      }
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static boolean method_2304(le var0, boolean var1) {
      return var0.field_991 = var1;
   }

   public static U method_2305(le var0) {
      return var0.field_987;
   }

   private void method_2306(ub var1) {
      this.field_985 = var1;
      boolean var10002 = true;
      byte var10003 = 1;
      this.field_992 = 0;
   }

   public static void method_2307(le var0, boolean var1) {
      var0.method_2312(var1);
   }

   public static void method_2308(le var0, ub var1) {
      var0.method_2306(var1);
   }

   private boolean method_4325() {
      boolean var10003 = true;
      boolean var10004 = true;
      boolean var10005 = true;
      boolean var10006 = true;
      byte var1 = 1;
      byte var2 = 1;
      this.field_991 = true;
      return this.field_984;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static U method_2311(le var0) {
      return var0.field_989;
   }

   private void method_2312(boolean var1) {
      KeyBinding.setKeyBindState(f$e.gameSettings.keyBindUseItem.getKeyCode(), var1);
   }

   public static int method_2313(le var0) {
      byte var10003 = 1;
      byte var10004 = 1;
      return ++var0.field_992;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public le() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[4];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "AutoEat";
      byte var6 = 1;
      var10006 = 1;
      var10002[1] = "AutoEater";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "AutoEating";
      var10005 = true;
      var10006 = 1;
      var10002[3] = "AutoFood";
      var10004 = 1;
      var6 = 1;
      super("AutoEat", var10002, true, 16773918, bE.MISCELLANEOUS);
      Float var3 = 19.0F;
      Float var4 = 0.0F;
      Float var8 = 19.0F;
      byte var10007 = 1;
      byte var10008 = 1;
      Integer var9 = 1;
      boolean var11 = true;
      byte var10009 = 1;
      String[] var10 = new String[2];
      var11 = true;
      var10009 = 1;
      boolean var10010 = true;
      byte var10011 = 1;
      var10[0] = "Hunger";
      byte var12 = 1;
      var10011 = 1;
      var10[1] = "FoodLevel";
      this.field_988 = new U(var3, var4, var8, var9, var10);
      var3 = 10.0F;
      var4 = 0.0F;
      var8 = 100.0F;
      var10007 = 1;
      var10008 = 1;
      var9 = 1;
      var11 = true;
      var10009 = 1;
      var10 = new String[4];
      var11 = true;
      var10009 = 1;
      var10010 = true;
      var10011 = 1;
      var10[0] = "Start Ticks";
      var12 = 1;
      var10011 = 1;
      var10[1] = "StartTicks";
      var10010 = true;
      var10011 = 1;
      var10[2] = "StartFactor";
      var10010 = true;
      var10011 = 1;
      var10[3] = "startt";
      this.field_989 = new U(var3, var4, var8, var9, var10);
      var3 = 5.0F;
      var4 = 0.0F;
      var8 = 10.0F;
      var10007 = 1;
      var10008 = 1;
      var9 = 1;
      var11 = true;
      var10009 = 1;
      var10 = new String[4];
      var11 = true;
      var10009 = 1;
      var10010 = true;
      var10011 = 1;
      var10[0] = "Stop Ticks";
      var12 = 1;
      var10011 = 1;
      var10[1] = "StopTicks";
      var10010 = true;
      var10011 = 1;
      var10[2] = "StopFactor";
      var10010 = true;
      var10011 = 1;
      var10[3] = "stopt";
      this.field_990 = new U(var3, var4, var8, var9, var10);
      var3 = 5.0F;
      var4 = 0.0F;
      var8 = 20.0F;
      var10007 = 1;
      var10008 = 1;
      var9 = 1;
      var11 = true;
      var10009 = 1;
      var10 = new String[4];
      var11 = true;
      var10009 = 1;
      var10010 = true;
      var10011 = 1;
      var10[0] = "Swap Ticks";
      var12 = 1;
      var10011 = 1;
      var10[1] = "SwapTicks";
      var10010 = true;
      var10011 = 1;
      var10[2] = "SwapFactor";
      var10010 = true;
      var10011 = 1;
      var10[3] = "st";
      this.field_987 = new U(var3, var4, var8, var9, var10);
      var6 = 1;
      var10006 = 1;
      this.field_984 = true;
      this.field_985 = ub.Waiting;
      boolean var2 = true;
      byte var5 = 1;
      t[] var10001 = new t[4];
      var2 = true;
      var5 = 1;
      boolean var7 = true;
      var6 = 1;
      var10001[0] = this.field_988;
      var10004 = 1;
      var6 = 1;
      var10001[1] = this.field_989;
      var7 = true;
      var6 = 1;
      var10001[2] = this.field_990;
      var7 = true;
      var6 = 1;
      var10001[3] = this.field_987;
      this.f$c(var10001);
      var2 = true;
      var5 = 1;
      ja[] var1 = new ja[4];
      var2 = true;
      var5 = 1;
      var7 = true;
      var6 = 1;
      var1[0] = new CC(this);
      var10004 = 1;
      var6 = 1;
      var1[1] = new uA(this);
      var7 = true;
      var6 = 1;
      var1[2] = new oC(this);
      var7 = true;
      var6 = 1;
      var1[3] = new zC(this);
      this.method_2383(var1);
   }
}

package net.futureclient.client;

public enum lf {
   KEY_PRESS;

   private static final lf[] field_978;
   MIDDLE_CLICK,
   LEFT_CLICK,
   RIGHT_CLICK,
   KEY_RELEASE;

   static {
      lf[] var10000 = new lf[5];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = KEY_PRESS;
      var10000[1] = KEY_RELEASE;
      var10000[2] = LEFT_CLICK;
      var10000[3] = RIGHT_CLICK;
      var10000[4] = MIDDLE_CLICK;
      field_978 = var10000;
   }
}

package net.futureclient.client;

public class lg extends xb {
   public String method_4224() {
      return "&e[number]";
   }

   public String method_4228(String[] var1) {
      if (var1.length == 1) {
         String var3 = var1[0];
         kc var2 = (kc)YH.method_1211().method_1205().method_2166(kc.class);
         if (var3 == null) {
            return "No number entered.";
         } else {
            if (var2 != null) {
               var2.field_1016.method_3691(Double.parseDouble(var3));
               var2.field_1012.method_3691(Double.parseDouble(var3));
            }

            return (new StringBuilder()).insert(0, "Horizontal and vertical percentage has been set to ").append(Double.parseDouble(var3)).toString();
         }
      } else {
         return null;
      }
   }

   public lg() {
      String[] var10001 = new String[8];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "VelocityPercentage";
      var10001[1] = "velocity%";
      var10001[2] = "%";
      var10001[3] = "Vel";
      var10001[4] = "Velocity_reduction";
      var10001[5] = "Reduce";
      var10001[6] = "Reduction";
      var10001[7] = "Lower";
      super(var10001);
   }
}

package net.futureclient.client;

public enum mA {
   Coords,
   Distance;

   private static final mA[] field_995;

   static {
      mA[] var10000 = new mA[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Coords;
      var10000[1] = Distance;
      field_995 = var10000;
   }
}

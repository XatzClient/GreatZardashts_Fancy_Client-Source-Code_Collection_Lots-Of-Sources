package net.futureclient.client;

import java.util.Arrays;
import java.util.List;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;

public class mB extends ka {
   private final List field_1002;

   public static List method_2327(mB var0) {
      return var0.field_1002;
   }

   public mB() {
      boolean var10003 = true;
      byte var10004 = 1;
      String[] var10002 = new String[5];
      var10003 = true;
      var10004 = 1;
      boolean var10005 = true;
      byte var10006 = 1;
      var10002[0] = "NoSoundLag";
      byte var6 = 1;
      var10006 = 1;
      var10002[1] = "NoSwapLag";
      var10005 = true;
      var10006 = 1;
      var10002[2] = "NoEquipSoundLag";
      var10005 = true;
      var10006 = 1;
      var10002[3] = "AntiSoundLag";
      var10005 = true;
      var10006 = 1;
      var10002[4] = "AntiSwapExploit";
      var10004 = 1;
      var6 = 1;
      super("NoSoundLag", var10002, true, -51200, bE.MISCELLANEOUS);
      boolean var2 = true;
      byte var4 = 1;
      SoundEvent[] var10001 = new SoundEvent[7];
      var2 = true;
      var4 = 1;
      boolean var5 = true;
      var6 = 1;
      var10001[0] = SoundEvents.ITEM_ARMOR_EQUIP_GENERIC;
      var10004 = 1;
      var6 = 1;
      var10001[1] = SoundEvents.ITEM_ARMOR_EQIIP_ELYTRA;
      var5 = true;
      var6 = 1;
      var10001[2] = SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND;
      var5 = true;
      var6 = 1;
      var10001[3] = SoundEvents.ITEM_ARMOR_EQUIP_IRON;
      var5 = true;
      var6 = 1;
      var10001[4] = SoundEvents.ITEM_ARMOR_EQUIP_GOLD;
      var5 = true;
      var6 = 1;
      var10001[5] = SoundEvents.ITEM_ARMOR_EQUIP_CHAIN;
      var5 = true;
      var6 = 1;
      var10001[6] = SoundEvents.ITEM_ARMOR_EQUIP_LEATHER;
      this.field_1002 = Arrays.asList(var10001);
      byte var3 = 1;
      var4 = 1;
      ja[] var1 = new ja[1];
      var2 = true;
      var4 = 1;
      var5 = true;
      var6 = 1;
      var1[0] = new Qc(this);
      this.method_2383(var1);
   }
}

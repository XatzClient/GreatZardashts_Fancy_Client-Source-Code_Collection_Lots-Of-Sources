package net.futureclient.client;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

public class mC extends ja {
   public final QC field_997;

   public mC(QC var1) {
      this.field_997 = var1;
   }

   public void method_4027(LD var1) {
      if (this.field_997.field_665.size() >= 100000) {
         this.field_997.field_665.clear();
      }

      Block var2 = var1.method_137().getBlock();
      if (((List)QC.method_1509(this.field_997).method_3690()).contains(var2)) {
         Jh var3 = new Jh((double)var1.method_3153().getX(), (double)var1.method_3153().getY(), (double)var1.method_3153().getZ());
         if (!this.field_997.field_665.contains(var3) && QC.method_4279().player.getDistance(var3.method_166(), var3.method_163(), var3.method_164()) <= 0.0D && var2 != Blocks.AIR) {
            this.field_997.field_665.add(var3);
         }
      }

   }

   public void method_4312(CD var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      this.method_4027((LD)var1);
   }
}

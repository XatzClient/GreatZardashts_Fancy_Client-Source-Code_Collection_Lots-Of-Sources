package net.futureclient.client;

public class mE extends CD {
}

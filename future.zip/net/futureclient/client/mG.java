package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;

public final class mG extends ja {
   public final BI field_976;

   public mG(BI var1, Fj var2) {
      this(var1);
   }

   private mG(BI var1) {
      this.field_976 = var1;
   }

   public void method_4241(je var1) {
      if ((var1.method_3084() instanceof Position || var1.method_3084() instanceof PositionRotation) && BI.method_650(this.field_976) != null) {
         var1.f$c(true);
      }

   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }
}

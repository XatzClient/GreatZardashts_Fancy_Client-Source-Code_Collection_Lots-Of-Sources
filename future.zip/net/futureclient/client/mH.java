package net.futureclient.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import java.io.File;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ImageBufferDownload;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import net.minecraft.util.StringUtils;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Level;

public class mH extends bF {
   private String field_963;
   private static ej field_964 = new ej();
   private static final String field_965 = "session.minecraft.net";
   private static final Gson field_966;
   private static final String field_967 = "authserver.mojang.com";
   private static final URL field_968;
   private Minecraft field_969 = Minecraft.getMinecraft();
   private static Map field_970;
   private String field_971;
   private static final Type field_972 = (new qG()).getType();
   public boolean field_973;

   public void method_2255(int var1) {
      this.method_3043().remove(var1);
   }

   public void method_2256(String var1) {
      this.field_971 = var1;
   }

   public String method_2257() {
      return this.field_971;
   }

   public void method_2258(String var1, String var2) {
      this.method_3043().add(var2.isEmpty() ? new Th(var1) : new Th(var1, var2));
   }

   public void method_2259(String var1) {
      this.field_963 = var1;
   }

   public String method_2260() {
      return this.field_963;
   }

   public void method_2261(String var1, int var2, int var3) {
      GlStateManager.color((float)1, (float)1, 1.0F, (float)1);
      ResourceLocation var4 = AbstractClientPlayer.getLocationSkin(var1);
      this.method_2268(var4, var1);
      this.field_969.getTextureManager().bindTexture(var4);
      GlStateManager.enableBlend();
      Gui.drawModalRectWithCustomSizedTexture(var2, var3, 32.0F, 32.0F, 32, 32, 256.0F, 256.0F);
      Gui.drawModalRectWithCustomSizedTexture(var2, var3, 160.0F, 32.0F, 32, 32, 256.0F, 256.0F);
      GlStateManager.disableBlend();
   }

   public static String method_2262(mH var0, String var1) {
      return var0.field_963 = var1;
   }

   public void method_2263(int var1, String var2, String var3) {
      this.method_3043().set(var1, var3.isEmpty() ? new Th(var2) : new Th(var2, var3));
   }

   public void method_2264(String var1, String var2, String var3) {
      this.method_3043().add(new Th(var1, var2, var3));
   }

   public static String method_2265(mH var0) {
      return var0.field_963;
   }

   public void method_2266() {
      if (field_964.method_3408(30L, TimeUnit.SECONDS)) {
         URL var10000 = field_968;
         String var10001 = "UTF-8";

         try {
            String var1 = IOUtils.toString(var10000, var10001);
            field_970 = (Map)field_966.fromJson(var1, field_972);
         } catch (Exception var4) {
            HashMap var2 = new HashMap();
            String var3 = "black";
            var2.put("authserver.mojang.com", var3);
            var2.put("session.minecraft.net", var3);
            field_970 = var2;
            var4.printStackTrace();
         }

         field_964.method_3404();
      }

   }

   private Session method_2267(String var1, String var2) throws AuthenticationException {
      if (!var1.isEmpty() && !var2.isEmpty()) {
         YggdrasilUserAuthentication var3;
         YggdrasilUserAuthentication var10000 = var3 = (YggdrasilUserAuthentication)(new YggdrasilAuthenticationService(Proxy.NO_PROXY, "")).createUserAuthentication(Agent.MINECRAFT);
         var3.logOut();
         var3.setUsername(var1);
         var10000.setPassword(var2);
         var3.logIn();
         return var10000.getSelectedProfile() == null ? null : new Session(var3.getSelectedProfile().getName(), var3.getSelectedProfile().getId().toString(), var3.getAuthenticatedToken(), "mojang");
      } else {
         return null;
      }
   }

   private ThreadDownloadImageData method_2268(ResourceLocation var1, String var2) {
      TextureManager var3;
      Object var4;
      if ((var4 = (var3 = Minecraft.getMinecraft().getTextureManager()).getTexture(var1)) == null) {
         Object[] var10004 = new Object[1];
         boolean var10005 = true;
         byte var10006 = 1;
         var10004[0] = StringUtils.stripControlCodes(var2);
         var4 = new ThreadDownloadImageData((File)null, String.format("https://skins.futureclient.net/MinecraftSkins/%s.png?bypass_secret=SHKzhL8TaNeE5cyJ", var10004), DefaultPlayerSkin.getDefaultSkin(EntityPlayer.getOfflineUUID(var2)), new ImageBufferDownload());
         var3.loadTexture(var1, (ITextureObject)var4);
      }

      return (ThreadDownloadImageData)var4;
   }

   public mH() {
      this.field_971 = this.field_969.getSession().getUsername();
      this.field_963 = "";
      this.field_1201 = new ArrayList();
      new NG(this, "accounts.txt");
      new Gi(this, "altdispenserkey.txt");
   }

   static {
      field_966 = (new GsonBuilder()).registerTypeAdapter(field_972, new MH((NG)null)).create();
      URL var0 = null;
      URL var10000 = new URL;
      URL var10001 = var10000;
      String var10002 = "http://status.mojang.com/check";

      label13: {
         try {
            var10001.<init>(var10002);
            var0 = var10000;
         } catch (MalformedURLException var2) {
            la.method_2324().method_2323(Level.INFO, "Malformed URL found trying while to format Mojang server status checker URL string.");
            var10000 = var0;
            break label13;
         }

         var10000 = var0;
      }

      field_968 = var10000;
   }

   private boolean method_2269(Session var1) {
      boolean var2 = true;
      StringBuilder var10000 = new StringBuilder;
      StringBuilder var10001 = var10000;

      try {
         var10001.<init>();
         String var3 = var10000.insert(0, UUID.randomUUID().toString().replace("-", "")).append(UUID.randomUUID().toString().replace("-", "").substring(0, 7)).toString();
         this.field_969.getSessionService().joinServer(var1.getProfile(), var1.getToken(), var3);
         return var2;
      } catch (AuthenticationException var4) {
         byte var5 = 0;
         return false;
      }
   }

   public void method_2270(String var1, String var2) {
      if (var2.isEmpty()) {
         ((w)this.field_969).setSession(new Session(var1, var1, "0", "mojang"));
         Sg.f$c(Ph.f$M);
      } else {
         Session var3 = null;
         mH var10000 = this;
         String var10001 = var1;
         String var10002 = var2;

         Session var5;
         label19: {
            try {
               var3 = var10000.method_2267(var10001, var10002);
            } catch (AuthenticationException var4) {
               la.method_2324().method_2323(Level.INFO, var4.getMessage());
               var5 = var3;
               break label19;
            }

            var5 = var3;
         }

         if (var5 != null) {
            ((w)this.field_969).setSession(var3);
            Sg.f$c(Ph.f$M);
         }

      }
   }

   public void method_2271(int var1) {
      mH var10000;
      label37: {
         this.field_973 = true;
         switch(oH.f$e[((Th)this.method_3043().get(var1)).method_1799().ordinal()]) {
         case 1:
            boolean var7 = false;
            ((w)this.field_969).setSession(new Session(((Th)this.method_3043().get(var1)).method_1792(), ((Th)this.method_3043().get(var1)).method_1792(), "0", "mojang"));
            Sg.f$c(Ph.f$M);
            var10000 = this;
            break label37;
         case 2:
         case 4:
            if (((Th)this.method_3043().get(var1)).method_1805().getToken().length() != 0 && this.method_2269(((Th)this.method_3043().get(var1)).method_1805())) {
               ((Th)this.method_3043().get(var1)).method_1795("");
               ((w)this.field_969).setSession(new Session(((Th)this.method_3043().get(var1)).method_1802(), ((Th)this.method_3043().get(var1)).method_1805().getPlayerID(), ((Th)this.method_3043().get(var1)).method_1805().getToken(), net.minecraft.util.Session.Type.MOJANG.toString()));
               Sg.f$c(Ph.f$M);
               la.method_2324().method_2323(Level.INFO, "Logging in with session.");
               var10000 = this;
               break label37;
            }

            if (!((Th)this.method_3043().get(var1)).method_1803().equals("") && ((Th)this.method_3043().get(var1)).method_1803() != null) {
               String var2 = ((Th)this.method_3043().get(var1)).method_1792();
               String var3 = ((Th)this.method_3043().get(var1)).method_1803();
               Session var4 = null;
               ((Th)this.method_3043().get(var1)).method_1795("");
               var10000 = this;
               String var10001 = var2;
               String var10002 = var3;

               Session var6;
               label28: {
                  try {
                     var4 = var10000.method_2267(var10001, var10002);
                  } catch (AuthenticationException var5) {
                     ((Th)this.method_3043().get(var1)).method_1795(var5.getMessage());
                     la.method_2324().method_2323(Level.ERROR, var5.getMessage());
                     var6 = var4;
                     break label28;
                  }

                  var6 = var4;
               }

               if (var6 != null) {
                  ((w)this.field_969).setSession(var4);
                  Sg.f$c(Ph.f$M);
                  ((Th)this.method_3043().get(var1)).method_1796(var4);
               }
            }
            break;
         case 3:
            ((Th)this.method_3043().get(var1)).method_1795("");
         }

         var10000 = this;
      }

      var10000.field_973 = false;
   }

   public void method_2272() {
      String var1 = field_970 == null ? "§7Loading..." : ((String)field_970.get("authserver.mojang.com")).replace("green", "§aOnline").replace("yellow", "§6Slow").replace("red", "§4Offline").replace("black", "§8DNS Failure");
      String var2 = field_970 == null ? "§7Loading..." : ((String)field_970.get("session.minecraft.net")).replace("green", "§aOnline").replace("yellow", "§6Slow").replace("red", "§4Offline").replace("black", "§8DNS Failure");
      this.field_969.fontRenderer.drawStringWithShadow((new StringBuilder()).insert(0, "§7Authentication Server: ").append(var1).toString(), 2.0F, (float)2, 16777215);
      this.field_969.fontRenderer.drawStringWithShadow((new StringBuilder()).insert(0, "§7Multiplayer Session: ").append(var2).toString(), 2.0F, (float)(2 + this.field_969.fontRenderer.FONT_HEIGHT), 16777215);
   }
}

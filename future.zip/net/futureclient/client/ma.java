package net.futureclient.client;

public class ma extends ja {
   public final Da field_1077;

   public ma(Da var1) {
      this.field_1077 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      Da var10000 = this.field_1077;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = Da.method_839(this.field_1077).method_3690();
      var10000.f$D(String.format("Wallhack §7[§F%s§7]", var10002));
      Da.method_4319().gameSettings.gammaSetting = 11.0F;
      if (Da.method_836(this.field_1077) != this.field_1077.field_411.method_3692().intValue()) {
         Da.method_834(this.field_1077, this.field_1077.field_411.method_3692().intValue());
         if ((Boolean)Da.method_833(this.field_1077).method_3690()) {
            iI.f$D();
            return;
         }

         iI.f$c();
      }

   }
}

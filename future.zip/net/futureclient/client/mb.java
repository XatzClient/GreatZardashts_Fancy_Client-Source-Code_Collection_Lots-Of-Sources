package net.futureclient.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;

public class mb extends ka {
   private final Map field_1080;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Map method_2490(mb var0) {
      return var0.field_1080;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public mb() {
      String[] var10002 = new String[6];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Skeleton";
      var10002[1] = "SkeletonESP";
      var10002[2] = "Skelly";
      var10002[3] = "Skele";
      var10002[4] = "Skeleesp";
      var10002[5] = "Skeleboy";
      super("Skeleton", var10002, true, -2368549, bE.RENDER);
      this.field_1080 = new HashMap();
      ja[] var10001 = new ja[2];
      boolean var1 = true;
      byte var2 = 1;
      var10001[0] = new Ed(this);
      var10001[1] = new cb(this);
      this.f$c(var10001);
   }
}

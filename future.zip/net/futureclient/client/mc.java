package net.futureclient.client;

import net.minecraft.client.entity.EntityPlayerSP;

public class mc extends ja {
   public final bA field_1079;

   public mc(bA var1) {
      this.field_1079 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      if ((Boolean)bA.method_2863(this.field_1079).method_3690() || !fI.f$c() && !fI.f$c(true) && !bA.method_3000().player.isOnLadder() && !bA.method_2968().player.isEntityInsideOpaqueBlock()) {
         if (bA.method_2898(this.field_1079)) {
            bA.method_2862(this.field_1079, 0.0D);
            bA.method_2861(this.field_1079, false);
         } else {
            mc var10000;
            double var2;
            double var3;
            VF var5;
            switch(OA.f$G[((JB)this.field_1079.field_1183.method_3690()).ordinal()]) {
            case 1:
               boolean var10001 = false;
               if (!bA.method_2871(this.field_1079).method_817(100L)) {
                  return;
               }

               if ((Boolean)bA.method_2869(this.field_1079).method_3690()) {
                  ((r)((w)bA.method_2952()).getTimer()).method_3790(1.0888F);
               }

               label454: {
                  if (!bA.method_3014().player.collidedHorizontally) {
                     if (PH.f$c(bA.method_2978().player.posY - (double)((int)bA.method_2941().player.posY), 3) == PH.f$c(1.273197475E-314D, 3)) {
                        var1.method_1726(bA.method_3006().player.motionY = 5.0927899E-315D + EI.method_861());
                        var10000 = this;
                        break label454;
                     }

                     if (PH.f$c(bA.method_2995().player.posY - (double)((int)bA.method_3002().player.posY), 3) == PH.f$c(1.9522361275E-314D, 3)) {
                        var1.method_1726(bA.method_2942().player.motionY = 5.941588215E-315D + EI.method_861());
                        var10000 = this;
                        break label454;
                     }

                     if (PH.f$c(bA.method_2998().player.posY - (double)((int)bA.method_3016().player.posY), 3) == PH.f$c(0.0D, 3)) {
                        var1.method_1726(bA.method_2975().player.motionY = 1.273197475E-314D - EI.method_861());
                        var10000 = this;
                        break label454;
                     }

                     if (PH.f$c(bA.method_2997().player.posY - (double)((int)bA.method_3013().player.posY), 3) == PH.f$c(1.273197475E-314D, 3)) {
                        var1.method_1726(bA.method_2996().player.motionY = 2.54639495E-315D + EI.method_861());
                        var10000 = this;
                        break label454;
                     }

                     if (PH.f$c(bA.method_2949().player.posY - (double)((int)bA.method_2990().player.posY), 3) == PH.f$c(1.358077306E-314D, 3)) {
                        var1.method_1726(bA.method_2946().player.motionY = 1.273197475E-314D + EI.method_861());
                     }
                  }

                  var10000 = this;
               }

               if (bA.method_2876(var10000.field_1079) == 1 && (bA.method_2999().player.moveForward != 0.0F || bA.method_2974().player.moveStrafing != 0.0F)) {
                  bA.method_2862(this.field_1079, 1.273197475E-314D * EI.method_854() - 5.941588215E-315D);
                  var5 = var1;
               } else if (bA.method_2876(this.field_1079) != 2 || bA.method_3009().player.moveForward == 0.0F && bA.method_2965().player.moveStrafing == 0.0F) {
                  if (bA.method_2876(this.field_1079) == 3) {
                     var2 = 6.790386532E-315D * (bA.method_2872(this.field_1079) - EI.method_854());
                     bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - var2);
                     bA.method_2867(this.field_1079, !bA.method_2846(this.field_1079));
                     var5 = var1;
                  } else {
                     if (bA.method_2961().player.onGround && bA.method_2876(this.field_1079) > 0) {
                        bA.method_2854(this.field_1079, bA.method_3001().player.moveForward == 0.0F && bA.method_2967().player.moveStrafing == 0.0F ? 0 : 1);
                     }

                     bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - bA.method_2872(this.field_1079) / 0.0D);
                     var5 = var1;
                  }
               } else {
                  var1.method_1726(bA.method_2994().player.motionY = (fI.f$E() ? 1.273197475E-314D : 3.59890486E-315D) + EI.method_861());
                  bA.method_2862(this.field_1079, bA.method_2856(this.field_1079) * (bA.method_2846(this.field_1079) ? 9.676300807E-315D : 9.16702182E-315D));
                  var5 = var1;
               }

               EI.method_858(var5, bA.method_2862(this.field_1079, Math.max(bA.method_2856(this.field_1079), EI.method_854())));
               if (bA.method_2934().player.moveForward != 0.0F || bA.method_2987().player.moveStrafing != 0.0F) {
                  bA.method_2887(this.field_1079);
                  return;
               }
               break;
            case 2:
               if (bA.method_2948().player.onGround || (double)bA.method_2891(this.field_1079) == 0.0D) {
                  label561: {
                     if (!bA.method_2970().player.collidedHorizontally && bA.method_2935().player.moveForward != 0.0F || bA.method_2956().player.moveStrafing != 0.0F) {
                        if ((double)bA.method_2891(this.field_1079) == 0.0D) {
                           bA.method_2862(this.field_1079, bA.method_2856(this.field_1079) * 1.9352601614E-314D);
                           bA.method_2900(this.field_1079, 3);
                           var5 = var1;
                           break label561;
                        }

                        if ((double)bA.method_2891(this.field_1079) == 0.0D) {
                           var5 = var1;
                           bA.method_2900(this.field_1079, 2);
                           var2 = 6.790386532E-315D * (bA.method_2872(this.field_1079) - EI.method_854());
                           bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - var2);
                           break label561;
                        }

                        if (fI.f$E() || bA.method_3015().player.collidedVertically) {
                           bA.method_2900(this.field_1079, 1);
                        }
                     }

                     var5 = var1;
                  }

                  EI.method_858(var5, bA.method_2862(this.field_1079, Math.max(bA.method_2856(this.field_1079), EI.method_854())));
                  return;
               }
               break;
            case 3:
               if (!bA.method_2871(this.field_1079).method_817(100L)) {
                  bA.method_2845(this.field_1079, 1);
                  return;
               }

               if (bA.method_3021().player.moveForward == 0.0F && bA.method_2979().player.moveStrafing == 0.0F) {
                  bA.method_2862(this.field_1079, EI.method_854());
               }

               if (PH.f$c(bA.method_3008().player.posY - (double)((int)bA.method_3022().player.posY), 3) == PH.f$c(1.273197475E-314D, 3)) {
                  var1.method_1726(bA.method_2954().player.motionY = 5.0927899E-315D + EI.method_861());
               } else if (PH.f$c(bA.method_2936().player.posY - (double)((int)bA.method_3010().player.posY), 3) == PH.f$c(1.9522361275E-314D, 3)) {
                  var1.method_1726(bA.method_2939().player.motionY = 5.941588215E-315D + EI.method_861());
               } else if (PH.f$c(bA.method_2938().player.posY - (double)((int)bA.method_3004().player.posY), 3) == PH.f$c(0.0D, 3)) {
                  var1.method_1726(bA.method_2932().player.motionY = 1.273197475E-314D + EI.method_861());
               }

               if (bA.method_2983().world.getCollisionBoxes(bA.method_2980().player, bA.method_3017().player.getEntityBoundingBox().offset(0.0D, 2.54639495E-315D, 0.0D)).size() > 0 && PH.f$c(bA.method_2981().player.posY - (double)((int)bA.method_2973().player.posY), 3) == PH.f$c(1.273197475E-314D, 3)) {
                  var1.method_1726(bA.method_2985().player.motionY = 2.54639495E-315D + EI.method_861());
               }

               if (bA.method_2889(this.field_1079) == 1 && bA.method_2977().player.collidedVertically && (bA.method_3003().player.moveForward != 0.0F || bA.method_3018().player.moveStrafing != 0.0F)) {
                  var10000 = this;
                  bA.method_2862(this.field_1079, 0.0D * EI.method_854() - 5.941588215E-315D);
               } else if (bA.method_2889(this.field_1079) != 2 || !bA.method_2943().player.collidedVertically || bA.method_2958().player.moveForward == 0.0F && bA.method_2960().player.moveStrafing == 0.0F) {
                  if (bA.method_2889(this.field_1079) == 3) {
                     var3 = 6.790386532E-315D * (bA.method_2872(this.field_1079) - EI.method_854());
                     var10000 = this;
                     bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - var3);
                  } else {
                     label299: {
                        if (bA.method_2930().player.onGround && bA.method_2889(this.field_1079) > 0) {
                           if (1.273197475E-314D * EI.method_854() - 5.941588215E-315D > bA.method_2856(this.field_1079)) {
                              bA.method_2845(this.field_1079, 0);
                              var10000 = this;
                              break label299;
                           }

                           bA.method_2845(this.field_1079, bA.method_3012().player.moveForward == 0.0F && bA.method_3023().player.moveStrafing == 0.0F ? 0 : 1);
                        }

                        var10000 = this;
                     }

                     bA.method_2862(var10000.field_1079, bA.method_2872(this.field_1079) - bA.method_2872(this.field_1079) / 0.0D);
                     var10000 = this;
                  }
               } else {
                  var1.method_1726(bA.method_2950().player.motionY = (fI.f$E() ? 1.273197475E-314D : 1.273197475E-314D) + EI.method_861());
                  var10000 = this;
                  bA.method_2862(this.field_1079, bA.method_2856(this.field_1079) * 1.9352601614E-314D);
               }

               if (bA.method_2889(var10000.field_1079) > 8) {
                  bA.method_2862(this.field_1079, EI.method_854());
               }

               bA.method_2862(this.field_1079, Math.max(bA.method_2856(this.field_1079), EI.method_854()));
               if (bA.method_2889(this.field_1079) > 0) {
                  EI.method_858(var1, bA.method_2856(this.field_1079));
               }

               if (bA.method_3019().player.moveForward != 0.0F || bA.method_3020().player.moveStrafing != 0.0F) {
                  bA.method_2853(this.field_1079);
                  return;
               }
               break;
            case 4:
               if (!bA.method_2871(this.field_1079).method_817(100L)) {
                  bA.method_2881(this.field_1079, 4);
                  return;
               }

               if (PH.f$c(bA.method_2937().player.posY - (double)((int)bA.method_2976().player.posY), 3) == PH.f$c(1.918284195E-314D, 3)) {
                  EntityPlayerSP var6 = bA.method_2982().player;
                  var6.motionY -= 5.941588215E-315D + EI.method_861();
                  var1.method_1726(var1.method_1723() - (1.7179677924E-314D + EI.method_861()));
                  var6 = bA.method_2992().player;
                  var6.posY -= 1.7179677924E-314D + EI.method_861();
               }

               if ((double)bA.method_2897(this.field_1079) != 0.0D || bA.method_3005().player.moveForward == 0.0F && bA.method_2940().player.moveStrafing == 0.0F) {
                  if ((double)bA.method_2897(this.field_1079) == 0.0D) {
                     var3 = 6.790386532E-315D * (bA.method_2872(this.field_1079) - EI.method_854());
                     var10000 = this;
                     bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - var3);
                  } else {
                     if (bA.method_2959().player.onGround) {
                        bA.method_2881(this.field_1079, 1);
                     }

                     var10000 = this;
                     bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - bA.method_2872(this.field_1079) / 0.0D);
                  }
               } else {
                  var1.method_1726(bA.method_2955().player.motionY = (fI.f$E() ? 1.273197475E-314D : 1.273197475E-314D) + EI.method_861());
                  var10000 = this;
                  bA.method_2862(this.field_1079, bA.method_2856(this.field_1079) * 1.9352601614E-314D);
               }

               bA.method_2862(var10000.field_1079, Math.max(bA.method_2856(this.field_1079), EI.method_854()));
               EI.method_858(var1, bA.method_2856(this.field_1079));
               bA.method_2850(this.field_1079);
               return;
            case 5:
               if (bA.method_3011().player.moveForward == 0.0F && bA.method_2933().player.moveStrafing == 0.0F) {
                  return;
               }

               if ((Boolean)bA.method_2869(this.field_1079).method_3690()) {
                  ((r)((w)bA.method_2988()).getTimer()).method_3790(1.0888F);
               }

               if (bA.method_2876(this.field_1079) == 1 && (bA.method_2957().player.moveForward != 0.0F || bA.method_2972().player.moveStrafing != 0.0F)) {
                  bA.method_2862(this.field_1079, 1.273197475E-314D * EI.method_854() - 5.941588215E-315D);
                  var5 = var1;
               } else if (bA.method_2876(this.field_1079) != 2 || bA.method_2971().player.moveForward == 0.0F && bA.method_2962().player.moveStrafing == 0.0F) {
                  if (bA.method_2876(this.field_1079) == 3) {
                     var3 = 6.790386532E-315D * (bA.method_2872(this.field_1079) - EI.method_854());
                     bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - var3);
                     bA.method_2867(this.field_1079, !bA.method_2846(this.field_1079));
                     var5 = var1;
                  } else {
                     if ((bA.method_3771().world.getCollisionBoxes(bA.method_2969().player, bA.method_3772().player.getEntityBoundingBox().offset(0.0D, bA.method_3770().player.motionY, 0.0D)).size() > 0 || bA.method_3775().player.collidedVertically) && bA.method_2876(this.field_1079) > 0) {
                        bA.method_2854(this.field_1079, bA.method_3759().player.moveForward == 0.0F && bA.method_3774().player.moveStrafing == 0.0F ? 0 : 1);
                     }

                     bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - bA.method_2872(this.field_1079) / 0.0D);
                     var5 = var1;
                  }
               } else {
                  var1.method_1726(bA.method_2944().player.motionY = (fI.f$E() ? 3.59890486E-315D : 3.59890486E-315D) + EI.method_861());
                  bA.method_2862(this.field_1079, bA.method_2856(this.field_1079) * (bA.method_2846(this.field_1079) ? 1.4769090705E-314D : 1.1034378113E-314D));
                  var5 = var1;
               }

               EI.method_858(var5, bA.method_2862(this.field_1079, Math.max(bA.method_2856(this.field_1079), EI.method_854())));
               if (bA.method_3776().player.moveForward != 0.0F || bA.method_3752().player.moveStrafing != 0.0F) {
                  bA.method_2887(this.field_1079);
                  return;
               }
               break;
            case 6:
               if (!bA.method_2871(this.field_1079).method_817(100L)) {
                  bA.method_2859(this.field_1079, 1);
                  return;
               }

               if (bA.method_3773().player.moveForward == 0.0F && bA.method_3769().player.moveStrafing == 0.0F) {
                  bA.method_2862(this.field_1079, EI.method_854());
               }

               if (bA.method_2878(this.field_1079) != 1 || !bA.method_3747().player.collidedVertically || bA.method_3745().player.moveForward == 0.0F && bA.method_3757().player.moveStrafing == 0.0F) {
                  if (bA.method_2878(this.field_1079) != 2 || !bA.method_3761().player.collidedVertically || bA.method_3767().player.moveForward == 0.0F && bA.method_4296().player.moveStrafing == 0.0F) {
                     if (bA.method_2878(this.field_1079) == 3) {
                        var3 = 6.790386532E-315D * (bA.method_2872(this.field_1079) - EI.method_854());
                        var10000 = this;
                        bA.method_2862(this.field_1079, bA.method_2872(this.field_1079) - var3);
                     } else {
                        label361: {
                           if (bA.method_4288().player.onGround && bA.method_2878(this.field_1079) > 0) {
                              if (1.273197475E-314D * EI.method_854() - 5.941588215E-315D > bA.method_2856(this.field_1079)) {
                                 bA.method_2859(this.field_1079, 0);
                                 var10000 = this;
                                 break label361;
                              }

                              bA.method_2859(this.field_1079, bA.method_4291().player.moveForward == 0.0F && bA.method_4292().player.moveStrafing == 0.0F ? 0 : 1);
                           }

                           var10000 = this;
                        }

                        bA.method_2862(var10000.field_1079, bA.method_2872(this.field_1079) - bA.method_2872(this.field_1079) / 0.0D);
                        var10000 = this;
                     }
                  } else {
                     var1.method_1726(bA.method_4301().player.motionY = (fI.f$E() ? 1.273197475E-314D : 1.273197475E-314D) + EI.method_861());
                     var10000 = this;
                     bA.method_2862(this.field_1079, bA.method_2856(this.field_1079) * 1.9352601614E-314D);
                  }
               } else {
                  var10000 = this;
                  bA.method_2862(this.field_1079, 0.0D + EI.method_854() - 5.941588215E-315D);
               }

               bA.method_2862(var10000.field_1079, Math.max(bA.method_2856(this.field_1079), EI.method_854()));
               if (bA.method_2878(this.field_1079) > 0) {
                  EI.method_858(var1, bA.method_2856(this.field_1079));
               }

               if (bA.method_4298().player.moveForward != 0.0F || bA.method_4294().player.moveStrafing != 0.0F) {
                  bA.method_2857(this.field_1079);
                  return;
               }
               break;
            case 7:
               EI.method_858(var1, bA.method_2873(this.field_1079).method_3692().doubleValue() / 0.0D);
            }

         }
      } else {
         bA.method_2862(this.field_1079, 0.0D);
         bA.method_2861(this.field_1079, true);
      }
   }
}

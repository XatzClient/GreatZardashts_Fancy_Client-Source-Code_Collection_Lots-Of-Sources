package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class md extends ka {
   private Float field_1070;
   private Float field_1071;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Float method_2462(md var0, Float var1) {
      return var0.field_1071 = var1;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Float method_2464(md var0) {
      return var0.field_1071;
   }

   public static Float method_2465(md var0) {
      return var0.field_1070;
   }

   public static Float method_2466(md var0, Float var1) {
      return var0.field_1070 = var1;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public md() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "NoRotate";
      var10002[1] = "Rotations";
      var10002[2] = "Rotate";
      super("NoRotate", var10002, false, -12234273, bE.RENDER);
      ja[] var10001 = new ja[2];
      boolean var1 = true;
      byte var2 = 1;
      byte var10006 = 0;
      var10001[0] = new dd(this);
      var10001[1] = new Eb(this);
      this.f$c(var10001);
   }
}

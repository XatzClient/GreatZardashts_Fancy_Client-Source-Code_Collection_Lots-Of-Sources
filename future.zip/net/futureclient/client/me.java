package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class me extends ka {
   private transient double field_1061;
   private EG field_1062;
   private U field_1063;
   private t field_1064;
   private U field_1065;
   private t field_1066;
   private ga field_1067;
   private t field_1068;
   private t field_1069;

   public static t method_2440(me var0) {
      return var0.field_1064;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static t method_2443(me var0) {
      return var0.field_1069;
   }

   public static U method_2444(me var0) {
      return var0.field_1065;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static EG method_2446(me var0) {
      return var0.field_1062;
   }

   public static t method_2447(me var0) {
      return var0.field_1068;
   }

   public static ga method_2448(me var0) {
      return var0.field_1067;
   }

   public static double method_2449(me var0) {
      return var0.field_1061;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static U method_2451(me var0) {
      return var0.field_1063;
   }

   public static double method_2452(me var0, double var1) {
      return var0.field_1061 = var1;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static t method_2454(me var0) {
      return var0.field_1066;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public me() {
      String[] var10002 = new String[4];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "Trigger";
      var10002[1] = "ac";
      var10002[2] = "clicker";
      var10002[3] = "AutoClicker";
      super("Trigger", var10002, true, -4115980, bE.COMBAT);
      sE var3 = sE.MouseButton;
      String[] var5 = new String[4];
      boolean var10005 = true;
      byte var10006 = 1;
      var5[0] = "Check";
      var5[1] = "AttackCheck";
      var5[2] = "Attack";
      var5[3] = "ac";
      this.field_1067 = new ga(var3, var5);
      Boolean var4 = true;
      var5 = new String[5];
      var10005 = true;
      var10006 = 1;
      var5[0] = "InvisibleCheck";
      var5[1] = "Invisibles";
      var5[2] = "Invis";
      var5[3] = "ic";
      var5[4] = "i";
      this.field_1066 = new t(var4, var5);
      var4 = false;
      var5 = new String[5];
      var10005 = true;
      var10006 = 1;
      var5[0] = "TeamCheck";
      var5[1] = "Team";
      var5[2] = "AttackTeammates";
      var5[3] = "t";
      var5[4] = "tc";
      this.field_1064 = new t(var4, var5);
      var4 = true;
      var5 = new String[5];
      var10005 = true;
      var10006 = 1;
      var5[0] = "FriendCheck";
      var5[1] = "Friends";
      var5[2] = "AttackFriends";
      var5[3] = "Betray";
      var5[4] = "f";
      this.field_1069 = new t(var4, var5);
      var4 = true;
      var5 = new String[3];
      var10005 = true;
      var10006 = 1;
      var5[0] = "WeaponCheck";
      var5[1] = "Weapon";
      var5[2] = "w";
      this.field_1068 = new t(var4, var5);
      Float var6 = 8.0F;
      Float var8 = 0.1F;
      Float var9 = 20.0F;
      Double var10 = 1.273197475E-314D;
      String[] var10007 = new String[4];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "AttackSpeed";
      var10007[1] = "CPS";
      var10007[2] = "clicks";
      var10007[3] = "click";
      this.field_1063 = new U(var6, var8, var9, var10, var10007);
      var6 = 2.0F;
      var8 = 0.1F;
      var9 = 10.0F;
      var10 = 1.273197475E-314D;
      var10007 = new String[3];
      var10008 = true;
      var10009 = 1;
      var10007[0] = "RandomSpeed";
      var10007[1] = "randomsped";
      var10007[2] = "rspeed";
      this.field_1065 = new U(var6, var8, var9, var10, var10007);
      this.field_1061 = 0.0D;
      this.field_1062 = new EG();
      t[] var10001 = new t[7];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_1067;
      var10001[1] = this.field_1066;
      var10001[2] = this.field_1064;
      var10001[3] = this.field_1069;
      var10001[4] = this.field_1068;
      var10001[5] = this.field_1063;
      var10001[6] = this.field_1065;
      this.f$c(var10001);
      ja[] var1 = new ja[1];
      var2 = true;
      var7 = 1;
      var1[0] = new Fg(this);
      this.f$c(var1);
   }
}

package net.futureclient.client;

public enum mf {
   Cancel;

   private static final mf[] field_1074;
   Offhand;

   static {
      mf[] var10000 = new mf[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Cancel;
      var10000[1] = Offhand;
      field_1074 = var10000;
   }
}

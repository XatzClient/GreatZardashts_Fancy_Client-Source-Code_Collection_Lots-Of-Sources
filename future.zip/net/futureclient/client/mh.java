package net.futureclient.client;

public class mh extends xb {
   private static void method_2423(jB var0) {
      Object[] var10001 = new Object[0];
      boolean var10002 = true;
      byte var10003 = 1;
      var0.method_3649(var10001);
   }

   public String method_4224() {
      return null;
   }

   public String method_4228(String[] var1) {
      YH.method_1211().method_1203().method_3043().forEach(accept<invokedynamic>());
      return "Reloaded config.";
   }

   public mh() {
      String[] var10001 = new String[2];
      boolean var10002 = true;
      byte var10003 = 1;
      var10001[0] = "Reload";
      var10001[1] = "Load";
      super(var10001);
   }
}

package net.futureclient.client;

import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;

public class nA extends ja {
   public final gb field_1078;

   public nA(gb var1) {
      this.field_1078 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4307((Kg)var1);
   }

   public void method_4307(Kg var1) {
      if ((Boolean)this.field_1078.field_1407.method_3690() && (Boolean)this.field_1078.field_1413.method_3690() && var1.method_3084() instanceof CPacketClickWindow) {
         if (gb.method_4273().player.isSneaking()) {
            gb.method_4274().player.connection.sendPacket(new CPacketEntityAction(gb.method_4276().player, Action.START_SNEAKING));
         }

         if (gb.method_4245().player.isSprinting()) {
            gb.method_4242().player.connection.sendPacket(new CPacketEntityAction(gb.method_4281().player, Action.START_SPRINTING));
         }
      }

   }
}

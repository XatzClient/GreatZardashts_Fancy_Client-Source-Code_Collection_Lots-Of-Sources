package net.futureclient.client;

import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.TextFormatting;

public class nB extends ja {
   public final ec field_1076;

   public nB(ec var1) {
      this.field_1076 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketChat) {
         SPacketChat var2 = (SPacketChat)var1.method_3084();
         (new Thread(this.run<invokedynamic>(this, var2))).start();
      }

   }

   private void method_2481(SPacketChat var1) {
      SPacketChat var10000 = var1;

      Exception var8;
      label40: {
         boolean var10001;
         String var2;
         try {
            if ((var2 = TextFormatting.getTextWithoutFormattingCodes(var10000.getChatComponent().getUnformattedText())) == null || !var2.isEmpty()) {
               return;
            }
         } catch (Exception var6) {
            var8 = var6;
            var10001 = false;
            break label40;
         }

         String var9 = var2;

         try {
            tG var3;
            if ((var3 = Bj.f$c(var9)) != tG.English && var3 != tG.AutoDetect) {
               String var4 = QH.f$c(var2, var3, tG.English);
               if (ec.method_3366(this.field_1076).method_1540(var4, var1.getChatComponent().getUnformattedText()) < 1.0185579796E-314D) {
                  var4 = var4.replace("&lt;", "<").replace("&gt;", ">");
                  la.method_2324().method_2326((new StringBuilder()).insert(0, "(").append(Character.toUpperCase(var3.name().charAt(0))).append(var3.name().substring(1).toLowerCase()).append(") ").append(TextFormatting.GRAY).append(var4).toString(), false);
                  return;
               }
            }

            return;
         } catch (Exception var5) {
            var8 = var5;
            var10001 = false;
         }
      }

      Exception var7 = var8;
      var7.printStackTrace();
   }
}

package net.futureclient.client;

import net.minecraft.network.Packet;

public abstract class nD extends eF {
   public nD(Packet var1) {
      super(var1);
   }
}

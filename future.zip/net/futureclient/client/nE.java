package net.futureclient.client;

import net.minecraft.network.play.server.SPacketChat;

public class nE extends ja {
   public final xF field_1072;

   public nE(xF var1) {
      this.field_1072 = var1;
   }

   private static boolean method_2476(String var0, Bg var1) {
      return var0.contains(var1.method_757());
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      String var2;
      if (var1.method_3084() instanceof SPacketChat && (var2 = ((SPacketChat)var1.method_3084()).getChatComponent().getUnformattedText()).contains("has requested to teleport to you.") && (Bg)YH.method_1211().method_1216().method_3043().stream().filter(var2.test<invokedynamic>(var2)).findFirst().orElse((Object)null) != null && xF.method_4310(this.field_1072).method_3405((long)(xF.method_4309(this.field_1072).method_3692().floatValue() * 1000.0F))) {
         xF.method_4319().player.sendChatMessage("/tpaccept");
      }

   }
}

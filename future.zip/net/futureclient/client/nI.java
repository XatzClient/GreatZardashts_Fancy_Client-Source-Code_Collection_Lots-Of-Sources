package net.futureclient.client;

import java.awt.Color;
import java.awt.Point;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class nI {
   public static float field_1060 = 0.0F;

   public static Point method_2426() {
      Minecraft var0;
      int var1;
      if ((var1 = (var0 = Minecraft.getMinecraft()).gameSettings.guiScale) == 0) {
         var1 = 1000;
      }

      int var2;
      for(int var10000 = var2 = 0; var10000 < var1 && var0.displayWidth / (var2 + 1) >= 320 && var0.displayHeight / (var2 + 1) >= 240; var10000 = var2) {
         ++var2;
      }

      return new Point(Mouse.getX() / var2, var0.displayHeight / var2 - Mouse.getY() / var2 - 1);
   }

   public static void method_2427(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, Color var8) {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glPushMatrix();
      method_2438(var8);
      GL11.glBegin(7);
      GL11.glVertex2d((double)var6, (double)var7);
      GL11.glVertex2d((double)var4, (double)var5);
      GL11.glVertex2d((double)var2, (double)var3);
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glEnd();
      GL11.glBegin(7);
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glVertex2d((double)var2, (double)var3);
      GL11.glVertex2d((double)var4, (double)var5);
      GL11.glVertex2d((double)var6, (double)var7);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
   }

   public static void method_2428(double var0, double var2, double var4, double var6, float var8, int var9, int var10) {
      method_2431(var0, var2, var4, var6, var10);
      float var14 = (float)(var9 >> 24 & 255) / 255.0F;
      float var11 = (float)(var9 >> 16 & 255) / 255.0F;
      float var12 = (float)(var9 >> 8 & 255) / 255.0F;
      float var13 = (float)(var9 & 255) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glPushMatrix();
      GL11.glColor4f(var11, var12, var13, var14);
      GL11.glLineWidth(var8);
      GL11.glBegin(1);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glColor4f((float)0, (float)0, 0.0F, (float)0);
   }

   public static void method_2429(AxisAlignedBB var0) {
      if (var0 != null) {
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glEnd();
         GL11.glBegin(7);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.maxZ);
         GL11.glVertex3d(var0.minX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.minX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.minZ);
         GL11.glVertex3d(var0.maxX, var0.maxY, var0.maxZ);
         GL11.glVertex3d(var0.maxX, var0.minY, var0.maxZ);
         GL11.glEnd();
      }
   }

   public static void method_2430(AxisAlignedBB var0, float var1, Color var2) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2896);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glLineWidth(var1);
      GL11.glColor4f((float)var2.getRed() / 255.0F, (float)var2.getGreen() / 255.0F, (float)var2.getBlue() / 255.0F, (float)var2.getAlpha() / 255.0F);
      Di.method_945(var0);
      GL11.glLineWidth(1.0F);
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glEnable(2896);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
   }

   public static void method_2431(double var0, double var2, double var4, double var6, int var8) {
      float var9 = (float)(var8 >> 24 & 255) / 255.0F;
      float var10 = (float)(var8 >> 16 & 255) / 255.0F;
      float var11 = (float)(var8 >> 8 & 255) / 255.0F;
      float var12 = (float)(var8 & 255) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glPushMatrix();
      GL11.glColor4f(var10, var11, var12, var9);
      GL11.glBegin(7);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var2);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
   }

   public static void method_2432(float var0, float var1, ResourceLocation var2) {
      GL11.glPushMatrix();
      Minecraft.getMinecraft().getTextureManager().bindTexture(var2);
      GlStateManager.enableBlend();
      GL11.glEnable(2848);
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableAlpha();
      GlStateManager.alphaFunc(516, 0.1F);
      GlStateManager.enableBlend();
      GlStateManager.blendFunc(770, 771);
      GL11.glTranslatef(var0, var1, 0.0F);
      method_2436(0, 0, 0.0F, (float)0, 12, 12, 12, 12, 12.0F, 12.0F);
      GlStateManager.disableAlpha();
      GlStateManager.disableRescaleNormal();
      GlStateManager.disableLighting();
      GlStateManager.disableRescaleNormal();
      GL11.glDisable(2848);
      GlStateManager.disableBlend();
      GL11.glPopMatrix();
   }

   public static void method_2433(float var0, float var1, ResourceLocation var2, int var3, int var4) {
      Minecraft.getMinecraft().getTextureManager().bindTexture(var2);
      GlStateManager.enableBlend();
      GL11.glEnable(2848);
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableAlpha();
      GlStateManager.alphaFunc(516, 0.1F);
      GlStateManager.enableBlend();
      GlStateManager.blendFunc(770, 771);
      GL11.glTranslatef(var0, var1, 0.0F);
      method_2436(0, 0, 0.0F, (float)0, var3, var4, var3, var4, (float)var3, (float)var4);
      GlStateManager.disableAlpha();
      GlStateManager.disableRescaleNormal();
      GlStateManager.disableLighting();
      GlStateManager.disableRescaleNormal();
      GL11.glDisable(2848);
      GlStateManager.disableBlend();
   }

   public static void method_2434(AxisAlignedBB var0, Color var1) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2896);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glColor4f((float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var1.getAlpha() / 255.0F);
      method_2429(var0);
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glEnable(2896);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
   }

   public static String method_2435(String var0) {
      return (new StringBuilder()).insert(0, String.valueOf(Character.toUpperCase(var0.charAt(0)))).append(var0.substring(1)).toString();
   }

   public static void method_2436(int var0, int var1, float var2, float var3, int var4, int var5, int var6, int var7, float var8, float var9) {
      Gui.drawScaledCustomSizeModalRect(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public static void method_2437(int var0, int var1, double var2, double var4, int var6) {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2884);
      GL11.glBlendFunc(770, 771);
      double var7 = 6.984873503E-315D / (double)var6 / 0.0D;
      var4 = var4;
      double var9 = var2 - 0.0D;
      double var11 = var2 + 0.0D;
      GL11.glBegin(8);

      int var10000;
      double var10001;
      int var13;
      double var14;
      for(var10000 = var13 = 0; var10000 <= var6; var10000 = var13) {
         var2 = (double)var13 * 0.0D * 6.984873503E-315D / (double)var6;
         GL11.glVertex2d(var4 * Math.cos(var2) + (double)var0, var4 * Math.sin(var2) + (double)var1);
         GL11.glVertex2d(var9 * Math.cos(var2) + (double)var0, var9 * Math.sin(var2) + (double)var1);
         GL11.glVertex2d(var4 * Math.cos(var2) + (double)var0, var4 * Math.sin(var2) + (double)var1);
         var14 = var9 * Math.cos(var2 + 0.0D * var7) + (double)var0;
         var10001 = var9 * Math.sin(var2 + 0.0D * var7);
         ++var13;
         GL11.glVertex2d(var14, var10001 + (double)var1);
      }

      GL11.glEnd();
      GL11.glBegin(7);
      var7 = 6.984873503E-315D / (double)var6 / 0.0D;

      for(var10000 = var13 = 0; var10000 < var6; var10000 = var13) {
         var2 = (double)var13 * 0.0D * 6.984873503E-315D / (double)var6;
         GL11.glVertex2d(var9 * Math.cos(var2) + (double)var0, var9 * Math.sin(var2) + (double)var1);
         GL11.glVertex2d(var11 * Math.cos(var2 + var7) + (double)var0, var11 * Math.sin(var2 + var7) + (double)var1);
         GL11.glVertex2d(var11 * Math.cos(var2 + 0.0D * var7) + (double)var0, var11 * Math.sin(var2 + 0.0D * var7) + (double)var1);
         var14 = var9 * Math.cos(var2 + 0.0D * var7) + (double)var0;
         var10001 = var9 * Math.sin(var2 + 0.0D * var7);
         ++var13;
         GL11.glVertex2d(var14, var10001 + (double)var1);
      }

      GL11.glEnd();
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glEnable(2884);
   }

   public static void method_2438(Color var0) {
      GL11.glColor4f((float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, (float)var0.getAlpha() / 255.0F);
   }

   public static int method_2439(String var0, int var1, int var2, int var3) {
      return Minecraft.getMinecraft().fontRenderer.drawString(var0, (float)var1, (float)var2, var3, false);
   }
}

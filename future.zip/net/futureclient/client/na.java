package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import org.lwjgl.input.Mouse;

public class na extends Wa {
   private Minecraft field_1051 = Minecraft.getMinecraft();
   private U field_1052;
   private boolean field_1053;

   public na(U var1) {
      super(var1.f$c()[0]);
      this.field_1052 = var1;
   }

   public void method_3982(int var1, int var2, int var3) {
      super.method_3982(var1, var2, var3);
      if (this.method_2412(var1, var2) && var3 == 0) {
         this.field_1051.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         this.method_2411(true);
      }

   }

   private void method_2411(boolean var1) {
      this.field_1053 = var1;
   }

   private boolean method_2412(int var1, int var2) {
      Iterator var3 = bC.method_3037().method_3034().iterator();

      do {
         if (!var3.hasNext()) {
            if ((float)var1 >= this.f$D() && (float)var1 <= this.f$D() + (float)(this.f$D() + 7) && (float)var2 >= this.f$c() && (float)var2 <= this.f$c() + (float)this.f$E) {
               return true;
            }

            return false;
         }
      } while(!((kB)var3.next()).field_908);

      return false;
   }

   private void method_2413(int var1, int var2) {
      if (!Mouse.isButtonDown(0)) {
         this.method_2411(false);
      }

      if (this.method_2415() && this.method_2412(var1, var2)) {
         double var3 = (double)Math.round((double)(((float)var1 - this.f$D()) / (float)(this.f$D() + 7)) * this.field_1052.method_3687().doubleValue() * (1.0D / this.field_1052.field_1497.doubleValue())) / (1.0D / this.field_1052.field_1497.doubleValue());
         this.field_1052.method_3691(var3);
         if (this.field_1052.method_3692().doubleValue() < this.field_1052.method_3693().doubleValue()) {
            this.field_1052.method_3691(this.field_1052.method_3693());
            return;
         }

         if (this.field_1052.method_3692().doubleValue() > this.field_1052.method_3687().doubleValue()) {
            this.field_1052.method_3691(this.field_1052.method_3687());
         }
      }

   }

   public int method_2414() {
      return 14;
   }

   private boolean method_2415() {
      return this.field_1053;
   }

   public void method_3986(int var1, int var2, float var3) {
      this.method_2413(var1, var2);
      int var6;
      if (this.field_1052.method_3692().doubleValue() > this.field_1052.method_3687().doubleValue()) {
         var6 = this.f$D() + 7;
      } else {
         var6 = (int)(this.field_1052.method_3692().doubleValue() / this.field_1052.method_3687().doubleValue() * (double)(this.f$D() + 7));
      }

      YE var4 = (YE)YH.method_1211().method_1205().method_2166(YE.class);
      zF var5 = (zF)YH.method_1211().method_1205().method_2166(zF.class);
      Di.method_937(this.f$D() + (float)this.f$G, this.f$c() + (float)this.f$e, this.f$D() + (float)var6 + (float)this.f$G, this.f$c() + (float)this.method_2414() + 1.0F + (float)this.f$e, !this.method_2412(var1, var2) ? var5.field_1445.getRGB() + -1728053248 : var5.field_1445.getRGB() + 1879048192);
      Object[] var10002;
      boolean var10003;
      byte var10004;
      if ((Boolean)var4.field_583.method_3690()) {
         GlStateManager.enableBlend();
         sH var7 = var4.field_573;
         var10002 = new Object[2];
         var10003 = true;
         var10004 = 1;
         var10002[0] = this.f$c();
         var10002[1] = this.field_1052.method_3692();
         var7.method_3678(String.format("%s§7 %s", var10002), (double)(this.f$I + 2.0F), (double)(this.f$L + 4.0F), 16777215);
         GlStateManager.disableBlend();
      } else {
         FontRenderer var10000 = this.field_1051.fontRenderer;
         var10002 = new Object[2];
         var10003 = true;
         var10004 = 1;
         var10002[0] = this.f$c();
         var10002[1] = this.field_1052.method_3692();
         var10000.drawStringWithShadow(String.format("%s§7 %s", var10002), this.f$I + 2.0F, this.f$L + 4.0F, 16777215);
      }
   }
}

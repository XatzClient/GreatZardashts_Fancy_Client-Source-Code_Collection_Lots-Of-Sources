package net.futureclient.client;

import net.minecraft.network.play.server.SPacketPlayerPosLook;

public class nb extends ja {
   public final Nc field_1048;

   public nb(Nc var1) {
      this.field_1048 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketPlayerPosLook) {
         Nc.method_594(this.field_1048).method_814();
      }

   }
}

package net.futureclient.client;

public enum nc {
   AAC,
   Normal;

   private static final nc[] field_1059;

   static {
      nc[] var10000 = new nc[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Normal;
      var10000[1] = AAC;
      field_1059 = var10000;
   }
}

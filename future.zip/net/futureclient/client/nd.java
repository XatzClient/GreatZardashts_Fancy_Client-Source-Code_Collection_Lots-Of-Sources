package net.futureclient.client;

public class nd extends ja {
   public final hc field_1055;

   public nd(hc var1) {
      this.field_1055 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2420((YF)var1);
   }

   public void method_2420(YF var1) {
      if (((Kb)hc.method_3422(this.field_1055).method_3690()).equals(Kb.Player)) {
         var1.method_1336(hc.method_4278().player);
      }

   }
}

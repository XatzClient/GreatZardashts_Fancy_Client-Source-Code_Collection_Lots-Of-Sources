package net.futureclient.client;

import net.minecraft.util.math.AxisAlignedBB;

public class nf extends ja {
   public final Zf field_1046;

   public nf(Zf var1) {
      this.field_1046 = var1;
   }

   public void method_2495(be var1) {
      switch(kg.f$G[((tF)Zf.method_1348(this.field_1046).method_3690()).ordinal()]) {
      case 1:
         boolean var10001 = false;
         if (var1.method_2797() != null && var1.method_2797().maxY > Zf.method_4296().player.getEntityBoundingBox().minY && Zf.method_4301().player.isSneaking()) {
            var1.method_2800((AxisAlignedBB)null);
            return;
         }
         break;
      case 2:
         var1.method_2800((AxisAlignedBB)null);
         Zf.method_4288().player.noClip = true;
         return;
      case 3:
         if (Zf.method_4291().player.collidedHorizontally) {
            var1.method_2800((AxisAlignedBB)null);
         }

         if (Zf.method_4292().player.movementInput.sneak || Zf.method_4298().player.movementInput.jump && (double)var1.method_3153().getY() > Zf.method_4294().player.posY) {
            var1.f$c(true);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_2495((be)var1);
   }
}

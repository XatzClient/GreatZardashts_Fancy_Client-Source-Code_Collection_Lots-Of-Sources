package net.futureclient.client;

public enum oA {
   Riga,
   Hypixel,
   Creative,
   AAC,
   Gomme,
   Normal;

   private static final oA[] field_1045;

   static {
      oA[] var10000 = new oA[6];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Normal;
      var10000[1] = Creative;
      var10000[2] = Hypixel;
      var10000[3] = Gomme;
      var10000[4] = Riga;
      var10000[5] = AAC;
      field_1045 = var10000;
   }
}

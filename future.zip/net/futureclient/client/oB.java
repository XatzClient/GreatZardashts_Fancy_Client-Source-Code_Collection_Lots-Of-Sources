package net.futureclient.client;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult.Type;

public class oB extends ja {
   public final PC field_1050;

   public oB(PC var1) {
      this.field_1050 = var1;
   }

   public void method_2753(tE var1) {
      if (var1.method_3980().equals(lf.MIDDLE_CLICK) && PC.method_4242().objectMouseOver != null && PC.method_4269().objectMouseOver.typeOfHit.equals(Type.ENTITY) && PC.method_4315().objectMouseOver.entityHit instanceof EntityPlayer) {
         EntityPlayer var2 = (EntityPlayer)PC.method_4319().objectMouseOver.entityHit;
         if (YH.method_1211().method_1216().method_1481(var2.getName())) {
            YH.method_1211().method_1216().method_3042(YH.method_1211().method_1216().method_1482(var2.getName()));
            return;
         }

         YH.method_1211().method_1216().method_3798(new Bg(var2.getName(), var2.getName()));
      }

   }

   public void method_4312(CD var1) {
      this.method_2753((tE)var1);
   }
}

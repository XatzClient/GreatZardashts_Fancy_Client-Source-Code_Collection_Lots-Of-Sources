package net.futureclient.client;

public class oD extends CD {
   private String field_1056;

   public oD(String var1) {
      this.field_1056 = var1;
   }

   public void method_3452(String var1) {
      this.field_1056 = var1;
   }

   public String method_3453() {
      return this.field_1056;
   }
}

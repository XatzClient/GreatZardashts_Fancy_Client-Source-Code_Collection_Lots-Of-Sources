package net.futureclient.client;

import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.BlockPos;

public class oE extends ja {
   public final tD field_1054;

   public oE(tD var1) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      this.field_1054 = var1;
      super();
   }

   public void method_4230(IF var1) {
      if (var1.method_3084() instanceof SPacketPlayerPosLook) {
         SPacketPlayerPosLook var2 = (SPacketPlayerPosLook)var1.method_3084();
         if (tD.method_4276().player.isEntityAlive()) {
            WorldClient var10000 = tD.method_4242().world;
            BlockPos var10001 = new BlockPos(tD.method_4274().player.posX, tD.method_4245().player.posY, tD.method_4281().player.posZ);
            boolean var10003 = true;
            byte var10004 = 1;
            nF var3;
            if (var10000.isBlockLoaded(var10001, false) && !(tD.method_4269().currentScreen instanceof GuiDownloadTerrain) && !((QF)tD.method_3887(this.field_1054).method_3690()).equals(QF.Setback) && (var3 = (nF)tD.method_3902(this.field_1054).remove(var2.getTeleportId())) != null && var3.f$E() == var2.getX() && var3.f$D() == var2.getY() && var3.f$c() == var2.getZ()) {
               byte var10002 = 1;
               byte var4 = 1;
               var1.method_729(true);
               return;
            }
         }

         ((m)var2).setYaw(tD.method_4315().player.rotationYaw);
         ((m)var2).setPitch(tD.method_4319().player.rotationPitch);
         tD.method_3889(this.field_1054, var2.getTeleportId());
      }

   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }
}

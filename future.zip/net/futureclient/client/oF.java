package net.futureclient.client;

import java.util.Iterator;

public class oF extends ja {
   public final YE field_1047;

   public oF(YE var1) {
      this.field_1047 = var1;
   }

   public void method_4183(Xe var1) {
      if (YE.method_1257(this.field_1047).size() > 20) {
         YE.method_1257(this.field_1047).poll();
      }

      YE.method_1257(this.field_1047).add(EI.method_857(YE.method_4315().player) * (double)((r)((w)YE.method_4319()).getTimer()).method_3789());
      double var2 = 0.0D;
      Iterator var4 = YE.method_1257(this.field_1047).iterator();

      for(Iterator var10000 = var4; var10000.hasNext(); var10000 = var4) {
         double var5 = (Double)var4.next();
         var2 += var5;
      }

      YE.method_1251(this.field_1047, var2 / (double)YE.method_1257(this.field_1047).size());
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

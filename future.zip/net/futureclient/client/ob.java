package net.futureclient.client;

import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;

public class ob extends ja {
   public final hc field_1112;

   public ob(hc var1) {
      this.field_1112 = var1;
   }

   public void method_2709(Zd var1) {
      RayTraceResult var2;
      if ((var2 = var1.method_1108()) != null && var2.typeOfHit == Type.ENTITY && var2.entityHit == hc.method_4275().player) {
         Object var10008 = null;
         var1.method_1109(new RayTraceResult(Type.MISS, var2.hitVec, (EnumFacing)null, new BlockPos(var2.hitVec)));
      }

   }

   public void method_4312(CD var1) {
      this.method_2709((Zd)var1);
   }
}

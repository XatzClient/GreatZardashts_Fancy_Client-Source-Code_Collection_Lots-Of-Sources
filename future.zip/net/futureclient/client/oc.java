package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;

public class oc extends ja {
   public final ld field_1111;

   public oc(ld var1) {
      this.field_1111 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }

   public void method_4183(Xe var1) {
      ld var10000 = this.field_1111;
      Object[] var10002 = new Object[1];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = this.field_1111.field_974.method_3690();
      var10000.f$D(String.format("Sprint §7[§F%s§7]", var10002));
      if (ld.method_2277(this.field_1111)) {
         switch(ZC.f$e[((Ab)this.field_1111.field_974.method_3690()).ordinal()]) {
         case 1:
            Minecraft var2 = ld.method_4315();
            boolean var10001 = false;
            KeyBinding.setKeyBindState(var2.gameSettings.keyBindSprint.getKeyCode(), true);
            return;
         case 2:
            ld.method_4319().player.setSprinting(true);
         }
      }

   }
}

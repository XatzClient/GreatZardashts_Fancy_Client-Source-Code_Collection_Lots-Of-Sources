package net.futureclient.client;

public class od extends ja {
   public final wc field_1126;

   public od(wc var1) {
      this.field_1126 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4040((VF)var1);
   }

   public void method_4040(VF var1) {
      // $FF: Couldn't be decompiled
   }
}

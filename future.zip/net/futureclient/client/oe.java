package net.futureclient.client;

public class oe extends ja {
   public final Zf field_1124;

   public oe(Zf var1) {
      this.field_1124 = var1;
   }

   public void method_4312(CD var1) {
      this.method_2748((Le)var1);
   }

   public void method_2748(Le var1) {
      var1.method_729(true);
   }
}

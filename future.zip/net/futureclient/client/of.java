package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.RayTraceResult.Type;
import org.lwjgl.input.Mouse;

public class of extends ja {
   public final SF field_1110;

   public of(SF var1) {
      this.field_1110 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      switch(zE.f$e[var1.method_326().ordinal()]) {
      case 1:
         Minecraft var10000 = SF.method_4297();
         boolean var10001 = false;
         if (var10000.objectMouseOver != null && SF.method_4285().objectMouseOver.typeOfHit == Type.BLOCK && SF.method_1691(this.field_1110) && Mouse.isButtonDown(1) && !SF.method_4284().player.isSneaking() && SF.method_1683(this.field_1110) == 0 && SF.method_4286().inGameHasFocus) {
            SF.method_1689(this.field_1110, SF.method_4293().objectMouseOver.getBlockPos());
            EI.method_881(EI.method_877(), SF.method_1693(this.field_1110), 0.0D);
            SF.method_4295().player.setPosition((double)SF.method_1693(this.field_1110).getX() + 0.0D, (double)SF.method_1693(this.field_1110).getY() + SF.method_4250().world.getBlockState(SF.method_1693(this.field_1110)).getBoundingBox(SF.method_4287().world, SF.method_1693(this.field_1110)).maxY, (double)SF.method_1693(this.field_1110).getZ() + 0.0D);
            SF.method_1690(this.field_1110, 5);
         }

         if (SF.method_1683(this.field_1110) > 0) {
            SF.method_1688(this.field_1110);
         }
      default:
      }
   }
}

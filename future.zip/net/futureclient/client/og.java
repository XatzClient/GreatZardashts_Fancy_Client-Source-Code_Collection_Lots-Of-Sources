package net.futureclient.client;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.network.play.server.SPacketTabComplete;

public class og extends ja {
   public final DH field_1109;

   public og(DH var1) {
      this.field_1109 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      DH.method_709(this.field_1109, new ArrayList());
      if (var1.method_3084() instanceof SPacketTabComplete) {
         SPacketTabComplete var10000 = (SPacketTabComplete)var1.method_3084();
         var1.method_729(true);
         String[] var2;
         int var3 = (var2 = var10000.getMatches()).length;

         int var4;
         for(int var9 = var4 = 0; var9 < var3; var9 = var4) {
            String[] var5;
            if ((var5 = var2[var4].split(":")).length > 1 && !DH.method_711(this.field_1109).contains(var5[0].substring(1))) {
               DH.method_711(this.field_1109).add(var5[0].substring(1));
            }

            ++var4;
         }

         StringBuilder var6;
         StringBuilder var10 = var6 = new StringBuilder();
         Object[] var10002 = new Object[1];
         boolean var10003 = true;
         byte var10004 = 1;
         var10002[0] = DH.method_711(this.field_1109).size();
         var10.append(String.format("Found plugins (%s): ", var10002));
         Iterator var7 = DH.method_711(this.field_1109).iterator();
         Iterator var11 = var7;

         while(var11.hasNext()) {
            String var8 = (String)var7.next();
            var11 = var7;
            var6.append(var8);
            var6.append(", ");
         }

         la.method_2324().method_2322((new StringBuilder()).insert(0, var6.substring(0, var6.length() - 2)).append(".").toString());
         YH.method_1211().method_1212().method_1334(this);
      }

   }
}

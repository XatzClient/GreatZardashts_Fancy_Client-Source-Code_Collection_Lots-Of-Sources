package net.futureclient.client;

import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.util.math.AxisAlignedBB;

public class pA extends ka {
   private boolean field_1095;
   private EG field_1096;
   private int field_1097;
   private double field_1098;
   private int field_1099;
   private int field_1100;
   private t field_1101;
   private double field_1102;
   private int field_1103;
   private int field_1104;
   private boolean field_1105;
   private double field_1106;
   private U field_1107;
   private ga field_1108;

   public static Minecraft method_4242() {
      return f$e;
   }

   public static int method_2511(pA var0) {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return var0.field_1097;
   }

   public static int method_2512(pA var0, int var1) {
      return var0.field_1104 = var1;
   }

   public void method_4314() {
      if (this.field_1108.method_3690() == sd.Cowabunga) {
         ((r)((w)f$e).getTimer()).method_3790(1.0F);
         f$e.player.onGround = false;
         f$e.player.capabilities.isFlying = false;
      }

      if (this.field_1108.method_3690() == sd.Hypixel) {
         this.field_1103 = 4;
         this.field_1106 = 0.0D;
      }

      super.method_4314();
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4244() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static int method_2517(pA var0) {
      return var0.field_1103;
   }

   public static double method_2518(pA var0) {
      return var0.field_1106;
   }

   public static boolean method_2519(pA var0, boolean var1) {
      return var0.field_1105 = var1;
   }

   public static int method_2520(pA var0, int var1) {
      return var0.field_1099 = var1;
   }

   public static boolean method_2521(pA var0) {
      return var0.field_1095;
   }

   public static int method_2522(pA var0) {
      return var0.field_1099;
   }

   public static double method_2523(pA var0, double var1) {
      return var0.field_1098 = var1;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Minecraft method_4250() {
      return f$e;
   }

   public static ga method_2526(pA var0) {
      return var0.field_1108;
   }

   private double method_2527(EntityPlayer var1, double var2) {
      List var4;
      if ((var4 = var1.world.getCollisionBoxes(var1, var1.getEntityBoundingBox().grow(0.0D, -var2, 0.0D))).isEmpty()) {
         return 0.0D;
      } else {
         var2 = 0.0D;
         Iterator var6 = var4.iterator();

         while(var6.hasNext()) {
            AxisAlignedBB var5;
            if ((var5 = (AxisAlignedBB)var6.next()).maxY > var2) {
               var2 = var5.maxY;
            }
         }

         return var1.posY - var2;
      }
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static double method_2529(pA var0, double var1) {
      return var0.field_1106 = var1;
   }

   public static int method_2530(pA var0, int var1) {
      return var0.field_1100 = var1;
   }

   public static t method_2531(pA var0) {
      return var0.field_1101;
   }

   public static boolean method_2532(pA var0) {
      return var0.field_1105;
   }

   public static double method_2533(pA var0, EntityPlayer var1, double var2) {
      return var0.method_2527(var1, var2);
   }

   public static EG method_2534(pA var0) {
      return var0.field_1096;
   }

   public static void method_2535(pA var0, double var1, double var3, double var5) {
      var0.method_2540(var1, var3, var5);
   }

   public static int method_2536(pA var0) {
      return var0.field_1100;
   }

   public static U method_2537(pA var0) {
      return var0.field_1107;
   }

   public static double method_2538(pA var0) {
      return var0.field_1098;
   }

   public static boolean method_2539(pA var0, boolean var1) {
      return var0.field_1095 = var1;
   }

   private void method_2540(double var1, double var3, double var5) {
      f$e.player.connection.sendPacket(new Position(var1, var3, var5, f$e.player.onGround));
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static double method_2543(pA var0) {
      return var0.field_1102;
   }

   public static double method_2544(pA var0, double var1) {
      return var0.field_1102 = var1;
   }

   public static int method_2545(pA var0) {
      return --var0.field_1097;
   }

   public static int method_2546(pA var0, int var1) {
      return var0.field_1103 = var1;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4272() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static int method_2551(pA var0) {
      return var0.field_1104;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public void method_4326() {
      if (f$e.player != null && f$e.world != null) {
         this.field_1102 = EI.method_854();
         f$e.player.onGround = true;
         if (this.field_1108.method_3690() == sd.Cowabunga) {
            ((r)((w)f$e).getTimer()).method_3790(1.0F);
         }
      }

      this.field_1105 = false;
      this.field_1095 = true;
      this.field_1106 = 0.0D;
      this.field_1104 = 1;
      super.method_4326();
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public static int method_2561(pA var0) {
      return ++var0.field_1097;
   }

   public static Minecraft method_4282() {
      return f$e;
   }

   public static Minecraft method_4283() {
      return f$e;
   }

   public static Minecraft method_4284() {
      return f$e;
   }

   public static Minecraft method_3745() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return f$e;
   }

   public static Minecraft method_4285() {
      return f$e;
   }

   public static Minecraft method_3747() {
      return f$e;
   }

   public static Minecraft method_4286() {
      return f$e;
   }

   public static Minecraft method_4287() {
      return f$e;
   }

   public static Minecraft method_4288() {
      return f$e;
   }

   public static Minecraft method_4289() {
      return f$e;
   }

   public static Minecraft method_3752() {
      return f$e;
   }

   public static Minecraft method_4290() {
      return f$e;
   }

   public static Minecraft method_4291() {
      return f$e;
   }

   public static Minecraft method_4292() {
      return f$e;
   }

   public static Minecraft method_4293() {
      return f$e;
   }

   public static Minecraft method_3757() {
      return f$e;
   }

   public static Minecraft method_4294() {
      return f$e;
   }

   public static Minecraft method_3759() {
      return f$e;
   }

   public static Minecraft method_4295() {
      return f$e;
   }

   public static Minecraft method_3761() {
      return f$e;
   }

   public static Minecraft method_4296() {
      return f$e;
   }

   public static Minecraft method_4297() {
      return f$e;
   }

   public static Minecraft method_4298() {
      return f$e;
   }

   public static Minecraft method_4299() {
      return f$e;
   }

   public static Minecraft method_4300() {
      return f$e;
   }

   public static Minecraft method_3767() {
      return f$e;
   }

   public static Minecraft method_4301() {
      return f$e;
   }

   public static Minecraft method_2930() {
      return f$e;
   }

   public static Minecraft method_3769() {
      return f$e;
   }

   public static Minecraft method_2932() {
      return f$e;
   }

   public static Minecraft method_2933() {
      return f$e;
   }

   public static Minecraft method_2934() {
      return f$e;
   }

   public static Minecraft method_2935() {
      return f$e;
   }

   public static Minecraft method_2936() {
      return f$e;
   }

   public static Minecraft method_2937() {
      return f$e;
   }

   public static Minecraft method_2938() {
      return f$e;
   }

   public static Minecraft method_2939() {
      return f$e;
   }

   public static Minecraft method_2940() {
      return f$e;
   }

   public static Minecraft method_2941() {
      return f$e;
   }

   public static Minecraft method_2942() {
      return f$e;
   }

   public static Minecraft method_2943() {
      return f$e;
   }

   public static Minecraft method_2944() {
      return f$e;
   }

   public static Minecraft method_2945() {
      return f$e;
   }

   public static Minecraft method_2946() {
      return f$e;
   }

   public static Minecraft method_3770() {
      return f$e;
   }

   public static Minecraft method_2948() {
      return f$e;
   }

   public static Minecraft method_2949() {
      return f$e;
   }

   public static Minecraft method_2950() {
      return f$e;
   }

   public static Minecraft method_3771() {
      return f$e;
   }

   public static Minecraft method_2952() {
      return f$e;
   }

   public static Minecraft method_3772() {
      return f$e;
   }

   public static Minecraft method_2954() {
      return f$e;
   }

   public static Minecraft method_2955() {
      return f$e;
   }

   public static Minecraft method_2956() {
      return f$e;
   }

   public static Minecraft method_2957() {
      return f$e;
   }

   public static Minecraft method_2958() {
      return f$e;
   }

   public static Minecraft method_2959() {
      return f$e;
   }

   public static Minecraft method_2960() {
      return f$e;
   }

   public static Minecraft method_2961() {
      return f$e;
   }

   public static Minecraft method_2962() {
      return f$e;
   }

   public static Minecraft method_3773() {
      return f$e;
   }

   public static Minecraft method_2964() {
      return f$e;
   }

   public static Minecraft method_2965() {
      return f$e;
   }

   public static Minecraft method_3774() {
      return f$e;
   }

   public static Minecraft method_2967() {
      return f$e;
   }

   public static Minecraft method_2968() {
      return f$e;
   }

   public static Minecraft method_2969() {
      return f$e;
   }

   public static Minecraft method_2970() {
      return f$e;
   }

   public static Minecraft method_2971() {
      return f$e;
   }

   public static Minecraft method_2972() {
      return f$e;
   }

   public static Minecraft method_2973() {
      return f$e;
   }

   public static Minecraft method_2974() {
      return f$e;
   }

   public static Minecraft method_2975() {
      return f$e;
   }

   public static Minecraft method_2976() {
      return f$e;
   }

   public static Minecraft method_2977() {
      return f$e;
   }

   public static Minecraft method_2978() {
      return f$e;
   }

   public static Minecraft method_2979() {
      return f$e;
   }

   public static Minecraft method_2980() {
      return f$e;
   }

   public static Minecraft method_2981() {
      return f$e;
   }

   public static Minecraft method_2982() {
      return f$e;
   }

   public static Minecraft method_2983() {
      return f$e;
   }

   public static Minecraft method_2984() {
      return f$e;
   }

   public static Minecraft method_2985() {
      return f$e;
   }

   public static Minecraft method_3775() {
      return f$e;
   }

   public static Minecraft method_2987() {
      return f$e;
   }

   public static Minecraft method_2988() {
      return f$e;
   }

   public static Minecraft method_2989() {
      return f$e;
   }

   public static Minecraft method_2990() {
      return f$e;
   }

   public static Minecraft method_2991() {
      return f$e;
   }

   public static Minecraft method_2992() {
      return f$e;
   }

   public static Minecraft method_2993() {
      return f$e;
   }

   public static Minecraft method_2994() {
      return f$e;
   }

   public static Minecraft method_2995() {
      return f$e;
   }

   public static Minecraft method_2996() {
      return f$e;
   }

   public static Minecraft method_2997() {
      return f$e;
   }

   public static Minecraft method_2998() {
      return f$e;
   }

   public static Minecraft method_2999() {
      return f$e;
   }

   public static Minecraft method_3000() {
      return f$e;
   }

   public static Minecraft method_3001() {
      return f$e;
   }

   public static Minecraft method_3002() {
      return f$e;
   }

   public static Minecraft method_3003() {
      boolean var10000 = true;
      boolean var10001 = true;
      boolean var10002 = true;
      boolean var10003 = true;
      return f$e;
   }

   public static Minecraft method_3004() {
      return f$e;
   }

   public static Minecraft method_3005() {
      return f$e;
   }

   public static Minecraft method_3006() {
      return f$e;
   }

   public static Minecraft method_3776() {
      return f$e;
   }

   public static Minecraft method_3008() {
      return f$e;
   }

   public static Minecraft method_3009() {
      return f$e;
   }

   public static Minecraft method_3010() {
      return f$e;
   }

   public static Minecraft method_3011() {
      return f$e;
   }

   public static Minecraft method_3012() {
      return f$e;
   }

   public static Minecraft method_3013() {
      return f$e;
   }

   public static Minecraft method_3014() {
      return f$e;
   }

   public static Minecraft method_3015() {
      return f$e;
   }

   public static Minecraft method_3016() {
      return f$e;
   }

   public static Minecraft method_3017() {
      return f$e;
   }

   public static Minecraft method_3018() {
      return f$e;
   }

   public static Minecraft method_3019() {
      return f$e;
   }

   public static Minecraft method_3020() {
      return f$e;
   }

   public static Minecraft method_3021() {
      return f$e;
   }

   public static Minecraft method_3022() {
      return f$e;
   }

   public static Minecraft method_3023() {
      return f$e;
   }

   public static Minecraft method_2683() {
      return f$e;
   }

   public static Minecraft method_2684() {
      return f$e;
   }

   public static Minecraft method_2685() {
      return f$e;
   }

   public static Minecraft method_2686() {
      return f$e;
   }

   public static Minecraft method_2687() {
      return f$e;
   }

   public static Minecraft method_2688() {
      return f$e;
   }

   public static Minecraft method_2689() {
      return f$e;
   }

   public static Minecraft method_2690() {
      return f$e;
   }

   public static Minecraft method_2691() {
      return f$e;
   }

   public static Minecraft method_2692() {
      return f$e;
   }

   public static Minecraft method_2693() {
      return f$e;
   }

   public static Minecraft method_2694() {
      return f$e;
   }

   public static Minecraft method_2695() {
      return f$e;
   }

   public static Minecraft method_2696() {
      return f$e;
   }

   public static Minecraft method_2697() {
      return f$e;
   }

   public static Minecraft method_2698() {
      return f$e;
   }

   public static Minecraft method_2699() {
      return f$e;
   }

   public static Minecraft method_2700() {
      return f$e;
   }

   public static Minecraft method_2701() {
      return f$e;
   }

   public static Minecraft method_2702() {
      return f$e;
   }

   public pA() {
      String[] var10002 = new String[2];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "LongJump";
      var10002[1] = "LJ";
      super("LongJump", var10002, true, -15421042, bE.MOVEMENT);
      Boolean var3 = true;
      String[] var6 = new String[5];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "MiniJumps";
      var6[1] = "MiniJump";
      var6[2] = "SmallJumps";
      var6[3] = "HypixelJumps";
      var6[4] = "HypixelJump";
      this.field_1101 = new t(var3, var6);
      Double var4 = 0.0D;
      Double var8 = 0.0D;
      Double var9 = 0.0D;
      Double var10 = 1.273197475E-314D;
      String[] var10007 = new String[3];
      boolean var10008 = true;
      byte var10009 = 1;
      var10007[0] = "Boost";
      var10007[1] = "Distance";
      var10007[2] = "Length";
      this.field_1107 = new U(var4, var8, var9, var10, var10007);
      sd var5 = sd.Normal;
      var6 = new String[5];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Mode";
      var6[1] = "Type";
      var6[2] = "Method";
      var6[3] = "m";
      var6[4] = "mod";
      this.field_1108 = new ga(var5, var6);
      this.field_1096 = new EG();
      this.field_1102 = 1.1441801305E-314D;
      t[] var10001 = new t[3];
      boolean var2 = true;
      byte var7 = 1;
      var10001[0] = this.field_1108;
      var10001[1] = this.field_1101;
      var10001[2] = this.field_1107;
      this.f$c(var10001);
      ja[] var1 = new ja[3];
      var2 = true;
      var7 = 1;
      var1[0] = new Nd(this);
      var1[1] = new OB(this);
      var1[2] = new Cb(this);
      this.f$c(var1);
   }
}

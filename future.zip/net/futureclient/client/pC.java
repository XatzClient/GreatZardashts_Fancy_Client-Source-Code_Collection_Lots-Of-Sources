package net.futureclient.client;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;

public class pC extends ka {
   private t field_1113;
   private List field_1114;
   private boolean field_1115;
   private Jh field_1116;
   private double field_1117;
   private EntityOtherPlayerMP field_1118;
   private ci field_1119;
   private Jh field_1120;
   private ga field_1121;
   private ga field_1122;
   private U field_1123;

   public void method_4314() {
      super.method_4314();
      if (f$e.world != null && f$e.player != null) {
         this.field_1114.forEach(accept<invokedynamic>());
         f$e.world.removeEntityFromWorld(-1337);
      }

      this.field_1114.clear();
      this.field_1119 = null;
   }

   public static Minecraft method_4242() {
      return f$e;
   }

   public static Minecraft method_4243() {
      return f$e;
   }

   public static Minecraft method_4245() {
      return f$e;
   }

   public static Jh method_2715(pC var0) {
      return var0.field_1120;
   }

   public static Minecraft method_4315() {
      return f$e;
   }

   public static Jh method_2717(pC var0, Jh var1) {
      return var0.field_1120 = var1;
   }

   public static ga method_2718(pC var0) {
      return var0.field_1122;
   }

   public static Jh method_2719(pC var0, Jh var1) {
      return var0.field_1116 = var1;
   }

   public static boolean method_2720(pC var0, boolean var1) {
      return var0.field_1115 = var1;
   }

   private static void method_2721(Packet var0) {
      f$e.player.connection.sendPacket(var0);
   }

   public static EntityOtherPlayerMP method_2722(pC var0) {
      return var0.field_1118;
   }

   public static ci method_2723(pC var0) {
      return var0.field_1119;
   }

   public static Minecraft method_4319() {
      return f$e;
   }

   public static Jh method_2725(pC var0) {
      return var0.field_1116;
   }

   public static boolean method_2726(pC var0) {
      return var0.field_1115;
   }

   public static U method_2727(pC var0) {
      return var0.field_1123;
   }

   public static ci method_2728(pC var0, ci var1) {
      return var0.field_1119 = var1;
   }

   public static ga method_2729(pC var0) {
      return var0.field_1121;
   }

   public static t method_2730(pC var0) {
      return var0.field_1113;
   }

   public static double method_2731(pC var0, double var1) {
      return var0.field_1117 = var1;
   }

   public static List method_2732(pC var0) {
      return var0.field_1114;
   }

   public static Minecraft method_4267() {
      return f$e;
   }

   public static Minecraft method_4269() {
      return f$e;
   }

   public static Minecraft method_4270() {
      return f$e;
   }

   public static Minecraft method_4271() {
      return f$e;
   }

   public static Minecraft method_4273() {
      return f$e;
   }

   public static Minecraft method_4274() {
      return f$e;
   }

   public static Minecraft method_4275() {
      return f$e;
   }

   public static Minecraft method_4276() {
      return f$e;
   }

   public static Minecraft method_4277() {
      return f$e;
   }

   public static Minecraft method_4278() {
      return f$e;
   }

   public static Minecraft method_4279() {
      return f$e;
   }

   public static Minecraft method_4280() {
      return f$e;
   }

   public void method_4326() {
      super.method_4326();
      if (f$e.world != null && f$e.player != null) {
         this.field_1118 = new EntityOtherPlayerMP(f$e.world, new GameProfile(f$e.player.getUniqueID(), f$e.player.getCommandSenderEntity().getName()));
         if ((Boolean)this.field_1113.method_3690()) {
            f$e.world.addEntityToWorld(-1337, this.field_1118);
         }

         this.field_1118.setPositionAndRotation(f$e.player.posX, f$e.player.getEntityBoundingBox().minY, f$e.player.posZ, f$e.player.rotationYaw, f$e.player.rotationPitch);
         this.field_1118.inventory = f$e.player.inventory;
         this.field_1118.inventoryContainer = f$e.player.inventoryContainer;
         this.field_1118.rotationYawHead = f$e.player.rotationYawHead;
         this.field_1118.setSneaking(f$e.player.isSneaking());
         this.field_1118.onLivingUpdate();
      } else {
         this.f$c(false);
      }
   }

   public static Minecraft method_4281() {
      return f$e;
   }

   public pC() {
      String[] var10002 = new String[3];
      boolean var10003 = true;
      byte var10004 = 1;
      var10002[0] = "FakeLag";
      var10002[1] = "Blink";
      var10002[2] = "fl";
      super("FakeLag", var10002, true, -7292787, bE.MOVEMENT);
      sb var3 = sb.Blink;
      String[] var6 = new String[3];
      boolean var10005 = true;
      byte var10006 = 1;
      var6[0] = "Mode";
      var6[1] = "Mod";
      var6[2] = "Type";
      this.field_1122 = new ga(var3, var6);
      hd var4 = hd.Always;
      var6 = new String[4];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Pulse";
      var6[1] = "Puls";
      var6[2] = "Pulss";
      var6[3] = "Pul";
      this.field_1121 = new ga(var4, var6);
      Double var5 = 0.0D;
      Double var9 = 1.0D;
      Double var10 = 0.0D;
      String[] var11 = new String[4];
      boolean var10007 = true;
      byte var10008 = 1;
      var11[0] = "Factor";
      var11[1] = "Ticks";
      var11[2] = "TickCount";
      var11[3] = "Tick";
      this.field_1123 = new U(var5, var9, var10, var11);
      Boolean var7 = true;
      var6 = new String[3];
      var10005 = true;
      var10006 = 1;
      var6[0] = "Render";
      var6[1] = "Draw";
      var6[2] = "r";
      this.field_1113 = new t(var7, var6);
      this.field_1114 = new CopyOnWriteArrayList();
      t[] var10001 = new t[4];
      boolean var2 = true;
      byte var8 = 1;
      var10001[0] = this.field_1122;
      var10001[1] = this.field_1121;
      var10001[2] = this.field_1123;
      var10001[3] = this.field_1113;
      this.f$c(var10001);
      ja[] var1 = new ja[4];
      var2 = true;
      var8 = 1;
      var1[0] = new Tb(this);
      var1[1] = new NC(this);
      var1[2] = new Sd(this);
      var1[3] = new Rd(this);
      this.f$c(var1);
   }
}

package net.futureclient.client;

public class pE extends ja {
   public final DF field_1127;

   public pE(DF var1) {
      this.field_1127 = var1;
   }

   public void method_2753(tE var1) {
      if (var1.method_3980() == lf.KEY_PRESS) {
         this.field_1127.method_3043().forEach(var1.accept<invokedynamic>(var1));
      }

   }

   public void method_4312(CD var1) {
      this.method_2753((tE)var1);
   }

   private static void method_2755(tE var0, eD var1) {
      if (var1.method_3056() != 0 && var1.method_3056() == var0.method_3981()) {
         var1.method_3057();
      }

   }
}

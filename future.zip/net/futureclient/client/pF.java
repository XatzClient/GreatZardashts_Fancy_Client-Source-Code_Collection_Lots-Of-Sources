package net.futureclient.client;

public class pF extends ja {
   public final Zf field_1125;

   public pF(Zf var1) {
      this.field_1125 = var1;
   }

   public void method_2803(Re var1) {
      var1.f$c(true);
   }

   public void method_4312(CD var1) {
      this.method_2803((Re)var1);
   }
}

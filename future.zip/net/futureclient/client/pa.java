package net.futureclient.client;

import java.util.Iterator;
import java.util.List;
import net.minecraft.item.Item;

public class pa extends ja {
   public final ta field_1086;

   public pa(ta var1) {
      this.field_1086 = var1;
   }

   public void method_4183(Xe var1) {
      boolean var2 = false;
      Iterator var3 = ((List)ta.method_3829(this.field_1086).f$c()).iterator();

      pa var10000;
      while(true) {
         if (var3.hasNext()) {
            if (EI.method_887((Item)var3.next()) == null) {
               continue;
            }

            var2 = true;
            var10000 = this;
            break;
         }

         var10000 = this;
         break;
      }

      if ((Boolean)ta.method_3825(var10000.field_1086).method_3690()) {
         if (ta.method_3833(this.field_1086).isEmpty()) {
            int var4;
            int var5 = var4 = 0;

            while(true) {
               if (var5 >= 9) {
                  ta.method_3831(this.field_1086, ta.method_3833(this.field_1086).iterator());
                  break;
               }

               if (((wa)ta.method_3832(this.field_1086).method_3690()).equals(wa.Any) || ((wa)ta.method_3832(this.field_1086).method_3690()).equals(wa.Whitelist) && ((List)ta.method_3829(this.field_1086).f$c()).contains(ta.method_4267().player.inventoryContainer.getSlot(var4 + 36).getStack().getItem()) || ((wa)ta.method_3832(this.field_1086).method_3690()).equals(wa.Blacklist) && !((List)ta.method_3829(this.field_1086).f$c()).contains(ta.method_4273().player.inventoryContainer.getSlot(var4 + 36).getStack().getItem())) {
                  ta.method_3833(this.field_1086).add(var4);
               }

               ++var4;
               var5 = var4;
            }
         }

         if (ta.method_3828(this.field_1086).hasNext()) {
            ta.method_4276().player.inventory.currentItem = (Integer)ta.method_3828(this.field_1086).next();
         } else {
            ta.method_3833(this.field_1086).clear();
         }
      }

      if (!ta.method_4274().gameSettings.keyBindUseItem.isKeyDown() || (Boolean)ta.method_3834(this.field_1086).method_3690()) {
         ta.method_3835(this.field_1086).method_814();
      }

      if (((wa)ta.method_3832(this.field_1086).method_3690()).equals(wa.Any) || ((wa)ta.method_3832(this.field_1086).method_3690()).equals(wa.Whitelist) && var2 || ((wa)ta.method_3832(this.field_1086).method_3690()).equals(wa.Blacklist) && !var2) {
         if (ta.method_3835(this.field_1086).method_811(ta.method_3824(this.field_1086).method_3692().floatValue() * 1000.0F) && ((w)ta.method_4245()).getRightClickDelayTimer() > ta.method_3827(this.field_1086).method_3692().intValue()) {
            ((w)ta.method_4281()).setRightClickDelayTimer(ta.method_3827(this.field_1086).method_3692().intValue());
         }

         if ((Boolean)ta.method_3834(this.field_1086).method_3690() && ta.method_4242().objectMouseOver != null && ta.method_4269().objectMouseOver.getBlockPos() != null && fI.f$c(ta.method_4315().objectMouseOver.getBlockPos())) {
            ((w)ta.method_4319()).method_3640(lf.RIGHT_CLICK);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4183((Xe)var1);
   }
}

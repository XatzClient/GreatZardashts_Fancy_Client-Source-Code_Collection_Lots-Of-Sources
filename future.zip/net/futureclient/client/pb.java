package net.futureclient.client;

import java.util.Objects;
import net.minecraft.block.BlockLiquid;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class pb extends ja {
   public final bB field_1085;

   public pb(bB var1) {
      this.field_1085 = var1;
   }

   public void method_2495(be var1) {
      BlockPos var2 = var1.method_3153();
      if (var1.method_2796() instanceof BlockLiquid && !bB.method_4274().player.isSneaking() && EI.method_872().fallDistance < 3.0F && !fI.f$c() && fI.f$c(false) && fI.f$D(var1.method_3153()) && var1.method_2798() != null && (var1.method_2798().equals(bB.method_4245().player) && !((Qd)bB.method_2818(this.field_1085).method_3690()).equals(Qd.Dolphin) || var1.method_2798().getControllingPassenger() != null && Objects.equals(var1.method_2798().getControllingPassenger(), bB.method_4281().player))) {
         var1.method_2800(new AxisAlignedBB((double)var2.getX(), (double)var2.getY(), (double)var2.getZ(), (double)(var2.getX() + 1), (double)(var2.getY() + 1), (double)(var2.getZ() + 1)));
      }

   }

   public void method_4312(CD var1) {
      this.method_2495((be)var1);
   }
}

package net.futureclient.client;

import net.minecraft.client.Minecraft;

public class pc extends ja {
   public final hb field_1088;

   public pc(hb var1) {
      this.field_1088 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }

   public void method_4147(Lf var1) {
      switch(Md.f$e[var1.method_326().ordinal()]) {
      case 1:
         Minecraft var10000 = hb.method_4245();
         boolean var10001 = false;
         if (var10000.player.onGround && !hb.method_4281().player.isSneaking() && hb.method_4315().world.getCollisionBoxes(hb.method_4242().player, hb.method_4269().player.getEntityBoundingBox().offset(0.0D, 0.0D, 0.0D).shrink(1.748524532E-314D)).isEmpty()) {
            hb.method_4319().player.jump();
         }
      default:
      }
   }
}

package net.futureclient.client;

import java.util.Iterator;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.network.play.server.SPacketPlayerListItem.Action;
import net.minecraft.network.play.server.SPacketPlayerListItem.AddPlayerData;

public class pe extends ja {
   public final MD field_1094;

   public pe(MD var1) {
      this.field_1094 = var1;
   }

   public void method_4312(CD var1) {
      this.method_4230((IF)var1);
   }

   public void method_4230(IF var1) {
      Packet var2;
      SPacketPlayerListItem var4;
      if ((var2 = var1.method_3084()) instanceof SPacketPlayerListItem && (var4 = (SPacketPlayerListItem)var2).getAction() == Action.UPDATE_LATENCY) {
         Iterator var5 = var4.getEntries().iterator();

         while(var5.hasNext()) {
            AddPlayerData var3 = (AddPlayerData)var5.next();
            if (MD.method_4242().getConnection().getPlayerInfo(var3.getProfile().getId()) == null && !MD.method_309(this.field_1094, var3.getProfile().getId()) && MD.method_311(this.field_1094).method_3405(1000L)) {
               oI.f$c(var3.run<invokedynamic>(var3));
               MD.method_311(this.field_1094).method_3404();
            }
         }
      }

   }

   private static void method_2508(AddPlayerData var0) {
      String var1 = hH.f$k(var0.getProfile().getId());
      MD.method_4269().addScheduledTask(var1.run<invokedynamic>(var1));
   }

   private static void method_2771(String var0) {
      la.method_2324().method_2322((new StringBuilder()).insert(0, var0).append(" is vanished.").toString());
   }
}

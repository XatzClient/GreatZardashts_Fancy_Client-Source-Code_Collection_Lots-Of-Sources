package net.futureclient.client;

import net.minecraft.network.play.client.CPacketKeepAlive;

public class pf extends ja {
   public final gf field_1093;

   public pf(gf var1) {
      this.field_1093 = var1;
   }

   public void method_4241(je var1) {
      if (var1.method_3084() instanceof CPacketKeepAlive) {
         CPacketKeepAlive var2 = (CPacketKeepAlive)var1.method_3084();
         if (!gf.method_3483(this.field_1093).contains(var2)) {
            gf.method_3483(this.field_1093).add(var2);
            var1.f$c(true);
         }
      }

   }

   public void method_4312(CD var1) {
      this.method_4241((je)var1);
   }
}

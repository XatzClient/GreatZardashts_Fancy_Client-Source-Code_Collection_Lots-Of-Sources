package net.futureclient.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class pg {
   public static void method_2499(File var0, File var1) {
      byte[] var10000 = new byte[1024];
      boolean var10001 = true;
      byte var10002 = 1;
      byte[] var2 = var10000;
      File var14 = var1;

      IOException var15;
      label53: {
         ZipInputStream var3;
         ZipEntry var4;
         ZipEntry var16;
         try {
            if (!var14.exists()) {
               var1.mkdir();
            }

            var16 = var4 = (var3 = new ZipInputStream(new FileInputStream(var0))).getNextEntry();
         } catch (IOException var8) {
            var15 = var8;
            var10001 = false;
            break label53;
         }

         ZipInputStream var17;
         while(true) {
            FileOutputStream var13;
            try {
               if (var16 == null) {
                  break;
               }

               String var5 = var4.getName();
               File var12 = new File(var1, var5);
               (new File(var12.getParent())).mkdirs();
               var13 = new FileOutputStream(var12);
               var17 = var3;

               int var6;
               while((var6 = var17.read(var2)) > 0) {
                  var17 = var3;
                  var13.write(var2, 0, var6);
               }
            } catch (IOException var10) {
               var15 = var10;
               var10001 = false;
               break label53;
            }

            FileOutputStream var19 = var13;

            try {
               var19.close();
               var16 = var4 = var3.getNextEntry();
            } catch (IOException var9) {
               var15 = var9;
               var10001 = false;
               break label53;
            }
         }

         var17 = var3;
         ZipInputStream var18 = var3;

         try {
            var18.closeEntry();
            var17.close();
            return;
         } catch (IOException var7) {
            var15 = var7;
            var10001 = false;
         }
      }

      IOException var11 = var15;
      var11.printStackTrace();
   }
}

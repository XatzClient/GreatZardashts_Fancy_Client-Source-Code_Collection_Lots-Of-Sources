package net.futureclient.client;

import net.minecraft.network.play.client.CPacketPlayer.Position;

public class qA extends ja {
   public final Nc field_1081;

   public qA(Nc var1) {
      this.field_1081 = var1;
   }

   public void method_2493(dF var1) {
      if (!((eA)this.field_1081.field_272.method_3690()).equals(eA.Vanilla)) {
         double var2 = var1.f$c().minY - Nc.method_597(this.field_1081);
         if (Nc.method_598(this.field_1081) && var2 > (double)var1.method_3117()) {
            double[] var10000 = new double[6];
            boolean var10001 = true;
            byte var10002 = 1;
            var10000[0] = 1.4429571377E-314D;
            var10000[1] = var2 < 1.0D && var2 > 1.273197475E-314D ? 9.676300807E-315D : 0.0D;
            var10000[2] = 1.0D;
            var10000[3] = 3.395193264E-315D;
            var10000[4] = 1.0185579796E-314D;
            var10000[5] = 4.24399158E-315D;
            double[] var4 = var10000;
            if (!((eA)this.field_1081.field_272.method_3690()).equals(eA.AAC) && var2 >= 0.0D) {
               var10000 = new double[8];
               var10001 = true;
               var10002 = 1;
               var10000[0] = 1.4429571377E-314D;
               var10000[1] = 1.188317643E-314D;
               var10000[2] = 1.612716801E-314D;
               var10000[3] = 1.1034378113E-314D;
               var10000[4] = 1.697596633E-314D;
               var10000[5] = 2.0371159592E-314D;
               var10000[6] = 4.24399158E-315D;
               var10000[7] = 1.4429571377E-314D;
               var4 = var10000;
            }

            Nc.method_596(this.field_1081, var2 > 1.0D ? 0.15F : 0.35F);
            boolean var5 = (Boolean)this.field_1081.field_274.method_3690() && fI.f$c();

            int var6;
            for(int var7 = var6 = 0; var7 < (var2 > 1.0D ? var4.length : 2); var7 = var6) {
               Nc.method_4242().player.connection.sendPacket(new Position(Nc.method_4274().player.posX, Nc.method_4245().player.posY + var4[var6], Nc.method_4281().player.posZ, true));
               if ((Boolean)this.field_1081.field_274.method_3690()) {
                  Nc.method_588(this.field_1081);
                  if (Nc.method_593(this.field_1081) >= 2) {
                     ((r)((w)Nc.method_4269()).getTimer()).method_3790(Nc.method_600(this.field_1081));
                     Nc.method_590(this.field_1081, 0);
                  }
               }

               ++var6;
            }

            Nc.method_595(this.field_1081, false);
         }

      }
   }

   public void method_4312(CD var1) {
      this.method_2493((dF)var1);
   }
}

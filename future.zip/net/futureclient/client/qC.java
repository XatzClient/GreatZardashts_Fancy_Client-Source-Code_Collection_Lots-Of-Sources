package net.futureclient.client;

public enum qC {
   private static final qC[] field_1082;
   Tick,
   AAC;

   static {
      qC[] var10000 = new qC[2];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Tick;
      var10000[1] = AAC;
      field_1082 = var10000;
   }
}

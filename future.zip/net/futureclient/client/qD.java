package net.futureclient.client;

public enum qD {
   Rainbow,
   Default,
   Static;

   private static final qD[] field_1092;

   static {
      qD[] var10000 = new qD[3];
      boolean var10001 = true;
      byte var10002 = 1;
      var10000[0] = Default;
      var10000[1] = Rainbow;
      var10000[2] = Static;
      field_1092 = var10000;
   }
}

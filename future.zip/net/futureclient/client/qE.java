package net.futureclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;

public class qE extends ja {
   public final zD field_1087;

   public qE(zD var1) {
      this.field_1087 = var1;
   }

   public void method_4147(Lf var1) {
      if ((Boolean)zD.method_4157(this.field_1087).method_3690()) {
         if (zD.method_4158(this.field_1087) && !zD.method_4283().player.movementInput.sneak) {
            zD.method_4280().player.connection.sendPacket(new CPacketEntityAction(zD.method_4243().player, Action.STOP_SNEAKING));
            zD.method_4156(this.field_1087, false);
         }

      } else {
         boolean var2 = zD.method_4279().player.motionX != 0.0D && zD.method_4271().player.motionZ != 0.0D;
         if (!var2) {
            zD.method_4275().player.connection.sendPacket(new CPacketEntityAction(zD.method_4278().player, Action.START_SNEAKING));
            zD.method_4156(this.field_1087, true);
         } else {
            switch(bf.f$e[var1.method_326().ordinal()]) {
            case 1:
               Minecraft var10000 = zD.method_4270();
               boolean var10001 = false;
               var10000.player.connection.sendPacket(new CPacketEntityAction(zD.method_4277().player, Action.START_SNEAKING));
               zD.method_4273().player.connection.sendPacket(new CPacketEntityAction(zD.method_4267().player, Action.START_SNEAKING));
               zD.method_4274().player.connection.sendPacket(new CPacketEntityAction(zD.method_4276().player, Action.STOP_SNEAKING));
               return;
            case 2:
               zD.method_4281().player.connection.sendPacket(new CPacketEntityAction(zD.method_4245().player, Action.START_SNEAKING));
               zD.method_4269().player.connection.sendPacket(new CPacketEntityAction(zD.method_4242().player, Action.START_SNEAKING));
               zD.method_4156(this.field_1087, true);
            default:
            }
         }
      }
   }

   public void method_4312(CD var1) {
      this.method_4147((Lf)var1);
   }
}

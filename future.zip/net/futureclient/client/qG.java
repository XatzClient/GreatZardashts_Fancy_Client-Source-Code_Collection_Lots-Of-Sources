package net.futureclient.client;

import com.google.gson.reflect.TypeToken;

public final class qG extends TypeToken {
}
